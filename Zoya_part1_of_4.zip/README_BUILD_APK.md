# Building Zoya AI Android APK on Your Phone (No Computer Needed)

This repository includes a complete, ready-to-run GitHub Actions workflow (`.github/workflows/build-zoya-apk.yml`) that compiles the Zoya React web app, bundles it inside the native Android project (`android/`), compiles the Kotlin `AgentVoiceAccessibilityService`, `BankingSafetyConfig`, `AndroidBridge`, and `ZoyaHologramOverlayService` via Gradle (`assembleStandardDebug`), and publishes an installable `zoya-ai-debug.apk` both as a workflow artifact and as a **GitHub Release asset**.

---

## Phone-Friendly Step-by-Step Guide

### Step 1: Export Project to GitHub from AI Studio
1. Open this project in Google AI Studio on your phone or browser.
2. Tap the **GitHub / Export to GitHub** icon in the top toolbar.
3. Sign in to your GitHub account if prompted and create a new repository (for example, `zoya-ai-assistant`).
4. Push the project files to the `main` branch.

### Step 2: Open the Actions Tab on Your Phone
1. Open `https://github.com/<your-username>/<your-repo>` in Chrome or the GitHub mobile app on your phone.
2. Tap the **Actions** tab in the top navigation bar.
3. If GitHub asks to enable workflows on the repository, tap **"I understand my workflows, go ahead and enable them"**.

### Step 3: Run the Workflow
1. Under **Workflows**, select **"Build Zoya AI Native Android APK"**.
2. Note: Pushing to `main` triggers a build automatically. To start a build manually at any time, tap the **"Run workflow"** dropdown button and tap the green **"Run workflow"** button.
3. Wait approximately **4 to 6 minutes** until a green checkmark appears next to the workflow run.

### Step 4: Download & Install `zoya-ai-debug.apk` on Your Phone
Because downloading workflow artifacts on mobile browsers often hits zip/redirect issues, this workflow automatically publishes a direct `.apk` file to your repository's **Releases** page:
1. Go to the main page of your repository on GitHub (`https://github.com/<your-username>/<your-repo>`).
2. Scroll down to the **Releases** section (or visit `https://github.com/<your-username>/<your-repo>/releases`).
3. Tap the latest release (`Zoya AI Android APK (Build #1)`).
4. Under **Assets**, tap **`zoya-ai-debug.apk`** to download the APK directly to your phone's `Downloads` folder.
5. Tap the downloaded `zoya-ai-debug.apk` notification on your phone and tap **Install** (allow "Install unknown apps" if prompted by Android).

---

## First-Launch Phone Configuration
1. **Enter Keys in Android Keystore Vault:** Open the installed Zoya APK, tap **Settings (gear icon) -> Gemini API Key**, enter your Gemini API key, and tap **Run Encrypt-Decrypt Self-Test** to verify hardware-backed `EncryptedSharedPreferences` encryption.
2. **Enter GitHub Token for Python Studio APK Builds:** Go to **Settings -> Tool & Cloud API Keys**, enter your GitHub Personal Access Token (`ghp_...` with `repo` and `workflow` scopes), and open **Python Studio -> Test GitHub Connection**.
3. **Enable Accessibility Service & Banking Shield Self-Test:** Open **Accessibility & Device Control**, enable **Zoya AI Accessibility Service** in Android Settings, and tap **Scan Phone Apps Now** under **Banking Shield Self-Test** to verify all banking/UPI apps on your phone are blocked.
