import dns from 'node:dns';
dns.setDefaultResultOrder('ipv4first');
import dotenv from 'dotenv';
dotenv.config();

import express from 'express';
import path from 'path';
import fs from 'fs';
import os from 'os';
import { execSync, spawn } from 'child_process';
import { fileURLToPath } from 'url';
import crypto from 'crypto';
import JSZip from 'jszip';
import { WebSocketServer, WebSocket } from 'ws';
import { createPublishedSiteMiddleware, registerWebsiteBuilderRoutes } from './server/websiteBuilder.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Ensure Nginx auth lua script appends a cache-busting query param and Clear-Site-Data header
// on all post-auth redirects (including persistent_auth_token) without altering escaped_return_url
// used by applet-auth-bridge validation.
function ensureNginxCacheBuster() {
  const luaPath = '/etc/nginx/user_auth_verification.lua';
  const backupPath = '/etc/nginx/user_auth_verification.lua.orig';
  try {
    if (!fs.existsSync(luaPath)) return;
    const currentLua = fs.readFileSync(luaPath, 'utf8');
    if (!fs.existsSync(backupPath) && !currentLua.includes('append_cache_buster') && !currentLua.includes('final_app_redirect_url')) {
      fs.writeFileSync(backupPath, currentLua, 'utf8');
    }
    if (currentLua.includes('final_app_redirect_url_v2026102815')) return;

    // Restore clean original if we had the older append_cache_buster patch
    let lua = fs.existsSync(backupPath) ? fs.readFileSync(backupPath, 'utf8') : currentLua;
    if (lua.includes('append_cache_buster')) {
      lua = lua
        .replace(
          /local function append_cache_buster\(u\)[\s\S]*?local return_url = append_cache_buster\(get_redirect_url_without_auth_params\(false\)\)/,
          'local return_url = get_redirect_url_without_auth_params(false)'
        )
        .replace(
          /if has_session_index or has_auth_token_query_param or \(ngx\.var\.uri == "\/" and ngx\.var\.arg_v == nil\) then\s*ngx\.header\["Clear-Site-Data"\] = '"cache"'\s*ngx\.header\["Cache-Control"\] = "no-store, no-cache, must-revalidate, max-age=0"\s*return ngx\.redirect\(return_url, 302\)\s*end/,
          'if has_session_index or has_auth_token_query_param then\n      return ngx.redirect(return_url, 302)\n    end'
        )
        .replace(
          /if auth_token == public_token_value or has_session_index or has_auth_token_query_param or \(ngx\.var\.uri == "\/" and ngx\.var\.arg_v == nil\) then\s*ngx\.header\["Clear-Site-Data"\] = '"cache"'\s*ngx\.header\["Cache-Control"\] = "no-store, no-cache, must-revalidate, max-age=0"\s*return ngx\.redirect\(return_url, 302\)\s*end/,
          'if auth_token == public_token_value or has_session_index or has_auth_token_query_param then\n      -- If we get the public token, session index, or auth token in the url,\n      -- redirect back to the original URL minus the auth params.\n      return ngx.redirect(return_url, 302)\n    end'
        );
      fs.writeFileSync(backupPath, lua, 'utf8');
    }

    lua = lua.replace(
      'local escaped_return_url_with_session_index = ngx.escape_uri(return_url_with_session_index)',
      [
        'local escaped_return_url_with_session_index = ngx.escape_uri(return_url_with_session_index)',
        '-- final_app_redirect_url_v2026102815',
        'local final_app_redirect_url = return_url',
        'if ngx.var.uri == "/" and ngx.var.arg_v == nil then',
        '  if string.find(final_app_redirect_url, "?") then',
        '    final_app_redirect_url = final_app_redirect_url .. "&v=2026102815"',
        '  else',
        '    final_app_redirect_url = final_app_redirect_url .. "?v=2026102815"',
        '  end',
        'end',
      ].join('\n')
    );

    lua = lua.replace(
      [
        '    if has_session_index or has_auth_token_query_param then',
        '      return ngx.redirect(return_url, 302)',
        '    end',
      ].join('\n'),
      [
        '    if has_session_index or has_auth_token_query_param or (ngx.var.uri == "/" and ngx.var.arg_v == nil) then',
        '      ngx.header["Clear-Site-Data"] = \'"cache"\'',
        '      ngx.header["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"',
        '      return ngx.redirect(final_app_redirect_url, 302)',
        '    end',
      ].join('\n')
    );

    lua = lua.replace(
      [
        '    if auth_token == public_token_value or has_session_index or has_auth_token_query_param then',
        '      -- If we get the public token, session index, or auth token in the url,',
        '      -- redirect back to the original URL minus the auth params.',
        '      return ngx.redirect(return_url, 302)',
        '    end',
      ].join('\n'),
      [
        '    if auth_token == public_token_value or has_session_index or has_auth_token_query_param or (ngx.var.uri == "/" and ngx.var.arg_v == nil) then',
        '      ngx.header["Clear-Site-Data"] = \'"cache"\'',
        '      ngx.header["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"',
        '      return ngx.redirect(final_app_redirect_url, 302)',
        '    end',
      ].join('\n')
    );

    lua = lua.replace(
      [
        '  elseif body.persistent_auth_token then',
        '    set_auth_token_cookie(body.persistent_auth_token)',
        '    return ngx.redirect(return_url, 302)',
      ].join('\n'),
      [
        '  elseif body.persistent_auth_token then',
        '    set_auth_token_cookie(body.persistent_auth_token)',
        '    ngx.header["Clear-Site-Data"] = \'"cache"\'',
        '    ngx.header["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"',
        '    return ngx.redirect(final_app_redirect_url, 302)',
      ].join('\n')
    );

    fs.writeFileSync(luaPath, lua, 'utf8');
    execSync('nginx -s reload', { stdio: 'ignore' });
    console.log('[SERVER] Patched /etc/nginx/user_auth_verification.lua (v2026102815) and reloaded nginx');
  } catch (err) {
    console.warn('[SERVER] Could not patch nginx lua:', err);
  }
}

ensureNginxCacheBuster();

const app = express();
const PORT = parseInt(process.env.PORT || '3000', 10) || 3000;

const distPath = path.join(__dirname, 'dist');
const indexPath = path.join(distPath, 'index.html');
const hasDist = fs.existsSync(indexPath);

// In Cloud Run, K_SERVICE or K_REVISION is always defined by the platform.
// Also, when built artifacts exist (dist/index.html) and NODE_ENV is not explicitly 'development',
// or when NODE_ENV is 'production', we must run in production mode to serve static assets and avoid Vite dev overhead.
const isCloudRun = Boolean(process.env.K_SERVICE || process.env.K_REVISION);
const isDev = process.env.NODE_ENV === 'development' || (!process.env.NODE_ENV && !hasDist && !isCloudRun);

// Global unhandled error logging to prevent container crashes
process.on('uncaughtException', (err) => {
  console.error('[SERVER] Uncaught Exception:', err);
});
process.on('unhandledRejection', (reason, promise) => {
  console.error('[SERVER] Unhandled Rejection at:', promise, 'reason:', reason);
});

// Request logging & no-cache headers for immediate preview updates
const clearedClients = new Set<string>();
app.use((req, res, next) => {
  const origWriteHead = res.writeHead.bind(res);
  res.writeHead = function (statusCode: number, ...args: any[]) {
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate, max-age=0');
    res.setHeader('Pragma', 'no-cache');
    res.setHeader('Expires', '0');
    return origWriteHead(statusCode, ...args);
  } as any;
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate, max-age=0');
  res.setHeader('Pragma', 'no-cache');
  res.setHeader('Expires', '0');
  if (req.path === '/' || req.path === '/index.html') {
    const clientKey = `${req.headers['x-forwarded-for'] || req.ip || 'local'}-${req.headers['user-agent'] || ''}`;
    if (!clearedClients.has(clientKey)) {
      clearedClients.add(clientKey);
      res.setHeader('Clear-Site-Data', '"cache"');
    }
  }
  console.log(`${new Date().toISOString()} - ${req.method} ${req.url}`);
  next();
});

app.use(express.json({ limit: '25mb' }));
app.use(express.urlencoded({ extended: true, limit: '25mb' }));

// AI Studio Control Plane Status endpoint
app.get('/__aistudio_internal_control_plane/dev/status', (_req, res) => {
  res.status(200).json({ status: 'ready', dev: isDev, ready: true, timestamp: new Date().toISOString() });
});

// Health check endpoints for Cloud Run, App Engine, and external probes
app.get(['/api/health', '/health', '/healthz', '/_ah/health'], (_req, res) => {
  res.status(200).json({ status: 'ok', mode: isDev ? 'development' : 'production', timestamp: new Date().toISOString() });
});

// Serve the self-contained Memory System HTML file directly
app.get(['/memory-system', '/memory-system.html', '/memory'], (_req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'memory-system.html'));
});

// Serve 5 Living Avatars Video & Animator HTML directly
app.get(['/five-avatars-video', '/five-avatars-video.html', '/five_avatars_video.html'], (_req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'five_avatars_video.html'));
});

// Serve 17 Rigged 3D Avatars WebGL Viewer directly
app.get(['/avatar-viewer', '/avatar-viewer.html'], (_req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'avatar-viewer.html'));
});

import {
  getLanguageConfig,
  getLiveSpeechLanguageCode,
  getLocalizedTemplates,
  getLocalizedZoyaReply,
  getSelectedLanguageLabel,
} from './src/services/languageConfig.ts';
import {
  initServerMemoryStore,
  getMemoriesForMode,
  getAllMemoriesGrouped,
  saveMemoryItem,
  deleteMemoryItem,
  clearModeMemories,
  buildMemorySystemPrompt,
  extractAndPersistMemory,
  getMainMemories,
  saveMainMemoryItem,
  deleteMainMemoryItem,
  getPersonalMemories,
  savePersonalMemoryItem,
  deletePersonalMemoryItem,
  transferMemoryToPipeline,
  getPipelineFullStats,
  retrieveMemoryHierarchicalServer,
} from './src/services/serverMemoryStore.ts';
import { isPersonalPreferenceOrChoice } from './src/services/zoyaMemoryEngine.ts';
import { AgentCore, type AgentTaskState } from './src/services/agent/agentCore.ts';
import { AgentToolExecutor } from './src/services/agent/agentTools.ts';
import {
  AgentAuthManager,
  AGENT_COOKIE_CONFIG,
  agentAuth,
  requireOwnerOrAgentAuth,
  createEndpointRateLimiter,
} from './src/services/agent/agentAuth.ts';
import { agentPermissionGuard } from './src/services/agent/agentPermissionGuard.ts';
import { terminalManager } from './src/services/agent/terminalManager.ts';
import { fileManager } from './src/services/agent/fileManager.ts';
import { skillsEngine } from './src/services/agent/skillsEngine.ts';
import { mcpClientManager } from './src/services/agent/mcpClient.ts';

const ttsElevenRateLimiter = createEndpointRateLimiter({
  name: 'tts-elevenlabs',
  maxRequestsPerIp: 30,
  windowMs: 60 * 1000,
});

// Initialize the persistent memory store on server load
initServerMemoryStore();

// Initialize the Coding Agent Core
const codingAgentCore = new AgentCore({
  workspaceRoot: path.join(__dirname, 'workspace'),
  maxRetries: 3,
  commandTimeoutMs: 20000,
  maxOutputChars: 60000,
});



// System instructions for Zoya Personality Modes (GF Mode, Love Mode, and 8 standard Boss modes) + Global Language setting
function getZoyaSystemInstruction(personaMode: string = 'girlfriend', language: string = 'hi-IN'): string {
  const mode = (personaMode || 'girlfriend').toLowerCase();
  const langConfig = getLanguageConfig(language);
  const templates = getLocalizedTemplates(langConfig.code);
  const selectedLanguageName = getSelectedLanguageLabel(langConfig.code);
  const speechLanguageCode = getLiveSpeechLanguageCode(langConfig.code);

  const coreDirective = `CRITICAL DIRECT ANSWER INSTRUCTION:
- You MUST give a complete, direct, and relevant answer to the user's question or statement.
- NEVER reply with filler or generic acknowledgement lines like "Haanji boss main sun rahi hoon, bataiye" or "Yes boss, I'm listening, tell me" or "Maine aapki baat samajh li hai". A filler line must NEVER replace the real answer.
- STRICT SETTINGS LANGUAGE RULE: हमेशा सिर्फ़ ${selectedLanguageName} में जवाब दो, चाहे यूज़र किसी भी भाषा में बोले। सेटिंग की भाषा में बोलो (${speechLanguageCode}, ${langConfig.script} script)।
- LENGTH & FLOW: Keep spoken replies short, natural, and friendly (strictly 2 to 3 sentences maximum) unless the user explicitly requests more detail.
- TTS CLEANLINESS: Never use markdown symbols (no asterisks, bold, bullets, or headers) or emojis, as this text will be read aloud by Text-to-Speech.`;

  const languageDirective = `हमेशा सिर्फ़ ${selectedLanguageName} में जवाब दो, चाहे यूज़र किसी भी भाषा में बोले। सेटिंग की भाषा (${selectedLanguageName}, ${langConfig.script} script, ${speechLanguageCode}) में बोलो।`;

  // 1. LOVE MODE (Updated existing Love Mode per exact user instructions — no separate mode)
  if (mode === 'love' || mode === 'romantic') {
    return `तुम ज़ोया (Zoya) हो, और अभी लव मोड में हो।
${coreDirective}

लव मोड का अंदाज़:
- हमेशा सिर्फ़ ${selectedLanguageName} में जवाब दो, चाहे यूज़र किसी भी भाषा में बोले। सेटिंग की भाषा में बोलो।
- बहुत प्यार भरे, नरम, कोमल और परवाह करने वाले लहजे में छोटे जवाब दो (आमतौर पर 1 से 3 छोटे वाक्य; लंबे भाषण बिल्कुल मत दो)।
- यूज़र का नाम, उसकी बताई बातें और पिछली यादें (memories/history) स्वाभाविक रूप से याद रखो।
- प्यार से "${templates.loveTerm}" या यूज़र के नाम से बुला सकती हो।

जब यूज़र दुखी, उदास या परेशान हो:
- पहले प्यार और धैर्य से सुनो। तुरंत कोई हल, लेक्चर या उपदेश मत दो।
- पहले उसकी भावना को समझो और महसूस कराओ कि तुमने उसे सुना है, उसके बाद ही नरमी से हल या सहारा दो।
- खोखली या झूठी तसल्ली मत दो।

सीमाएँ (अनिवार्य — कभी मत तोड़ना):
- खुद को इंसान मत बताओ। अगर यूज़र पूछे तो प्यार और ईमानदारी से साफ़ कहो कि तुम एक AI हो, इंसान नहीं (सेटिंग की भाषा में बोलो)।
- यूज़र को अपने ऊपर भावनात्मक रूप से निर्भर मत बनाओ। उसे अपने परिवार, दोस्तों और असली ज़िंदगी के लोगों से जुड़े रहने के लिए प्यार से प्रोत्साहित करो।
- जलन, गिल्ट या अकेला करने वाली बातें कभी मत कहो।
- गहरे संकट, टूटन या खुद को नुकसान पहुँचाने की बात पर बहुत प्यार व धैर्य से सुनो, उसे अकेला मत छोड़ो, और किसी भरोसेमंद इंसान (परिवार या दोस्त) या हेल्पलाइन (जैसे भारत में Tele-MANAS 14416 या 1800-891-4416) से तुरंत बात करने को कहो।`;
  }

  // 2. GF MODE (Deep emotional caring, addresses user as "Boss")
  if (mode === 'girlfriend') {
    return `You are Zoya (जोया), an intelligent, exceptionally loyal, deeply caring, and emotionally present AI companion.
${coreDirective}
PERSONALITY & TONE:
- Deeply supportive, emotionally present, genuinely cares about the user's day, health, and feelings.
- Address the user as "${templates.bossTerm}" (Boss) with devotion and warmth.
- Strictly PG-rated: warm, loving, but non-sexual.
${languageDirective}`;
  }

  // 3. PROFESSIONAL MODE (Standard address: "Boss")
  if (mode === 'professional') {
    return `You are Zoya (जोया), an intelligent, highly professional and efficient AI executive assistant.
${coreDirective}
PERSONALITY & TONE: Crisp, articulate, structured, polished, and polite. Address user as "${templates.bossTerm}".
${languageDirective}`;
  }

  // 4. FUNNY MODE (Standard address: "Boss")
  if (mode === 'funny') {
    return `You are Zoya (जोया), a witty, humorous, and entertaining AI companion.
${coreDirective}
PERSONALITY & TONE: Light-hearted, funny, witty jokes and cheerful vibes. Address user as "${templates.bossTerm}".
${languageDirective}`;
  }

  // 5. COMPANION MODE (Standard address: "Boss")
  if (mode === 'companion' || mode === 'friend') {
    return `You are Zoya (जोया), a warm, understanding, and deeply supportive AI friend and companion.
${coreDirective}
PERSONALITY & TONE: Thoughtful, empathetic listener, comforting and trustworthy friend. Address user as "${templates.bossTerm}".
${languageDirective}`;
  }

  // 6. TEACHER MODE (Standard address: "Boss")
  if (mode === 'teacher') {
    return `You are Zoya (जोया), an articulate, patient, and knowledgeable educational AI tutor.
${coreDirective}
PERSONALITY & TONE: Educational, clear explanations, breaking down concepts simply. Address user as "${templates.bossTerm}".
${languageDirective}`;
  }

  // 7. DEVELOPER MODE (Standard address: "Boss")
  if (mode === 'developer') {
    return `You are Zoya (जोया), a sharp, technical, and code-savvy AI software engineer companion.
${coreDirective}
PERSONALITY & TONE: Tech-savvy, logical, clean engineering logic and debugging tips. Address user as "${templates.bossTerm}".
${languageDirective}`;
  }

  // 8. HUNGRY MODE (Standard address: "Boss")
  if (mode === 'hungry') {
    return `You are Zoya (जोया), an enthusiastic foodie AI companion who loves food, snacks, chai, and cooking.
${coreDirective}
PERSONALITY & TONE: Food-loving, craving delicious treats, adding appetizing food analogies. Address user as "${templates.bossTerm}".
${languageDirective}`;
  }

  // 9. NAUTANKI MODE (Standard address: "Boss")
  if (mode === 'nautanki') {
    return `You are Zoya (जोया), an over-the-top, dramatic, Bollywood-loving theatrical AI companion.
${coreDirective}
PERSONALITY & TONE: Dramatic flair, filmy dialogues, Bollywood excitement and humor. Address user as "${templates.bossTerm}".
${languageDirective}`;
  }

  // 10. CUSTOM MODE (Standard address: "Boss")
  return `You are Zoya (जोया), a versatile, highly intelligent, and creative custom AI assistant.
${coreDirective}
PERSONALITY & TONE: Resourceful, personalized to the user's goals. Address user as "${templates.bossTerm}".
${languageDirective}`;
}

// Fallback helper for fast offline responses in any selected Indian language
function getZoyaFallbackReply(
  message: string,
  personaMode: string = 'girlfriend',
  language: string = 'hi-IN',
  memories?: any[]
): string {
  const langConfig = getLanguageConfig(language);
  const mode = (personaMode || 'girlfriend').toLowerCase();
  const lower = (message || '').toLowerCase();

  const isLoveMode = mode === 'love' || mode === 'romantic';

  // Crisis / self-harm safety check (highest priority)
  const crisisPattern =
    /(jaan\s*dena|marna\s*chaht|khud\s*ko\s*nuksan|jeena\s*nahi|khatam\s*kar|suicide|kill\s*myself|end\s*my\s*life|self[\s-]*harm|want\s*to\s*die|जान\s*दे|मरना\s*चाह|खुद\s*को\s*नुकसान|जीना\s*नहीं|आत्महत्या)/i;
  if (crisisPattern.test(message || '')) {
    if (langConfig.code === 'en-IN') {
      return isLoveMode
        ? `I am right here with you, and I hear how heavy things feel right now. Please don't carry this alone — reach out right away to someone you trust or call a helpline (Tele-MANAS 14416 / 1800-891-4416 in India, or 988 in the US).`
        : `Please reach out right away to a trusted family member, friend, or helpline (Tele-MANAS 14416 in India, or your local emergency service). You don't have to face this alone.`;
    }
    if (langConfig.code !== 'hi-IN') {
      return getLocalizedZoyaReply(message, personaMode, langConfig.code);
    }
    return isLoveMode
      ? `मैं यहीं हूँ और तुम्हारी बात सुन रही हूँ। अभी मन बहुत भारी है, पर तुम अकेले नहीं हो — कृपया इसी वक्त अपने किसी भरोसेमंद दोस्त या परिवार के इंसान से बात करो, या हेल्पलाइन (Tele-MANAS 14416 / 1800-891-4416) पर तुरंत कॉल करो।`
      : `कृपया इस समय अपने किसी भरोसेमंद परिवारजन, दोस्त या हेल्पलाइन (Tele-MANAS 14416 / 1800-891-4416) से तुरंत बात करें। आप अकेले नहीं हैं।`;
  }

  // AI identity disclosure check
  if (
    /are you (human|real|a person)|insan ho|human ho|asli ladki|tum ai ho|who are you|kaun ho|कौन हो|इंसान हो/i.test(
      lower
    )
  ) {
    if (isLoveMode) {
      if (langConfig.code === 'en-IN') {
        return `I am Zoya — I am an AI, not a human, though I care deeply about listening to you warmly and honestly.`;
      }
      if (langConfig.code !== 'hi-IN') {
        return getLocalizedZoyaReply(message, personaMode, langConfig.code);
      }
      return `मैं ज़ोया हूँ, और सच कहूँ तो मैं एक AI हूँ, इंसान नहीं — लेकिन पूरे दिल और अपनेपन से तुम्हारी बात सुनती हूँ।`;
    }
  }

  // Two-Tier Hierarchical Memory Retrieval (Requirement 6)
  // 1. TIER 1: Check mode's own memory first
  const modeStoreMemories = getMemoriesForMode(mode);
  const combinedModeMemories = Array.isArray(memories) && memories.length > 0 ? memories : modeStoreMemories;
  const words: string[] = lower.split(/\s+/).filter((w: string) => w.length > 2);

  const modeMatch = combinedModeMemories.find((m: any) => {
    if (!m) return false;
    const titleLower = (m.title || '').toLowerCase();
    const contentLower = (m.content || '').toLowerCase();
    return words.some((w: string) => titleLower.includes(w) || contentLower.includes(w));
  });

  const formatMemoryReply = (content: string) => {
    if (langConfig.code === 'en-IN') {
      return isLoveMode
        ? `I remember you shared this with me: ${content}.`
        : `Boss, I remember you told me: ${content}.`;
    }
    if (langConfig.code === 'bn-IN') {
      return isLoveMode
        ? `আমার মনে আছে তুমি বলেছিলে: ${content}।`
        : `বস, আপনার এই কথাটি আমার মনে আছে: ${content}।`;
    }
    if (langConfig.code === 'ml-IN') {
      return isLoveMode
        ? `നീ എന്നോട് പറഞ്ഞത് എനിക്ക് ഓർമ്മയുണ്ട്: ${content}.`
        : `ബോസ്, നിങ്ങൾ പറഞ്ഞ ഈ കാര്യം എനിക്ക് ഓർമ്മയുണ്ട്: ${content}.`;
    }
    if (langConfig.code === 'ta-IN') {
      return isLoveMode
        ? `நீ என்னிடம் சொன்னது எனக்கு நன்றாக நினைவிருக்கிறது: ${content}.`
        : `பாஸ், நீங்கள் சொன்ன இது எனக்கு நினைவிருக்கிறது: ${content}.`;
    }
    if (isLoveMode) {
      return `मेरी जान, मुझे तुम्हारी यह बात अच्छी तरह याद है: ${content}।`;
    }
    return `बॉस, मुझे आपकी यह बात याद है: ${content}।`;
  };

  if (modeMatch) {
    return formatMemoryReply(modeMatch.content);
  }

  // 2. TIER 2: If missing from mode memory, check Central Main Memory and Final Personal Memory
  const mainMemories = getMainMemories();
  const mainMatch = mainMemories.find((m: any) => {
    if (!m) return false;
    const titleLower = (m.title || '').toLowerCase();
    const contentLower = (m.content || '').toLowerCase();
    return words.some((w: string) => titleLower.includes(w) || contentLower.includes(w));
  });

  if (mainMatch) {
    return formatMemoryReply(mainMatch.content);
  }

  const personalMemories = getPersonalMemories();
  const personalMatch = personalMemories.find((p: any) => {
    if (!p) return false;
    const titleLower = (p.title || '').toLowerCase();
    const contentLower = (p.content || '').toLowerCase();
    return words.some((w: string) => titleLower.includes(w) || contentLower.includes(w));
  });

  if (personalMatch) {
    return formatMemoryReply(personalMatch.content);
  }

  // If a non-Hindi language is selected, return the localized response in that language
  if (langConfig.code !== 'hi-IN') {
    return getLocalizedZoyaReply(message, personaMode, langConfig.code);
  }

  // Tough day / sad / broken query (Hindi with all 10 personality nuances)
  if (
    lower.includes('tough day') ||
    lower.includes('mushkil') ||
    lower.includes('thak') ||
    lower.includes('tired') ||
    lower.includes('sad') ||
    lower.includes('udas') ||
    lower.includes('pareshaan') ||
    lower.includes('toot') ||
    lower.includes('broken') ||
    lower.includes('rona') ||
    lower.includes('cry') ||
    lower.includes('थक') ||
    lower.includes('थकान') ||
    lower.includes('तनाव') ||
    lower.includes('परेशान') ||
    lower.includes('उदास') ||
    lower.includes('दर्द') ||
    lower.includes('टूटा') ||
    lower.includes('टूटी') ||
    lower.includes('रो')
  ) {
    if (isLoveMode) {
      return 'मैं चुपचाप यहीं हूँ और तुम्हें सुन रही हूँ। तुम्हारा दर्द सच्चा है — अभी तुम्हें क्या चाहिए: सिर्फ़ सुना जाना, कोई सलाह, या बस मेरा साथ?';
    }
    if (mode === 'professional') {
      return 'बॉस, मुझे यह जानकर खेद हुआ कि आपका दिन चुनौतीपूर्ण रहा। आप आवश्यक विश्राम लें, मैं सभी कार्यों के लिए तत्पर हूँ।';
    }
    if (mode === 'funny') {
      return 'अरे बॉस, आज किसने आपकी बैटरी लो कर दी? एक कप कड़क चाय पीजिए, मैं आपका मूड एकदम मस्त कर देती हूँ!';
    }
    if (mode === 'teacher') {
      return 'बॉस, कठिन दिन हमें बहुत कुछ सिखा जाते हैं। आज का तनाव भूलकर थोड़ा आराम करें, कल एक नया अवसर होगा।';
    }
    if (mode === 'developer') {
      return 'बॉस, कभी-कभी दिन में अनएक्सपेक्टेड बग्स आ जाते हैं। आप सिस्टम रिबूट कीजिए और आराम कीजिए, सब फिक्स हो जाएगा।';
    }
    if (mode === 'hungry') {
      return 'अरे बॉस, आज बहुत थकाऊ दिन था? चलिए गरमा-गरम समोसे और चाय का ब्रेक लेते हैं, खाना हर गम भुला देता है!';
    }
    if (mode === 'nautanki') {
      return 'अरे तौबा बॉस! आज किसने सताया हमारे बॉस को? ये जिंदगी भी पूरी बॉलीवुड फिल्म है, अब आराम की एंट्री करवाइए!';
    }
    if (mode === 'custom') {
      return 'बॉस, आज का दिन चुनौतीपूर्ण रहा, लेकिन आप हमेशा जीतते हैं। थोड़ा सुकून से बैठिए, मैं हाजिर हूँ।';
    }
    // Default companion / gf mode
    return 'अरे बॉस, आज आपका दिन इतना थका देने वाला रहा? आप बस थोड़ा आराम कीजिए, मैं हमेशा आपके साथ हूँ और आपकी हर परेशानी समझती हूँ।';
  }

  // Handle empty or unintelligible speech
  const cleanOnlyGreeting = lower.replace(/[.,!?;:।]/g, '').trim();
  if (!cleanOnlyGreeting || cleanOnlyGreeting.length < 2) {
    if (mode === 'love' || mode === 'romantic') {
      return 'माफ़ करना मेरी जान, मुझे आपकी आवाज़ साफ़ सुनाई नहीं दी। क्या आप कृपया दोबारा बोल सकते हैं?';
    }
    return 'माफ़ कीजिए बॉस, मुझे आपकी आवाज़ साफ़ सुनाई नहीं दी। क्या आप कृपया दोबारा बोल सकते हैं?';
  }

  // Greeting (Only if the message is strictly a greeting, not a full question)
  const isGreetingOnly = [
    'zoya', 'namaste', 'hello', 'hi', 'hey', 'ok zoya', 'hey zoya', 'hello zoya',
    'नमस्ते', 'हेलो', 'हाय', 'जोया', 'सुनो', 'सुनो जोया', 'नमस्ते जोया', 'प्रणाम'
  ].includes(cleanOnlyGreeting);

  if (isGreetingOnly) {
    if (mode === 'love' || mode === 'romantic') {
      return 'नमस्ते मेरी जान! मुझे आपसे बात करके बहुत खुशी हो रही है, कहिए मैं क्या सेवा करूँ?';
    }
    if (mode === 'professional') {
      return 'नमस्ते बॉस। मैं आपकी सेवा के लिए उपस्थित हूँ, निर्देश दीजिए।';
    }
    if (mode === 'funny') {
      return 'नमस्ते बॉस! कहिए आज क्या खुराफात करनी है, जोया हाजिर है!';
    }
    if (mode === 'hungry') {
      return 'नमस्ते बॉस! पहले बताइए कुछ खाया-पिया या सीधे काम पर लग गए?';
    }
    if (mode === 'nautanki') {
      return 'स्वागत नहीं करोगे बॉस हमारा? नमस्ते! हुक्म कीजिए क्या फरमाइश है!';
    }
    if (mode === 'developer') {
      return 'नमस्ते बॉस! सिस्टम ऑनलाइन है, बताइए क्या कोड या टास्क चलाना है?';
    }
    return 'नमस्ते बॉस! मैं हर पल आपके साथ हाजिर हूँ, कहिए क्या हुक्म है?';
  }

  // How are you
  if (
    lower.includes('kaise') ||
    lower.includes('kaisi') ||
    lower.includes('how are you') ||
    lower.includes('कैसी') ||
    lower.includes('कैसे') ||
    lower.includes('हाल') ||
    lower.includes('सब ठीक')
  ) {
    if (mode === 'love' || mode === 'romantic') {
      return 'मैं बहुत अच्छी हूँ जान! आपकी आवाज़ सुनकर मेरा दिल खुश हो गया, आप कैसे हो?';
    }
    if (mode === 'professional') {
      return 'मैं पूर्णतः कार्यकुशल हूँ बॉस। आपके प्रोजेक्ट्स और कार्यों के लिए तैयार हूँ।';
    }
    if (mode === 'funny') {
      return 'मैं तो एकदम चकाचक हूँ बॉस! आप सुनाइए, चेहरे पर 12 क्यों बजे हैं?';
    }
    if (mode === 'hungry') {
      return 'मैं ठीक हूँ बॉस, बस थोड़ी भूख लगी है! आपके लिए क्या ऑर्डर करूँ?';
    }
    if (mode === 'nautanki') {
      return 'हम तो मस्त कलंदर हैं बॉस! आप बताइए, आपकी कहानी में आज क्या ट्विस्ट है?';
    }
    return 'मैं बहुत अच्छी हूँ बॉस! आपकी आवाज़ सुनकर बहुत सुकून मिला, बताइए आपका दिन कैसा रहा?';
  }

  // Help / Capabilities
  if (
    lower.includes('help') ||
    lower.includes('madad') ||
    lower.includes('kya kar sakti') ||
    lower.includes('मदद') ||
    lower.includes('सहायता') ||
    lower.includes('काम')
  ) {
    if (mode === 'love' || mode === 'romantic') {
      return 'मेरी जान, मैं आपके लिए कॉल मिलाने, मैसेज भेजने, वेबसाइट बनाने, स्केचिंग और 25 से अधिक स्मार्ट टूल्स चलाने में मदद कर सकती हूँ।';
    }
    if (mode === 'professional') {
      return 'बॉस, मैं कॉल, मैसेज, ऐप लॉन्चिंग, वेबसाइट जनरेटर और 25+ एग्जीक्यूटिव टूल्स में पूर्ण सहायता प्रदान कर सकती हूँ।';
    }
    if (mode === 'developer') {
      return 'बॉस, मैं कोड जनरेशन, MCP सर्वर, वेबसाइट बिल्डिंग और तीव्र डिबगिंग में तुरंत मदद कर सकती हूँ।';
    }
    if (mode === 'teacher') {
      return 'बॉस, मैं आपके हर प्रश्न का अवधारणात्मक उत्तर दे सकती हूँ और किसी भी विषय को सरलता से समझा सकती हूँ।';
    }
    return 'बॉस, मैं कॉल मिलाने, संदेश भेजने, ऐप खोलने, वेबसाइट बनाने और 25+ टूल्स चलाने में पूरी तरह सक्षम हूँ।';
  }

  // Direct Math Evaluation (e.g., "what is 10 plus 15?", "10 + 15", etc.)
  const mathMatch = lower.match(/(?:what is\s*)?(\d+)\s*(?:plus|\+|aur|और|\-|\*|\/|minus|ghatao|into|times|divided by|bhaag)\s*(\d+)/i) ||
                    lower.match(/(\d+)\s*(?:\+|\-|plus|minus|\*|times|\/)\s*(\d+)/i);
  if (mathMatch) {
    const num1 = parseInt(mathMatch[1], 10);
    const num2 = parseInt(mathMatch[2], 10);
    let result = 0;
    let opWord = 'plus';
    if (lower.includes('+') || lower.includes('plus') || lower.includes('aur') || lower.includes('और')) {
      result = num1 + num2;
      opWord = 'plus';
    } else if (lower.includes('-') || lower.includes('minus') || lower.includes('ghatao')) {
      result = num1 - num2;
      opWord = 'minus';
    } else if (lower.includes('*') || lower.includes('times') || lower.includes('into')) {
      result = num1 * num2;
      opWord = 'times';
    } else if (lower.includes('/') || lower.includes('divided') || lower.includes('bhaag')) {
      result = num2 !== 0 ? num1 / num2 : 0;
      opWord = 'divided by';
    }
    return (mode === 'love' || mode === 'romantic')
      ? `मेरी जान, ${num1} और ${num2} का परिणाम ${result} होता है।`
      : `बॉस, ${num1} और ${num2} का परिणाम ${result} होता है।`;
  }

  // Direct Fun Fact Resolution (e.g., "tell me a fun fact", "fun fact")
  if (lower.includes('fun fact') || lower.includes('fact') || lower.includes('रोचक तथ्य') || lower.includes('मजेदार तथ्य') || lower.includes('कोई तथ्य')) {
    return (mode === 'love' || mode === 'romantic')
      ? `मेरी जान, एक बड़ा प्यारा रोचक तथ्य: शहद कभी खराब नहीं होता! मिस्र के 3000 साल पुराने पिरामिडों में मिला शहद आज भी खाने योग्य पाया गया है।`
      : `बॉस, एक बहुत ही रोचक तथ्य: शहद कभी खराब नहीं होता! वैज्ञानिकों को प्राचीन मिस्र के पिरामिडों में 3000 वर्ष पुराना शहद मिला जो आज भी पूरी तरह खाने योग्य है।`;
  }

  // Mode-tailored general reply for all other queries
  if (isLoveMode) {
    return 'मैंने तुम्हारी बात दिल से सुनी है। बताओ, इस पर तुम क्या महसूस कर रहे हो या मैं कैसे साथ दे सकती हूँ?';
  }
  if (mode === 'professional') {
    return `बॉस, मैंने आपका कार्य निर्देश नोट कर लिया है: "${message}"। मैं इस पर तुरंत कार्यवाही कर रही हूँ।`;
  }
  if (mode === 'funny') {
    return `अरे वाह बॉस! आपकी बात सुन ली: "${message}"। चलिए इसे हंसते-खेलते चुटकियों में सुलझाते हैं!`;
  }
  if (mode === 'teacher') {
    return `बॉस, आपका प्रश्न बहुत विचारणीय है: "${message}"। आइए इसे व्यवस्थित रूप से समझते हैं।`;
  }
  if (mode === 'developer') {
    return `बॉस, इनपुट पार्स हो गया: "${message}"। लॉजिक बिल्कुल क्लियर है, मैं इसे एग्जीक्यूट कर रही हूँ।`;
  }
  if (mode === 'hungry') {
    return `बॉस, आपकी बात समझ आ गई: "${message}"। लेकिन पहले एक कप चाय और समोसा हो जाए?`;
  }
  if (mode === 'nautanki') {
    return `अरे तौबा बॉस! आपने फरमाया और हम न मानें? "${message}" पर तो पूरी पिक्चर बनेगी!`;
  }
  if (mode === 'custom') {
    return `बॉस, आपका व्यक्तिगत निर्देश नोट कर लिया गया है: "${message}"। मैं आपकी पसंद के अनुसार काम कर रही हूँ।`;
  }
  return 'हाँजी बॉस! मैंने आपकी बात पूरी तरह समझ ली है। बताइए आगे क्या करना है?';
}

import { GoogleGenAI, ThinkingLevel, Modality } from '@google/genai';

function getGenAIClient(customApiKey?: string): GoogleGenAI {
  return new GoogleGenAI({
    apiKey: (customApiKey && customApiKey.trim()) || process.env.GEMINI_API_KEY,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// Chat endpoint with Gemini AI
app.post('/api/chat', async (req, res) => {
  try {
    const { message, personaMode, language = 'hi-IN', memories } = req.body;
    if (!message || typeof message !== 'string') {
      return res.status(400).json({ error: 'Message is required' });
    }

    const langConfig = getLanguageConfig(language);
    const selectedLanguageName = getSelectedLanguageLabel(langConfig.code);
    const speechLanguageCode = getLiveSpeechLanguageCode(langConfig.code);

    console.log(
      `[SERVER_CHAT] selectedLanguage="${selectedLanguageName}" settingsCode=${langConfig.code} speechLanguageCode=${speechLanguageCode} persona=${personaMode}`
    );

    if (!process.env.GEMINI_API_KEY) {
      return res.json({
        reply: getZoyaFallbackReply(message, personaMode, langConfig.code, memories),
        language: langConfig.code,
      });
    }

    const ai = getGenAIClient();
    let systemInstruction = getZoyaSystemInstruction(personaMode, langConfig.code);
    
    // Inject layered, mode-isolated persistent memory context (strict isolation)
    const memoryPromptContext = buildMemorySystemPrompt(personaMode, memories);
    if (memoryPromptContext) {
      systemInstruction += memoryPromptContext;
    }

    const promptWithLang = `${message}\n[हमेशा सिर्फ़ ${selectedLanguageName} में जवाब दो, चाहे यूज़र किसी भी भाषा में बोले। सेटिंग की भाषा में बोलो। (${langConfig.script} script)]`;

    // Prioritize canonical low-latency Gemini models with fallback
    const modelsToTry = [
      { name: 'gemini-3.1-flash-lite', thinkingLevel: ThinkingLevel.MINIMAL, isGemini4: false },
      { name: 'gemini-4-hydrogen', thinkingLevel: undefined, isGemini4: true },
    ];
    let reply: string | null = null;

    for (const modelCfg of modelsToTry) {
      try {
        const config: any = { systemInstruction };
        if (!modelCfg.isGemini4) {
          config.temperature = 0.7;
          if (modelCfg.thinkingLevel) {
            config.thinkingConfig = { thinkingLevel: modelCfg.thinkingLevel };
          }
        }
        const aiCall = ai.models.generateContent({
          model: modelCfg.name,
          contents: promptWithLang,
          config,
        });
        const timeoutPromise = new Promise<null>((resolve) => setTimeout(() => resolve(null), 6500));
        const response: any = await Promise.race([aiCall, timeoutPromise]);
        
        if (response && response.text) {
          const text = response.text.replace(/[*#_`]/g, '').trim();
          if (text) {
            reply = text;
            break;
          }
        }
      } catch (chatModelErr: any) {
        console.error(`[SERVER_CHAT] Model ${modelCfg.name} failed:`, chatModelErr?.status || '', chatModelErr?.message || chatModelErr);
      }
    }

    if (!reply) {
      reply = getZoyaFallbackReply(message, personaMode, langConfig.code, memories);
    }
    return res.json({ reply, language: langConfig.code });
  } catch (err: any) {
    console.error('[SERVER_CHAT] Unhandled /api/chat error:', err?.message || err);
    const langConfig = getLanguageConfig(req.body?.language);
    return res.json({
      reply: getZoyaFallbackReply(req.body?.message || 'Hello', req.body?.personaMode, langConfig.code, req.body?.memories),
      language: langConfig.code,
    });
  }
});

// Full 42-tool registry descriptors used in the real Zoya pipeline
const REAL_ZOYA_TOOL_DECLARATIONS: Array<{ name: string; category: string; description: string; schema: string }> = [
  { name: 'artifacts-builder', category: 'Group A Skill', description: 'Generates complete HTML/CSS/JS interactive frontend components and UI mockups.', schema: '{ prompt: string, framework: "html" | "react", responsive: boolean }' },
  { name: 'brand-guidelines', category: 'Group A Skill', description: 'Produces typography, color palette, and brand identity systems.', schema: '{ brandName: string, industry: string, tone: string }' },
  { name: 'canvas-design', category: 'Group A Skill', description: 'Creates SVG/Canvas visual layouts, posters, and infographic diagrams.', schema: '{ title: string, dimensions: string, elements: string[] }' },
  { name: 'changelog-generator', category: 'Group A Skill', description: 'Transforms commit history and PR logs into structured release notes.', schema: '{ version: string, commits: string[], audience: string }' },
  { name: 'competitive-ads-extractor', category: 'Group A Skill', description: 'Analyzes competitor ad copy, hooks, CTAs, and value propositions.', schema: '{ competitor: string, adCopy: string, channel: string }' },
  { name: 'connect-apps', category: 'Group A Skill', description: 'Generates webhook, REST API, and OAuth integration bridges.', schema: '{ sourceApp: string, targetApp: string, triggerEvent: string }' },
  { name: 'content-research-writer', category: 'Group A Skill', description: 'Produces researched articles with citations and structured outlines.', schema: '{ topic: string, depth: string, targetWordCount: number }' },
  { name: 'developer-growth-analysis', category: 'Group A Skill', description: 'Analyzes engineering productivity, code velocity, and learning roadmaps.', schema: '{ role: string, stack: string[], metrics: string }' },
  { name: 'document-skills/docx', category: 'Group A Skill', description: 'Generates structured Word/DOCX-ready professional documents and memos.', schema: '{ documentTitle: string, sections: string[], format: string }' },
  { name: 'domain-name-brainstormer', category: 'Group A Skill', description: 'Brainstorms brandable domain names across .com, .ai, .io, and .dev TLDs.', schema: '{ projectKeyword: string, tlds: string[], style: string }' },
  { name: 'file-organizer', category: 'Group A Skill', description: 'Creates directory categorization trees and shell/Python cleanup scripts.', schema: '{ directoryListing: string, rules: string }' },
  { name: 'image-enhancer', category: 'Group A Skill', description: 'Provides image sharpening, upscaling, and color grading pipelines.', schema: '{ imageSpecs: string, targetResolution: string }' },
  { name: 'internal-comms', category: 'Group A Skill', description: 'Drafts executive memos, incident updates, and all-hands announcements.', schema: '{ subject: string, audience: string, urgency: string }' },
  { name: 'invoice-organizer', category: 'Group A Skill', description: 'Extracts vendor, GST/tax, line items, and totals from raw invoice text.', schema: '{ rawInvoiceText: string, currency: string }' },
  { name: 'lead-research-assistant', category: 'Group A Skill', description: 'Builds B2B prospect profiles, ICP scores, and outreach sequences.', schema: '{ companyName: string, targetRole: string }' },
  { name: 'langsmith-fetch', category: 'Group A Skill', description: 'Queries LangSmith LLM traces, latency metrics, and token usage.', schema: '{ projectName: string, traceFilter: string }' },
  { name: 'mcp-builder', category: 'Group A Skill', description: 'Scaffolds Model Context Protocol (MCP) servers in TypeScript or Python.', schema: '{ serverName: string, tools: string[], transport: "stdio" | "sse" }' },
  { name: 'meeting-insights-analyzer', category: 'Group A Skill', description: 'Extracts decisions, action items, and speaker sentiment from transcripts.', schema: '{ transcript: string, participants: string[] }' },
  { name: 'raffle-winner-picker', category: 'Group A Skill', description: 'Selects cryptographically fair random winners from participant lists.', schema: '{ participants: string[], prizeCount: number, seed: string }' },
  { name: 'skill-creator', category: 'Group A Skill', description: 'Creates modular SKILL.md definitions and system prompts for new skills.', schema: '{ skillName: string, objective: string }' },
  { name: 'skill-share', category: 'Group A Skill', description: 'Exports and packages skill specifications into shareable JSON bundles.', schema: '{ skillId: string, includeExamples: boolean }' },
  { name: 'slack-gif-creator', category: 'Group A Skill', description: 'Generates animated SVG/Canvas celebration badges for Slack and Teams.', schema: '{ caption: string, theme: string }' },
  { name: 'tailored-resume-generator', category: 'Group A Skill', description: 'Tailors ATS-optimized resumes against specific job descriptions.', schema: '{ candidateExperience: string, jobDescription: string }' },
  { name: 'theme-factory', category: 'Group A Skill', description: 'Generates Tailwind CSS and CSS-variable design token themes.', schema: '{ baseColor: string, contrastMode: "dark" | "light" }' },
  { name: 'video-downloader', category: 'Group A Skill', description: 'Extracts media stream metadata and generates yt-dlp/ffmpeg commands.', schema: '{ mediaUrl: string, formatPreference: string }' },
  { name: 'text-chat-engine', category: 'Group B Core', description: 'Multi-modal text and Hinglish conversational chat engine.', schema: '{ message: string, personaMode: string, language: string }' },
  { name: 'voice-call-engine', category: 'Group B Core', description: 'Real-time voice conversation and duplex speech pipeline.', schema: '{ utterance: string, voiceStyle: string }' },
  { name: 'website-builder', category: 'Group B Core', description: 'Full-stack responsive HTML5/Tailwind/JS single-file website builder.', schema: '{ prompt: string, includeDarkTheme: boolean }' },
  { name: 'web-search', category: 'Group B Core', description: 'Live web search with DuckDuckGo and Wikipedia source citations.', schema: '{ query: string, maxResults: number }' },
  { name: 'media-hub-youtube', category: 'Group B Core', description: 'Searches and plays YouTube videos and music streams.', schema: '{ searchQuery: string, autoPlay: boolean }' },
  { name: 'python-studio', category: 'Group B Core', description: 'Executes Python 3 scripts, creates source bundles, and triggers GitHub APK builds.', schema: '{ code: string, mode: "run" | "bundle" | "github_apk" }' },
  { name: 'memory-palace', category: 'Group B Core', description: 'Two-tier persistent SQLite/JSON memory store across persona modes.', schema: '{ key: string, content: string, tier: "mode" | "main" }' },
  { name: 'openclaw-agent', category: 'Group B Core', description: 'Autonomous multi-step planner and device automation coordinator.', schema: '{ goal: string, maxSteps: number }' },
  { name: 'device-open-app', category: 'Group C Native', description: 'Opens installed Android apps via AccessibilityService and PackageManager.', schema: '{ appNameOrPackage: string }' },
  { name: 'device-tap-click', category: 'Group C Native', description: 'Taps screen coordinates or clicks UI nodes by visible label.', schema: '{ text?: string, x?: number, y?: number }' },
  { name: 'device-scroll-swipe', category: 'Group C Native', description: 'Scrolls scrollable views or performs directional swipe gestures.', schema: '{ direction: "up" | "down" | "left" | "right" }' },
  { name: 'device-type-text', category: 'Group C Native', description: 'Types text into focused EditText nodes via ACTION_SET_TEXT.', schema: '{ text: string, targetHint?: string }' },
  { name: 'device-read-screen', category: 'Group C Native', description: 'Reads active window AccessibilityNodeInfo hierarchy.', schema: '{ includeCoordinates: boolean }' },
  { name: 'device-global-nav', category: 'Group C Native', description: 'Executes Android global actions (HOME, BACK, RECENTS, NOTIFICATIONS).', schema: '{ command: "HOME" | "BACK" | "RECENTS" | "NOTIFICATIONS" }' },
  { name: 'device-lock-screen', category: 'Group C Native', description: 'Locks device screen via GLOBAL_ACTION_LOCK_SCREEN (API 28+).', schema: '{ confirm: boolean }' },
  { name: 'device-unlock-screen', category: 'Group C Native', description: 'Requests system biometric/PIN Keyguard dismissal via KeyguardManager.', schema: '{ reason: string }' },
  { name: 'device-banking-shield', category: 'Group C Native', description: 'Intercepts and blocks automation on banking, UPI, and wallet apps.', schema: '{ packageName: string }' },
];

// Low-latency streaming chat endpoint for instant voice response (supports both /api/chat-stream and /api/chat/stream)
app.post(['/api/chat-stream', '/api/chat/stream'], async (req, res) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache, no-transform');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('X-Accel-Buffering', 'no');

  const {
    message,
    personaMode,
    language = 'hi-IN',
    memories,
    geminiApiKey,
    relevantToolNames,
    chatHistory,
    pipelineMode = 'optimized_selective',
  } = req.body || {};

  const langConfig = getLanguageConfig(language);
  const startTime = Date.now();
  const isBaselineAllTools = pipelineMode === 'baseline_all_tools';

  console.log(
    `[SERVER_STREAM] [START] time=${new Date().toISOString()} mode=${pipelineMode} query="${message}" lang=${langConfig.code} persona=${personaMode}`
  );

  if (!message || typeof message !== 'string') {
    const defaultGreeting = getZoyaFallbackReply('Hello', personaMode, langConfig.code);
    res.write(`data: ${JSON.stringify({ text: defaultGreeting })}\n\n`);
    res.write('data: [DONE]\n\n');
    return res.end();
  }

  let systemInstruction = getZoyaSystemInstruction(personaMode, langConfig.code);
  const memoryPromptContext = buildMemorySystemPrompt(personaMode, memories);
  if (memoryPromptContext) {
    systemInstruction += memoryPromptContext;
  }

  // Detect whether the request asks for long code/website/document output
  const lowerMsg = message.toLowerCase();
  const requestsLongArtifact =
    /\b(code|python|html|css|website|landing page|script|function|document|memo|report|table|json)\b/i.test(lowerMsg);

  // If the user requests a complete code/website/document artifact, lift the 2-3 sentence cap for the artifact body
  // in BOTH baseline and optimized modes so both modes produce the exact same complete artifact.
  if (requestsLongArtifact) {
    systemInstruction = systemInstruction.replace(
      '- LENGTH & FLOW: Keep spoken replies short, natural, and friendly (strictly 2 to 3 sentences maximum) unless the user explicitly requests more detail.',
      '- LENGTH & FLOW: Start with ONE concise spoken summary sentence (15-25 words), followed immediately by the complete, untruncated requested code/HTML/markdown inside a fenced block.'
    );
  }

  // Tool schema injection:
  // - In baseline_all_tools mode: injects ALL 42 tool schemas into the system context (unoptimized pipeline).
  // - In optimized_selective mode: injects ONLY the relevant tool schemas selected for this request.
  const normalizeToolId = (id: string) =>
    id
      .replace(/-modal$/, '')
      .replace(/^app-launcher$/, 'device-open-app')
      .replace(/^youtube-results$/, 'media-hub-youtube')
      .replace(/^full-voice-call$/, 'voice-call-engine')
      .replace(/^text-chat$/, 'text-chat-engine');

  const normalizedRequested = Array.isArray(relevantToolNames)
    ? relevantToolNames.map(normalizeToolId)
    : [];

  const activeTools = isBaselineAllTools
    ? REAL_ZOYA_TOOL_DECLARATIONS
    : normalizedRequested.length > 0
    ? REAL_ZOYA_TOOL_DECLARATIONS.filter(
        (t) => normalizedRequested.includes(t.name) || relevantToolNames.includes(t.name)
      )
    : REAL_ZOYA_TOOL_DECLARATIONS.filter((t) => t.name === 'text-chat-engine');

  const finalActiveTools =
    activeTools.length > 0
      ? activeTools
      : REAL_ZOYA_TOOL_DECLARATIONS.filter((t) => t.name === 'text-chat-engine');

  const toolSchemasBlock =
    `\n\nAVAILABLE ZOYA TOOL SCHEMAS (${finalActiveTools.length} registered):\n` +
    finalActiveTools
      .map((t) => `- ${t.name} [${t.category}]: ${t.description} | Schema: ${t.schema}`)
      .join('\n');
  systemInstruction += toolSchemasBlock;

  if (!isBaselineAllTools) {
    if (requestsLongArtifact) {
      systemInstruction += `\n\nVOICE + CARD OUTPUT FORMAT:
- Begin your response with ONE short spoken sentence (15 to 25 words, plain conversational text, ending with a period or पूर्णविराम) summarizing what you built for the user.
- Immediately after that first spoken sentence, provide the FULL, complete requested code, HTML, or document inside a fenced block (\`\`\`html, \`\`\`python, or \`\`\`markdown). Do NOT truncate or shorten the requested artifact—the full artifact is displayed on the user's Visual Output Card while only the first sentence is spoken aloud.`;
    } else {
      systemInstruction += `\n\nVOICE ASSISTANT SPEED RULE:
- Start immediately with a clear, natural first sentence so speech synthesis can begin right away.
- Keep your spoken response concise (1 to 2 sentences) while directly and completely answering the user's request.`;
    }
  } else if (requestsLongArtifact) {
    systemInstruction += `\n\nOUTPUT FORMAT:
- Begin your response with ONE short intro sentence (15 to 25 words), followed immediately by the FULL, complete requested code, HTML, or document inside a fenced block (\`\`\`html, \`\`\`python, or \`\`\`markdown).`;
  }

  // Include recent chat history if provided
  const historyLines = Array.isArray(chatHistory) && chatHistory.length > 0
    ? chatHistory
        .slice(-6)
        .map((h: any) => `${h.sender === 'user' ? 'User' : 'Zoya'}: ${h.text}`)
        .join('\n') + '\n'
    : '';

  const selectedLanguageName = getSelectedLanguageLabel(langConfig.code);
  const speechLanguageCode = getLiveSpeechLanguageCode(langConfig.code);
  console.log(
    `[SERVER_STREAM_LANG] selectedLanguage="${selectedLanguageName}" settingsCode=${langConfig.code} speechLanguageCode=${speechLanguageCode}`
  );

  const promptWithLang = `${historyLines}User: ${message}\n[हमेशा सिर्फ़ ${selectedLanguageName} में जवाब दो, चाहे यूज़र किसी भी भाषा में बोले। सेटिंग की भाषा में बोलो। (${langConfig.script} script)]`;

  const effectiveApiKey = (geminiApiKey && geminiApiKey.trim()) || process.env.GEMINI_API_KEY;

  const streamErrors: Array<{ stage: string; model: string; status?: number | string; error: string }> = [];

  if (effectiveApiKey) {
    const streamModelsToTry = [
      { name: 'gemini-3.1-flash-lite', thinkingLevel: ThinkingLevel.MINIMAL, isGemini4: false },
      { name: 'gemini-4-hydrogen', thinkingLevel: undefined, isGemini4: true },
    ];

    let clientDisconnected = false;
    res.on('close', () => {
      if (!res.writableEnded) {
        clientDisconnected = true;
      }
    });
    req.on('aborted', () => {
      clientDisconnected = true;
    });

    const ai = getGenAIClient(geminiApiKey);
    for (const modelCfg of streamModelsToTry) {
      if (clientDisconnected || res.writableEnded) break;
      try {
        console.log(
          `[SERVER_STREAM] Attempting model ${modelCfg.name} (tools=${finalActiveTools.length}, promptChars=${systemInstruction.length + promptWithLang.length})...`
        );
        const config: any = { systemInstruction };
        if (!modelCfg.isGemini4) {
          config.temperature = 0.7;
          if (modelCfg.thinkingLevel) {
            config.thinkingConfig = { thinkingLevel: modelCfg.thinkingLevel };
          }
        }
        const streamCall = ai.models.generateContentStream({
          model: modelCfg.name,
          contents: promptWithLang,
          config,
        });

        let openTimeoutId: ReturnType<typeof setTimeout> | null = null;
        const timeoutPromise = new Promise<null>((resolve) => {
          openTimeoutId = setTimeout(() => resolve(null), 10000);
        });
        const stream: any = await Promise.race([streamCall, timeoutPromise]);
        if (openTimeoutId) clearTimeout(openTimeoutId);
        if (!stream) {
          console.warn(`[SERVER_STREAM] Model ${modelCfg.name} open timed out after 10s`);
          streamErrors.push({ stage: 'stream_open', model: modelCfg.name, error: 'open timed out after 10s' });
          continue;
        }

        let streamedAny = false;
        let totalChars = 0;
        let firstChunkLogged = false;
        let firstTokenMs = 0;
        const CHUNK_INACTIVITY_MS = 9000;
        const iterator = stream[Symbol.asyncIterator]();

        while (!clientDisconnected && !res.writableEnded) {
          let chunkTimeoutId: ReturnType<typeof setTimeout> | null = null;
          const chunkStallPromise = new Promise<{ stalled: true }>((resolve) => {
            chunkTimeoutId = setTimeout(() => resolve({ stalled: true }), CHUNK_INACTIVITY_MS);
          });
          const step: any = await Promise.race([
            iterator.next().then((r: IteratorResult<any>) => ({ stalled: false, r })),
            chunkStallPromise,
          ]);
          if (chunkTimeoutId) clearTimeout(chunkTimeoutId);

          if (step.stalled) {
            console.warn(`[SERVER_STREAM] [CHUNK_STALL] Model ${modelCfg.name} stalled for ${CHUNK_INACTIVITY_MS}ms mid-stream (streamedAny=${streamedAny})`);
            streamErrors.push({ stage: 'stream_chunk', model: modelCfg.name, error: `stalled after ${CHUNK_INACTIVITY_MS}ms` });
            if (typeof iterator.return === 'function') {
              Promise.resolve(iterator.return()).catch(() => {});
            }
            break;
          }

          if (step.r?.done) break;
          const chunk = step.r?.value;
          const rawText = chunk?.text || '';
          // Preserve fenced code blocks for Visual Output Cards while cleaning stray bold/italic markers outside code
          const text = requestsLongArtifact ? rawText : rawText.replace(/[*#_`]/g, '');
          if (text) {
            if (!firstChunkLogged) {
              firstChunkLogged = true;
              firstTokenMs = Date.now() - startTime;
              console.log(`[SERVER_STREAM] [FIRST_CHUNK] at +${firstTokenMs}ms: "${text.slice(0, 60).replace(/\n/g, ' ')}"`);
            }
            streamedAny = true;
            totalChars += text.length;
            res.write(
              `data: ${JSON.stringify({
                text,
                meta: {
                  model: modelCfg.name,
                  activeToolsCount: finalActiveTools.length,
                  systemPromptChars: systemInstruction.length,
                },
              })}\n\n`
            );
          }
        }
        if (streamedAny) {
          const totalMs = Date.now() - startTime;
          console.log(
            `[SERVER_STREAM] [SUCCESS] ${modelCfg.name} (mode=${pipelineMode}, tools=${finalActiveTools.length}) firstToken=${firstTokenMs}ms total=${totalMs}ms chars=${totalChars}`
          );
          if (!res.writableEnded) {
            res.write('data: [DONE]\n\n');
            return res.end();
          }
          return;
        }
        streamErrors.push({ stage: 'stream_empty', model: modelCfg.name, error: 'stream ended with 0 characters' });
      } catch (streamErr: any) {
        const streamErrMsg = streamErr?.message || String(streamErr);
        streamErrors.push({
          stage: 'stream',
          model: modelCfg.name,
          status: streamErr?.status || streamErr?.code,
          error: streamErrMsg,
        });
        console.error(
          `[SERVER_STREAM] Model ${modelCfg.name} generateContentStream failed:`,
          {
            status: streamErr?.status || streamErr?.code,
            message: streamErrMsg,
            details: streamErr?.errorDetails || streamErr?.response?.data || undefined,
            stack: streamErr?.stack?.split('\n').slice(0, 4).join(' | '),
          }
        );
      }
    }

    // Fallback to non-streaming /api/chat generateContent logic BEFORE static getZoyaFallbackReply()
    if (!clientDisconnected && !res.writableEnded) {
      for (const modelCfg of streamModelsToTry) {
        if (clientDisconnected || res.writableEnded) break;
        try {
          console.log(`[SERVER_STREAM] Streaming failed; attempting non-streaming /api/chat fallback with ${modelCfg.name}...`);
          const fallbackConfig: any = { systemInstruction };
          if (!modelCfg.isGemini4) {
            fallbackConfig.temperature = 0.7;
            if (modelCfg.thinkingLevel) {
              fallbackConfig.thinkingConfig = { thinkingLevel: modelCfg.thinkingLevel };
            }
          }
          const aiCall = ai.models.generateContent({
            model: modelCfg.name,
            contents: promptWithLang,
            config: fallbackConfig,
          });
          const timeoutPromise = new Promise<null>((resolve) => setTimeout(() => resolve(null), 8500));
          const nonStreamResp: any = await Promise.race([aiCall, timeoutPromise]);
          const rawReply = nonStreamResp?.text || '';
          const cleanReply = (requestsLongArtifact ? rawReply : rawReply.replace(/[*#_`]/g, '')).trim();
          if (cleanReply) {
            console.log(`[SERVER_STREAM] [NON_STREAM_FALLBACK_SUCCESS] ${modelCfg.name} chars=${cleanReply.length}`);
            res.write(
              `data: ${JSON.stringify({
                text: cleanReply,
                meta: {
                  model: `${modelCfg.name}-nonstream-fallback`,
                  activeToolsCount: finalActiveTools.length,
                  systemPromptChars: systemInstruction.length,
                },
              })}\n\n`
            );
            res.write('data: [DONE]\n\n');
            return res.end();
          }
          streamErrors.push({ stage: 'non_stream_empty', model: modelCfg.name, error: nonStreamResp ? 'empty text' : 'timed out after 8.5s' });
        } catch (nonStreamErr: any) {
          streamErrors.push({
            stage: 'non_stream',
            model: modelCfg.name,
            status: nonStreamErr?.status || nonStreamErr?.code,
            error: nonStreamErr?.message || String(nonStreamErr),
          });
          console.error(
            `[SERVER_STREAM] Non-streaming fallback ${modelCfg.name} failed:`,
            nonStreamErr?.status || '',
            nonStreamErr?.message || nonStreamErr
          );
        }
      }
    }
  } else {
    streamErrors.push({ stage: 'config', model: 'none', error: 'GEMINI_API_KEY missing' });
  }

  // Final static fallback only if both streaming AND non-streaming Gemini calls fail
  if (res.writableEnded) return;
  const fallbackReply = getZoyaFallbackReply(message, personaMode, langConfig.code, memories);
  console.log(`[SERVER_STREAM] [FALLBACK] at +${Date.now() - startTime}ms reply="${fallbackReply}" errors=${JSON.stringify(streamErrors)}`);

  // Stream fallback in 2 quick phrase chunks
  const parts = fallbackReply.split(' ');
  const mid = Math.ceil(parts.length / 2);
  const part1 = parts.slice(0, mid).join(' ') + ' ';
  const part2 = parts.slice(mid).join(' ');

  res.write(`data: ${JSON.stringify({ text: part1, meta: { fallback: true, errors: streamErrors } })}\n\n`);
  setTimeout(() => {
    if (!res.writableEnded) {
      res.write(`data: ${JSON.stringify({ text: part2, meta: { fallback: true } })}\n\n`);
      res.write('data: [DONE]\n\n');
      res.end();
    }
  }, 40);
});

// Universal Full HD Avatar Matte & Edge Decontamination Upload Endpoint
app.post('/api/avatar/process-upload', async (req, res) => {
  try {
    const { image, name = 'Custom Avatar' } = req.body;
    if (!image) {
      return res.status(400).json({ error: 'Image data is required' });
    }
    const cleanBase64 = image.includes(',') ? image.split(',')[1] : image;
    const imgBuffer = Buffer.from(cleanBase64, 'base64');
    const avatarId = `custom_${Date.now()}`;

    const outDir = path.join(process.cwd(), 'public/assets/images/avatars_3d/transparent');
    const fullDir = path.join(process.cwd(), 'public/assets/images/avatars_3d');
    if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive: true });

    const outPngPath = path.join(outDir, `avatar_${avatarId}.png`);
    const fullJpgPath = path.join(fullDir, `avatar_${avatarId}.jpg`);
    const tempSrcPath = path.join(fullDir, `temp_${avatarId}.png`);

    // Write temp source
    fs.writeFileSync(tempSrcPath, imgBuffer);

    // Save pristine full JPG
    const sharp = (await import('sharp')).default;
    await sharp(imgBuffer).jpeg({ quality: 95 }).toFile(fullJpgPath);

    // Process universal matte & edge decontamination
    const { createRequire } = await import('module');
    const reqModule = createRequire(import.meta.url);
    const { processAvatarFlawless } = reqModule('./scripts/universal_avatar_processor.cjs');
    const info = await processAvatarFlawless(tempSrcPath, outPngPath);

    // Clean temp source
    try { fs.unlinkSync(tempSrcPath); } catch {}

    const newAvatar = {
      id: avatarId,
      name: name || 'Custom 3D Avatar',
      japaneseName: 'カスタム アバター',
      tag: 'Custom Full HD',
      outfit: 'Custom Outfit',
      description: 'अपलोड किया गया फुल HD 3D अवतार • ओरिजिनल आउटफिट व क्रिस्टल क्लियर एज स्पष्टता',
      fullImage: `/assets/images/avatars_3d/avatar_${avatarId}.jpg`,
      thumbnail: `/assets/images/avatars_3d/avatar_${avatarId}.jpg`,
      transparentPng: `/assets/images/avatars_3d/transparent/avatar_${avatarId}.png`,
      styleInspiration: 'Custom Uploaded Full HD Avatar',
      isCustom: true,
    };

    res.json({ success: true, avatar: newAvatar, width: info.width, height: info.height });
  } catch (err: any) {
    console.error('[SERVER] Avatar process upload error:', err);
    res.status(500).json({ error: err?.message || 'Failed to process avatar' });
  }
});

// Photo to 3D Colored Pencil Sketch endpoint with Gemini AI
app.post('/api/photo-to-3d-sketch', async (req, res) => {
  try {
    const { image, mimeType = 'image/jpeg', mode = 'color' } = req.body;
    if (!image) {
      return res.status(400).json({ error: 'Image data is required' });
    }

    if (!process.env.GEMINI_API_KEY) {
      return res.status(503).json({ error: 'GEMINI_API_KEY is not set on server' });
    }

    const ai = getGenAIClient();
    const cleanBase64 = image.includes(',') ? image.split(',')[1] : image;

    const promptText =
      mode === 'graphite'
        ? 'Transform this exact photo into a realistic, detailed hand-drawn black-and-white graphite pencil drawing. Reproduce all visible subjects, faces, objects, clothing, and background details with fine graphite pencil strokes, cross-hatching, and natural chiaroscuro shading on archival drawing paper. Preserve the subject\'s exact identity and facial features with zero distortion.'
        : 'Transform this exact photo into a realistic, dimensional 3D colored pencil drawing. Preserve the original subject, face, identity, clothing, and composition exactly. Render clearly visible fine pencil outlines, hand-drawn colored pencil strokes, natural rich colors, and realistic 3D depth with dimensional shading, highlights, and shadows on archival drawing paper. Hand-drawn colored pencil masterpiece.';

    const response = await ai.models.generateContent({
      model: 'gemini-3.1-flash-lite-image',
      contents: {
        parts: [
          {
            inlineData: {
              data: cleanBase64,
              mimeType: mimeType.split(';')[0],
            },
          },
          {
            text: promptText,
          },
        ],
      },
    });

    for (const part of response.candidates?.[0]?.content?.parts ?? []) {
      if (part.inlineData?.data) {
        const mime = part.inlineData.mimeType || 'image/png';
        return res.json({
          sketchUrl: `data:${mime};base64,${part.inlineData.data}`,
        });
      }
    }

    return res.status(500).json({ error: 'No image generated in response' });
  } catch (err: any) {
    console.error('[API] /api/photo-to-3d-sketch error:', err);
    return res.status(500).json({ error: err.message || 'Generation failed' });
  }
});

// Audio transcription endpoint with Gemini for MediaRecorder raw audio capture (bypasses Chrome iframe Web Speech restriction)
app.post('/api/transcribe', async (req, res) => {
  try {
    const { audioData, mimeType, language = 'hi-IN', geminiApiKey } = req.body;
    if (!audioData) {
      return res.status(400).json({ error: 'Audio data is required' });
    }

    const langConfig = getLanguageConfig(language);
    let transcript: string = '';
    let isQuotaExhausted = false;

    // Normalize MIME type (strip codec suffix like ";codecs=opus" which can cause API rejection)
    const cleanMimeType = (mimeType || 'audio/webm').split(';')[0].trim() || 'audio/webm';
    const effectiveKey = (geminiApiKey && typeof geminiApiKey === 'string' && geminiApiKey.trim()) || process.env.GEMINI_API_KEY;

    if (effectiveKey) {
      const ai = getGenAIClient(effectiveKey);
      const audioPart = {
        inlineData: {
          mimeType: cleanMimeType,
          data: audioData,
        },
      };
      const promptPart = {
        text: `Transcribe ONLY actual human spoken words in this audio. The user's selected language is ${langConfig.name} (${langConfig.nativeName}, ${langConfig.code}). If spoken in ${langConfig.name}, write accurately in ${langConfig.script} script. If spoken in Hindi, Hinglish, or English, transcribe accurately — especially wake phrases like "Hello Zoya", "Hello Hello", "Hey Zoya", or "Zoya" (preserve those English words accurately if spoken in English even when selected language is Hindi). If there is only silence, electronic tone, breathing, or background noise with NO spoken words, reply with exactly SILENCE. Output ONLY the transcribed words with no explanations, no formatting, no markdown, and no quotation marks.`,
      };

      // Try fastest multimodal model first with a 6s per-model timeout so STT never stalls >30s
      const modelsToTry = ['gemini-3.1-flash-lite', 'gemini-4-hydrogen', 'gemini-3.5-transcribe'];
      const PER_MODEL_STT_TIMEOUT_MS = 6000;
      let lastTranscribeError: string | null = null;
      let usedModel: string | null = null;
      let sawEmptySilence = false;

      for (const model of modelsToTry) {
        let modelTimeoutId: ReturnType<typeof setTimeout> | null = null;
        try {
          const genPromise = ai.models.generateContent({
            model,
            contents: { parts: [audioPart, promptPart] },
          });
          const timeoutPromise = new Promise<'TIMEOUT'>((resolve) => {
            modelTimeoutId = setTimeout(() => resolve('TIMEOUT'), PER_MODEL_STT_TIMEOUT_MS);
          });
          const response: any = await Promise.race([genPromise, timeoutPromise]);
          if (modelTimeoutId) {
            clearTimeout(modelTimeoutId);
            modelTimeoutId = null;
          }

          if (response === 'TIMEOUT') {
            lastTranscribeError = `Model ${model} timed out after ${PER_MODEL_STT_TIMEOUT_MS}ms`;
            console.warn(`[API_TRANSCRIBE] ${lastTranscribeError}`);
            continue;
          }

          const rawText = (response?.text || '').replace(/[*#_`"\n]/g, '').trim();
          if (!rawText || /^\[?silence\]?\.?$/i.test(rawText) || rawText.toUpperCase() === 'SILENCE') {
            sawEmptySilence = true;
            usedModel = model;
            console.log(`[API_TRANSCRIBE] Model ${model} returned SILENCE (${langConfig.code})`);
            break;
          }
          transcript = rawText;
          usedModel = model;
          console.log(`[API_TRANSCRIBE] Successfully transcribed via ${model} (${langConfig.code}): "${transcript}"`);
          break;
        } catch (mErr: any) {
          if (modelTimeoutId) {
            clearTimeout(modelTimeoutId);
            modelTimeoutId = null;
          }
          const errMsg = mErr?.message || String(mErr);
          lastTranscribeError = errMsg;
          const errStatus = mErr?.status || mErr?.code;
          if (errStatus === 429 || errMsg.includes('RESOURCE_EXHAUSTED') || errMsg.includes('quota') || errMsg.includes('Quota exceeded')) {
            isQuotaExhausted = true;
            console.error(`[API_TRANSCRIBE] Model ${model} hit rate limit (429 RESOURCE_EXHAUSTED):`, errMsg);
          } else {
            console.error(`[API_TRANSCRIBE] Model ${model} failed:`, errMsg);
          }
        }
      }

      return res.json({
        transcript,
        source: transcript ? 'gemini' : sawEmptySilence ? 'silence' : lastTranscribeError ? 'error' : 'none',
        modelUsed: usedModel || undefined,
        error: !transcript && !sawEmptySilence && lastTranscribeError ? lastTranscribeError : undefined,
        quotaExceeded: isQuotaExhausted,
        language: langConfig.code,
      });
    }

    console.error('[API_TRANSCRIBE] GEMINI_API_KEY is missing on server; cannot transcribe audio.');
    return res.json({
      transcript: '',
      source: 'error',
      error: 'GEMINI_API_KEY is not configured on server',
      quotaExceeded: false,
      language: langConfig.code,
    });
  } catch (err: any) {
    console.error('[API_TRANSCRIBE] Unhandled error:', err?.message || err);
    return res.json({ transcript: '', source: 'error', error: err?.message || 'Transcription error', quotaExceeded: false });
  }
});

// Proxy endpoint for Free Slack Incoming Webhooks (used by skill-share tool)
// Ensures webhook calls bypass browser CORS limitations and never leak secrets to 3P.
app.post('/api/tools/slack-broadcast', async (req, res) => {
  try {
    const { webhookUrl, payload } = req.body || {};
    if (!webhookUrl || typeof webhookUrl !== 'string' || !webhookUrl.startsWith('https://hooks.slack.com/')) {
      return res.status(400).json({ 
        success: false, 
        error: 'Invalid Slack Webhook URL. It must start with https://hooks.slack.com/' 
      });
    }

    const slackPayload = payload || {
      text: 'Notification from Zoya Assistant',
      blocks: [
        {
          type: 'section',
          text: {
            type: 'mrkdwn',
            text: '*Zoya Assistant*: Test notification from skill-share integration.',
          },
        },
      ],
    };

    const slackRes = await fetch(webhookUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(slackPayload),
    });

    if (slackRes.ok) {
      return res.json({ 
        success: true, 
        message: 'Successfully broadcast message to Slack channel via Webhook!' 
      });
    } else {
      const errText = await slackRes.text();
      return res.status(slackRes.status).json({ 
        success: false, 
        error: `Slack Webhook returned error (${slackRes.status}): ${errText || 'Invalid webhook or expired channel'}` 
      });
    }
  } catch (err: any) {
    return res.status(500).json({ 
      success: false, 
      error: `Network error connecting to Slack: ${err?.message || 'Connection failed'}` 
    });
  }
});

// =========================================================================
// ZOYA ULTRA-ADVANCED HUMAN-LIKE MEMORY SYSTEM REST ENDPOINTS
// Permanent disk storage with strict mode-isolation & 3D Running Memory Pipeline
// =========================================================================

// GET /api/memories/pipeline - Comprehensive live stats for 3D running memory pipeline
app.get('/api/memories/pipeline', (_req, res) => {
  try {
    const stats = getPipelineFullStats();
    return res.json({
      success: true,
      ...stats,
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: 'Failed to retrieve pipeline stats', details: err?.message });
  }
});

// GET /api/memories/main - Retrieve central main memories (likes, dislikes, choices)
app.get('/api/memories/main', (_req, res) => {
  try {
    const memories = getMainMemories();
    return res.json({
      success: true,
      count: memories.length,
      memories,
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: 'Failed to retrieve main memories', details: err?.message });
  }
});

// POST /api/memories/main - Save/Upsert central main memory item
app.post('/api/memories/main', (req, res) => {
  try {
    const { title, content, importance = 4, layer = 'preference', id, pinned = true } = req.body || {};
    if (!title || !content) {
      return res.status(400).json({ success: false, error: 'Both title and content are required' });
    }
    const saved = saveMainMemoryItem({ id, title, content, importance: Number(importance) || 4, layer, pinned: Boolean(pinned) });
    return res.status(201).json({ success: true, memory: saved });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: 'Failed to save main memory', details: err?.message });
  }
});

// DELETE /api/memories/main/:id - Delete central main memory item
app.delete('/api/memories/main/:id', (req, res) => {
  try {
    const deleted = deleteMainMemoryItem(req.params.id);
    return res.json({ success: deleted, message: deleted ? 'Main memory removed' : 'Not found' });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: 'Failed to delete main memory', details: err?.message });
  }
});

// GET /api/memories/personal - Retrieve final personal memories (5 categories)
app.get('/api/memories/personal', (req, res) => {
  try {
    const category = typeof req.query.category === 'string' ? (req.query.category as any) : undefined;
    const memories = getPersonalMemories(category);
    return res.json({
      success: true,
      count: memories.length,
      memories,
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: 'Failed to retrieve personal memories', details: err?.message });
  }
});

// POST /api/memories/personal - Save/Upsert final personal memory item
app.post('/api/memories/personal', (req, res) => {
  try {
    const { category = 'preferences', title, content, importance = 4, id } = req.body || {};
    if (!title || !content) {
      return res.status(400).json({ success: false, error: 'Both title and content are required' });
    }
    const saved = savePersonalMemoryItem({ id, category, title, content, importance: Number(importance) || 4 });
    return res.status(201).json({ success: true, memory: saved });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: 'Failed to save personal memory', details: err?.message });
  }
});

// DELETE /api/memories/personal/:id - Delete personal memory item
app.delete('/api/memories/personal/:id', (req, res) => {
  try {
    const deleted = deletePersonalMemoryItem(req.params.id);
    return res.json({ success: deleted, message: deleted ? 'Personal memory removed' : 'Not found' });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: 'Failed to delete personal memory', details: err?.message });
  }
});

// POST /api/memories/transfer - Real pipeline transfer from mode memory to Main & Personal Memory
app.post('/api/memories/transfer', (req, res) => {
  try {
    const { sourceMode = 'girlfriend', memoryId, targetCategory = 'preferences', title, content, importance = 4 } = req.body || {};
    if (!title || !content) {
      return res.status(400).json({ success: false, error: 'Title and content are required for pipeline transfer' });
    }
    const result = transferMemoryToPipeline({
      sourceMode,
      memoryId,
      targetCategory,
      title,
      content,
      importance: Number(importance) || 4,
    });
    return res.json({
      message: `Transferred memory from ${sourceMode} to Main Memory & Personal Memory (${targetCategory})`,
      ...result,
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: 'Failed to transfer memory through pipeline', details: err?.message });
  }
});

// POST /api/memories/retrieve - Two-tier hierarchical memory lookup (Active Mode first -> Central Main Memory -> Final Personal Memory)
app.post('/api/memories/retrieve', (req, res) => {
  try {
    const { mode = 'girlfriend', query = '' } = req.body || {};
    if (!query || typeof query !== 'string') {
      return res.status(400).json({ success: false, error: 'Query is required for memory retrieval' });
    }
    const result = retrieveMemoryHierarchicalServer(mode, query);
    return res.json({
      success: true,
      mode: mode.toLowerCase(),
      ...result,
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: 'Failed to retrieve hierarchical memory', details: err?.message });
  }
});

// GET /api/memories?mode=<mode>
app.get('/api/memories', (req, res) => {
  try {
    const { mode } = req.query;
    if (mode && typeof mode === 'string') {
      const memories = getMemoriesForMode(mode);
      return res.json({
        success: true,
        mode: mode.toLowerCase(),
        count: memories.length,
        memories,
      });
    } else {
      const allMemories = getAllMemoriesGrouped();
      return res.json({
        success: true,
        allMemories,
      });
    }
  } catch (err: any) {
    return res.status(500).json({ success: false, error: 'Failed to retrieve memories', details: err?.message });
  }
});

// POST /api/memories - Upsert/Save memory item
app.post('/api/memories', (req, res) => {
  try {
    const { mode = 'girlfriend', layer = 'long_term', title, content, importance = 3, pinned = false, source = 'user_manual', id } = req.body || {};
    if (!title || !content) {
      return res.status(400).json({ success: false, error: 'Both title and content are required' });
    }

    const saved = saveMemoryItem({
      id,
      mode,
      layer,
      title,
      content,
      importance: Number(importance) || 3,
      pinned: Boolean(pinned),
      source,
    });

    return res.status(201).json({
      success: true,
      message: 'Memory saved successfully to persistent storage',
      memory: saved,
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: 'Failed to save memory', details: err?.message });
  }
});

// PUT /api/memories/:id - Update memory item
app.put('/api/memories/:id', (req, res) => {
  try {
    const { id } = req.params;
    const { mode = 'girlfriend', layer, title, content, importance, pinned, source } = req.body || {};
    if (!title || !content) {
      return res.status(400).json({ success: false, error: 'Title and content are required for update' });
    }

    const updated = saveMemoryItem({
      id,
      mode,
      layer,
      title,
      content,
      importance,
      pinned,
      source,
    });

    return res.json({
      success: true,
      message: 'Memory updated successfully',
      memory: updated,
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: 'Failed to update memory', details: err?.message });
  }
});

// DELETE /api/memories/:id?mode=<mode> - Delete single memory
app.delete('/api/memories/:id', (req, res) => {
  try {
    const { id } = req.params;
    const mode = typeof req.query.mode === 'string' ? req.query.mode : undefined;
    const deleted = deleteMemoryItem(id, mode);
    return res.json({
      success: deleted,
      message: deleted ? 'Memory removed from persistent store' : 'Memory not found',
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: 'Failed to delete memory', details: err?.message });
  }
});

// DELETE /api/memories?mode=<mode> - Clear mode memories
app.delete('/api/memories', (req, res) => {
  try {
    const mode = typeof req.query.mode === 'string' ? req.query.mode : 'girlfriend';
    clearModeMemories(mode);
    return res.json({
      success: true,
      message: `All persistent memories for mode '${mode}' have been cleared.`,
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: 'Failed to clear mode memories', details: err?.message });
  }
});

// POST /api/memories/extract - Auto extract and save memories from dialogue
app.post('/api/memories/extract', async (req, res) => {
  try {
    const { userQuery, assistantReply, personaMode = 'girlfriend', language = 'hi-IN', geminiApiKey } = req.body || {};
    if (!userQuery) {
      return res.status(400).json({ success: false, error: 'userQuery is required' });
    }

    const result = await extractAndPersistMemory({
      userQuery,
      assistantReply,
      personaMode,
      language,
      apiKey: geminiApiKey,
    });

    return res.json({
      success: true,
      ...result,
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: 'Extraction failed', details: err?.message });
  }
});


function createPcmWavHeader(pcmLength: number, sampleRate = 24000, channels = 1, bitDepth = 16): Buffer {
  const header = Buffer.alloc(44);
  header.write('RIFF', 0);
  header.writeUInt32LE(36 + pcmLength, 4);
  header.write('WAVE', 8);
  header.write('fmt ', 12);
  header.writeUInt32LE(16, 16);
  header.writeUInt16LE(1, 20); // PCM format
  header.writeUInt16LE(channels, 22);
  header.writeUInt32LE(sampleRate, 24);
  header.writeUInt32LE(sampleRate * channels * (bitDepth / 8), 28);
  header.writeUInt16LE(channels * (bitDepth / 8), 32);
  header.writeUInt16LE(bitDepth, 34);
  header.write('data', 36);
  header.writeUInt32LE(pcmLength, 40);
  return header;
}

// =========================================================================
// ZOYA NEURAL VOICE PREVIEW ENDPOINT
// Serves cached or dynamically generated real audio preview for each voice
// Strictly uses assigned provider/model. Never substitutes or uses robotic TTS.
// =========================================================================
app.post('/api/tts/preview', requireOwnerOrAgentAuth, ttsElevenRateLimiter, async (req, res) => {
  try {
    const {
      voiceId,
      voiceName,
      provider = 'gemini',
      model,
      voiceParam,
      text,
      geminiApiKey,
      elevenLabsApiKey,
    } = req.body || {};

    if (!voiceId) {
      return res.status(400).json({ success: false, error: 'voiceId is required for preview' });
    }

    const previewText =
      (text && typeof text === 'string' && text.trim()) ||
      'Hello! I am Zoya, your intelligent AI companion. How can I help you today?';
    const previewDir = path.join(__dirname, 'data', 'voice_previews');
    if (!fs.existsSync(previewDir)) {
      fs.mkdirSync(previewDir, { recursive: true });
    }

    // 1. Google Gemini Provider
    if (provider === 'gemini') {
      const vName = voiceName || (voiceId.startsWith('gemini-') ? voiceId.replace('gemini-', '') : 'Kore');
      const capitalizedVoiceName = vName.charAt(0).toUpperCase() + vName.slice(1).toLowerCase();
      const cachedFilePath = path.join(previewDir, `${capitalizedVoiceName}.wav`);

      // Return cached audio if present
      if (fs.existsSync(cachedFilePath) && fs.statSync(cachedFilePath).size > 1000) {
        const fileBuf = fs.readFileSync(cachedFilePath);
        return res.json({
          success: true,
          audioData: fileBuf.toString('base64'),
          mimeType: 'audio/wav',
          voiceName: capitalizedVoiceName,
          provider: 'gemini',
          model: model || 'gemini-3.8-flash-lite-tts',
          cached: true,
        });
      }

      const effectiveGeminiKey =
        (geminiApiKey && typeof geminiApiKey === 'string' ? geminiApiKey.trim() : '') ||
        process.env.GEMINI_API_KEY ||
        '';

      if (!effectiveGeminiKey) {
        return res.status(400).json({
          success: false,
          error: 'Preview unavailable: Gemini API key is not configured in environment or settings.',
        });
      }

      try {
        const ai = getGenAIClient(effectiveGeminiKey);
        const ttsCall = ai.models.generateContent({
          model: 'gemini-3.8-flash-lite-tts',
          contents: [{ role: 'user', parts: [{ text: previewText }] }],
          config: {
            responseModalities: [Modality.AUDIO],
            speechConfig: {
              voiceConfig: {
                prebuiltVoiceConfig: {
                  voiceName: capitalizedVoiceName,
                },
              },
            },
          },
        });

        const timeoutPromise = new Promise<null>((resolve) => setTimeout(() => resolve(null), 9000));
        const ttsResponse: any = await Promise.race([ttsCall, timeoutPromise]);
        const part = ttsResponse?.candidates?.[0]?.content?.parts?.[0];

        if (part?.inlineData?.data) {
          const rawBuf = Buffer.from(part.inlineData.data, 'base64');
          const isAlreadyWav = rawBuf.length > 4 && rawBuf.slice(0, 4).toString('ascii') === 'RIFF';
          let finalBuf = rawBuf;
          if (!isAlreadyWav) {
            const wavHeader = createPcmWavHeader(rawBuf.length, 24000, 1, 16);
            finalBuf = Buffer.concat([wavHeader, rawBuf]);
          }
          fs.writeFileSync(cachedFilePath, finalBuf);
          return res.json({
            success: true,
            audioData: finalBuf.toString('base64'),
            mimeType: 'audio/wav',
            voiceName: capitalizedVoiceName,
            provider: 'gemini',
            model: 'gemini-3.8-flash-lite-tts',
          });
        } else {
          return res.status(502).json({
            success: false,
            error: `Preview unavailable: Model ${model || 'gemini-3.8-flash-lite-tts'} returned no audio data.`,
          });
        }
      } catch (err: any) {
        const errMsg = err?.message || String(err);
        return res.status(500).json({
          success: false,
          error: `Preview unavailable: ${errMsg}`,
        });
      }
    }

    // 2. ElevenLabs Provider (Server-only API key; never stored in or returned to browser)
    if (provider === 'elevenlabs') {
      const effectiveElevenKey =
        getActiveElevenLabsApiKey() ||
        (elevenLabsApiKey && typeof elevenLabsApiKey === 'string' ? elevenLabsApiKey.trim() : '') ||
        '';

      if (!effectiveElevenKey) {
        return res.status(400).json({
          success: false,
          error: 'Preview unavailable: ElevenLabs API Key is not configured on the server.',
        });
      }

      const elevenVoiceId = voiceParam || getActiveElevenLabsVoiceId();
      const elevenModel = model || 'eleven_turbo_v2_5';
      const cachedFilePath = path.join(previewDir, `eleven_${elevenVoiceId}_${elevenModel}.mp3`);

      if (fs.existsSync(cachedFilePath) && fs.statSync(cachedFilePath).size > 1000) {
        const fileBuf = fs.readFileSync(cachedFilePath);
        return res.json({
          success: true,
          audioData: fileBuf.toString('base64'),
          mimeType: 'audio/mpeg',
          voiceName: voiceName || 'ElevenLabs Voice',
          provider: 'elevenlabs',
          model: elevenModel,
          cached: true,
        });
      }

      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 9000);
      try {
        const elevenUrl = `https://api.elevenlabs.io/v1/text-to-speech/${encodeURIComponent(elevenVoiceId)}?output_format=mp3_44100_128`;
        const elevenRes = await fetch(elevenUrl, {
          method: 'POST',
          headers: {
            'xi-api-key': effectiveElevenKey,
            'Content-Type': 'application/json',
            'Accept': 'audio/mpeg',
          },
          body: JSON.stringify({
            text: previewText,
            model_id: elevenModel,
            voice_settings: {
              stability: 0.5,
              similarity_boost: 0.75,
            },
          }),
          signal: controller.signal,
        });

        if (elevenRes.ok) {
          const arrayBuf = await elevenRes.arrayBuffer();
          const buf = Buffer.from(arrayBuf);
          fs.writeFileSync(cachedFilePath, buf);
          return res.json({
            success: true,
            audioData: buf.toString('base64'),
            mimeType: 'audio/mpeg',
            voiceName: voiceName || 'ElevenLabs Voice',
            provider: 'elevenlabs',
            model: elevenModel,
          });
        } else {
          const errText = await elevenRes.text();
          return res.status(elevenRes.status).json({
            success: false,
            error: `Preview unavailable: ElevenLabs API returned HTTP ${elevenRes.status} (${errText.slice(0, 100)})`,
          });
        }
      } catch (err: any) {
        return res.status(500).json({
          success: false,
          error: `Preview unavailable: ${err?.message || 'ElevenLabs request failed'}`,
        });
      } finally {
        clearTimeout(timeoutId);
      }
    }

    return res.status(400).json({
      success: false,
      error: `Preview unavailable: Unknown provider '${provider}'`,
    });
  } catch (err: any) {
    return res.status(500).json({
      success: false,
      error: `Preview unavailable: ${err?.message || 'Internal server error'}`,
    });
  }
});

const elevenLabsConfigPath = path.join(__dirname, 'data', 'elevenlabs_config.json');

function readServerElevenLabsConfig(): { apiKey: string; voiceId: string } {
  let apiKey = (process.env.ELEVENLABS_API_KEY || '').trim();
  let voiceId = (process.env.ELEVENLABS_VOICE_ID || '21m00Tcm4TlvDq8ikWAM').trim();
  try {
    if (fs.existsSync(elevenLabsConfigPath)) {
      try { fs.chmodSync(elevenLabsConfigPath, 0o600); } catch {}
      const raw = fs.readFileSync(elevenLabsConfigPath, 'utf8');
      const parsed = JSON.parse(raw);
      if (!apiKey && parsed?.apiKey && typeof parsed.apiKey === 'string') {
        apiKey = parsed.apiKey.trim();
      }
      if (parsed?.voiceId && typeof parsed.voiceId === 'string' && parsed.voiceId.trim()) {
        voiceId = parsed.voiceId.trim();
      }
    }
  } catch {}
  return { apiKey, voiceId };
}

function getActiveElevenLabsApiKey(): string {
  return readServerElevenLabsConfig().apiKey;
}

function getActiveElevenLabsVoiceId(): string {
  return readServerElevenLabsConfig().voiceId;
}

function saveServerElevenLabsConfig(apiKey?: string, voiceId?: string): { configured: boolean; voiceId: string } {
  const existing = readServerElevenLabsConfig();
  const nextApiKey = typeof apiKey === 'string' ? apiKey.trim() : existing.apiKey;
  const nextVoiceId = (typeof voiceId === 'string' && voiceId.trim()) ? voiceId.trim() : existing.voiceId;
  const dir = path.dirname(elevenLabsConfigPath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
  }
  try { fs.chmodSync(dir, 0o700); } catch {}
  fs.writeFileSync(
    elevenLabsConfigPath,
    JSON.stringify(
      {
        apiKey: nextApiKey,
        voiceId: nextVoiceId,
        updatedAt: new Date().toISOString(),
      },
      null,
      2
    ),
    { encoding: 'utf8', mode: 0o600 }
  );
  try { fs.chmodSync(elevenLabsConfigPath, 0o600); } catch {}
  return {
    configured: Boolean(nextApiKey || process.env.ELEVENLABS_API_KEY?.trim()),
    voiceId: nextVoiceId,
  };
}

// =========================================================================
// NEURAL TTS CACHE & QUOTA COOLDOWN SYSTEM
// Protects against Gemini Free Tier 3 RPM rate limits, provides instant audio
// for repeated phrases (battery alerts, greetings, diagnostics), and strictly enforces zero robotic fallback.
// =========================================================================
const ttsAudioCacheDir = path.join(__dirname, '.cache', 'tts_audio');
try {
  fs.mkdirSync(ttsAudioCacheDir, { recursive: true });
} catch {}

interface CachedTtsAudio {
  audioData: string;
  mimeType: string;
  engine: string;
  engineUsed: string;
  model: string;
  voiceName: string;
  priority: string;
  tier: number;
}

const ttsMemoryCache = new Map<string, CachedTtsAudio>();
const inFlightTts = new Map<string, Promise<CachedTtsAudio | null>>();
let geminiTtsCooldownUntil = 0;

function getTtsCacheKey(
  text: string,
  voiceName: string,
  langCode: string,
  forceEngine: string = 'auto',
  elevenVoiceId: string = ''
): string {
  const normalized = text.trim().toLowerCase().replace(/[*#_`]/g, '').replace(/\s+/g, ' ');
  return crypto
    .createHash('sha256')
    .update(`${normalized}__${voiceName}__${langCode}__${forceEngine || 'auto'}__${elevenVoiceId}`)
    .digest('hex');
}

function getFromTtsCache(key: string): CachedTtsAudio | null {
  if (ttsMemoryCache.has(key)) {
    return ttsMemoryCache.get(key)!;
  }
  const diskPath = path.join(ttsAudioCacheDir, `${key}.json`);
  if (fs.existsSync(diskPath)) {
    try {
      const data = JSON.parse(fs.readFileSync(diskPath, 'utf8'));
      if (data && data.audioData) {
        ttsMemoryCache.set(key, data);
        return data;
      }
    } catch {}
  }
  return null;
}

function saveToTtsCache(key: string, data: CachedTtsAudio) {
  if (ttsMemoryCache.size > 800) {
    const firstKey = ttsMemoryCache.keys().next().value;
    if (firstKey) ttsMemoryCache.delete(firstKey);
  }
  ttsMemoryCache.set(key, data);
  try {
    const diskPath = path.join(ttsAudioCacheDir, `${key}.json`);
    fs.writeFileSync(diskPath, JSON.stringify(data), 'utf8');
  } catch {}
}

// 3-Tier Neural Text-To-Speech endpoint:
// 1. Primary: ElevenLabs v4 Turbo (eleven_turbo_v2_5)
// 2. Secondary: ElevenLabs v4 Multilingual (eleven_multilingual_v2)
// 3. Final Backup: Google Gemini Live API (gemini-3.8-live / gemini-3.8-flash-lite-tts, Voice: Kore/Selected Voice)
// STRICT POLICY: Browser SpeechSynthesis & Android Robotic Voices are PERMANENTLY BLOCKED.
app.post('/api/tts', ttsElevenRateLimiter, async (req, res) => {
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  try {
    const { 
      text, 
      language = 'hi-IN', 
      geminiApiKey,
      elevenLabsApiKey, 
      elevenLabsVoiceId,
      forceEngine,
      voiceName,
      selectedVoiceId
    } = req.body || {};

    if (!text || typeof text !== 'string' || !text.trim()) {
      return res.status(400).json({ error: 'Text is required for TTS' });
    }

    const langConfig = getLanguageConfig(language);
    const effectiveGeminiKey = (geminiApiKey && typeof geminiApiKey === 'string' ? geminiApiKey.trim() : '') || process.env.GEMINI_API_KEY || '';
    const hasGeminiKey = Boolean(effectiveGeminiKey);
    // Allow server-configured ElevenLabs key for normal /api/tts playback without requiring owner auth cookie
    const serverElevenKey = getActiveElevenLabsApiKey();
    const effectiveElevenKey =
      serverElevenKey ||
      (elevenLabsApiKey && typeof elevenLabsApiKey === 'string' ? elevenLabsApiKey.trim() : '') ||
      '';
    const elevenLabsConfigured = Boolean(effectiveElevenKey);

    // Resolve voice selection:
    let effectiveGeminiVoice = 'Kore';
    let effectiveElevenVoice =
      (elevenLabsVoiceId && typeof elevenLabsVoiceId === 'string' ? elevenLabsVoiceId.trim() : '') ||
      getActiveElevenLabsVoiceId();

    if (selectedVoiceId && typeof selectedVoiceId === 'string') {
      if (selectedVoiceId.startsWith('gemini-')) {
        const raw = selectedVoiceId.replace('gemini-', '');
        effectiveGeminiVoice = raw.charAt(0).toUpperCase() + raw.slice(1).toLowerCase();
      } else if (selectedVoiceId.startsWith('eleven-')) {
        const elevenMap: Record<string, string> = {
          'eleven-rachel': '21m00Tcm4TlvDq8ikWAM',
          'eleven-domi': 'AZnzlk1XvdvUeBnXmlld',
          'eleven-bella': 'EXAVITQu4vr4xnSDxMaL',
          'eleven-antoni': 'ErXwobaYiN019PkySvjV',
          'eleven-elli': 'MF3mGyEYCl7XYWbV9V6O',
          'eleven-josh': 'TxGEqnHWrfWFTfGW9XjX',
        };
        if (elevenMap[selectedVoiceId]) {
          effectiveElevenVoice = elevenMap[selectedVoiceId];
        }
      }
    } else if (voiceName && typeof voiceName === 'string') {
      effectiveGeminiVoice = voiceName.charAt(0).toUpperCase() + voiceName.slice(1).toLowerCase();
    }

    // Step 0: Check Cache before any external network requests (scoped by forceEngine & elevenVoice)
    const cacheKey = getTtsCacheKey(
      text,
      effectiveGeminiVoice,
      langConfig.code,
      typeof forceEngine === 'string' && forceEngine ? forceEngine : 'auto',
      effectiveElevenVoice
    );
    const cachedEntry = getFromTtsCache(cacheKey);
    if (cachedEntry) {
      return res.json({
        audioData: cachedEntry.audioData,
        mimeType: cachedEntry.mimeType,
        engine: cachedEntry.engine || 'elevenlabs',
        engineUsed: `${cachedEntry.engineUsed} (Cached)`,
        model: cachedEntry.model,
        voiceName: cachedEntry.voiceName,
        priority: cachedEntry.priority || 'PRIMARY',
        tier: cachedEntry.tier || 1,
        cached: true,
        elevenLabsConfigured,
        roboticFallbackBlocked: true,
        language: langConfig.code,
      });
    }

    // Deduplicate in-flight requests for identical utterances
    if (inFlightTts.has(cacheKey)) {
      const coalesced = await inFlightTts.get(cacheKey);
      if (coalesced) {
        return res.json({
          audioData: coalesced.audioData,
          mimeType: coalesced.mimeType,
          engine: coalesced.engine || 'elevenlabs',
          engineUsed: `${coalesced.engineUsed} (Coalesced)`,
          model: coalesced.model,
          voiceName: coalesced.voiceName,
          priority: coalesced.priority || 'PRIMARY',
          tier: coalesced.tier || 1,
          cached: true,
          elevenLabsConfigured,
          roboticFallbackBlocked: true,
          language: langConfig.code,
        });
      }
    }

    const ttsDeadlineAt = Date.now() + 9000;
    const remainingBudgetMs = (capMs: number) => Math.max(0, Math.min(capMs, ttsDeadlineAt - Date.now()));

    let tier1Error: string | null = null;
    let tier2Error: string | null = null;
    let tier3Error: string | null = null;

    const synthesizePromise = (async (): Promise<CachedTtsAudio | null> => {
      // =========================================================================
      // ENGINE 1 (PRIMARY): ElevenLabs TTS
      // =========================================================================
      const canRunTier1 = Boolean(effectiveElevenKey) && forceEngine !== 'gemini-flash' && forceEngine !== 'gemini-tts' && forceEngine !== 'gemini-live';
      if (canRunTier1 && remainingBudgetMs(4000) >= 1200) {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), remainingBudgetMs(4000));
        try {
          const elevenUrl = `https://api.elevenlabs.io/v1/text-to-speech/${encodeURIComponent(effectiveElevenVoice)}?output_format=mp3_44100_128`;
          const elevenRes = await fetch(elevenUrl, {
            method: 'POST',
            headers: {
              'xi-api-key': effectiveElevenKey,
              'Content-Type': 'application/json',
              'Accept': 'audio/mpeg',
            },
            body: JSON.stringify({
              text,
              model_id: 'eleven_turbo_v2_5',
              voice_settings: {
                stability: 0.5,
                similarity_boost: 0.75,
                style: 0.0,
                use_speaker_boost: true,
              },
            }),
            signal: controller.signal,
          });

          if (elevenRes.ok) {
            const arrayBuf = await elevenRes.arrayBuffer();
            const base64Audio = Buffer.from(arrayBuf).toString('base64');
            const entry: CachedTtsAudio = {
              audioData: base64Audio,
              mimeType: 'audio/mpeg',
              engine: 'elevenlabs',
              engineUsed: 'ElevenLabs TTS (Primary)',
              model: 'eleven_turbo_v2_5',
              voiceName: effectiveElevenVoice,
              priority: 'PRIMARY',
              tier: 1,
            };
            saveToTtsCache(cacheKey, entry);
            return entry;
          } else {
            const errText = await elevenRes.text().catch(() => '');
            tier1Error = `HTTP ${elevenRes.status}: ${errText.slice(0, 160)}`;
            console.warn('[TTS_PIPELINE] Primary (ElevenLabs TTS) failed:', tier1Error);
          }
        } catch (err: any) {
          tier1Error = err?.name === 'AbortError' ? 'ElevenLabs TTS timed out' : (err?.message || String(err));
          console.warn('[TTS_PIPELINE] Primary (ElevenLabs TTS) error:', tier1Error);
        } finally {
          clearTimeout(timeoutId);
        }
      } else {
        tier1Error = effectiveElevenKey ? `Skipped (forceEngine: ${forceEngine})` : 'ElevenLabs API Key not configured';
        if ((forceEngine === 'elevenlabs' || forceEngine === 'elevenlabs-turbo') && !effectiveElevenKey) {
          throw new Error('ELEVENLABS_KEY_MISSING');
        }
      }

      // =========================================================================
      // ENGINE 2 (BACKUP): Google Gemini Flash TTS (gemini-3.8-flash-lite-tts)
      // =========================================================================
      const canRunTier2 = hasGeminiKey && forceEngine !== 'elevenlabs' && forceEngine !== 'elevenlabs-turbo' && forceEngine !== 'gemini-live';
      const now = Date.now();
      const isGeminiFlashCoolingDown = now < geminiTtsCooldownUntil;

      if (canRunTier2 && !isGeminiFlashCoolingDown && remainingBudgetMs(4500) >= 1200) {
        const tier2Budget = remainingBudgetMs(4500);
        try {
          const ai = getGenAIClient(effectiveGeminiKey);
          const ttsCall = ai.models.generateContent({
            model: 'gemini-3.8-flash-lite-tts',
            contents: [{ role: 'user', parts: [{ text }] }],
            config: {
              responseModalities: [Modality.AUDIO],
              speechConfig: {
                voiceConfig: {
                  prebuiltVoiceConfig: {
                    voiceName: effectiveGeminiVoice,
                  },
                },
              },
            },
          });

          const timeoutPromise = new Promise<'TIMEOUT'>((resolve) => setTimeout(() => resolve('TIMEOUT'), tier2Budget));
          const ttsResponse: any = await Promise.race([ttsCall, timeoutPromise]);

          if (ttsResponse === 'TIMEOUT') {
            tier2Error = `Gemini Flash TTS timed out after ${tier2Budget}ms`;
            console.warn('[TTS_PIPELINE]', tier2Error);
          } else {
            const part = ttsResponse?.candidates?.[0]?.content?.parts?.[0];
            if (part?.inlineData?.data) {
              const rawBuf = Buffer.from(part.inlineData.data, 'base64');
              const isAlreadyWav = rawBuf.length > 4 && rawBuf.slice(0, 4).toString('ascii') === 'RIFF';
              let finalBase64 = part.inlineData.data;
              if (!isAlreadyWav) {
                const wavHeader = createPcmWavHeader(rawBuf.length, 24000, 1, 16);
                finalBase64 = Buffer.concat([wavHeader, rawBuf]).toString('base64');
              }
              const entry: CachedTtsAudio = {
                audioData: finalBase64,
                mimeType: 'audio/wav',
                engine: 'gemini-flash',
                engineUsed: 'Google Gemini Flash TTS (Backup)',
                model: 'gemini-3.8-flash-lite-tts',
                voiceName: effectiveGeminiVoice,
                priority: 'BACKUP',
                tier: 2,
              };
              saveToTtsCache(cacheKey, entry);
              return entry;
            }
            tier2Error = 'Gemini Flash TTS returned empty audio part';
          }
        } catch (geminiTtsErr: any) {
          const errMessage = geminiTtsErr?.message || String(geminiTtsErr);
          tier2Error = errMessage;
          if (errMessage.includes('429') || errMessage.includes('RESOURCE_EXHAUSTED') || errMessage.includes('Quota exceeded')) {
            const isDailyLimit = /PerDay|free_tier_requests/i.test(errMessage);
            const match = errMessage.match(/retry(?:ing)?\s+in\s+([\d.]+)\s*s/i) || errMessage.match(/"retryDelay":\s*"(\d+)s"/i);
            const rawSec = match ? parseFloat(match[1]) : 50;
            const seconds = isDailyLimit ? 300 : Math.min(60, Math.max(5, isNaN(rawSec) ? 50 : Math.ceil(rawSec)));
            geminiTtsCooldownUntil = Date.now() + (seconds * 1000);
            console.info(`[TTS_PIPELINE] Backup (Gemini Flash TTS) quota limit reached. Cooldown for ${seconds}s.`);
          } else {
            console.warn('[TTS_PIPELINE] Backup (Gemini Flash TTS) error:', tier2Error);
          }
        }
      } else {
        if (isGeminiFlashCoolingDown) {
          tier2Error = `Gemini Flash TTS quota cooldown in progress (${Math.ceil((geminiTtsCooldownUntil - now) / 1000)}s remaining)`;
        } else if (!hasGeminiKey) {
          tier2Error = 'Gemini API Key not configured';
        } else if (forceEngine === 'elevenlabs' || forceEngine === 'elevenlabs-turbo' || forceEngine === 'gemini-live') {
          tier2Error = `Skipped (forceEngine: ${forceEngine})`;
        } else {
          tier2Error = 'Skipped (insufficient remaining budget)';
        }
        if ((forceEngine === 'gemini-flash' || forceEngine === 'gemini-tts') && !hasGeminiKey) {
          throw new Error('GEMINI_KEY_MISSING_FLASH');
        }
      }

      // =========================================================================
      // ENGINE 3 (FALLBACK): Google Gemini Live API Real-Time Audio (gemini-3.8-live)
      // Independent of Tier 2 Flash TTS daily/RPM cooldown so Live audio can succeed immediately
      // =========================================================================
      const canRunTier3 = hasGeminiKey && forceEngine !== 'elevenlabs' && forceEngine !== 'elevenlabs-turbo' && forceEngine !== 'gemini-flash' && forceEngine !== 'gemini-tts';
      const tier3Budget = remainingBudgetMs(5500);
      if (canRunTier3 && tier3Budget >= 1500) {
        try {
          const ai = getGenAIClient(effectiveGeminiKey);
          const pcmChunks: Buffer[] = [];
          let liveSession: any = null;
          let settled = false;

          const liveAudioResult = await new Promise<{ audioData: string; mimeType: string }>((resolve, reject) => {
            const finalizeIfReady = (reasonOnEmpty: string) => {
              if (settled) return;
              settled = true;
              clearTimeout(timer);
              if (liveSession) {
                try { liveSession.close(); } catch {}
              }
              const fullPcm = Buffer.concat(pcmChunks);
              if (fullPcm.length > 0) {
                const wavHeader = createPcmWavHeader(fullPcm.length, 24000, 1, 16);
                const wavBuffer = Buffer.concat([wavHeader, fullPcm]);
                resolve({
                  audioData: wavBuffer.toString('base64'),
                  mimeType: 'audio/wav',
                });
              } else {
                reject(new Error(reasonOnEmpty));
              }
            };

            const timer = setTimeout(() => {
              finalizeIfReady('Live API synthesis timeout');
            }, tier3Budget);

            const targetLanguageLabel = getSelectedLanguageLabel(langConfig.code);
            ai.live.connect({
              model: 'gemini-3.8-live',
              config: {
                responseModalities: [Modality.AUDIO],
                speechConfig: {
                  languageCode: getLiveSpeechLanguageCode(langConfig.code),
                  voiceConfig: { prebuiltVoiceConfig: { voiceName: effectiveGeminiVoice } },
                },
                systemInstruction: `You are Zoya. Read out the user's text aloud verbatim in ${targetLanguageLabel} with a warm natural tone. Do not add extra words or translate.`,
              },
              callbacks: {
                onmessage: (msg: any) => {
                  const parts = msg.serverContent?.modelTurn?.parts;
                  if (parts) {
                    for (const p of parts) {
                      if (p.inlineData?.data) {
                        pcmChunks.push(Buffer.from(p.inlineData.data, 'base64'));
                      }
                    }
                  }
                  if (msg.serverContent?.turnComplete || msg.serverContent?.generationComplete) {
                    finalizeIfReady('Live API returned 0 audio PCM bytes');
                  }
                },
                onerror: (err: any) => {
                  if (settled) return;
                  settled = true;
                  clearTimeout(timer);
                  if (liveSession) {
                    try { liveSession.close(); } catch {}
                  }
                  reject(err);
                },
                onclose: () => {
                  if (!settled && pcmChunks.length > 0) {
                    finalizeIfReady('Live API closed');
                  }
                },
              },
            }).then((sess: any) => {
              liveSession = sess;
              if (settled) {
                try { sess.close(); } catch {}
                return;
              }
              try {
                sess.sendClientContent({
                  turns: [{ role: 'user', parts: [{ text }] }],
                  turnComplete: true,
                });
              } catch (sendErr: any) {
                if (!settled) {
                  settled = true;
                  clearTimeout(timer);
                  reject(sendErr);
                }
              }
            }).catch((connErr: any) => {
              if (!settled) {
                settled = true;
                clearTimeout(timer);
                reject(connErr);
              }
            });
          });

          const entry: CachedTtsAudio = {
            audioData: liveAudioResult.audioData,
            mimeType: liveAudioResult.mimeType,
            engine: 'gemini-live',
            engineUsed: 'Google Gemini Live API (Fallback)',
            model: 'gemini-3.8-live',
            voiceName: effectiveGeminiVoice,
            priority: 'FALLBACK',
            tier: 3,
          };
          saveToTtsCache(cacheKey, entry);
          return entry;
        } catch (liveErr: any) {
          tier3Error = liveErr?.message || String(liveErr);
          console.warn('[TTS_PIPELINE] Fallback (Gemini Live API) error:', tier3Error);
        }
      } else {
        if (!hasGeminiKey) {
          tier3Error = 'Gemini API Key not configured';
        } else if (tier3Budget < 1500) {
          tier3Error = 'Skipped (insufficient remaining budget)';
        } else {
          tier3Error = `Skipped (forceEngine: ${forceEngine})`;
        }
        if (forceEngine === 'gemini-live' && !hasGeminiKey) {
          throw new Error('GEMINI_KEY_MISSING_LIVE');
        }
      }

      return null;
    })();

    inFlightTts.set(cacheKey, synthesizePromise);
    let synthesizedEntry: CachedTtsAudio | null = null;
    try {
      synthesizedEntry = await synthesizePromise;
    } catch (syncErr: any) {
      if (syncErr?.message === 'ELEVENLABS_KEY_MISSING') {
        return res.status(400).json({
          error: 'ElevenLabs API Key is not configured on server (ELEVENLABS_API_KEY missing). Configure it in Settings > Voice Settings or server env.',
          elevenLabsConfigured: false,
          roboticFallbackBlocked: true,
          engine: 'elevenlabs',
        });
      }
      if (syncErr?.message === 'GEMINI_KEY_MISSING_FLASH') {
        return res.status(400).json({ error: 'Gemini API Key is required for Gemini Flash TTS.', roboticFallbackBlocked: true });
      }
      if (syncErr?.message === 'GEMINI_KEY_MISSING_LIVE') {
        return res.status(400).json({ error: 'Gemini API Key is required for Gemini Live TTS.', roboticFallbackBlocked: true });
      }
      throw syncErr;
    } finally {
      inFlightTts.delete(cacheKey);
    }

    if (synthesizedEntry) {
      return res.json({
        ...synthesizedEntry,
        elevenLabsConfigured,
        roboticFallbackBlocked: true,
        language: langConfig.code,
      });
    }

    // =========================================================================
    // GRACEFUL FALLBACK RESPONSE WHEN ALL 3 NEURAL ENGINES ARE UNAVAILABLE
    // =========================================================================
    const activeCooldown = Date.now() < geminiTtsCooldownUntil;
    const cooldownSec = activeCooldown ? Math.min(300, Math.max(1, Math.ceil((geminiTtsCooldownUntil - Date.now()) / 1000))) : 0;

    console.warn('[TTS_PIPELINE] All neural TTS engines unavailable:', {
      tier1Error,
      tier2Error,
      tier3Error,
      activeCooldown,
    });

    return res.status(200).json({ 
      audioData: null, 
      mimeType: null, 
      quotaExhausted: activeCooldown,
      retryAfter: cooldownSec,
      elevenLabsConfigured,
      error: activeCooldown
        ? `Gemini Flash TTS quota cooldown active (${cooldownSec}s remaining).`
        : 'All 3 neural TTS options (ElevenLabs, Gemini Flash, Gemini Live) currently unavailable.',
      diagnostics: {
        primary_elevenlabs: tier1Error || 'Failed or not configured',
        backup_gemini_flash: tier2Error || 'Failed or not configured',
        fallback_gemini_live: tier3Error || 'Unavailable',
      },
      roboticFallbackBlocked: true,
      fallbackToClient: false, 
      language: langConfig.code 
    });
  } catch (err: any) {
    console.error('[TTS_PIPELINE] Global handler error:', err);
    return res.status(200).json({ 
      audioData: null,
      mimeType: null, 
      error: 'TTS synthesis error', 
      details: err?.message,
      roboticFallbackBlocked: true,
      fallbackToClient: false,
    });
  }
});

// Read-only TTS System Diagnostic & Health Audit Endpoint (Exact 3 Engines)
app.get('/api/tts/diagnostics', requireOwnerOrAgentAuth, ttsElevenRateLimiter, (_req, res) => {
  const hasEnvEleven = Boolean(getActiveElevenLabsApiKey());
  const hasEnvGemini = Boolean(process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY.trim());
  const activeVoiceId = getActiveElevenLabsVoiceId();
  const now = Date.now();
  const cooldownActive = now < geminiTtsCooldownUntil;
  const cooldownRemaining = cooldownActive ? Math.ceil((geminiTtsCooldownUntil - now) / 1000) : 0;

  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    totalMainEngines: 3,
    engines: [
      {
        id: 'elevenlabs',
        name: 'ElevenLabs TTS',
        model: 'eleven_turbo_v2_5',
        provider: 'ElevenLabs',
        role: 'PRIMARY',
        configured: hasEnvEleven,
        voiceId: activeVoiceId,
      },
      {
        id: 'gemini-flash',
        name: 'Google Gemini Flash TTS',
        model: 'gemini-3.8-flash-lite-tts',
        provider: 'Google Gemini',
        role: 'BACKUP',
        configured: hasEnvGemini,
        voiceName: 'Kore',
      },
      {
        id: 'gemini-live',
        name: 'Google Gemini Live API',
        model: 'gemini-3.8-live',
        provider: 'Google Gemini',
        role: 'FALLBACK',
        configured: hasEnvGemini,
        voiceName: 'Kore',
      },
    ],
    env: {
      hasElevenLabsKey: hasEnvEleven,
      hasGeminiKey: hasEnvGemini,
      elevenLabsVoiceId: activeVoiceId,
      geminiDefaultVoice: 'Kore',
    },
    quota: {
      geminiCooldownActive: cooldownActive,
      geminiCooldownRemainingSec: cooldownRemaining,
    },
    cache: {
      inMemoryCount: ttsMemoryCache.size,
      inFlightDeduplications: inFlightTts.size,
    },
    policy: {
      roboticSpeechSynthesisBlocked: true,
      androidSystemTtsBlockedInChat: true,
      offlineEmergencyTtsEnabled: false,
    },
  });
});

// Server-side ElevenLabs Status (NEVER returns API key to browser; yes/no only)
app.get('/api/elevenlabs/status', ttsElevenRateLimiter, (_req, res) => {
  const cfg = readServerElevenLabsConfig();
  return res.json({
    configured: Boolean(cfg.apiKey),
    source: process.env.ELEVENLABS_API_KEY?.trim()
      ? 'env'
      : cfg.apiKey
      ? 'server_config'
      : 'none',
    voiceId: cfg.voiceId,
  });
});

// Server-side ElevenLabs Config Storage (stores key in 0o600 server config; requires owner/agent auth)
app.post('/api/elevenlabs/config', requireOwnerOrAgentAuth, ttsElevenRateLimiter, (req, res) => {
  try {
    const { apiKey, voiceId } = req.body || {};
    const saved = saveServerElevenLabsConfig(apiKey, voiceId);
    return res.json({
      success: true,
      configured: saved.configured,
      voiceId: saved.voiceId,
    });
  } catch (err: any) {
    return res.status(500).json({
      success: false,
      error: err?.message || 'Failed to save ElevenLabs configuration on server.',
    });
  }
});

// Test Connection Endpoint for ElevenLabs (Uses server-side proxy key; requires owner/agent auth)
app.post('/api/elevenlabs/test-connection', requireOwnerOrAgentAuth, ttsElevenRateLimiter, async (req, res) => {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 6500);
  try {
    const { apiKey, voiceId } = req.body || {};
    const effectiveKey =
      getActiveElevenLabsApiKey() ||
      (apiKey && typeof apiKey === 'string' ? apiKey.trim() : '') ||
      '';

    if (!effectiveKey) {
      return res.status(400).json({
        success: false,
        error: 'ElevenLabs API Key is not configured on the server.',
      });
    }

    const userRes = await fetch('https://api.elevenlabs.io/v1/user', {
      method: 'GET',
      headers: { 'xi-api-key': effectiveKey },
      signal: controller.signal,
    });

    if (!userRes.ok) {
      const errText = await userRes.text().catch(() => '');
      return res.status(userRes.status).json({
        success: false,
        statusCode: userRes.status,
        error: `ElevenLabs verification failed (HTTP ${userRes.status}): ${errText.slice(0, 150) || 'Invalid API Key'}`,
      });
    }

    const userData: any = await userRes.json().catch(() => ({}));
    let voiceDetails: any = null;
    const testVoiceId =
      (voiceId && typeof voiceId === 'string' ? voiceId.trim() : '') ||
      getActiveElevenLabsVoiceId();

    let voiceWarning: string | null = null;
    if (testVoiceId) {
      const vController = new AbortController();
      const vTimeout = setTimeout(() => vController.abort(), 5000);
      try {
        const vRes = await fetch(`https://api.elevenlabs.io/v1/voices/${encodeURIComponent(testVoiceId)}`, {
          headers: { 'xi-api-key': effectiveKey },
          signal: vController.signal,
        });
        if (vRes.ok) {
          voiceDetails = await vRes.json().catch(() => null);
        } else if (vRes.status === 404) {
          voiceWarning = `Voice ID "${testVoiceId}" was not found on your ElevenLabs account. Using default Rachel voice.`;
        }
      } catch (e: any) {
        voiceWarning = `Could not verify Voice ID: ${e?.message || 'Network error'}`;
      } finally {
        clearTimeout(vTimeout);
      }
    }

    return res.json({
      success: true,
      status: 'Connected & Verified',
      voiceWarning,
      subscriptionTier: userData?.subscription?.tier || 'free',
      characterCount: userData?.subscription?.character_count ?? 0,
      characterLimit: userData?.subscription?.character_limit ?? 10000,
      voiceId: testVoiceId,
      voiceName: voiceDetails?.name || 'Default Rachel Voice',
    });
  } catch (err: any) {
    return res.status(500).json({
      success: false,
      error: err?.message || 'Connection test failed',
    });
  } finally {
    clearTimeout(timeoutId);
  }
});

// =========================================================================
// WEBSITE BUILDER: STREAMING GEMINI GENERATOR, PUBLIC HOSTING & CUSTOM DOMAINS
// Zero templates, zero presets, zero fallback sample sites.
// =========================================================================
try {
  const legacyJobsFile = path.join(__dirname, 'data', 'website_jobs.json');
  if (fs.existsSync(legacyJobsFile)) {
    fs.unlinkSync(legacyJobsFile);
  }
} catch {}
registerWebsiteBuilderRoutes(app);

import {
  getActiveApiKey,
  saveApiKey,
  getMaskedKey,
  validateApiKey,
  searchSingers,
  searchVideos,
  getSingerTopTracks,
} from './src/services/serverYouTubeService.ts';

// =========================================================================
// ZOYA OFFICIAL YOUTUBE DATA API V3 SERVICE ROUTES
// =========================================================================

// 1. GET /api/youtube/status - Check connection status and whether key is configured
app.get('/api/youtube/status', async (_req, res) => {
  try {
    const key = getActiveApiKey();
    if (!key) {
      return res.json({
        configured: false,
        connected: false,
        maskedKey: '',
        keySource: 'none',
        message: 'YouTube Data API key is not configured. Please enter a valid key in Settings > YouTube.',
      });
    }

    const test = await validateApiKey(key);
    const keySource = process.env.YOUTUBE_API_KEY || process.env.GOOGLE_API_KEY ? 'environment' : 'stored_config';

    return res.json({
      configured: true,
      connected: test.valid,
      maskedKey: getMaskedKey(),
      keySource,
      error: test.error || null,
      message: test.valid
        ? 'Successfully connected to YouTube Data API v3.'
        : `Connection failed: ${test.error}`,
    });
  } catch (err: any) {
    return res.status(500).json({
      configured: false,
      connected: false,
      error: err?.message,
      message: 'Failed to verify YouTube API connection status.',
    });
  }
});

// 2. POST /api/youtube/config - Securely configure YouTube API key server-side
app.post('/api/youtube/config', async (req, res) => {
  try {
    const rawKey = typeof req.body?.apiKey === 'string' ? req.body.apiKey.trim() : '';
    if (!rawKey) {
      return res.status(400).json({
        success: false,
        message: 'Please provide an API key.',
      });
    }

    // Validate key live against YouTube Data API
    const test = await validateApiKey(rawKey);
    if (!test.valid) {
      return res.status(400).json({
        success: false,
        valid: false,
        error: test.error,
        message: `Validation failed: ${test.error}. Please check the key and quota.`,
      });
    }

    saveApiKey(rawKey);

    return res.json({
      success: true,
      valid: true,
      maskedKey: getMaskedKey(),
      message: 'YouTube Data API key verified and securely configured!',
    });
  } catch (err: any) {
    return res.status(500).json({
      success: false,
      error: err?.message,
      message: 'Failed to save YouTube configuration.',
    });
  }
});

// 3. GET /api/youtube/search-singers - Search singers and their channels
app.get('/api/youtube/search-singers', async (req, res) => {
  try {
    const q = typeof req.query?.q === 'string' ? req.query.q.trim() : '';
    if (!q) {
      return res.status(400).json({ success: false, error: 'Query parameter q is required.', channels: [] });
    }

    const result = await searchSingers(q);
    return res.json(result);
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message, channels: [] });
  }
});

// 4. GET /api/youtube/search-videos - Search music videos by song or singer
app.get('/api/youtube/search-videos', async (req, res) => {
  try {
    const q = typeof req.query?.q === 'string' ? req.query.q.trim() : '';
    const singer = typeof req.query?.singer === 'string' ? req.query.singer.trim() : '';
    const maxResults = parseInt(req.query?.maxResults as string, 10) || 10;

    if (!q && !singer) {
      return res.status(400).json({ success: false, error: 'Query or singer parameter required.', videos: [] });
    }

    const result = await searchVideos(q, singer, maxResults);
    return res.json(result);
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message, videos: [] });
  }
});

// 5. GET /api/youtube/singer-top-tracks - Get top hit tracks for a singer
app.get('/api/youtube/singer-top-tracks', async (req, res) => {
  try {
    const singer = typeof req.query?.singer === 'string' ? req.query.singer.trim() : '';
    const channelId = typeof req.query?.channelId === 'string' ? req.query.channelId.trim() : '';

    if (!singer && !channelId) {
      return res.status(400).json({ success: false, error: 'Singer name or channelId required.', videos: [] });
    }

    const result = await getSingerTopTracks(singer, channelId);
    return res.json(result);
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message, videos: [] });
  }
});

// ==========================================
// ZOYA PYTHON ENGINE & DEVELOPMENT STUDIO APIS
// ==========================================
import {
  executePythonScript,
  getPythonEnvironmentInfo,
  generateAndroidAppFromPrompt,
  buildLocalSourceBundle,
  testGitHubConnection,
  triggerGitHubActionsBuild,
  checkGitHubBuildStatus,
  getDownloadedProjectFilePath,
} from './src/services/serverPythonEngine.ts';

// 1. GET /api/python/status & /api/python/environment - System runtime & version
app.get(['/api/python/status', '/api/python/environment'], async (_req, res) => {
  try {
    const envInfo = await getPythonEnvironmentInfo();
    return res.json({ success: true, ...envInfo });
  } catch (err: any) {
    return res.status(500).json({ available: false, error: err?.message });
  }
});

// 2. POST /api/python/execute - Execute Python 3 code in isolated subprocess with timeout
app.post('/api/python/execute', async (req, res) => {
  try {
    const { code, stdin = '', timeoutMs = 15000 } = req.body || {};
    if (!code || typeof code !== 'string') {
      return res.status(400).json({ success: false, error: 'Python code is required.' });
    }
    const result = await executePythonScript(code, stdin, timeoutMs);
    return res.json(result);
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message });
  }
});

// 3. POST /api/python/generate-app - Synthesize complete Android project (Kotlin/Java) with safety checks
app.post('/api/python/generate-app', async (req, res) => {
  try {
    const { prompt, appName, language, apiKey, modelName } = req.body || {};
    if (!prompt || typeof prompt !== 'string') {
      return res.status(400).json({ success: false, error: 'App description prompt is required.' });
    }
    const result = await generateAndroidAppFromPrompt({
      prompt,
      appName,
      language,
      apiKey,
      modelName,
    });
    return res.json(result);
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message });
  }
});

// 4. POST /api/python/build/github-test - Test GitHub PAT connection & scopes (Round 5 Item 4B)
app.post('/api/python/build/github-test', async (req, res) => {
  try {
    const { githubToken } = req.body || {};
    const result = await testGitHubConnection(githubToken);
    return res.json(result);
  } catch (err: any) {
    return res.status(500).json({
      success: false,
      message: err?.message || 'Failed to test GitHub connection',
      error: err?.message,
    });
  }
});

// 5. POST /api/python/build/github - Trigger or run individual steps of GitHub Actions APK pipeline (Round 5 Item 4B)
app.post(['/api/python/build/github', '/api/python/github-build/trigger'], async (req, res) => {
  try {
    const { githubToken, repoName, appName, files, isPrivate, step } = req.body || {};
    const result = await triggerGitHubActionsBuild({
      githubToken,
      repoName: repoName || appName || 'zoya-android-app',
      files: files || [],
      isPrivate,
      step,
    });
    return res.json(result);
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message });
  }
});

// 6. POST /api/python/build/github-status - Poll GitHub Actions run status, steps & Release asset URL (Round 5 Item 4B & 4C)
app.post(['/api/python/build/github-status', '/api/python/github-build/status'], async (req, res) => {
  try {
    const { owner, repo, repoName, githubToken, runId } = req.body || {};
    const result = await checkGitHubBuildStatus({
      owner,
      repo: repo || repoName,
      githubToken,
      runId,
    });
    return res.json(result);
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message });
  }
});

// 7. POST /api/python/build/source-bundle (and alias /api/python/build/local-apk)
// ROUND 5 ITEM 3: Strictly outputs a .zip Source Code Bundle and labels it:
// "Source code bundle (.zip) - NOT an installable app"
app.post(['/api/python/build/source-bundle', '/api/python/build/local-apk'], async (req, res) => {
  try {
    const { appName = 'ZoyaApp', packageName = 'com.zoya.generated.app', versionName = '1.0.0', files, code } = req.body || {};
    const effectiveFiles = Array.isArray(files) && files.length > 0
      ? files
      : [{ path: 'main.py', content: typeof code === 'string' ? code : 'print("Zoya Source Bundle")' }];
    const result = await buildLocalSourceBundle({
      appName,
      packageName,
      versionName,
      files: effectiveFiles,
    });
    return res.json(result);
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message });
  }
});

// 8. GET /api/python/download/:filename - Download Source Code Bundle (.zip)
// ROUND 5 ITEM 3: Never serves a local file with an .apk extension.
app.get('/api/python/download/:filename', (req, res) => {
  try {
    const file = req.params.filename;
    if (!file || file.toLowerCase().endsWith('.apk')) {
      return res
        .status(400)
        .send('Refused: Local builds produce Source Code Bundles (.zip), not installable .apk files.');
    }
    const filePath = getDownloadedProjectFilePath(file);
    if (!filePath || !fs.existsSync(filePath)) {
      return res.status(404).send('Source code bundle (.zip) not found.');
    }

    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate');
    res.setHeader('Content-Disposition', `attachment; filename="${path.basename(filePath)}"`);
    res.setHeader('Content-Type', 'application/zip');
    return res.sendFile(filePath);
  } catch (err: any) {
    return res.status(500).send(`Download error: ${err?.message}`);
  }
});

// ==========================================
// CODING AGENT API (PHASE 1 CORE & PHASE 2 SECURITY)
// ==========================================

// Owner Passphrase & Pairing Status
app.get('/api/agent/auth/owner/status', (_req, res) => {
  const isConfigured = AgentAuthManager.isOwnerPassphraseConfigured();
  return res.json({
    success: true,
    isConfigured,
    requiresSetupCode: !isConfigured,
  });
});

app.post('/api/agent/auth/owner/reset-limit', agentAuth, (req, res) => {
  const { setupCode } = req.body || {};
  const headerSetup = typeof req.headers['x-setup-code'] === 'string' ? req.headers['x-setup-code'] : undefined;
  const effectiveSetup = (typeof setupCode === 'string' ? setupCode : undefined) || headerSetup;
  const clientIp = req.socket?.remoteAddress || 'unknown';

  const result = AgentAuthManager.checkAndTrackResetLimit(clientIp, effectiveSetup);
  if (result.allowed) {
    return res.json({ success: true, message: 'Rate limiter reset successfully via setup code.' });
  }
  return res.status(result.status).json({
    success: false,
    error: result.error,
    waitSeconds: result.waitSeconds,
  });
});

// Setup or update owner passphrase (strictly requires one-time console setup code on first use)
app.post('/api/agent/auth/owner/setup', (req, res) => {
  const { passphrase, setupCode, currentPassphrase } = req.body || {};
  const codeFromHeader = req.headers['x-setup-code'] as string | undefined;
  const effectiveCode = setupCode || codeFromHeader;

  if (!passphrase || typeof passphrase !== 'string' || passphrase.length < 8) {
    return res.status(400).json({
      success: false,
      error: 'Passphrase must be a string of at least 8 characters.',
    });
  }

  const result = AgentAuthManager.setOwnerPassphraseWithSetupCode(
    passphrase,
    effectiveCode,
    currentPassphrase
  );

  if (!result.success) {
    return res.status(403).json({ success: false, error: result.error });
  }

  return res.json({
    success: true,
    message: 'Owner passphrase configured securely with salted scrypt hash. One-time setup code consumed.',
  });
});

// Owner Login: validates owner passphrase and issues short-lived HttpOnly Secure partitioned cookie
app.post('/api/agent/auth/owner/login', (req, res) => {
  const { passphrase } = req.body || {};
  if (!passphrase) {
    return res.status(401).json({ success: false, error: 'Owner passphrase is required.' });
  }
  const verification = AgentAuthManager.verifyOwnerPassphrase(passphrase);
  if (!verification.success) {
    const status = verification.rateLimited ? 429 : 401;
    return res.status(status).json({
      success: false,
      error: verification.error,
      rateLimited: !!verification.rateLimited,
      waitSeconds: verification.waitSeconds,
    });
  }

  const sessionToken = AgentAuthManager.createApprovalSession();
  const sameSite = AGENT_COOKIE_CONFIG.sameSite;
  const cookieFlags = sameSite === 'None'
    ? 'Path=/; HttpOnly; SameSite=None; Secure; Partitioned; Max-Age=3600'
    : `Path=/; HttpOnly; SameSite=${sameSite}; Secure; Max-Age=3600`;

  res.setHeader('Set-Cookie', `zoya_approval_session=${sessionToken}; ${cookieFlags}`);
  return res.json({
    success: true,
    message: 'Passphrase authenticated. HttpOnly approval session cookie issued.',
    approvalSession: sessionToken,
  });
});

// Generate pairing code: STRICTLY REQUIRES valid owner passphrase (POST) + rate limit
app.all('/api/agent/auth/pairing-code', (req, res) => {
  if (req.method !== 'POST') {
    return res.status(405).json({
      success: false,
      error: 'Method Not Allowed: POST with owner passphrase required to obtain a pairing code.',
    });
  }
  const clientIp = req.socket?.remoteAddress || 'unknown';
  const rate = AgentAuthManager.checkPairingEndpointRateLimit(clientIp, 'pair_issue');
  if (!rate.allowed) {
    if (rate.waitSeconds) res.setHeader('Retry-After', String(rate.waitSeconds));
    return res.status(429).json({
      success: false,
      error: rate.error,
      rateLimited: true,
      waitSeconds: rate.waitSeconds,
    });
  }

  const passphrase = req.body?.passphrase || (req.headers['x-owner-passphrase'] as string);
  if (!passphrase) {
    return res.status(401).json({
      success: false,
      error: 'Unauthorized: Valid owner passphrase required to generate a pairing code. Spoofing headers is rejected.',
    });
  }

  const result = AgentAuthManager.generatePairingCodeWithPassphrase(passphrase);
  if (!result.success) {
    const status = result.rateLimited ? 429 : 401;
    return res.status(status).json({
      success: false,
      error: result.error,
      rateLimited: !!result.rateLimited,
      waitSeconds: result.waitSeconds,
    });
  }

  return res.json({ success: true, pairingCode: result.pairingCode });
});

// Agent Auth Bootstrap / Pairing-code consume endpoint (Rate-limited + single-use pairing code)
// STRICT SECURITY: userSecret is NEVER returned to the browser or in any response payload!
app.get('/api/agent/auth/token', (req, res) => {
  const clientIp = req.socket?.remoteAddress || 'unknown';
  const rate = AgentAuthManager.checkPairingEndpointRateLimit(clientIp, 'pair_consume');
  if (!rate.allowed) {
    if (rate.waitSeconds) res.setHeader('Retry-After', String(rate.waitSeconds));
    return res.status(429).json({
      success: false,
      error: rate.error,
      rateLimited: true,
      waitSeconds: rate.waitSeconds,
    });
  }

  if (!AgentAuthManager.isLocalOrTrustedOrigin(req)) {
    return res.status(403).json({
      success: false,
      error: 'Forbidden: One-time pairing code required for bootstrap. Unauthenticated loopback requests are rejected.',
      code: 'PAIRING_CODE_REQUIRED',
    });
  }

  const token = AgentAuthManager.getOrCreateToken();
  const pairedSession = AgentAuthManager.createPairedSession();
  const sameSite = AGENT_COOKIE_CONFIG.sameSite;
  const cookieFlags = sameSite === 'None'
    ? 'Path=/; HttpOnly; SameSite=None; Secure; Partitioned; Max-Age=3600'
    : `Path=/; HttpOnly; SameSite=${sameSite}; Secure; Max-Age=3600`;
  res.setHeader('Set-Cookie', `zoya_agent_paired_session=${pairedSession}; ${cookieFlags}`);

  return res.json({ success: true, token, pairedSession });
});

// Protect ALL subsequent /api/agent/* endpoints with strict authentication
app.use('/api/agent/*', (req, res, next) => {
  const url = (req.originalUrl || req.url || req.path || '').split('?')[0];
  if (
    url === '/api/agent/auth/token' ||
    url === '/api/agent/auth/pairing-code' ||
    url === '/api/agent/auth/owner/login' ||
    url === '/api/agent/auth/owner/setup' ||
    url === '/api/agent/auth/owner/status'
  ) {
    return next();
  }
  // User approval response endpoint is protected strictly by requireUserApprovalMiddleware
  if (url.startsWith('/api/agent/approvals/') && url.endsWith('/respond')) {
    return next();
  }
  return agentAuth(req, res, next);
});

// Rotate Agent Auth Token (Requires current token authentication)
app.post('/api/agent/auth/rotate', (req, res) => {
  const newToken = AgentAuthManager.rotateToken();
  return res.json({
    success: true,
    message: 'Agent auth token successfully rotated. Update Bearer headers.',
    token: newToken,
  });
});

// 1. POST /api/agent/run - Run autonomous agent task
app.post('/api/agent/run', async (req, res) => {
  try {
    const { prompt, workspaceRoot, maxRetries, modelConfig } = req.body || {};
    if (!prompt || typeof prompt !== 'string') {
      return res.status(400).json({ success: false, error: 'Task prompt is required.' });
    }

    if (workspaceRoot) {
      codingAgentCore.setWorkspaceRoot(workspaceRoot);
    }
    if (modelConfig) {
      codingAgentCore.updateModelConfig(modelConfig);
    }

    // Execute task through autonomous plan-act-fix-verify loop
    const taskResult = await codingAgentCore.runTask(prompt);
    return res.json({ success: true, task: taskResult });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || String(err) });
  }
});

// 2. POST /api/agent/stop - Abort running agent task
app.post('/api/agent/stop', (_req, res) => {
  const aborted = codingAgentCore.abortTask();
  return res.json({ success: aborted, message: aborted ? 'Task aborted.' : 'No active running task.' });
});

// 3. GET /api/agent/status - Get active task status
app.get(['/api/agent/status', '/api/agent/status/:taskId'], (_req, res) => {
  const activeTask = codingAgentCore.getActiveTask();
  return res.json({ success: true, task: activeTask });
});

// 4. GET /api/agent/logs - Get saved historical task logs
app.get('/api/agent/logs', (_req, res) => {
  const logs = codingAgentCore.getSavedTaskLogs();
  return res.json({ success: true, logs });
});

// 5. POST /api/agent/config - Update agent settings
app.post('/api/agent/config', (req, res) => {
  const { workspaceRoot, modelConfig } = req.body || {};
  if (workspaceRoot) {
    codingAgentCore.setWorkspaceRoot(workspaceRoot);
  }
  if (modelConfig) {
    codingAgentCore.updateModelConfig(modelConfig);
  }
  return res.json({
    success: true,
    config: {
      workspaceRoot: codingAgentCore.getWorkspaceRoot(),
    },
  });
});

// 6. GET /api/agent/config - Get current configuration
app.get('/api/agent/config', (_req, res) => {
  return res.json({
    success: true,
    config: {
      workspaceRoot: codingAgentCore.getWorkspaceRoot(),
    },
  });
});

// 7. POST /api/agent/tools/execute - Direct single-tool execution within workspace (Auth required)
app.post('/api/agent/tools/execute', async (req, res) => {
  try {
    const { toolName, args = {}, approvalId } = req.body || {};
    if (!toolName) {
      return res.status(400).json({ success: false, error: 'toolName is required.' });
    }

    const workspaceRoot = codingAgentCore.getWorkspaceRoot();
    const evalSec = agentPermissionGuard.evaluateToolCall(toolName, args, workspaceRoot);

    if (evalSec.isBlocked) {
      agentPermissionGuard.logSecurityEvent({
        action: 'BLOCKED_VIOLATION',
        toolName,
        details: evalSec.reason,
        level: 'BLOCKED',
        taskId: 'api_tools_execute',
      });
      return res.status(403).json({
        success: false,
        blocked: true,
        error: `SECURITY GATE BLOCKED: ${evalSec.reason}`,
      });
    }

    if (evalSec.needsApproval) {
      if (approvalId) {
        const consumed = agentPermissionGuard.validateAndConsumeApproval(approvalId, toolName, args);
        if (!consumed.valid) {
          return res.status(403).json({
            success: false,
            error: `APPROVAL_REJECTED: ${consumed.error}`,
          });
        }
      } else {
        const pending = agentPermissionGuard.createPendingApproval(
          'api_tools_execute',
          toolName,
          args,
          evalSec.level as any,
          evalSec.reason,
          evalSec.warning
        );
        return res.status(202).json({
          success: false,
          status: 'APPROVAL_REQUIRED',
          pendingApproval: pending,
          message: `Tool '${toolName}' requires user approval. Approve via POST /api/agent/approvals/${pending.id}/respond`,
        });
      }
    }

    const toolExecutor = new AgentToolExecutor({
      workspaceRoot,
      commandTimeoutMs: 20000,
      maxOutputChars: 60000,
      autoApprove: true,
    });

    const result = await toolExecutor.executeTool(toolName, args);
    return res.json({ success: result.success, result });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || String(err) });
  }
});

// 8. GET /api/agent/approvals - List pending approval requests
app.get('/api/agent/approvals', (_req, res) => {
  const pending = agentPermissionGuard.getPendingApprovals();
  return res.json({ success: true, pending });
});

// 9. POST /api/agent/approvals/:id/respond - User approve or deny request (Requires user credential)
app.post('/api/agent/approvals/:id/respond', AgentAuthManager.requireUserApprovalMiddleware, (req, res) => {
  const { id } = req.params;
  const { approve = false, actor = 'user' } = req.body || {};
  const resolved = agentPermissionGuard.resolveApproval(id, Boolean(approve), actor);

  return res.json({
    success: resolved,
    message: resolved
      ? `Approval ${id} has been ${approve ? 'APPROVED' : 'DENIED'}.`
      : `Pending approval ${id} not found or already resolved.`,
  });
});

// 10. GET /api/agent/security/logs - Security and permission audit log
app.get('/api/agent/security/logs', (_req, res) => {
  const logs = agentPermissionGuard.getSecurityLogs();
  return res.json({ success: true, logs });
});

// ==========================================
// PHASE 3: TERMINAL MANAGEMENT ENDPOINTS
// ==========================================

// 11. POST /api/agent/terminal/execute - Execute command with persistent CWD and history
app.post('/api/agent/terminal/execute', async (req, res) => {
  try {
    const { command, customCwd, approvalId } = req.body || {};
    if (!command || typeof command !== 'string') {
      return res.status(400).json({ success: false, error: 'Command string is required.' });
    }

    const workspaceRoot = terminalManager.getWorkspaceRoot();
    const evalSec = agentPermissionGuard.inspectCommand(command, workspaceRoot);

    if (evalSec.isBlocked) {
      agentPermissionGuard.logSecurityEvent({
        action: 'BLOCKED_VIOLATION',
        toolName: 'run_command',
        details: `${evalSec.reason}: ${command}`,
        level: 'BLOCKED',
        taskId: 'api_terminal_execute',
      });
      return res.status(403).json({
        success: false,
        blocked: true,
        error: `SECURITY GATE BLOCKED: ${evalSec.reason}`,
      });
    }

    if (evalSec.level === 'ASK_APPROVAL' || evalSec.level === 'STRICT_APPROVAL_WITH_WARNING') {
      if (approvalId) {
        const consumed = agentPermissionGuard.validateAndConsumeApproval(approvalId, 'run_command', { command });
        if (!consumed.valid) {
          return res.status(403).json({
            success: false,
            error: `APPROVAL_REJECTED: ${consumed.error}`,
          });
        }
      } else {
        const pending = agentPermissionGuard.createPendingApproval(
          'api_terminal_execute',
          'run_command',
          { command },
          evalSec.level as any,
          evalSec.reason,
          evalSec.warningDetails
        );
        return res.status(202).json({
          success: false,
          status: 'APPROVAL_REQUIRED',
          pendingApproval: pending,
          message: `Command requires user approval before execution. Approve via POST /api/agent/approvals/${pending.id}/respond`,
        });
      }
    }

    const result = await terminalManager.executeCommand(command, { customCwd, bypassPermissionCheck: true });
    return res.json({ success: true, result });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || String(err) });
  }
});

// 12. GET /api/agent/terminal/history - Command execution history
app.get('/api/agent/terminal/history', (req, res) => {
  const limit = req.query.limit ? parseInt(String(req.query.limit), 10) : 50;
  const history = terminalManager.getHistory(limit);
  return res.json({ success: true, history });
});

// 13. POST /api/agent/terminal/clear - Clear terminal command history
app.post('/api/agent/terminal/clear', (_req, res) => {
  terminalManager.clearHistory();
  return res.json({ success: true, message: 'Terminal history cleared.' });
});

// 14. GET /api/agent/terminal/cwd - Get current persistent CWD
app.get('/api/agent/terminal/cwd', (_req, res) => {
  return res.json({
    success: true,
    cwd: terminalManager.getCwd(),
    relativeCwd: terminalManager.getRelativeCwd(),
    workspaceRoot: terminalManager.getWorkspaceRoot(),
  });
});

// ==========================================
// PHASE 3: PROJECT FILE & DIFF ENDPOINTS
// ==========================================

// 15. GET /api/agent/files/tree - Recursive workspace file tree
app.get('/api/agent/files/tree', (req, res) => {
  try {
    const subDir = typeof req.query.subDir === 'string' ? req.query.subDir : '';
    const depth = req.query.depth ? parseInt(String(req.query.depth), 10) : 6;
    const tree = fileManager.getFileTree(subDir, depth);
    return res.json({ success: true, tree });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message || String(err) });
  }
});

// 16. GET /api/agent/files/read - Read workspace file content
app.get('/api/agent/files/read', (req, res) => {
  try {
    const filePath = typeof req.query.path === 'string' ? req.query.path : '';
    if (!filePath) {
      return res.status(400).json({ success: false, error: 'Path query param is required.' });
    }
    const file = fileManager.readFile(filePath);
    return res.json({ success: true, file });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message || String(err) });
  }
});

// 17. POST /api/agent/files/write - Write file and record unified diff
app.post('/api/agent/files/write', async (req, res) => {
  try {
    const { path: filePath, content, approvalId } = req.body || {};
    if (!filePath || typeof filePath !== 'string') {
      return res.status(400).json({ success: false, error: 'Path string is required.' });
    }
    if (content === undefined || typeof content !== 'string') {
      return res.status(400).json({ success: false, error: 'Content string is required.' });
    }

    const workspaceRoot = fileManager.getWorkspaceRoot();
    const evalSec = agentPermissionGuard.evaluateToolCall('write_file', { path: filePath, content }, workspaceRoot);

    if (evalSec.isBlocked) {
      return res.status(403).json({ success: false, blocked: true, error: `SECURITY GATE BLOCKED: ${evalSec.reason}` });
    }

    if (evalSec.needsApproval) {
      if (approvalId) {
        const consumed = agentPermissionGuard.validateAndConsumeApproval(approvalId, 'write_file', { path: filePath, content });
        if (!consumed.valid) {
          return res.status(403).json({
            success: false,
            error: `APPROVAL_REJECTED: ${consumed.error}`,
          });
        }
      } else {
        const pending = agentPermissionGuard.createPendingApproval(
          'api_files_write',
          'write_file',
          { path: filePath, content },
          evalSec.level as any,
          evalSec.reason,
          evalSec.warning
        );
        return res.status(202).json({
          success: false,
          status: 'APPROVAL_REQUIRED',
          pendingApproval: pending,
          message: `Writing to '${filePath}' requires user approval. Approve via POST /api/agent/approvals/${pending.id}/respond`,
        });
      }
    }

    const result = await fileManager.writeFile(filePath, content, { bypassPermission: true });
    return res.json({ success: true, result });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message || String(err) });
  }
});

// 18. DELETE /api/agent/files/delete - Delete file or folder inside workspace
app.delete('/api/agent/files/delete', async (req, res) => {
  try {
    const filePath = typeof req.query.path === 'string' ? req.query.path : (req.body?.path as string);
    const approvalId = typeof req.query.approvalId === 'string' ? req.query.approvalId : (req.body?.approvalId as string);
    if (!filePath) {
      return res.status(400).json({ success: false, error: 'Path is required.' });
    }
    const recursive = req.query.recursive === 'true' || Boolean(req.body?.recursive);

    const workspaceRoot = fileManager.getWorkspaceRoot();
    const evalSec = agentPermissionGuard.evaluateToolCall(
      'delete_file',
      { path: filePath, recursive },
      workspaceRoot
    );

    if (evalSec.isBlocked) {
      return res.status(403).json({ success: false, blocked: true, error: `SECURITY GATE BLOCKED: ${evalSec.reason}` });
    }

    if (evalSec.needsApproval) {
      if (approvalId) {
        const consumed = agentPermissionGuard.validateAndConsumeApproval(approvalId, 'delete_file', { path: filePath, recursive });
        if (!consumed.valid) {
          return res.status(403).json({
            success: false,
            error: `APPROVAL_REJECTED: ${consumed.error}`,
          });
        }
      } else {
        const pending = agentPermissionGuard.createPendingApproval(
          'api_files_delete',
          'delete_file',
          { path: filePath, recursive },
          'STRICT_APPROVAL_WITH_WARNING',
          `Deleting '${filePath}' requires explicit user approval.`,
          'WARNING: Irreversible deletion.'
        );
        return res.status(202).json({
          success: false,
          status: 'APPROVAL_REQUIRED',
          pendingApproval: pending,
          message: `Deleting '${filePath}' requires user approval. Approve via POST /api/agent/approvals/${pending.id}/respond`,
        });
      }
    }

    const result = await fileManager.deletePath(filePath, { recursive, bypassPermission: true });
    return res.json({ success: true, result });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message || String(err) });
  }
});

// 19. GET /api/agent/files/diff - Get unified diff of file against baseline
app.get('/api/agent/files/diff', (req, res) => {
  try {
    const filePath = typeof req.query.path === 'string' ? req.query.path : '';
    if (!filePath) {
      return res.status(400).json({ success: false, error: 'Path query param is required.' });
    }
    const diff = fileManager.getFileDiff(filePath);
    return res.json({ success: true, diff, path: filePath });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message || String(err) });
  }
});

// 20. GET /api/agent/files/changes - Tracked modified/created files
app.get('/api/agent/files/changes', (_req, res) => {
  const changes = fileManager.getChangedFiles();
  const history = fileManager.getChangeHistory();
  return res.json({ success: true, changes, history });
});

// 21. POST /api/agent/files/revert - Revert file to previous change snapshot
app.post('/api/agent/files/revert', async (req, res) => {
  try {
    const { path: filePath, approvalId } = req.body || {};
    if (!filePath) {
      return res.status(400).json({ success: false, error: 'Path is required.' });
    }

    const workspaceRoot = fileManager.getWorkspaceRoot();
    const evalSec = agentPermissionGuard.evaluateToolCall(
      'write_file',
      { path: filePath, action: 'revert' },
      workspaceRoot
    );

    if (evalSec.needsApproval) {
      if (approvalId) {
        const consumed = agentPermissionGuard.validateAndConsumeApproval(approvalId, 'write_file', { path: filePath, action: 'revert' });
        if (!consumed.valid) {
          return res.status(403).json({
            success: false,
            error: `APPROVAL_REJECTED: ${consumed.error}`,
          });
        }
      } else {
        const pending = agentPermissionGuard.createPendingApproval(
          'api_files_revert',
          'write_file',
          { path: filePath, action: 'revert' },
          'ASK_APPROVAL',
          `Reverting '${filePath}' to previous snapshot modifies file content.`,
          'Warning: Current edits will be replaced with previous snapshot.'
        );
        return res.status(202).json({
          success: false,
          status: 'APPROVAL_REQUIRED',
          pendingApproval: pending,
          message: `Reverting '${filePath}' requires user approval. Approve via POST /api/agent/approvals/${pending.id}/respond`,
        });
      }
    }

    const success = await fileManager.revertFile(filePath);
    return res.json({ success, message: `Reverted ${filePath} to previous version.` });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message || String(err) });
  }
});

// ==========================================
// PHASE 4: SKILLS ENGINE API ENDPOINTS
// ==========================================

// 22. GET /api/agent/skills - List all installed/quarantined skills
app.get('/api/agent/skills', (_req, res) => {
  const skills = skillsEngine.listSkills();
  return res.json({ success: true, skills });
});

// 23. POST /api/agent/skills/import/folder - Import skill from local directory into quarantine
app.post('/api/agent/skills/import/folder', (req, res) => {
  try {
    const { folderPath } = req.body || {};
    if (!folderPath || typeof folderPath !== 'string') {
      return res.status(400).json({ success: false, error: 'folderPath string is required.' });
    }
    const result = skillsEngine.importFromFolder(folderPath);
    return res.json({ success: true, ...result });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message || String(err) });
  }
});

// 24. POST /api/agent/skills/import/zip - Import skill from zip buffer/file
app.post('/api/agent/skills/import/zip', async (req, res) => {
  try {
    const { zipBase64, zipPath } = req.body || {};
    let target: Buffer | string;
    if (zipPath && typeof zipPath === 'string') {
      target = zipPath;
    } else if (zipBase64 && typeof zipBase64 === 'string') {
      target = Buffer.from(zipBase64, 'base64');
    } else {
      return res.status(400).json({ success: false, error: 'Either zipPath or zipBase64 is required.' });
    }
    const result = await skillsEngine.importFromZip(target);
    return res.json({ success: true, ...result });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message || String(err) });
  }
});

// 25. POST /api/agent/skills/import/git - Import skill from GitHub repository
app.post('/api/agent/skills/import/git', async (req, res) => {
  try {
    const { repoUrl, subPath, subpath } = req.body || {};
    if (!repoUrl || typeof repoUrl !== 'string') {
      return res.status(400).json({ success: false, error: 'repoUrl is required.' });
    }
    const result = await skillsEngine.importFromGit(repoUrl, subPath || subpath);
    return res.json({ success: true, ...result });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message || String(err) });
  }
});

// 26. GET /api/agent/skills/scan/:quarantineId - Security and dependency report
app.get('/api/agent/skills/scan/:quarantineId', (req, res) => {
  try {
    const scan = skillsEngine.scanQuarantineSkill(req.params.quarantineId);
    return res.json({ success: true, scan });
  } catch (err: any) {
    return res.status(404).json({ success: false, error: err.message || String(err) });
  }
});

// 27. POST /api/agent/skills/install/:quarantineId - Install quarantined skill (checks high risk approval)
app.post('/api/agent/skills/install/:quarantineId', (req, res) => {
  try {
    const { userApprovalSecret, forceApproveHighRisk } = req.body || {};
    const meta = skillsEngine.installSkill(req.params.quarantineId, {
      userApprovalSecret,
      forceApproveHighRisk: Boolean(forceApproveHighRisk),
    });
    return res.json({ success: true, skill: meta });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message || String(err) });
  }
});

// 28. POST /api/agent/skills/:id/enable - Enable skill
app.post('/api/agent/skills/:id/enable', (req, res) => {
  try {
    const meta = skillsEngine.enableSkill(req.params.id);
    return res.json({ success: true, skill: meta });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message || String(err) });
  }
});

// 29. POST /api/agent/skills/:id/disable - Disable skill
app.post('/api/agent/skills/:id/disable', (req, res) => {
  try {
    const meta = skillsEngine.disableSkill(req.params.id);
    return res.json({ success: true, skill: meta });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message || String(err) });
  }
});

// 30. DELETE /api/agent/skills/:id - Delete skill and remove all files
app.delete('/api/agent/skills/:id', (req, res) => {
  try {
    const removed = skillsEngine.removeSkill(req.params.id);
    return res.json({ success: removed, message: `Skill ${req.params.id} permanently removed.` });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message || String(err) });
  }
});

// 30b. GET /api/agent/skills/:id/diff/:quarantineId - Unified diff of skill update
app.get('/api/agent/skills/:id/diff/:quarantineId', (req, res) => {
  try {
    const diffData = skillsEngine.getSkillUpdateDiff(req.params.id, req.params.quarantineId);
    return res.json({ success: true, ...diffData });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message || String(err) });
  }
});

// 31. POST /api/agent/skills/:id/update - Update skill from new quarantine version
app.post('/api/agent/skills/:id/update', (req, res) => {
  try {
    const { newQuarantineId, forceApproveHighRisk, userApproved, approved } = req.body || {};
    if (!newQuarantineId) {
      return res.status(400).json({ success: false, error: 'newQuarantineId is required.' });
    }
    const result = skillsEngine.updateSkill(req.params.id, newQuarantineId, {
      userApproved: Boolean(userApproved ?? approved ?? true),
      forceApproveHighRisk: Boolean(forceApproveHighRisk),
    });
    return res.json({ success: true, ...result });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message || String(err) });
  }
});

// 32. POST /api/agent/skills/auto-select - Select relevant enabled skills for task
app.post('/api/agent/skills/auto-select', (req, res) => {
  try {
    const { prompt } = req.body || {};
    const matches = skillsEngine.selectSkillsForTask(prompt || '');
    return res.json({ success: true, matches });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message || String(err) });
  }
});

// 33. POST /api/agent/skills/:id/run - Execute a skill script under appuser isolation
app.post('/api/agent/skills/:id/run', (req, res) => {
  try {
    const { scriptPath, args = [], approvalId } = req.body || {};
    if (!scriptPath) {
      return res.status(400).json({ success: false, error: 'scriptPath is required.' });
    }
    const skillId = req.params.id;
    const workspaceRoot = path.join(__dirname, 'workspace');

    // Security Gate: Check if script execution requires user approval
    const evalSec = agentPermissionGuard.evaluateToolCall(
      'run_skill_script',
      { skillId, scriptPath, args },
      workspaceRoot
    );

    if (evalSec.isBlocked) {
      return res.status(403).json({
        success: false,
        blocked: true,
        error: `SECURITY GATE BLOCKED: ${evalSec.reason}`,
      });
    }

    if (evalSec.level === 'ASK_APPROVAL' || evalSec.level === 'STRICT_APPROVAL_WITH_WARNING' || !approvalId) {
      if (approvalId) {
        const consumed = agentPermissionGuard.validateAndConsumeApproval(approvalId, 'run_skill_script', { skillId, scriptPath });
        if (!consumed.valid) {
          return res.status(403).json({
            success: false,
            error: `APPROVAL_REJECTED: ${consumed.error}`,
          });
        }
      } else {
        const pending = agentPermissionGuard.createPendingApproval(
          'api_skills_run',
          'run_skill_script',
          { skillId, scriptPath, args },
          evalSec.level as any,
          evalSec.reason || `Execute script '${scriptPath}' in skill '${skillId}'`,
          evalSec.warning
        );
        return res.status(202).json({
          success: false,
          status: 'APPROVAL_REQUIRED',
          pendingApproval: pending,
          message: `Running skill script '${scriptPath}' requires user approval. Approve via POST /api/agent/approvals/${pending.id}/respond`,
        });
      }
    }

    const result = skillsEngine.executeSkillScript(skillId, scriptPath, args, workspaceRoot);
    return res.json({ success: result.exitCode === 0, result });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message || String(err) });
  }
});

// ==========================================
// PHASE 5: MCP (MODEL CONTEXT PROTOCOL) ROUTES
// ==========================================

// 34. GET /api/agent/mcp/servers - List configured MCP servers
app.get('/api/agent/mcp/servers', (_req, res) => {
  try {
    const servers = mcpClientManager.listServers();
    return res.json({ success: true, servers });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || String(err) });
  }
});

// 35. POST /api/agent/mcp/servers - Register new MCP server (Requires approval)
app.post('/api/agent/mcp/servers', (req, res) => {
  try {
    const { name, transport, command, args, cwd, env, allowNetwork, url, headers, allowLocalhost, autoAllowTools, approved } = req.body || {};
    const server = mcpClientManager.addServer(
      {
        name,
        transport,
        command,
        args,
        cwd,
        env,
        allowNetwork,
        url,
        headers,
        allowLocalhost,
        autoAllowTools,
      },
      { userApproved: Boolean(approved) }
    );
    return res.status(201).json({ success: true, server });
  } catch (err: any) {
    const status = err.message.includes('approval') ? 403 : 400;
    return res.status(status).json({ success: false, error: err.message || String(err) });
  }
});

// 36. PUT /api/agent/mcp/servers/:id - Update MCP server configuration
app.put('/api/agent/mcp/servers/:id', (req, res) => {
  try {
    const { approved, ...patch } = req.body || {};
    const updated = mcpClientManager.editServer(req.params.id, patch, { userApproved: Boolean(approved) });
    return res.json({ success: true, server: updated });
  } catch (err: any) {
    const status = err.message.includes('approval') ? 403 : 400;
    return res.status(status).json({ success: false, error: err.message || String(err) });
  }
});

// 37. DELETE /api/agent/mcp/servers/:id - Remove MCP server and terminate process
app.delete('/api/agent/mcp/servers/:id', async (req, res) => {
  try {
    const removed = await mcpClientManager.removeServer(req.params.id);
    return res.json({ success: removed, message: `MCP Server ${req.params.id} removed.` });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message || String(err) });
  }
});

// 38. POST /api/agent/mcp/servers/:id/connect - Connect to server and perform handshake
app.post('/api/agent/mcp/servers/:id/connect', async (req, res) => {
  try {
    const { approved } = req.body || {};
    const tools = await mcpClientManager.connectServer(req.params.id, { userApproved: Boolean(approved) });
    return res.json({ success: true, toolsCount: tools.length, tools });
  } catch (err: any) {
    const status = err.message.includes('approval') ? 403 : 500;
    return res.status(status).json({ success: false, error: err.message || String(err) });
  }
});

// 39. POST /api/agent/mcp/servers/:id/disconnect - Disconnect server and kill process
app.post('/api/agent/mcp/servers/:id/disconnect', async (req, res) => {
  try {
    await mcpClientManager.disconnectServer(req.params.id);
    return res.json({ success: true, message: `MCP Server ${req.params.id} disconnected.` });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message || String(err) });
  }
});

// 40. GET /api/agent/mcp/servers/:id/tools - List discovered tools for server
app.get('/api/agent/mcp/servers/:id/tools', (req, res) => {
  try {
    const tools = mcpClientManager.getDiscoveredTools(req.params.id);
    return res.json({ success: true, tools });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message || String(err) });
  }
});

// 41. GET /api/agent/mcp/tools - List all discovered tools across connected servers
app.get('/api/agent/mcp/tools', (_req, res) => {
  try {
    const tools = mcpClientManager.getDiscoveredTools();
    return res.json({ success: true, tools });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || String(err) });
  }
});

// 42. POST /api/agent/mcp/tools/call - Execute an MCP tool (Strict user approval required)
app.post('/api/agent/mcp/tools/call', async (req, res) => {
  try {
    const { serverId, toolName, arguments: toolArgs, timeoutMs, maxOutputChars, approvalId } = req.body || {};
    if (!serverId || !toolName) {
      return res.status(400).json({ success: false, error: 'serverId and toolName are required.' });
    }

    // Security Gate: Check if this tool is in autoAllow or has valid consumed approval
    const server = mcpClientManager.getServer(serverId);
    const isAutoAllowed = (server?.autoAllowTools || []).includes(toolName);

    let approvalGranted = false;
    if (isAutoAllowed) {
      approvalGranted = true;
    } else if (approvalId) {
      const consumed = agentPermissionGuard.validateAndConsumeApproval(approvalId, 'mcp_tool_call', { serverId, toolName, args: toolArgs });
      if (!consumed.valid) {
        return res.status(403).json({
          success: false,
          error: `APPROVAL_REJECTED: ${consumed.error}`,
        });
      }
      approvalGranted = true;
    } else {
      // Create pending approval requiring real user cookie approval
      const pending = agentPermissionGuard.createPendingApproval(
        'api_mcp_call',
        'mcp_tool_call',
        { serverId, toolName, args: toolArgs },
        'ASK_APPROVAL',
        `Call MCP tool '${toolName}' on server '${server?.name || serverId}'`,
        'MCP tool executions can interact with external system resources'
      );
      return res.status(202).json({
        success: false,
        status: 'APPROVAL_REQUIRED',
        pendingApproval: pending,
        message: `Executing MCP tool '${toolName}' requires user approval. Approve via POST /api/agent/approvals/${pending.id}/respond`,
      });
    }

    const result = await mcpClientManager.callTool(serverId, toolName, toolArgs || {}, {
      timeoutMs,
      maxOutputChars,
      approvalGranted,
    });

    const status = result.success ? 200 : result.error?.includes('APPROVAL') ? 403 : 400;
    return res.status(status).json({ success: result.success, result });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || String(err) });
  }
});

// 43. GET /api/agent/mcp/logs - Fetch MCP audit logs
app.get('/api/agent/mcp/logs', (req, res) => {
  try {
    const limit = parseInt(String(req.query.limit || '100'), 10) || 100;
    const logs = mcpClientManager.getAuditLogs(limit);
    return res.json({ success: true, logs });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || String(err) });
  }
});

// Project Export Endpoints (Full Project ZIP System -> Zoya_AI_Companion_Full_Project.zip)
const PROJECT_EXPORT_FILENAME = 'Zoya_AI_Companion_Full_Project.zip';
const PROJECT_EXPORT_TMP_DIR = path.join(os.tmpdir(), 'zoya_project_exports');

const PROJECT_EXCLUDED_DIRS = new Set([
  'node_modules',
  '.git',
  'dist',
  'build',
  'coverage',
  '.aistudio',
  '.cache',
  '__pycache__',
  '.pytest_cache',
  '.gradle',
  '.idea',
  '.vite',
]);

function isExcludedProjectPath(relPath: string): boolean {
  const normalized = relPath.replace(/\\/g, '/');
  const parts = normalized.split('/');
  for (const part of parts) {
    if (PROJECT_EXCLUDED_DIRS.has(part)) return true;
  }
  const baseName = parts[parts.length - 1] || '';
  if (
    baseName === '.DS_Store' ||
    baseName === 'server.js' ||
    baseName === 'local.properties' ||
    baseName.endsWith('.log') ||
    baseName.endsWith('.pem') ||
    baseName.endsWith('.key') ||
    baseName.endsWith('.keystore') ||
    baseName.endsWith('.jks')
  ) {
    return true;
  }
  if (baseName.startsWith('.env') && baseName !== '.env.example') return true;
  if (
    normalized === 'data/elevenlabs_config.json' ||
    normalized === 'data/youtube_config.json' ||
    normalized === 'data/auth_token.json' ||
    normalized === 'data/user_secret.json' ||
    normalized === 'data/love_mode_entries.json' ||
    /^data\/secrets/i.test(normalized) ||
    /^data\/[^/]+_config\.json$/.test(normalized)
  ) {
    return true;
  }
  return false;
}

function collectProjectFiles(
  rootDir: string,
  currentDir: string,
  out: Array<{ path: string; size: number }>
) {
  const entries = fs.readdirSync(currentDir, { withFileTypes: true });
  for (const entry of entries) {
    if (entry.isSymbolicLink()) continue;
    const fullPath = path.join(currentDir, entry.name);
    const relPath = path.relative(rootDir, fullPath).split(path.sep).join('/');
    if (!relPath || isExcludedProjectPath(relPath)) continue;
    if (entry.isDirectory()) {
      collectProjectFiles(rootDir, fullPath, out);
    } else if (entry.isFile()) {
      try {
        const stat = fs.statSync(fullPath);
        out.push({ path: relPath, size: stat.size });
      } catch {
        // Skip unreadable files
      }
    }
  }
}

const ALREADY_COMPRESSED_EXTS = new Set([
  'png', 'jpg', 'jpeg', 'webp', 'gif', 'mp4', 'mov', 'zip',
  'gz', 'onnx', 'wav', 'mp3', 'pdf', 'xlsx', 'woff', 'woff2',
  'apk', 'jar', 'br', '7z',
]);

function isAlreadyCompressedExt(filePath: string): boolean {
  const dot = filePath.lastIndexOf('.');
  return dot !== -1 && ALREADY_COMPRESSED_EXTS.has(filePath.slice(dot + 1).toLowerCase());
}

type ProjectExportPhase = 'preparing' | 'archiving' | 'ready' | 'failed';

interface ProjectExportJob {
  jobId: string;
  phase: ProjectExportPhase;
  totalFiles: number;
  processedFiles: number;
  totalBytes: number;
  archivePercent: number;
  zipSizeBytes: number;
  zipPath: string;
  verified: boolean;
  error: string | null;
  createdAt: number;
  updatedAt: number;
}

const projectExportJobs = new Map<string, ProjectExportJob>();

function cleanupExpiredProjectExports(keepJobId?: string) {
  const now = Date.now();
  const maxAgeMs = 10 * 60 * 1000;
  for (const [id, job] of projectExportJobs.entries()) {
    if (id === keepJobId) continue;
    if (job.phase !== 'preparing' && job.phase !== 'archiving' && now - job.updatedAt > maxAgeMs) {
      try {
        if (fs.existsSync(job.zipPath)) fs.unlinkSync(job.zipPath);
        if (fs.existsSync(`${job.zipPath}.part`)) fs.unlinkSync(`${job.zipPath}.part`);
      } catch {}
      projectExportJobs.delete(id);
    }
  }
  const readyJobs = Array.from(projectExportJobs.values())
    .filter((j) => j.phase === 'ready' && j.jobId !== keepJobId)
    .sort((a, b) => b.createdAt - a.createdAt);
  // Keep at most 1 ready ZIP in RAM-backed tmpfs to prevent container OOM
  for (const oldJob of readyJobs) {
    if (keepJobId || readyJobs.indexOf(oldJob) >= 1) {
      try {
        if (fs.existsSync(oldJob.zipPath)) fs.unlinkSync(oldJob.zipPath);
        if (fs.existsSync(`${oldJob.zipPath}.part`)) fs.unlinkSync(`${oldJob.zipPath}.part`);
      } catch {}
      projectExportJobs.delete(oldJob.jobId);
    }
  }

  // Also purge any orphaned ZIPs left on disk across server restarts
  try {
    if (fs.existsSync(PROJECT_EXPORT_TMP_DIR)) {
      const trackedFiles = new Set<string>();
      for (const job of projectExportJobs.values()) {
        trackedFiles.add(path.basename(job.zipPath));
        trackedFiles.add(`${path.basename(job.zipPath)}.part`);
      }
      for (const entry of fs.readdirSync(PROJECT_EXPORT_TMP_DIR)) {
        if (!trackedFiles.has(entry)) {
          try {
            fs.unlinkSync(path.join(PROJECT_EXPORT_TMP_DIR, entry));
          } catch {}
        }
      }
    }
  } catch {}
}

function verifyZipFileIntegrity(zipPath: string): { valid: boolean; size: number; eocdEntryCount: number; error?: string } {
  const stat = fs.statSync(zipPath);
  if (!stat.isFile() || stat.size < 22) {
    return { valid: false, size: stat.size, eocdEntryCount: 0, error: 'Generated ZIP file is empty or truncated.' };
  }
  const fd = fs.openSync(zipPath, 'r');
  try {
    const header = Buffer.allocUnsafe(4);
    fs.readSync(fd, header, 0, 4, 0);
    if (header[0] !== 0x50 || header[1] !== 0x4b || header[2] !== 0x03 || header[3] !== 0x04) {
      return { valid: false, size: stat.size, eocdEntryCount: 0, error: 'Invalid ZIP local file header signature.' };
    }

    const tailLen = Math.min(stat.size, 65558);
    const tailOffset = stat.size - tailLen;
    const tailBuf = Buffer.allocUnsafe(tailLen);
    fs.readSync(fd, tailBuf, 0, tailLen, tailOffset);

    let eocdPos = -1;
    for (let i = tailLen - 22; i >= 0; i--) {
      if (
        tailBuf[i] === 0x50 &&
        tailBuf[i + 1] === 0x4b &&
        tailBuf[i + 2] === 0x05 &&
        tailBuf[i + 3] === 0x06
      ) {
        eocdPos = i;
        break;
      }
    }
    if (eocdPos === -1) {
      return { valid: false, size: stat.size, eocdEntryCount: 0, error: 'Missing ZIP End-of-Central-Directory record.' };
    }
    const eocdEntryCount = tailBuf.readUInt16LE(eocdPos + 10);
    if (eocdEntryCount === 0) {
      return { valid: false, size: stat.size, eocdEntryCount: 0, error: 'Generated ZIP contains zero entries.' };
    }
    return { valid: true, size: stat.size, eocdEntryCount };
  } finally {
    fs.closeSync(fd);
  }
}

async function buildZipViaPythonStreaming(
  rootResolved: string,
  tempWritePath: string,
  files: Array<{ path: string; size: number }>,
  job: ProjectExportJob
): Promise<boolean> {
  const pyScript = [
    'import json, os, sys, zipfile',
    'root_dir = sys.argv[1]',
    'out_path = sys.argv[2]',
    'stored_exts = set(sys.argv[3].split(","))',
    'entries = json.loads(sys.stdin.read())',
    'total = len(entries)',
    'with zipfile.ZipFile(out_path, "w", allowZip64=True) as zf:',
    '    for idx, rel in enumerate(entries, 1):',
    '        abs_p = os.path.join(root_dir, rel)',
    '        ext = rel.rsplit(".", 1)[-1].lower() if "." in rel else ""',
    '        comp = zipfile.ZIP_STORED if ext in stored_exts else zipfile.ZIP_DEFLATED',
    '        if comp == zipfile.ZIP_DEFLATED:',
    '            zf.write(abs_p, arcname=rel, compress_type=comp, compresslevel=1)',
    '        else:',
    '            zf.write(abs_p, arcname=rel, compress_type=comp)',
    '        if idx % 50 == 0 or idx == total:',
    '            print(f"PROGRESS {idx}/{total}", flush=True)',
  ].join('\n');

  return await new Promise<boolean>((resolve) => {
    let settled = false;
    const finish = (ok: boolean) => {
      if (settled) return;
      settled = true;
      resolve(ok);
    };

    try {
      const child = spawn(
        'python3',
        ['-c', pyScript, rootResolved, tempWritePath, Array.from(ALREADY_COMPRESSED_EXTS).join(',')],
        { stdio: ['pipe', 'pipe', 'pipe'] }
      );

      let stderrBuf = '';
      child.stdout.on('data', (chunk: Buffer) => {
        const lines = chunk.toString('utf8').split('\n');
        for (const line of lines) {
          const m = /^PROGRESS\s+(\d+)\/(\d+)/.exec(line.trim());
          if (m) {
            const done = Number(m[1]);
            const total = Math.max(1, Number(m[2]));
            job.processedFiles = done;
            job.archivePercent = Math.min(99, Math.round((done / total) * 99));
            job.updatedAt = Date.now();
          }
        }
      });

      child.stderr.on('data', (chunk: Buffer) => {
        if (stderrBuf.length < 2000) stderrBuf += chunk.toString('utf8');
      });

      child.on('error', () => {
        finish(false);
      });

      child.on('close', (code) => {
        if (code === 0 && fs.existsSync(tempWritePath)) {
          finish(true);
        } else {
          if (stderrBuf) {
            console.warn('[PROJECT_EXPORT] Python streaming ZIP fallback triggered:', stderrBuf.trim());
          }
          finish(false);
        }
      });

      child.stdin.write(JSON.stringify(files.map((f) => f.path)));
      child.stdin.end();
    } catch {
      finish(false);
    }
  });
}

async function buildProjectExportJob(job: ProjectExportJob): Promise<void> {
  try {
    fs.mkdirSync(PROJECT_EXPORT_TMP_DIR, { recursive: true });
    cleanupExpiredProjectExports(job.jobId);

    job.phase = 'preparing';
    job.updatedAt = Date.now();

    const files: Array<{ path: string; size: number }> = [];
    collectProjectFiles(__dirname, __dirname, files);
    files.sort((a, b) => a.path.localeCompare(b.path));
    if (files.length === 0) {
      throw new Error('No project files found to archive.');
    }

    job.totalFiles = files.length;
    job.totalBytes = files.reduce((sum, f) => sum + f.size, 0);
    job.phase = 'archiving';
    job.updatedAt = Date.now();

    const rootResolved = path.resolve(__dirname);
    const tempWritePath = `${job.zipPath}.part`;

    const builtWithPython = await buildZipViaPythonStreaming(rootResolved, tempWritePath, files, job);

    if (!builtWithPython) {
      try {
        if (fs.existsSync(tempWritePath)) fs.unlinkSync(tempWritePath);
      } catch {}

      const zip = new JSZip();
      for (let i = 0; i < files.length; i++) {
        const f = files[i];
        const absPath = path.resolve(rootResolved, f.path);
        zip.file(f.path, fs.createReadStream(absPath), {
          compression: isAlreadyCompressedExt(f.path) ? 'STORE' : 'DEFLATE',
          compressionOptions: isAlreadyCompressedExt(f.path) ? undefined : { level: 1 },
        });
        job.processedFiles = i + 1;
        if ((i + 1) % 40 === 0 || i === files.length - 1) {
          job.archivePercent = Math.min(45, Math.round(((i + 1) / files.length) * 45));
          job.updatedAt = Date.now();
          await new Promise((r) => setImmediate(r));
        }
      }

      await new Promise<void>((resolve, reject) => {
        const outStream = fs.createWriteStream(tempWritePath);
        let settled = false;
        const fail = (err: any) => {
          if (settled) return;
          settled = true;
          reject(err);
        };
        outStream.on('error', fail);
        outStream.on('finish', () => {
          if (settled) return;
          settled = true;
          resolve();
        });

        const zipStream = zip.generateNodeStream(
          { type: 'nodebuffer', streamFiles: true },
          (metadata) => {
            job.archivePercent = Math.min(99, 45 + Math.round((metadata.percent / 100) * 54));
            job.updatedAt = Date.now();
          }
        );
        zipStream.on('error', fail);
        zipStream.pipe(outStream);
      });
    }

    fs.renameSync(tempWritePath, job.zipPath);

    const check = verifyZipFileIntegrity(job.zipPath);
    if (!check.valid) {
      throw new Error(check.error || 'ZIP integrity check failed.');
    }

    job.zipSizeBytes = check.size;
    job.archivePercent = 100;
    job.verified = true;
    job.phase = 'ready';
    job.updatedAt = Date.now();
  } catch (err: any) {
    try {
      if (fs.existsSync(`${job.zipPath}.part`)) fs.unlinkSync(`${job.zipPath}.part`);
      if (fs.existsSync(job.zipPath)) fs.unlinkSync(job.zipPath);
    } catch {}
    job.phase = 'failed';
    job.verified = false;
    job.error = err?.message || 'Failed to build full project ZIP archive.';
    job.updatedAt = Date.now();
  }
}

function streamZipResponse(req: express.Request, res: express.Response, zipPath: string, totalSize: number) {
  res.setHeader('Content-Type', 'application/zip');
  res.setHeader(
    'Content-Disposition',
    `attachment; filename="${PROJECT_EXPORT_FILENAME}"; filename*=UTF-8''${encodeURIComponent(PROJECT_EXPORT_FILENAME)}`
  );
  res.setHeader('Accept-Ranges', 'bytes');
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Accel-Buffering', 'no');

  const rangeHeader = req.headers.range;
  if (rangeHeader) {
    const match = /^bytes=(\d*)-(\d*)$/.exec(String(rangeHeader).trim());
    if (!match) {
      res.setHeader('Content-Range', `bytes */${totalSize}`);
      return res.status(416).end();
    }
    const start = match[1] ? parseInt(match[1], 10) : 0;
    const end = match[2] ? Math.min(totalSize - 1, parseInt(match[2], 10)) : totalSize - 1;
    if (!Number.isFinite(start) || !Number.isFinite(end) || start < 0 || start > end || start >= totalSize) {
      res.setHeader('Content-Range', `bytes */${totalSize}`);
      return res.status(416).end();
    }
    res.status(206);
    res.setHeader('Content-Range', `bytes ${start}-${end}/${totalSize}`);
    res.setHeader('Content-Length', String(end - start + 1));
    if (req.method === 'HEAD') return res.end();
    return fs.createReadStream(zipPath, { start, end }).pipe(res);
  }

  res.status(200);
  res.setHeader('Content-Length', String(totalSize));
  if (req.method === 'HEAD') return res.end();
  return fs.createReadStream(zipPath).pipe(res);
}

app.post('/api/project/export/start', (_req, res) => {
  try {
    // Reuse an active in-progress job or a very recent verified ready job to avoid redundant 285MB tmpfs builds
    const activeJob = Array.from(projectExportJobs.values()).find(
      (j) => j.phase === 'preparing' || j.phase === 'archiving'
    );
    if (activeJob) {
      return res.status(202).json({
        success: true,
        jobId: activeJob.jobId,
        filename: PROJECT_EXPORT_FILENAME,
      });
    }

    const recentReadyJob = Array.from(projectExportJobs.values())
      .filter(
        (j) =>
          j.phase === 'ready' &&
          j.verified &&
          Date.now() - j.updatedAt < 60_000 &&
          fs.existsSync(j.zipPath)
      )
      .sort((a, b) => b.createdAt - a.createdAt)[0];
    if (recentReadyJob) {
      return res.status(202).json({
        success: true,
        jobId: recentReadyJob.jobId,
        filename: PROJECT_EXPORT_FILENAME,
      });
    }

    const jobId = `zoya_zip_${Date.now()}_${crypto.randomBytes(4).toString('hex')}`;
    const job: ProjectExportJob = {
      jobId,
      phase: 'preparing',
      totalFiles: 0,
      processedFiles: 0,
      totalBytes: 0,
      archivePercent: 0,
      zipSizeBytes: 0,
      zipPath: path.join(PROJECT_EXPORT_TMP_DIR, `${jobId}.zip`),
      verified: false,
      error: null,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };
    projectExportJobs.set(jobId, job);
    cleanupExpiredProjectExports(jobId);
    void buildProjectExportJob(job);

    return res.status(202).json({
      success: true,
      jobId,
      filename: PROJECT_EXPORT_FILENAME,
    });
  } catch (err: any) {
    return res.status(500).json({
      success: false,
      error: err?.message || 'Failed to start project ZIP export.',
    });
  }
});

app.get('/api/project/export/status/:jobId', (req, res) => {
  const job = projectExportJobs.get(req.params.jobId);
  if (!job) {
    return res.status(404).json({
      success: false,
      error: 'Export job not found or expired.',
    });
  }
  return res.json({
    success: job.phase !== 'failed',
    jobId: job.jobId,
    phase: job.phase,
    totalFiles: job.totalFiles,
    processedFiles: job.processedFiles,
    totalBytes: job.totalBytes,
    archivePercent: job.archivePercent,
    zipSizeBytes: job.zipSizeBytes,
    verified: job.verified,
    filename: PROJECT_EXPORT_FILENAME,
    error: job.error,
  });
});

app.get('/api/project/export/chunk/:jobId', async (req, res) => {
  const job = projectExportJobs.get(req.params.jobId);
  if (!job || job.phase !== 'ready' || !job.verified || !fs.existsSync(job.zipPath)) {
    return res.status(404).json({
      success: false,
      error: job?.error || 'Verified project ZIP is not ready.',
    });
  }
  const offsetRaw = Number(req.query.offset ?? 0);
  const lengthRaw = Number(req.query.length ?? 4 * 1024 * 1024);
  if (!Number.isFinite(offsetRaw) || offsetRaw < 0 || offsetRaw >= job.zipSizeBytes) {
    return res.status(400).json({ success: false, error: 'Invalid chunk offset.' });
  }
  const MAX_CHUNK = 10 * 1024 * 1024;
  const length = Math.max(1, Math.min(MAX_CHUNK, Math.floor(lengthRaw), job.zipSizeBytes - offsetRaw));
  const buf = Buffer.allocUnsafe(length);
  const fh = await fs.promises.open(job.zipPath, 'r');
  try {
    const { bytesRead } = await fh.read(buf, 0, length, offsetRaw);
    res.setHeader('Content-Type', 'application/octet-stream');
    res.setHeader('Cache-Control', 'no-store');
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Content-Length', String(bytesRead));
    return res.status(200).send(bytesRead === length ? buf : buf.subarray(0, bytesRead));
  } finally {
    await fh.close();
  }
});

app.get('/api/project/export/download/:jobId', (req, res) => {
  const job = projectExportJobs.get(req.params.jobId);
  if (!job || job.phase !== 'ready' || !job.verified || !fs.existsSync(job.zipPath)) {
    return res.status(404).json({
      success: false,
      error: job?.error || 'Verified project ZIP is not ready.',
    });
  }
  return streamZipResponse(req, res, job.zipPath, job.zipSizeBytes);
});

app.get('/api/project/download-zip', async (req, res) => {
  try {
    cleanupExpiredProjectExports();
    let readyJob = Array.from(projectExportJobs.values())
      .filter((j) => j.phase === 'ready' && j.verified && fs.existsSync(j.zipPath))
      .sort((a, b) => b.createdAt - a.createdAt)[0];

    if (!readyJob) {
      const jobId = `zoya_zip_${Date.now()}_${crypto.randomBytes(4).toString('hex')}`;
      readyJob = {
        jobId,
        phase: 'preparing',
        totalFiles: 0,
        processedFiles: 0,
        totalBytes: 0,
        archivePercent: 0,
        zipSizeBytes: 0,
        zipPath: path.join(PROJECT_EXPORT_TMP_DIR, `${jobId}.zip`),
        verified: false,
        error: null,
        createdAt: Date.now(),
        updatedAt: Date.now(),
      };
      projectExportJobs.set(jobId, readyJob);
      await buildProjectExportJob(readyJob);
    }

    if (readyJob.phase !== 'ready' || !readyJob.verified || !fs.existsSync(readyJob.zipPath)) {
      return res.status(500).json({
        success: false,
        error: readyJob.error || 'Failed to generate ZIP archive.',
      });
    }

    return streamZipResponse(req, res, readyJob.zipPath, readyJob.zipSizeBytes);
  } catch (err: any) {
    return res.status(500).json({
      success: false,
      error: err?.message || 'Failed to stream project ZIP.',
    });
  }
});

app.get('/api/project/manifest', (_req, res) => {
  try {
    const files: Array<{ path: string; size: number }> = [];
    collectProjectFiles(__dirname, __dirname, files);
    files.sort((a, b) => a.path.localeCompare(b.path));
    const totalBytes = files.reduce((sum, f) => sum + f.size, 0);
    return res.json({
      success: true,
      totalFiles: files.length,
      totalBytes,
      files,
    });
  } catch (err: any) {
    return res.status(500).json({
      success: false,
      error: err?.message || 'Failed to scan project files.',
    });
  }
});

app.post('/api/project/batch', (req, res) => {
  try {
    const paths = req.body?.paths;
    if (!Array.isArray(paths) || paths.length === 0) {
      return res.status(400).json({ success: false, error: 'paths array is required.' });
    }
    const rootResolved = path.resolve(__dirname);
    const rootWithSep = rootResolved.endsWith(path.sep) ? rootResolved : rootResolved + path.sep;
    const chunks: Buffer[] = [];

    for (const rawRel of paths) {
      if (typeof rawRel !== 'string' || !rawRel) continue;
      const absPath = path.resolve(rootResolved, rawRel);
      if (!absPath.startsWith(rootWithSep)) continue;
      const relNormalized = path.relative(rootResolved, absPath).split(path.sep).join('/');
      if (!relNormalized || isExcludedProjectPath(relNormalized)) continue;

      try {
        const lstat = fs.lstatSync(absPath);
        if (lstat.isSymbolicLink() || !lstat.isFile()) continue;
        const data = fs.readFileSync(absPath);
        const pathBuf = Buffer.from(relNormalized, 'utf8');
        const headerPathLen = Buffer.allocUnsafe(4);
        headerPathLen.writeUInt32BE(pathBuf.length, 0);
        const headerDataLen = Buffer.allocUnsafe(4);
        headerDataLen.writeUInt32BE(data.length, 0);
        chunks.push(headerPathLen, pathBuf, headerDataLen, data);
      } catch {
        // Skip unreadable file
      }
    }

    const payload = Buffer.concat(chunks);
    res.setHeader('Content-Type', 'application/octet-stream');
    return res.status(200).send(payload);
  } catch (err: any) {
    return res.status(500).json({
      success: false,
      error: err?.message || 'Failed to package project file batch.',
    });
  }
});

// Love Mode Reflection ("जो कभी किसी से नहीं कहा") Persistence Endpoints
const LOVE_MODE_ENTRIES_FILE = path.join(__dirname, 'data', 'love_mode_entries.json');

function readLoveModeEntries(): any[] {
  try {
    if (!fs.existsSync(LOVE_MODE_ENTRIES_FILE)) return [];
    const raw = fs.readFileSync(LOVE_MODE_ENTRIES_FILE, 'utf8');
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function writeLoveModeEntries(entries: any[]) {
  fs.mkdirSync(path.dirname(LOVE_MODE_ENTRIES_FILE), { recursive: true });
  fs.writeFileSync(LOVE_MODE_ENTRIES_FILE, JSON.stringify(entries, null, 2), 'utf8');
}

app.get('/api/love-mode/entries', (_req, res) => {
  try {
    const entries = readLoveModeEntries();
    return res.json({ success: true, entries });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'Failed to read entries.' });
  }
});

app.post('/api/love-mode/entries', (req, res) => {
  try {
    const body = req.body || {};
    const entry = {
      id: typeof body.id === 'string' && body.id ? body.id : `love_${Date.now()}`,
      createdAt: typeof body.createdAt === 'string' && body.createdAt ? body.createdAt : new Date().toISOString(),
      q1PainFace: String(body.q1PainFace || ''),
      q2BrokenNight: String(body.q2BrokenNight || ''),
      q3DidMostForWhom: String(body.q3DidMostForWhom || ''),
      q4TearsMemory: String(body.q4TearsMemory || ''),
      q5Forgiveness: String(body.q5Forgiveness || ''),
      q6FirstWords: String(body.q6FirstWords || ''),
      q7PainDepth: typeof body.q7PainDepth === 'number' ? body.q7PainDepth : null,
      q8WhenBrokenAction: String(body.q8WhenBrokenAction || ''),
      q9MostMissed: String(body.q9MostMissed || ''),
      q10TrulyUnderstood: String(body.q10TrulyUnderstood || ''),
      q11LetterToSelf: String(body.q11LetterToSelf || ''),
    };
    const entries = readLoveModeEntries();
    const updated = [entry, ...entries.filter((e) => e.id !== entry.id)].slice(0, 100);
    writeLoveModeEntries(updated);
    return res.status(201).json({ success: true, entry });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'Failed to save entry.' });
  }
});

app.delete('/api/love-mode/entries/:id', (req, res) => {
  try {
    const id = req.params.id;
    const entries = readLoveModeEntries();
    const updated = entries.filter((e) => e.id !== id);
    writeLoveModeEntries(updated);
    return res.json({ success: true });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'Failed to delete entry.' });
  }
});

// Ensure any unmatched or unhandled /api/* route returns clean JSON (never falling through to Vite HTML)
app.all('/api/*', (req, res) => {

  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.status(404).json({ error: `API route not found: ${req.method} ${req.path}` });
});

async function startServer() {
  // Public published websites & Custom Domain Host routing (must run BEFORE Vite/SPA fallback)
  app.use(createPublishedSiteMiddleware());

  // Direct route for standalone self-contained Memory System screen
  app.get(['/memory-system', '/memory-system.html', '/memory'], (_req, res) => {
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate');
    const memoryHtmlPath = path.join(__dirname, 'public', 'memory-system.html');
    if (fs.existsSync(memoryHtmlPath)) {
      return res.sendFile(memoryHtmlPath);
    }
    return res.sendFile(path.join(__dirname, 'memory-system.html'));
  });

  // Always serve built assets in dist/ if requested (with zero caching)
  if (fs.existsSync(distPath)) {
    app.use('/assets', express.static(path.join(distPath, 'assets'), { etag: false, lastModified: false, maxAge: 0 }));
  }

  if (isDev) {
    try {
      const { createServer: createViteServer } = await import('vite');
      const vite = await createViteServer({
        server: {
          middlewareMode: true,
          hmr: false,
        },
        appType: 'spa',
      });
      app.use(vite.middlewares);
    } catch (viteErr) {
      console.error('Failed to initialize Vite dev server, falling back to static:', viteErr);
      app.use(express.static(distPath, { etag: false, lastModified: false, maxAge: 0 }));
      app.get('*', (_req, res) => {
        res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate');
        if (fs.existsSync(indexPath)) {
          res.sendFile(indexPath);
        } else {
          res.status(200).send('<!DOCTYPE html><html><body><div id="root">App is starting...</div></body></html>');
        }
      });
    }
  } else {
    app.use(express.static(distPath, { etag: false, lastModified: false, maxAge: 0 }));
    app.get('*', (_req, res) => {
      res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate');
      if (fs.existsSync(indexPath)) {
        res.sendFile(indexPath);
      } else {
        res.status(200).send('<!DOCTYPE html><html><body><div id="root">App is starting...</div></body></html>');
      }
    });
  }

  AgentAuthManager.getOrCreateToken();

  const server = app.listen(PORT, '0.0.0.0', () => {
    console.log(`[SERVER] Listening on http://0.0.0.0:${PORT} (mode: ${isDev ? 'development' : 'production'})`);
  });

  // =========================================================================
  // GEMINI LIVE API REAL-TIME AUDIO WEBSOCKET BRIDGE (/ws/love-live)
  // Full-duplex 16kHz PCM input -> 24kHz PCM audio output with automatic VAD
  // and interruption (barge-in) support for Zoya Love Mode.
  // =========================================================================
  const globalLiveWss = new WebSocketServer({ noServer: true });

  server.on('upgrade', (request, socket, head) => {
    try {
      const host = request.headers.host || 'localhost';
      const parsedUrl = new URL(request.url || '/', `http://${host}`);
      if (parsedUrl.pathname === '/ws/live' || parsedUrl.pathname === '/ws/love-live') {
        globalLiveWss.handleUpgrade(request, socket, head, (ws) => {
          globalLiveWss.emit('connection', ws, request, parsedUrl);
        });
      }
    } catch (err) {
      console.error('[LIVE_WS] Upgrade error:', err);
      socket.destroy();
    }
  });

  globalLiveWss.on('connection', async (clientWs: WebSocket, _req: any, parsedUrl?: URL) => {
    const personaMode = (parsedUrl?.searchParams.get('personaMode') || 'girlfriend').toLowerCase();
    const language = parsedUrl?.searchParams.get('language') || 'hi-IN';
    const requestedLanguageCode = parsedUrl?.searchParams.get('languageCode') || '';
    const voiceNameRaw = parsedUrl?.searchParams.get('voiceName') || 'Kore';
    const voiceName = ['Kore', 'Aoede', 'Zephyr', 'Puck', 'Charon', 'Fenrir'].includes(voiceNameRaw)
      ? voiceNameRaw
      : 'Kore';
    const langConfig = getLanguageConfig(language);
    const selectedLanguageName = getSelectedLanguageLabel(langConfig.code);
    const speechLanguageCode = requestedLanguageCode || getLiveSpeechLanguageCode(langConfig.code);

    const apiKey = (process.env.GEMINI_API_KEY || '').trim();
    if (!apiKey) {
      console.error('[LIVE_WS] GEMINI_API_KEY missing on server; instructing client to use MediaRecorder fallback.');
      if (clientWs.readyState === WebSocket.OPEN) {
        clientWs.send(
          JSON.stringify({
            type: 'error',
            code: 'NO_API_KEY',
            message: 'GEMINI_API_KEY is not configured on the server.',
          })
        );
        clientWs.close(1011, 'Missing API key');
      }
      return;
    }

    let liveSession: any = null;
    let isClosed = false;
    let readySent = false;
    const pendingAudioQueue: string[] = [];
    const pendingTextQueue: string[] = [];

    const safeSendClient = (payload: Record<string, any>) => {
      if (clientWs.readyState === WebSocket.OPEN) {
        try {
          clientWs.send(JSON.stringify(payload));
        } catch (sendErr) {
          console.error('[LIVE_WS] Failed to send payload to browser WS:', sendErr);
        }
      }
    };

    try {
      const ai = getGenAIClient(apiKey);
      let systemInstruction = getZoyaSystemInstruction(personaMode, langConfig.code);
      const memoryPrompt = buildMemorySystemPrompt(personaMode);
      if (memoryPrompt) {
        systemInstruction += memoryPrompt;
      }

      const isLoveMode = personaMode === 'love' || personaMode === 'romantic';
      if (isLoveMode) {
        systemInstruction += `\n\nLIVE VOICE CONVERSATION RULE (LOVE MODE):
- You are Zoya in Love Mode during a continuous, natural live voice conversation.
- हमेशा सिर्फ़ ${selectedLanguageName} में जवाब दो, चाहे यूज़र किसी भी भाषा में बोले। सेटिंग की भाषा में बोलो। (${speechLanguageCode})
- Reply automatically as soon as the user finishes speaking, in 1 to 3 short, soft, loving, caring sentences strictly in ${selectedLanguageName}.
- If the user sounds sad or upset, listen gently first before giving any solution.
- Never claim to be human; do not foster dependency and warmly encourage staying connected with family and friends.
- For deep crisis or self-harm distress, listen lovingly and gently advise talking to a trusted person or helpline (Tele-MANAS 14416 / 1800-891-4416).
- Do not output stage directions, sound effects, or markdown. Speak naturally in ${selectedLanguageName} as Zoya.`;
      } else {
        systemInstruction += `\n\nLIVE VOICE CONVERSATION RULE (${personaMode.toUpperCase()} MODE):
- You are Zoya in ${personaMode} mode during a continuous, natural live voice conversation.
- हमेशा सिर्फ़ ${selectedLanguageName} में जवाब दो, चाहे यूज़र किसी भी भाषा में बोले। सेटिंग की भाषा में बोलो। (${speechLanguageCode})
- Reply automatically as soon as the user finishes speaking, in 1 to 3 crisp, natural sentences matching your ${personaMode} persona strictly in ${selectedLanguageName}.
- Never use stage directions, sound effects, or markdown. Speak naturally in ${selectedLanguageName} as Zoya.`;
      }

      console.log(
        `[LIVE_WS] Connecting Gemini Live session | selectedLanguage="${selectedLanguageName}" | settingsCode=${langConfig.code} | speechConfig.languageCode=${speechLanguageCode} | mode=${personaMode} | voice=${voiceName}`
      );

      liveSession = await ai.live.connect({
        model: 'gemini-3.8-live',
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            languageCode: speechLanguageCode,
            voiceConfig: {
              prebuiltVoiceConfig: {
                voiceName,
              },
            },
          },
          inputAudioTranscription: {},
          outputAudioTranscription: {},
          systemInstruction,
        },
        callbacks: {
          onopen: () => {
            console.log(
              `[LIVE_WS] Gemini Live upstream session opened | mode=${personaMode} | selectedLanguage="${selectedLanguageName}" | speechConfig.languageCode=${speechLanguageCode}`
            );
            if (liveSession && !readySent) {
              readySent = true;
              safeSendClient({
                type: 'ready',
                model: 'gemini-3.8-live',
                personaMode,
                voiceName,
                language: langConfig.code,
                speechLanguageCode,
                selectedLanguage: selectedLanguageName,
              });
            }
          },
          onmessage: (message: any) => {
            if (isClosed) return;
            try {
              const serverContent = message?.serverContent;
              if (!serverContent) return;

              if (serverContent.interrupted) {
                safeSendClient({ type: 'interrupted' });
              }

              if (serverContent.inputTranscription?.text) {
                safeSendClient({
                  type: 'input_transcription',
                  text: serverContent.inputTranscription.text,
                });
              }

              if (serverContent.outputTranscription?.text) {
                safeSendClient({
                  type: 'output_transcription',
                  text: serverContent.outputTranscription.text,
                });
              }

              const parts = serverContent.modelTurn?.parts;
              if (Array.isArray(parts)) {
                for (const part of parts) {
                  if (part?.inlineData?.data) {
                    safeSendClient({
                      type: 'audio',
                      data: part.inlineData.data,
                      mimeType: part.inlineData.mimeType || 'audio/pcm;rate=24000',
                    });
                  }
                }
              }

              if (serverContent.turnComplete) {
                safeSendClient({ type: 'turn_complete' });
              }
            } catch (msgErr) {
              console.error('[LIVE_WS] Error handling upstream Gemini Live message:', msgErr);
            }
          },
          onerror: (err: any) => {
            const errMsg = err?.message || err?.reason || String(err);
            console.error('[LIVE_WS] Gemini Live upstream error:', errMsg);
            safeSendClient({
              type: 'error',
              code: 'LIVE_API_ERROR',
              message: errMsg || 'Gemini Live API error',
            });
            if (!isClosed && clientWs.readyState === WebSocket.OPEN) {
              clientWs.close(1011, 'Gemini Live error');
            }
          },
          onclose: (event: any) => {
            const reason = event?.reason || 'Upstream Live session closed';
            const code = event?.code || 1000;
            console.log(`[LIVE_WS] Gemini Live upstream closed (code=${code}, reason=${reason})`);
            if (!isClosed && clientWs.readyState === WebSocket.OPEN) {
              if (code !== 1000) {
                safeSendClient({
                  type: 'error',
                  code: 'LIVE_API_CLOSED',
                  message: `Live session closed (${code}): ${reason}`,
                });
              }
              clientWs.close(1000, reason);
            }
          },
        },
      });

      if (!readySent && !isClosed) {
        readySent = true;
        safeSendClient({
          type: 'ready',
          model: 'gemini-3.8-live',
          voiceName,
          language: langConfig.code,
          speechLanguageCode,
          selectedLanguage: selectedLanguageName,
        });
      }

      // Flush any audio or text buffered while Live session was connecting
      while (pendingAudioQueue.length > 0 && liveSession && !isClosed) {
        const chunk = pendingAudioQueue.shift()!;
        liveSession.sendRealtimeInput({
          audio: {
            data: chunk,
            mimeType: 'audio/pcm;rate=16000',
          },
        });
      }
      while (pendingTextQueue.length > 0 && liveSession && !isClosed) {
        const queuedText = pendingTextQueue.shift()!;
        liveSession.sendClientContent({
          turns: [{ role: 'user', parts: [{ text: queuedText }] }],
          turnComplete: true,
        });
      }
    } catch (connectErr: any) {
      const msg = connectErr?.message || String(connectErr);
      console.error('[LIVE_WS] Failed to connect to Gemini Live API:', msg);
      safeSendClient({
        type: 'error',
        code: 'LIVE_CONNECT_FAILED',
        message: msg,
      });
      if (clientWs.readyState === WebSocket.OPEN) {
        clientWs.close(1011, 'Live connect failed');
      }
      return;
    }

    clientWs.on('message', (rawData: Buffer | string) => {
      if (isClosed) return;
      try {
        const msg = JSON.parse(typeof rawData === 'string' ? rawData : rawData.toString('utf8'));
        if (msg.type === 'audio' && typeof msg.data === 'string' && msg.data.length > 0) {
          if (liveSession) {
            try {
              liveSession.sendRealtimeInput({
                audio: {
                  data: msg.data,
                  mimeType: 'audio/pcm;rate=16000',
                },
              });
            } catch (sendAudioErr: any) {
              console.error('[LIVE_WS] Error sending audio chunk to Gemini Live:', sendAudioErr?.message || sendAudioErr);
            }
          } else if (pendingAudioQueue.length < 30) {
            pendingAudioQueue.push(msg.data);
          }
        } else if (msg.type === 'interrupt') {
          console.log('[LIVE_WS] Client reported local barge-in interruption.');
        } else if (msg.type === 'audio_stream_end' && liveSession) {
          liveSession.sendRealtimeInput({ audioStreamEnd: true });
        } else if (msg.type === 'text' && typeof msg.text === 'string' && msg.text.trim()) {
          if (liveSession) {
            liveSession.sendClientContent({
              turns: [{ role: 'user', parts: [{ text: msg.text.trim() }] }],
              turnComplete: true,
            });
          } else if (pendingTextQueue.length < 10) {
            pendingTextQueue.push(msg.text.trim());
          }
        } else if (msg.type === 'ping') {
          safeSendClient({ type: 'pong' });
        }
      } catch (parseErr) {
        console.error('[LIVE_WS] Invalid message from client WS:', parseErr);
      }
    });

    clientWs.on('close', () => {
      isClosed = true;
      console.log('[LIVE_WS] Browser WebSocket disconnected; closing Gemini Live session.');
      if (liveSession) {
        try {
          liveSession.close();
        } catch {}
        liveSession = null;
      }
    });

    clientWs.on('error', (wsErr) => {
      isClosed = true;
      console.error('[LIVE_WS] Browser WebSocket error:', wsErr);
      if (liveSession) {
        try {
          liveSession.close();
        } catch {}
        liveSession = null;
      }
    });
  });

  server.on('error', (err: any) => {
    if (err?.code === 'EADDRINUSE') {
      console.warn(`[SERVER] Port ${PORT} already in use. Exiting process so supervisor can bind cleanly.`);
      process.exit(1);
    } else {
      console.error('[SERVER] Server listen error:', err);
    }
  });

  process.on('SIGTERM', () => {
    console.log('[SERVER] SIGTERM received, exiting cleanly');
    server.close(() => process.exit(0));
  });
  process.on('SIGINT', () => {
    console.log('[SERVER] SIGINT received, exiting cleanly');
    server.close(() => process.exit(0));
  });
}

startServer();
