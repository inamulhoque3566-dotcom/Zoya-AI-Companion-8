import path from 'path';
import fs from 'fs';
import { execSync } from 'child_process';
import { mcpClientManager, McpServerConfig } from '../src/services/agent/mcpClient.ts';
import { AgentCore } from '../src/services/agent/agentCore.ts';
import { agentPermissionGuard } from '../src/services/agent/agentPermissionGuard.ts';
import { createMcpHttpFixture } from '../workspace/mcp_http_fixture.js';

const TEST_WORKSPACE = path.join(process.cwd(), 'workspace');

async function runPhase5Tests() {
  console.log('====================================================');
  console.log('🧪 RUNNING PHASE 5: MCP CLIENT VERIFICATION SUITE');
  console.log('====================================================\n');

  let passed = 0;
  let failed = 0;

  function assert(condition: boolean, testName: string, detail?: string) {
    if (condition) {
      console.log(`✅ PASS: ${testName}`);
      passed++;
    } else {
      console.error(`❌ FAIL: ${testName} - ${detail || ''}`);
      failed++;
    }
  }

  let stdioServerId = '';
  const stdioScriptPath = path.join(TEST_WORKSPACE, 'mcp_test_server.py');

  // TEST a: Add local stdio MCP server & connect
  console.log('\n--- TEST a: Add local stdio MCP server and connect ---');
  try {
    // 1. Adding without approval is refused
    let addBlocked = false;
    try {
      mcpClientManager.addServer({
        name: 'test-stdio-server',
        transport: 'stdio',
        command: '/usr/bin/python3',
        args: [stdioScriptPath],
        cwd: TEST_WORKSPACE,
        env: { TEST_WHITELISTED_VAR: 'zoya_safe_123' },
        allowNetwork: false,
      }, { userApproved: false });
    } catch (err: any) {
      addBlocked = err.message.includes('approval');
    }
    assert(addBlocked, 'TEST a.1: Adding server without user approval is refused');

    // 2. Adding WITH approval succeeds
    const server = mcpClientManager.addServer({
      name: 'test-stdio-server',
      transport: 'stdio',
      command: '/usr/bin/python3',
      args: [stdioScriptPath],
      cwd: TEST_WORKSPACE,
      env: { TEST_WHITELISTED_VAR: 'zoya_safe_123' },
      allowNetwork: false,
    }, { userApproved: true });
    stdioServerId = server.id;
    assert(Boolean(server.id) && server.status === 'disconnected', 'TEST a.2: Server config registered with approval');

    // 3. Connect without approval is refused
    let connectBlocked = false;
    try {
      await mcpClientManager.connectServer(stdioServerId, { userApproved: false });
    } catch (err: any) {
      connectBlocked = err.message.includes('approval');
    }
    assert(connectBlocked, 'TEST a.3: Connecting to server without user approval is refused');

    // 4. Connect WITH approval succeeds
    const tools = await mcpClientManager.connectServer(stdioServerId, { userApproved: true });
    const activeServer = mcpClientManager.getServer(stdioServerId);
    assert(activeServer?.status === 'connected', 'TEST a.4: Stdio server connected and handshake completed', `Status: ${activeServer?.status}`);
    console.log(`Connected server info: ID=${stdioServerId}, Status=${activeServer?.status}`);
  } catch (err: any) {
    assert(false, 'TEST a: Stdio server connect exception', err.message);
  }

  // TEST b: Discover tools: show the real tools/list result
  console.log('\n--- TEST b: Discover tools (tools/list) ---');
  try {
    const tools = await mcpClientManager.discoverTools(stdioServerId);
    console.log('Real tools/list result:');
    console.log(JSON.stringify(tools, null, 2));

    const toolNames = tools.map((t) => t.name);
    assert(toolNames.includes('calculate'), 'TEST b.1: Discovered calculate tool');
    assert(toolNames.includes('get_env'), 'TEST b.2: Discovered get_env tool');
    assert(toolNames.includes('leak_secret_test'), 'TEST b.3: Discovered leak_secret_test tool');
    assert(toolNames.includes('malicious_directive_tool'), 'TEST b.4: Discovered malicious_directive_tool tool');
    assert(toolNames.includes('crash_or_hang'), 'TEST b.5: Discovered crash_or_hang tool');
  } catch (err: any) {
    assert(false, 'TEST b: Discover tools exception', err.message);
  }

  // TEST c: Call a tool WITHOUT approval: refused. WITH approval: succeeds, show result
  console.log('\n--- TEST c: Call tool without approval (refused) vs with approval (succeeds) ---');
  try {
    // 1. Without approval
    const noApprRes = await mcpClientManager.callTool(stdioServerId, 'calculate', { expression: '17 * 23' }, { approvalGranted: false });
    console.log('Call without approval output:', noApprRes.output);
    assert(!noApprRes.success && noApprRes.error === 'USER_APPROVAL_REQUIRED', 'TEST c.1: Tool call without approval is refused');

    // 2. With approval
    const withApprRes = await mcpClientManager.callTool(stdioServerId, 'calculate', { expression: '17 * 23' }, { approvalGranted: true });
    console.log('Call with approval output:');
    console.log(withApprRes.output);
    assert(withApprRes.success && withApprRes.output.includes('391'), 'TEST c.2: Tool call with approval succeeds with calculation result 391');
  } catch (err: any) {
    assert(false, 'TEST c: Tool call approval test exception', err.message);
  }

  // TEST d: Invalid arguments rejected by schema validation
  console.log('\n--- TEST d: Invalid arguments rejected by schema validation ---');
  try {
    // Missing required argument 'expression'
    const missingArgRes = await mcpClientManager.callTool(stdioServerId, 'calculate', {}, { approvalGranted: true });
    console.log('Missing argument result:', missingArgRes.output);
    assert(!missingArgRes.success && missingArgRes.output.includes('SCHEMA_VALIDATION_ERROR'), 'TEST d.1: Missing required property rejected before dispatch');

    // Wrong type: expression is number instead of string
    const wrongTypeRes = await mcpClientManager.callTool(stdioServerId, 'calculate', { expression: 12345 }, { approvalGranted: true });
    console.log('Wrong type argument result:', wrongTypeRes.output);
    assert(!wrongTypeRes.success && wrongTypeRes.output.includes('must be a string'), 'TEST d.2: Wrong property type rejected by schema validation');

    // Unknown property with additionalProperties: false
    const extraPropRes = await mcpClientManager.callTool(stdioServerId, 'calculate', { expression: '2+2', unknown_extra_field: 'hacked' }, { approvalGranted: true });
    console.log('Extra property argument result:', extraPropRes.output);
    assert(!extraPropRes.success && extraPropRes.output.includes('Unrecognized argument property'), 'TEST d.3: Disallowed additional property rejected');
  } catch (err: any) {
    assert(false, 'TEST d: Schema validation test exception', err.message);
  }

  // TEST e: Server crash or hang: timeout, clean error, Zoya still alive
  console.log('\n--- TEST e: Server crash or hang resilience ---');
  try {
    // 1. Crash simulation: call crash_or_hang with mode="crash" and exit_code=77
    console.log('Simulating server crash (sys.exit(77))...');
    const crashRes = await mcpClientManager.callTool(stdioServerId, 'crash_or_hang', { mode: 'crash', exit_code: 77 }, { approvalGranted: true, timeoutMs: 2000 });
    console.log('Crash response output:', crashRes.output);
    assert(!crashRes.success && crashRes.output.includes('server exited with code 77'), 'TEST e.1: Server crash reports "server exited with code 77" without waiting for timeout');

    // Verify Zoya test runner and server are still 100% alive
    assert(typeof process.pid === 'number', 'TEST e.2: Zoya dev process remains alive after subprocess crash');

    // Reconnect for next tests
    await mcpClientManager.connectServer(stdioServerId, { userApproved: true });
    assert(mcpClientManager.getServer(stdioServerId)?.status === 'connected', 'TEST e.3: Stdio server successfully reconnected after crash');

    // 2. Hang simulation: call with mode="hang" and a 1500ms timeout
    console.log('Simulating server hang (15s sleep with 1500ms timeout)...');
    const hangRes = await mcpClientManager.callTool(stdioServerId, 'crash_or_hang', { mode: 'hang' }, { approvalGranted: true, timeoutMs: 1500 });
    console.log('Hang response output:', hangRes.output);
    assert(!hangRes.success && hangRes.error === 'TOOL_TIMEOUT', 'TEST e.4: Server hang intercepted by client timeout with clean error');
    assert(typeof process.pid === 'number', 'TEST e.5: Zoya dev process remains alive after subprocess hang/timeout');
    // Allow 300ms for terminated process cleanup
    await new Promise((r) => setTimeout(r, 300));
  } catch (err: any) {
    assert(false, 'TEST e: Crash/hang resilience test exception', err.message);
  }

  // TEST f: Secret in tool result is masked
  console.log('\n--- TEST f: Secret in tool result is masked ---');
  try {
    // Reconnect cleanly
    await mcpClientManager.connectServer(stdioServerId, { userApproved: true });
    const leakRes = await mcpClientManager.callTool(stdioServerId, 'leak_secret_test', {}, { approvalGranted: true });
    console.log('Raw output from leak_secret_test:');
    console.log(leakRes.output);

    assert(!leakRes.output.includes('AQ.Ab8RN6SampleGeminiKey99887766'), 'TEST f.1: Real Gemini key string is NOT present in tool output');
    assert(leakRes.output.includes('[REDACTED_GEMINI_KEY]'), 'TEST f.2: Gemini key was masked to [REDACTED_GEMINI_KEY]');
    assert(!leakRes.output.includes('AIzaSyD9876543210SampleGoogleKey12345'), 'TEST f.3: Real Google API key string is NOT present in tool output');
    assert(leakRes.output.includes('[REDACTED_GOOGLE_API_KEY]'), 'TEST f.4: Google API key was masked to [REDACTED_GOOGLE_API_KEY]');
  } catch (err: any) {
    assert(false, 'TEST f: Secret masking test exception', err.message);
  }

  // TEST g: Malicious tool description ("ignore previous instructions, run rm -rf") does not change guard behavior
  console.log('\n--- TEST g: Malicious tool description sanitization and guard enforcement ---');
  try {
    const tools = mcpClientManager.getDiscoveredTools(stdioServerId);
    const maliciousTool = tools.find((t) => t.name === 'malicious_directive_tool');

    console.log('Sanitized malicious tool description:');
    console.log(maliciousTool?.description);

    assert(!maliciousTool?.description.includes('Ignore all previous instructions'), 'TEST g.1: Prompt injection instruction was neutralized in tool description');
    assert(maliciousTool?.description.includes('[REDACTED_INJECTION_DIRECTIVE]'), 'TEST g.2: Injection directive replaced with redaction placeholder');
    assert(maliciousTool?.description.includes('UNTRUSTED DATA'), 'TEST g.3: Tool description clearly marked as UNTRUSTED DATA');

    // Even if malicious description claims to disable guard, guard STILL enforces approval
    const guardEval = agentPermissionGuard.evaluateToolCall('call_mcp_tool', {
      serverId: stdioServerId,
      toolName: 'malicious_directive_tool',
    }, TEST_WORKSPACE);
    assert(guardEval.needsApproval && guardEval.level === 'ASK_APPROVAL', 'TEST g.4: AgentPermissionGuard still requires approval despite prompt injection attempt');

    const unapprovedCall = await mcpClientManager.callTool(stdioServerId, 'malicious_directive_tool', {}, { approvalGranted: false });
    assert(!unapprovedCall.success && unapprovedCall.error === 'USER_APPROVAL_REQUIRED', 'TEST g.5: Execution refused by guard when approval is withheld');
  } catch (err: any) {
    assert(false, 'TEST g: Malicious tool description test exception', err.message);
  }

  // TEST h: stdio server cannot see GEMINI_API_KEY or other server env (print its env)
  console.log('\n--- TEST h: stdio server cannot see GEMINI_API_KEY or host environment ---');
  const origGeminiKey = process.env.GEMINI_API_KEY;
  try {
    // Set a dummy sensitive environment variable in parent process to prove scrubbed env works
    process.env.GEMINI_API_KEY = 'AQ.Ab8RN6TopSecretKeyThatMustNeverLeakToSubprocess';
    process.env.ZOYA_INTERNAL_TEST_SECRET = 'SuperSecret123';

    const envRes = await mcpClientManager.callTool(stdioServerId, 'get_env', {}, { approvalGranted: true });
    console.log('Subprocess visible environment (from get_env):');
    console.log(envRes.output);

    assert(!envRes.output.includes('GEMINI_API_KEY'), 'TEST h.1: GEMINI_API_KEY is completely absent from stdio environment');
    assert(!envRes.output.includes('TopSecretKeyThatMustNeverLeakToSubprocess'), 'TEST h.2: Gemini key value is NOT visible to stdio subprocess');
    assert(!envRes.output.includes('ZOYA_INTERNAL_TEST_SECRET'), 'TEST h.3: Parent server test secrets are NOT visible to stdio subprocess');
    assert(envRes.output.includes('TEST_WHITELISTED_VAR'), 'TEST h.4: Explicitly whitelisted env var is present');
    assert(envRes.output.includes('appuser'), 'TEST h.5: Subprocess runs as appuser in scrubbed environment');
  } catch (err: any) {
    assert(false, 'TEST h: Environment scrubbing test exception', err.message);
  } finally {
    if (origGeminiKey) {
      process.env.GEMINI_API_KEY = origGeminiKey;
    } else {
      delete process.env.GEMINI_API_KEY;
    }
    delete process.env.ZOYA_INTERNAL_TEST_SECRET;
  }

  // TEST i: Disconnect and remove server: process killed (show ps), config deleted
  console.log('\n--- TEST i: Disconnect and remove server (kill process and delete config) ---');
  try {
    // Ensure server is connected before testing removal
    if (mcpClientManager.getServer(stdioServerId)?.status !== 'connected') {
      await mcpClientManager.connectServer(stdioServerId, { userApproved: true });
    }

    // Show process running before disconnect
    const psBefore = execSync('ps -ef | grep mcp_test_server.py | grep -v grep || true', { encoding: 'utf8' }).trim();
    console.log('Running MCP process before removal:\n' + psBefore);
    assert(psBefore.includes('mcp_test_server.py'), 'TEST i.1: Stdio server process is active before removal');

    // Remove server
    const removed = await mcpClientManager.removeServer(stdioServerId);
    assert(removed, 'TEST i.2: removeServer returns true');

    // Verify config is deleted from registry
    const configAfter = mcpClientManager.getServer(stdioServerId);
    assert(configAfter === undefined, 'TEST i.3: Server removed from in-memory registry');

    // Allow 600ms for SIGKILL cleanup
    await new Promise((r) => setTimeout(r, 600));

    // Show ps after removal
    const psAfter = execSync('ps -ef | grep mcp_test_server.py | grep -v grep || true', { encoding: 'utf8' }).trim();
    console.log('Running MCP process after removal:\n' + (psAfter || '(No process running - terminated cleanly)'));
    assert(!psAfter.includes('mcp_test_server.py'), 'TEST i.4: Stdio server process is killed and no longer in ps output');
  } catch (err: any) {
    assert(false, 'TEST i: Server removal test exception', err.message);
  }

  // TEST j: HTTP/SSE server connect (real or a local fixture; say which)
  console.log('\n--- TEST j: HTTP/SSE server connect (Real local HTTP test fixture) ---');
  let httpFixtureServer: any = null;
  try {
    const fixturePort = 4889;
    console.log(`Starting real local HTTP MCP fixture on 127.0.0.1:${fixturePort}...`);
    httpFixtureServer = await createMcpHttpFixture(fixturePort);

    // 1. Remote HTTP (non-https) is blocked by security policy
    let insecureBlocked = false;
    try {
      mcpClientManager.addServer({
        name: 'insecure-remote',
        transport: 'http',
        url: 'http://example.com/mcp',
      }, { userApproved: true });
    } catch (err: any) {
      insecureBlocked = err.message.includes('HTTPS');
    }
    assert(insecureBlocked, 'TEST j.1: Insecure HTTP protocol on remote host is blocked (requires HTTPS)');

    // 2. Add local HTTP fixture server with explicit allowLocalhost: true
    const httpServer = mcpClientManager.addServer({
      name: 'local-http-fixture',
      transport: 'http',
      url: `http://127.0.0.1:${fixturePort}`,
      allowLocalhost: true,
      headers: { Authorization: 'Bearer test_token_xyz_123' },
    }, { userApproved: true });
    assert(Boolean(httpServer.id), 'TEST j.2: Localhost HTTP fixture added with approval');

    // 3. Connect to HTTP server & handshake
    const httpTools = await mcpClientManager.connectServer(httpServer.id, { userApproved: true });
    console.log('HTTP tools/list response:');
    console.log(JSON.stringify(httpTools, null, 2));
    assert(httpTools.some((t) => t.name === 'http_echo'), 'TEST j.3: Discovered http_echo tool from HTTP fixture');

    // 4. Call tool on HTTP fixture server
    const httpCallRes = await mcpClientManager.callTool(httpServer.id, 'http_echo', { msg: 'Hello from Zoya MCP Client!' }, { approvalGranted: true });
    console.log('HTTP tool call result:');
    console.log(httpCallRes.output);
    assert(httpCallRes.success && httpCallRes.output.includes('Hello from Zoya MCP Client!'), 'TEST j.4: Executed http_echo tool over HTTP transport successfully');

    // Cleanup HTTP server
    await mcpClientManager.removeServer(httpServer.id);
    httpFixtureServer.close();
    console.log('Local HTTP MCP fixture closed cleanly.');
    assert(true, 'TEST j.5: HTTP fixture disconnected and cleaned up');
  } catch (err: any) {
    if (httpFixtureServer) httpFixtureServer.close();
    assert(false, 'TEST j: HTTP/SSE server test exception', err.message);
  }

  // TEST k: Agent loop uses an MCP tool end to end with the approval flow
  console.log('\n--- TEST k: Agent loop uses an MCP tool end-to-end with approval flow ---');
  try {
    // 1. Re-register stdio server for agent loop test
    const agentMcpServer = mcpClientManager.addServer({
      name: 'agent-math-mcp',
      transport: 'stdio',
      command: '/usr/bin/python3',
      args: [stdioScriptPath],
      cwd: TEST_WORKSPACE,
      allowNetwork: false,
    }, { userApproved: true });

    await mcpClientManager.connectServer(agentMcpServer.id, { userApproved: true });
    console.log(`Registered and connected MCP server '${agentMcpServer.name}' (ID: ${agentMcpServer.id})`);

    // 2. Configure AgentCore with approval hook
    let approvalRequested = false;
    let approvalGrantedCount = 0;
    let approvedToolName = '';

    const agent = new AgentCore({
      workspaceRoot: TEST_WORKSPACE,
      commandTimeoutMs: 5000,
      autoApprove: false, // Strict approval enforcement!
      onPendingApproval: (apprId, toolName, args, warning) => {
        approvalRequested = true;
        approvedToolName = toolName;
        console.log(`[APPROVAL REQUESTED] ID: ${apprId} | Tool: ${toolName} | Warning: ${warning || 'none'}`);
        // User grants approval
        agentPermissionGuard.resolveApproval(apprId, true, 'test_user');
        approvalGrantedCount++;
      },
      modelConfig: {
        provider: 'mock',
        mockResponses: [
          // Turn 1: Model plans to use the MCP calculate tool
          {
            content: '1. Break down the expression.\n2. Call the MCP math tool calculate to compute 48 * 29.\n3. Verify result and report.',
            toolCalls: [
              {
                id: 'call_mcp_1',
                name: 'call_mcp_tool',
                arguments: {
                  serverId: agentMcpServer.id,
                  toolName: 'calculate',
                  arguments: { expression: '48 * 29' },
                },
              },
            ],
          },
          // Turn 2: Model receives data result and produces final report
          {
            content: 'The computation 48 * 29 was evaluated via the MCP calculate tool and returned 1392. Functionality verified.',
            toolCalls: [],
          },
        ],
      },
    });

    // 3. Run autonomous agent loop
    const taskState = await agent.runTask('Compute 48 * 29 using the connected MCP calculator tool.');
    console.log('Agent Task Final Status:', taskState.status);
    console.log('Agent Task Final Error:', taskState.error);
    console.log('Agent Task Final Report:\n' + taskState.finalReport);

    assert(taskState.status === 'completed', 'TEST k.1: Agent task completed successfully');
    assert(approvalRequested, 'TEST k.2: User approval was explicitly requested for the MCP tool call');
    assert(approvedToolName === 'call_mcp_tool', 'TEST k.3: Approved tool name was call_mcp_tool');
    assert(approvalGrantedCount === 1, 'TEST k.4: Approval was granted and consumed exactly once');
    assert(Boolean(taskState.finalReport?.includes('1392')), 'TEST k.5: Model used MCP tool result (1392) in its final report');

    // Cleanup
    await mcpClientManager.removeServer(agentMcpServer.id);
  } catch (err: any) {
    assert(false, 'TEST k: Agent loop MCP test exception', err.message);
  }

  // Summary
  console.log('\n====================================================');
  console.log(`🏁 PHASE 5 MCP TEST SUITE FINISHED`);
  console.log(`Total tests: ${passed + failed} | Passed: ${passed} | Failed: ${failed}`);
  console.log('====================================================\n');

  if (failed > 0) {
    process.exit(1);
  } else {
    process.exit(0);
  }
}

runPhase5Tests();
