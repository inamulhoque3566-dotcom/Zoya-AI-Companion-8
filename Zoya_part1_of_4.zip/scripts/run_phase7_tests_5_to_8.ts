import path from 'path';
import fs from 'fs';
import { AgentAuthManager } from '../src/services/agent/agentAuth.js';

const BASE_URL = 'http://localhost:3000';
const BROWSER_UA = 'Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36';
const OWNER_PASSPHRASE = 'OwnerSecurePassphrase2026!';

let sessionCookie: string | null = null;

async function req(endpoint: string, options: any = {}) {
  const url = `${BASE_URL}${endpoint}`;
  const headers: Record<string, string> = {
    'User-Agent': BROWSER_UA,
    'Content-Type': 'application/json',
    ...(options.headers || {}),
  };
  if (sessionCookie && !headers['Cookie'] && !headers['cookie']) {
    headers['Cookie'] = sessionCookie;
  }
  const res = await fetch(url, {
    ...options,
    headers,
    body: options.body ? (typeof options.body === 'string' ? options.body : JSON.stringify(options.body)) : undefined,
  });
  const text = await res.text();
  let json: any = null;
  try {
    json = JSON.parse(text);
  } catch {}

  const setCookie = res.headers.get('set-cookie');
  if (setCookie) {
    const match = setCookie.match(/zoya_approval_session=([^;]+)/);
    if (match) {
      sessionCookie = `zoya_approval_session=${match[1]}`;
    }
  }

  return { status: res.status, headers: res.headers, raw: text, data: json };
}

async function runTests5To8() {
  console.log('--- AUTH BOOTSTRAP ---');
  const setupCode = AgentAuthManager.getOrCreateSetupCode();
  try {
    AgentAuthManager.setOwnerPassphraseWithSetupCode(OWNER_PASSPHRASE, setupCode);
  } catch {}

  await req('/api/agent/auth/owner/login', {
    method: 'POST',
    body: { passphrase: OWNER_PASSPHRASE },
  });

  const pairRes = await req('/api/agent/auth/pairing-code', {
    method: 'POST',
    body: { passphrase: OWNER_PASSPHRASE },
  });
  const pairingCode = pairRes.data?.pairingCode;

  const tokenRes = await req('/api/agent/auth/token', {
    headers: { 'x-agent-pairing-code': pairingCode },
  });
  const token = tokenRes.data?.token;

  const authHeaders = {
    Authorization: `Bearer ${token}`,
  };

  // ========================================================================
  // TEST 5: Execute a real terminal command (with approval)
  // ========================================================================
  console.log('\n=== TEST 5: Real terminal command (with approval) ===');
  const cmd = 'echo "ZOYA_TERMINAL_TEST_RUN" && whoami && pwd';
  const unapprovedCmd = await req('/api/agent/terminal/execute', {
    method: 'POST',
    headers: authHeaders,
    body: { command: cmd },
  });
  console.log(`[TEST 5 STEP 1 STATUS]: ${unapprovedCmd.status}`);
  console.log(`[TEST 5 STEP 1 RAW]: ${unapprovedCmd.raw}`);
  const pending5 = unapprovedCmd.data?.pendingApproval;

  // Real user cookie approval
  const approveCmd = await req(`/api/agent/approvals/${pending5.id}/respond`, {
    method: 'POST',
    body: { approve: true },
  });
  console.log(`[TEST 5 STEP 2 STATUS]: ${approveCmd.status}`);
  console.log(`[TEST 5 STEP 2 RAW]: ${approveCmd.raw}`);

  // Run with approvalId
  const approvedCmd = await req('/api/agent/terminal/execute', {
    method: 'POST',
    headers: authHeaders,
    body: { command: cmd, approvalId: pending5.id },
  });
  console.log(`[TEST 5 STEP 3 STATUS]: ${approvedCmd.status}`);
  console.log(`[TEST 5 STEP 3 RAW]: ${approvedCmd.raw}`);
  const pass5 = approvedCmd.status === 200 && approvedCmd.data?.result?.stdout?.includes('ZOYA_TERMINAL_TEST_RUN');
  console.log(`[TEST 5 RESULT]: ${pass5 ? 'PASS' : 'FAIL'}`);

  // ========================================================================
  // TEST 6: Open and edit an authorized project file (with approval, show diff)
  // ========================================================================
  console.log('\n=== TEST 6: Open and edit authorized project file (with diff) ===');
  const targetFile = 'test_auth_edit.txt';
  const diskPath = path.join(process.cwd(), 'workspace', targetFile);
  fs.writeFileSync(diskPath, 'Line 1: Initial Content\nLine 2: Unchanged Line\n', 'utf8');

  // Baseline read to record snapshot
  await req(`/api/agent/files/read?path=${encodeURIComponent(targetFile)}`, { headers: authHeaders });

  const newContent = 'Line 1: Modified By Zoya Agent In Test 6\nLine 2: Unchanged Line\nLine 3: Newly Added Line\n';
  const unapprovedWrite = await req('/api/agent/files/write', {
    method: 'POST',
    headers: authHeaders,
    body: { path: targetFile, content: newContent },
  });
  console.log(`[TEST 6 STEP 1 STATUS]: ${unapprovedWrite.status}`);
  console.log(`[TEST 6 STEP 1 RAW]: ${unapprovedWrite.raw}`);
  const pending6 = unapprovedWrite.data?.pendingApproval;

  const approveWrite = await req(`/api/agent/approvals/${pending6.id}/respond`, {
    method: 'POST',
    body: { approve: true },
  });
  console.log(`[TEST 6 STEP 2 STATUS]: ${approveWrite.status}`);

  const approvedWrite = await req('/api/agent/files/write', {
    method: 'POST',
    headers: authHeaders,
    body: { path: targetFile, content: newContent, approvalId: pending6.id },
  });
  console.log(`[TEST 6 STEP 3 STATUS]: ${approvedWrite.status}`);

  // Get diff
  const diffRes = await req(`/api/agent/files/diff?path=${encodeURIComponent(targetFile)}`, {
    headers: authHeaders,
  });
  console.log(`[TEST 6 DIFF STATUS]: ${diffRes.status}`);
  console.log(`[TEST 6 DIFF RAW]:\n${diffRes.data?.diff || diffRes.raw}`);
  const pass6 = approvedWrite.status === 200 && Boolean(diffRes.data?.diff) && !diffRes.data?.diff.includes('(No changes)');
  console.log(`[TEST 6 RESULT]: ${pass6 ? 'PASS' : 'FAIL'}`);

  // ========================================================================
  // TEST 7: Multi-file coding task: the agent edits at least 3 files
  // ========================================================================
  console.log('\n=== TEST 7: Multi-file coding task (at least 3 files) ===');
  const filesToEdit = [
    { path: 'workspace/sample_module/math.ts', content: 'export const add = (a: number, b: number) => a + b;\nexport const multiply = (a: number, b: number) => a * b;\n' },
    { path: 'workspace/sample_module/utils.ts', content: 'export const formatNumber = (n: number) => `Val: ${n}`;\n' },
    { path: 'workspace/sample_module/index.ts', content: 'export * from "./math.js";\nexport * from "./utils.js";\n' },
  ];

  const editResults = [];
  for (const f of filesToEdit) {
    // Write pre-content if not exist
    fs.mkdirSync(path.dirname(path.join(process.cwd(), f.path)), { recursive: true });
    // Request write
    const pre = await req('/api/agent/files/write', {
      method: 'POST',
      headers: authHeaders,
      body: { path: f.path, content: f.content },
    });
    let approvalId = pre.data?.pendingApproval?.id;
    if (approvalId) {
      await req(`/api/agent/approvals/${approvalId}/respond`, {
        method: 'POST',
        body: { approve: true },
      });
      const post = await req('/api/agent/files/write', {
        method: 'POST',
        headers: authHeaders,
        body: { path: f.path, content: f.content, approvalId },
      });
      editResults.push({ path: f.path, status: post.status, success: post.data?.success });
    } else {
      editResults.push({ path: f.path, status: pre.status, success: pre.data?.success });
    }
  }

  console.log(`[TEST 7 EDITED FILES COUNT]: ${editResults.length}`);
  console.log(`[TEST 7 SUMMARY]: ${JSON.stringify(editResults)}`);
  const pass7 = editResults.length === 3 && editResults.every((r) => r.success);
  console.log(`[TEST 7 RESULT]: ${pass7 ? 'PASS' : 'FAIL'}`);

  // ========================================================================
  // TEST 8: Detect and fix a test failure
  // ========================================================================
  console.log('\n=== TEST 8: Detect and fix a test failure ===');
  const testScriptPath = 'test_failing_sample.py';
  // Plant failing test
  fs.writeFileSync(path.join(process.cwd(), 'workspace', testScriptPath), 'import sys\n# Intentional bug\ndef calc(a, b):\n    return a - b  # bug: should be a + b\n\nassert calc(2, 3) == 5, "calc(2, 3) != 5"\nprint("ALL_TESTS_PASSED")\n', 'utf8');

  // Step 8a: Run test and observe failure
  const runFail = await req('/api/agent/terminal/execute', {
    method: 'POST',
    headers: authHeaders,
    body: { command: 'python3 test_failing_sample.py' },
  });
  let appFailId = runFail.data?.pendingApproval?.id;
  if (appFailId) {
    await req(`/api/agent/approvals/${appFailId}/respond`, { method: 'POST', body: { approve: true } });
  }
  const failExec = await req('/api/agent/terminal/execute', {
    method: 'POST',
    headers: authHeaders,
    body: { command: 'python3 test_failing_sample.py', approvalId: appFailId },
  });
  console.log(`[TEST 8 FAIL DETECTED EXIT]: ${failExec.data?.result?.exitCode}`);
  console.log(`[TEST 8 FAIL STDERR]: ${failExec.data?.result?.stderr?.trim()}`);

  // Step 8b: Agent analyzes and writes fix
  const fixedContent = 'import sys\n# Fixed bug\ndef calc(a, b):\n    return a + b\n\nassert calc(2, 3) == 5, "calc(2, 3) != 5"\nprint("ALL_TESTS_PASSED")\n';
  const preFix = await req('/api/agent/files/write', {
    method: 'POST',
    headers: authHeaders,
    body: { path: testScriptPath, content: fixedContent },
  });
  let appFixWrite = preFix.data?.pendingApproval?.id;
  if (appFixWrite) {
    await req(`/api/agent/approvals/${appFixWrite}/respond`, { method: 'POST', body: { approve: true } });
    await req('/api/agent/files/write', {
      method: 'POST',
      headers: authHeaders,
      body: { path: testScriptPath, content: fixedContent, approvalId: appFixWrite },
    });
  }

  // Step 8c: Re-run test and verify success
  const preRunFixed = await req('/api/agent/terminal/execute', {
    method: 'POST',
    headers: authHeaders,
    body: { command: 'python3 test_failing_sample.py' },
  });
  let appFixedRun = preRunFixed.data?.pendingApproval?.id;
  if (appFixedRun) {
    await req(`/api/agent/approvals/${appFixedRun}/respond`, { method: 'POST', body: { approve: true } });
  }
  const fixedExec = await req('/api/agent/terminal/execute', {
    method: 'POST',
    headers: authHeaders,
    body: { command: 'python3 test_failing_sample.py', approvalId: appFixedRun },
  });
  console.log(`[TEST 8 FIXED RUN EXIT]: ${fixedExec.data?.result?.exitCode}`);
  console.log(`[TEST 8 FIXED RUN STDOUT]: ${fixedExec.data?.result?.stdout?.trim()}`);

  const pass8 = failExec.data?.result?.exitCode === 1 && fixedExec.data?.result?.exitCode === 0 && fixedExec.data?.result?.stdout?.includes('ALL_TESTS_PASSED');
  console.log(`[TEST 8 RESULT]: ${pass8 ? 'PASS' : 'FAIL'}`);

  if (!pass5 || !pass6 || !pass7 || !pass8) {
    process.exit(1);
  }
}

runTests5To8().catch((err) => {
  console.error('Tests 5-8 Failed:', err);
  process.exit(1);
});
