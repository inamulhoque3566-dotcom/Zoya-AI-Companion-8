const sharp = require('sharp');

async function inspectDarkSliver() {
  const { data, info } = await sharp('public/assets/images/avatars_3d/transparent/avatar_pastel_blue_knit_shorts.png')
    .raw()
    .toBuffer({ resolveWithObject: true });

  const w = info.width;
  const h = info.height;

  // Let's print out what x=460 to x=495 looks like between y=1400 and y=1530
  console.log('Columns 460..500 between y=1400..1530:');
  for (let y = 1400; y < 1530; y += 10) {
    let line = `y=${y}: `;
    for (let x = 460; x <= 495; x += 2) {
      const idx = (y * w + x) * 4;
      const r = data[idx], g = data[idx+1], b = data[idx+2], a = data[idx+3];
      if (a === 0) line += ' . ';
      else if (r < 50 && g < 50 && b < 50) line += ' # ';
      else line += ' L '; // Leg skin / shoe
    }
    console.log(line);
  }
}

inspectDarkSliver().catch(console.error);
