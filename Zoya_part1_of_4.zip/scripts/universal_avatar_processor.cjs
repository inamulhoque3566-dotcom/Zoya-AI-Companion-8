const fs = require('fs');
const path = require('path');
const sharp = require('sharp');

/**
 * Universal High-Fidelity Avatar Matte, Logo Cleanup & Grounding Engine
 * 
 * Master Cleanup Rules:
 * 1. REMOVE ALL DUPLICATE BACKGROUNDS:
 *    - Completely sweeps away studio backdrops, duplicate background rectangles, and border remnants.
 *    - Eliminates duplicate floor shadows around, under, and behind the feet.
 *    - Removes background gaps between legs/shoes.
 * 2. REMOVE ALL GOOGLE GEMINI LOGOS & WATERMARKS:
 *    - Automatically detects and removes all 48x48 Gemini sparkle/star watermarks and logos in corners/margins.
 *    - Zeros out any isolated watermark islands so no marks, patches, or remnants remain.
 * 3. 100% AVATAR & CLOTHING PROTECTION:
 *    - Preserves all dresses (midnight black, sapphire gown, emerald saree, pink knits, white aprons).
 *    - Zero unwanted holes, zero transparency inside clothing or shoes, zero distortion of original proportions.
 * 4. NATURAL FEET GROUNDING:
 *    - Locates the exact sole of the shoes (shoeBottomY) without trailing floor shadow.
 *    - Grounds the avatar firmly at the bottom row of the canvas (zero floating gap).
 * 5. GLOBAL COMPATIBILITY:
 *    - Applied across all 20 avatars, modular fallbacks, and all future uploaded avatars.
 */
async function processAvatarFlawless(inputPath, outputPath, options = {}) {
  const img = sharp(inputPath);
  const { data, info } = await img.removeAlpha().raw().toBuffer({ resolveWithObject: true });
  const W = info.width;
  const H = info.height;

  // 1. Analyze background profile from outer border perimeter
  let rSum = 0, gSum = 0, bSum = 0, count = 0;
  for (let x = 0; x < W; x += 4) {
    for (let y = 0; y < 8; y += 4) {
      const idx = (y * W + x) * 3;
      rSum += data[idx]; gSum += data[idx + 1]; bSum += data[idx + 2]; count++;
    }
  }
  const bgR = rSum / count, bgG = gSum / count, bgB = bSum / count;
  const luma = 0.299 * bgR + 0.587 * bgG + 0.114 * bgB;

  // Background classification
  const isChromaGreen = bgG > bgR + 25 && bgG > bgB + 25;
  const isChromaBlue = bgB > bgR + 30 && bgB > bgG + 30 && bgB > 120;
  const isLightBg = luma > 175;
  const isClassicGray = (isLightBg && luma < 225) || (Math.abs(bgR - 203) < 15 && Math.abs(bgG - 203) < 15);
  const isTealStudio = bgG > bgR + 5 && bgB > bgR + 10;

  function isFloorOrBg(r, g, b, y) {
    if (isChromaGreen) {
      return (g > r + 20 && g > b + 20) || (Math.abs(r - bgR) < 30 && Math.abs(g - bgG) < 30 && Math.abs(b - bgB) < 30);
    }
    if (isChromaBlue) {
      return (b > r + 25 && b > g + 25) || (Math.abs(r - bgR) < 30 && Math.abs(g - bgG) < 30 && Math.abs(b - bgB) < 30);
    }
    if (isClassicGray) {
      const isNeutral = Math.abs(r - g) <= 8 && Math.abs(r - b) <= 8 && Math.abs(g - b) <= 8;
      // Floor shadow region in lower section
      if (y > H * 0.70 && isNeutral && r >= 65 && r <= 225) return true;
      return isNeutral && r >= 170 && r <= 235;
    }
    if (isLightBg) {
      const isNeutral = Math.abs(r - g) <= 8 && Math.abs(r - b) <= 8 && Math.abs(g - b) <= 8;
      if (y > H * 0.70 && isNeutral && r >= 65 && r <= 225) return true;
      return isNeutral && r >= 215;
    }
    if (isTealStudio) {
      const dist = Math.sqrt((r - bgR)**2 + (g - bgG)**2 + (b - bgB)**2);
      if (dist < 25) return true;
      if (g >= r + 4 && b >= r + 8 && r <= 35 && g <= 55 && b <= 100) return true;
      if (y > H * 0.70 && r <= 32 && g <= 35 && b <= 52 && Math.abs(r - g) <= 10) return true;
      return false;
    }
    // Dark violet/navy studio
    const dist = Math.sqrt((r - bgR)**2 + (g - bgG)**2 + (b - bgB)**2);
    if (dist < 28) return true;
    if (b >= r + 8 && b >= g + 8 && r <= 40 && g <= 32 && b <= 95) return true;
    if (y > H * 0.70 && r <= 35 && g <= 30 && b <= 65 && Math.abs(r - g) <= 12) return true;
    return false;
  }

  // 2. Pre-detect and mask any Google Gemini watermarks / logos
  // Gemini watermarks: ~48x48 pixel icons located in outer corners
  const isWatermark = new Uint8Array(W * H);
  for (const corner of ['BR', 'BL', 'TR']) {
    const minX = corner.includes('R') ? Math.floor(W * 0.65) : 0;
    const maxX = corner.includes('R') ? W : Math.floor(W * 0.35);
    const minY = corner.includes('B') ? Math.floor(H * 0.65) : 0;
    const maxY = corner.includes('B') ? H : Math.floor(H * 0.35);

    let edgePixels = [];
    for (let y = minY; y < maxY; y++) {
      for (let x = minX; x < maxX; x++) {
        const idx = (y * W + x) * 3;
        const r = data[idx], g = data[idx + 1], b = data[idx + 2];
        const rR = data[(y * W + Math.min(W - 1, x + 1)) * 3];
        const rD = data[(Math.min(H - 1, y + 1) * W + x) * 3];
        const grad = Math.abs(r - rR) + Math.abs(r - rD);
        if (grad > 20) edgePixels.push({ x, y });
      }
    }

    if (edgePixels.length > 20 && edgePixels.length < 600) {
      let cMinX = W, cMaxX = 0, cMinY = H, cMaxY = 0;
      for (const p of edgePixels) {
        if (p.x < cMinX) cMinX = p.x;
        if (p.x > cMaxX) cMaxX = p.x;
        if (p.y < cMinY) cMinY = p.y;
        if (p.y > cMaxY) cMaxY = p.y;
      }
      const boxW = cMaxX - cMinX + 1, boxH = cMaxY - cMinY + 1;
      if (boxW >= 25 && boxW <= 80 && boxH >= 25 && boxH <= 80) {
        // Expand watermark mask with safety margin to completely erase all logo remnants
        for (let y = Math.max(0, cMinY - 12); y <= Math.min(H - 1, cMaxY + 12); y++) {
          for (let x = Math.max(0, cMinX - 12); x <= Math.min(W - 1, cMaxX + 12); x++) {
            isWatermark[y * W + x] = 1;
          }
        }
      }
    }
  }

  // 3. Locate exact shoe sole boundary (discarding empty floor shadow beneath shoes)
  let shoeBottomY = H - 1;
  for (let y = H - 1; y >= Math.floor(H * 0.70); y--) {
    let highContrastInRow = 0;
    let distinctColorCount = 0;
    for (let x = 10; x < W - 10; x++) {
      if (isWatermark[y * W + x]) continue;
      const idx = (y * W + x) * 3;
      const r = data[idx], g = data[idx + 1], b = data[idx + 2];
      const rR = data[(y * W + x + 1) * 3];
      const gR = data[(y * W + x + 1) * 3 + 1];
      const bR = data[(y * W + x + 1) * 3 + 2];
      const edgeMag = Math.abs(r - rR) + Math.abs(g - gR) + Math.abs(b - bR);
      if (edgeMag > 22) highContrastInRow++;
      if (!isFloorOrBg(r, g, b, y)) distinctColorCount++;
    }
    if (highContrastInRow >= 8 && distinctColorCount >= 10) {
      shoeBottomY = y;
      break;
    }
  }

  // 4. Row-by-Row Silhouette Boundary Detection
  const leftBounds = new Int32Array(H);
  const rightBounds = new Int32Array(H);
  let minY = H;

  for (let y = 0; y <= shoeBottomY; y++) {
    let l = 0;
    while (l < W && (isWatermark[y * W + l] || isFloorOrBg(data[(y * W + l) * 3], data[(y * W + l) * 3 + 1], data[(y * W + l) * 3 + 2], y))) {
      l++;
    }

    let r = W - 1;
    while (r >= l && (isWatermark[y * W + r] || isFloorOrBg(data[(y * W + r) * 3], data[(y * W + r) * 3 + 1], data[(y * W + r) * 3 + 2], y))) {
      r--;
    }

    leftBounds[y] = l;
    rightBounds[y] = r;

    if (r - l >= 6 && y < minY) {
      minY = y;
    }
  }

  if (minY >= shoeBottomY) {
    minY = 0;
    shoeBottomY = H - 1;
  }

  // 5. Generate pristine alpha mask:
  // - Mark all pixels outside [leftBounds, rightBounds] as background (alpha = 0)
  // - Clear background between legs/feet
  // - Watermark pixels zeroed out
  const mask = new Uint8Array(W * H);
  for (let y = minY; y <= shoeBottomY; y++) {
    const l = leftBounds[y], r = rightBounds[y];
    for (let x = l; x <= r; x++) {
      if (isWatermark[y * W + x]) continue;

      // In lower 35% of avatar (legs & feet region):
      // Clean duplicate floor shadow / background between separated legs
      if (y >= minY + (shoeBottomY - minY) * 0.65) {
        const idx = (y * W + x) * 3;
        const rC = data[idx], gC = data[idx + 1], bC = data[idx + 2];
        if (isFloorOrBg(rC, gC, bC, y)) {
          continue; // Leave as background between legs
        }
      }

      mask[y * W + x] = 255; // 100% solid opacity
    }
  }

  // 6. Connected Component Analysis to purge any disconnected watermark remnants
  const visited = new Uint8Array(W * H);
  const components = [];
  for (let y = minY; y <= shoeBottomY; y++) {
    for (let x = 0; x < W; x++) {
      const idx = y * W + x;
      if (mask[idx] === 255 && !visited[idx]) {
        let count = 0;
        const q = [idx];
        visited[idx] = 1;
        let head = 0;
        while (head < q.length) {
          const curr = q[head++];
          count++;
          const cx = curr % W;
          const cy = Math.floor(curr / W);
          const nbs = [curr - 1, curr + 1, curr - W, curr + W];
          for (const nb of nbs) {
            if (nb >= 0 && nb < W * H && !visited[nb] && mask[nb] === 255) {
              visited[nb] = 1;
              q.push(nb);
            }
          }
        }
        components.push({ count, pixels: q });
      }
    }
  }

  // Retain only the main avatar body component(s), zero out small disconnected islands (< 1800 px)
  components.sort((a, b) => b.count - a.count);
  for (let i = 1; i < components.length; i++) {
    if (components[i].count < 1800) {
      for (const pix of components[i].pixels) {
        mask[pix] = 0;
      }
    }
  }

  // 7. Grounding and Screen-Framing:
  // Re-verify the lowest row containing non-zero mask pixels to ensure perfect ground contact
  let trueBottom = 0;
  for (let y = shoeBottomY; y >= minY; y--) {
    let rowCount = 0;
    for (let x = 0; x < W; x++) {
      if (mask[y * W + x] === 255) rowCount++;
    }
    if (rowCount >= 2) {
      trueBottom = y;
      break;
    }
  }

  if (trueBottom <= minY) trueBottom = shoeBottomY;

  // Preserve up to 8px headroom above headTopY
  const cropTop = Math.max(0, minY - 8);
  const cropBottom = trueBottom; // Feet rest solidly on the ground baseline
  const cropHeight = cropBottom - cropTop + 1;
  const cropWidth = W;

  // 8. Assemble Full HD output with pure color preservation
  const outRgba = new Uint8Array(cropWidth * cropHeight * 4);
  for (let cy = 0; cy < cropHeight; cy++) {
    const y = cropTop + cy;
    for (let x = 0; x < cropWidth; x++) {
      const srcIdx = y * W + x;
      const dstIdx = (cy * cropWidth + x) * 4;
      const src3 = srcIdx * 3;

      if (mask[srcIdx] === 255) {
        outRgba[dstIdx] = data[src3];
        outRgba[dstIdx + 1] = data[src3 + 1];
        outRgba[dstIdx + 2] = data[src3 + 2];
        outRgba[dstIdx + 3] = 255;
      } else {
        outRgba[dstIdx + 3] = 0;
      }
    }
  }

  // 9. Subpixel anti-aliasing feathering on outermost 1-pixel boundary
  for (let cy = 0; cy < cropHeight; cy++) {
    for (let x = 0; x < cropWidth; x++) {
      const idx4 = (cy * cropWidth + x) * 4;
      if (outRgba[idx4 + 3] === 255) {
        let bgNeighbors = 0;
        for (let dy = -1; dy <= 1; dy++) {
          for (let dx = -1; dx <= 1; dx++) {
            const ny = cy + dy, nx = x + dx;
            if (ny >= 0 && ny < cropHeight && nx >= 0 && nx < cropWidth) {
              if (outRgba[(ny * cropWidth + nx) * 4 + 3] === 0) bgNeighbors++;
            }
          }
        }
        if (bgNeighbors > 0) {
          outRgba[idx4 + 3] = Math.round(255 * (1 - (bgNeighbors / 8) * 0.4));
        }
      }
    }
  }

  // 10. Write pristine PNG
  const outDir = path.dirname(outputPath);
  if (!fs.existsSync(outDir)) {
    fs.mkdirSync(outDir, { recursive: true });
  }

  await sharp(outRgba, {
    raw: { width: cropWidth, height: cropHeight, channels: 4 }
  })
    .png({ compressionLevel: 9 })
    .toFile(outputPath);

  console.log(
    `[MasterCleanup] ${path.basename(outputPath)}: Grounded at bottom (y=${cropBottom}), size: ${cropWidth}x${cropHeight}, head: y=${minY}, original: ${W}x${H}`
  );

  return {
    width: cropWidth,
    height: cropHeight,
    aspectRatio: cropWidth / cropHeight,
    headTopY: minY - cropTop,
    feetBottomY: cropHeight - 1,
    originalWidth: W,
    originalHeight: H,
    groundGrounded: true,
  };
}

module.exports = { processAvatarFlawless };
