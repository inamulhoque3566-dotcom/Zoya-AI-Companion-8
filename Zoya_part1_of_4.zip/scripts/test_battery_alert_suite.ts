import fs from 'fs';
import path from 'path';
import { BatteryAlertSystem } from '../src/services/battery/batteryAlertSystem';
import { BATTERY_ALERT_CONFIG } from '../src/services/battery/batteryAlertConfig';
import { micStateMachine } from '../src/services/speech/MicStateMachine';

console.log('================================================================');
console.log('🧪 COMPREHENSIVE BATTERY, CHARGING & FLIGHT MODE TEST SUITE');
console.log('================================================================\n');

// -----------------------------------------------------------------------------
// 1. Static Configuration & Dialogue Audit
// -----------------------------------------------------------------------------
console.log('--- TEST GROUP 1: Static Config & Dialogue Integrity ---');
const configFilePath = path.resolve('src/services/battery/batteryAlertConfig.ts');
if (!fs.existsSync(configFilePath)) {
  console.error('❌ batteryAlertConfig.ts not found');
  process.exit(1);
}
console.log('✅ batteryAlertConfig.ts exists.');

// Check exact phrases required by User Request:
const requiredDialogues = [
  {
    name: 'Charger in normal (<95%)',
    expected: 'Charging shuru ho gayi, power aa gaya. Abhi battery {PERCENT} percent hai.',
    actual: BATTERY_ALERT_CONFIG.dialogues.chargerConnectedNormal,
  },
  {
    name: 'Charger in full (>=95%)',
    expected: 'Charging shuru ho gayi, power aa gaya. Battery already {PERCENT} percent hai, lagbhag full.',
    actual: BATTERY_ALERT_CONFIG.dialogues.chargerConnectedFull,
  },
  {
    name: 'Charger unplugged',
    expected: 'Power off ho gaya, charger nikal diya gaya. Abhi battery {PERCENT} percent hai.',
    actual: BATTERY_ALERT_CONFIG.dialogues.chargerDisconnected,
  },
  {
    name: '20% low battery warning',
    expected: 'Boss, battery sirf {PERCENT} percent bachi hai. Kripya charger laga dijiye, warna jaldi band ho sakta hai.',
    actual: BATTERY_ALERT_CONFIG.dialogues.lowBattery20,
  },
  {
    name: '10% low battery warning',
    expected: 'Boss, battery bahut kam hai, sirf {PERCENT} percent! Abhi charger lagaiye, warna phone band ho jayega.',
    actual: BATTERY_ALERT_CONFIG.dialogues.lowBattery10,
  },
  {
    name: '3% critical low warning',
    expected: 'Boss, emergency! Battery sirf {PERCENT} percent hai, phone kabhi bhi band ho sakta hai. Turant charger lagaiye!',
    actual: BATTERY_ALERT_CONFIG.dialogues.lowBattery3,
  },
  {
    name: 'Flight mode ON',
    expected: 'Flight mode on ho gaya. Network aur internet band ho gaye hain.',
    actual: BATTERY_ALERT_CONFIG.dialogues.flightModeOn,
  },
  {
    name: 'Flight mode OFF',
    expected: 'Flight mode off ho gaya. Network wapas aa raha hai.',
    actual: BATTERY_ALERT_CONFIG.dialogues.flightModeOff,
  },
  {
    name: 'App Installed',
    expected: '{APP_NAME} install ho gaya.',
    actual: BATTERY_ALERT_CONFIG.dialogues.appInstalled,
  },
  {
    name: 'App Uninstalled',
    expected: '{APP_NAME} uninstall ho gaya.',
    actual: BATTERY_ALERT_CONFIG.dialogues.appUninstalled,
  },
];

for (const d of requiredDialogues) {
  if (d.actual !== d.expected) {
    console.error(`❌ Mismatch in dialogue [${d.name}]:\n  Expected: "${d.expected}"\n  Got:      "${d.actual}"`);
    process.exit(1);
  }
  console.log(`✅ Dialogue verified: [${d.name}] -> "${d.actual}"`);
}

// -----------------------------------------------------------------------------
// 2. Unit Tests with Simulated Battery & Airplane-Mode Sources
// -----------------------------------------------------------------------------
console.log('\n--- TEST GROUP 2: State Machine & Event Processing Tests ---');

// In-memory test harness
const spokenAnnouncements: Array<{ text: string; offline: boolean; priority: string; time: number }> = [];

class TestableBatteryAlertSystem extends BatteryAlertSystem {
  constructor() {
    super();
  }

  // Override offline TTS to capture directly in test harness
  public override speakOffline(text: string, onDone?: () => void): void {
    spokenAnnouncements.push({ text, offline: true, priority: 'normal', time: Date.now() });
    onDone?.();
  }
}

const system = new TestableBatteryAlertSystem();
// Register primary speaker
system.registerSpeaker((text: string, onDone?: () => void) => {
  spokenAnnouncements.push({ text, offline: false, priority: 'normal', time: Date.now() });
  onDone?.();
});

// Setup mock storage and enable all flags
system.setEnabled(true);
system.setChargingAnnouncementsEnabled(true);
system.setLowBatteryWarningsEnabled(true);
system.setFlightModeAnnouncementsEnabled(true);
system.setAppInstallAnnouncementsEnabled(true);

function clearSpoken() {
  spokenAnnouncements.length = 0;
  (system as any).isCurrentlySpeaking = false;
  (system as any).announcementQueue = [];
  (micStateMachine as any).currentState = 'STANDBY';
  (micStateMachine as any).activeTtsSource = undefined;
}

// Test 2.1: App start / open / unlock must produce ZERO speech when battery > 20%
clearSpoken();
system.handleBatteryUpdate(80, false, true);
if (spokenAnnouncements.length > 0) {
  console.error(`❌ Opening app at 80% should be SILENT, but spoke: "${spokenAnnouncements[0].text}"`);
  process.exit(1);
}
console.log('✅ App open / unlock at 80% is completely silent (no annoyance).');

// Test 2.2: Plug in charger at 45% -> Correct text and percent
clearSpoken();
(system as any).lastChargingToggleTime = 0;
(system as any).lastChargingState = false;
system.handleBatteryUpdate(45, true, false);
if (spokenAnnouncements.length !== 1) {
  console.error(`❌ Expected 1 announcement on charger connect, got ${spokenAnnouncements.length}`);
  process.exit(1);
}
const expectedConnected45 = 'Charging shuru ho gayi, power aa gaya. Abhi battery 45 percent hai.';
if (spokenAnnouncements[0].text !== expectedConnected45) {
  console.error(`❌ Text mismatch on 45% plug in:\n  Expected: "${expectedConnected45}"\n  Got:      "${spokenAnnouncements[0].text}"`);
  process.exit(1);
}
console.log(`✅ Plug in at 45% verified: "${spokenAnnouncements[0].text}"`);

// Test 2.3: Plug in at 96% -> Correct full text
clearSpoken();
(system as any).lastChargingToggleTime = 0;
(system as any).lastChargingState = false;
system.handleBatteryUpdate(96, true, false);
const expectedConnected96 = 'Charging shuru ho gayi, power aa gaya. Battery already 96 percent hai, lagbhag full.';
if (spokenAnnouncements[0]?.text !== expectedConnected96) {
  console.error(`❌ Text mismatch on 96% full plug in:\n  Expected: "${expectedConnected96}"\n  Got:      "${spokenAnnouncements[0]?.text}"`);
  process.exit(1);
}
console.log(`✅ Plug in at 96% full verified: "${spokenAnnouncements[0].text}"`);

// Test 2.4: Unplug at 60% -> Correct text and percent
clearSpoken();
(system as any).lastChargingToggleTime = 0;
(system as any).lastChargingState = true;
system.handleBatteryUpdate(60, false, false);
const expectedUnplug60 = 'Power off ho gaya, charger nikal diya gaya. Abhi battery 60 percent hai.';
if (spokenAnnouncements[0]?.text !== expectedUnplug60) {
  console.error(`❌ Text mismatch on unplug at 60%:\n  Expected: "${expectedUnplug60}"\n  Got:      "${spokenAnnouncements[0]?.text}"`);
  process.exit(1);
}
console.log(`✅ Unplug at 60% verified: "${spokenAnnouncements[0].text}"`);

// Test 2.5: Falling through 20, 10, 3 (each once per discharge cycle)
clearSpoken();
(system as any).lastChargingState = false;
system.handleBatteryUpdate(20, false, false);
const expected20 = 'Boss, battery sirf 20 percent bachi hai. Kripya charger laga dijiye, warna jaldi band ho sakta hai.';
if (spokenAnnouncements[0]?.text !== expected20) {
  console.error(`❌ 20% warning mismatch: got "${spokenAnnouncements[0]?.text}"`);
  process.exit(1);
}
console.log('✅ 20% warning spoken once.');

// Repeated update at 19% or 20% should NOT speak 20% again
clearSpoken();
system.handleBatteryUpdate(19, false, false);
if (spokenAnnouncements.length !== 0) {
  console.error('❌ Repeated 20% warning triggered in same discharge cycle!');
  process.exit(1);
}
console.log('✅ Duplicate 20% warning blocked in same cycle.');

// Fall to 10%
clearSpoken();
system.handleBatteryUpdate(10, false, false);
const expected10 = 'Boss, battery bahut kam hai, sirf 10 percent! Abhi charger lagaiye, warna phone band ho jayega.';
if (spokenAnnouncements[0]?.text !== expected10) {
  console.error(`❌ 10% warning mismatch: got "${spokenAnnouncements[0]?.text}"`);
  process.exit(1);
}
console.log('✅ 10% warning spoken once.');

// Fall to 3%
clearSpoken();
system.handleBatteryUpdate(3, false, false);
const expected3 = 'Boss, emergency! Battery sirf 3 percent hai, phone kabhi bhi band ho sakta hai. Turant charger lagaiye!';
if (spokenAnnouncements[0]?.text !== expected3) {
  console.error(`❌ 3% critical warning mismatch: got "${spokenAnnouncements[0]?.text}"`);
  process.exit(1);
}
console.log('✅ 3% critical emergency warning spoken once.');

// Test 2.6: Jump from 21% to 9% (only the 10% warning, NOT both)
system.resetDischargeCycle();
clearSpoken();
(system as any).lastChargingState = false;
system.handleBatteryUpdate(21, false, false);
clearSpoken();
// Jump straight to 9%:
system.handleBatteryUpdate(9, false, false);
if (spokenAnnouncements.length !== 1) {
  console.error(`❌ Jump 21% -> 9% should produce exactly 1 warning (10%), but got ${spokenAnnouncements.length}`);
  process.exit(1);
}
if (!spokenAnnouncements[0].text.includes('battery bahut kam hai') || !spokenAnnouncements[0].text.includes('9 percent')) {
  console.error(`❌ Jump 21% -> 9% should speak 10% warning with 9%, but spoke: "${spokenAnnouncements[0].text}"`);
  process.exit(1);
}
console.log(`✅ Jump from 21% to 9% correctly spoke only the most severe threshold (10% template with 9%): "${spokenAnnouncements[0].text}"`);

// Jump straight to 2%
system.resetDischargeCycle();
clearSpoken();
(system as any).lastChargingState = false;
system.handleBatteryUpdate(25, false, false);
clearSpoken();
system.handleBatteryUpdate(2, false, false);
if (spokenAnnouncements.length !== 1 || !spokenAnnouncements[0].text.includes('emergency')) {
  console.error(`❌ Jump to 2% should speak only 3% critical warning, got: "${spokenAnnouncements[0]?.text}"`);
  process.exit(1);
}
console.log('✅ Jump to 2% correctly spoke only 3% critical emergency warning.');

// Test 2.7: Warning while charging must be SILENT
system.resetDischargeCycle();
clearSpoken();
(system as any).lastChargingState = true;
system.handleBatteryUpdate(10, true, false); // plugged in and at 10%
if (spokenAnnouncements.some(a => a.text.includes('Boss, battery bahut kam hai'))) {
  console.error('❌ Low-battery warning was incorrectly spoken while CHARGING!');
  process.exit(1);
}
console.log('✅ While charging, low-battery warnings are strictly SILENT.');

// Test 2.8: Rapid plug/unplug spam (debounced within 2 seconds)
system.resetDischargeCycle();
clearSpoken();
(system as any).lastChargingToggleTime = 0;
(system as any).lastChargingState = false;
system.handleBatteryUpdate(50, true, false); // 1st plug -> spoken
const countAfterFirst = spokenAnnouncements.length;
system.handleBatteryUpdate(50, false, false); // rapid toggle (<2s) -> ignored
system.handleBatteryUpdate(50, true, false);  // rapid toggle (<2s) -> ignored
if (spokenAnnouncements.length !== countAfterFirst) {
  console.error(`❌ Debounce failed! Rapid plug spam produced ${spokenAnnouncements.length} announcements instead of 1.`);
  process.exit(1);
}
console.log('✅ Rapid plug/unplug spam correctly debounced within 2 seconds.');

// Test 2.9: Flight Mode ON then OFF (offline TTS used)
clearSpoken();
(system as any).lastFlightModeToggleTime = 0;
(system as any).lastFlightModeState = null;
system.handleFlightModeUpdate(true, false);
if (spokenAnnouncements.length !== 1) {
  console.error('❌ Flight mode ON announcement failed');
  process.exit(1);
}
if (spokenAnnouncements[0].text !== BATTERY_ALERT_CONFIG.dialogues.flightModeOn) {
  console.error(`❌ Flight mode ON text mismatch: got "${spokenAnnouncements[0].text}"`);
  process.exit(1);
}
if (!spokenAnnouncements[0].offline) {
  console.error('❌ Flight mode ON must use offline TTS!');
  process.exit(1);
}
console.log('✅ Flight mode ON verified with OFFLINE TTS: "' + spokenAnnouncements[0].text + '"');

clearSpoken();
(system as any).lastFlightModeToggleTime = 0;
(system as any).lastFlightModeState = true;
system.handleFlightModeUpdate(false, false);
if (spokenAnnouncements[0]?.text !== BATTERY_ALERT_CONFIG.dialogues.flightModeOff) {
  console.error(`❌ Flight mode OFF text mismatch: got "${spokenAnnouncements[0]?.text}"`);
  process.exit(1);
}
if (!spokenAnnouncements[0].offline) {
  console.error('❌ Flight mode OFF must use offline TTS!');
  process.exit(1);
}
console.log('✅ Flight mode OFF verified with OFFLINE TTS: "' + spokenAnnouncements[0].text + '"');

// Test 2.10: Flight mode toggle spam (debounced within 2 seconds)
clearSpoken();
(system as any).lastFlightModeToggleTime = Date.now();
(system as any).lastFlightModeState = false;
system.handleFlightModeUpdate(true, false); // rapid change within debounceMs
if (spokenAnnouncements.length > 0) {
  console.error('❌ Flight mode debounce failed!');
  process.exit(1);
}
console.log('✅ Flight mode toggle spam correctly debounced within 2 seconds.');

// Test 2.11: App Installed & Uninstalled announcements
clearSpoken();
(system as any).lastAppEventTime = 0;
(system as any).lastAppEventKey = '';
system.handleAppInstalled('WhatsApp');
if (spokenAnnouncements[0]?.text !== 'WhatsApp install ho gaya.') {
  console.error(`❌ App install announcement mismatch: got "${spokenAnnouncements[0]?.text}"`);
  process.exit(1);
}
console.log('✅ App installed announcement verified: "' + spokenAnnouncements[0].text + '"');

clearSpoken();
(system as any).lastAppEventTime = 0;
(system as any).lastAppEventKey = '';
system.handleAppUninstalled('Instagram');
if (spokenAnnouncements[0]?.text !== 'Instagram uninstall ho gaya.') {
  console.error(`❌ App uninstall announcement mismatch: got "${spokenAnnouncements[0]?.text}"`);
  process.exit(1);
}
console.log('✅ App uninstalled announcement verified: "' + spokenAnnouncements[0].text + '"');

// Test 2.12: Queueing when assistant is speaking
clearSpoken();
(system as any).isCurrentlySpeaking = true;
(system as any).currentSpeakingPriority = 'normal';
(system as any).queueAnnouncement('Queued message 1', 'normal', false, 'test');
if (spokenAnnouncements.length > 0) {
  console.error('❌ Message should be queued while assistant is speaking!');
  process.exit(1);
}
if ((system as any).announcementQueue.length !== 1) {
  console.error('❌ Message was not pushed to announcementQueue!');
  process.exit(1);
}
console.log('✅ Announcement correctly queued while assistant is busy.');

// Test 2.13: 3% Critical warning interrupts lower priority announcement
(system as any).queueAnnouncement(
  BATTERY_ALERT_CONFIG.dialogues.lowBattery3.replace('{PERCENT}', '3'),
  'critical',
  false,
  'critical test'
);
// Critical warning immediately interrupts!
if (spokenAnnouncements.length !== 1 || !spokenAnnouncements[0].text.includes('emergency')) {
  console.error('❌ 3% critical warning did not interrupt lower priority speech!');
  process.exit(1);
}
console.log('✅ 3% critical emergency warning successfully interrupts lower priority speech.');

// Test 2.14: Stale announcement older than 15s is dropped
clearSpoken();
(system as any).isCurrentlySpeaking = false;
(system as any).announcementQueue = [
  {
    id: 'stale_item',
    text: 'Old message',
    priority: 'normal',
    isOfflineTts: false,
    createdAt: Date.now() - 20000, // 20s old (> 15s)
  },
];
(system as any).processNextInQueue();
if (spokenAnnouncements.length > 0) {
  console.error('❌ Stale announcement older than 15s was NOT dropped!');
  process.exit(1);
}
console.log('✅ Stale announcement (>15s) correctly dropped from queue.');

// Test 2.15: Sub-Toggles (when turned off, silent)
clearSpoken();
system.setChargingAnnouncementsEnabled(false);
(system as any).lastChargingToggleTime = 0;
(system as any).lastChargingState = false;
system.handleBatteryUpdate(70, true, false);
if (spokenAnnouncements.length > 0) {
  console.error('❌ Charging announcement was spoken even when toggle was OFF!');
  process.exit(1);
}
console.log('✅ Charging announcement toggle OFF is strictly SILENT.');

clearSpoken();
system.setLowBatteryWarningsEnabled(false);
system.resetDischargeCycle();
(system as any).lastChargingState = false;
system.handleBatteryUpdate(20, false, false);
if (spokenAnnouncements.length > 0) {
  console.error('❌ Low-battery warning was spoken even when toggle was OFF!');
  process.exit(1);
}
console.log('✅ Low-battery warning toggle OFF is strictly SILENT.');

clearSpoken();
system.setFlightModeAnnouncementsEnabled(false);
(system as any).lastFlightModeToggleTime = 0;
(system as any).lastFlightModeState = null;
system.handleFlightModeUpdate(true, false);
if (spokenAnnouncements.length > 0) {
  console.error('❌ Flight mode announcement was spoken even when toggle was OFF!');
  process.exit(1);
}
console.log('✅ Flight mode toggle OFF is strictly SILENT.');

clearSpoken();
system.setAppInstallAnnouncementsEnabled(false);
(system as any).lastAppEventTime = 0;
(system as any).lastAppEventKey = '';
system.handleAppInstalled('Telegram');
if (spokenAnnouncements.length > 0) {
  console.error('❌ App install announcement was spoken even when toggle was OFF!');
  process.exit(1);
}
console.log('✅ App install toggle OFF is strictly SILENT.');

// -----------------------------------------------------------------------------
// 3. Android Native Code Verification
// -----------------------------------------------------------------------------
console.log('\n--- TEST GROUP 3: Android Native Implementation Audit ---');

const bridgePath = path.resolve('android/app/src/main/java/com/openclaw/assistant/bridge/AndroidBridge.kt');
const bridgeContent = fs.readFileSync(bridgePath, 'utf8');

const bridgeRequiredTokens = [
  'speakOffline',
  'TextToSpeech',
  'isAirplaneMode',
  'setChargingAnnouncementsEnabled',
  'isChargingAnnouncementsEnabled',
  'setLowBatteryWarningsEnabled',
  'isLowBatteryWarningsEnabled',
  'setFlightModeAnnouncementsEnabled',
  'isFlightModeAnnouncementsEnabled',
  'setAppInstallAnnouncementsEnabled',
  'isAppInstallAnnouncementsEnabled',
  'getBatteryLevel',
  'isCharging',
  'getBatteryStatus',
];

for (const token of bridgeRequiredTokens) {
  if (!bridgeContent.includes(token)) {
    console.error(`❌ AndroidBridge.kt missing required method/token: ${token}`);
    process.exit(1);
  }
}
console.log('✅ AndroidBridge.kt native methods (offline TTS, airplane mode, toggles) verified.');

const mainActPath = path.resolve('android/app/src/main/java/com/openclaw/assistant/MainActivity.kt');
const mainActContent = fs.readFileSync(mainActPath, 'utf8');

const mainActRequiredTokens = [
  'registerBatteryMonitor',
  'unregisterBatteryMonitor',
  'registerAirplaneModeReceiver',
  'unregisterAirplaneModeReceiver',
  'registerPackageReceiver',
  'unregisterPackageReceiver',
  'ACTION_AIRPLANE_MODE_CHANGED',
  'ACTION_PACKAGE_ADDED',
  'ACTION_PACKAGE_REMOVED',
  'airplane-mode-changed',
  'app-installed',
  'app-uninstalled',
  'battery-status-changed',
];

for (const token of mainActRequiredTokens) {
  if (!mainActContent.includes(token)) {
    console.error(`❌ MainActivity.kt missing required receiver/token: ${token}`);
    process.exit(1);
  }
}
console.log('✅ MainActivity.kt native runtime broadcast receivers verified.');

const manifestPath = path.resolve('android/app/src/main/AndroidManifest.xml');
const manifestContent = fs.readFileSync(manifestPath, 'utf8');
if (!manifestContent.includes('android.permission.QUERY_ALL_PACKAGES')) {
  console.error('❌ AndroidManifest.xml missing QUERY_ALL_PACKAGES permission');
  process.exit(1);
}
console.log('✅ AndroidManifest.xml QUERY_ALL_PACKAGES verified.');

console.log('\n================================================================');
console.log('🎉 ALL BATTERY, CHARGING, FLIGHT MODE & APP TESTS PASSED 100%!');
console.log('================================================================\n');
process.exit(0);
