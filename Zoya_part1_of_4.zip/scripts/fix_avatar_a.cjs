const sharp = require('sharp');
const fs = require('fs');

async function fixAvatarA() {
  console.log('=== FIXING AVATAR A (COZY PASTEL) ===');

  // Load pristine source
  const srcImg = sharp('public/assets/aistudio/file_00000000eb7881fa8a888c25bfc4c0f7_32dd4f88.png');
  const { data, info } = await srcImg.raw().toBuffer({ resolveWithObject: true });
  const w = info.width;
  const h = info.height;

  const out = Buffer.from(data);

  // 1. Clean noise with alpha <= 15
  let lowAlphaCleaned = 0;
  for (let i = 0; i < out.length; i += 4) {
    if (out[i + 3] <= 15) {
      out[i + 3] = 0;
      lowAlphaCleaned++;
    }
  }
  console.log(`Cleaned faint alpha <= 15: ${lowAlphaCleaned} pixels`);

  // 2. Remove isolated stray clusters outside the avatar's legs below y = 940:
  // Leg bounds:
  // Left leg (viewer left): x ~ 370..475
  // Right leg (viewer right): x ~ 485..595
  // Ground shoe contact: y up to 1665
  // Any stray pixels with x < 365 or x > 605 for y >= 940 are outside the legs
  let strayRemoved = 0;
  for (let y = 940; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const idx = (y * w + x) * 4;
      if (out[idx + 3] > 0) {
        if (x < 365 || x > 605) {
          out[idx + 3] = 0;
          strayRemoved++;
        }
      }
    }
  }
  console.log(`Removed stray pixels outside legs: ${strayRemoved} pixels`);

  // 3. Remove ground shadow below shoes (y >= 1664)
  // Check rows 1660..h
  let shadowRemoved = 0;
  for (let y = 1662; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const idx = (y * w + x) * 4;
      if (out[idx + 3] > 0) {
        const r = out[idx], g = out[idx + 1], b = out[idx + 2];
        // If below soles or dark/grey floor shadow
        if (y >= 1666 || (r < 150 && g < 150 && b < 150 && Math.abs(r - g) < 20 && Math.abs(g - b) < 20)) {
          out[idx + 3] = 0;
          shadowRemoved++;
        }
      }
    }
  }
  console.log(`Removed ground shadow under shoes: ${shadowRemoved} pixels`);

  // 4. Remove dark vertical sliver and leftover background between the ankles/legs (y: 1360..1525, x: 468..490)
  // Let's verify each pixel in the inter-leg gap:
  // If r < 60 && g < 60 && b < 60, it's the dark vertical sliver!
  let sliverRemoved = 0;
  for (let y = 1360; y <= 1530; y++) {
    for (let x = 465; x <= 495; x++) {
      const idx = (y * w + x) * 4;
      if (out[idx + 3] > 0) {
        const r = out[idx], g = out[idx + 1], b = out[idx + 2];
        if (r < 65 && g < 65 && b < 65) {
          out[idx + 3] = 0;
          sliverRemoved++;
        }
      }
    }
  }
  console.log(`Removed dark vertical sliver pixels between legs: ${sliverRemoved} pixels`);

  // 5. Save perfected transparent PNG
  const outPngPath = 'public/assets/images/avatars_3d/transparent/avatar_pastel_blue_knit_shorts.png';
  const outPngBuf = await sharp(out, { raw: { width: w, height: h, channels: 4 } })
    .png({ compressionLevel: 8 })
    .toBuffer();

  fs.writeFileSync(outPngPath, outPngBuf);
  console.log(`✓ Saved ${outPngPath}`);

  // Sync to modular fallback
  const modularPath = 'public/assets/images/avatars_modular/avatar_pastel_blue_knit_shorts/body_skin.png';
  fs.writeFileSync(modularPath, outPngBuf);
  console.log(`✓ Synced ${modularPath}`);

  // Update preview JPG card
  const cardBgSvg = `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}">
    <defs>
      <radialGradient id="cardBg" cx="50%" cy="40%" r="65%">
        <stop offset="0%" stop-color="#1e1b4b"/>
        <stop offset="60%" stop-color="#0f172a"/>
        <stop offset="100%" stop-color="#020617"/>
      </radialGradient>
    </defs>
    <rect width="${w}" height="${h}" fill="url(#cardBg)"/>
  </svg>`;
  const cardBgBuf = Buffer.from(cardBgSvg);
  const jpgPath = 'public/assets/images/avatars_3d/avatar_pastel_blue_knit_shorts.jpg';
  await sharp(cardBgBuf)
    .resize(w, h)
    .composite([{ input: outPngBuf, top: 0, left: 0 }])
    .jpeg({ quality: 92 })
    .toFile(jpgPath);
  console.log(`✓ Updated card preview: ${jpgPath}`);

  // 6. Generate Verification Magenta Composite and Zoom on legs/feet
  const magenta = await sharp({
    create: { width: w, height: h, channels: 4, background: { r: 255, g: 0, b: 255, alpha: 1 } }
  }).png().toBuffer();

  const fullMagenta = await sharp(magenta)
    .composite([{ input: outPngBuf }])
    .png()
    .toBuffer();

  fs.writeFileSync('proof_artifacts/avatar_a_fixed_full_magenta.png', fullMagenta);

  // Zoom on legs, ankles and sneakers
  await sharp(fullMagenta)
    .extract({ left: 330, top: 920, width: 320, height: 750 })
    .toFile('proof_artifacts/avatar_a_fixed_legs_feet_zoom_magenta.png');

  console.log('✓ Proof artifacts created for Avatar A');
}

fixAvatarA().catch(console.error);
