const sharp = require('sharp');
const path = require('path');

async function testLegSeparation() {
  const srcPath = path.join(__dirname, '../src/assets/images/zoya_3d_sweater_glasses_1793764031303.jpg');
  const { data: origRgb, info } = await sharp(srcPath).removeAlpha().raw().toBuffer({ resolveWithObject: true });
  const W = info.width, H = info.height;

  // Let's inspect rows 1200, 1220, 1240, 1260, 1280, 1300, 1320
  for (const y of [1205, 1220, 1240, 1260, 1280, 1300, 1320]) {
    let rowStr = `y=${y}: `;
    for (let x = 320; x <= 460; x += 2) {
      const idx = (y * W + x) * 3;
      const r = origRgb[idx], g = origRgb[idx + 1], b = origRgb[idx + 2];
      const chroma = Math.max(Math.abs(r - g), Math.abs(r - b), Math.abs(g - b));
      // Background has chroma <= 5 and r > 165
      const isGreyBg = (chroma <= 6 && r >= 165);
      if (isGreyBg) {
        rowStr += '.';
      } else {
        rowStr += '#';
      }
    }
    console.log(rowStr);
  }
}
testLegSeparation().catch(console.error);
