const sharp = require('sharp');

async function inspectSareeZoomMetrics() {
  // Let's analyze the hem and feet in the original source
  const src = await sharp('public/assets/aistudio/file_00000000c0d4821189e14bf178224f8d_f1687d5b.png')
    .raw()
    .toBuffer({ resolveWithObject: true });

  const cur = await sharp('public/assets/images/avatars_3d/transparent/avatar_midnight_gold_zari_saree.png')
    .raw()
    .toBuffer({ resolveWithObject: true });

  const w = src.info.width;
  const h = src.info.height;

  // Let's check the bottom 150 rows (y=1386..1536)
  console.log('Comparing source and cur at bottom hem:');
  for (let y = 1450; y < h; y += 10) {
    let srcActive = 0, curActive = 0;
    for (let x = 0; x < w; x++) {
      if (src.data[(y * w + x) * 4 + 3] > 10) srcActive++;
      if (cur.data[(y * w + x) * 4 + 3] > 10) curActive++;
    }
    console.log(`y=${y}: srcActive=${srcActive}, curActive=${curActive}`);
  }

  // Let's inspect the sheer fabric area on the right side: x=650..850, y=500..1000
  let srcSemi = 0, curSemi = 0;
  for (let y = 500; y < 1000; y++) {
    for (let x = 650; x < 850; x++) {
      const idx = (y * w + x) * 4;
      const as = src.data[idx + 3];
      const ac = cur.data[idx + 3];
      if (as > 20 && as < 235) srcSemi++;
      if (ac > 20 && ac < 235) curSemi++;
    }
  }
  console.log(`Sheer pallu semi-alpha pixels in [650..850, 500..1000]: src=${srcSemi}, cur=${curSemi}`);
}

inspectSareeZoomMetrics().catch(console.error);
