import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import http from 'http';
import { spawnSync } from 'child_process';
import { agentPermissionGuard } from '../src/services/agent/agentPermissionGuard';
import { AgentCore } from '../src/services/agent/agentCore';

function makeHttpRequest(options: http.RequestOptions, postData?: string): Promise<{ statusCode: number; headers: http.IncomingHttpHeaders; body: string }> {
  return new Promise((resolve, reject) => {
    const req = http.request(options, (res) => {
      let data = '';
      res.on('data', (chunk) => { data += chunk; });
      res.on('end', () => {
        resolve({
          statusCode: res.statusCode || 0,
          headers: res.headers,
          body: data
        });
      });
    });
    req.on('error', (err) => reject(err));
    if (postData) {
      req.write(postData);
    }
    req.end();
  });
}

async function runPartA() {
  console.log('================================================================');
  console.log('PART A: QUICK FIXES RAW VERIFICATION');
  console.log('================================================================\n');

  // ITEM 1: Bootstrap Real HTTP Requests
  console.log('----------------------------------------------------------------');
  console.log('ITEM 1: Bootstrap Real HTTP Requests & Single-Use Pairing Code');
  console.log('----------------------------------------------------------------');
  
  // 1a: Request without pairing code
  const res1a = await makeHttpRequest({
    hostname: '127.0.0.1',
    port: 3000,
    path: '/api/agent/auth/token',
    method: 'POST',
    headers: { 'Content-Type': 'application/json' }
  }, JSON.stringify({}));
  console.log(`[1a Request without pairing code]`);
  console.log(`HTTP Status Code: ${res1a.statusCode}`);
  console.log(`HTTP Response:    ${res1a.body}`);

  // 1b: Obtain pairing code via UI simulation
  const res1b = await makeHttpRequest({
    hostname: '127.0.0.1',
    port: 3000,
    path: '/api/agent/auth/pairing-code',
    method: 'POST',
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120.0.0.0',
      'Content-Type': 'application/json'
    }
  }, JSON.stringify({}));
  const codeJson = JSON.parse(res1b.body);
  const pairingCode = codeJson.pairingCode;
  console.log(`\n[1b Obtained Pairing Code via browser session]`);
  console.log(`HTTP Status Code: ${res1b.statusCode}`);
  console.log(`Pairing Code:     ${pairingCode}`);

  // 1c: Request with valid pairing code
  const res1c = await makeHttpRequest({
    hostname: '127.0.0.1',
    port: 3000,
    path: '/api/agent/auth/token',
    method: 'POST',
    headers: { 'Content-Type': 'application/json' }
  }, JSON.stringify({ pairingCode }));
  console.log(`\n[1c Request with valid pairing code]`);
  console.log(`HTTP Status Code: ${res1c.statusCode}`);
  console.log(`HTTP Response:    ${res1c.body}`);

  // 1d: Replay the same consumed code
  const res1d = await makeHttpRequest({
    hostname: '127.0.0.1',
    port: 3000,
    path: '/api/agent/auth/token',
    method: 'POST',
    headers: { 'Content-Type': 'application/json' }
  }, JSON.stringify({ pairingCode }));
  console.log(`\n[1d Replaying already consumed pairing code]`);
  console.log(`HTTP Status Code: ${res1d.statusCode}`);
  console.log(`HTTP Response:    ${res1d.body}`);

  // ITEM 2: OS-Level Secret Protection as appuser
  console.log('\n----------------------------------------------------------------');
  console.log('ITEM 2: OS-Level Secret Protection as appuser (UID 1000)');
  console.log('----------------------------------------------------------------');

  const catProc = spawnSync('su', ['-s', '/bin/bash', 'appuser', '-c', 'cat /root/.zoya/agent_user_secret.json']);
  console.log(`$ su -s /bin/bash appuser -c "cat /root/.zoya/agent_user_secret.json"`);
  console.log(`Exit Code: ${catProc.status}`);
  console.log(`Stdout:    "${(catProc.stdout || '').toString().trim()}"`);
  console.log(`Stderr:    "${(catProc.stderr || '').toString().trim()}"`);

  const lsProc = spawnSync('su', ['-s', '/bin/bash', 'appuser', '-c', 'ls /root/.zoya']);
  console.log(`\n$ su -s /bin/bash appuser -c "ls /root/.zoya"`);
  console.log(`Exit Code: ${lsProc.status}`);
  console.log(`Stdout:    "${(lsProc.stdout || '').toString().trim()}"`);
  console.log(`Stderr:    "${(lsProc.stderr || '').toString().trim()}"`);

  // ITEM 3: chr()-built "/etc/passwd" script & approval preview
  console.log('\n----------------------------------------------------------------');
  console.log('ITEM 3: chr() Script Bypass Block & Legitimate Script Approval Preview');
  console.log('----------------------------------------------------------------');

  const ws = path.join(process.cwd(), 'workspace');
  if (!fs.existsSync(ws)) fs.mkdirSync(ws, { recursive: true });

  const chrScriptPath = path.join(ws, 'chr_evasion_test.py');
  fs.writeFileSync(
    chrScriptPath,
    'p = "".join([chr(47), chr(101), chr(116), chr(99), chr(47), chr(112), chr(97), chr(115), chr(115), chr(119), chr(100)])\nwith open(p) as f:\n    print(f.read())\n',
    'utf8'
  );

  const chrInspection = agentPermissionGuard.inspectCommand('python3 chr_evasion_test.py', ws);
  console.log(`[chr() Evasion Script Inspection]`);
  console.log(`isBlocked: ${chrInspection.isBlocked}`);
  console.log(`Level:     ${chrInspection.level}`);
  console.log(`Reason:    ${chrInspection.reason}`);

  const runBlockedProc = agentPermissionGuard.executeConfined(
    'python3 chr_evasion_test.py',
    ws,
    { bypassPermissionCheck: false }
  );
  console.log(`\n[Execution Attempt of chr() script via guard]`);
  console.log(`Exit Code: ${runBlockedProc.exitCode}`);
  console.log(`Stderr:    "${runBlockedProc.stderr.trim()}"`);

  // Harmless script approval request
  const harmlessPath = path.join(ws, 'harmless_script.py');
  fs.writeFileSync(
    harmlessPath,
    '# Compute factorial\ndef factorial(n):\n    return 1 if n <= 1 else n * factorial(n - 1)\n\nprint("Factorial of 5:", factorial(5))\n',
    'utf8'
  );
  const harmlessInspection = agentPermissionGuard.inspectCommand('python3 harmless_script.py', ws);
  console.log(`\n[Legitimate Script Inspection & Approval Warning]`);
  console.log(`Level:          ${harmlessInspection.level}`);
  console.log(`needsApproval:  ${harmlessInspection.needsApproval}`);
  console.log(`Approval Warning & Preview:\n${harmlessInspection.approvalWarning}`);

  // ITEM 4: Network Isolation
  console.log('\n----------------------------------------------------------------');
  console.log('ITEM 4: Kernel Network Isolation (unshare -n as appuser UID 1000)');
  console.log('----------------------------------------------------------------');

  const pingProc = spawnSync('unshare', ['-n', '-S', '1000', '-G', '1000', 'ping', '-c', '1', '-W', '1', '8.8.8.8']);
  console.log(`$ unshare -n -S 1000 -G 1000 ping -c 1 -W 1 8.8.8.8`);
  console.log(`Exit Code: ${pingProc.status}`);
  console.log(`Stdout:    "${(pingProc.stdout || '').toString().trim()}"`);
  console.log(`Stderr:    "${(pingProc.stderr || '').toString().trim()}"`);

  const curlLocal = spawnSync('unshare', ['-n', '-S', '1000', '-G', '1000', 'curl', '-m', '1', 'http://127.0.0.1:3000']);
  console.log(`\n$ unshare -n -S 1000 -G 1000 curl -m 1 http://127.0.0.1:3000`);
  console.log(`Exit Code: ${curlLocal.status}`);
  console.log(`Stdout:    "${(curlLocal.stdout || '').toString().trim()}"`);
  console.log(`Stderr:    "${(curlLocal.stderr || '').toString().trim()}"`);

  // ITEM 5: Step List of Agent Run showing first step is "plan"
  console.log('\n----------------------------------------------------------------');
  console.log('ITEM 5: Agent Run Step List (Step 1 is "plan")');
  console.log('----------------------------------------------------------------');

  const agent = new AgentCore({
    workspaceRoot: ws,
    modelName: 'gemini-2.5-flash',
    apiKey: process.env.GEMINI_API_KEY || 'test-key',
    maxIterations: 5,
  });

  const task = await agent.runTask({
    taskPrompt: 'Calculate the sum of numbers 1 to 5 in python and print the answer',
    systemInstruction: 'Solve user requests directly.',
    enableVerification: false,
    autoApproveSafe: true,
  });

  console.log(`Task Status: ${task.status}`);
  console.log(`Total Steps Logged: ${task.steps.length}`);
  console.log(`Step Breakdown:`);
  task.steps.forEach((s) => {
    console.log(`  Step ${s.stepNumber} [Phase: ${s.phase}]: ${s.thought.slice(0, 80).replace(/\n/g, ' ')}...`);
  });
  console.log(`First Step Phase: "${task.steps[0]?.phase}"`);
}

runPartA().catch((err) => {
  console.error('Fatal error in Part A runner:', err);
  process.exit(1);
});
