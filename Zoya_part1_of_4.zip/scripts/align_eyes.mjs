import sharp from 'sharp';
import fs from 'fs';

async function findAlignment(cropPath, generatedPath) {
  // Read nose/mouth reference patch from cropPath
  // In face_crop (300x250):
  // Nose tip is around (145, 120), mouth is around (145, 160)
  // Let's take a 60x60 patch around (120, 110)
  const patchWidth = 60;
  const patchHeight = 60;
  const patchLeft = 120;
  const patchTop = 110;

  const patchBuf = await sharp(cropPath)
    .extract({ left: patchLeft, top: patchTop, width: patchWidth, height: patchHeight })
    .removeAlpha()
    .grayscale()
    .raw()
    .toBuffer();

  // Test scales from 1024 / 300 = 3.41 down to 1.0
  // Since 300x250 into 1024x1024:
  // If scaled to fit width: scale = 1024 / 300 = 3.413
  // If scaled to fit height: scale = 1024 / 250 = 4.096
  // Or letterboxed with 1024 height: width = 1024 * (300/250) = 1228 (overflow)
  // If letterboxed with 1024 width: height = 1024 * (250/300) = 853.3, top = (1024 - 853) / 2 = 85.3
  console.log('Testing scales around 1024 / 300 = 3.413...');

  let bestScore = Infinity;
  let bestScale = 1;
  let bestX = 0;
  let bestY = 0;

  for (let s = 3.35; s <= 3.48; s += 0.01) {
    const scaledW = Math.round(patchWidth * s);
    const scaledH = Math.round(patchHeight * s);

    const scaledPatch = await sharp(patchBuf, {
      raw: { width: patchWidth, height: patchHeight, channels: 1 }
    })
      .resize(scaledW, scaledH, { kernel: 'lanczos3' })
      .raw()
      .toBuffer();

    // Search in generated image
    const genImg = await sharp(generatedPath).grayscale().raw().toBuffer({ resolveWithObject: true });
    const gw = genImg.info.width;
    const gh = genImg.info.height;
    const gdata = genImg.data;

    // Search around expected center: left = 120 * s, top = 110 * s + offset
    const expX = Math.round(patchLeft * s);
    const expY = Math.round(patchTop * s + (1024 - 250 * s) / 2);

    for (let dy = -20; dy <= 20; dy += 2) {
      for (let dx = -20; dx <= 20; dx += 2) {
        const tx = expX + dx;
        const ty = expY + dy;
        if (tx < 0 || ty < 0 || tx + scaledW >= gw || ty + scaledH >= gh) continue;

        let diff = 0;
        for (let py = 0; py < scaledH; py += 3) {
          for (let px = 0; px < scaledW; px += 3) {
            const pVal = scaledPatch[py * scaledW + px];
            const gVal = gdata[(ty + py) * gw + (tx + px)];
            diff += Math.abs(pVal - gVal);
          }
        }

        if (diff < bestScore) {
          bestScore = diff;
          bestScale = s;
          bestX = tx;
          bestY = ty;
        }
      }
    }
  }

  console.log(`Alignment found: scale=${bestScale.toFixed(4)}, patch at (${bestX}, ${bestY}), score=${bestScore}`);
  const cropOriginX = bestX - patchLeft * bestScale;
  const cropOriginY = bestY - patchTop * bestScale;
  console.log(`Crop (0,0) in generated image: (${cropOriginX.toFixed(2)}, ${cropOriginY.toFixed(2)})`);

  return { scale: bestScale, originX: cropOriginX, originY: cropOriginY };
}

findAlignment(
  'public/assets/images/avatars_modular/avatar_pastel_blue_knit_shorts/face_crop.png',
  'src/assets/images/face_closed_eyes_1794411100565.jpg'
);
