import { spawnSync } from 'child_process';
import fs from 'fs';

interface SuiteResult {
  name: string;
  command: string;
  exitCode: number;
  stdout: string;
  stderr: string;
  durationMs: number;
}

const SUITES = [
  { name: 'TypeScript Compilation', command: 'npx tsc --noEmit' },
  { name: 'Vite Production Build', command: 'npm run build' },
  { name: 'Phase 1: Agent Core', command: 'npx tsx scripts/test_phase1_agent_core.ts' },
  { name: 'Phase 2: Security & Sandboxing', command: 'npx tsx scripts/test_phase2_security.ts' },
  { name: 'Phase 3: Terminal & Files', command: 'npx tsx scripts/test_phase3_terminal_files.ts' },
  { name: 'Phase 3: Quick Fixes', command: 'npx tsx scripts/test_phase3_quick_fixes.ts' },
  { name: 'Phase 4: Skills Engine', command: 'npx tsx scripts/test_phase4_skills.ts' },
  { name: 'Phase 5: MCP Integration', command: 'npx tsx scripts/test_phase5_mcp.ts' },
  { name: 'Phase 6: UI Modal & Theme', command: 'npx tsx scripts/test_phase6_ui.ts' },
  { name: 'Security Gaps Audit', command: 'npx tsx scripts/test_security_gaps.ts' },
  { name: 'Guard Enforcement', command: 'npx tsx scripts/test_guard_enforcement.ts' },
  { name: 'Auth Matrix & Endpoints', command: 'npx tsx scripts/test_all_endpoints_auth.ts' },
  { name: 'Real Model Loop', command: 'npx tsx scripts/test_real_model_loop.ts' },
  { name: 'Part 1 Security Verification', command: 'npx tsx scripts/test_part1_security_verification.ts' },
  { name: 'CSRF & Cookie Hardening', command: 'npx tsx scripts/test_csrf_and_cookie.ts' },
  { name: 'Mobile 360x800 Playwright Headless', command: 'npx tsx scripts/test_browser_mobile_360x800.ts' },
  { name: 'Banking Safety Shield', command: 'npx tsx scripts/test_independent_banking.ts' },
  { name: 'Device Lock Suite', command: 'npx tsx scripts/test_device_lock_suite.ts' },
  { name: 'Battery Alert Suite', command: 'npx tsx scripts/test_battery_alert_suite.ts' },
];

console.log('========================================================================');
console.log('🚀 MASTER TEST RUNNER: EXECUTING ALL 19 MANDATORY SUITES');
console.log('========================================================================\n');

const results: SuiteResult[] = [];

for (const suite of SUITES) {
  console.log(`>>> RUNNING: ${suite.name} ("${suite.command}")`);
  const start = Date.now();
  const [cmd, ...args] = suite.command.split(' ');
  const res = spawnSync(cmd, args, {
    cwd: process.cwd(),
    shell: true,
    encoding: 'utf8',
    maxBuffer: 50 * 1024 * 1024,
  });
  const durationMs = Date.now() - start;
  const exitCode = res.status ?? (res.error ? 1 : 0);
  console.log(`<<< FINISHED: ${suite.name} -> Exit Code: ${exitCode} (${durationMs}ms)\n`);

  results.push({
    name: suite.name,
    command: suite.command,
    exitCode,
    stdout: res.stdout || '',
    stderr: res.stderr || '',
    durationMs,
  });
}

// Write full detailed logs to disk
fs.writeFileSync('all_suites_results.json', JSON.stringify(results, null, 2));

console.log('========================================================================');
console.log('📊 MASTER TEST EXECUTION SUMMARY TABLE');
console.log('========================================================================');
console.log('| Suite Name | Command | Exit Code | Status | Duration |');
console.log('|---|---|---|---|---|');
for (const r of results) {
  const statusStr = r.exitCode === 0 ? '✅ PASS' : '❌ FAIL';
  console.log(`| ${r.name} | \`${r.command}\` | ${r.exitCode} | ${statusStr} | ${(r.durationMs / 1000).toFixed(2)}s |`);
}

const allPassed = results.every((r) => r.exitCode === 0);
console.log('\n========================================================================');
console.log(`TOTAL SUITES: ${results.length} | PASSED: ${results.filter(r => r.exitCode === 0).length} | FAILED: ${results.filter(r => r.exitCode !== 0).length}`);
console.log(`OVERALL RESULT: ${allPassed ? '✅ ALL SUITES PASSED WITHOUT UNEXPECTED ERROR' : '❌ FAILURES ENCOUNTERED'}`);
console.log('========================================================================');
