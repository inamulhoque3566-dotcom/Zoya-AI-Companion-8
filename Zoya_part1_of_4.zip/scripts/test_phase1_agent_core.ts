import path from 'path';
import fs from 'fs';
import { AgentToolExecutor, resolveWorkspacePath } from '../src/services/agent/agentTools.ts';
import { AgentCore } from '../src/services/agent/agentCore.ts';

const TEST_WORKSPACE = path.join(process.cwd(), 'workspace', 'test_sandbox');
if (!fs.existsSync(TEST_WORKSPACE)) {
  fs.mkdirSync(TEST_WORKSPACE, { recursive: true });
}
try {
  fs.chmodSync(TEST_WORKSPACE, 0o777);
} catch {}

import { resolveGeminiApiKey } from '../src/services/agent/modelProvider.ts';

async function runPhase1Tests() {
  console.log('====================================================');
  console.log('🧪 RUNNING PHASE 1: AGENT CORE VERIFICATION SUITE');
  console.log('====================================================\n');

  let passed = 0;
  let failed = 0;

  function assert(condition: boolean, testName: string, detail?: string) {
    if (condition) {
      console.log(`✅ PASS: ${testName}`);
      passed++;
    } else {
      console.error(`❌ FAIL: ${testName} - ${detail || ''}`);
      failed++;
    }
  }

  const executor = new AgentToolExecutor({
    workspaceRoot: TEST_WORKSPACE,
    commandTimeoutMs: 3000, // 3s for fast test
    maxOutputChars: 500, // 500 chars limit for testing output truncation
    autoApprove: true,
  });

  // Test 1: Workspace path confinement (valid path)
  try {
    const valid = resolveWorkspacePath('src/sample.py', TEST_WORKSPACE);
    assert(valid.startsWith(path.resolve(TEST_WORKSPACE)), 'Workspace path resolution inside boundary');
  } catch (e: any) {
    assert(false, 'Workspace path resolution inside boundary', e.message);
  }

  // Test 2: Workspace path confinement (path traversal protection)
  try {
    resolveWorkspacePath('../../etc/passwd', TEST_WORKSPACE);
    assert(false, 'Path traversal protection blocked illegal traversal');
  } catch (e: any) {
    assert(e.message.includes('traverses outside'), 'Path traversal protection blocked illegal traversal');
  }

  // Test 3: write_file tool
  const writeRes = await executor.executeTool('write_file', {
    path: 'calculator.py',
    content: `def add(a, b):\n    return a + b\n\ndef multiply(a, b):\n    return a * b\n`,
  });
  assert(writeRes.success, 'Tool write_file creates file in workspace', writeRes.output);

  // Test 4: read_file tool with line numbers
  const readRes = await executor.executeTool('read_file', {
    path: 'calculator.py',
    startLine: 1,
    endLine: 3,
  });
  assert(
    readRes.success && readRes.output.includes('1: def add(a, b):'),
    'Tool read_file reads with line numbering',
    readRes.output
  );

  // Test 5: replace_file_content (surgical patch)
  const replaceRes = await executor.executeTool('replace_file_content', {
    path: 'calculator.py',
    targetContent: 'return a + b',
    replacementContent: 'return (a + b) # fixed precision',
  });
  assert(replaceRes.success, 'Tool replace_file_content surgically patches target code', replaceRes.output);

  const verifyPatched = await executor.executeTool('read_file', { path: 'calculator.py' });
  assert(
    verifyPatched.output.includes('# fixed precision'),
    'File contains verified patch content'
  );

  // Test 6: multi_file_edit (batch multi-file atomic edits)
  const multiRes = await executor.executeTool('multi_file_edit', {
    edits: [
      {
        path: 'test_calc.py',
        content: `import unittest
from calculator import add

class TestCalc(unittest.TestCase):
    def test_add(self):
        self.assertEqual(add(2, 3), 5)

if __name__ == '__main__':
    unittest.main()
`,
      },
      { path: 'notes.txt', content: 'Test calculator notes' },
    ],
  });
  assert(multiRes.success, 'Tool multi_file_edit executes atomic batch updates', multiRes.output);

  // Test 7: search_code (grep across workspace)
  const searchRes = await executor.executeTool('search_code', {
    query: 'fixed precision',
  });
  assert(
    searchRes.success && searchRes.output.includes('calculator.py'),
    'Tool search_code finds code matches with line numbers',
    searchRes.output
  );

  // Test 8: list_dir tool
  const listRes = await executor.executeTool('list_dir', { dirPath: '.' });
  assert(
    listRes.success && listRes.output.includes('calculator.py'),
    'Tool list_dir lists workspace files and directory contents',
    listRes.output
  );

  // Test 9: run_command with confined workspace and output size limit
  const cmdRes = await executor.executeTool('run_command', {
    command: 'python3 -c "import calculator; print(\'Result:\', calculator.add(10, 20))"',
  });
  assert(
    cmdRes.success && cmdRes.output.includes('Result: 30'),
    'Tool run_command executes script in confined workspace',
    cmdRes.output
  );

  // Test 10: run_command output truncation limit
  const bigRes = await executor.executeTool('run_command', {
    command: 'python3 -c "print(\'A\' * 2000)"',
  });
  assert(
    bigRes.output.includes('TRUNCATED') && bigRes.output.length <= 600,
    'Tool run_command bounds output size strictly with truncation marker'
  );

  // Test 11: run_command timeout enforcement
  const timeoutRes = await executor.executeTool('run_command', {
    command: 'sleep 10',
    timeoutMs: 1500, // 1.5s timeout
  });
  assert(
    !timeoutRes.success && timeoutRes.error === 'TIMEOUT',
    'Tool run_command enforces process timeout strictly'
  );

  // Test 12: run_tests tool
  const testRes = await executor.executeTool('run_tests', {
    testCommand: 'python3 -m unittest test_calc.py',
  });
  assert(
    testRes.success && (testRes.output.includes('OK') || testRes.output.includes('passed') || testRes.output.includes('Ran 1 test')),
    'Tool run_tests executes test runner and captures test results',
    testRes.output
  );

  // Test 13: run_build tool (compilation / syntax verification)
  const buildRes = await executor.executeTool('run_build', {
    buildCommand: 'python3 -m py_compile calculator.py test_calc.py',
  });
  assert(buildRes.success, 'Tool run_build verifies clean build/compilation', buildRes.output);

  // Test 14: AgentCore End-to-End Loop with Plan, Tool Logging, and Report
  console.log('\n--- Testing Autonomous Agent Loop ---');
  try {
    fs.chmodSync(TEST_WORKSPACE, 0o777);
  } catch {}
  const apiKey = resolveGeminiApiKey();
  const agent = new AgentCore({
    workspaceRoot: TEST_WORKSPACE,
    maxRetries: 3,
    commandTimeoutMs: 15000,
    autoApprove: true,
    modelConfig: {
      provider: 'gemini',
      apiKey,
      model: 'gemini-3.5-flash-lite',
    },
  });

  const taskResult = await agent.runTask(
    'Create a utility file named math_utils.py with a function factorial(n), write a test file test_math.py, run the test, and confirm everything passes.'
  );

  assert(
    taskResult.status === 'completed',
    'Agent loop completed successfully with plan-act-verify cycle',
    taskResult.error
  );
  assert(
    taskResult.logs.length >= 2,
    `Every tool call logged (Logged steps: ${taskResult.logs.length})`
  );
  assert(
    fs.existsSync(path.join(TEST_WORKSPACE, 'math_utils.py')),
    'math_utils.py created on disk by agent'
  );

  console.log('\n====================================================');
  console.log(`TEST SUMMARY: ${passed} PASSED, ${failed} FAILED`);
  console.log('====================================================');

  if (failed > 0) {
    process.exit(1);
  }
}

runPhase1Tests().catch((err) => {
  console.error('Test suite crashed:', err);
  process.exit(1);
});
