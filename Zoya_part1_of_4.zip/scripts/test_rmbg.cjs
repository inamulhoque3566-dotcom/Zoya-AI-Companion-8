const ort = require('onnxruntime-node');
const sharp = require('sharp');
const fs = require('fs');

async function testRmbg() {
  const modelPath = './node_modules/@xenova/transformers/.cache/briaai/RMBG-1.4/onnx/model_quantized.onnx';
  console.log('Loading session from:', modelPath);
  const session = await ort.InferenceSession.create(modelPath);
  console.log('Input names:', session.inputNames);
  console.log('Output names:', session.outputNames);

  // Load avatar 1
  const inputJpg = 'src/assets/images/avatar_1_cute_1793674609394.jpg';
  const meta = await sharp(inputJpg).metadata();
  console.log('Original size:', meta.width, meta.height);

  // Resize to 1024x1024 RGB
  const resized = await sharp(inputJpg)
    .resize(1024, 1024, { fit: 'fill' })
    .removeAlpha()
    .raw()
    .toBuffer();

  // RMBG-1.4 expects shape [1, 3, 1024, 1024] float32 normalized: (x / 255.0 - 0.5) / 0.5 or (x/255 - [0.485,0.456,0.406])/[0.229,0.224,0.225]
  // Standard briaai/RMBG-1.4 normalization: (val / 255.0 - 0.5) / 0.5
  const floatData = new Float32Array(3 * 1024 * 1024);
  const channelSize = 1024 * 1024;
  for (let i = 0; i < channelSize; i++) {
    const r = resized[i * 3];
    const g = resized[i * 3 + 1];
    const b = resized[i * 3 + 2];
    // Exact RMBG-1.4 preprocessor: (val * rescale_factor - mean) / std = (val / 255.0 - 0.5) / 1.0
    floatData[i] = (r / 255.0 - 0.5);
    floatData[channelSize + i] = (g / 255.0 - 0.5);
    floatData[2 * channelSize + i] = (b / 255.0 - 0.5);
  }

  const inputTensor = new ort.Tensor('float32', floatData, [1, 3, 1024, 1024]);
  const feeds = {};
  feeds[session.inputNames[0]] = inputTensor;

  console.log('Running inference...');
  const results = await session.run(feeds);
  const outputTensor = results[session.outputNames[0]];
  console.log('Output dims:', outputTensor.dims, 'type:', outputTensor.type);

  // Output dims typically [1, 1, 1024, 1024]
  const maskData = outputTensor.data; // Float32Array
  // Find min and max
  let min = 999, max = -999;
  for (let i = 0; i < maskData.length; i += 100) {
    if (maskData[i] < min) min = maskData[i];
    if (maskData[i] > max) max = maskData[i];
  }
  console.log('Mask value range:', min, 'to', max);

  // Convert mask to 1024x1024 8-bit grayscale
  const mask8 = new Uint8Array(1024 * 1024);
  for (let i = 0; i < 1024 * 1024; i++) {
    let val = maskData[i];
    // If output is sigmoid or 0..1:
    let byteVal = Math.round(Math.min(1, Math.max(0, val)) * 255);
    mask8[i] = byteVal;
  }

  // Resize mask back to original dimensions (meta.width x meta.height)
  const { data: resizedMask, info: maskInfo } = await sharp(mask8, {
    raw: { width: 1024, height: 1024, channels: 1 }
  })
    .resize(meta.width, meta.height)
    .raw()
    .toBuffer({ resolveWithObject: true });

  console.log('resizedMask channels:', maskInfo.channels);

  // Combine original image with alpha mask!
  const originalRgb = await sharp(inputJpg).removeAlpha().raw().toBuffer();
  const outRgba = new Uint8Array(meta.width * meta.height * 4);
  const totalPixels = meta.width * meta.height;
  for (let i = 0; i < totalPixels; i++) {
    outRgba[i * 4] = originalRgb[i * 3];
    outRgba[i * 4 + 1] = originalRgb[i * 3 + 1];
    outRgba[i * 4 + 2] = originalRgb[i * 3 + 2];
    outRgba[i * 4 + 3] = resizedMask[i * maskInfo.channels];
  }

  await sharp(outRgba, {
    raw: { width: meta.width, height: meta.height, channels: 4 }
  })
    .png()
    .toFile('/tmp/test_rmbg_avatar1.png');

  console.log('SUCCESS: Saved to /tmp/test_rmbg_avatar1.png');
}

testRmbg().catch(err => {
  console.error('Error running test:', err);
});
