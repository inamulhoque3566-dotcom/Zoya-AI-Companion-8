const sharp = require('sharp');
const path = require('path');

async function inspect() {
  const meta = await sharp(path.join(__dirname, '../public/assets/images/anime_princess_3d_transparent.png')).metadata();
  console.log('anime_princess_3d_transparent meta:', meta.width, meta.height, meta.channels);

  const { data, info } = await sharp(path.join(__dirname, '../public/assets/images/anime_princess_3d_transparent.png'))
    .raw()
    .toBuffer({ resolveWithObject: true });

  console.log('Channels:', info.channels);
  // Check rows 1200 to 1375
  let nonZeroBelow1200 = 0;
  let nonZeroBelow1360 = 0;
  for (let y = 1200; y < info.height; y++) {
    for (let x = 0; x < info.width; x++) {
      const idx = (y * info.width + x) * info.channels;
      const alpha = info.channels === 4 ? data[idx + 3] : 255;
      if (alpha > 10) {
        nonZeroBelow1200++;
        if (y >= 1360) {
          nonZeroBelow1360++;
          if (nonZeroBelow1360 <= 10) {
            console.log(`Row y=${y}, x=${x}, r=${data[idx]}, g=${data[idx+1]}, b=${data[idx+2]}, a=${alpha}`);
          }
        }
      }
    }
  }
  console.log(`nonZeroBelow1200: ${nonZeroBelow1200}, nonZeroBelow1360: ${nonZeroBelow1360}`);

  // Let's also check lateral bounds for y in [1200, 1375]
  let minX = info.width, maxX = 0;
  for (let y = 1200; y < info.height; y++) {
    for (let x = 0; x < info.width; x++) {
      const idx = (y * info.width + x) * info.channels;
      const alpha = info.channels === 4 ? data[idx + 3] : 255;
      if (alpha > 20) {
        if (x < minX) minX = x;
        if (x > maxX) maxX = x;
      }
    }
  }
  console.log(`Bounds for y>=1200: x in [${minX}, ${maxX}]`);
}

inspect().catch(console.error);
