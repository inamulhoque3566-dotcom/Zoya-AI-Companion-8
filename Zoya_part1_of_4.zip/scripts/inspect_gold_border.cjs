const sharp = require('sharp');

async function inspectGoldBorder() {
  const { data, info } = await sharp('public/assets/aistudio/file_00000000c0d4821189e14bf178224f8d_f1687d5b.png')
    .raw()
    .toBuffer({ resolveWithObject: true });

  const cur = await sharp('public/assets/images/avatars_3d/transparent/avatar_midnight_gold_zari_saree.png')
    .raw()
    .toBuffer({ resolveWithObject: true });

  const w = info.width;
  const h = info.height;

  // Let's print out what colors exist across the bottom hem in the original source
  console.log('Original source at y=1500..1525:');
  for (let y = 1500; y <= 1525; y += 5) {
    let goldCount = 0;
    let fabricCount = 0;
    let shadowCount = 0;
    for (let x = 200; x < 900; x++) {
      const idx = (y * w + x) * 4;
      const a = data[idx + 3];
      if (a > 20) {
        const r = data[idx], g = data[idx+1], b = data[idx+2];
        // Gold zari: r > 180, g > 130, b > 90
        if (r > 160 && g > 120 && b < 200) goldCount++;
        // Dark fabric: r < 40 && g < 40 && b < 40
        else if (r < 50 && g < 50 && b < 50) fabricCount++;
        else shadowCount++;
      }
    }
    console.log(`y=${y}: goldZari=${goldCount}, darkFabric=${fabricCount}, other=${shadowCount}`);
  }

  // Now check current transparent at same rows:
  console.log('\nCurrent transparent at y=1500..1525:');
  for (let y = 1500; y <= 1525; y += 5) {
    let goldCount = 0;
    let fabricCount = 0;
    let shadowCount = 0;
    for (let x = 200; x < 900; x++) {
      const idx = (y * w + x) * 4;
      const a = cur.data[idx + 3];
      if (a > 20) {
        const r = cur.data[idx], g = cur.data[idx+1], b = cur.data[idx+2];
        if (r > 160 && g > 120 && b < 200) goldCount++;
        else if (r < 50 && g < 50 && b < 50) fabricCount++;
        else shadowCount++;
      }
    }
    console.log(`y=${y}: goldZari=${goldCount}, darkFabric=${fabricCount}, other=${shadowCount}`);
  }
}

inspectGoldBorder().catch(console.error);
