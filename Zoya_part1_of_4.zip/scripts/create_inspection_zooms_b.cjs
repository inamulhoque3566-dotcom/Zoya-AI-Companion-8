const sharp = require('sharp');

async function createInspectionZooms() {
  const w = 1024, h = 1536;

  // Let's create magenta composite of pristine source AND current transparent for Avatar B
  const magenta = await sharp({
    create: { width: w, height: h, channels: 4, background: { r: 255, g: 0, b: 255, alpha: 1 } }
  }).png().toBuffer();

  // 1. Pristine source on magenta
  const srcOnMagenta = await sharp(magenta)
    .composite([{ input: 'public/assets/aistudio/file_00000000c0d4821189e14bf178224f8d_f1687d5b.png' }])
    .png()
    .toBuffer();

  // 2. Current transparent on magenta
  const curOnMagenta = await sharp(magenta)
    .composite([{ input: 'public/assets/images/avatars_3d/transparent/avatar_midnight_gold_zari_saree.png' }])
    .png()
    .toBuffer();

  // Extract zoom areas for both:
  // Zoom 1: Bottom hem (left: 200, top: 1350, width: 624, height: 186)
  await sharp(srcOnMagenta).extract({ left: 200, top: 1350, width: 624, height: 186 }).toFile('proof_artifacts/avatar_b_src_hem_magenta.png');
  await sharp(curOnMagenta).extract({ left: 200, top: 1350, width: 624, height: 186 }).toFile('proof_artifacts/avatar_b_cur_hem_magenta.png');

  // Zoom 2: Hands & Waist (left: 300, top: 500, width: 450, height: 400)
  await sharp(srcOnMagenta).extract({ left: 300, top: 500, width: 450, height: 400 }).toFile('proof_artifacts/avatar_b_src_hands_magenta.png');
  await sharp(curOnMagenta).extract({ left: 300, top: 500, width: 450, height: 400 }).toFile('proof_artifacts/avatar_b_cur_hands_magenta.png');

  // Zoom 3: Sheer Pallu drape (left: 600, top: 400, width: 400, height: 600)
  await sharp(srcOnMagenta).extract({ left: 600, top: 400, width: 400, height: 600 }).toFile('proof_artifacts/avatar_b_src_pallu_magenta.png');
  await sharp(curOnMagenta).extract({ left: 600, top: 400, width: 400, height: 600 }).toFile('proof_artifacts/avatar_b_cur_pallu_magenta.png');

  console.log('Saved inspection zooms to proof_artifacts/');
}

createInspectionZooms().catch(console.error);
