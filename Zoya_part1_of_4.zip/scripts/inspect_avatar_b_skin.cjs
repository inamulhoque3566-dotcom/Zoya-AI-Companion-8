const sharp = require('sharp');

async function inspectAvatarBSkin() {
  const src = await sharp('public/assets/aistudio/file_00000000c0d4821189e14bf178224f8d_f1687d5b.png')
    .raw()
    .toBuffer({ resolveWithObject: true });

  const w = src.info.width;
  const h = src.info.height;

  console.log('Inspecting skin at bottom (y=1500..1525):');
  for (let y = 1500; y <= 1525; y += 5) {
    let line = `y=${y}: `;
    for (let x = 380; x <= 620; x += 15) {
      const idx = (y * w + x) * 4;
      const r = src.data[idx], g = src.data[idx+1], b = src.data[idx+2], a = src.data[idx+3];
      if (a === 0) line += ' . ';
      else if (r > 180 && g > 140 && b > 130) line += ' S ';
      else if (r > 150 && g > 110 && b < 100) line += ' G '; // Gold
      else line += ' D '; // Dark fabric
    }
    console.log(line);
  }
}

inspectAvatarBSkin().catch(console.error);
