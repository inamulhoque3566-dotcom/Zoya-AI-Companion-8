const sharp = require('sharp');

async function inspectSourceAroundSliver() {
  const { data, info } = await sharp('public/assets/aistudio/file_00000000eb7881fa8a888c25bfc4c0f7_32dd4f88.png')
    .raw()
    .toBuffer({ resolveWithObject: true });

  const w = info.width;
  const h = info.height;

  console.log('Source image (file_00000000eb7881fa8a888c25bfc4c0f7_32dd4f88.png) around y=1440:');
  for (let x = 465; x <= 495; x++) {
    const idx = (1440 * w + x) * 4;
    console.log(`x=${x}: rgba=(${data[idx]}, ${data[idx+1]}, ${data[idx+2]}, ${data[idx+3]})`);
  }

  // Also check if there is an outer sliver or fragments outside the legs (e.g. x=560..600 or x=380..420 or around ankles)
  console.log('\nChecking outer leg borders at y=1440:');
  // left side of left leg
  for (let x = 410; x <= 425; x++) {
    const idx = (1440 * w + x) * 4;
    console.log(`left edge x=${x}: rgba=(${data[idx]}, ${data[idx+1]}, ${data[idx+2]}, ${data[idx+3]})`);
  }
  // right side of right leg
  for (let x = 550; x <= 565; x++) {
    const idx = (1440 * w + x) * 4;
    console.log(`right edge x=${x}: rgba=(${data[idx]}, ${data[idx+1]}, ${data[idx+2]}, ${data[idx+3]})`);
  }
}

inspectSourceAroundSliver().catch(console.error);
