const sharp = require('sharp');

async function inspectSareeAnatomy() {
  const { data, info } = await sharp('public/assets/images/avatars_3d/transparent/avatar_midnight_gold_zari_saree.png')
    .raw()
    .toBuffer({ resolveWithObject: true });

  const srcPng = await sharp('public/assets/aistudio/file_00000000c0d4821189e14bf178224f8d_f1687d5b.png')
    .raw()
    .toBuffer({ resolveWithObject: true });

  const w = info.width;
  const h = info.height;

  // Let's find differences between srcPng and current transparent
  let diffCount = 0;
  let missingHemPixels = 0;

  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const idx = (y * w + x) * 4;
      const aSrc = srcPng.data[idx + 3];
      const aCur = data[idx + 3];

      if (aSrc > 50 && aCur === 0) {
        if (y > 1480) missingHemPixels++;
        diffCount++;
      }
    }
  }

  console.log(`Avatar B: total pixels removed from source: ${diffCount}, of which below y=1480: ${missingHemPixels}`);

  // Check hands (y ~ 500..850)
  // Let's inspect edges of hands and body for leftover halos
  // Check sheer fabric of saree:
  // Pallu / veil drape flows on right side (x: 600..850, y: 350..1200)
  let semiTransparentSrc = 0;
  let semiTransparentCur = 0;
  for (let i = 0; i < srcPng.data.length; i += 4) {
    const aS = srcPng.data[i + 3];
    const aC = data[i + 3];
    if (aS > 10 && aS < 240) semiTransparentSrc++;
    if (aC > 10 && aC < 240) semiTransparentCur++;
  }
  console.log(`Semi-transparent pixels (sheer fabric): source=${semiTransparentSrc}, current=${semiTransparentCur}`);
}

inspectSareeAnatomy().catch(console.error);
