// Automated Verification Suite for Zoya Voice Recognition & Auto-Send Flow

function assertEqual<T>(actual: T, expected: T, message: string): void {
  if (actual !== expected) {
    throw new Error(`Assertion failed: ${message} (expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)})`);
  }
}

function assertOk(condition: unknown, message: string): void {
  if (!condition) {
    throw new Error(`Assertion failed: ${message}`);
  }
}

// Mock browser globals before instantiating SpeechRecognizerManager
class MockSpeechRecognition {
  public continuous = false;
  public interimResults = false;
  public maxAlternatives = 1;
  public lang = 'hi-IN';

  public onstart: (() => void) | null = null;
  public onresult: ((event: any) => void) | null = null;
  public onspeechend: (() => void) | null = null;
  public onerror: ((event: any) => void) | null = null;
  public onend: (() => void) | null = null;

  public started = false;
  public stopped = false;
  public aborted = false;

  public static instances: MockSpeechRecognition[] = [];

  constructor() {
    MockSpeechRecognition.instances.push(this);
  }

  start() {
    this.started = true;
    this.onstart?.();
  }

  stop() {
    this.stopped = true;
    this.onend?.();
  }

  abort() {
    this.aborted = true;
    this.onend?.();
  }

  emitResult(results: Array<{ transcript: string; isFinal: boolean; confidence?: number }>, resultIndex = 0) {
    const formatted = results.map((r) => {
      const item: any = [{ transcript: r.transcript, confidence: r.confidence ?? 0.95 }];
      item.isFinal = r.isFinal;
      return item;
    });
    this.onresult?.({
      resultIndex,
      results: formatted,
    });
  }
}

Object.defineProperty(globalThis, 'window', {
  value: {
    SpeechRecognition: MockSpeechRecognition,
    webkitSpeechRecognition: MockSpeechRecognition,
    setTimeout: globalThis.setTimeout.bind(globalThis),
    clearTimeout: globalThis.clearTimeout.bind(globalThis),
  },
  configurable: true,
  writable: true,
});

Object.defineProperty(globalThis, 'navigator', {
  value: {
    userAgent: 'Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/124.0.0.0 Mobile Safari/537.36',
    mediaDevices: {
      getUserMedia: async () => ({
        getTracks: () => [{ stop: () => {} }],
      }),
    },
  },
  configurable: true,
  writable: true,
});

const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

async function runTests() {
  const { SpeechRecognizerManager } = await import('../src/services/speech/SpeechRecognizerManager.ts');
  console.log('=== ZOYA VOICE AUTO-SEND VERIFICATION SUITE ===\n');
  let passed = 0;

  // ---------------------------------------------------------------------------
  // TEST 1: Utterance followed by immediate recognition.onend (Core Bug Fix)
  // ---------------------------------------------------------------------------
  {
    MockSpeechRecognition.instances = [];
    const manager = new SpeechRecognizerManager();

    let inputText = '';
    const partialUpdates: string[] = [];
    const submittedQueries: Array<{ text: string; source: string }> = [];

    manager.setListener({
      onListening: () => {},
      onPartialResult: (text) => {
        partialUpdates.push(text);
        inputText = text;
      },
      onWakeWordDetected: (text, commandAfterWake) => {
        const query = commandAfterWake || text || 'Hello Zoya';
        inputText = '';
        submittedQueries.push({ text: query, source: 'wake' });
      },
      onResult: (text) => {
        inputText = '';
        submittedQueries.push({ text, source: 'result' });
      },
      onError: () => {},
    });

    await manager.enablePersistentListening('hi-IN');
    const rec = MockSpeechRecognition.instances[MockSpeechRecognition.instances.length - 1];
    assertOk(rec, 'MockSpeechRecognition instance should be created');

    // User speaks a general command: interim -> final -> immediate browser onend (before 950ms silence timer)
    rec.emitResult([{ transcript: 'आज मौसम', isFinal: false }]);
    assertEqual(inputText, 'आज मौसम', 'Interim transcript should populate inputText via onPartialResult');
    assertEqual(submittedQueries.length, 0, 'Interim transcript must NOT be auto-submitted');

    rec.emitResult([{ transcript: 'आज मौसम कैसा है', isFinal: true }]);
    assertEqual(inputText, 'आज मौसम कैसा है', 'Final transcript updates onPartialResult preview');

    // Browser fires onend immediately (80ms after speech stops, well before old 950ms silenceTimer)
    await sleep(80);
    rec.onend?.();

    assertEqual(submittedQueries.length, 1, 'Utterance must auto-submit immediately when onend fires');
    assertEqual(submittedQueries[0].text, 'आज मौसम कैसा है', 'Exact recognized transcript must be auto-submitted');
    assertEqual(inputText, '', 'Chat input box must be cleared upon auto-submission');

    // Wait 600ms to verify scheduleAutoRestart (200ms) or old timers do not double-submit
    await sleep(600);
    assertEqual(submittedQueries.length, 1, 'Auto-restart must not re-submit the same utterance');
    await manager.disablePersistentListening();

    console.log('PASS [1/6]: Utterance auto-submits when recognition.onend fires before silence timer');
    passed++;
  }

  // ---------------------------------------------------------------------------
  // TEST 2: Incomplete Interim Transcripts Not Submitted Prematurely; Final Settled Auto-Submits
  // ---------------------------------------------------------------------------
  {
    MockSpeechRecognition.instances = [];
    const manager = new SpeechRecognizerManager();

    const submittedQueries: string[] = [];
    const partialTranscripts: string[] = [];

    manager.setListener({
      onListening: () => {},
      onPartialResult: (t) => partialTranscripts.push(t),
      onWakeWordDetected: (text, cmd) => submittedQueries.push(cmd || text),
      onResult: (t) => submittedQueries.push(t),
      onError: () => {},
    });

    await manager.enablePersistentListening('hi-IN');
    const rec = MockSpeechRecognition.instances[MockSpeechRecognition.instances.length - 1];

    // Emit multiple interim results — including an interim wake phrase mid-sentence
    rec.emitResult([{ transcript: 'Hello Zoya', isFinal: false }]);
    await sleep(100);
    rec.emitResult([{ transcript: 'Hello Zoya tell me', isFinal: false }]);
    await sleep(100);
    assertEqual(submittedQueries.length, 0, 'Interim wake-word or partial speech must NOT be submitted mid-sentence');

    // Now final result arrives while session remains open
    rec.emitResult([{ transcript: 'Hello Zoya tell me a joke', isFinal: true }]);

    // Wait 520ms for final_settled timer (450ms) to auto-submit without needing onend
    await sleep(520);
    assertEqual(submittedQueries.length, 1, 'Final transcript must auto-submit after 450ms settle window even while session stays open');
    assertEqual(submittedQueries[0], 'tell me a joke', 'Command after wake word must be extracted and submitted');

    await manager.disablePersistentListening();
    console.log('PASS [2/6]: Interim transcripts are not submitted early; finalized utterance auto-submits once');
    passed++;
  }

  // ---------------------------------------------------------------------------
  // TEST 3: Wake-Word Handling ("Hello Zoya", "Hey Zoya", Devanagari "हेलो जोया", "हैलो ज़ोया")
  // ---------------------------------------------------------------------------
  {
    const manager = new SpeechRecognizerManager();

    const enHello = manager.checkWakePhrase('Hello Zoya');
    assertEqual(enHello.matched, true, '"Hello Zoya" must match wake phrase');
    assertEqual(enHello.remainingText, '', 'Standalone "Hello Zoya" has empty remainingText');

    const enHeyCmd = manager.checkWakePhrase('Hey Zoya open the camera');
    assertEqual(enHeyCmd.matched, true, '"Hey Zoya ..." must match wake phrase');
    assertEqual(enHeyCmd.remainingText, 'open the camera', 'Command after "Hey Zoya" must be extracted');

    const hiHello = manager.checkWakePhrase('हेलो जोया');
    assertEqual(hiHello.matched, true, 'Devanagari "हेलो जोया" must match wake phrase (fixed ASCII \\b bug)');
    assertEqual(hiHello.remainingText, '', 'Standalone "हेलो जोया" has empty remainingText');

    const hiHailoCmd = manager.checkWakePhrase('हैलो ज़ोया तुम कैसी हो');
    assertEqual(hiHailoCmd.matched, true, 'Devanagari "हैलो ज़ोया तुम कैसी हो" must match wake phrase');
    assertEqual(hiHailoCmd.remainingText, 'तुम कैसी हो', 'Devanagari command after wake word must be extracted');

    // Verify end-to-end standalone "Hello Zoya" auto-sends "Hello Zoya" to chat handler
    MockSpeechRecognition.instances = [];
    const dispatched: string[] = [];
    manager.setListener({
      onListening: () => {},
      onPartialResult: () => {},
      onWakeWordDetected: (text, cmd) => dispatched.push(cmd || text || 'Hello Zoya'),
      onResult: (text) => dispatched.push(text),
      onError: () => {},
    });

    await manager.startListening();
    const rec = MockSpeechRecognition.instances[MockSpeechRecognition.instances.length - 1];
    rec.emitResult([{ transcript: 'हेलो जोया', isFinal: true }]);
    rec.onend?.();

    assertEqual(dispatched.length, 1, 'Saying "हेलो जोया" must auto-submit immediately');
    assertEqual(dispatched[0], 'हेलो जोया', 'Standalone wake phrase submits greeting to Zoya');

    await manager.stopListening();
    console.log('PASS [3/6]: Wake-word detection ("Hello Zoya", "Hey Zoya", "हेलो जोया", "हैलो ज़ोया") auto-submits accurately');
    passed++;
  }

  // ---------------------------------------------------------------------------
  // TEST 4: Deduplication — Repeated Transcripts / Overlapping Events Submit Only Once
  // ---------------------------------------------------------------------------
  {
    MockSpeechRecognition.instances = [];
    const manager = new SpeechRecognizerManager();
    const dispatched: string[] = [];

    manager.setListener({
      onListening: () => {},
      onPartialResult: () => {},
      onWakeWordDetected: (text, cmd) => dispatched.push(cmd || text),
      onResult: (text) => dispatched.push(text),
      onError: () => {},
    });

    await manager.startListening();
    const rec = MockSpeechRecognition.instances[MockSpeechRecognition.instances.length - 1];

    // Emit final result, then fire onspeechend, onend, and stopListening, plus a duplicate emission
    rec.emitResult([{ transcript: 'Tell me the time', isFinal: true }]);
    rec.onspeechend?.();
    rec.onend?.();
    await manager.stopListening();

    // Start again immediately and emit identical transcript within 1800ms deduplication window
    await manager.startListening();
    const rec2 = MockSpeechRecognition.instances[MockSpeechRecognition.instances.length - 1];
    rec2.emitResult([{ transcript: 'Tell me the time', isFinal: true }]);
    rec2.onend?.();
    await manager.stopListening();

    assertEqual(dispatched.length, 1, 'Duplicate transcripts and overlapping lifecycle events must be dispatched exactly once');
    assertEqual(dispatched[0], 'Tell me the time', 'Dispatched text matches expected utterance');

    console.log('PASS [4/6]: Single-dispatch deduplication prevents repeated submissions');
    passed++;
  }

  // ---------------------------------------------------------------------------
  // TEST 5: Manual Typing & Manual Send Button Preservation
  // ---------------------------------------------------------------------------
  {
    // Simulate App.tsx state & refs for manual typing + voice listener interaction
    let inputText = '';
    let hasManualText = false;
    let isVoiceInput = false;
    const processedQueries: Array<{ query: string; source: 'voice' | 'text' }> = [];

    const handleUserInputChange = (val: string) => {
      isVoiceInput = false;
      hasManualText = val.trim().length > 0;
      inputText = val;
    };

    const handleProcessUserQuery = (queryToProcess?: string, source: 'voice' | 'text' = 'text') => {
      const text = (queryToProcess ?? inputText).trim();
      if (!text) return;
      if (source === 'text' || !hasManualText) {
        inputText = '';
        hasManualText = false;
        isVoiceInput = false;
      }
      processedQueries.push({ query: text, source });
    };

    // User manually types in the input box
    handleUserInputChange('My manual note to Zoya');
    assertEqual(inputText, 'My manual note to Zoya', 'Manual typing updates inputText');
    assertEqual(hasManualText, true, 'hasManualText flag is set');

    // Background partial voice event arrives while user is manually typing
    if (!hasManualText) {
      isVoiceInput = true;
      inputText = 'background noise';
    }
    assertEqual(inputText, 'My manual note to Zoya', 'Manual typing must not be overwritten by background voice partials');
    assertEqual(isVoiceInput, false, 'isVoiceInput remains false');

    // User clicks manual Send button
    handleProcessUserQuery(inputText, 'text');
    assertEqual(processedQueries.length, 1, 'Manual Send submits query');
    assertEqual(processedQueries[0].query, 'My manual note to Zoya', 'Manual Send submits exact typed query');
    assertEqual(processedQueries[0].source, 'text', 'Manual Send source is text');
    assertEqual(inputText, '', 'Manual Send clears inputText');

    console.log('PASS [5/6]: Manual typing and manual Send button functionality preserved');
    passed++;
  }

  // ---------------------------------------------------------------------------
  // TEST 6: Microphone / TTS Isolation (Zoya's Own Response Blocked from Auto-Sending)
  // ---------------------------------------------------------------------------
  {
    MockSpeechRecognition.instances = [];
    const manager = new SpeechRecognizerManager();
    const dispatched: string[] = [];

    manager.setListener({
      onListening: () => {},
      onPartialResult: () => {},
      onWakeWordDetected: (text, cmd) => dispatched.push(cmd || text),
      onResult: (text) => dispatched.push(text),
      onError: () => {},
    });

    await manager.startListening();
    const rec = MockSpeechRecognition.instances[MockSpeechRecognition.instances.length - 1];

    // Zoya begins speaking TTS response -> pauseForAssistantSpeaking() called
    manager.pauseForAssistantSpeaking();

    // Any residual recognition result or onend during TTS playback must be ignored
    rec.emitResult([{ transcript: 'मैं ज़ोया हूँ, आपकी क्या मदद कर सकती हूँ', isFinal: true }]);
    rec.onend?.();
    assertEqual(dispatched.length, 0, 'SpeechRecognizerManager must ignore all transcripts while paused for TTS speaking');

    // Resume after TTS finishes
    manager.resumeAfterAssistantSpeaking();
    await sleep(450);
    const recAfterResume = MockSpeechRecognition.instances[MockSpeechRecognition.instances.length - 1];
    recAfterResume.emitResult([{ transcript: 'Thank you Zoya', isFinal: true }]);
    recAfterResume.onend?.();

    assertEqual(dispatched.length, 1, 'After TTS finishes and mic resumes, new user commands auto-submit normally');
    assertEqual(dispatched[0], 'Thank you Zoya', 'Post-TTS utterance matches');

    await manager.stopListening();
    console.log('PASS [6/6]: Microphone/TTS isolation prevents Zoya response echo and resumes cleanly');
    passed++;
  }

  console.log(`\nALL ${passed}/6 VOICE AUTO-SEND TESTS PASSED SUCCESSFULLY.`);
}

runTests().catch((err) => {
  console.error('TEST SUITE FAILED:', err);
  throw err;
});
