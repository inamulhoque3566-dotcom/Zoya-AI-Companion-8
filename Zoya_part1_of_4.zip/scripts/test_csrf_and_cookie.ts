import assert from 'assert';
import { AgentAuthManager } from '../src/services/agent/agentAuth.ts';

const BASE_URL = 'http://127.0.0.1:3000';
const OWNER_PASSPHRASE = 'OwnerSecurePassphrase2026!';

async function runCsrfAndCookieTest() {
  console.log('🧪 Starting CSRF Protection & Fixed Cookie Configuration Verification...\n');

  // Initialize passphrase with setup code
  const setupCode = AgentAuthManager.getOrCreateSetupCode();
  AgentAuthManager.setOwnerPassphraseWithSetupCode(OWNER_PASSPHRASE, setupCode);

  // 1. Reset rate limit and perform owner login to get cookie
  await fetch(`${BASE_URL}/api/agent/auth/owner/reset-limit`, { method: 'POST' });
  const loginRes = await fetch(`${BASE_URL}/api/agent/auth/owner/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ passphrase: OWNER_PASSPHRASE }),
  });
  assert.strictEqual(loginRes.status, 200, `Login should succeed, got ${loginRes.status}`);
  const setCookie = loginRes.headers.get('set-cookie') || '';
  console.log(`[TEST 1] Set-Cookie header issued: ${setCookie}`);
  assert.ok(setCookie.includes('SameSite=Strict'), 'Cookie must use fixed SameSite=Strict from AGENT_COOKIE_CONFIG');
  assert.ok(setCookie.includes('Secure'), 'Cookie must have Secure flag');
  assert.ok(setCookie.includes('HttpOnly'), 'Cookie must have HttpOnly flag');
  console.log('✅ TEST 1 PASSED: Fixed AGENT_COOKIE_CONFIG used (SameSite=Strict; Secure; HttpOnly).\n');

  const cookieMatch = setCookie.match(/zoya_approval_session=([^;]+)/);
  const sessionToken = cookieMatch ? cookieMatch[1] : '';
  assert.ok(sessionToken, 'Must extract valid session token');

  // 2. Pair to get agent token and trigger an action requiring approval
  const pairCodeRes = await fetch(`${BASE_URL}/api/agent/auth/pairing-code`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ passphrase: OWNER_PASSPHRASE }),
  });
  const { pairingCode } = await pairCodeRes.json();
  const tokenRes = await fetch(`${BASE_URL}/api/agent/auth/token?code=${pairingCode}`);
  const { token: agentToken } = await tokenRes.json();

  // Trigger write needing approval via /api/agent/tools/execute
  const toolExecRes = await fetch(`${BASE_URL}/api/agent/tools/execute`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${agentToken}`,
    },
    body: JSON.stringify({
      toolName: 'write_file',
      args: {
        path: 'csrf_test_protected.txt',
        content: 'Testing CSRF blocking on approvals',
      },
    }),
  });
  const toolExecData = await toolExecRes.json();
  const approvalId = toolExecData.pendingApproval?.id || toolExecData.pendingApprovalId;
  assert.ok(approvalId, 'Must have received a pending approval ID');
  console.log(`[TEST 2] Created pending approval request: ${approvalId}`);

  // 3. ATTEMPT 1: Cross-origin approval with malicious Origin: http://attacker.evil
  console.log('[TEST 3] Testing cross-origin approval attempt (Origin: http://attacker.evil)...');
  const maliciousOriginRes = await fetch(`${BASE_URL}/api/agent/approvals/${approvalId}/respond`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Cookie': `zoya_approval_session=${sessionToken}`,
      'Origin': 'http://attacker.evil',
    },
    body: JSON.stringify({ approve: true }),
  });
  const maliciousOriginData = await maliciousOriginRes.json();
  console.log(`Response status: ${maliciousOriginRes.status}`, maliciousOriginData);
  assert.strictEqual(maliciousOriginRes.status, 403, 'Cross-origin request MUST be rejected with 403 Forbidden');
  assert.strictEqual(maliciousOriginData.code, 'CSRF_VIOLATION', 'Error code must be CSRF_VIOLATION');
  console.log('✅ TEST 3 PASSED: Cross-origin approval rejected with HTTP 403 CSRF_VIOLATION.\n');

  // 4. ATTEMPT 2: Cross-site Sec-Fetch-Site header: cross-site
  console.log('[TEST 4] Testing cross-site Sec-Fetch-Site attempt (Sec-Fetch-Site: cross-site)...');
  const crossSiteRes = await fetch(`${BASE_URL}/api/agent/approvals/${approvalId}/respond`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Cookie': `zoya_approval_session=${sessionToken}`,
      'Sec-Fetch-Site': 'cross-site',
    },
    body: JSON.stringify({ approve: true }),
  });
  const crossSiteData = await crossSiteRes.json();
  console.log(`Response status: ${crossSiteRes.status}`, crossSiteData);
  assert.strictEqual(crossSiteRes.status, 403, 'Sec-Fetch-Site: cross-site MUST be rejected with 403 Forbidden');
  assert.strictEqual(crossSiteData.code, 'CSRF_VIOLATION', 'Error code must be CSRF_VIOLATION');
  console.log('✅ TEST 4 PASSED: Sec-Fetch-Site: cross-site rejected with HTTP 403 CSRF_VIOLATION.\n');

  // 5. ATTEMPT 3: Legitimate Same-Origin approval (Origin matches Host: 127.0.0.1:3000)
  console.log('[TEST 5] Testing legitimate same-origin approval (Origin: http://127.0.0.1:3000)...');
  const legitimateRes = await fetch(`${BASE_URL}/api/agent/approvals/${approvalId}/respond`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Cookie': `zoya_approval_session=${sessionToken}`,
      'Origin': 'http://127.0.0.1:3000',
    },
    body: JSON.stringify({ approve: true }),
  });
  const legitimateData = await legitimateRes.json();
  console.log(`Response status: ${legitimateRes.status}`, legitimateData);
  assert.strictEqual(legitimateRes.status, 200, 'Same-origin request with session cookie MUST succeed');
  assert.strictEqual(legitimateData.success, true);
  console.log('✅ TEST 5 PASSED: Legitimate same-origin approval accepted with HTTP 200.\n');

  console.log('🎉 ALL CSRF & COOKIE CONFIGURATION TESTS PASSED 100%!');
}

runCsrfAndCookieTest().catch((err) => {
  console.error('❌ CSRF Test Failed:', err);
  process.exit(1);
});
