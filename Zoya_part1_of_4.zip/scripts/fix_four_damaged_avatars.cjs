const fs = require('fs');
const path = require('path');
const sharp = require('sharp');

/**
 * 1. Process Sapphire Celestial Gown
 * Restores the complete flowing royal ballgown with sparkling crystals.
 * Zero severed skirt, zero background oval, zero floor remnants.
 */
async function processSapphireGown() {
  const src = 'public/assets/images/avatars_3d/avatar_sapphire_celestial_gown.jpg';
  console.log('Processing Sapphire Celestial Gown from:', src);

  const img = sharp(src);
  const { data, info } = await img.removeAlpha().raw().toBuffer({ resolveWithObject: true });
  const W = info.width;
  const H = info.height;

  // Mask: 0 = background, 255 = foreground
  const alpha = new Uint8Array(W * H);

  // Background color check for violet studio gradient
  const isVioletBg = (r, g, b) => {
    // Studio violet: b > r, r >= g, dark
    if (b > r && r >= g && r < 58 && g < 38 && b < 115) return true;
    if (r < 18 && g < 18 && b < 28) return true; // near black edge
    return false;
  };

  // 1. Identify left and right boundaries of the gown skirt row-by-row (y in [630..1275])
  const skirtL = new Int32Array(H).fill(0);
  const skirtR = new Int32Array(H).fill(W - 1);

  for (let y = 630; y <= 1275; y++) {
    // Scan from x=0 inward
    let l = 0;
    while (l < Math.floor(W / 2)) {
      const idx = (y * W + l) * 3;
      const r = data[idx], g = data[idx + 1], b = data[idx + 2];
      if (!isVioletBg(r, g, b)) break;
      l++;
    }
    // Scan from x=W-1 inward
    let r = W - 1;
    while (r > Math.floor(W / 2)) {
      const idx = (y * W + r) * 3;
      const red = data[idx], grn = data[idx + 1], blu = data[idx + 2];
      if (!isVioletBg(red, grn, blu)) break;
      r--;
    }
    skirtL[y] = l;
    skirtR[y] = r;
  }

  // Smooth skirt boundary curves so there are zero jagged outliers
  for (let pass = 0; pass < 3; pass++) {
    for (let y = 632; y < 1274; y++) {
      skirtL[y] = Math.round((skirtL[y - 1] + skirtL[y] + skirtL[y + 1]) / 3);
      skirtR[y] = Math.round((skirtR[y - 1] + skirtR[y] + skirtR[y + 1]) / 3);
    }
  }

  // 2. Build foreground mask
  for (let y = 0; y < H; y++) {
    for (let x = 0; x < W; x++) {
      const idx = y * W + x;
      const idx3 = idx * 3;
      const r = data[idx3], g = data[idx3 + 1], b = data[idx3 + 2];

      // Floor cutoff: below hem of gown (y > 1275)
      if (y > 1275) {
        alpha[idx] = 0;
        continue;
      }

      // Sparkle diamond watermark removal (lower right near edge)
      if (x > 595 && x < 665 && y > 1060 && y < 1240) {
        if (Math.abs(r - g) < 25 && b > 65 && b < 165 && (r > 60 || g > 60)) {
          // If outside the main skirt core or at watermark position
          if (x >= skirtR[y] - 15) {
            alpha[idx] = 0;
            continue;
          }
        }
      }

      // Skirt region: y in [630..1275]
      if (y >= 630 && y <= 1275) {
        if (x >= skirtL[y] && x <= skirtR[y]) {
          alpha[idx] = 255; // 100% solid gown
        } else {
          alpha[idx] = 0;
        }
        continue;
      }

      // Upper body, head, hair: y < 630
      // Outside lateral bounding envelope:
      if (x < 210 || x > 560) {
        alpha[idx] = 0;
        continue;
      }

      // Top of head starts around y = 80
      if (y < 80) {
        alpha[idx] = 0;
        continue;
      }

      // Arm and torso cavities:
      // Gap between right arm and torso: x in [268..316], y in [440..620]
      if (x >= 268 && x <= 316 && y >= 440 && y <= 620 && isVioletBg(r, g, b)) {
        alpha[idx] = 0;
        continue;
      }
      // Gap between left arm and torso: x in [455..500], y in [440..620]
      if (x >= 455 && x <= 500 && y >= 440 && y <= 620 && isVioletBg(r, g, b)) {
        alpha[idx] = 0;
        continue;
      }

      // General studio background check for remaining upper pixels:
      if (isVioletBg(r, g, b)) {
        alpha[idx] = 0;
      } else {
        alpha[idx] = 255;
      }
    }
  }

  // 3. Subpixel anti-aliasing & color bleed
  const cleanRgba = applyAntiAliasingAndColorBleed(data, alpha, W, H);

  // 4. Save
  const outPaths = [
    'public/assets/images/avatars_3d/transparent/avatar_sapphire_celestial_gown.png',
    'public/assets/images/avatars_modular/sapphire_celestial_gown/body_skin.png',
  ];
  for (const outPath of outPaths) {
    fs.mkdirSync(path.dirname(outPath), { recursive: true });
    await sharp(cleanRgba, { raw: { width: W, height: H, channels: 4 } })
      .png({ compressionLevel: 9 })
      .toFile(outPath);
    console.log('Saved:', outPath);
  }
}

/**
 * 2. Process Sage Daisy Gingham Dress & Pink Rib Knit Maxi
 * Completely removes duplicate purple background layers, hearts, and remnants.
 */
async function processDuplicateBgAvatar(config) {
  const { id, src, outPaths, bottomCutoff, watermarkRange } = config;
  console.log(`\nProcessing Avatar: ${id} from: ${src}`);

  const img = sharp(src);
  const { data, info } = await img.removeAlpha().raw().toBuffer({ resolveWithObject: true });
  const W = info.width;
  const H = info.height;

  const isBg = new Uint8Array(W * H);

  const isVioletBg = (x, y) => {
    if (x < 0 || x >= W || y < 0 || y >= H) return true;
    if (bottomCutoff && y >= bottomCutoff) return true;

    const idx = (y * W + x) * 3;
    const r = data[idx], g = data[idx + 1], b = data[idx + 2];

    // Star watermark removal
    if (watermarkRange && x >= watermarkRange.minX && x <= watermarkRange.maxX && y >= watermarkRange.minY && y <= watermarkRange.maxY) {
      if (b > 65 && b < 165 && Math.abs(r - g) < 25) return true;
    }

    // Studio violet backdrop:
    // Low red, low green, blue dominant, or floor shadow
    if (b >= r && r >= g && r < 58 && g < 38 && b < 115) return true;
    if (b > r + 3 && r < 60 && g < 42 && b < 120) return true;
    if (r < 20 && g < 20 && b < 32) return true; // near black
    if (y > H * 0.70 && r < 40 && g < 30 && b < 65) return true; // floor shadow

    return false;
  };

  // BFS from all 4 borders
  const queue = new Int32Array(W * H);
  let qHead = 0, qTail = 0;

  for (let x = 0; x < W; x++) {
    if (isVioletBg(x, 0)) { isBg[x] = 1; queue[qTail++] = x; }
    const bIdx = (H - 1) * W + x;
    if (isVioletBg(x, H - 1)) { isBg[bIdx] = 1; queue[qTail++] = bIdx; }
  }
  for (let y = 0; y < H; y++) {
    const lIdx = y * W;
    if (!isBg[lIdx] && isVioletBg(0, y)) { isBg[lIdx] = 1; queue[qTail++] = lIdx; }
    const rIdx = y * W + W - 1;
    if (!isBg[rIdx] && isVioletBg(W - 1, y)) { isBg[rIdx] = 1; queue[qTail++] = rIdx; }
  }

  const dx = [-1, 1, 0, 0];
  const dy = [0, 0, -1, 1];

  while (qHead < qTail) {
    const curr = queue[qHead++];
    const cx = curr % W;
    const cy = Math.floor(curr / W);

    for (let i = 0; i < 4; i++) {
      const nx = cx + dx[i];
      const ny = cy + dy[i];
      if (nx >= 0 && nx < W && ny >= 0 && ny < H) {
        const nIdx = ny * W + nx;
        if (!isBg[nIdx] && isVioletBg(nx, ny)) {
          isBg[nIdx] = 1;
          queue[qTail++] = nIdx;
        }
      }
    }
  }

  // Also flood fill interior cavities between arms and waist
  for (let y = Math.floor(H * 0.15); y < Math.floor(H * 0.75); y++) {
    for (let x = Math.floor(W * 0.10); x < Math.floor(W * 0.90); x++) {
      const idx = y * W + x;
      if (!isBg[idx] && isVioletBg(x, y)) {
        const cavityQ = [idx];
        isBg[idx] = 1;
        let cHead = 0;
        while (cHead < cavityQ.length) {
          const cCurr = cavityQ[cHead++];
          const ccx = cCurr % W;
          const ccy = Math.floor(cCurr / W);
          for (let i = 0; i < 4; i++) {
            const cnx = ccx + dx[i];
            const cny = ccy + dy[i];
            if (cnx >= 0 && cnx < W && cny >= 0 && cny < H) {
              const cnIdx = cny * W + cnx;
              if (!isBg[cnIdx] && isVioletBg(cnx, cny)) {
                isBg[cnIdx] = 1;
                cavityQ.push(cnIdx);
              }
            }
          }
        }
      }
    }
  }

  // Connected component analysis to drop floating hearts / watermark remnants
  const visited = new Uint8Array(W * H);
  const fgComponents = [];
  for (let y = 0; y < H; y++) {
    for (let x = 0; x < W; x++) {
      const idx = y * W + x;
      if (!isBg[idx] && !visited[idx]) {
        const comp = [idx];
        visited[idx] = 1;
        let cHead = 0;
        while (cHead < comp.length) {
          const curr = comp[cHead++];
          const cx = curr % W;
          const cy = Math.floor(curr / W);
          for (let i = 0; i < 4; i++) {
            const nx = cx + dx[i];
            const ny = cy + dy[i];
            if (nx >= 0 && nx < W && ny >= 0 && ny < H) {
              const nIdx = ny * W + nx;
              if (!isBg[nIdx] && !visited[nIdx]) {
                visited[nIdx] = 1;
                comp.push(nIdx);
              }
            }
          }
        }
        fgComponents.push({ size: comp.length, pixels: comp });
      }
    }
  }

  fgComponents.sort((a, b) => b.size - a.size);
  console.log('Top components:', fgComponents.slice(0, 4).map(c => c.size));
  // Keep only the main avatar body component(s)
  for (let i = 1; i < fgComponents.length; i++) {
    if (fgComponents[i].size < 10000) {
      for (const pix of fgComponents[i].pixels) {
        isBg[pix] = 1;
      }
    }
  }

  // Alpha mask
  const alpha = new Uint8Array(W * H);
  for (let i = 0; i < W * H; i++) {
    alpha[i] = isBg[i] ? 0 : 255;
  }

  const cleanRgba = applyAntiAliasingAndColorBleed(data, alpha, W, H);

  for (const outPath of outPaths) {
    fs.mkdirSync(path.dirname(outPath), { recursive: true });
    await sharp(cleanRgba, { raw: { width: W, height: H, channels: 4 } })
      .png({ compressionLevel: 9 })
      .toFile(outPath);
    console.log('Saved:', outPath);
  }
}

function applyAntiAliasingAndColorBleed(data, alpha, W, H) {
  // Smooth 3x3 anti-aliasing
  const smoothedAlpha = new Uint8Array(W * H);
  for (let y = 0; y < H; y++) {
    for (let x = 0; x < W; x++) {
      const idx = y * W + x;
      if (alpha[idx] === 0) {
        smoothedAlpha[idx] = 0;
      } else {
        let fgCount = 0;
        let total = 0;
        for (let oy = -1; oy <= 1; oy++) {
          for (let ox = -1; ox <= 1; ox++) {
            const sx = x + ox;
            const sy = y + oy;
            if (sx >= 0 && sx < W && sy >= 0 && sy < H) {
              total++;
              if (alpha[sy * W + sx] === 255) fgCount++;
            }
          }
        }
        if (fgCount === total) {
          smoothedAlpha[idx] = 255;
        } else {
          smoothedAlpha[idx] = Math.round((fgCount / total) * 255);
        }
      }
    }
  }

  // Color bleed on semi-transparent boundary pixels
  const cleanRgba = new Uint8Array(W * H * 4);
  const searchDist = 3;

  for (let y = 0; y < H; y++) {
    for (let x = 0; x < W; x++) {
      const idx = y * W + x;
      const idx4 = idx * 4;
      const idx3 = idx * 3;
      const a = smoothedAlpha[idx];

      if (a === 0) {
        cleanRgba[idx4] = 0;
        cleanRgba[idx4 + 1] = 0;
        cleanRgba[idx4 + 2] = 0;
        cleanRgba[idx4 + 3] = 0;
        continue;
      }

      if (a === 255) {
        cleanRgba[idx4] = data[idx3];
        cleanRgba[idx4 + 1] = data[idx3 + 1];
        cleanRgba[idx4 + 2] = data[idx3 + 2];
        cleanRgba[idx4 + 3] = 255;
        continue;
      }

      // Find nearest solid foreground pixel
      let bestDistSq = Infinity;
      let fgR = data[idx3], fgG = data[idx3 + 1], fgB = data[idx3 + 2];

      for (let dy = -searchDist; dy <= searchDist; dy++) {
        const sy = y + dy;
        if (sy < 0 || sy >= H) continue;
        for (let dx = -searchDist; dx <= searchDist; dx++) {
          const sx = x + dx;
          if (sx < 0 || sx >= W) continue;
          const sIdx = sy * W + sx;
          if (alpha[sIdx] === 255) {
            const distSq = dx * dx + dy * dy;
            if (distSq < bestDistSq) {
              bestDistSq = distSq;
              fgR = data[sIdx * 3];
              fgG = data[sIdx * 3 + 1];
              fgB = data[sIdx * 3 + 2];
            }
          }
        }
      }

      cleanRgba[idx4] = fgR;
      cleanRgba[idx4 + 1] = fgG;
      cleanRgba[idx4 + 2] = fgB;
      cleanRgba[idx4 + 3] = a;
    }
  }

  return cleanRgba;
}

async function run() {
  // 1. Classic Sweater & Glasses (Zoya): copy pristine anime_princess_3d_transparent.png
  console.log('[1/4] Restoring Classic Sweater & Glasses...');
  const classicBuf = fs.readFileSync('public/assets/images/anime_princess_3d_transparent.png');
  fs.writeFileSync('public/assets/images/zoya_new_avatar_transparent.png', classicBuf);
  fs.writeFileSync('public/assets/images/avatars_modular/classic/body_skin.png', classicBuf);

  // 2. Sapphire Celestial Gown: restore full ballgown
  console.log('\n[2/4] Restoring Sapphire Celestial Gown...');
  await processSapphireGown();

  // 3. Sage Daisy Gingham Dress: completely remove duplicate background
  console.log('\n[3/4] Purging duplicate background in Sage Daisy Gingham...');
  await processDuplicateBgAvatar({
    id: 'daisy_gingham',
    src: 'public/assets/images/avatars_3d/avatar_daisy_gingham.jpg',
    outPaths: [
      'public/assets/images/avatars_3d/transparent/avatar_daisy_gingham.png',
      'public/assets/images/avatars_modular/daisy_gingham/body_skin.png',
    ],
    bottomCutoff: 1358,
    watermarkRange: { minX: 615, maxX: 675, minY: 1235, maxY: 1295 },
  });

  // 4. Pink Rib Knit & White Maxi: completely remove duplicate background
  console.log('\n[4/4] Purging duplicate background in Pink Rib Knit & White Maxi...');
  await processDuplicateBgAvatar({
    id: 'pink_knit_maxi',
    src: 'public/assets/images/avatars_3d/avatar_pink_knit_maxi.jpg',
    outPaths: [
      'public/assets/images/avatars_3d/transparent/avatar_pink_knit_maxi.png',
      'public/assets/images/avatars_modular/pink_knit_maxi/body_skin.png',
    ],
    bottomCutoff: 1356,
    watermarkRange: { minX: 620, maxX: 680, minY: 1190, maxY: 1250 },
  });

  console.log('\n--- ALL FOUR AVATARS COMPLETED SUCCESSFULLY ---');
}

run().catch(console.error);
