import { androidAccessibility } from '../src/services/androidAccessibility';

async function runAccessibilityTests() {
  console.log('=== ZOYA ACCESSIBILITY & BANKING SAFETY AUDIT ===');

  // 1. Status Check
  const status = androidAccessibility.getStatus();
  console.log('Service status:', status.isRunning ? 'Active' : 'Standby');
  console.log('Service name:', status.serviceName);

  // 2. Banking Safety Tests
  console.log('\nTesting Banking Safety Protection:');
  const testApps = [
    { name: 'PhonePe', pkg: 'com.phonepe.app' },
    { name: 'Google Pay', pkg: 'com.google.android.apps.nbu.paisa.user' },
    { name: 'Paytm', pkg: 'net.one97.paytm' },
    { name: 'YONO SBI', pkg: 'com.sbi.lotusintouch' },
    { name: 'Generic Camera App', pkg: 'com.android.camera' }
  ];

  for (const app of testApps) {
    const isBlocked = androidAccessibility.isPackageBlocked(app.pkg);
    const testAction = await androidAccessibility.executeAction({ action: 'open_app', app: app.name });
    console.log(`- ${app.name} (${app.pkg}): Blocked=${isBlocked} | Action result success=${testAction.success}`);
    if (isBlocked && testAction.success) {
      throw new Error(`CRITICAL: Protected app ${app.name} was not blocked!`);
    }
  }

  // 3. Normal Actions Test
  console.log('\nTesting Standard Allowed Actions:');
  const readScreen = await androidAccessibility.executeAction({ action: 'read_screen' });
  console.log('Read screen nodes count:', readScreen.data?.nodes?.length);

  const scrollDown = await androidAccessibility.executeAction({ action: 'scroll', direction: 'down' });
  console.log('Scroll down result:', scrollDown.success, scrollDown.message);

  const globalBack = await androidAccessibility.executeAction({ action: 'global_action', command: 'back' });
  console.log('Global back result:', globalBack.success, globalBack.message);

  console.log('\n✓ All Accessibility & Safety Guard tests PASSED perfectly.');
}

runAccessibilityTests().catch((err) => {
  console.error('Test failed:', err);
  process.exit(1);
});
