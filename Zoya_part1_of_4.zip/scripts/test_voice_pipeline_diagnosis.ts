import { speechManager } from '../src/services/speech/SpeechRecognizerManager';

async function runVoiceDiagnosticTests() {
  console.log('====================================================');
  console.log('ZOYA AI - VOICE PIPELINE & INTERACTION AUDIT TESTS');
  console.log('====================================================\n');

  let passed = 0;
  let failed = 0;

  function assert(condition: boolean, desc: string) {
    if (condition) {
      console.log(`[PASS] ${desc}`);
      passed++;
    } else {
      console.error(`[FAIL] ${desc}`);
      failed++;
    }
  }

  // TEST 1: SpeechRecognizerManager pauseForAssistantSpeaking & resumeAfterAssistantSpeaking
  console.log('--- TEST 1: SpeechRecognizerManager Pause & Resume State Guard ---');
  assert(speechManager.isPausedForSpeaking === false, 'Initially isPausedForSpeaking should be false');
  
  speechManager.pauseForAssistantSpeaking();
  assert(speechManager.isPausedForSpeaking === true, 'After pauseForAssistantSpeaking(), isPausedForSpeaking should be true');

  // Verify that startListening returns early when isPausedForSpeaking is true
  const startedWhileSpeaking = await speechManager.startListening('hi-IN');
  assert(startedWhileSpeaking === false, 'startListening() must be blocked while assistant is speaking');

  speechManager.resumeAfterAssistantSpeaking();
  assert(speechManager.isPausedForSpeaking === false, 'After resumeAfterAssistantSpeaking(), isPausedForSpeaking should be false');

  // TEST 2: Verify /api/chat-stream generates full unbroken response
  console.log('\n--- TEST 2: /api/chat-stream Endpoint Verification ---');
  try {
    const chatRes = await fetch('http://localhost:3000/api/chat-stream', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        message: 'नमस्ते जोया, आप कैसी हैं?',
        personaMode: 'girlfriend',
        language: 'hi-IN',
        memories: []
      })
    });
    assert(chatRes.ok, `Chat stream HTTP status 200 (received ${chatRes.status})`);
    
    const text = await chatRes.text();
    assert(text.includes('data:'), 'Chat stream output contains SSE data chunks');
    assert(text.includes('[DONE]'), 'Chat stream cleanly finishes with [DONE] marker');
  } catch (err: any) {
    assert(false, `/api/chat-stream request failed: ${err.message}`);
  }

  // TEST 3: Verify /api/tts endpoint generates valid audio
  console.log('\n--- TEST 3: /api/tts Neural Audio Generation ---');
  try {
    const ttsRes = await fetch('http://localhost:3000/api/tts', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        text: 'नमस्ते जान, मैं बिल्कुल ठीक हूँ।',
        personaMode: 'girlfriend',
        language: 'hi-IN'
      })
    });
    assert(ttsRes.ok, `TTS HTTP status 200 (received ${ttsRes.status})`);
    const ttsData = await ttsRes.json();
    assert(Boolean((ttsData.audioData && ttsData.audioData.length > 100) || ttsData.fallbackToClient), `TTS returned valid audioData or resilient fallbackToClient (engine: ${ttsData.engine})`);
  } catch (err: any) {
    assert(false, `/api/tts request failed: ${err.message}`);
  }

  // TEST 4: Verify /api/transcribe endpoint
  console.log('\n--- TEST 4: /api/transcribe Fallback Endpoint ---');
  try {
    const transcribeRes = await fetch('http://localhost:3000/api/transcribe', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        audioData: 'UklGRiQAAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQAAAAA=',
        mimeType: 'audio/wav',
        language: 'hi-IN'
      })
    });
    assert(transcribeRes.ok, `Transcribe HTTP status 200 (received ${transcribeRes.status})`);
    const transcribeData = await transcribeRes.json();
    assert(typeof transcribeData.transcript === 'string' || typeof transcribeData.text === 'string', 'Transcribe returned transcript string');
  } catch (err: any) {
    assert(false, `/api/transcribe request failed: ${err.message}`);
  }

  // TEST 5: Input Text Isolation & State Machine Flow
  console.log('\n--- TEST 5: State Machine & Input Box Isolation Logic ---');
  let inputText = 'User was typing here';
  let isInputFocused = true;
  let liveTranscript = '';

  // Simulate onPartialResult event arriving while user is typing in the box
  const incomingSpeech = 'हेलो जोया';
  if (!isInputFocused) {
    inputText = incomingSpeech;
  }
  liveTranscript = incomingSpeech;

  assert(inputText === 'User was typing here', 'Active user input preserved when isInputFocused is true');
  assert(liveTranscript === 'हेलो जोया', 'Live speech transcript updated in liveTranscript toast');

  // Simulate query dispatch:
  isInputFocused = false;
  const dispatchedQuery = liveTranscript;
  inputText = ''; // Cleared on dispatch
  assert(inputText === '', 'Input text is cleared upon query dispatch');
  assert(dispatchedQuery === 'हेलो जोया', 'Dispatched query reaches assistant');

  console.log(`\n====================================================`);
  console.log(`DIAGNOSTIC TEST SUMMARY: ${passed} PASSED, ${failed} FAILED`);
  console.log(`====================================================\n`);

  if (failed > 0) {
    process.exit(1);
  }
}

runVoiceDiagnosticTests().catch((e) => {
  console.error('Test runner fatal error:', e);
  process.exit(1);
});
