import { chromium } from 'playwright';
import fs from 'fs';
import path from 'path';

const proofDir = path.join(process.cwd(), 'public', 'assets', 'proof');
if (!fs.existsSync(proofDir)) {
  fs.mkdirSync(proofDir, { recursive: true });
}

const AVATAR_IDS = [
  'boho_mini_dress',
  'peasant_blouse_skirt',
  'pink_knit_maxi',
  'floral_palazzo_pants',
  'red_cardigan_floral',
  'plum_royal_anarkali',
  'ivory_floral_anarkali',
  'classic',
  'avatar_urban_crop_hoodie',
  'avatar_white_ruffle_babydoll',
  'avatar_pink_athleisure_track',
  'avatar_pastel_blue_knit_shorts',
  'avatar_slate_blue_regal_kurta',
  'avatar_midnight_gold_zari_saree',
  'avatar_nautical_denim_shorts',
];

async function run() {
  console.log('[PROOF] Starting headless Chromium to verify all 15 real avatars on home screen...');
  const browser = await chromium.launch({
    headless: true,
    args: ['--no-sandbox', '--disable-setuid-sandbox'],
  });

  const context = await browser.newContext({
    viewport: { width: 420, height: 860 },
    deviceScaleFactor: 1,
  });

  const page = await context.newPage();

  // Navigate to local dev server
  await page.goto('http://localhost:3000', { waitUntil: 'networkidle' });
  await page.waitForTimeout(1000);

  const results = [];

  for (const avatarId of AVATAR_IDS) {
    console.log(`[PROOF] Testing & capturing avatar: ${avatarId}`);

    await page.evaluate((id) => {
      if (typeof window.__zoyaSelectAvatar === 'function') {
        window.__zoyaSelectAvatar(id);
      }
    }, avatarId);

    // Wait for canvas to load and render the texture
    await page.waitForTimeout(1500);

    const activeAvatarId = await page.evaluate(() => {
      return document.querySelector('[data-testid="zoya-avatar-rig"]')?.getAttribute('data-avatar-id');
    });

    const canvasCount = await page.evaluate(() => {
      const canvases = document.querySelectorAll('[data-testid="zoya-living-avatar-canvas"]');
      return canvases.length;
    });

    const isCanvasRendered = await page.evaluate(() => {
      const canvas = document.querySelector('[data-testid="zoya-living-avatar-canvas"]');
      if (!canvas) return false;
      const rect = canvas.getBoundingClientRect();
      return rect.width > 50 && rect.height > 50;
    });

    const screenshotPath = path.join(proofDir, `avatar_${avatarId}.png`);
    await page.screenshot({ path: screenshotPath });

    const status = (canvasCount === 1 && isCanvasRendered && activeAvatarId === avatarId)
      ? 'VERIFIED'
      : 'FAILED';

    results.push({
      id: avatarId,
      status,
      activeAvatarId,
      canvasCount,
      screenshot: `/assets/proof/avatar_${avatarId}.png`,
    });
    console.log(`  -> Status: ${status} (active: ${activeAvatarId}, canvases: ${canvasCount})`);
  }

  // Switching Test: Switch avatars 5 times consecutively
  console.log('[PROOF] Running 5-times consecutive avatar switching test...');
  const switchChain = [
    'boho_mini_dress',
    'avatar_midnight_gold_zari_saree',
    'avatar_urban_crop_hoodie',
    'plum_royal_anarkali',
    'avatar_pink_athleisure_track',
  ];

  let switchSuccess = true;
  for (let i = 0; i < switchChain.length; i++) {
    const nextId = switchChain[i];
    await page.evaluate((id) => {
      if (typeof window.__zoyaSelectAvatar === 'function') {
        window.__zoyaSelectAvatar(id);
      }
    }, nextId);
    await page.waitForTimeout(800);

    const activeCanvasCount = await page.evaluate(() => {
      return document.querySelectorAll('[data-testid="zoya-living-avatar-canvas"]').length;
    });

    const currentId = await page.evaluate(() => {
      return document.querySelector('[data-testid="zoya-avatar-rig"]')?.getAttribute('data-avatar-id');
    });

    if (activeCanvasCount !== 1 || currentId !== nextId) {
      console.error(`Switch step ${i + 1} (${nextId}) failed: count=${activeCanvasCount}, currentId=${currentId}`);
      switchSuccess = false;
    }
  }

  const finalSwitchScreenshotPath = path.join(proofDir, 'switch_5_final.png');
  await page.screenshot({ path: finalSwitchScreenshotPath });

  console.log('[PROOF] 5-times switch result:', switchSuccess ? 'PASSED (Exactly 1 active canvas throughout)' : 'FAILED');
  console.log('---BEGIN_RESULTS---');
  console.log(JSON.stringify({ results, switchSuccess }, null, 2));
  console.log('---END_RESULTS---');

  await browser.close();
}

run().catch((err) => {
  console.error('[PROOF] Error running test script:', err);
  process.exit(1);
});
