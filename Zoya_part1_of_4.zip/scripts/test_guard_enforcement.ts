import fs from 'fs';
import path from 'path';
import { AgentAuthManager } from '../src/services/agent/agentAuth.ts';

async function testGuardEnforcement() {
  console.log('========================================================================================');
  console.log('🛡️  TESTING PERMISSION GUARD ENFORCEMENT ON files/write, files/delete, files/revert, tools/execute');
  console.log('========================================================================================\n');

  const token = AgentAuthManager.getOrCreateToken();
  const headers = {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${token}`,
  };

  const testFile = 'guard_test_file.txt';
  const fullTestFilePath = path.join(process.cwd(), 'workspace', testFile);
  if (fs.existsSync(fullTestFilePath)) fs.unlinkSync(fullTestFilePath);

  // 1. files/write without approval
  console.log('1. Testing POST /api/agent/files/write without approval...');
  const res1 = await fetch('http://localhost:3000/api/agent/files/write', {
    method: 'POST',
    headers,
    body: JSON.stringify({ path: testFile, content: 'Initial Content 123' }),
  });
  const data1 = await res1.json();
  console.log(`   Status: ${res1.status}`);
  console.log(`   Response: status=${data1.status}, pendingId=${data1.pendingApproval?.id}`);
  const pass1 = res1.status === 202 && data1.status === 'APPROVAL_REQUIRED' && !fs.existsSync(fullTestFilePath);
  console.log(`   File created on disk: ${fs.existsSync(fullTestFilePath)} (Expected: false) -> ${pass1 ? 'PASS ✅' : 'FAIL ❌'}`);

  const approvalId1 = data1.pendingApproval?.id;

  // 2a. Self-approval test: Agent tries to approve with its own agent token -> Must be 403 Forbidden
  console.log('\n2a. Testing agent self-approval prevention (Agent token on approval endpoint)...');
  const resAgentSelfApprove = await fetch(`http://localhost:3000/api/agent/approvals/${approvalId1}/respond`, {
    method: 'POST',
    headers, // Agent token
    body: JSON.stringify({ approve: true }),
  });
  const dataAgentSelfApprove = await resAgentSelfApprove.json();
  const passSelfApproveBlocked = resAgentSelfApprove.status === 403 && dataAgentSelfApprove.code === 'AGENT_SELF_APPROVAL_FORBIDDEN';
  console.log(`   Self-approval blocked with 403: ${passSelfApproveBlocked ? 'PASS ✅' : 'FAIL ❌'} (${dataAgentSelfApprove.error})`);

  // 2b. Human User approves request using dedicated user approval credential
  console.log('\n2b. Approving request via user credential (x-user-approval-token)...');
  const userSecret = AgentAuthManager.getUserApprovalSecret();
  const userHeaders = {
    'Content-Type': 'application/json',
    'x-user-approval-token': userSecret,
  };
  const resApprove = await fetch(`http://localhost:3000/api/agent/approvals/${approvalId1}/respond`, {
    method: 'POST',
    headers: userHeaders,
    body: JSON.stringify({ approve: true }),
  });
  const dataApprove = await resApprove.json();
  console.log(`   User Approve Response: ${dataApprove.message} (success=${dataApprove.success})`);

  // 3. Retry files/write with approved approvalId
  console.log('\n3. Re-submitting POST /api/agent/files/write with approved approvalId...');
  const res2 = await fetch('http://localhost:3000/api/agent/files/write', {
    method: 'POST',
    headers,
    body: JSON.stringify({ path: testFile, content: 'Initial Content 123', approvalId: approvalId1 }),
  });
  const data2 = await res2.json();
  console.log(`   Status: ${res2.status}, Success: ${data2.success}`);
  const pass2 = res2.status === 200 && fs.existsSync(fullTestFilePath);
  console.log(`   File created on disk: ${fs.existsSync(fullTestFilePath)} (Expected: true) -> ${pass2 ? 'PASS ✅' : 'FAIL ❌'}`);

  // 4. files/revert without approval
  console.log('\n4. Testing POST /api/agent/files/revert without approval...');
  // First make an edit so there is a previous snapshot
  const resEditApprove = await fetch('http://localhost:3000/api/agent/files/write', {
    method: 'POST',
    headers,
    body: JSON.stringify({ path: testFile, content: 'Edited Content 456' }),
  });
  const dataEditApprove = await resEditApprove.json();
  await fetch(`http://localhost:3000/api/agent/approvals/${dataEditApprove.pendingApproval?.id}/respond`, {
    method: 'POST',
    headers: userHeaders,
    body: JSON.stringify({ approve: true }),
  });
  await fetch('http://localhost:3000/api/agent/files/write', {
    method: 'POST',
    headers,
    body: JSON.stringify({ path: testFile, content: 'Edited Content 456', approvalId: dataEditApprove.pendingApproval?.id }),
  });

  const resRevert = await fetch('http://localhost:3000/api/agent/files/revert', {
    method: 'POST',
    headers,
    body: JSON.stringify({ path: testFile }),
  });
  const dataRevert = await resRevert.json();
  console.log(`   Revert Status: ${resRevert.status}, status=${dataRevert.status}`);
  const pass4 = resRevert.status === 202 && dataRevert.status === 'APPROVAL_REQUIRED';
  console.log(`   Revert intercepted by Guard: ${pass4 ? 'PASS ✅' : 'FAIL ❌'}`);

  // 5. files/delete without approval
  console.log('\n5. Testing DELETE /api/agent/files/delete without approval...');
  const resDel = await fetch(`http://localhost:3000/api/agent/files/delete?path=${testFile}`, {
    method: 'DELETE',
    headers,
  });
  const dataDel = await resDel.json();
  console.log(`   Delete Status: ${resDel.status}, status=${dataDel.status}`);
  const pass5 = resDel.status === 202 && dataDel.status === 'APPROVAL_REQUIRED' && fs.existsSync(fullTestFilePath);
  console.log(`   File still preserved on disk: ${fs.existsSync(fullTestFilePath)} (Expected: true) -> ${pass5 ? 'PASS ✅' : 'FAIL ❌'}`);

  // 6. tools/execute without approval for mutating tool
  console.log('\n6. Testing POST /api/agent/tools/execute for mutating tool without approval...');
  const resTool = await fetch('http://localhost:3000/api/agent/tools/execute', {
    method: 'POST',
    headers,
    body: JSON.stringify({ toolName: 'write_file', args: { path: 'tool_test.txt', content: 'test' } }),
  });
  const dataTool = await resTool.json();
  console.log(`   Tool Status: ${resTool.status}, status=${dataTool.status}`);
  const pass6 = resTool.status === 202 && dataTool.status === 'APPROVAL_REQUIRED';
  console.log(`   Tool execution intercepted by Guard: ${pass6 ? 'PASS ✅' : 'FAIL ❌'}`);

  // 7. tools/execute with forbidden command
  console.log('\n7. Testing POST /api/agent/tools/execute with dangerous blocked command...');
  const resBlocked = await fetch('http://localhost:3000/api/agent/tools/execute', {
    method: 'POST',
    headers,
    body: JSON.stringify({ toolName: 'run_command', args: { command: 'cat /etc/passwd' } }),
  });
  const dataBlocked = await resBlocked.json();
  console.log(`   Blocked Status: ${resBlocked.status}, blocked=${dataBlocked.blocked}`);
  const pass7 = resBlocked.status === 403 && dataBlocked.blocked === true;
  console.log(`   Forbidden command blocked: ${pass7 ? 'PASS ✅' : 'FAIL ❌'}`);

  // Clean up test file
  if (fs.existsSync(fullTestFilePath)) fs.unlinkSync(fullTestFilePath);

  console.log('\n========================================================================================');
  const allPassed = pass1 && passSelfApproveBlocked && pass2 && pass4 && pass5 && pass6 && pass7;
  console.log(`RESULT: ${allPassed ? 'ALL GUARD TESTS PASSED ✅' : 'SOME GUARD TESTS FAILED ❌'}`);
  console.log('========================================================================================');

  if (!allPassed) process.exit(1);
}

testGuardEnforcement().catch((err) => {
  console.error('Guard test runner crashed:', err);
  process.exit(1);
});
