const sharp = require('sharp');

async function inspectSourceCleanlinessA() {
  const src = await sharp('public/assets/aistudio/file_00000000eb7881fa8a888c25bfc4c0f7_32dd4f88.png')
    .raw()
    .toBuffer({ resolveWithObject: true });

  const w = src.info.width;
  const h = src.info.height;

  console.log('Inspecting source file_00000000eb7881fa8a888c25bfc4c0f7_32dd4f88.png...');
  let veryLowAlpha = 0;
  let semiAlpha = 0;
  let fullAlpha = 0;
  let zeroAlpha = 0;

  for (let i = 0; i < src.data.length; i += 4) {
    const a = src.data[i + 3];
    if (a === 0) zeroAlpha++;
    else if (a < 15) veryLowAlpha++;
    else if (a < 240) semiAlpha++;
    else fullAlpha++;
  }

  console.log(`Alphas in pristine source: zero=${zeroAlpha}, veryLow(<15)=${veryLowAlpha}, semi=${semiAlpha}, full=${fullAlpha}`);

  // Check if there are any isolated pixels in pristine source below y=950
  let strayCount = 0;
  for (let y = 950; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const idx = (y * w + x) * 4;
      const a = src.data[idx + 3];
      if (a > 10 && (x < 370 || x > 620)) {
        strayCount++;
      }
    }
  }
  console.log(`Stray pixels in pristine source below y=950 outside [370..620]: ${strayCount}`);
}

inspectSourceCleanlinessA().catch(console.error);
