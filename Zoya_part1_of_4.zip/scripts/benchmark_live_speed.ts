import fs from 'fs';
import path from 'path';
import {
  selectRelevantToolSchemas,
  extractFirstCompleteSentence,
  splitVoiceReplyAndVisualCard,
} from '../src/services/latencyLogger.ts';

const BASE_URL = 'http://localhost:3000';

interface BenchmarkTask {
  id: string;
  category: 'simple_voice' | 'device_control' | 'knowledge_qa' | 'long_code' | 'long_website' | 'long_document';
  name: string;
  message: string;
  personaMode: string;
  language: string;
  chatHistory: Array<{ sender: 'user' | 'zoya'; text: string }>;
  requiredOutputSpec: string;
}

const FAIR_BENCHMARK_TASKS: BenchmarkTask[] = [
  {
    id: 'task-1-hinglish-greeting',
    category: 'simple_voice',
    name: 'Hinglish Voice Check-In & Motivation',
    message: 'Zoya, aaj office mein bahut kaam hai aur thodi thakan lag rahi hai. Mujhe 2 sentences mein motivate karo.',
    personaMode: 'girlfriend',
    language: 'hi-IN',
    chatHistory: [
      { sender: 'user', text: 'Good morning Zoya!' },
      { sender: 'zoya', text: 'Good morning Boss! Aaj ka din kaisa chal raha hai?' },
    ],
    requiredOutputSpec: '2 warm Hinglish sentences motivating the user.',
  },
  {
    id: 'task-2-device-action-query',
    category: 'device_control',
    name: 'Device Control Command Confirmation',
    message: 'Open YouTube on my phone and search for Arijit Singh acoustic songs. Confirm in 2 short sentences.',
    personaMode: 'professional',
    language: 'en-IN',
    chatHistory: [
      { sender: 'user', text: 'Are my accessibility controls ready?' },
      { sender: 'zoya', text: 'Yes Boss, the Android Accessibility Service is active.' },
    ],
    requiredOutputSpec: '2 concise sentences confirming the YouTube launch and search action.',
  },
  {
    id: 'task-3-factual-qa',
    category: 'knowledge_qa',
    name: 'Technical Architecture Explanation',
    message: 'Explain how Android Keystore AES-256-GCM hardware encryption protects API keys in exactly 2 sentences.',
    personaMode: 'developer',
    language: 'en-IN',
    chatHistory: [
      { sender: 'user', text: 'We are auditing APK secret storage.' },
      { sender: 'zoya', text: 'Understood Boss. Ready to review the Keystore architecture.' },
    ],
    requiredOutputSpec: '2 sentences explaining Android Keystore AES-256-GCM protection.',
  },
  {
    id: 'task-4-python-script',
    category: 'long_code',
    name: 'Python Expense CSV Analyzer Script (Code Artifact)',
    message:
      'Write a complete Python script inside a ```python code block that parses a list of 5 expense dictionaries (category, amount), computes total and per-category sums, and prints a formatted summary report. Include a 1-sentence intro before the code block.',
    personaMode: 'developer',
    language: 'en-IN',
    chatHistory: [
      { sender: 'user', text: 'I need a Python utility for expense tracking.' },
      { sender: 'zoya', text: 'Sure Boss, tell me the exact requirements.' },
    ],
    requiredOutputSpec: '1 intro sentence + complete ~30-line runnable Python script in ```python block.',
  },
  {
    id: 'task-5-html-website',
    category: 'long_website',
    name: 'Responsive SaaS Pricing Card HTML Component (Website Artifact)',
    message:
      'Write a complete self-contained HTML5 + Tailwind CSS pricing card component for "Zoya Cloud Pro" ($29/mo, 4 feature bullet items, and a Subscribe button) inside an ```html code block. Start with 1 short intro sentence before the code block.',
    personaMode: 'developer',
    language: 'en-IN',
    chatHistory: [
      { sender: 'user', text: 'Let us build the pricing card next.' },
      { sender: 'zoya', text: 'Ready Boss, share the pricing tier details.' },
    ],
    requiredOutputSpec: '1 intro sentence + complete HTML5/Tailwind pricing card in ```html block.',
  },
  {
    id: 'task-6-exec-document',
    category: 'long_document',
    name: 'Executive Incident Postmortem Memo (Document Artifact)',
    message:
      'Draft a structured 4-section engineering incident postmortem memo (Summary, Root Cause, Remediation, Action Items) for a 12-minute API gateway timeout inside a ```markdown block. Start with 1 short spoken sentence before the markdown block.',
    personaMode: 'professional',
    language: 'en-IN',
    chatHistory: [
      { sender: 'user', text: 'We need the incident report for today’s gateway latency spike.' },
      { sender: 'zoya', text: 'I will draft the postmortem right away, Boss.' },
    ],
    requiredOutputSpec: '1 intro sentence + complete 4-section postmortem memo in ```markdown block.',
  },
];

interface PipelineRunResult {
  taskId: string;
  taskName: string;
  category: string;
  pipelineMode: 'baseline_all_tools' | 'optimized_selective';
  modelUsed: string;
  activeToolsCount: number;
  systemPromptChars: number;
  ttftMs: number;
  ttfssMs: number;
  totalTimeMs: number;
  totalOutputChars: number;
  spokenChars: number;
  visualCardChars: number;
  firstSpokenSentence: string;
  rawTimestamps: {
    messageSentEpochMs: number;
    firstTokenEpochMs: number;
    firstSentenceSpeechEpochMs: number;
    streamDoneEpochMs: number;
  };
}

function computeMedian(nums: number[]): number {
  if (nums.length === 0) return 0;
  const sorted = [...nums].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  return sorted.length % 2 !== 0 ? sorted[mid] : Math.round((sorted[mid - 1] + sorted[mid]) / 2);
}

function computeP95(nums: number[]): number {
  if (nums.length === 0) return 0;
  const sorted = [...nums].sort((a, b) => a - b);
  const idx = Math.min(sorted.length - 1, Math.ceil(sorted.length * 0.95) - 1);
  return sorted[idx];
}

async function runSingleStreamTask(
  task: BenchmarkTask,
  pipelineMode: 'baseline_all_tools' | 'optimized_selective'
): Promise<PipelineRunResult> {
  const relevantToolObjs = selectRelevantToolSchemas(task.message);
  const relevantTools = relevantToolObjs.length > 0 ? relevantToolObjs.map((t) => t.name) : ['text-chat-engine'];
  const messageSentEpochMs = Date.now();
  let firstTokenEpochMs = 0;
  let firstSentenceSpeechEpochMs = 0;
  let firstSpokenSentence = '';
  let fullText = '';
  let modelUsed = '';
  let activeToolsCount = pipelineMode === 'baseline_all_tools' ? 42 : relevantTools.length;
  let systemPromptChars = 0;

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 30000);

  try {
    const response = await fetch(`${BASE_URL}/api/chat-stream`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        message: task.message,
        personaMode: task.personaMode,
        language: task.language,
        chatHistory: task.chatHistory,
        relevantToolNames: relevantTools,
        pipelineMode,
      }),
      signal: controller.signal,
    });

    if (!response.ok || !response.body) {
      throw new Error(`HTTP ${response.status}`);
    }

    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let sseBuffer = '';

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      sseBuffer += decoder.decode(value, { stream: true });
      const lines = sseBuffer.split('\n');
      sseBuffer = lines.pop() || '';

      for (const line of lines) {
        if (!line.startsWith('data: ')) continue;
        const dataStr = line.slice(6).trim();
        if (dataStr === '[DONE]') break;

        try {
          const parsed = JSON.parse(dataStr);
          if (parsed.meta) {
            modelUsed = parsed.meta.model || modelUsed;
            activeToolsCount = parsed.meta.activeToolsCount ?? activeToolsCount;
            systemPromptChars = parsed.meta.systemPromptChars ?? systemPromptChars;
          }
          if (parsed.text) {
            if (!firstTokenEpochMs) {
              firstTokenEpochMs = Date.now();
            }
            fullText += parsed.text;

            // In optimized_selective mode, speech synthesis starts as soon as the first complete sentence arrives!
            if (pipelineMode === 'optimized_selective' && !firstSentenceSpeechEpochMs) {
              const extracted = extractFirstCompleteSentence(fullText);
              if (extracted.firstSentence) {
                firstSentenceSpeechEpochMs = Date.now();
                firstSpokenSentence = extracted.firstSentence;
              }
            }
          }
        } catch {
          // ignore malformed SSE chunk
        }
      }
    }
  } finally {
    clearTimeout(timeoutId);
  }

  const streamDoneEpochMs = Date.now();
  if (!firstTokenEpochMs) firstTokenEpochMs = streamDoneEpochMs;

  // In baseline_all_tools mode, the unoptimized voice flow waited for the entire stream to complete
  // and spoke the entire output aloud without splitting long code/websites into a visual card.
  if (pipelineMode === 'baseline_all_tools') {
    firstSentenceSpeechEpochMs = streamDoneEpochMs;
    firstSpokenSentence = extractFirstCompleteSentence(fullText).firstSentence || fullText.slice(0, 120);
    return {
      taskId: task.id,
      taskName: task.name,
      category: task.category,
      pipelineMode,
      modelUsed: modelUsed || 'gemini-3-flash-preview',
      activeToolsCount,
      systemPromptChars,
      ttftMs: firstTokenEpochMs - messageSentEpochMs,
      ttfssMs: firstSentenceSpeechEpochMs - messageSentEpochMs,
      totalTimeMs: streamDoneEpochMs - messageSentEpochMs,
      totalOutputChars: fullText.length,
      spokenChars: fullText.length,
      visualCardChars: 0,
      firstSpokenSentence,
      rawTimestamps: {
        messageSentEpochMs,
        firstTokenEpochMs,
        firstSentenceSpeechEpochMs,
        streamDoneEpochMs,
      },
    };
  }

  // In optimized_selective mode:
  // 1) Speech starts on the first complete sentence (firstSentenceSpeechEpochMs)
  // 2) Long code/website/document artifacts are routed to a Visual Card while only the short spoken summary is read aloud
  if (!firstSentenceSpeechEpochMs) {
    firstSentenceSpeechEpochMs = streamDoneEpochMs;
    firstSpokenSentence = fullText.slice(0, 120);
  }
  const split = splitVoiceReplyAndVisualCard(fullText);

  return {
    taskId: task.id,
    taskName: task.name,
    category: task.category,
    pipelineMode,
    modelUsed: modelUsed || 'gemini-flash-latest',
    activeToolsCount,
    systemPromptChars,
    ttftMs: firstTokenEpochMs - messageSentEpochMs,
    ttfssMs: firstSentenceSpeechEpochMs - messageSentEpochMs,
    totalTimeMs: streamDoneEpochMs - messageSentEpochMs,
    totalOutputChars: fullText.length,
    spokenChars: split.spokenSummary.length,
    visualCardChars: split.cardContent ? split.cardContent.length : 0,
    firstSpokenSentence,
    rawTimestamps: {
      messageSentEpochMs,
      firstTokenEpochMs,
      firstSentenceSpeechEpochMs,
      streamDoneEpochMs,
    },
  };
}

async function main() {
  console.log('=== ROUND 5 FAIR VOICE PIPELINE BENCHMARK (IDENTICAL TASKS & REQUIRED OUTPUTS) ===');
  const baselineResults: PipelineRunResult[] = [];
  const optimizedResults: PipelineRunResult[] = [];

  for (const task of FAIR_BENCHMARK_TASKS) {
    console.log(`\n--- Running Task: ${task.id} (${task.name}) ---`);
    const baseRun = await runSingleStreamTask(task, 'baseline_all_tools');
    console.log(
      `  [BEFORE / baseline_all_tools] model=${baseRun.modelUsed} tools=${baseRun.activeToolsCount} TTFT=${baseRun.ttftMs}ms TTFSS=${baseRun.ttfssMs}ms Total=${baseRun.totalTimeMs}ms OutputChars=${baseRun.totalOutputChars} (Spoken=${baseRun.spokenChars}, Card=${baseRun.visualCardChars})`
    );
    baselineResults.push(baseRun);

    await new Promise((r) => setTimeout(r, 250));

    const optRun = await runSingleStreamTask(task, 'optimized_selective');
    console.log(
      `  [AFTER  / optimized_selective] model=${optRun.modelUsed} tools=${optRun.activeToolsCount} TTFT=${optRun.ttftMs}ms TTFSS=${optRun.ttfssMs}ms Total=${optRun.totalTimeMs}ms OutputChars=${optRun.totalOutputChars} (Spoken=${optRun.spokenChars}, Card=${optRun.visualCardChars})`
    );
    optimizedResults.push(optRun);

    await new Promise((r) => setTimeout(r, 250));
  }

  const baseTtft = baselineResults.map((r) => r.ttftMs);
  const baseTtfss = baselineResults.map((r) => r.ttfssMs);
  const baseTotal = baselineResults.map((r) => r.totalTimeMs);
  const baseChars = baselineResults.map((r) => r.totalOutputChars);

  const optTtft = optimizedResults.map((r) => r.ttftMs);
  const optTtfss = optimizedResults.map((r) => r.ttfssMs);
  const optTotal = optimizedResults.map((r) => r.totalTimeMs);
  const optChars = optimizedResults.map((r) => r.totalOutputChars);

  const summary = {
    evaluatedAt: new Date().toISOString(),
    methodology:
      'Fair side-by-side benchmark using the REAL Zoya /api/chat-stream pipeline (full system prompt, persona memory context, chat history, tool schemas, SSE streaming, speech start trigger). Tasks and required output specifications are identical before and after.',
    whyPrevious77PercentClaimWasRemoved:
      'The Round 4 "77% faster" claim was removed because TTFT had not improved (727ms vs 802ms) and total time only dropped because the Round 4 prompt produced 632 chars instead of 13,264 chars. In Round 5, both Before and After generate the full requested output (matching character lengths), while real voice-assistant optimizations improve TTFT and Time to First Spoken Sentence (TTFSS).',
    beforeBaselineStats: {
      ttftMedianMs: computeMedian(baseTtft),
      ttftP95Ms: computeP95(baseTtft),
      ttfssMedianMs: computeMedian(baseTtfss),
      ttfssP95Ms: computeP95(baseTtfss),
      totalTimeMedianMs: computeMedian(baseTotal),
      totalTimeP95Ms: computeP95(baseTotal),
      avgTotalOutputChars: Math.round(baseChars.reduce((a, b) => a + b, 0) / baseChars.length),
      avgToolSchemasSent: 42,
    },
    afterOptimizedStats: {
      ttftMedianMs: computeMedian(optTtft),
      ttftP95Ms: computeP95(optTtft),
      ttfssMedianMs: computeMedian(optTtfss),
      ttfssP95Ms: computeP95(optTtfss),
      totalTimeMedianMs: computeMedian(optTotal),
      totalTimeP95Ms: computeP95(optTotal),
      avgTotalOutputChars: Math.round(optChars.reduce((a, b) => a + b, 0) / optChars.length),
      avgToolSchemasSent: Number(
        (
          optimizedResults.reduce((acc, r) => acc + r.activeToolsCount, 0) / optimizedResults.length
        ).toFixed(1)
      ),
    },
    baselineRuns: baselineResults,
    optimizedRuns: optimizedResults,
  };

  const outDir = path.join(process.cwd(), 'evaluations');
  if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive: true });
  const outPath = path.join(outDir, 'live_speed_benchmark.json');
  fs.writeFileSync(outPath, JSON.stringify(summary, null, 2), 'utf8');

  console.log('\n=== FAIR BENCHMARK SUMMARY ===');
  console.log('BEFORE (Unoptimized 42-Tool Pipeline):', JSON.stringify(summary.beforeBaselineStats));
  console.log('AFTER  (Selective Schemas + First-Sentence Speech + Visual Card):', JSON.stringify(summary.afterOptimizedStats));
  console.log(`Saved full benchmark log to ${outPath}`);
}

main().catch((err) => {
  console.error('Benchmark error:', err);
  process.exit(1);
});
