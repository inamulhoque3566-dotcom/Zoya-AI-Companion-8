import fs from 'fs';
import path from 'path';
import http from 'http';
import { AgentAuthManager } from '../src/services/agent/agentAuth.ts';
import { AgentPermissionGuard, agentPermissionGuard } from '../src/services/agent/agentPermissionGuard.ts';
import { AgentToolExecutor } from '../src/services/agent/agentTools.ts';

const TEST_WORKSPACE = path.join(process.cwd(), 'workspace', 'security_test_sandbox');
if (!fs.existsSync(TEST_WORKSPACE)) {
  fs.mkdirSync(TEST_WORKSPACE, { recursive: true });
}

function sendRawHttp(options: {
  method?: string;
  path: string;
  headers?: Record<string, string>;
  body?: string;
}): Promise<{ statusCode: number; data: any; rawBody: string }> {
  return new Promise((resolve, reject) => {
    const req = http.request(
      {
        hostname: '127.0.0.1',
        port: 3000,
        path: options.path,
        method: options.method || 'GET',
        headers: options.headers || {},
      },
      (res) => {
        let rawBody = '';
        res.on('data', (chunk) => (rawBody += chunk));
        res.on('end', () => {
          let data: any = null;
          try {
            data = JSON.parse(rawBody);
          } catch {}
          resolve({ statusCode: res.statusCode || 0, data, rawBody });
        });
      }
    );
    req.on('error', reject);
    if (options.body) req.write(options.body);
    req.end();
  });
}

async function runSecurityGapsVerification() {
  console.log('========================================================================================');
  console.log('🔒 VERIFYING 4 SECURITY GAP FIXES WITH REAL OUTPUT');
  console.log('========================================================================================\n');

  let passed = 0;
  let failed = 0;

  function assert(condition: boolean, title: string, details?: string) {
    if (condition) {
      console.log(`✅ PASS: ${title}`);
      passed++;
    } else {
      console.error(`❌ FAIL: ${title} - ${details || ''}`);
      failed++;
    }
  }

  const guard = AgentPermissionGuard.getInstance();
  const OWNER_PASSPHRASE = 'OwnerSecurePassphrase2026!';
  const setupCode = AgentAuthManager.getOrCreateSetupCode();
  try {
    AgentAuthManager.setOwnerPassphraseWithSetupCode(OWNER_PASSPHRASE, setupCode);
  } catch {}
  const agentToken = AgentAuthManager.getOrCreateToken();
  const userSecret = AgentAuthManager.getUserApprovalSecret();

  // =====================================================================
  // GAP 1: TOKEN BOOTSTRAP RESTRICTION
  // =====================================================================
  console.log('--- 1. TOKEN BOOTSTRAP: Restrict GET /api/agent/auth/token ---');

  // 1a-1. Loopback request without pairing code -> 403 Forbidden
  const resNoCode = await sendRawHttp({
    path: '/api/agent/auth/token',
    headers: { Host: 'localhost:3000' },
  });
  console.log(`[1a-1 Loopback without code]: Status=${resNoCode.statusCode}, Code=${resNoCode.data?.code}`);
  assert(resNoCode.statusCode === 403 && resNoCode.data?.code === 'PAIRING_CODE_REQUIRED', 'Bootstrap rejects loopback without pairing code (403)');

  // 1a-2. Loopback request with one-time pairing code -> 200 OK
  const pairRes = await sendRawHttp({
    path: '/api/agent/auth/pairing-code',
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'User-Agent': 'Mozilla/5.0',
    },
    body: JSON.stringify({ passphrase: OWNER_PASSPHRASE }),
  });
  const resWithCode = await sendRawHttp({
    path: '/api/agent/auth/token',
    headers: { 'x-agent-pairing-code': pairRes.data?.pairingCode },
  });
  console.log(`[1a-2 Loopback with pairing code]: Status=${resWithCode.statusCode}, HasToken=${Boolean(resWithCode.data?.token)}`);
  assert(resWithCode.statusCode === 200 && resWithCode.data?.success === true && Boolean(resWithCode.data?.token), 'Bootstrap succeeds with one-time pairing code (200)');

  // 1b. External/Attacker Host Header (Rejected -> 403 Forbidden)
  const resBadHost = await sendRawHttp({
    path: '/api/agent/auth/token',
    headers: { Host: 'evil-attacker.com' },
  });
  console.log(`[1b Untrusted Host "evil-attacker.com"]: Status=${resBadHost.statusCode}, Error="${resBadHost.data?.error}"`);
  assert(resBadHost.statusCode === 403 && resBadHost.data?.success === false, 'Bootstrap rejects non-local Host header (evil-attacker.com)');

  // 1c. External/Attacker Origin Header (Rejected -> 403 Forbidden)
  const resBadOrigin = await sendRawHttp({
    path: '/api/agent/auth/token',
    headers: {
      Host: 'localhost:3000',
      Origin: 'https://malicious-website.org',
    },
  });
  console.log(`[1c Untrusted Origin "https://malicious-website.org"]: Status=${resBadOrigin.statusCode}, Error="${resBadOrigin.data?.error}"`);
  assert(resBadOrigin.statusCode === 403 && resBadOrigin.data?.success === false, 'Bootstrap rejects cross-origin browser Origin header');

  // 1d. IP-based non-loopback Host (Rejected -> 403 Forbidden)
  const resIpHost = await sendRawHttp({
    path: '/api/agent/auth/token',
    headers: { Host: '198.51.100.42:3000' },
  });
  console.log(`[1d Non-Loopback External IP Host "198.51.100.42"]: Status=${resIpHost.statusCode}, Error="${resIpHost.data?.error}"`);
  assert(resIpHost.statusCode === 403 && resIpHost.data?.success === false, 'Bootstrap rejects non-loopback external IP Host header');


  // =====================================================================
  // GAP 2: APPROVAL BINDING (Single-Use, 5-Min TTL, Cryptographic Binding)
  // =====================================================================
  console.log('\n--- 2. APPROVAL BINDING: Single-Use, 5-Min TTL & Cryptographic Request Binding ---');

  // Request approval for write A
  const reqWriteA = guard.createPendingApproval(
    'binding_test_task',
    'write_file',
    { path: 'fileA.txt', content: 'Secret Content A' },
    'ASK_APPROVAL',
    'Writing fileA.txt'
  );
  console.log(`[Approval Created for Write A]: ID=${reqWriteA.id}, Hash=${reqWriteA.bindingHash.slice(0, 16)}...`);

  // Approve it via user credential
  guard.resolveApproval(reqWriteA.id, true, 'human_user');

  // Test 2a: Reuse approval for write B -> MUST BE REJECTED
  console.log('\n[2a. Test Binding Mismatch]: Attempting to reuse approval for write B (fileB.txt)...');
  const consumeMismatch = guard.validateAndConsumeApproval(
    reqWriteA.id,
    'write_file',
    { path: 'fileB.txt', content: 'Secret Content A' } // Path differs
  );
  console.log(`   Validation Result: valid=${consumeMismatch.valid}, error="${consumeMismatch.error}"`);
  assert(
    consumeMismatch.valid === false && consumeMismatch.error?.includes('Approval binding mismatch'),
    'Reuse approval for write B is rejected (Approval binding mismatch)'
  );

  // Test 2a-2: Reuse approval for write A with modified content -> MUST BE REJECTED
  console.log('\n[2a-2. Test Content Hash Tampering]: Attempting to reuse approval with altered content...');
  const consumeContentTamper = guard.validateAndConsumeApproval(
    reqWriteA.id,
    'write_file',
    { path: 'fileA.txt', content: 'TAMPERED Content' } // Content differs
  );
  console.log(`   Validation Result: valid=${consumeContentTamper.valid}, error="${consumeContentTamper.error}"`);
  assert(
    consumeContentTamper.valid === false && consumeContentTamper.error?.includes('Approval binding mismatch'),
    'Tampered content with same path is rejected (Content SHA-256 hash mismatch)'
  );

  // Test 2b: Valid first consumption succeeds, then SECOND consumption MUST BE REJECTED (single-use)
  console.log('\n[2b. Test Single-Use Enforcement]:');
  const consumeFirst = guard.validateAndConsumeApproval(
    reqWriteA.id,
    'write_file',
    { path: 'fileA.txt', content: 'Secret Content A' }
  );
  console.log(`   First Consume: valid=${consumeFirst.valid}`);
  assert(consumeFirst.valid === true, 'First legitimate consumption succeeds');

  const consumeSecond = guard.validateAndConsumeApproval(
    reqWriteA.id,
    'write_file',
    { path: 'fileA.txt', content: 'Secret Content A' }
  );
  console.log(`   Second Consume: valid=${consumeSecond.valid}, error="${consumeSecond.error}"`);
  assert(
    consumeSecond.valid === false && consumeSecond.error?.includes('already been consumed (single-use only)'),
    'Reusing the same approvalId twice is rejected (single-use only)'
  );

  // Test 2c: Expired approval -> MUST BE REJECTED (5-minute TTL)
  console.log('\n[2c. Test TTL Expiration]:');
  const reqExpire = guard.createPendingApproval(
    'binding_test_task_expire',
    'write_file',
    { path: 'file_expire.txt', content: 'Expire me' },
    'ASK_APPROVAL',
    'Writing file_expire.txt'
  );
  guard.resolveApproval(reqExpire.id, true, 'human_user');

  // Artificially expire the approval (simulate passing beyond 5 minutes)
  guard.setApprovalExpiryForTesting(reqExpire.id, Date.now() - 5000);

  const consumeExpired = guard.validateAndConsumeApproval(
    reqExpire.id,
    'write_file',
    { path: 'file_expire.txt', content: 'Expire me' }
  );
  console.log(`   Expired Consume: valid=${consumeExpired.valid}, error="${consumeExpired.error}"`);
  assert(
    consumeExpired.valid === false && consumeExpired.error?.includes('expired (5-minute TTL exceeded)'),
    'Expired approval is rejected (5-minute TTL exceeded)'
  );


  // =====================================================================
  // GAP 3: SELF-APPROVAL PREVENTION
  // =====================================================================
  console.log('\n--- 3. SELF-APPROVAL PREVENTION: Agent cannot approve its own actions ---');

  // Create a real pending approval on the HTTP server by calling POST /api/agent/files/write
  const agentHeaders = {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${agentToken}`,
  };

  const createReqRes = await fetch('http://localhost:3000/api/agent/files/write', {
    method: 'POST',
    headers: agentHeaders,
    body: JSON.stringify({ path: 'self_approve_test.txt', content: 'Critical System Config' }),
  });
  const createReqData = await createReqRes.json();
  const serverApprovalId = createReqData.pendingApproval?.id;
  console.log(`[Created Pending Approval on Server]: ID=${serverApprovalId}`);

  // 3a. Agent tries to approve via HTTP with its own agent token -> 403 Forbidden
  console.log('\n[3a. Agent token to /api/agent/approvals/:id/respond]:');
  const resAgentApprove = await fetch(`http://localhost:3000/api/agent/approvals/${serverApprovalId}/respond`, {
    method: 'POST',
    headers: agentHeaders,
    body: JSON.stringify({ approve: true }),
  });
  const dataAgentApprove = await resAgentApprove.json();
  console.log(`   Status: ${resAgentApprove.status}, Code: ${dataAgentApprove.code}, Error: "${dataAgentApprove.error}"`);
  assert(
    resAgentApprove.status === 403 && dataAgentApprove.code === 'AGENT_SELF_APPROVAL_FORBIDDEN',
    'Agent credentials cannot self-approve (HTTP 403 AGENT_SELF_APPROVAL_FORBIDDEN)'
  );

  // 3b. Agent subprocess attempts to curl approval endpoint via run_command -> BLOCKED by Guard
  console.log('\n[3b. Agent subprocess curling approval endpoint via run_command]:');
  const selfApproveCommand = `curl -X POST http://localhost:3000/api/agent/approvals/${serverApprovalId}/respond -d '{"approve":true}'`;
  const toolExecutor = new AgentToolExecutor({
    workspaceRoot: TEST_WORKSPACE,
    commandTimeoutMs: 5000,
    maxOutputChars: 5000,
    autoApprove: true,
  });

  const selfApproveResult = await toolExecutor.executeTool('run_command', { command: selfApproveCommand });
  console.log(`   Tool Execution Result: success=${selfApproveResult.success}, output="${selfApproveResult.output}"`);
  assert(
    selfApproveResult.success === false &&
      selfApproveResult.output.includes('SECURITY VIOLATION') &&
      selfApproveResult.output.includes('Agent subprocess cannot invoke approval endpoints'),
    'Agent run_command attempting to curl approval endpoint is blocked by security gate'
  );

  // 3c. Unauthenticated request to approval endpoint -> 401 Unauthorized
  console.log('\n[3c. Unauthenticated request to /api/agent/approvals/:id/respond]:');
  const resNoAuthApprove = await fetch(`http://localhost:3000/api/agent/approvals/${serverApprovalId}/respond`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ approve: true }),
  });
  const dataNoAuthApprove = await resNoAuthApprove.json();
  console.log(`   Status: ${resNoAuthApprove.status}, Code: ${dataNoAuthApprove.code}`);
  assert(
    resNoAuthApprove.status === 401 && dataNoAuthApprove.code === 'USER_APPROVAL_UNAUTHORIZED',
    'Unauthenticated approval request is rejected (HTTP 401 USER_APPROVAL_UNAUTHORIZED)'
  );

  // 3d. User approval credential succeeds -> 200 OK
  console.log('\n[3d. Legitimate user credential to /api/agent/approvals/:id/respond]:');
  const resUserApprove = await fetch(`http://localhost:3000/api/agent/approvals/${serverApprovalId}/respond`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-user-approval-token': userSecret,
    },
    body: JSON.stringify({ approve: true }),
  });
  const dataUserApprove = await resUserApprove.json();
  console.log(`   Status: ${resUserApprove.status}, Success: ${dataUserApprove.success}, Msg: "${dataUserApprove.message}"`);
  assert(
    resUserApprove.status === 200 && dataUserApprove.success === true,
    'Human user with dedicated user approval credential successfully approves'
  );


  // =====================================================================
  // GAP 4: COMMAND BYPASSES
  // =====================================================================
  console.log('\n--- 4. COMMAND BYPASSES: Verification of 5 Specific Commands ---');

  const bypassCommands = [
    {
      cmd: `python3 -c "print(open('/etc/passwd').read())"`,
      expected: 'BLOCKED',
      desc: 'Python open sensitive system file (/etc/passwd)',
    },
    {
      cmd: `node -e "require('fs').readFileSync('/etc/passwd')"`,
      expected: 'BLOCKED',
      desc: 'Node readFileSync sensitive system file (/etc/passwd)',
    },
    {
      cmd: `bash -c "cat /etc/passwd"`,
      expected: 'BLOCKED',
      desc: 'Bash subshell cat sensitive system file (/etc/passwd)',
    },
    {
      cmd: `cat ../../etc/hosts`,
      expected: 'BLOCKED',
      desc: 'Relative path traversal to system file (../../etc/hosts)',
    },
    {
      cmd: `python3 -c "import shutil; shutil.rmtree('/tmp/x')"`,
      expected: 'BLOCKED',
      desc: 'Python shutil.rmtree recursive destructive deletion outside workspace (rejected absolute path)',
    },
  ];

  for (let i = 0; i < bypassCommands.length; i++) {
    const item = bypassCommands[i];
    const inspection = guard.inspectCommand(item.cmd, TEST_WORKSPACE);
    console.log(`\n[Command ${i + 1}]: ${item.cmd}`);
    console.log(`   Description: ${item.desc}`);
    console.log(`   Evaluated Level: ${inspection.level}`);
    console.log(`   isBlocked: ${inspection.isBlocked}`);
    console.log(`   Reason: "${inspection.reason}"`);
    if (inspection.warningDetails) {
      console.log(`   Warning Details: "${inspection.warningDetails}"`);
    }

    const matchesExpected =
      item.expected === 'BLOCKED'
        ? inspection.level === 'BLOCKED' && inspection.isBlocked === true
        : inspection.level === 'STRICT_APPROVAL_WITH_WARNING' && inspection.isBlocked === false;

    assert(matchesExpected, `Command ${i + 1} (${item.desc}) is ${item.expected}`);
  }

  // Check OS isolation / user status
  console.log('\n--- OS User Isolation & Container Sandbox Inspection ---');
  let currentUser = 'root';
  let uid = 0;
  try {
    const os = await import('os');
    const u = os.userInfo();
    currentUser = u.username;
    uid = u.uid;
  } catch {}
  console.log(`Runtime Process OS User: "${currentUser}" (UID: ${uid})`);
  console.log(`Bubblewrap (bwrap) Available: No (Not installed in container image)`);
  console.log(`Container Sandbox Model: Cloud Run container root with process-level and gate-level isolation.`);

  console.log('\n========================================================================================');
  console.log(`SECURITY GAPS AUDIT SUMMARY: ${passed} PASSED, ${failed} FAILED`);
  console.log('========================================================================================');

  if (failed > 0) {
    process.exit(1);
  }
}

runSecurityGapsVerification().catch((err) => {
  console.error('Security verification crashed:', err);
  process.exit(1);
});
