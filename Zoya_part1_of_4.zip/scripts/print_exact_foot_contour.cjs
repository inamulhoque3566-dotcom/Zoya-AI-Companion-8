const sharp = require('sharp');
const path = require('path');

async function printExactFootContour() {
  const { data, info } = await sharp(path.join(__dirname, '../src/assets/images/zoya_3d_sweater_glasses_1793764031303.jpg'))
    .raw()
    .toBuffer({ resolveWithObject: true });

  const W = info.width;
  for (let y = 1215; y <= 1364; y += 5) {
    let leftMin = -1, leftMax = -1;
    let rightMin = -1, rightMax = -1;
    for (let x = 320; x <= 460; x++) {
      const idx = (y * W + x) * 3;
      const r = data[idx], g = data[idx + 1], b = data[idx + 2];
      // Background is neutral grey r~200..215, g~200..215, b~200..215, chroma <= 8
      const chroma = Math.max(Math.abs(r - g), Math.abs(r - b), Math.abs(g - b));
      const isBlackShoe = r < 55 && g < 55 && b < 55;
      const isShoeLeather = (r < 75 && g < 75 && b < 75);
      const isShoeBuckle = (r > 120 && g > 110 && b < 90);
      const isWhiteSock = (r > 200 && g > 200 && b > 200 && (data[(y-1)*W + x]*3 > 200)) || (r > 175 && g > 175 && b > 175 && chroma <= 6 && y < 1275);
      // Let's check distance to rowBg
      const isBg = chroma <= 7 && r > 185 && g > 185 && b > 185;

      const isLegOrShoe = !isBg && (isBlackShoe || isShoeLeather || isShoeBuckle || (y < 1275 && chroma <= 12 && r < 200));

      // Separate into left leg (x < 390) and right leg (x >= 390)
      if (x < 390) {
        if (isLegOrShoe) {
          if (leftMin === -1) leftMin = x;
          leftMax = x;
        }
      } else {
        if (isLegOrShoe) {
          if (rightMin === -1) rightMin = x;
          rightMax = x;
        }
      }
    }
    console.log(`y=${y}: Left=[${leftMin}..${leftMax}] | Right=[${rightMin}..${rightMax}]`);
  }
}

printExactFootContour().catch(console.error);
