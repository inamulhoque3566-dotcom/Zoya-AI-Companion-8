const sharp = require('sharp');
const path = require('path');
const fs = require('fs');

async function processZoyaSweater() {
  const srcPath = path.join(__dirname, '../src/assets/images/zoya_3d_sweater_glasses_1793764031303.jpg');
  const destPath = path.join(__dirname, '../public/assets/images/anime_princess_3d_transparent.png');

  const { data: origRgb, info } = await sharp(srcPath).removeAlpha().raw().toBuffer({ resolveWithObject: true });
  const W = info.width;
  const H = info.height;
  console.log(`Processing Zoya Sweater: ${W}x${H}`);

  // 1. Calibrate per-row studio background color from outer left & right margins (x=2..15)
  const rowBg = new Array(H);
  for (let y = 0; y < H; y++) {
    let r = 0, g = 0, b = 0, c = 0;
    for (let x = 2; x < 16; x++) {
      const i1 = (y * W + x) * 3;
      const i2 = (y * W + (W - 1 - x)) * 3;
      r += origRgb[i1] + origRgb[i2];
      g += origRgb[i1 + 1] + origRgb[i2 + 1];
      b += origRgb[i1 + 2] + origRgb[i2 + 2];
      c += 2;
    }
    rowBg[y] = [r / c, g / c, b / c];
  }

  // Exact function to check if (x, y) is inside the leg/shoe geometry for y >= 1215
  const isInsideLegEnvelopes = (x, y) => {
    if (y < 1215 || y > 1362) return false;
    
    // Left leg / sock / shoe
    let leftMin = 327, leftMax = 375;
    if (y >= 1270 && y <= 1340) {
      leftMin = 325;
      leftMax = 388;
    } else if (y > 1340 && y <= 1355) {
      leftMin = 328;
      leftMax = 386;
    } else if (y > 1355) {
      leftMin = 336;
      leftMax = 379;
    }
    if (x >= leftMin && x <= leftMax) return true;

    // Right leg / sock / shoe
    let rightMin = 405, rightMax = 453;
    if (y >= 1270 && y <= 1340) {
      rightMin = 394;
      rightMax = 456;
    } else if (y > 1340 && y <= 1355) {
      rightMin = 394;
      rightMax = 456;
    } else if (y > 1355) {
      rightMin = 403;
      rightMax = 444;
    }
    if (x >= rightMin && x <= rightMax) return true;

    return false;
  };

  // 2. Determine background candidates across entire image
  const isBgCandidate = new Uint8Array(W * H);

  for (let y = 0; y < H; y++) {
    const [bgR, bgG, bgB] = rowBg[y];
    for (let x = 0; x < W; x++) {
      const idx = y * W + x;
      const idx3 = idx * 3;
      const r = origRgb[idx3];
      const g = origRgb[idx3 + 1];
      const b = origRgb[idx3 + 2];

      // Above top of hair
      if (y < 28) {
        isBgCandidate[idx] = 1;
        continue;
      }

      // Below bottom of shoes
      if (y > 1362) {
        isBgCandidate[idx] = 1;
        continue;
      }

      // For lower section y >= 1215:
      if (y >= 1215) {
        if (!isInsideLegEnvelopes(x, y)) {
          // Outside the two leg envelopes is 100% background!
          isBgCandidate[idx] = 1;
          continue;
        } else {
          // Inside the leg envelopes: check if it's the gap or floor shadow
          // Left shoe/right shoe is dark leather or buckle or white sock
          isBgCandidate[idx] = 0;
          continue;
        }
      }

      // Torso & Skirt region y in [28, 1214]
      // Protected white sweater: y in [230, 530], x in [260, 510]
      if (y >= 230 && y <= 530 && x >= 270 && x <= 498) {
        isBgCandidate[idx] = 0;
        continue;
      }

      // Distance to background
      const distToBg = Math.sqrt((r - bgR) ** 2 + (g - bgG) ** 2 + (b - bgB) ** 2);
      const chroma = Math.max(Math.abs(r - g), Math.abs(r - b), Math.abs(g - b));

      // Neutral studio background
      if (distToBg < 28 && chroma <= 10) {
        isBgCandidate[idx] = 1;
      } else if (distToBg < 45 && chroma <= 6) {
        isBgCandidate[idx] = 1;
      } else {
        isBgCandidate[idx] = 0;
      }
    }
  }

  // 3. Flood-fill from outer border
  const bgMask = new Uint8Array(W * H);
  const queue = new Int32Array(W * H);
  let qHead = 0, qTail = 0;

  const pushBg = (idx) => {
    if (bgMask[idx] === 0) {
      bgMask[idx] = 1;
      queue[qTail++] = idx;
    }
  };

  // Push borders
  for (let x = 0; x < W; x++) {
    pushBg(x);
    pushBg((H - 1) * W + x);
  }
  for (let y = 0; y < H; y++) {
    pushBg(y * W);
    pushBg(y * W + (W - 1));
  }

  while (qHead < qTail) {
    const curr = queue[qHead++];
    const cx0 = curr % W;
    const cy0 = Math.floor(curr / W);

    if (cx0 + 1 < W && isBgCandidate[curr + 1] && bgMask[curr + 1] === 0) pushBg(curr + 1);
    if (cx0 - 1 >= 0 && isBgCandidate[curr - 1] && bgMask[curr - 1] === 0) pushBg(curr - 1);
    if (cy0 + 1 < H && isBgCandidate[curr + W] && bgMask[curr + W] === 0) pushBg(curr + W);
    if (cy0 - 1 >= 0 && isBgCandidate[curr - W] && bgMask[curr - W] === 0) pushBg(curr - W);
  }

  // 4. Construct final RGBA with antialiased edges
  const outRgba = new Uint8Array(W * H * 4);

  for (let y = 0; y < H; y++) {
    const [bgR, bgG, bgB] = rowBg[y];
    for (let x = 0; x < W; x++) {
      const idx = y * W + x;
      const idx3 = idx * 3;
      const idx4 = idx * 4;

      let r = origRgb[idx3];
      let g = origRgb[idx3 + 1];
      let b = origRgb[idx3 + 2];

      // Hard 0 alpha rules
      if (y < 28 || y > 1362) {
        outRgba[idx4] = 0; outRgba[idx4 + 1] = 0; outRgba[idx4 + 2] = 0; outRgba[idx4 + 3] = 0;
        continue;
      }
      if (y >= 1215 && !isInsideLegEnvelopes(x, y)) {
        outRgba[idx4] = 0; outRgba[idx4 + 1] = 0; outRgba[idx4 + 2] = 0; outRgba[idx4 + 3] = 0;
        continue;
      }
      if (bgMask[idx] === 1) {
        outRgba[idx4] = 0; outRgba[idx4 + 1] = 0; outRgba[idx4 + 2] = 0; outRgba[idx4 + 3] = 0;
        continue;
      }

      // Check distance to bg for edge softening
      const distToBg = Math.sqrt((r - bgR) ** 2 + (g - bgG) ** 2 + (b - bgB) ** 2);

      // Check if neighboring any bgMask pixel (boundary pixel)
      let isEdge = false;
      for (let dy = -1; dy <= 1; dy++) {
        for (let dx = -1; dx <= 1; dx++) {
          const ny = y + dy, nx = x + dx;
          if (ny >= 0 && ny < H && nx >= 0 && nx < W) {
            if (bgMask[ny * W + nx] === 1 || (ny >= 1215 && !isInsideLegEnvelopes(nx, ny))) {
              isEdge = true;
              break;
            }
          }
        }
        if (isEdge) break;
      }

      let alpha = 255;
      if (isEdge && !(y >= 230 && y <= 530 && x >= 270 && x <= 498)) {
        if (distToBg < 30) {
          alpha = Math.round(Math.max(0, Math.min(255, ((distToBg - 10) / 20) * 255)));
        }
      }

      outRgba[idx4] = r;
      outRgba[idx4 + 1] = g;
      outRgba[idx4 + 2] = b;
      outRgba[idx4 + 3] = alpha;
    }
  }

  // Save to target transparent PNG
  await sharp(outRgba, {
    raw: { width: W, height: H, channels: 4 }
  })
    .png()
    .toFile(destPath);

  console.log(`Saved flawless transparent avatar to: ${destPath}`);
}

processZoyaSweater().catch(console.error);
