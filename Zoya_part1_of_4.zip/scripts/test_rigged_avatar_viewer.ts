import * as THREE from 'three';
import { AVATAR_GLB_LIST } from '../src/data/avatarGlbConfig';
import { createProceduralHumanoidAvatar } from '../src/services/avatar/riggedAvatarEngine';

console.log('====================================================');
console.log('🧪 TESTING 17 RIGGED 3D AVATARS ENGINE & CONFIG');
console.log('====================================================\n');

let allPassed = true;

// 1. Verify 17 Avatar Slots
console.log('[TEST 1] Verifying AVATAR_GLB_LIST (17 slots)...');
if (AVATAR_GLB_LIST.length !== 17) {
  console.error(`❌ Expected exactly 17 avatars, but found ${AVATAR_GLB_LIST.length}`);
  allPassed = false;
} else {
  console.log(`✅ Exact count: 17 avatar slots verified.`);
}

AVATAR_GLB_LIST.forEach((av, i) => {
  if (av.id !== i + 1) {
    console.error(`❌ Avatar slot ID mismatch at index ${i}: expected ${i + 1}, got ${av.id}`);
    allPassed = false;
  }
  if (!av.path || !av.name) {
    console.error(`❌ Avatar slot missing path or name at index ${i}`);
    allPassed = false;
  }
});
console.log(`✅ All 17 avatar slots properly mapped with IDs 1 to 17 and valid GLB paths.`);

// 2. Verify Procedural Rigged Avatar Generation
console.log('\n[TEST 2] Verifying Procedural Rigged Humanoid Avatar Generator...');
const testAvatar = createProceduralHumanoidAvatar('TestAvatar', '#8C9BFF');

const foundBones = new Set<string>();
let headMeshWithMorphs: THREE.Mesh | null = null;

testAvatar.traverse((child) => {
  if ((child as THREE.Bone).isBone) {
    foundBones.add(child.name);
  }
  if ((child as THREE.Mesh).isMesh) {
    const m = child as THREE.Mesh;
    if (m.morphTargetDictionary && (m.morphTargetDictionary['eyeBlinkLeft'] !== undefined || m.morphTargetDictionary['blink'] !== undefined)) {
      headMeshWithMorphs = m;
    }
  }
});

const requiredBones = [
  'mixamorigHips',
  'mixamorigSpine',
  'mixamorigChest',
  'mixamorigNeck',
  'mixamorigHead',
  'mixamorigLeftShoulder',
  'mixamorigLeftArm',
  'mixamorigLeftForeArm',
  'mixamorigLeftHand',
  'mixamorigRightShoulder',
  'mixamorigRightArm',
  'mixamorigRightForeArm',
  'mixamorigRightHand',
  'mixamorigLeftUpLeg',
  'mixamorigLeftLeg',
  'mixamorigLeftFoot',
  'mixamorigRightUpLeg',
  'mixamorigRightLeg',
  'mixamorigRightFoot',
];

let missingRequiredCount = 0;
for (const b of requiredBones) {
  if (!foundBones.has(b)) {
    console.error(`❌ Missing bone in procedural skeleton: ${b}`);
    missingRequiredCount++;
    allPassed = false;
  }
}

if (missingRequiredCount === 0) {
  console.log(`✅ All 19 required humanoid bones found in skeleton.`);
}

if (!headMeshWithMorphs) {
  console.error(`❌ No mesh with eyelid morph targets found!`);
  allPassed = false;
} else {
  console.log(`✅ Eyelid morph targets detected: ${Object.keys(headMeshWithMorphs.morphTargetDictionary || {}).join(', ')}`);
}

// 3. Test Pattern-Based Matching
console.log('\n[TEST 3] Testing Pattern-Based Bone Regex Matching...');
const sampleBoneNames = [
  // Mixamo
  'mixamorigHips',
  'mixamorigLeftShoulder',
  'mixamorigLeftArm',
  'mixamorigLeftForeArm',
  'mixamorigLeftHand',
  'mixamorigRightShoulder',
  'mixamorigRightArm',
  'mixamorigRightForeArm',
  'mixamorigRightHand',
  // VRM / RPM / Blender
  'LeftShoulder',
  'left_arm',
  'lowerarm_l',
  'hand.l',
  'RightShoulder',
  'right_arm',
  'lowerarm_r',
  'hand.r',
  'pelvis',
];

const BONE_PATTERNS = {
  hips: /^(hips|pelvis|root|mixamorig[:_]?hips|bip01[:_]?pelvis|cc_base_hip)$/i,
  leftShoulder: /(left.*(shoulder|clavicle)|mixamorig[:_]?leftshoulder|clavicle_l|shoulder\.l)/i,
  leftArm: /(left.*(upperarm|arm)|mixamorig[:_]?leftarm|upperarm_l|arm\.l)/i,
  leftForeArm: /(left.*(forearm|lowerarm)|mixamorig[:_]?leftforearm|lowerarm_l|forearm\.l)/i,
  leftHand: /(left.*hand|mixamorig[:_]?lefthand|hand_l|hand\.l)/i,
  rightShoulder: /(right.*(shoulder|clavicle)|mixamorig[:_]?rightshoulder|clavicle_r|shoulder\.r)/i,
  rightArm: /(right.*(upperarm|arm)|mixamorig[:_]?rightarm|upperarm_r|arm\.r)/i,
  rightForeArm: /(right.*(forearm|lowerarm)|mixamorig[:_]?rightforearm|lowerarm_r|forearm\.r)/i,
  rightHand: /(right.*hand|mixamorig[:_]?righthand|hand_r|hand\.r)/i,
};

let patternMatches = 0;
for (const name of sampleBoneNames) {
  let matched = false;
  for (const [key, pat] of Object.entries(BONE_PATTERNS)) {
    if (pat.test(name)) {
      matched = true;
      patternMatches++;
      break;
    }
  }
  if (!matched) {
    console.error(`❌ Name "${name}" failed to match any bone pattern`);
    allPassed = false;
  }
}
console.log(`✅ All ${sampleBoneNames.length} sample convention names matched successfully.`);

// 4. Verify Blinking Timing Specification
console.log('\n[TEST 4] Verifying Blinking Timing Specs...');
const minBlinkDuration = 0.12; // 120ms
const maxBlinkDuration = 0.18; // 180ms
const closeDuration = 0.045; // 45ms
const holdDuration = 0.020; // 20ms

for (let i = 0; i < 50; i++) {
  const dur = 0.12 + Math.random() * 0.06;
  if (dur < minBlinkDuration || dur > maxBlinkDuration) {
    console.error(`❌ Blink duration out of range: ${dur}`);
    allPassed = false;
  }
  const openDuration = dur - closeDuration - holdDuration;
  if (openDuration <= closeDuration) {
    console.error(`❌ Open duration not slower than close duration`);
    allPassed = false;
  }
}
console.log(`✅ Blinking timings: 120-180ms total, fast close (45ms), slower open (55-115ms) verified.`);

console.log('\n====================================================');
if (allPassed) {
  console.log('🎉 ALL RIGGED 3D AVATAR TESTS PASSED 100%!');
  console.log('====================================================\n');
  process.exit(0);
} else {
  console.error('❌ SOME CHECKS FAILED');
  process.exit(1);
}
