# Android Project & APK Build Inspection Script
import os
import re
import json

print("== ZOYA ANDROID PROJECT & APK BUILD INSPECTOR ==")

android_dir = os.path.abspath(os.path.join(os.getcwd(), "android"))
manifest_path = os.path.join(android_dir, "app", "src", "main", "AndroidManifest.xml")
gradle_path = os.path.join(android_dir, "app", "build.gradle.kts")

print(f"Android Root: {android_dir}")
print(f"Manifest Exists: {os.path.exists(manifest_path)}")
print(f"Gradle File Exists: {os.path.exists(gradle_path)}")

# 1. Audit Android Manifest
if os.path.exists(manifest_path):
    with open(manifest_path, "r", encoding="utf-8") as f:
        content = f.read()
    
    permissions = re.findall(r'<uses-permission\s+android:name="([^"]+)"', content)
    services = re.findall(r'<service\s+android:name="([^"]+)"', content)
    
    print(f"\nDeclared Permissions ({len(permissions)}):")
    for p in permissions:
        print(f"  • {p}")
        
    print(f"\nRegistered Services ({len(services)}):")
    for s in services:
        print(f"  • {s}")

# 2. Check Gradle Configurations
if os.path.exists(gradle_path):
    with open(gradle_path, "r", encoding="utf-8") as f:
        gradle_content = f.read()
        
    compile_sdk = re.search(r'compileSdk\s*=\s*(\d+)', gradle_content)
    min_sdk = re.search(r'minSdk\s*=\s*(\d+)', gradle_content)
    target_sdk = re.search(r'targetSdk\s*=\s*(\d+)', gradle_content)
    
    print(f"\nSDK Targets:")
    print(f"  • compileSdk: {compile_sdk.group(1) if compile_sdk else 'unknown'}")
    print(f"  • minSdk: {min_sdk.group(1) if min_sdk else 'unknown'}")
    print(f"  • targetSdk: {target_sdk.group(1) if target_sdk else 'unknown'}")

print("\n✓ Android build structure audit completed successfully.")
