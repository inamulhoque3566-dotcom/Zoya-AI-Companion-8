# Excel Spreadsheet Creation with OpenPyXL in Zoya Python Studio
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

print("== OpenPyXL Spreadsheet Generator ==")

wb = openpyxl.Workbook()
ws = wb.active
ws.title = "Q4 Financial Overview"

# Color themes
header_fill = PatternFill(start_color="1E293B", end_color="1E293B", fill_type="solid")
header_font = Font(name="Calibri", size=11, bold=True, color="FFFFFF")
accent_fill = PatternFill(start_color="F1F5F9", end_color="F1F5F9", fill_type="solid")
bold_font = Font(name="Calibri", size=11, bold=True)
currency_format = '"$"#,##0.00'

# Title row
ws.merge_cells("A1:E1")
title_cell = ws["A1"]
title_cell.value = "ZOYA AUTOMATED FINANCIAL LEDGER — Q4 2026"
title_cell.font = Font(name="Calibri", size=14, bold=True, color="0F172A")
title_cell.alignment = Alignment(horizontal="center", vertical="center")
ws.row_dimensions[1].height = 30

# Table headers
headers = ["Department", "Budget Allocation", "Actual Spend", "Variance ($)", "Utilization (%)"]
ws.append([])
ws.append(headers)
ws.row_dimensions[3].height = 24

for col_idx, header in enumerate(headers, 1):
    cell = ws.cell(row=3, column=col_idx)
    cell.fill = header_fill
    cell.font = header_font
    cell.alignment = Alignment(horizontal="center", vertical="center")

# Department records
records = [
    ["AI Model Inference", 120000, 114500],
    ["Mobile Android Client", 65000, 61200],
    ["Cloud Infrastructure", 85000, 89400],
    ["Security & Audit", 45000, 38000],
    ["Voice Synthesis Services", 55000, 52300],
]

for r_idx, (dept, budget, actual) in enumerate(records, 4):
    var_formula = f"=B{r_idx}-C{r_idx}"
    util_formula = f"=C{r_idx}/B{r_idx}"
    ws.append([dept, budget, actual, var_formula, util_formula])
    
    # Apply number formats
    ws[f"B{r_idx}"].number_format = currency_format
    ws[f"C{r_idx}"].number_format = currency_format
    ws[f"D{r_idx}"].number_format = currency_format
    ws[f"E{r_idx}"].number_format = "0.0%"
    ws.row_dimensions[r_idx].height = 20

# Totals row
totals_row = 4 + len(records)
ws.append(["TOTAL", f"=SUM(B4:B{totals_row-1})", f"=SUM(C4:C{totals_row-1})", f"=SUM(D4:D{totals_row-1})", f"=C{totals_row}/B{totals_row}"])
ws.row_dimensions[totals_row].height = 22

for col_letter in ["A", "B", "C", "D", "E"]:
    cell = ws[f"{col_letter}{totals_row}"]
    cell.font = bold_font
    cell.fill = accent_fill
    if col_letter in ["B", "C", "D"]:
        cell.number_format = currency_format
    elif col_letter == "E":
        cell.number_format = "0.0%"

# Auto-fit column widths
for col in ws.columns:
    max_len = max(len(str(cell.value or '')) for cell in col)
    col_letter = get_column_letter(col[0].column)
    ws.column_dimensions[col_letter].width = max(max_len + 4, 14)

excel_filename = "zoya_q4_financial_ledger.xlsx"
wb.save(excel_filename)
print(f"✓ Excel Workbook generated successfully: {excel_filename}")
print(f"• Includes 5 departments, dynamic formulas, and currency formatting.")
