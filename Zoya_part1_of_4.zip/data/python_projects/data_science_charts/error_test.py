
print("Step 1 ok")
raise ValueError("Intentional test exception for error pipeline audit")
