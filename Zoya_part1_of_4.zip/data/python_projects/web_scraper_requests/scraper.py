# Web Scraping & Structured Extraction with Requests & BeautifulSoup
import requests
from bs4 import BeautifulSoup
import json
import csv

print("== Zoya Web Extraction Pipeline ==")

# Simulate HTML response or fetch public quote
sample_html = """
<!DOCTYPE html>
<html>
<head><title>Zoya Technology Radar 2026</title></head>
<body>
    <div class="header">
        <h1>Emerging Mobile & AI Technologies</h1>
        <span class="updated">Last updated: October 2026</span>
    </div>
    <div class="tech-grid">
        <div class="card" data-category="mobile">
            <h3 class="title">Jetpack Compose 1.8</h3>
            <span class="rating">9.4</span>
            <p class="desc">Declarative UI framework for modern Android apps.</p>
        </div>
        <div class="card" data-category="ai">
            <h3 class="title">Gemini 2.5 Flash</h3>
            <span class="rating">9.8</span>
            <p class="desc">High-speed multimodal AI inference with sub-second response.</p>
        </div>
        <div class="card" data-category="voice">
            <h3 class="title">Neural TTS Streaming</h3>
            <span class="rating">9.6</span>
            <p class="desc">Real-time sentence chunk audio streaming with zero latency.</p>
        </div>
        <div class="card" data-category="python">
            <h3 class="title">Python 3.10 Subprocess Sandbox</h3>
            <span class="rating">9.9</span>
            <p class="desc">Isolated runtime environment with full C-extension support.</p>
        </div>
    </div>
</body>
</html>
"""

soup = BeautifulSoup(sample_html, 'html.parser')
page_title = soup.title.string if soup.title else "Untitled"
print(f"Document Title: {page_title}")

cards = soup.find_all('div', class_='card')
print(f"Found {len(cards)} technology cards:\n")

extracted_items = []
for idx, card in enumerate(cards, 1):
    title = card.find('h3', class_='title').get_text(strip=True)
    rating = float(card.find('span', class_='rating').get_text(strip=True))
    desc = card.find('p', class_='desc').get_text(strip=True)
    cat = card.get('data-category', 'general')
    
    extracted_items.append({
        "id": idx,
        "title": title,
        "category": cat,
        "rating": rating,
        "description": desc
    })
    print(f"[{idx}] {title} (Rating: {rating}/10) [{cat}]")
    print(f"    {desc}")

# Write to JSON
json_filename = "extracted_technologies.json"
with open(json_filename, "w", encoding="utf-8") as jf:
    json.dump(extracted_items, jf, indent=2)

# Write to CSV
csv_filename = "extracted_technologies.csv"
with open(csv_filename, "w", newline="", encoding="utf-8") as cf:
    writer = csv.DictWriter(cf, fieldnames=["id", "title", "category", "rating", "description"])
    writer.writeheader()
    writer.writerows(extracted_items)

print(f"\n✓ Saved structured results to:")
print(f"  • {json_filename}")
print(f"  • {csv_filename}")
