/**
 * Zoya AI — Editable Banking, UPI, Payment & Credential App Blocklist
 *
 * SECURITY POLICY:
 * Zoya Accessibility Service & Voice Automation will NEVER inspect, read, tap,
 * type into, or automate any app in this list or matching the financial package regex.
 *
 * Keep this blocklist synchronized with:
 * `android/app/src/main/java/com/openclaw/assistant/bridge/accessibility/BankingSafetyConfig.kt`
 */

const CUSTOM_BLOCKLIST_STORAGE_KEY = 'zoya_custom_blocked_financial_packages_v1';

export const BLOCKED_FINANCIAL_PACKAGES: readonly string[] = [
  // UPI & Payment Apps (India)
  'com.google.android.apps.nbu.paisa.user', // Google Pay (GPay)
  'com.phonepe.app',                        // PhonePe
  'net.one97.paytm',                        // Paytm
  'in.org.npci.upiapp',                     // BHIM UPI
  'in.amazon.mShop.android.shopping',       // Amazon (Amazon Pay)
  'com.dreamplug.androidapp',               // CRED
  'com.mobikwik_new',                       // MobiKwik
  'com.freecharge.android',                 // Freecharge
  'com.bharatpe.app',                       // BharatPe
  'com.slice',                              // slice
  'com.uni.app',                            // Uni Cards
  'money.jupiter',                          // Jupiter Money
  'com.epifi.paisa',                        // Fi Money
  'com.fampay.in',                          // FamPay
  'com.naviapp',                            // Navi UPI & Loans
  'com.myairtelapp',                        // Airtel Thanks
  'com.jio.myjio',                          // MyJio (JioPay)
  'com.jio.bapp',                           // JioFinance

  // Major Indian Banks
  'com.sbi.lotusintouch',                   // YONO SBI
  'com.sbi.SBIFreedomPlus',                 // YONO Lite SBI
  'com.snapwork.hdfc',                      // HDFC Bank MobileBanking
  'com.hdfcbank.payzapp',                   // HDFC PayZapp
  'com.csam.icici.bank.imobile',            // iMobile Pay by ICICI Bank
  'com.axis.mobile',                        // Axis Mobile
  'com.msf.kbank.mobile',                   // Kotak 811 & Mobile Banking
  'com.infrasoft.uboi',                     // Union Bank of India (Vyom)
  'com.baroda.mpassbook',                   // Bank of Baroda Passbook
  'com.bankofbaroda.mconnect',              // bob World
  'com.Version1',                           // PNB ONE
  'com.canarabank.mobility',                // Canara ai1
  'com.idfcfirstbank.optimus',              // IDFC FIRST Bank
  'com.indusind.indie',                     // INDIE by IndusInd
  'com.fss.indus',                          // IndusMobile
  'com.yesbank',                            // IRIS by YES BANK
  'com.rblbank.mobank',                     // RBL MoBank
  'com.fedmobile',                          // FedMobile
  'com.Bandhan.Bandhan',                    // mBandhan
  'com.boi.ua.android',                     // BOI Mobile
  'com.cbi.bank',                           // Central Bank of India
  'com.indianbank.indpay',                  // IndOASIS
  'com.iob.iobmobile',                      // IOB Mobile
  'com.uco.mbs',                            // UCO mBanking Plus
  'com.idbibank.goMobilePlus',              // IDBI Bank GO Mobile+
  'com.dbs.in.digitalbank',                 // digibank by DBS
  'com.scb.breeze.android.in',              // Standard Chartered India
  'com.hsbc.hsbcindia',                     // HSBC India
  'com.citibank.mobile.in',                 // Citi Mobile India
  'com.au.small.finance.bank',              // AU 0101
  'com.ippb.app',                           // IPPB Mobile Banking
  'com.airtel.paymentsbank',                // Airtel Payments Bank
  'com.paytmpaymentsbank',                  // Paytm Payments Bank
  'com.finopaymentbank.mobile',             // FinoPay

  // Stock Brokers, Mutual Funds & Crypto
  'com.zerodha.kite3',                      // Zerodha Kite
  'com.zerodha.coin',                       // Zerodha Coin
  'com.nextbillion.groww',                  // Groww
  'in.upstox.app',                          // Upstox
  'com.msf.angelmobile',                    // Angel One
  'com.icicidirect.markets',                // ICICIdirect
  'com.hdfcsec.investright',                // HDFC Sky
  'com.kotak.neo',                          // Kotak Neo
  'com.dhan.live',                          // Dhan
  'com.indmoney',                           // INDmoney
  'com.kuvera.android',                     // Kuvera
  'com.etmoney.webapp',                     // ET Money
  'com.coinswitch.kuber',                   // CoinSwitch
  'com.coindcx.btc',                        // CoinDCX
  'com.binance.dev',                        // Binance
  'com.coinbase.android',                   // Coinbase

  // International Payment & Banking Apps
  'com.paypal.android.p2pmobile',           // PayPal
  'com.venmo',                              // Venmo
  'com.squareup.cash',                      // Cash App
  'com.revolut.revolut',                    // Revolut
  'com.transferwise.android',               // Wise
  'com.stripe.android.dashboard',           // Stripe
  'com.google.android.apps.walletnfcrel',   // Google Wallet
  'com.samsung.android.spay',               // Samsung Pay
  'com.chase.sig.android',                  // Chase Mobile
  'com.infonow.bofa',                       // Bank of America
  'com.wf.wellsfargomobile',                // Wells Fargo
  'com.citi.citimobile',                    // Citi Mobile

  // Password Managers & 2FA Authenticators
  'com.x8bit.bitwarden',                    // Bitwarden
  'com.agilebits.onepassword',              // 1Password
  'com.lastpass.lpandroid',                 // LastPass
  'com.dashlane',                           // Dashlane
  'com.proton.android.pass',                // Proton Pass
  'com.google.android.apps.authenticator2', // Google Authenticator
  'com.azure.authenticator',                // Microsoft Authenticator
  'com.authy.authy',                        // Authy

  // Additional Verified Indian & Global Financial / Broker Packages
  'com.fi.money',
  'org.openlake.slice',
  'com.postpe.app',
  'org.altruist.BajajExperia',
  'com.indiabulls.consumer',
  'com.tatadigital.tcp',
  'com.airtel.thanks',
  'com.finobank.bpay',
  'com.ippb.mobilebanking',
  'com.paywithring',
  'com.lazypay.android',
  'com.simpl.android',
  'money.freo.save',
  'com.uni.cards',
  'com.fivepaisa.trade',
  'in.indmoney',
  'com.etmoney.android',
  'com.scripbox.app',
  'com.myjar.app',
  'com.gullak.app',
  'com.motilalofficial',
  'com.sharekhan',
  'com.icicisecurities',
  'com.icicibank.pockets',
  'com.axis.open',
  'com.pnb.pnbone',
  'com.unionbank.ecommerce.mobile.android',
  'com.indusind.mpassbook',
  'com.boi.bankofindia',
  'com.infrasofttech.centmobile',
  'com.federalbank.fedmobile',
  'com.sc.scmobile.in',
  'com.hsbc.in.hsbcpersonalbanking',
  'com.monzo.android',
  'co.coinodc.cx',
  'com.wazirx.android',
  'com.mudrex.app',
  'com.kucoin.android',
  'com.kraken.invest.app',
  'com.bitbns',
  'com.sbi.upi',
  'com.kotak.cherry',
  'com.cred.android',
];

const BLOCKED_SET = new Set(BLOCKED_FINANCIAL_PACKAGES.map((p) => p.toLowerCase()));

/**
 * Explicit fail-closed allowlist: ONLY these non-financial utility/communication packages are permitted.
 * Everything else (including unknown packages and all banking/UPI/wallet packages) is blocked by default.
 */
export const ALLOWED_AUTOMATION_PACKAGES: readonly string[] = [
  'com.whatsapp',
  'com.whatsapp.w4b',
  'com.google.android.dialer',
  'com.android.dialer',
  'com.samsung.android.dialer',
  'com.google.android.contacts',
  'com.android.contacts',
  'com.google.android.apps.messaging',
  'com.android.mms',
  'com.google.android.youtube',
  'com.spotify.music',
  'com.google.android.deskclock',
  'com.android.deskclock',
  'com.google.android.calendar',
  'com.google.android.apps.maps',
  'com.android.camera',
  'com.google.android.googlecamera',
  'com.google.android.calculator',
  'com.android.calculator2',
];

const ALLOWED_SET = new Set(ALLOWED_AUTOMATION_PACKAGES.map((p) => p.toLowerCase()));

/**
 * Heuristic pattern used by the Banking Shield Self-Test screen to flag any installed
 * app whose name or package contains financial keywords ("pay", "bank", "upi", "wallet", "fin", etc.).
 */
const FINANCIAL_HEURISTIC_REGEX =
  /(bank|pay|upi|wallet|fin|money|credit|loan|invest|trade|brok|cash|coin|wealth|card|insurance|mutual|fund|emi|vault|authenticator|passbook|bhim|chit|goldloan|sbi|hdfc|icici|axis|kotak)/i;

export interface InstalledAppShieldEntry {
  packageName: string;
  appName: string;
  isUserApp: boolean;
  isBlocked: boolean;
  isCustomBlocked: boolean;
  looksFinancial: boolean;
  flaggedUnblockedFinancial: boolean;
  matchedReason: string;
}

export interface BankingShieldSelfTestReport {
  source: 'android_package_manager' | 'web_preview_sample';
  totalScanned: number;
  blockedCount: number;
  flaggedUnblockedCount: number;
  safeNonFinancialCount: number;
  apps: InstalledAppShieldEntry[];
}

const inMemoryCustomBlocked = new Set<string>();

export function getCustomBlockedPackages(): string[] {
  const combined = new Set<string>(inMemoryCustomBlocked);
  try {
    if (typeof localStorage !== 'undefined') {
      const raw = localStorage.getItem(CUSTOM_BLOCKLIST_STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) {
          parsed.forEach((p) => {
            const clean = String(p).trim().toLowerCase();
            if (clean) combined.add(clean);
          });
        }
      }
    }
  } catch {
    // ignore
  }
  return Array.from(combined);
}

export function addCustomBlockedPackage(packageName: string): string[] {
  const clean = packageName.trim().toLowerCase();
  if (!clean) return getCustomBlockedPackages();

  inMemoryCustomBlocked.add(clean);
  const updated = getCustomBlockedPackages();

  try {
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem(CUSTOM_BLOCKLIST_STORAGE_KEY, JSON.stringify(updated));
    }
  } catch {
    // ignore
  }

  try {
    const bridge = typeof window !== 'undefined' ? (window as any).AndroidBridge : null;
    if (bridge && typeof bridge.addCustomBlockedPackage === 'function') {
      bridge.addCustomBlockedPackage(clean);
    }
  } catch {
    // ignore
  }

  return updated;
}

export function removeCustomBlockedPackage(packageName: string): string[] {
  const clean = packageName.trim().toLowerCase();
  inMemoryCustomBlocked.delete(clean);
  const current = new Set(getCustomBlockedPackages());
  current.delete(clean);
  const updated = Array.from(current);

  try {
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem(CUSTOM_BLOCKLIST_STORAGE_KEY, JSON.stringify(updated));
    }
  } catch {
    // ignore
  }

  try {
    const bridge = typeof window !== 'undefined' ? (window as any).AndroidBridge : null;
    if (bridge && typeof bridge.removeCustomBlockedPackage === 'function') {
      bridge.removeCustomBlockedPackage(clean);
    }
  } catch {
    // ignore
  }

  return updated;
}

export function isBlockedFinancialPackage(packageName?: string | null): boolean {
  if (!packageName || typeof packageName !== 'string') return true;
  const normalized = packageName.trim().toLowerCase();
  if (!normalized) return true;
  if (BLOCKED_SET.has(normalized)) return true;
  if (getCustomBlockedPackages().includes(normalized)) return true;
  // Fail-closed: block everything not on the explicit allowlist
  return !ALLOWED_SET.has(normalized);
}

export function looksLikeFinancialApp(packageName?: string | null, appName?: string | null): boolean {
  const pkg = (packageName || '').trim().toLowerCase();
  const label = (appName || '').trim().toLowerCase();
  return BLOCKED_SET.has(pkg) || FINANCIAL_HEURISTIC_REGEX.test(pkg) || FINANCIAL_HEURISTIC_REGEX.test(label);
}

export function evaluateAppForBankingShield(
  packageName: string,
  appName: string,
  isUserApp = true
): InstalledAppShieldEntry {
  const cleanPkg = packageName.trim();
  const lowerPkg = cleanPkg.toLowerCase();
  const customList = getCustomBlockedPackages();
  const isCustomBlocked = customList.includes(lowerPkg);
  const isStaticBlocked = BLOCKED_SET.has(lowerPkg);
  const isAllowed = !isCustomBlocked && !isStaticBlocked && ALLOWED_SET.has(lowerPkg);
  const isBlocked = !isAllowed;
  const looksFinancial = looksLikeFinancialApp(cleanPkg, appName);

  let matchedReason = 'ALLOWED: Explicit Non-Financial Automation Allowlist';
  if (isCustomBlocked) {
    matchedReason = 'BLOCKED: User Custom Blocklist';
  } else if (isStaticBlocked) {
    matchedReason = 'BLOCKED: Exact Banking/UPI Package List';
  } else if (!isAllowed) {
    matchedReason = 'BLOCKED: Fail-Closed Policy (Package not in explicit allowlist)';
  }

  return {
    packageName: cleanPkg,
    appName: appName.trim() || cleanPkg,
    isUserApp,
    isBlocked,
    isCustomBlocked,
    looksFinancial,
    flaggedUnblockedFinancial: looksFinancial && !isBlocked,
    matchedReason,
  };
}

/**
 * Sample representative device app list used ONLY when previewing in a desktop/mobile browser
 * outside the installed Android APK. Includes a couple of regional/unlisted financial-looking
 * apps so the user can test flagging & 1-click blocking right in the UI as well as on the phone.
 */
const WEB_PREVIEW_SAMPLE_INSTALLED_APPS: Array<{ packageName: string; appName: string; isUserApp: boolean }> = [
  { packageName: 'com.google.android.apps.nbu.paisa.user', appName: 'Google Pay (GPay)', isUserApp: true },
  { packageName: 'com.phonepe.app', appName: 'PhonePe UPI', isUserApp: true },
  { packageName: 'net.one97.paytm', appName: 'Paytm', isUserApp: true },
  { packageName: 'com.sbi.lotusintouch', appName: 'YONO SBI', isUserApp: true },
  { packageName: 'com.snapwork.hdfc', appName: 'HDFC Bank MobileBanking', isUserApp: true },
  { packageName: 'com.zerodha.kite3', appName: 'Zerodha Kite', isUserApp: true },
  { packageName: 'org.coop.saraswat.mobilepassbook', appName: 'Saraswat Co-op Fin Passbook', isUserApp: true },
  { packageName: 'in.regional.keralagramin.smartpay', appName: 'Kerala Gramin SmartPay', isUserApp: true },
  { packageName: 'com.whatsapp', appName: 'WhatsApp Messenger', isUserApp: true },
  { packageName: 'com.google.android.youtube', appName: 'YouTube', isUserApp: false },
  { packageName: 'com.instagram.android', appName: 'Instagram', isUserApp: true },
  { packageName: 'com.spotify.music', appName: 'Spotify', isUserApp: true },
];

/**
 * Runs the Banking Shield Self-Test across installed apps on the phone (via AndroidBridge)
 * or clearly labeled web preview sample apps when in a browser.
 */
export function runBankingShieldInstalledAppsAudit(
  extraTestPackages: Array<{ packageName: string; appName: string }> = []
): BankingShieldSelfTestReport {
  let rawApps: Array<{ packageName: string; appName: string; isUserApp: boolean }> = [];
  let source: 'android_package_manager' | 'web_preview_sample' = 'web_preview_sample';

  try {
    const bridge = typeof window !== 'undefined' ? (window as any).AndroidBridge : null;
    if (bridge && typeof bridge.getInstalledAppsJson === 'function') {
      const resJson = bridge.getInstalledAppsJson();
      const parsed = JSON.parse(resJson);
      if (parsed && parsed.success && Array.isArray(parsed.apps)) {
        source = 'android_package_manager';
        rawApps = parsed.apps.map((a: any) => ({
          packageName: String(a.packageName || ''),
          appName: String(a.appName || a.packageName || ''),
          isUserApp: Boolean(a.isUserApp ?? true),
        }));
      }
    }
  } catch {
    // Fallback to web_preview_sample
  }

  if (rawApps.length === 0) {
    rawApps = [...WEB_PREVIEW_SAMPLE_INSTALLED_APPS];
  }

  for (const extra of extraTestPackages) {
    if (
      extra.packageName &&
      !rawApps.some((a) => a.packageName.toLowerCase() === extra.packageName.toLowerCase())
    ) {
      rawApps.unshift({
        packageName: extra.packageName,
        appName: extra.appName || extra.packageName,
        isUserApp: true,
      });
    }
  }

  const evaluated = rawApps.map((app) =>
    evaluateAppForBankingShield(app.packageName, app.appName, app.isUserApp)
  );

  // Sort: Flagged unblocked financial apps first, then Blocked apps, then standard apps
  evaluated.sort((a, b) => {
    if (a.flaggedUnblockedFinancial !== b.flaggedUnblockedFinancial) {
      return a.flaggedUnblockedFinancial ? -1 : 1;
    }
    if (a.isBlocked !== b.isBlocked) {
      return a.isBlocked ? -1 : 1;
    }
    return a.appName.localeCompare(b.appName);
  });

  const blockedCount = evaluated.filter((a) => a.isBlocked).length;
  const flaggedUnblockedCount = evaluated.filter((a) => a.flaggedUnblockedFinancial).length;
  const safeNonFinancialCount = evaluated.length - blockedCount - flaggedUnblockedCount;

  return {
    source,
    totalScanned: evaluated.length,
    blockedCount,
    flaggedUnblockedCount,
    safeNonFinancialCount,
    apps: evaluated,
  };
}

export const BLOCKED_BANKING_PACKAGES = BLOCKED_FINANCIAL_PACKAGES;

export const SAFETY_BLOCKED_MESSAGE =
  'Security Shield: Banking, UPI, and financial apps or websites cannot be automated or accessed by Zoya.';

export function isPackageBlocked(packageName?: string | null): boolean {
  return isBlockedFinancialPackage(packageName);
}

const BROWSER_PACKAGES = new Set([
  'com.android.chrome',
  'org.chromium.chrome',
  'org.mozilla.firefox',
  'com.microsoft.emmx',
  'com.opera.browser',
  'com.brave.browser',
  'com.sec.android.app.sbrowser',
  'com.duckduckgo.mobile.android',
]);

export function isBrowserPackage(packageName?: string | null): boolean {
  if (!packageName) return false;
  return BROWSER_PACKAGES.has(packageName.trim().toLowerCase());
}

export function isBrowserHostBlocked(urlOrHost?: string | null): { blocked: boolean; reason?: string } {
  if (!urlOrHost) return { blocked: true, reason: SAFETY_BLOCKED_MESSAGE };
  const lower = urlOrHost.trim().toLowerCase();
  if (FINANCIAL_HEURISTIC_REGEX.test(lower)) {
    return {
      blocked: true,
      reason: SAFETY_BLOCKED_MESSAGE,
    };
  }
  return { blocked: false };
}

export function evaluateDeviceActionSafety(
  targetPackageOrText?: string | null,
  targetUrl?: string | null,
  options?: { failClosedIfUnknownBrowserUrl?: boolean }
): { isSafe: boolean; reason: string } {
  if (isBlockedFinancialPackage(targetPackageOrText)) {
    return { isSafe: false, reason: SAFETY_BLOCKED_MESSAGE };
  }
  if (options?.failClosedIfUnknownBrowserUrl && isBrowserPackage(targetPackageOrText) && !targetUrl) {
    return {
      isSafe: false,
      reason: 'Fail-closed security policy: Browser URL is hidden, empty, or inaccessible.',
    };
  }
  if (targetUrl) {
    const hostCheck = isBrowserHostBlocked(targetUrl);
    if (hostCheck.blocked) {
      return { isSafe: false, reason: hostCheck.reason || SAFETY_BLOCKED_MESSAGE };
    }
  }
  return { isSafe: true, reason: 'Allowed' };
}

