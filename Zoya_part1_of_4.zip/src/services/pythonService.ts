import { getSecretFromVault, setSecretInVault } from './secretVault';

export interface PythonRunResult {
  success: boolean;
  stdout: string;
  stderr: string;
  exitCode: number | null;
  executionTimeMs: number;
  timedOut?: boolean;
  error?: string;
}

export interface GeneratedAppProject {
  appName: string;
  packageName: string;
  versionName: string;
  language: 'kotlin' | 'java';
  minSdk: number;
  targetSdk: number;
  description: string;
  permissions: string[];
  files: Array<{
    path: string;
    content: string;
    description?: string;
  }>;
  buildInstructions: string;
  zipDownloadUrl?: string;
}

export interface GitHubConnectionTestResponse {
  success: boolean;
  status?: number;
  username?: string;
  name?: string;
  scopes?: string[];
  hasRepoScope?: boolean;
  hasWorkflowScope?: boolean;
  missingScopes?: string[];
  isFineGrained?: boolean;
  message: string;
  error?: string;
}

export type GitHubPipelineStepId =
  | 'create_repo'
  | 'push_files'
  | 'push_workflow'
  | 'trigger_workflow'
  | 'full';

const GITHUB_PAT_KEY = 'zoya_github_pat';
const AI_MODEL_KEY = 'zoya_custom_ai_model';

class PythonStudioService {
  async getSavedGitHubToken(): Promise<string> {
    return getSecretFromVault(GITHUB_PAT_KEY);
  }

  async saveGitHubToken(token: string): Promise<void> {
    await setSecretInVault(GITHUB_PAT_KEY, token);
  }

  getSavedModelConfig(): { modelName: string; apiKey: string } {
    try {
      const raw = localStorage.getItem(AI_MODEL_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        return {
          modelName: parsed.modelName || 'gemini-2.5-flash',
          apiKey: '',
        };
      }
    } catch {}
    return { modelName: 'gemini-2.5-flash', apiKey: '' };
  }

  async getSavedModelConfigAsync(): Promise<{ modelName: string; apiKey: string }> {
    const syncCfg = this.getSavedModelConfig();
    const apiKey = await getSecretFromVault('zoya_api_key');
    return { modelName: syncCfg.modelName, apiKey };
  }

  async saveModelConfig(modelName: string, apiKey: string): Promise<void> {
    try {
      localStorage.setItem(
        AI_MODEL_KEY,
        JSON.stringify({ modelName: modelName.trim() || 'gemini-2.5-flash' })
      );
      await setSecretInVault('zoya_api_key', apiKey);
    } catch {}
  }

  async getStatus(): Promise<{
    available: boolean;
    version: string;
    executable: string;
    platform: string;
  }> {
    try {
      const res = await fetch('/api/python/status');
      if (!res.ok) throw new Error('Status failed');
      return await res.json();
    } catch {
      return {
        available: false,
        version: 'Offline',
        executable: 'python3',
        platform: 'unknown',
      };
    }
  }

  async runPythonCode(
    code: string,
    stdin = '',
    timeoutMs = 15000
  ): Promise<PythonRunResult> {
    try {
      const res = await fetch('/api/python/execute', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code, stdin, timeoutMs }),
      });
      return await res.json();
    } catch (err: any) {
      return {
        success: false,
        stdout: '',
        stderr: err?.message || 'Network error calling Python engine.',
        exitCode: -1,
        executionTimeMs: 0,
        error: err?.message,
      };
    }
  }

  async generateAndroidApp(params: {
    prompt: string;
    appName?: string;
    language?: 'kotlin' | 'java';
  }): Promise<{
    success: boolean;
    safetyBlocked?: boolean;
    error?: string;
    app?: GeneratedAppProject;
  }> {
    const modelCfg = await this.getSavedModelConfigAsync();
    try {
      const res = await fetch('/api/python/generate-app', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...params,
          modelName: modelCfg.modelName,
          apiKey: modelCfg.apiKey || undefined,
        }),
      });
      return await res.json();
    } catch (err: any) {
      return {
        success: false,
        error: err?.message || 'Failed to connect to Zoya App Synthesizer.',
      };
    }
  }

  /**
   * ROUND 5 ITEM 4B:
   * Tests the GitHub Personal Access Token directly (calling GET https://api.github.com/user
   * or server proxy fallback) and checks the username and `repo` + `workflow` scopes.
   */
  async testGitHubConnection(githubToken: string): Promise<GitHubConnectionTestResponse> {
    const token = (githubToken || '').trim();
    if (!token) {
      return {
        success: false,
        message: 'Please enter your GitHub Personal Access Token first.',
        error: 'Token is empty',
      };
    }

    // Try server proxy first, or direct GitHub API call when running inside standalone APK
    try {
      const res = await fetch('/api/python/build/github-test', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ githubToken: token }),
      });
      if (res.ok) {
        return await res.json();
      }
    } catch {
      // Fallback to direct client-side fetch to api.github.com/user (for standalone phone APK)
    }

    try {
      const ghRes = await fetch('https://api.github.com/user', {
        method: 'GET',
        headers: {
          Authorization: `Bearer ${token}`,
          Accept: 'application/vnd.github+json',
          'X-GitHub-Api-Version': '2022-11-28',
        },
      });
      const scopesHeader = ghRes.headers.get('x-oauth-scopes') || '';
      const scopes = scopesHeader
        .split(',')
        .map((s) => s.trim())
        .filter(Boolean);
      const data: any = await ghRes.json().catch(() => ({}));

      if (!ghRes.ok) {
        return {
          success: false,
          status: ghRes.status,
          message: `GitHub authentication failed (HTTP ${ghRes.status}): ${data.message || 'Invalid token'}`,
          error: data.message || `HTTP ${ghRes.status}`,
        };
      }

      const username = data.login || 'unknown';
      const isFineGrained = token.startsWith('github_pat_') && scopes.length === 0;
      const hasRepoScope =
        isFineGrained || scopes.includes('repo') || scopes.includes('public_repo');
      const hasWorkflowScope = isFineGrained || scopes.includes('workflow');
      const missingScopes: string[] = [];
      if (!hasRepoScope) missingScopes.push('repo');
      if (!hasWorkflowScope) missingScopes.push('workflow');

      let message = `Connected as @${username}.`;
      if (isFineGrained) {
        message +=
          ' (Fine-grained PAT detected — ensure Contents & Workflows Read/Write permissions are enabled).';
      } else if (missingScopes.length > 0) {
        message += ` WARNING: Missing required scope(s): ${missingScopes.join(', ')}. Enable both 'repo' and 'workflow' scopes.`;
      } else {
        message += ` Verified required scopes ('repo' and 'workflow' present).`;
      }

      return {
        success: true,
        status: ghRes.status,
        username,
        name: data.name || username,
        scopes,
        hasRepoScope,
        hasWorkflowScope,
        missingScopes,
        isFineGrained,
        message,
      };
    } catch (err: any) {
      return {
        success: false,
        message: `Failed to reach GitHub API: ${err?.message || 'Network error'}`,
        error: err?.message,
      };
    }
  }

  async triggerGitHubBuild(params: {
    githubToken: string;
    repoName: string;
    files: Array<{ path: string; content: string }>;
    isPrivate?: boolean;
    step?: GitHubPipelineStepId;
  }): Promise<{
    success: boolean;
    stepCompleted?: string;
    failedStep?: string;
    owner?: string;
    repoUrl?: string;
    actionsUrl?: string;
    runId?: number;
    message?: string;
    error?: string;
  }> {
    try {
      const res = await fetch('/api/python/build/github', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(params),
      });
      return await res.json();
    } catch (err: any) {
      return {
        success: false,
        error: err?.message || 'Failed to trigger GitHub Actions build.',
      };
    }
  }

  /**
   * ROUND 5 ITEM 3:
   * Packages a local Source Code Bundle (.zip) — NEVER an .apk file.
   * Explicitly labeled: "Source code bundle (.zip) - NOT an installable app"
   */
  async packageLocalSourceBundle(params: {
    appName: string;
    packageName: string;
    versionName?: string;
    files: Array<{ path: string; content: string }>;
  }): Promise<{
    success: boolean;
    fileName?: string;
    downloadUrl?: string;
    sizeBytes?: number;
    label?: string;
    isInstallableApk?: boolean;
    message?: string;
    error?: string;
  }> {
    try {
      const res = await fetch('/api/python/build/source-bundle', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(params),
      });
      return await res.json();
    } catch (err: any) {
      return {
        success: false,
        error: err?.message || 'Failed to package local source code bundle (.zip).',
      };
    }
  }

  // Backward-compatible method name that strictly calls packageLocalSourceBundle (.zip)
  async packageLocalApk(params: {
    appName: string;
    packageName: string;
    versionName?: string;
    files: Array<{ path: string; content: string }>;
  }) {
    return this.packageLocalSourceBundle(params);
  }

  async checkGitHubBuildStatus(params: {
    owner: string;
    repo: string;
    githubToken: string;
    runId?: number;
  }): Promise<{
    success: boolean;
    status?: string;
    conclusion?: string | null;
    htmlUrl?: string;
    artifactDownloadUrl?: string;
    releaseAssetApiUrl?: string;
    releaseBrowserDownloadUrl?: string;
    releaseAssetName?: string;
    releaseTag?: string;
    steps?: Array<{ name: string; status: string; conclusion: string | null }>;
    error?: string;
  }> {
    try {
      const res = await fetch('/api/python/build/github-status', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(params),
      });
      return await res.json();
    } catch (err: any) {
      return {
        success: false,
        error: err?.message || 'Failed to poll build status.',
      };
    }
  }

  /**
   * ROUND 5 ITEM 4C:
   * Downloads the compiled APK Release asset through the native Android bridge
   * (`window.AndroidBridge.downloadReleaseAssetApk`) into the phone's `Downloads` folder,
   * handling private repo Authorization headers without browser CORS issues.
   */
  async downloadReleaseApkViaNativeBridge(params: {
    releaseAssetApiUrl?: string;
    releaseBrowserDownloadUrl?: string;
    fileName: string;
    githubToken?: string;
  }): Promise<{
    success: boolean;
    usedNativeBridge: boolean;
    filePath?: string;
    fileName?: string;
    bytesDownloaded?: number;
    fallbackUrl?: string;
    message: string;
    error?: string;
  }> {
    const targetUrl = params.releaseAssetApiUrl || params.releaseBrowserDownloadUrl || '';
    if (!targetUrl) {
      return {
        success: false,
        usedNativeBridge: false,
        message: 'No Release asset URL found yet. Wait for the Publish Release step to finish.',
        error: 'Missing Release asset URL',
      };
    }

    const bridge = typeof window !== 'undefined' ? (window as any).AndroidBridge : null;
    if (bridge && typeof bridge.downloadReleaseAssetApk === 'function') {
      try {
        const rawJson = bridge.downloadReleaseAssetApk(
          targetUrl,
          params.fileName || 'app-debug.apk',
          params.githubToken || ''
        );
        const parsed = JSON.parse(rawJson);
        if (parsed.success) {
          return {
            success: true,
            usedNativeBridge: true,
            filePath: parsed.filePath,
            fileName: parsed.fileName,
            bytesDownloaded: parsed.bytesDownloaded,
            message:
              parsed.message ||
              `APK downloaded via Native Bridge to ${parsed.filePath}. Tap Install APK to launch package installer.`,
          };
        }
        return {
          success: false,
          usedNativeBridge: true,
          fallbackUrl: params.releaseBrowserDownloadUrl || targetUrl,
          message: `Native bridge download failed: ${parsed.error || 'Unknown error'}. Use the direct Release link fallback below.`,
          error: parsed.error || 'Native download error',
        };
      } catch (err: any) {
        return {
          success: false,
          usedNativeBridge: true,
          fallbackUrl: params.releaseBrowserDownloadUrl || targetUrl,
          message: `Native bridge exception: ${err?.message}. Use the direct Release link fallback below.`,
          error: err?.message,
        };
      }
    }

    // Running in web browser (not inside installed Android APK)
    return {
      success: false,
      usedNativeBridge: false,
      fallbackUrl: params.releaseBrowserDownloadUrl || targetUrl,
      message:
        'Native AndroidBridge is only available inside the installed Zoya APK on your phone. In a browser, use the GitHub Release Asset link below to download the APK.',
      error: 'ANDROID_BRIDGE_NOT_AVAILABLE_IN_BROWSER',
    };
  }

  /**
   * Launches the Android system package installer for a downloaded APK via `window.AndroidBridge.installDownloadedApk`.
   */
  installDownloadedApkViaNativeBridge(filePath: string): {
    success: boolean;
    message: string;
    error?: string;
  } {
    const bridge = typeof window !== 'undefined' ? (window as any).AndroidBridge : null;
    if (bridge && typeof bridge.installDownloadedApk === 'function') {
      try {
        const rawJson = bridge.installDownloadedApk(filePath);
        const parsed = JSON.parse(rawJson);
        return {
          success: Boolean(parsed.success),
          message: parsed.message || 'Launched Android package installer.',
          error: parsed.error,
        };
      } catch (err: any) {
        return {
          success: false,
          message: `Failed to launch installer: ${err?.message}`,
          error: err?.message,
        };
      }
    }
    return {
      success: false,
      message: 'APK installation via FileProvider requires running inside the installed Zoya Android APK.',
      error: 'ANDROID_BRIDGE_NOT_AVAILABLE_IN_BROWSER',
    };
  }
}

export const pythonService = new PythonStudioService();
