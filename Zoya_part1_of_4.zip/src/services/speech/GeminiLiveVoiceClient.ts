/**
 * Gemini Live API Full-Duplex Voice Client (16kHz PCM In -> 24kHz PCM Out)
 * Global Always-On Voice Engine across all Zoya modes and screens with:
 * - Hardware + software acoustic echo suppression
 * - Automatic Voice Activity Detection & instant voice barge-in
 * - Silent background auto-reconnect on timeout/network drop
 * - Zero-drop session swap on language or persona mode changes
 */
import {
  getLanguageConfig,
  getLiveSpeechLanguageCode,
  getSelectedLanguageLabel,
} from '../languageConfig';
import { voiceTelemetry } from '../voiceTelemetry';
import { micStateMachine } from './MicStateMachine';

export const MIC_PERMISSION_DENIED_HI =
  'माइक की अनुमति नहीं मिली। ब्राउज़र में Allow करो या ऐप को नए टैब में खोलो।';

export interface GeminiLiveCallbacks {
  onReady?: () => void;
  onAudioLevel?: (level: number) => void;
  onUserSpeakingChange?: (speaking: boolean) => void;
  onUserTranscript?: (text: string, isFinal?: boolean) => void;
  onAssistantTranscript?: (text: string, isFinal?: boolean) => void;
  onTurnComplete?: (userText: string, assistantText: string) => void;
  onAudioMissingForTurn?: (assistantText: string) => void;
  onSpeakingChange?: (speaking: boolean) => void;
  onInterrupted?: () => void;
  onPermissionError?: (message: string) => void;
  onError?: (message: string) => void;
  onFallbackRequired?: (reason: string) => void;
  onClosed?: () => void;
}

export interface GeminiLiveStartOptions {
  personaMode?: string;
  language?: string;
  voiceName?: string;
}

function arrayBufferToBase64(buffer: ArrayBuffer): string {
  const bytes = new Uint8Array(buffer);
  const chunkSize = 0x8000;
  let binary = '';
  for (let i = 0; i < bytes.length; i += chunkSize) {
    const sub = bytes.subarray(i, Math.min(i + chunkSize, bytes.length));
    binary += String.fromCharCode.apply(null, Array.from(sub));
  }
  return btoa(binary);
}

function base64ToInt16Array(base64: string): Int16Array {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return new Int16Array(bytes.buffer, bytes.byteOffset, Math.floor(bytes.byteLength / 2));
}

function resampleFloat32To16kInt16(input: Float32Array, inputSampleRate: number): Int16Array {
  const targetRate = 16000;
  if (inputSampleRate === targetRate) {
    const out = new Int16Array(input.length);
    for (let i = 0; i < input.length; i++) {
      const s = Math.max(-1, Math.min(1, input[i]));
      out[i] = s < 0 ? s * 0x8000 : s * 0x7fff;
    }
    return out;
  }

  const ratio = inputSampleRate / targetRate;
  const outLength = Math.max(1, Math.floor(input.length / ratio));
  const out = new Int16Array(outLength);
  for (let i = 0; i < outLength; i++) {
    const srcIdx = i * ratio;
    const i0 = Math.floor(srcIdx);
    const i1 = Math.min(input.length - 1, i0 + 1);
    const frac = srcIdx - i0;
    const sample = input[i0] * (1 - frac) + input[i1] * frac;
    const clamped = Math.max(-1, Math.min(1, sample));
    out[i] = clamped < 0 ? clamped * 0x8000 : clamped * 0x7fff;
  }
  return out;
}

export class GeminiLiveVoiceClient {
  private ws: WebSocket | null = null;
  private mediaStream: MediaStream | null = null;
  private captureCtx: AudioContext | null = null;
  private sourceNode: MediaStreamAudioSourceNode | null = null;
  private processorNode: ScriptProcessorNode | null = null;
  private silentGainNode: GainNode | null = null;

  private playbackCtx: AudioContext | null = null;
  private nextPlaybackTime = 0;
  private activeSources = new Set<AudioBufferSourceNode>();

  private callbacks: GeminiLiveCallbacks = {};
  private currentOptions: GeminiLiveStartOptions = {
    personaMode: 'girlfriend',
    language: 'hi-IN',
    voiceName: 'Kore',
  };

  private isActive = false;
  private isStopping = false;
  private shouldStayConnected = false;
  private isIntentionalWsSwap = false;
  private isLiveReady = false;
  private hasOpenedOnce = false;
  private isAiSpeaking = false;
  private isUserSpeakingNow = false;
  private silenceFrameCounter = 0;
  private turnCompleteReceived = false;
  private echoGuardUntil = 0;
  private externalTtsPlaying = false;
  private consecutiveBargeInFrames = 0;
  private consecutiveReconnectFailures = 0;

  private currentUserTurnText = '';
  private currentAssistantTurnText = '';
  private currentTurnAudioBytes = 0;
  private readyTimeoutTimer: ReturnType<typeof setTimeout> | null = null;
  private keepAlivePingTimer: ReturnType<typeof setInterval> | null = null;
  private playbackWatchdogTimer: ReturnType<typeof setTimeout> | null = null;
  private reconnectTimer: ReturnType<typeof setTimeout> | null = null;
  private socketEpoch = 0;

  public pauseCaptureForExternalTts(paused: boolean): void {
    this.externalTtsPlaying = paused;
    if (paused) {
      this.interruptPlayback();
      this.consecutiveBargeInFrames = 0;
    } else {
      this.echoGuardUntil = Date.now() + 700;
      this.consecutiveBargeInFrames = 0;
    }
  }

  public isRunning(): boolean {
    return this.isActive && !this.isStopping && this.shouldStayConnected;
  }

  public isSpeaking(): boolean {
    return this.isAiSpeaking;
  }

  public getCurrentOptions(): GeminiLiveStartOptions {
    return { ...this.currentOptions };
  }

  public async start(options: GeminiLiveStartOptions, callbacks: GeminiLiveCallbacks): Promise<boolean> {
    await this.stop();
    this.callbacks = callbacks;
    this.currentOptions = { ...options };
    this.isStopping = false;
    this.shouldStayConnected = true;
    this.isActive = true;
    this.isLiveReady = false;
    this.hasOpenedOnce = false;
    this.isAiSpeaking = false;
    this.isUserSpeakingNow = false;
    this.silenceFrameCounter = 0;
    this.turnCompleteReceived = false;
    this.echoGuardUntil = 0;
    this.consecutiveBargeInFrames = 0;
    this.consecutiveReconnectFailures = 0;
    this.currentUserTurnText = '';
    this.currentAssistantTurnText = '';
    this.currentTurnAudioBytes = 0;

    // 1. Explicit Microphone Permission & Hardware Capture with Acoustic Echo Cancellation
    if (typeof navigator === 'undefined' || !navigator.mediaDevices?.getUserMedia) {
      console.warn('[GLOBAL_LIVE_CLIENT] getUserMediaError:', 'NotSupportedError', 'navigator.mediaDevices.getUserMedia unavailable');
      this.callbacks.onPermissionError?.(MIC_PERMISSION_DENIED_HI);
      this.isActive = false;
      this.shouldStayConnected = false;
      return false;
    }

    try {
      this.mediaStream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
          channelCount: 1,
        },
      });
      micStateMachine.reportMicPermission(true);
      voiceTelemetry.update('mic', {
        isOk: true,
        stateText: 'ACTIVE',
        detail: 'Gemini Live microphone hardware active',
      });
    } catch (permErr: any) {
      const errName = String(permErr?.name || 'Error');
      const errMsg = String(permErr?.message || permErr || '');
      if (errName === 'NotAllowedError' || errName === 'PermissionDeniedError' || errName === 'SecurityError') {
        micStateMachine.reportMicPermission(false);
      }
      console.warn('[GLOBAL_LIVE_CLIENT] getUserMedia failed:', {
        name: errName,
        message: errMsg,
      });
      voiceTelemetry.update('mic', {
        isOk: false,
        health: 'fail',
        stateText: 'INACTIVE',
        detail: `${errName}: ${errMsg}`,
        error: `${errName}: ${errMsg}`,
      });
      voiceTelemetry.update('recording', {
        isOk: false,
        health: 'fail',
        stateText: 'NOT RECORDING',
        detail: 'Mic acquisition failed',
        error: `${errName}: ${errMsg}`,
      });

      this.callbacks.onPermissionError?.(MIC_PERMISSION_DENIED_HI);
      this.isActive = false;
      this.shouldStayConnected = false;
      return false;
    }

    // 2. Initialize Capture & Playback AudioContexts during user gesture
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      this.captureCtx = new AudioCtx({ sampleRate: 16000 });
      if (this.captureCtx.state === 'suspended') {
        await this.captureCtx.resume().catch(() => {});
      }

      this.playbackCtx = new AudioCtx({ sampleRate: 24000 });
      if (this.playbackCtx.state === 'suspended') {
        await this.playbackCtx.resume().catch(() => {});
      }
      this.nextPlaybackTime = this.playbackCtx.currentTime;
    } catch (audioInitErr: any) {
      console.error('[GLOBAL_LIVE_CLIENT] AudioContext initialization error:', audioInitErr?.name, audioInitErr?.message || audioInitErr);
      this.cleanupAudioOnly();
      this.callbacks.onError?.('ऑडियो इंजन शुरू नहीं हो सका।');
      this.isActive = false;
      this.shouldStayConnected = false;
      return false;
    }

    // Start local mic capture pipeline ONCE; stays alive across silent WS reconnects & language swaps!
    const pipelineOk = this.startMicAudioPipeline();
    if (!pipelineOk) {
      this.cleanupAudioOnly();
      this.isActive = false;
      this.shouldStayConnected = false;
      return false;
    }

    return await this.connectWebSocketSession(this.currentOptions);
  }

  /**
   * Silently replaces the background Gemini Live WebSocket session with new language or persona mode
   * WITHOUT stopping the microphone stream or flipping the UI mic state to OFF.
   */
  public async reconnectWithOptions(newOptions: GeminiLiveStartOptions): Promise<boolean> {
    if (!this.shouldStayConnected || this.isStopping) {
      return false;
    }
    this.currentOptions = { ...this.currentOptions, ...newOptions };
    console.log('[GLOBAL_LIVE_CLIENT] Silently updating live session options without turning off mic:', this.currentOptions);
    this.interruptPlayback();
    this.currentUserTurnText = '';
    this.currentAssistantTurnText = '';
    this.currentTurnAudioBytes = 0;
    this.consecutiveReconnectFailures = 0;
    return await this.connectWebSocketSession(this.currentOptions);
  }

  private async connectWebSocketSession(options: GeminiLiveStartOptions): Promise<boolean> {
    if (!this.shouldStayConnected || this.isStopping) return false;

    this.clearSocketTimers();
    this.closeCurrentSocketSilently();

    const epoch = ++this.socketEpoch;
    this.isLiveReady = false;

    const langConfig = getLanguageConfig(options.language || 'hi-IN');
    const speechLanguageCode = getLiveSpeechLanguageCode(langConfig.code);
    const selectedLanguage = getSelectedLanguageLabel(langConfig.code);

    console.log('[GLOBAL_LIVE_CLIENT] Language configured for Live API:', {
      personaMode: options.personaMode || 'girlfriend',
      selectedLanguage,
      settingsCode: langConfig.code,
      speechConfigLanguageCode: speechLanguageCode,
      voiceName: options.voiceName || 'Kore',
    });

    const wsProto = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const params = new URLSearchParams({
      personaMode: options.personaMode || 'girlfriend',
      language: langConfig.code,
      languageCode: speechLanguageCode,
      voiceName: options.voiceName || 'Kore',
    });
    const wsUrl = `${wsProto}//${window.location.host}/ws/live?${params.toString()}`;

    return await new Promise<boolean>((resolve) => {
      let settled = false;
      const settle = (ok: boolean) => {
        if (!settled) {
          settled = true;
          resolve(ok);
        }
      };

      try {
        const ws = new WebSocket(wsUrl);
        this.ws = ws;

        this.readyTimeoutTimer = setTimeout(() => {
          if (epoch !== this.socketEpoch || this.isStopping || !this.shouldStayConnected) return;
          if (!this.isLiveReady) {
            console.warn('[GLOBAL_LIVE_CLIENT] Live API handshake timeout; handling silently...');
            if (!this.hasOpenedOnce) {
              this.triggerFallback('Gemini Live API connection timed out');
              settle(false);
            } else {
              this.scheduleSilentReconnect('handshake_timeout');
              settle(false);
            }
          }
        }, 7000);

        ws.onopen = () => {
          if (epoch !== this.socketEpoch || this.isStopping) return;
          console.log('[GLOBAL_LIVE_CLIENT] WebSocket connected to /ws/live, awaiting Gemini Live ready...', {
            personaMode: options.personaMode || 'girlfriend',
            selectedLanguage,
            speechConfigLanguageCode: speechLanguageCode,
          });
          this.keepAlivePingTimer = setInterval(() => {
            if (this.ws && this.ws.readyState === WebSocket.OPEN) {
              try {
                this.ws.send(JSON.stringify({ type: 'ping' }));
              } catch {}
            }
          }, 20000);
        };

        ws.onmessage = (event) => {
          if (epoch !== this.socketEpoch || this.isStopping) return;
          try {
            const msg = JSON.parse(event.data);
            switch (msg.type) {
              case 'ready': {
                if (this.readyTimeoutTimer) {
                  clearTimeout(this.readyTimeoutTimer);
                  this.readyTimeoutTimer = null;
                }
                this.isLiveReady = true;
                this.hasOpenedOnce = true;
                this.consecutiveReconnectFailures = 0;
                voiceTelemetry.update('geminiApi', {
                  isOk: true,
                  stateText: 'CONNECTED',
                  detail: `Live WS ready (${msg.model || 'gemini-live'})`,
                });
                console.log('[GLOBAL_LIVE_CLIENT] Gemini Live ready:', {
                  model: msg.model,
                  personaMode: msg.personaMode || options.personaMode,
                  selectedLanguage: msg.selectedLanguage || selectedLanguage,
                  speechConfigLanguageCode: msg.speechLanguageCode || speechLanguageCode,
                  voiceName: msg.voiceName,
                });
                this.callbacks.onReady?.();
                settle(true);
                break;
              }

              case 'audio': {
                if (typeof msg.data === 'string' && msg.data.length > 0) {
                  this.turnCompleteReceived = false;
                  this.currentTurnAudioBytes += msg.data.length;
                  voiceTelemetry.update('tts', {
                    isOk: true,
                    stateText: 'WORKING',
                    detail: 'Gemini Live PCM audio stream received',
                  });
                  this.queuePcm24kAudio(msg.data);
                }
                break;
              }

              case 'input_transcription': {
                const chunk = String(msg.text || '');
                if (chunk) {
                  const normChunk = chunk.trim().toLowerCase();
                  const normOut = this.currentAssistantTurnText.trim().toLowerCase();
                  if (
                    (this.isAiSpeaking || this.externalTtsPlaying || Date.now() < this.echoGuardUntil) &&
                    normChunk.length >= 4 &&
                    normOut.includes(normChunk)
                  ) {
                    console.log('[GLOBAL_LIVE_CLIENT] Filtered echo input transcription:', chunk);
                    break;
                  }
                  this.currentUserTurnText += chunk;
                  voiceTelemetry.update('stt', {
                    isOk: true,
                    stateText: 'WORKING',
                    detail: `Live STT: "${this.currentUserTurnText.trim().slice(0, 80)}"`,
                  });
                  this.callbacks.onUserTranscript?.(this.currentUserTurnText.trim(), false);
                }
                break;
              }

              case 'output_transcription': {
                const chunk = String(msg.text || '');
                if (chunk) {
                  this.currentAssistantTurnText += chunk;
                  voiceTelemetry.update('aiResponse', {
                    isOk: true,
                    stateText: 'RECEIVED',
                    detail: this.currentAssistantTurnText.trim().slice(0, 80),
                  });
                  this.callbacks.onAssistantTranscript?.(this.currentAssistantTurnText.trim(), false);
                }
                break;
              }

              case 'interrupted': {
                console.log('[GLOBAL_LIVE_CLIENT] Upstream reported user barge-in interruption');
                this.currentAssistantTurnText = '';
                this.currentTurnAudioBytes = 0;
                this.interruptPlayback();
                this.callbacks.onInterrupted?.();
                break;
              }

              case 'turn_complete': {
                this.turnCompleteReceived = true;
                const uText = this.currentUserTurnText.trim();
                const aText = this.currentAssistantTurnText.trim();
                const audioBytes = this.currentTurnAudioBytes;
                if (uText) this.callbacks.onUserTranscript?.(uText, true);
                if (aText) this.callbacks.onAssistantTranscript?.(aText, true);
                if (uText || aText) {
                  this.callbacks.onTurnComplete?.(uText, aText);
                }
                if (aText && audioBytes === 0) {
                  console.warn('[GLOBAL_LIVE_CLIENT] Turn completed with text but 0 audio bytes:', aText);
                  this.callbacks.onAudioMissingForTurn?.(aText);
                }
                this.currentUserTurnText = '';
                this.currentAssistantTurnText = '';
                this.currentTurnAudioBytes = 0;
                if (this.activeSources.size === 0 && this.isAiSpeaking) {
                  this.finishAiSpeaking();
                }
                break;
              }

              case 'error': {
                const errCode = String(msg.code || '');
                const errMsg = msg.message || errCode || 'Gemini Live API error';
                console.warn('[GLOBAL_LIVE_CLIENT] Server Live API message error:', errCode, errMsg);
                if (errCode === 'NO_API_KEY' || !this.hasOpenedOnce) {
                  this.triggerFallback(errMsg);
                  settle(false);
                } else {
                  this.scheduleSilentReconnect(errMsg);
                  settle(false);
                }
                break;
              }
            }
          } catch (parseErr) {
            console.error('[GLOBAL_LIVE_CLIENT] Failed to parse server WS message:', parseErr);
          }
        };

        ws.onerror = () => {
          if (epoch !== this.socketEpoch || this.isStopping || !this.shouldStayConnected) return;
          console.warn('[GLOBAL_LIVE_CLIENT] WebSocket transport hiccup; keeping mic active');
          if (!this.hasOpenedOnce) {
            this.triggerFallback('WebSocket transport error');
          } else {
            this.scheduleSilentReconnect('WebSocket transport error');
          }
          settle(false);
        };

        ws.onclose = (ev) => {
          if (epoch !== this.socketEpoch || this.isStopping || !this.shouldStayConnected || this.isIntentionalWsSwap) {
            return;
          }
          console.warn(`[GLOBAL_LIVE_CLIENT] Live WebSocket closed (code=${ev.code}, reason=${ev.reason}); mic stays ON`);
          if (!this.hasOpenedOnce) {
            this.triggerFallback(ev.reason || `Live WS closed (${ev.code})`);
          } else {
            // Silent auto-reconnect on timeout or network disconnect without notifying/turning off mic
            this.scheduleSilentReconnect(ev.reason || `Live session closed (${ev.code})`);
          }
          settle(false);
        };
      } catch (wsErr: any) {
        console.error('[GLOBAL_LIVE_CLIENT] Failed to open WebSocket:', wsErr?.name, wsErr?.message || wsErr);
        if (!this.hasOpenedOnce) {
          this.triggerFallback(wsErr?.message || 'WebSocket creation failed');
        } else {
          this.scheduleSilentReconnect(wsErr?.message || 'WebSocket creation failed');
        }
        settle(false);
      }
    });
  }

  private scheduleSilentReconnect(reason: string): void {
    if (this.isStopping || !this.shouldStayConnected) return;
    if (this.reconnectTimer) return;

    this.consecutiveReconnectFailures++;
    if (this.consecutiveReconnectFailures > 4) {
      console.warn('[GLOBAL_LIVE_CLIENT] Multiple consecutive reconnect failures; switching silently to fallback recorder:', reason);
      this.triggerFallback(reason);
      return;
    }

    const delayMs = Math.min(2500, 350 * this.consecutiveReconnectFailures);
    console.log(`[GLOBAL_LIVE_CLIENT] Silent auto-reconnect #${this.consecutiveReconnectFailures} scheduled in ${delayMs}ms (${reason})`);
    this.reconnectTimer = setTimeout(() => {
      this.reconnectTimer = null;
      if (!this.isStopping && this.shouldStayConnected) {
        this.connectWebSocketSession(this.currentOptions).catch(() => {});
      }
    }, delayMs);
  }

  private clearSocketTimers(): void {
    if (this.readyTimeoutTimer) {
      clearTimeout(this.readyTimeoutTimer);
      this.readyTimeoutTimer = null;
    }
    if (this.keepAlivePingTimer) {
      clearInterval(this.keepAlivePingTimer);
      this.keepAlivePingTimer = null;
    }
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
  }

  private closeCurrentSocketSilently(): void {
    if (!this.ws) return;
    this.isIntentionalWsSwap = true;
    const sock = this.ws;
    this.ws = null;
    sock.onopen = null;
    sock.onmessage = null;
    sock.onerror = null;
    sock.onclose = null;
    try {
      if (sock.readyState === WebSocket.OPEN) {
        sock.close(1000, 'Session swap');
      } else if (sock.readyState === WebSocket.CONNECTING) {
        sock.close();
      }
    } catch {}
    this.isIntentionalWsSwap = false;
  }

  private startMicAudioPipeline(): boolean {
    if (!this.captureCtx || !this.mediaStream) return false;
    try {
      this.sourceNode = this.captureCtx.createMediaStreamSource(this.mediaStream);
      const bufferSize = this.captureCtx.sampleRate <= 24000 ? 1024 : 2048;
      this.processorNode = this.captureCtx.createScriptProcessor(bufferSize, 1, 1);

      // Connect through zero-gain sink so ScriptProcessor executes without playing mic into speakers
      this.silentGainNode = this.captureCtx.createGain();
      this.silentGainNode.gain.value = 0;

      const sampleRate = this.captureCtx.sampleRate;
      // Raised threshold + 5-frame hold (~160-320ms sustained loud speech) so Zoya does not self-interrupt
      const BARGE_IN_RMS_THRESHOLD = 0.42;
      const BARGE_IN_REQUIRED_FRAMES = 5;
      const USER_SPEECH_ANIM_THRESHOLD = 0.035;

      voiceTelemetry.update('recording', {
        isOk: true,
        stateText: 'RECORDING',
        detail: `Live 16kHz PCM capture running (${sampleRate}Hz)`,
      });

      this.processorNode.onaudioprocess = (e) => {
        if (!this.isActive || this.isStopping || !this.shouldStayConnected) {
          return;
        }

        const input = e.inputBuffer.getChannelData(0);
        let sumSq = 0;
        for (let i = 0; i < input.length; i++) {
          sumSq += input[i] * input[i];
        }
        const rms = Math.min(1, Math.sqrt(sumSq / input.length) * 3.2);
        this.callbacks.onAudioLevel?.(rms);

        // Hard mute Live upstream capture while external /api/tts speaker audio is playing
        if (this.externalTtsPlaying) {
          this.consecutiveBargeInFrames = 0;
          return;
        }

        const playbackActiveOrTail = this.isAiSpeaking || Date.now() < this.echoGuardUntil;

        if (!playbackActiveOrTail) {
          if (rms >= USER_SPEECH_ANIM_THRESHOLD) {
            this.silenceFrameCounter = 0;
            if (!this.isUserSpeakingNow) {
              this.isUserSpeakingNow = true;
              this.callbacks.onUserSpeakingChange?.(true);
            }
          } else {
            this.silenceFrameCounter++;
            if (this.isUserSpeakingNow && this.silenceFrameCounter >= 8) {
              this.isUserSpeakingNow = false;
              this.callbacks.onUserSpeakingChange?.(false);
            }
          }
        }

        if (playbackActiveOrTail) {
          // Echo suppression gate while Zoya speaks:
          // Require sustained high-energy speech (>= 0.42 for 5+ frames) before triggering barge-in
          if (this.isAiSpeaking && rms >= BARGE_IN_RMS_THRESHOLD) {
            this.consecutiveBargeInFrames++;
            if (this.consecutiveBargeInFrames >= BARGE_IN_REQUIRED_FRAMES) {
              console.log('[GLOBAL_LIVE_CLIENT] User voice barge-in detected (RMS:', rms.toFixed(3), ') -> interrupting AI playback');
              this.interruptPlayback();
              this.echoGuardUntil = 0;
              this.consecutiveBargeInFrames = 0;
              this.currentAssistantTurnText = '';
              this.currentTurnAudioBytes = 0;
              if (this.ws && this.ws.readyState === WebSocket.OPEN) {
                try {
                  this.ws.send(JSON.stringify({ type: 'interrupt' }));
                } catch {}
              }
              this.callbacks.onInterrupted?.();
            } else {
              return;
            }
          } else {
            this.consecutiveBargeInFrames = 0;
            return;
          }
        }

        if (!this.isLiveReady || !this.ws || this.ws.readyState !== WebSocket.OPEN) return;

        const pcm16 = resampleFloat32To16kInt16(input, sampleRate);
        const base64 = arrayBufferToBase64(pcm16.buffer as ArrayBuffer);
        try {
          this.ws.send(JSON.stringify({ type: 'audio', data: base64 }));
        } catch (sendErr) {
          console.error('[GLOBAL_LIVE_CLIENT] Error sending PCM chunk over WS:', sendErr);
        }
      };

      this.sourceNode.connect(this.processorNode);
      this.processorNode.connect(this.silentGainNode);
      this.silentGainNode.connect(this.captureCtx.destination);
      return true;
    } catch (err: any) {
      console.error('[GLOBAL_LIVE_CLIENT] Error building mic audio capture pipeline:', err?.name, err?.message || err);
      this.callbacks.onError?.('माइक ऑडियो पाइपलाइन शुरू नहीं हो सकी।');
      return false;
    }
  }

  private queuePcm24kAudio(base64Pcm: string): void {
    if (!this.playbackCtx || this.isStopping) return;

    try {
      if (this.playbackCtx.state === 'suspended') {
        this.playbackCtx.resume().catch(() => {});
      }

      const int16 = base64ToInt16Array(base64Pcm);
      if (int16.length === 0) return;

      const float32 = new Float32Array(int16.length);
      for (let i = 0; i < int16.length; i++) {
        float32[i] = int16[i] / 32768;
      }

      const audioBuffer = this.playbackCtx.createBuffer(1, float32.length, 24000);
      audioBuffer.getChannelData(0).set(float32);

      const source = this.playbackCtx.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(this.playbackCtx.destination);

      const now = this.playbackCtx.currentTime;
      if (this.nextPlaybackTime < now + 0.015) {
        this.nextPlaybackTime = now + 0.02;
      }

      this.activeSources.add(source);
      if (!this.isAiSpeaking) {
        this.isAiSpeaking = true;
        this.isUserSpeakingNow = false;
        this.callbacks.onUserSpeakingChange?.(false);
        this.callbacks.onSpeakingChange?.(true);
      }

      source.onended = () => {
        this.activeSources.delete(source);
        if (this.activeSources.size === 0 && this.turnCompleteReceived && !this.isStopping) {
          this.finishAiSpeaking();
        }
      };

      source.start(this.nextPlaybackTime);
      voiceTelemetry.update('speaker', {
        isOk: true,
        stateText: 'PLAYING',
        detail: 'Playing 24kHz Gemini Live PCM audio',
      });
      this.nextPlaybackTime += audioBuffer.duration;

      if (this.playbackWatchdogTimer) {
        clearTimeout(this.playbackWatchdogTimer);
      }
      const remainingMs = Math.max(1500, Math.ceil((this.nextPlaybackTime - this.playbackCtx.currentTime) * 1000) + 1500);
      this.playbackWatchdogTimer = setTimeout(() => {
        this.playbackWatchdogTimer = null;
        if (this.isAiSpeaking && !this.isStopping) {
          console.warn('[GLOBAL_LIVE_CLIENT] Playback watchdog cleared lingering speaking state');
          this.activeSources.clear();
          this.finishAiSpeaking();
        }
      }, remainingMs);
    } catch (playErr: any) {
      console.error('[GLOBAL_LIVE_CLIENT] Error decoding/playing 24kHz PCM chunk:', playErr);
      voiceTelemetry.update('speaker', {
        isOk: false,
        health: 'fail',
        stateText: 'NOT PLAYING',
        detail: playErr?.message || 'PCM decode error',
        error: playErr?.message || String(playErr),
      });
    }
  }

  private finishAiSpeaking(): void {
    if (this.playbackWatchdogTimer) {
      clearTimeout(this.playbackWatchdogTimer);
      this.playbackWatchdogTimer = null;
    }
    this.isAiSpeaking = false;
    this.echoGuardUntil = Date.now() + 700;
    voiceTelemetry.update('speaker', {
      isOk: true,
      stateText: 'IDLE',
      detail: 'Live playback finished cleanly',
    });
    this.callbacks.onSpeakingChange?.(false);
  }

  public interruptPlayback(): void {
    if (this.playbackWatchdogTimer) {
      clearTimeout(this.playbackWatchdogTimer);
      this.playbackWatchdogTimer = null;
    }
    for (const src of Array.from(this.activeSources)) {
      try {
        src.onended = null;
        src.stop();
        src.disconnect();
      } catch {}
    }
    this.activeSources.clear();
    if (this.playbackCtx) {
      this.nextPlaybackTime = this.playbackCtx.currentTime;
    }
    if (this.isAiSpeaking) {
      this.isAiSpeaking = false;
      this.echoGuardUntil = Date.now() + 200;
      this.callbacks.onSpeakingChange?.(false);
    }
  }

  private async triggerFallback(reason: string): Promise<void> {
    if (this.isStopping) return;
    const cb = this.callbacks.onFallbackRequired;
    await this.stop();
    cb?.(reason);
  }

  private cleanupAudioOnly(): void {
    if (this.processorNode) {
      try {
        this.processorNode.onaudioprocess = null;
        this.processorNode.disconnect();
      } catch {}
      this.processorNode = null;
    }
    if (this.sourceNode) {
      try {
        this.sourceNode.disconnect();
      } catch {}
      this.sourceNode = null;
    }
    if (this.silentGainNode) {
      try {
        this.silentGainNode.disconnect();
      } catch {}
      this.silentGainNode = null;
    }
    if (this.mediaStream) {
      try {
        this.mediaStream.getTracks().forEach((t) => t.stop());
      } catch {}
      this.mediaStream = null;
    }
    if (this.captureCtx && this.captureCtx.state !== 'closed') {
      try {
        this.captureCtx.close().catch(() => {});
      } catch {}
      this.captureCtx = null;
    }
    this.interruptPlayback();
    if (this.playbackCtx && this.playbackCtx.state !== 'closed') {
      try {
        this.playbackCtx.close().catch(() => {});
      } catch {}
      this.playbackCtx = null;
    }
  }

  public async stop(): Promise<void> {
    if (this.isStopping) return;
    this.isStopping = true;
    this.shouldStayConnected = false;
    this.isActive = false;
    this.isLiveReady = false;
    this.isUserSpeakingNow = false;

    this.clearSocketTimers();
    if (this.playbackWatchdogTimer) {
      clearTimeout(this.playbackWatchdogTimer);
      this.playbackWatchdogTimer = null;
    }

    this.closeCurrentSocketSilently();
    this.cleanupAudioOnly();
    this.externalTtsPlaying = false;
    voiceTelemetry.update('mic', {
      isOk: false,
      health: 'idle',
      stateText: 'INACTIVE',
      detail: 'Gemini Live stopped',
    });
    voiceTelemetry.update('recording', {
      isOk: false,
      health: 'idle',
      stateText: 'NOT RECORDING',
      detail: 'Gemini Live capture stopped',
    });
    this.isStopping = false;
  }
}

export const geminiLiveVoiceClient = new GeminiLiveVoiceClient();
