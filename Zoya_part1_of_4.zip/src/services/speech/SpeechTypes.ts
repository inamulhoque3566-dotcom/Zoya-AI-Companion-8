/**
 * Voice Interaction & Speech Recognition Types
 * Directly ported from openclaw-assistant-main-mic-updated.zip
 * Mirrors OpenClawSession.kt and SpeechRecognizerManager.kt
 */

export enum AssistantState {
  IDLE = 'IDLE',
  LISTENING = 'LISTENING',
  PROCESSING = 'PROCESSING',
  THINKING = 'THINKING',
  PREPARING_SPEECH = 'PREPARING_SPEECH',
  SPEAKING = 'SPEAKING',
  ERROR = 'ERROR',
}

export type SpeechResult =
  | { type: 'ready' }
  | { type: 'listening' }
  | { type: 'rmsChanged'; rmsdB: number }
  | { type: 'partialResult'; text: string }
  | { type: 'result'; text: string; confidence?: number; alternatives?: string[] }
  | { type: 'error'; error: string; code?: number };

export type HardwareCaptureState =
  | 'idle'
  | 'starting'
  | 'active'
  | 'receiving_audio'
  | 'restarting'
  | 'error';

export interface HardwareStateInfo {
  state: HardwareCaptureState;
  engine: 'webspeech' | 'mediarecorder' | 'native' | 'none';
  isHardwareLive: boolean;
  receivingAudio: boolean;
  error?: string;
  details?: string;
}

export interface SpeechRecognizerListener {
  onReady?: () => void;
  onListening?: () => void;
  onRmsChanged?: (rmsdB: number) => void;
  onPartialResult?: (text: string) => void;
  onResult?: (text: string, confidence?: number, alternatives?: string[]) => void;
  onWakeWordDetected?: (wakePhrase: string, remainingText?: string) => void;
  onStandbyListening?: () => void;
  onError?: (error: string, code?: number) => void;
  onSttError?: (error: string) => void;
  onEnd?: () => void;
  onHardwareStateChange?: (info: HardwareStateInfo) => void;
}

/**
 * Native Android Bridge interface when running inside Android WebView / APK container
 */
export interface OpenClawNativeBridge {
  isAvailable?: () => boolean;
  startListening?: (language?: string, silenceTimeoutMs?: number) => void;
  stopListening?: () => void;
  cancel?: () => void;
  interruptTTS?: () => void;
  getVoiceWakeMode?: () => string;
  setVoiceWakeMode?: (mode: string) => void;
  isAccessibilityEnabled?: () => boolean;
  openAccessibilitySettings?: () => void;
  openRestrictedSettings?: () => string;
  openAppDetailsSettings?: () => string;
  isBatteryOptimizationIgnored?: () => boolean;
  requestIgnoreBatteryOptimization?: () => string;
  getBankingSafetyBlocklist?: () => string;
  getAccessibilityStatus?: () => string;
  executeAccessibilityAction?: (actionJson: string) => string;
  getDeviceSecurityStatus?: () => string;
  openSecurityEnrollment?: (type: string) => string;
  lockDevice?: () => string;
  requestDeviceUnlock?: () => string;
}

declare global {
  interface Window {
    __openclaw?: OpenClawNativeBridge;
    AndroidBridge?: OpenClawNativeBridge;
  }
}
