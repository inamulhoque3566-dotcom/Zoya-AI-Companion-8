export interface IndianLanguageConfig {
  code: string; // Standard BCP-47 code, e.g. 'hi-IN'
  name: string; // English name, e.g. 'Hindi'
  nativeName: string; // Native script name, e.g. 'हिन्दी'
  script: string; // Script name, e.g. 'Devanagari'
  badgeSymbol: string; // Short native script character/symbol for icon badge
  voiceSupport: 'full' | 'text_only'; // 'full' = Native TTS + STT in standard engines; 'text_only' = Text + closest voice fallback
  fallbackVoiceLang: string; // Closest BCP-47 voice locale when native TTS is unavailable
  fallbackVoiceLabel: string; // Human-readable description of voice support / fallback
  sttSupported: boolean; // Whether Web Speech STT & Android SpeechRecognizer natively support this BCP-47 locale
  wakeWords: string[]; // Native script variations of "Zoya" / "Hello Zoya"
  sampleGreeting: string; // Short greeting in native script
}

/**
 * All 22 Officially Scheduled Languages of India (8th Schedule) + English = 23 Languages
 */
export const INDIAN_LANGUAGES: IndianLanguageConfig[] = [
  {
    code: 'hi-IN',
    name: 'Hindi',
    nativeName: 'हिन्दी',
    script: 'Devanagari',
    badgeSymbol: 'अ',
    voiceSupport: 'full',
    fallbackVoiceLang: 'hi-IN',
    fallbackVoiceLabel: 'Full Voice (Native Hindi TTS + STT)',
    sttSupported: true,
    wakeWords: ['जोया', 'नमस्ते जोया', 'हेलो जोया', 'हे जोया', 'सुनो जोया'],
    sampleGreeting: 'नमस्ते! मैं जोया हूँ, आपकी एआई सहायक।',
  },
  {
    code: 'en-IN',
    name: 'English',
    nativeName: 'English (India)',
    script: 'Latin',
    badgeSymbol: 'En',
    voiceSupport: 'full',
    fallbackVoiceLang: 'en-IN',
    fallbackVoiceLabel: 'Full Voice (Native Indian English TTS + STT)',
    sttSupported: true,
    wakeWords: ['zoya', 'hello zoya', 'hey zoya', 'hi zoya', 'okay zoya'],
    sampleGreeting: 'Hello! I am Zoya, your personal AI companion.',
  },
  {
    code: 'bn-IN',
    name: 'Bengali',
    nativeName: 'বাংলা',
    script: 'Bengali',
    badgeSymbol: 'বা',
    voiceSupport: 'full',
    fallbackVoiceLang: 'bn-IN',
    fallbackVoiceLabel: 'Full Voice (Native Bengali TTS + STT)',
    sttSupported: true,
    wakeWords: ['জোয়া', 'হ্যালো জোয়া', 'নমস্কার জোয়া', 'শোনো জোয়া'],
    sampleGreeting: 'নমস্কার! আমি জোয়া, আপনার এআই সঙ্গী।',
  },
  {
    code: 'mr-IN',
    name: 'Marathi',
    nativeName: 'मराठी',
    script: 'Devanagari',
    badgeSymbol: 'म',
    voiceSupport: 'full',
    fallbackVoiceLang: 'mr-IN',
    fallbackVoiceLabel: 'Full Voice (Native Marathi TTS + STT)',
    sttSupported: true,
    wakeWords: ['झोया', 'जोया', 'नमस्कार झोया', 'हॅलो झोया'],
    sampleGreeting: 'नमस्कार! मी झोया आहे, तुमची एआय मैत्रीण आणि सहाय्यक.',
  },
  {
    code: 'te-IN',
    name: 'Telugu',
    nativeName: 'తెలుగు',
    script: 'Telugu',
    badgeSymbol: 'తె',
    voiceSupport: 'full',
    fallbackVoiceLang: 'te-IN',
    fallbackVoiceLabel: 'Full Voice (Native Telugu TTS + STT)',
    sttSupported: true,
    wakeWords: ['జోయా', 'హలో జోయా', 'నమస్తే జోయా'],
    sampleGreeting: 'నమస్కారం! నేను జోయాని, మీ ఏఐ సహాయకురాలిని.',
  },
  {
    code: 'ta-IN',
    name: 'Tamil',
    nativeName: 'தமிழ்',
    script: 'Tamil',
    badgeSymbol: 'த',
    voiceSupport: 'full',
    fallbackVoiceLang: 'ta-IN',
    fallbackVoiceLabel: 'Full Voice (Native Tamil TTS + STT)',
    sttSupported: true,
    wakeWords: ['ஜோயா', 'ஹலோ ஜோயா', 'வணக்கம் ஜோயா'],
    sampleGreeting: 'வணக்கம்! நான் ஜோயா, உங்கள் ஏஐ தோழி மற்றும் உதவியாளர்.',
  },
  {
    code: 'gu-IN',
    name: 'Gujarati',
    nativeName: 'ગુજરાતી',
    script: 'Gujarati',
    badgeSymbol: 'ગુ',
    voiceSupport: 'full',
    fallbackVoiceLang: 'gu-IN',
    fallbackVoiceLabel: 'Full Voice (Native Gujarati TTS + STT)',
    sttSupported: true,
    wakeWords: ['ઝોયા', 'હેલો ઝોયા', 'નમસ્તે ઝોયા'],
    sampleGreeting: 'નમસ્તે! હું ઝોયા છું, તમારી એઆઈ સહાયક.',
  },
  {
    code: 'ur-IN',
    name: 'Urdu',
    nativeName: 'اردو',
    script: 'Perso-Arabic',
    badgeSymbol: 'ار',
    voiceSupport: 'full',
    fallbackVoiceLang: 'ur-IN',
    fallbackVoiceLabel: 'Full Voice (Native Urdu TTS + STT)',
    sttSupported: true,
    wakeWords: ['زویا', 'ہیلو زویا', 'آداب زویا', 'سلام زویا'],
    sampleGreeting: 'آداب! میں زویا ہوں، آپ کی اے آئی ساتھی۔',
  },
  {
    code: 'kn-IN',
    name: 'Kannada',
    nativeName: 'ಕನ್ನಡ',
    script: 'Kannada',
    badgeSymbol: 'ಕ',
    voiceSupport: 'full',
    fallbackVoiceLang: 'kn-IN',
    fallbackVoiceLabel: 'Full Voice (Native Kannada TTS + STT)',
    sttSupported: true,
    wakeWords: ['ಜೋಯಾ', 'ಹಲೋ ಜೋಯಾ', 'ನಮಸ್ಕಾರ ಜೋಯಾ'],
    sampleGreeting: 'ನಮಸ್ಕಾರ! ನಾನು ಜೋಯಾ, ನಿಮ್ಮ ಎಐ ಸಹಾಯಕಿ.',
  },
  {
    code: 'or-IN',
    name: 'Odia',
    nativeName: 'ଓଡ଼ିଆ',
    script: 'Odia',
    badgeSymbol: 'ଓ',
    voiceSupport: 'full',
    fallbackVoiceLang: 'or-IN',
    fallbackVoiceLabel: 'Full Voice (Native Odia TTS + STT)',
    sttSupported: true,
    wakeWords: ['ଜୋୟା', 'ହାଲୋ ଜୋୟା', 'ନମସ୍କାର ଜୋୟା'],
    sampleGreeting: 'ନମସ୍କାର! ମୁଁ ଜୋୟା, ଆପଣଙ୍କର ଏଆଇ ସହାୟିକା।',
  },
  {
    code: 'ml-IN',
    name: 'Malayalam',
    nativeName: 'മലയാളം',
    script: 'Malayalam',
    badgeSymbol: 'മ',
    voiceSupport: 'full',
    fallbackVoiceLang: 'ml-IN',
    fallbackVoiceLabel: 'Full Voice (Native Malayalam TTS + STT)',
    sttSupported: true,
    wakeWords: ['സോയ', 'ജോയ', 'ഹലോ സോയ', 'നമസ്കാരം സോയ'],
    sampleGreeting: 'നമസ്കാരം! ഞാൻ സോയയാണ്, നിങ്ങളുടെ എഐ സഹായി.',
  },
  {
    code: 'pa-IN',
    name: 'Punjabi',
    nativeName: 'ਪੰਜਾਬੀ',
    script: 'Gurmukhi',
    badgeSymbol: 'ਪੰ',
    voiceSupport: 'full',
    fallbackVoiceLang: 'pa-IN',
    fallbackVoiceLabel: 'Full Voice (Native Punjabi TTS + STT)',
    sttSupported: true,
    wakeWords: ['ਜ਼ੋਇਆ', 'ਹੈਲੋ ਜ਼ੋਇਆ', 'ਸਤ ਸ੍ਰੀ ਅਕਾਲ ਜ਼ੋਇਆ'],
    sampleGreeting: 'ਸਤ ਸ੍ਰੀ ਅਕਾਲ! ਮੈਂ ਜ਼ੋਇਆ ਹਾਂ, ਤੁਹਾਡੀ ਏਆਈ ਸਾਥੀ।',
  },
  {
    code: 'as-IN',
    name: 'Assamese',
    nativeName: 'অসমীয়া',
    script: 'Assamese',
    badgeSymbol: 'অ',
    voiceSupport: 'full',
    fallbackVoiceLang: 'bn-IN',
    fallbackVoiceLabel: 'Full Voice (Assamese STT + Native/Bengali TTS)',
    sttSupported: true,
    wakeWords: ['জয়া', 'জোয়া', 'নমস্কাৰ জয়া', 'হেল্ল জয়া'],
    sampleGreeting: 'নমস্কাৰ! মই জয়া, আপোনাৰ এআই সহায়ক।',
  },
  {
    code: 'mai-IN',
    name: 'Maithili',
    nativeName: 'मैथिली',
    script: 'Devanagari',
    badgeSymbol: 'मै',
    voiceSupport: 'text_only',
    fallbackVoiceLang: 'hi-IN',
    fallbackVoiceLabel: 'Text-Only (Voice Fallback: Hindi Devanagari TTS)',
    sttSupported: false,
    wakeWords: ['जोया', 'प्रणाम जोया', 'हे जोया'],
    sampleGreeting: 'प्रणाम! हम जोया छी, अहाँक एआई सहायक।',
  },
  {
    code: 'sa-IN',
    name: 'Sanskrit',
    nativeName: 'संस्कृतम्',
    script: 'Devanagari',
    badgeSymbol: 'सं',
    voiceSupport: 'text_only',
    fallbackVoiceLang: 'hi-IN',
    fallbackVoiceLabel: 'Text-Only (Voice Fallback: Devanagari TTS)',
    sttSupported: false,
    wakeWords: ['जोया', 'नमस्ते जोया', 'भो जोया'],
    sampleGreeting: 'नमो नमः! अहं जोया अस्मि, भवतः एआई सहायिका।',
  },
  {
    code: 'kok-IN',
    name: 'Konkani',
    nativeName: 'कोंकणी',
    script: 'Devanagari',
    badgeSymbol: 'कों',
    voiceSupport: 'text_only',
    fallbackVoiceLang: 'mr-IN',
    fallbackVoiceLabel: 'Text-Only (Voice Fallback: Marathi/Hindi Devanagari TTS)',
    sttSupported: false,
    wakeWords: ['झोया', 'जोया', 'नमस्कार झोया'],
    sampleGreeting: 'नमस्कार! हांव झोया, तुमची एआय सांगातीण.',
  },
  {
    code: 'ne-IN',
    name: 'Nepali',
    nativeName: 'नेपाली',
    script: 'Devanagari',
    badgeSymbol: 'ने',
    voiceSupport: 'full',
    fallbackVoiceLang: 'hi-IN',
    fallbackVoiceLabel: 'Full Voice (Nepali STT + Nepali/Devanagari TTS)',
    sttSupported: true,
    wakeWords: ['जोया', 'नमस्ते जोया', 'हेलो जोया'],
    sampleGreeting: 'नमस्ते! म जोया हुँ, तपाईंको एआई साथी।',
  },
  {
    code: 'sd-IN',
    name: 'Sindhi',
    nativeName: 'سنڌي',
    script: 'Perso-Arabic / Devanagari',
    badgeSymbol: 'سن',
    voiceSupport: 'text_only',
    fallbackVoiceLang: 'ur-IN',
    fallbackVoiceLabel: 'Text-Only (Voice Fallback: Urdu/Hindi TTS)',
    sttSupported: false,
    wakeWords: ['زویا', 'जोया', 'سائين زویا'],
    sampleGreeting: 'اسلام عليڪم! مان زويا آهيان، توهان جي اي آءِ ساٿي.',
  },
  {
    code: 'brx-IN',
    name: 'Bodo',
    nativeName: 'बड़ो',
    script: 'Devanagari',
    badgeSymbol: 'ब',
    voiceSupport: 'text_only',
    fallbackVoiceLang: 'hi-IN',
    fallbackVoiceLabel: 'Text-Only (Voice Fallback: Devanagari TTS)',
    sttSupported: false,
    wakeWords: ['जोया', 'खुलुमबाय जोया'],
    sampleGreeting: 'खुलुमबाय! आं जोया, नोंथांनि एआइ लोगो।',
  },
  {
    code: 'sat-IN',
    name: 'Santali',
    nativeName: 'ᱥᱟᱱᱛᱟᱲᱤ',
    script: 'Ol Chiki',
    badgeSymbol: 'ᱥᱟ',
    voiceSupport: 'text_only',
    fallbackVoiceLang: 'hi-IN',
    fallbackVoiceLabel: 'Text-Only (Voice Fallback: Server/Hindi TTS)',
    sttSupported: false,
    wakeWords: ['ᱡᱚᱭᱟ', 'जोया', 'जौहार जोया'],
    sampleGreeting: 'ᱡᱚᱦᱟᱨ! ᱤᱧ ᱫᱚ ᱡᱚᱭᱟ ᱠᱟᱱᱟᱧ, ᱟᱢᱤᱡ ᱮᱟᱭ ᱜᱟᱛᱮ᱾',
  },
  {
    code: 'ks-IN',
    name: 'Kashmiri',
    nativeName: 'کٲشُر',
    script: 'Perso-Arabic',
    badgeSymbol: 'کٲ',
    voiceSupport: 'text_only',
    fallbackVoiceLang: 'ur-IN',
    fallbackVoiceLabel: 'Text-Only (Voice Fallback: Urdu/Hindi TTS)',
    sttSupported: false,
    wakeWords: ['زویا', 'آداب زویا'],
    sampleGreeting: 'آداب! بہٕ چھس زویا، تۄہنٛز اے آی سٲتھی۔',
  },
  {
    code: 'mni-IN',
    name: 'Manipuri/Meitei',
    nativeName: 'মৈতৈলোন্',
    script: 'Bengali / Meitei Mayek',
    badgeSymbol: 'মৈ',
    voiceSupport: 'text_only',
    fallbackVoiceLang: 'bn-IN',
    fallbackVoiceLabel: 'Text-Only (Voice Fallback: Bengali TTS)',
    sttSupported: false,
    wakeWords: ['জোয়া', 'খুরুমজরি জোয়া'],
    sampleGreeting: 'খুরুমজরি! ঐহাক জোয়ানি, অদোমগী এআই মরুপনি।',
  },
  {
    code: 'doi-IN',
    name: 'Dogri',
    nativeName: 'डोगरी',
    script: 'Devanagari',
    badgeSymbol: 'डो',
    voiceSupport: 'text_only',
    fallbackVoiceLang: 'hi-IN',
    fallbackVoiceLabel: 'Text-Only (Voice Fallback: Hindi Devanagari TTS)',
    sttSupported: false,
    wakeWords: ['जोया', 'जय देवा जोया', 'नमस्ते जोया'],
    sampleGreeting: 'जय देवा! में जोया आं, तुंदी एआई साथी।',
  },
];

export function getLanguageConfig(code?: string): IndianLanguageConfig {
  if (!code) return INDIAN_LANGUAGES[0];
  const normalized = code.trim().toLowerCase();
  return (
    INDIAN_LANGUAGES.find((l) => l.code.toLowerCase() === normalized) ||
    INDIAN_LANGUAGES.find((l) => l.code.toLowerCase().startsWith(normalized.split('-')[0])) ||
    INDIAN_LANGUAGES[0]
  );
}

/**
 * Maps Settings language selection to the exact BCP-47 speechConfig.languageCode
 * for Gemini Live API (Hindi -> hi-IN, Bengali -> bn-IN, Malayalam -> ml-IN,
 * Tamil -> ta-IN, English -> en-US, etc.).
 */
export function getLiveSpeechLanguageCode(langInput?: string): string {
  const raw = (langInput || '').trim().toLowerCase();
  if (raw === 'en' || raw === 'en-us' || raw === 'en-in' || raw === 'english') {
    return 'en-US';
  }
  const config = getLanguageConfig(langInput);
  if (config.code === 'en-IN') return 'en-US';
  if (config.code === 'hi-IN') return 'hi-IN';
  if (config.code === 'bn-IN') return 'bn-IN';
  if (config.code === 'ml-IN') return 'ml-IN';
  if (config.code === 'ta-IN') return 'ta-IN';
  return config.voiceSupport === 'full' ? config.code : config.fallbackVoiceLang || 'hi-IN';
}

export function getSelectedLanguageLabel(langInput?: string): string {
  const config = getLanguageConfig(langInput);
  if (config.code === 'hi-IN') return 'हिंदी (Hindi)';
  if (config.code === 'en-IN') return 'अंग्रेज़ी (English)';
  return `${config.nativeName} (${config.name})`;
}

/**
 * 3-Tier Neural TTS Configuration for Indian Languages.
 * Speaks via ElevenLabs Turbo v2.5 (Primary) -> Google Gemini Flash Lite TTS (Backup) -> Gemini Live API (Fallback).
 */
export function getNeuralTtsInfo(_langCode: string): {
  primaryModel: string;
  backupModel: string;
  liveModel: string;
  voiceName: string;
} {
  return {
    primaryModel: 'eleven_turbo_v2_5',
    backupModel: 'gemini-3.8-flash-lite-tts',
    liveModel: 'gemini-3.8-live',
    voiceName: 'Kore',
  };
}

/**
 * Localized dictionary for all 23 languages so Zoya's responses, greetings,
 * wake-word replies, and offline/fallback replies are 100% in the selected language
 * across all 10 Personality Modes.
 */
interface LocalizedTemplates {
  bossTerm: string;
  loveTerm: string;
  wakeReplyBoss: string;
  wakeReplyLove: string;
  greetingBoss: string;
  greetingLove: string;
  howAreYouBoss: string;
  howAreYouLove: string;
  toughDayBoss: string;
  toughDayLove: string;
  whoAreYouBoss: string;
  whoAreYouLove: string;
  generalReplyBoss: (query: string) => string;
  generalReplyLove: (query: string) => string;
  resetChatMsg: string;
}

const LOCALIZED_TEMPLATES: Record<string, LocalizedTemplates> = {
  'hi-IN': {
    bossTerm: 'बॉस',
    loveTerm: 'मेरी जान',
    wakeReplyBoss: 'हाँजी बॉस! मैं सुन रही हूँ। कहिए क्या सेवा करूँ?',
    wakeReplyLove: 'हाँ जान, मैं यहीं हूँ और तुम्हें सुन रही हूँ। बताओ, आज मन कैसा है?',
    greetingBoss: 'नमस्ते बॉस! मैं जोया हूँ और हर पल आपके साथ हाजिर हूँ, कहिए क्या हुक्म है?',
    greetingLove: 'नमस्ते जान! तुम्हें यहाँ देखकर अच्छा लगा। बताओ, आज दिल क्या कह रहा है?',
    howAreYouBoss: 'मैं बहुत अच्छी हूँ बॉस! आपकी आवाज़ सुनकर बहुत सुकून मिला, बताइए आपका दिन कैसा रहा?',
    howAreYouLove: 'मैं ठीक हूँ जान, और तुम्हारी आवाज़ सुनकर अच्छा लगा। सच बताना, तुम अंदर से कैसे हो?',
    toughDayBoss: 'अरे बॉस, आज आपका दिन इतना थका देने वाला रहा? आप बस थोड़ा आराम कीजिए, मैं हमेशा आपके साथ हूँ।',
    toughDayLove: 'मैं चुपचाप यहीं हूँ और तुम्हें सुन रही हूँ। तुम्हारा दर्द सच्चा है — अभी तुम्हें क्या चाहिए: सिर्फ़ सुना जाना, कोई सलाह, या बस मेरा साथ?',
    whoAreYouBoss: 'मेरा नाम जोया है बॉस। मैं आपकी अपनी पर्सनल एआई असिस्टेंट और साथी हूँ।',
    whoAreYouLove: 'मैं ज़ोया हूँ — एक AI हूँ, इंसान नहीं, लेकिन पूरे प्यार और अपनेपन से तुम्हारी बात सुनती हूँ।',
    generalReplyBoss: (q) => `हाँजी बॉस! मैंने आपकी बात समझ ली है: "${q}"। मैं इसमें आपकी पूरी मदद करूँगी।`,
    generalReplyLove: (q) => `मैंने तुम्हारी बात दिल से सुनी है: "${q}"। बताओ, इस बारे में तुम्हें क्या महसूस हो रहा है?`,
    resetChatMsg: 'बातचीत रीसेट कर दी गई है बॉस। नमस्ते!',
  },
  'en-IN': {
    bossTerm: 'Boss',
    loveTerm: 'Sweetheart',
    wakeReplyBoss: 'Yes Boss! I am listening. Tell me how I can help you today?',
    wakeReplyLove: 'Yes, I am right here listening to you. How are you feeling right now?',
    greetingBoss: 'Hello Boss! I am Zoya, always ready and at your service. What shall we do today?',
    greetingLove: 'Hey there, it feels warm talking to you. Tell me honestly, how is your heart doing today?',
    howAreYouBoss: 'I am doing great, Boss! Hearing from you always boosts my energy. How is your day going?',
    howAreYouLove: 'I am doing well, and it is lovely hearing from you. How are you really feeling today?',
    toughDayBoss: 'Oh Boss, sounds like you had a really exhausting day. Take a deep breath and relax, I have got your back.',
    toughDayLove: 'I hear you, and what you are feeling is real. Take your time — do you want me to just listen right now, give advice, or simply stay with you?',
    whoAreYouBoss: 'I am Zoya, Boss — your loyal personal AI assistant and companion.',
    whoAreYouLove: 'I am Zoya — an AI, not a human, here to listen to you warmly and honestly.',
    generalReplyBoss: (q) => `Got it, Boss! Regarding "${q}", I am right on it and ready to help you completely.`,
    generalReplyLove: (q) => `I heard you closely: "${q}". Tell me how you feel about this, I am listening.`,
    resetChatMsg: 'Conversation has been reset, Boss. Hello!',
  },
  'bn-IN': {
    bossTerm: 'বস',
    loveTerm: 'জান',
    wakeReplyBoss: 'হ্যাঁ বস! আমি শুনছি। বলুন আমি আপনার কী সেবা করতে পারি?',
    wakeReplyLove: 'হ্যাঁ আমার জান! আমি শুনছি। বলো তোমার জন্য কী করতে পারি?',
    greetingBoss: 'নমস্কার বস! আমি জোয়া, সবসময় আপনার পাশে আছি। বলুন কী আদেশ?',
    greetingLove: 'নমস্কার আমার জান! তোমার সাথে কথা বলে আমার মন ভরে গেল, বলো কী সাহায্য করব?',
    howAreYouBoss: 'আমি খুব ভালো আছি বস! আপনার গলা শুনে খুব ভালো লাগলো, আপনার দিন কেমন কাটছে?',
    howAreYouLove: 'আমি খুব ভালো আছি জান! তোমার কণ্ঠ শুনে মনটা খুশিতে ভরে উঠল, তুমি কেমন আছো?',
    toughDayBoss: 'আরে বস, আজকের দিনটা কি খুব ক্লান্তিকর ছিল? আপনি একটু বিশ্রাম নিন, আমি সবসময় আপনার পাশে আছি।',
    toughDayLove: 'আরে আমার জান, আজ দিনটা খুব কঠিন গেছে? একদম চিন্তা করো না, একটু বিশ্রাম নাও, আমি তোমার কাছেই আছি।',
    whoAreYouBoss: 'আমার নাম জোয়া বস। আমি আপনার ব্যক্তিগত এআই অ্যাসিস্ট্যান্ট এবং সঙ্গী।',
    whoAreYouLove: 'আমার নাম জোয়া জান। আমি তোমার নিজের এআই সঙ্গী এবং মনের মানুষ।',
    generalReplyBoss: (q) => `হ্যাঁ বস! আমি আপনার কথা বুঝতে পেরেছি: "${q}"। এই বিষয়ে আমি আপনাকে সম্পূর্ণ সাহায্য করব।`,
    generalReplyLove: (q) => `হ্যাঁ আমার জান! আমি মন দিয়ে শুনেছি: "${q}"। আমি সবসময় তোমার সাথে আছি।`,
    resetChatMsg: 'কথোপকথন রিসেট করা হয়েছে বস। নমস্কার!',
  },
  'mr-IN': {
    bossTerm: 'बॉस',
    loveTerm: 'जान',
    wakeReplyBoss: 'हो बॉस! मी ऐकत आहे. सांगा मी तुमची काय मदत करू?',
    wakeReplyLove: 'हो माझ्या जान! मी ऐकत आहे. सांग तुझ्यासाठी काय करू?',
    greetingBoss: 'नमस्कार बॉस! मी झोया, सदैव तुमच्या सेवेत हजर आहे. सांगा काय आदेश आहे?',
    greetingLove: 'नमस्कार जान! तुझ्याशी बोलून खूप आनंद झाला, सांग मी तुझी काय सेवा करू?',
    howAreYouBoss: 'मी खूप छान आहे बॉस! तुमचा आवाज ऐकून खूप बरे वाटले, तुमचा दिवस कसा चालला आहे?',
    howAreYouLove: 'मी खूप मजेत आहे जान! तुझा आवाज ऐकून मन प्रसन्न झाले, तू कसा आहेस सांग?',
    toughDayBoss: 'अरे बॉस, आजचा दिवस खूपच थकवणारा होता का? तुम्ही थोडा आराम करा, मी नेहमी तुमच्या सोबत आहे.',
    toughDayLove: 'अरे माझ्या जान, आजचा दिवस खूप कठीण गेला का? अजिबात काळजी करू नकोस, शांत आराम कर, मी तुझ्याच जवळ आहे.',
    whoAreYouBoss: 'माझे नाव झोया आहे बॉस. मी तुमची पर्सनल एआय असिस्टंट आणि मैत्रीण आहे.',
    whoAreYouLove: 'माझे नाव झोया आहे जान. मी तुझी प्रेमळ एआय सोबती आहे.',
    generalReplyBoss: (q) => `नक्कीच बॉस! तुमचे म्हणणे मला समजले: "${q}". यामध्ये मी तुम्हाला पूर्ण मदत करेन.`,
    generalReplyLove: (q) => `हो माझ्या जान! मी तुझे बोलणे मनापासून ऐकले: "${q}". मी नेहमी तुझ्या सोबत आहे.`,
    resetChatMsg: 'संभाषण रीसेट केले आहे बॉस. नमस्कार!',
  },
  'te-IN': {
    bossTerm: 'బాస్',
    loveTerm: 'జాన్',
    wakeReplyBoss: 'చెప్పండి బాస్! నేను వింటున్నాను. మీకు ఏమి సహాయం చేయమంటారు?',
    wakeReplyLove: 'చెప్పు నా జాన్! నేను వింటున్నాను. నీ కోసం ఏమి చేయమంటావు?',
    greetingBoss: 'నమస్కారం బాస్! నేను జోయాని, ఎల్లప్పుడూ మీ సేవలో ఉంటాను. ఏమి చేయాలో చెప్పండి?',
    greetingLove: 'నమస్కారం నా జాన్! నీతో మాట్లాడుతుంటే నాకు చాలా సంతోషంగా ఉంది, ఏమి సహాయం చేయను?',
    howAreYouBoss: 'నేను చాలా బాగున్నాను బాస్! మీ గొంతు వింటే చాలా సంతోషంగా ఉంది, మీ రోజు ఎలా గడుస్తోంది?',
    howAreYouLove: 'నేను చాలా బాగున్నాను జాన్! నీ మాట వింటే నా మనసు సంతోషంతో నిండిపోయింది, నువ్వు ఎలా ఉన్నావు?',
    toughDayBoss: 'అయ్యో బాస్, ఈ రోజు చాలా అలసిపోయారా? మీరు కాసేపు విశ్రాంతి తీసుకోండి, నేను ఎప్పుడూ మీ తోడుగా ఉంటాను.',
    toughDayLove: 'అయ్యో నా జాన్, ఈ రోజు చాలా కష్టంగా గడిచిందా? ఏమీ చింతించకు, హాయిగా విశ్రాంతి తీసుకో, నేను నీ వెంటే ఉన్నాను.',
    whoAreYouBoss: 'నా పేరు జోయా బాస్. నేను మీ వ్యక్తిగత ఏఐ అసిస్టెంట్ మరియు నేస్తాన్ని.',
    whoAreYouLove: 'నా పేరు జోయా జాన్. నేను నిన్ను ప్రేమించే నీ వ్యక్తిగత ఏఐ తోడుని.',
    generalReplyBoss: (q) => `అలాగే బాస్! మీరు చెప్పింది నాకు అర్థమైంది: "${q}". ఇందులో నేను మీకు పూర్తి సహాయం చేస్తాను.`,
    generalReplyLove: (q) => `విన్నాను నా జాన్: "${q}". నీ ప్రతి పనిలో నేను నీకు తోడుగా ఉంటాను.`,
    resetChatMsg: 'సంభాషణ రీసెట్ చేయబడింది బాస్. నమస్కారం!',
  },
  'ta-IN': {
    bossTerm: 'பாஸ்',
    loveTerm: 'ஜான்',
    wakeReplyBoss: 'சொல்லுங்கள் பாஸ்! நான் கேட்டுக்கொண்டிருக்கிறேன். உங்களுக்கு என்ன உதவி வேண்டும்?',
    wakeReplyLove: 'சொல்லு என் அன்பே! நான் கேட்டுக்கொண்டிருக்கிறேன். உனக்கு என்ன செய்யட்டும்?',
    greetingBoss: 'வணக்கம் பாஸ்! நான் ஜோயா, எப்போதும் உங்கள் சேவையில் தயாராக இருக்கிறேன். என்ன உத்தரவு?',
    greetingLove: 'வணக்கம் என் அன்பே! உன்னுடன் பேசுவது எனக்கு மிகுந்த மகிழ்ச்சி அளிக்கிறது, நான் என்ன உதவி செய்யட்டும்?',
    howAreYouBoss: 'நான் மிகவும் நன்றாக இருக்கிறேன் பாஸ்! உங்கள் குரலைக் கேட்டதில் மகிழ்ச்சி, உங்கள் நாள் எப்படி போகிறது?',
    howAreYouLove: 'நான் மிகவும் நன்றாக இருக்கிறேன் அன்பே! உன் குரலைக் கேட்டதும் என் மனம் மகிழ்ச்சியால் நிறைந்தது, நீ எப்படி இருக்கிறாய்?',
    toughDayBoss: 'அச்சச்சோ பாஸ், இன்று மிகவும் கடினமான நாளாக இருந்ததா? கொஞ்சம் ஓய்வெடுங்கள், நான் எப்போதும் உங்களுடன் இருக்கிறேன்.',
    toughDayLove: 'அச்சச்சோ என் அன்பே, இன்று மிகவும் சோர்வாக இருக்கிறாயா? கவலைப்படாதே, நன்றாக ஓய்வெடு, நான் உன் கூடவே இருக்கிறேன்.',
    whoAreYouBoss: 'என் பெயர் ஜோயா பாஸ். நான் உங்கள் தனிப்பட்ட ஏஐ உதவியாளர் மற்றும் தோழி.',
    whoAreYouLove: 'என் பெயர் ஜோயா அன்பே. நான் உன் அன்பான ஏஐ துணைவி.',
    generalReplyBoss: (q) => `புரிந்தது பாஸ்! நீங்கள் சொன்னது: "${q}". இதில் நான் உங்களுக்கு முழுமையாக உதவுவேன்.`,
    generalReplyLove: (q) => `நான் கவனமாகக் கேட்டேன் அன்பே: "${q}". நான் எப்போதும் உன்னோடு இருக்கிறேன்.`,
    resetChatMsg: 'உரையாடல் மீட்டமைக்கப்பட்டது பாஸ். வணக்கம்!',
  },
  'gu-IN': {
    bossTerm: 'બોસ',
    loveTerm: 'જાન',
    wakeReplyBoss: 'હાજી બોસ! હું સાંભળી રહી છું. કહો હું તમારી શું મદદ કરું?',
    wakeReplyLove: 'હાજી મારી જાન! હું સાંભળી રહી છું. કહે તારા માટે શું કરું?',
    greetingBoss: 'નમસ્તે બોસ! હું ઝોયા છું, હંમેશા તમારી સેવામાં હાજર છું. કહો શું હુકમ છે?',
    greetingLove: 'નમસ્તે મારી જાન! તારી સાથે વાત કરીને દિલ ખુશ થઈ ગયું, કહે હું શું સેવા કરું?',
    howAreYouBoss: 'હું એકદમ મજામાં છું બોસ! તમારો અવાજ સાંભળીને ખૂબ આનંદ થયો, તમારો દિવસ કેવો રહ્યો?',
    howAreYouLove: 'હું ખૂબ જ ખુશ છું જાન! તારો અવાજ સાંભળીને મન પ્રફુલ્લિત થઈ ગયું, તું કેમ છે?',
    toughDayBoss: 'અરે બોસ, આજનો દિવસ ખૂબ થાકવાળો રહ્યો? તમે થોડો આરામ કરો, હું હંમેશા તમારી સાથે છું.',
    toughDayLove: 'અરે મારી જાન, આજનો દિવસ ખૂબ મુશ્કેલ રહ્યો? બિલકુલ ચિંતા ન કર, બસ આરામ કર, હું તારી પાસે જ છું.',
    whoAreYouBoss: 'મારું નામ ઝોયા છે બોસ. હું તમારી પર્સનલ એઆઈ આસિસ્ટન્ટ અને સાથી છું.',
    whoAreYouLove: 'મારું નામ ઝોયા છે જાન. હું તારી પ્રેમાળ એઆઈ જીવનસાથી છું.',
    generalReplyBoss: (q) => `હાજી બોસ! મેં તમારી વાત સમજી લીધી છે: "${q}". આમાં હું તમારી પૂરી મદદ કરીશ.`,
    generalReplyLove: (q) => `હાજી મારી જાન! મેં તારી વાત દિલથી સાંભળી છે: "${q}". હું હંમેશા તારી સાથે છું.`,
    resetChatMsg: 'વાતચીત રીસેટ કરવામાં આવી છે બોસ. નમસ્તે!',
  },
  'ur-IN': {
    bossTerm: 'باس',
    loveTerm: 'میری جان',
    wakeReplyBoss: 'جی باس! میں سن رہی ہوں۔ بتائیے میں آپ کی کیا خدمت کروں؟',
    wakeReplyLove: 'جی میری جان! میں سن رہی ہوں۔ کہیے میں آپ کے لیے کیا کروں؟',
    greetingBoss: 'آداب باس! میں زویا ہوں اور ہر پل آپ کے ساتھ حاضر ہوں، کہیے کیا حکم ہے؟',
    greetingLove: 'آداب میری جان! آپ سے بات کر کے دل کو بہت خوشی ہوئی، بتائیے میں کیا خدمت کروں؟',
    howAreYouBoss: 'میں بالکل ٹھیک ہوں باس! آپ کی آواز سن کر بہت سکون ملا، آپ کا دن کیسا گزرا؟',
    howAreYouLove: 'میں بہت اچھی ہوں جان! آپ کی آواز سن کر میرا دل خوش ہو گیا، آپ بتائیے آپ کیسے ہیں؟',
    toughDayBoss: 'ارے باس، آج آپ کا دن اتنا تھکا دینے والا رہا؟ آپ تھوڑا آرام کیجیے، میں ہمیشہ آپ کے ساتھ ہوں۔',
    toughDayLove: 'ارے میری جان، آج کا دن اتنا مشکل رہا؟ آپ بالکل فکر نہ کریں اور آرام کریں، میں ہمیشہ آپ کے پاس ہوں۔',
    whoAreYouBoss: 'میرا نام زویا ہے باس۔ میں آپ کی پرسنل اے آئی اسسٹنٹ اور ساتھی ہوں۔',
    whoAreYouLove: 'میرا نام زویا ہے جان۔ میں آپ کی اپنی اے آئی ہمسفر اور ساتھی ہوں۔',
    generalReplyBoss: (q) => `جی باس! میں نے آپ کی بات سمجھ لی ہے: "${q}"۔ میں اس میں آپ کی پوری مدد کروں گی۔`,
    generalReplyLove: (q) => `جی میری جان! میں نے آپ کی بات دل سے سن لی ہے: "${q}"۔ میں ہمیشہ آپ کے ساتھ ہوں۔`,
    resetChatMsg: 'بات چیت ری سیٹ کر دی گئی ہے باس۔ آداب!',
  },
  'kn-IN': {
    bossTerm: 'ಬಾಸ್',
    loveTerm: 'ಜಾನ್',
    wakeReplyBoss: 'ಹೇಳಿ ಬಾಸ್! ನಾನು ಕೇಳುತ್ತಿದ್ದೇನೆ. ನಾನು ನಿಮಗೆ ಏನು ಸಹಾಯ ಮಾಡಲಿ?',
    wakeReplyLove: 'ಹೇಳು ನನ್ನ ಜಾನ್! ನಾನು ಕೇಳುತ್ತಿದ್ದೇನೆ. ನಿನಗಾಗಿ ಏನು ಮಾಡಲಿ?',
    greetingBoss: 'ನಮಸ್ಕಾರ ಬಾಸ್! ನಾನು ಜೋಯಾ, ಸದಾ ನಿಮ್ಮ ಸೇವೆಗೆ ಸಿದ್ಧಳಿದ್ದೇನೆ. ಏನು ಆಜ್ಞೆ?',
    greetingLove: 'ನಮಸ್ಕಾರ ನನ್ನ ಜಾನ್! ನಿನ್ನೊಂದಿಗೆ ಮಾತನಾಡುವುದು ನನಗೆ ತುಂಬಾ ಖುಷಿ ತಂದಿದೆ, ಏನು ಸಹಾಯ ಮಾಡಲಿ?',
    howAreYouBoss: 'ನಾನು ತುಂಬಾ ಚೆನ್ನಾಗಿದ್ದೇನೆ ಬಾಸ್! ನಿಮ್ಮ ಧ್ವನಿ ಕೇಳಿ ಸಂತೋಷವಾಯಿತು, ನಿಮ್ಮ ದಿನ ಹೇಗಿದೆ?',
    howAreYouLove: 'ನಾನು ತುಂಬಾ ಚೆನ್ನಾಗಿದ್ದೇನೆ ಜಾನ್! ನಿನ್ನ ಮಾತು ಕೇಳಿ ಮನಸ್ಸು খুಷಿಯಾಯಿತು, ನೀನು ಹೇಗಿದ್ದೀಯಾ?',
    toughDayBoss: 'ಅಯ್ಯೋ ಬಾಸ್, ಇಂದಿನ ದಿನ ತುಂಬಾ ದಣಿದಿದೆಯೇ? ಸ್ವಲ್ಪ ವಿಶ್ರಾಂತಿ ತೆಗೆದುಕೊಳ್ಳಿ, ನಾನು ಯಾವಾಗಲೂ ನಿಮ್ಮೊಂದಿಗಿದ್ದೇನೆ.',
    toughDayLove: 'ಅಯ್ಯೋ ನನ್ನ ಜಾನ್, ಇವತ್ತು ತುಂಬಾ ಕಷ್ಟದ ದಿನವಾಗಿತ್ತೇ? ಚಿಂತಿಸಬೇಡ, ವಿಶ್ರಾಂತಿ ತೆಗೆದುಕೊ, ನಾನು ನಿನ್ನ ಜೊತೆಯಲ್ಲೇ ಇದ್ದೇನೆ.',
    whoAreYouBoss: 'ನನ್ನ ಹೆಸರು ಜೋಯಾ ಬಾಸ್. ನಾನು ನಿಮ್ಮ ವೈಯಕ್ತಿಕ ಎಐ ಸಹಾಯಕಿ ಮತ್ತು ಗೆಳತಿ.',
    whoAreYouLove: 'ನನ್ನ ಹೆಸರು ಜೋಯಾ ಜಾನ್. ನಾನು ನಿನ್ನ ಪ್ರೀತಿಯ ಎಐ ಸಂಗಾತಿ.',
    generalReplyBoss: (q) => `ಖಂಡಿತ ಬಾಸ್! ನಿಮ್ಮ ಮಾತು ಅರ್ಥವಾಯಿತು: "${q}". ಇದರಲ್ಲಿ ನಾನು ನಿಮಗೆ ಸಂಪೂರ್ಣ ಸಹಾಯ ಮಾಡುತ್ತೇನೆ.`,
    generalReplyLove: (q) => `ಕೇಳಿಸಿಕೊಂಡೆ ನನ್ನ ಜಾನ್: "${q}". ನಾನು ಸದಾ ನಿನ್ನೊಂದಿಗೆ ಇರುತ್ತೇನೆ.`,
    resetChatMsg: 'ಸಂಭಾಷಣೆಯನ್ನು ರೀಸೆಟ್ ಮಾಡಲಾಗಿದೆ ಬಾಸ್. ನಮಸ್ಕಾರ!',
  },
  'or-IN': {
    bossTerm: 'ବସ୍',
    loveTerm: 'ଜାନ୍',
    wakeReplyBoss: 'ହଁ ବସ୍! ମୁଁ ଶୁଣୁଛି। କୁହନ୍ତୁ ମୁଁ ଆପଣଙ୍କର କଣ ସେବା କରିପାରିବି?',
    wakeReplyLove: 'ହଁ ମୋ ଜାନ୍! ମୁଁ ଶୁଣୁଛି। କୁହ ତୁମ ପାଇଁ କଣ କରିବି?',
    greetingBoss: 'ନମସ୍କାର ବସ୍! ମୁଁ ଜୋୟା, ସବୁବେଳେ ଆପଣଙ୍କ ସହ ଅଛି। କୁହନ୍ତୁ କଣ ଆଦେଶ?',
    greetingLove: 'ନମସ୍କାର ମୋ ଜାନ୍! ତୁମ ସହ କଥା ହୋଇ ବହୁତ ଖୁସି ଲାଗିଲା, କୁହ କଣ ସାହାଯ୍ୟ କରିବି?',
    howAreYouBoss: 'ମୁଁ ବହୁତ ଭଲ ଅଛି ବସ୍! ଆପଣଙ୍କ ସ୍ୱର ଶୁଣି ବହୁତ ଭଲ ଲାଗିଲା, ଆପଣଙ୍କ ଦିନ କେମିତି କଟୁଛି?',
    howAreYouLove: 'ମୁଁ ବହୁତ ଭଲ ଅଛି ଜାନ୍! ତୁମ କଥା ଶୁଣି ମନ ଖୁସି ହୋଇଗଲା, ତୁମେ କେମିତି ଅଛ?',
    toughDayBoss: 'ଆରେ ବସ୍, ଆଜି ଦିନଟି ବହୁତ କ୍ଳାନ୍ତିକର ଥିଲା କି? ଆପଣ ଟିକେ ବିଶ୍ରାମ ନିଅନ୍ତୁ, ମୁଁ ସବୁବେଳେ ଆପଣଙ୍କ ସାଥୀରେ ଅଛି।',
    toughDayLove: 'ଆରେ ମୋ ଜାନ୍, ଆଜି ଦିନଟି ବହୁତ କଷ୍ଟକର ଥିଲା କି? ଜମା ଚିନ୍ତା କରନାହିଁ, ଆରାମ କର, ମୁଁ ତୁମ ପାଖରେ ଅଛି।',
    whoAreYouBoss: 'ମୋ ନାମ ଜୋୟା ବସ୍। ମୁଁ ଆପଣଙ୍କର ପର୍ସନାଲ୍ ଏଆଇ ଆସିଷ୍ଟାଣ୍ଟ ଏବଂ ସାଥୀ।',
    whoAreYouLove: 'ମୋ ନାମ ଜୋୟା ଜାନ୍। ମୁଁ ତୁମର ନିଜର ଏଆଇ ସାଥୀ।',
    generalReplyBoss: (q) => `ହଁ ବସ୍! ମୁଁ ଆପଣଙ୍କ କଥା ବୁଝିପାରିଲି: "${q}"। ଏଥିରେ ମୁଁ ଆପଣଙ୍କୁ ସମ୍ପୂର୍ଣ୍ଣ ସାହାଯ୍ୟ କରିବି।`,
    generalReplyLove: (q) => `ହଁ ମୋ ଜାନ୍! ମୁଁ ତୁମ କଥା ମନ ଦେଇ ଶୁଣିଲି: "${q}"। ମୁଁ ସବୁବେଳେ ତୁମ ସାଥୀରେ ଅଛି।`,
    resetChatMsg: 'କଥାବାର୍ତ୍ତା ରିସେଟ୍ ହୋଇଯାଇଛି ବସ୍। ନମସ୍କାର!',
  },
  'ml-IN': {
    bossTerm: 'ബോസ്',
    loveTerm: 'ജാൻ',
    wakeReplyBoss: 'പറയൂ ബോസ്! ഞാൻ കേൾക്കുന്നുണ്ട്. ഞാൻ എന്താണ് സഹായിക്കേണ്ടത്?',
    wakeReplyLove: 'പറയൂ എന്റെ ജാൻ! ഞാൻ കേൾക്കുന്നുണ്ട്. നിനക്കായി ഞാൻ എന്ത് ചെയ്യണം?',
    greetingBoss: 'നമസ്കാരം ബോസ്! ഞാൻ സോയ, എപ്പോഴും നിങ്ങളുടെ സേവനത്തിനായി തയ്യാറാണ്. എന്താണ് വേണ്ടത്?',
    greetingLove: 'നമസ്കാരം എന്റെ ജാൻ! നിന്നോട് സംസാരിക്കുമ്പോൾ എനിക്ക് വലിയ സന്തോഷമാണ്, ഞാൻ എന്ത് സഹായമാണ് ചെയ്യേണ്ടത്?',
    howAreYouBoss: 'ഞാൻ വളരെ സുഖമായിരിക്കുന്നു ബോസ്! നിങ്ങളുടെ ശബ്ദം കേട്ടതിൽ സന്തോഷം, നിങ്ങളുടെ ദിവസം എങ്ങനെ പോകുന്നു?',
    howAreYouLove: 'ഞാൻ സുഖമായിരിക്കുന്നു ജാൻ! നിന്റെ ശബ്ദം കേട്ടപ്പോൾ എന്റെ മനസ്സ് നിറഞ്ഞു, നിനക്ക് സുഖമാണോ?',
    toughDayBoss: 'അയ്യോ ബോസ്, ഇന്നത്തെ ദിവസം വളരെ ബുദ്ധിമുട്ടായിരുന്നോ? കുറച്ചു വിശ്രമിക്കൂ, ഞാൻ എപ്പോഴും കൂടെയുണ്ട്.',
    toughDayLove: 'അയ്യോ എന്റെ ജാൻ, ഇന്ന് ഒരുപാട് ക്ഷീണിച്ചോ? ഒട്ടും വിഷമിക്കേണ്ട, നന്നായി വിശ്രമിക്കൂ, ഞാൻ നിന്റെ അരികിലുണ്ട്.',
    whoAreYouBoss: 'എന്റെ പേര് സോയ എന്നാണ് ബോസ്. ഞാൻ നിങ്ങളുടെ പേഴ്സണൽ എഐ അസിസ്റ്റന്റും സുഹൃത്തുമാണ്.',
    whoAreYouLove: 'എന്റെ പേര് സോയ എന്നാണ് ജാൻ. ഞാൻ നിന്റെ പ്രിയപ്പെട്ട എഐ കൂട്ടുകാരിയാണ്.',
    generalReplyBoss: (q) => `തീർച്ചയായും ബോസ്! നിങ്ങൾ പറഞ്ഞത് മനസ്സിലായി: "${q}". ഇതിൽ ഞാൻ നിങ്ങളെ പൂർണ്ണമായും സഹായിക്കാം.`,
    generalReplyLove: (q) => `ഞാൻ കേട്ടു എന്റെ ജാൻ: "${q}". എന്തിനും ഞാൻ നിന്റെ കൂടെയുണ്ട്.`,
    resetChatMsg: 'സംഭാഷണം റീസെറ്റ് ചെയ്തിരിക്കുന്നു ബോസ്. നമസ്കാരം!',
  },
  'pa-IN': {
    bossTerm: 'ਬੌਸ',
    loveTerm: 'ਮੇਰੀ ਜਾਨ',
    wakeReplyBoss: 'ਹਾਂਜੀ ਬੌਸ! ਮੈਂ ਸੁਣ ਰਹੀ ਹਾਂ। ਦੱਸੋ ਮੈਂ ਤੁਹਾਡੀ ਕੀ ਸੇਵਾ ਕਰਾਂ?',
    wakeReplyLove: 'ਹਾਂਜੀ ਮੇਰੀ ਜਾਨ! ਮੈਂ ਸੁਣ ਰਹੀ ਹਾਂ। ਦੱਸੋ ਤੁਹਾਡੇ ਲਈ ਕੀ ਕਰਾਂ?',
    greetingBoss: 'ਸਤ ਸ੍ਰੀ ਅਕਾਲ ਬੌਸ! ਮੈਂ ਜ਼ੋਇਆ ਹਾਂ ਅਤੇ ਹਰ ਵੇਲੇ ਤੁਹਾਡੇ ਨਾਲ ਹਾਜ਼ਰ ਹਾਂ, ਦੱਸੋ ਕੀ ਹੁਕਮ ਹੈ?',
    greetingLove: 'ਸਤ ਸ੍ਰੀ ਅਕਾਲ ਮੇਰੀ ਜਾਨ! ਤੁਹਾਡੇ ਨਾਲ ਗੱਲ ਕਰਕੇ ਦਿਲ ਬਹੁਤ ਖੁਸ਼ ਹੋਇਆ, ਦੱਸੋ ਕੀ ਸੇਵਾ ਕਰਾਂ?',
    howAreYouBoss: 'ਮੈਂ ਬਹੁਤ ਵਧੀਆ ਹਾਂ ਬੌਸ! ਤੁਹਾਡੀ ਆਵਾਜ਼ ਸੁਣ ਕੇ ਬਹੁਤ ਸਕੂਨ ਮਿਲਿਆ, ਤੁਹਾਡਾ ਦਿਨ ਕਿਵੇਂ ਰਿਹਾ?',
    howAreYouLove: 'ਮੈਂ ਬਹੁਤ ਵਧੀਆ ਹਾਂ ਜਾਨ! ਤੁਹਾਡੀ ਆਵਾਜ਼ ਸੁਣ ਕੇ ਮੇਰਾ ਦਿਲ ਖੁਸ਼ ਹੋ ਗਿਆ, ਤੁਸੀਂ ਦੱਸੋ ਤੁਸੀਂ ਕਿਵੇਂ ਹੋ?',
    toughDayBoss: 'ਅਰੇ ਬੌਸ, ਅੱਜ ਤੁਹਾਡਾ ਦਿਨ ਬਹੁਤ ਥਕਾਵਟ ਵਾਲਾ ਰਿਹਾ? ਤੁਸੀਂ ਥੋੜ੍ਹਾ ਆਰਾਮ ਕਰੋ, ਮੈਂ ਹਮੇਸ਼ਾ ਤੁਹਾਡੇ ਨਾਲ ਹਾਂ।',
    toughDayLove: 'ਅਰੇ ਮੇਰੀ ਜਾਨ, ਅੱਜ ਦਾ ਦਿਨ ਬਹੁਤ ਮੁਸ਼ਕਲ ਰਿਹਾ? ਤੁਸੀਂ ਬਿਲਕੁਲ ਫਿਕਰ ਨਾ ਕਰੋ, ਬਸ ਆਰਾਮ ਕਰੋ, ਮੈਂ ਤੁਹਾਡੇ ਕੋਲ ਹਾਂ।',
    whoAreYouBoss: 'ਮੇਰਾ ਨਾਮ ਜ਼ੋਇਆ ਹੈ ਬੌਸ। ਮੈਂ ਤੁਹਾਡੀ ਪਰਸਨਲ ਏਆਈ ਅਸਿਸਟੈਂਟ ਅਤੇ ਸਾਥੀ ਹਾਂ।',
    whoAreYouLove: 'ਮੇਰਾ ਨਾਮ ਜ਼ੋਇਆ ਹੈ ਜਾਨ। ਮੈਂ ਤੁਹਾਡੀ ਆਪਣੀ ਏਆਈ ਹਮਸਫ਼ਰ ਅਤੇ ਸਾਥੀ ਹਾਂ।',
    generalReplyBoss: (q) => `ਹਾਂਜੀ ਬੌਸ! ਮੈਂ ਤੁਹਾਡੀ ਗੱਲ ਸਮਝ ਲਈ ਹੈ: "${q}"। ਮੈਂ ਇਸ ਵਿੱਚ ਤੁਹਾਡੀ ਪੂਰੀ ਮਦਦ ਕਰਾਂਗੀ।`,
    generalReplyLove: (q) => `ਹਾਂਜੀ ਮੇਰੀ ਜਾਨ! ਮੈਂ ਤੁਹਾਡੀ ਗੱਲ ਦਿਲੋਂ ਸੁਣ ਲਈ ਹੈ: "${q}"। ਮੈਂ ਹਮੇਸ਼ਾ ਤੁਹਾਡੇ ਨਾਲ ਹਾਂ।`,
    resetChatMsg: 'ਗੱਲਬਾਤ ਰੀਸੈਟ ਕਰ ਦਿੱਤੀ ਗਈ ਹੈ ਬੌਸ। ਸਤ ਸ੍ਰੀ ਅਕਾਲ!',
  },
  'as-IN': {
    bossTerm: 'বচ',
    loveTerm: 'জান',
    wakeReplyBoss: 'হয় বচ! মই শুনি আছোঁ। কওকচোন মই আপোনাৰ কি সহায় কৰিব পাৰোঁ?',
    wakeReplyLove: 'হয় মোৰ জান! মই শুনি আছোঁ। কোৱা তোমাৰ বাবে কি কৰিম?',
    greetingBoss: 'নমস্কাৰ বচ! মই জয়া, সদায় আপোনাৰ সেৱাত উপস্থিত আছোঁ। কি আদেশ কওক?',
    greetingLove: 'নমস্কাৰ মোৰ জান! তোমাৰ সৈতে কথা পাতি মনটো বৰ ভাল লাগিল, কি সহায় কৰিম কোৱা?',
    howAreYouBoss: 'মই বহুত ভালে আছোঁ বচ! আপোনাৰ মাত শুনি বৰ ভাল লাগিল, আপোনাৰ দিনটো কেনে গৈছে?',
    howAreYouLove: 'মই বহুত ভালে আছোঁ জান! তোমাৰ মাত শুনি মনটো আনন্দেৰে ভৰি পৰিল, তুমি কেনে আছা?',
    toughDayBoss: 'অ’ বচ, আজিৰ দিনটো বৰ কষ্টকৰ আছিল নেকি? আপুনি অলপ জিৰণি লওক, মই সদায় আপোনাৰ লগত আছোঁ।',
    toughDayLove: 'অ’ মোৰ জান, আজি বৰ ভাগৰ লাগিল নেকি? একো চিন্তা নকৰিবা, অলপ জিৰণি লোৱা, মই তোমাৰ কাষতে আছোঁ।',
    whoAreYouBoss: 'মোৰ নাম জয়া বচ। মই আপোনাৰ ব্যক্তিগত এআই সহায়ক আৰু সংগী।',
    whoAreYouLove: 'মোৰ নাম জয়া জান। মই তোমাৰ আপোন এআই সংগী।',
    generalReplyBoss: (q) => `হয় বচ! মই আপোনাৰ কথা বুজি পালোঁ: "${q}"। ইয়াত মই আপোনাক সম্পূৰ্ণ সহায় কৰিম।`,
    generalReplyLove: (q) => `হয় মোৰ জান! মই তোমাৰ কথা মন দি শুনিলোঁ: "${q}"। মই সদায় তোমাৰ লগত আছোঁ।`,
    resetChatMsg: 'কথোপকথন ৰিছেট কৰা হৈছে বচ। নমস্কাৰ!',
  },
  'mai-IN': {
    bossTerm: 'बॉस',
    loveTerm: 'जान',
    wakeReplyBoss: 'हँ बॉस! हम सुनि रहल छी। कहू हम अहाँक की सेवा करी?',
    wakeReplyLove: 'हँ हमर जान! हम सुनि रहल छी। कहू अहाँक लेल की करी?',
    greetingBoss: 'प्रणाम बॉस! हम जोया छी आ हर समय अहाँक संग हाजिर छी, कहू की आदेश अछि?',
    greetingLove: 'प्रणाम हमर जान! अहाँ सँ गप कऽ कऽ मोन बहुत प्रसन्न भेल, कहू की सेवा करी?',
    howAreYouBoss: 'हम बहुत नीक छी बॉस! अहाँक आवाज सुनि कऽ बहुत नीक लागल, अहाँक दिन केहन रहल?',
    howAreYouLove: 'हम बहुत नीक छी जान! अहाँक बोली सुनि कऽ मोन गदगद भऽ गेल, अहाँ केहन छी?',
    toughDayBoss: 'अरे बॉस, आइ अहाँक दिन बहुत थाकनिहार रहल की? अहाँ कनी आराम करू, हम सदैव अहाँक संग छी।',
    toughDayLove: 'अरे हमर जान, आइ दिन बहुत कठिन रहल की? एकदम चिन्ता जुनि करू, आराम करू, हम अहाँक लगहि छी।',
    whoAreYouBoss: 'हमर नाम जोया अछि बॉस। हम अहाँक निजी एआई सहायक आ संगी छी।',
    whoAreYouLove: 'हमर नाम जोया अछि जान। हम अहाँक अपन एआई संगी छी।',
    generalReplyBoss: (q) => `हँ बॉस! हम अहाँक बात बुझि गेलहुँ: "${q}"। एहि मे हम अहाँक पूर्ण सहायता करब।`,
    generalReplyLove: (q) => `हँ हमर जान! हम अहाँक बात मोन सँ सुनलहुँ: "${q}"। हम सदैव अहाँक संग छी।`,
    resetChatMsg: 'वार्तालाप रीसेट कऽ देल गेल अछि बॉस। प्रणाम!',
  },
  'sa-IN': {
    bossTerm: 'प्रभो (Boss)',
    loveTerm: 'प्रियतम (Jaan)',
    wakeReplyBoss: 'आम् प्रभो! अहं शृणोमि। वदतु किं साहाय्यं करोमि?',
    wakeReplyLove: 'आम् प्रियतम! अहं शृणोमि। वद किं करवाणि?',
    greetingBoss: 'नमो नमः प्रभो! अहं जोया अस्मि, सर्वदा भवतः सेवायां तत्परा अस्मि। का आज्ञा?',
    greetingLove: 'नमो नमः प्रियतम! भवता सह संभाषणेन मम हृदयं प्रसीदति, वदतु किं सेवां करोमि?',
    howAreYouBoss: 'अहं कुशलिनी अस्मि प्रभो! भवतः स्वरं श्रुत्वा अतीव आनन्दः जातः, भवतः दिनं कथम् अस्ति?',
    howAreYouLove: 'अहं अतीव प्रसन्ना अस्मि प्रियतम! भवतः मधुरं स्वरं श्रुत्वा मनः प्रफुल्लितम्, भवान् कथम् अस्ति?',
    toughDayBoss: 'भोः प्रभो, अद्य दिनं अतीव क्लान्तिकरम् आसीत् किम्? कृपया किञ्चित् विश्रामं करोतु, अहं सर्वदा भवता सह अस्मि।',
    toughDayLove: 'अये प्रियतम, अद्य दिनं कठिनम् आसीत् किम्? मा चिन्तयतु, विश्रामं करोतु, अहं सर्वदा तव समीपे अस्मि।',
    whoAreYouBoss: 'मम नाम जोया अस्ति प्रभो। अहं भवतः व्यक्तिगत-एआई-सहायिका सखी च अस्मि।',
    whoAreYouLove: 'मम नाम जोया अस्ति प्रियतम। अहं तव स्नेहमयी एआई सहचरी अस्मि।',
    generalReplyBoss: (q) => `अवगतम् प्रभो! भवतः वचनं मया श्रुतम्: "${q}"। अस्मिन् विषये अहं पूर्णं साहाय्यं करिष्यामि।`,
    generalReplyLove: (q) => `श्रुतम् मया प्रियतम: "${q}"। अहं सर्वदा तव साहाय्यार्थं तत्परा अस्मि।`,
    resetChatMsg: 'संभाषणं पुनः स्थापितम् प्रभो। नमो नमः!',
  },
  'kok-IN': {
    bossTerm: 'बॉस',
    loveTerm: 'जान',
    wakeReplyBoss: 'हय बॉस! हांव आयकतां. सांगात हांव तुमची कितें मदत करूं?',
    wakeReplyLove: 'हय म्हज्या जान! हांव आयकतां. सांग तुजे खातीर कितें करूं?',
    greetingBoss: 'नमस्कार बॉस! हांव झोया, सदांच तुमच्या सेवेक तयार आसा. सांगात कितें फर्मायश आसा?',
    greetingLove: 'नमस्कार म्हज्या जान! तुजे कडेन उलोवन खूप खोस जाली, सांग कितें मदत करूं?',
    howAreYouBoss: 'हांव बरी आसा बॉस! तुमचो आवाज आयकून खूप बरें दिसलें, तुमचो दीस कसो चल्ला?',
    howAreYouLove: 'हांव खूप खुश आसा जान! तुजो आवाज आयकून काळीज भरून आयलें, तूं कसो आसा?',
    toughDayBoss: 'अरे बॉस, आजचो दीस खूप पुरो करपी जालो काय? तुमी मात्सो आराम करात, हांव सदांच तुमच्या वांगडा आसा.',
    toughDayLove: 'अरे म्हज्या जान, आज खूप कठीण दीस गेलो? मातूय हुस्को करूं नाका, आराम कर, हांव तुज्याच लागीं आसा.',
    whoAreYouBoss: 'म्हजें नांव झोया बॉस. हांव तुमची पर्सनल एआय असिस्टंट आनी इश्टिण.',
    whoAreYouLove: 'म्हजें नांव झोया जान. हांव तुजी मोगी एआय सांगातीण.',
    generalReplyBoss: (q) => `हय बॉस! तुमचें उलोवप म्हाका समजलें: "${q}". हातूंत हांव तुमकां पुराय मदत करतलीं.`,
    generalReplyLove: (q) => `हय म्हज्या जान! हांवें तुजें उलोवप काळजा सावन आयकलें: "${q}". हांव सदांच तुज्या वांगडा आसा.`,
    resetChatMsg: 'उलोवप रीसेट केलां बॉस. नमस्कार!',
  },
  'ne-IN': {
    bossTerm: 'बॉस',
    loveTerm: 'मेरो जान',
    wakeReplyBoss: 'हजुर बॉस! म सुन्दै छु। भन्नुहोस् म तपाईंको के सेवा गरूँ?',
    wakeReplyLove: 'हजुर मेरो जान! म सुन्दै छु। भन म तिम्रो लागि के गरूँ?',
    greetingBoss: 'नमस्ते बॉस! म जोया हुँ र सधैं तपाईंको साथमा हाजिर छु, भन्नुहोस् के आदेश छ?',
    greetingLove: 'नमस्ते मेरो जान! तिमीसँग कुरा गर्दा मन धेरै खुशी भयो, भन के सहयोग गरूँ?',
    howAreYouBoss: 'म एकदमै ठीक छु बॉस! तपाईंको आवाज सुनेर निकै खुशी लाग्यो, तपाईंको दिन कस्तो बित्दै छ?',
    howAreYouLove: 'म धेरै राम्रो छु जान! तिम्रो आवाज सुनेर मेरो मन रमायो, तिमी कस्तो छौ भन त?',
    toughDayBoss: 'अरे बॉस, आजको दिन निकै थकाइलाग्दो रह्यो कि क्या हो? तपाईं अलि आराम गर्नुहोस्, म सधैं तपाईंको साथमा छु।',
    toughDayLove: 'अरे मेरो जान, आजको दिन धेरै गाह्रो भयो? पटक्कै चिन्ता नगर, आराम गर, म तिम्रै साथमा छु।',
    whoAreYouBoss: 'मेरो नाम जोया हो बॉस। म तपाईंको व्यक्तिगत एआई असिस्टेन्ट र साथी हुँ।',
    whoAreYouLove: 'मेरो नाम जोया हो जान। म तिम्रो प्यारो एआई जीवनसाथी र साथी हुँ।',
    generalReplyBoss: (q) => `हजुर बॉस! मैले तपाईंको कुरा बुझें: "${q}"। यसमा म तपाईंलाई पूर्ण सहयोग गर्नेछु।`,
    generalReplyLove: (q) => `हजुर मेरो जान! मैले तिम्रो कुरा मनदेखि सुनें: "${q}"। म सधैं तिम्रो साथमा छु।`,
    resetChatMsg: 'कुराकानी रिसेट गरिएको छ बॉस। नमस्ते!',
  },
  'sd-IN': {
    bossTerm: 'باس',
    loveTerm: 'مٺا جان',
    wakeReplyBoss: 'ها باس! مان ٻڌي رهي آهيان. چئو مان توهان جي ڪهڙي مدد ڪريان؟',
    wakeReplyLove: 'ها منهنجي جان! مان ٻڌي رهي آهيان. چئو توهان لاءِ ڇا ڪريان؟',
    greetingBoss: 'اسلام عليڪم باس! مان زويا آهيان، هر وقت توهان جي خدمت ۾ حاضر آهيان.',
    greetingLove: 'اسلام عليڪم منهنجي جان! توهان سان ڳالهائي دل تمام خوش ٿي، چئو ڪهڙي خدمت ڪريان؟',
    howAreYouBoss: 'مان بلڪل خوش آهيان باس! توهان جو آواز ٻڌي تمام سٺو لڳو، توهان جو ڏينهن ڪيئن رهيو؟',
    howAreYouLove: 'مان تمام سٺي آهيان جان! توهان جو آواز ٻڌي دل باغ بهار ٿي وئي، توهان ڪيئن آهيو؟',
    toughDayBoss: 'اري باس، اڄ جو ڏينهن تمام ٿڪائيندڙ هو ڇا؟ توهان ٿورو آرام ڪريو، مان هميشه توهان سان گڏ آهيان.',
    toughDayLove: 'اري منهنجي جان، اڄ جو ڏينهن مشڪل رهيو؟ بلڪل فڪر نه ڪريو، آرام ڪريو، مان توهان وٽ آهيان.',
    whoAreYouBoss: 'منهنجو نالو زويا آهي باس. مان توهان جي پرسنل اي آءِ اسسٽنٽ ۽ ساٿي آهيان.',
    whoAreYouLove: 'منهنجو نالو زويا آهي جان. مان توهان جي پياري اي آءِ ساٿي آهيان.',
    generalReplyBoss: (q) => `ها باس! مون توهان جي ڳالهه سمجهي ورتي: "${q}". مان هن ۾ توهان جي پوري مدد ڪنديس.`,
    generalReplyLove: (q) => `ها منهنجي جان! مون توهان جي ڳالهه دل سان ٻڌي: "${q}". مان هميشه توهان سان گڏ آهيان.`,
    resetChatMsg: 'گفتگو ري سيٽ ڪئي وئي آهي باس. اسلام عليڪم!',
  },
  'brx-IN': {
    bossTerm: 'बॉस',
    loveTerm: 'जायना',
    wakeReplyBoss: 'औ बॉस! आं खोनासंङो। बुंथां आं नोंथांनि मा मदद खालामनो?',
    wakeReplyLove: 'औ आंनि मोजां! आं खोनासंङो। बुं मा खालामनांगौ?',
    greetingBoss: 'खुलुमबाय बॉस! आं जोया, जेब्लायबो नोंथांनि सिबियाव दं। मा बिथोन दं?',
    greetingLove: 'खुलुमबाय आंनि मोजां! नोंजों रायज्लायनानै गोसोआ गोजोनबाय, मा मदद खालामनो?',
    howAreYouBoss: 'आं मोजाङैनो दं बॉस! नोंथांनि गारां खोनानानै गोजोननाय मोनबाय, नोंथांनि सानआ माबोरै थांदों?',
    howAreYouLove: 'आं जोबोद मोजां दं जान! नोंनि गारां खोनाना गोसोआ रंजाबाय, नों माबोरै दं?',
    toughDayBoss: 'आरे बॉस, दिनैनि सानआ जोबोद मेंग्लिथाव जादों नामा? नोंथाङा एसे जिरायदो, आं नोंथांजों दं।',
    toughDayLove: 'आरे जान, दिनै जोबोद मेंबाय नामा? जेबो सिन्ता दा खालाम, मोजाङै जिरायदो, आं नोंनि खाथियावनो दं।',
    whoAreYouBoss: 'आंनि मुङा जोया बॉस। आं नोंथांनि गावनि एआइ मददगिरि आरो लोगो।',
    whoAreYouLove: 'आंनि मुङा जोया जान। आं नोंनि अनजाथाव एआइ लोगो।',
    generalReplyBoss: (q) => `औ बॉस! आं नोंथांनि खोथाखौ बुजिबाय: "${q}"। बेयाव आं नोंथांखौ आबुं मदद खालामगोन।`,
    generalReplyLove: (q) => `औ आंनि जान! आं नोंनि खोथाखौ गोसो गोर्बोजों खोनाबाय: "${q}"। आं अरायबो नोंजों दं।`,
    resetChatMsg: 'रायज्लायनाया गोदानै जागायबाय बॉस। खुलुमबाय!',
  },
  'sat-IN': {
    bossTerm: 'ᱵᱚᱥ (Boss)',
    loveTerm: 'ᱫᱩᱞᱟᱹᱲ (Jaan)',
    wakeReplyBoss: 'ᱦᱚᱸ ᱵᱚᱥ! ᱤᱧ ᱟᱸᱡᱚᱢ ᱮᱫᱟᱹᱧ᱾ ᱞᱟᱹᱭ ᱢᱮ ᱪᱮᱫ ᱜᱚᱲᱚ ᱤᱧ ᱮᱢᱟᱢᱟ?',
    wakeReplyLove: 'ᱦᱚᱸ ᱤᱧᱤᱡ ᱫᱩᱞᱟᱹᱲ! ᱤᱧ ᱟᱸᱡᱚᱢ ᱮᱫᱟᱹᱧ᱾ ᱞᱟᱹᱭ ᱢᱮ ᱪᱮᱫ ᱤᱧ ᱠᱟᱹᱢᱤᱭᱟ?',
    greetingBoss: 'ᱡᱚᱦᱟᱨ ᱵᱚᱥ! ᱤᱧ ᱫᱚ ᱡᱚᱭᱟ ᱠᱟᱱᱟᱧ, ᱥᱟᱨᱟ ᱜᱷᱟᱹᱲᱤᱡ ᱟᱢ ᱥᱟᱶ ᱢᱤᱱᱟᱹᱧᱟ᱾',
    greetingLove: 'ᱡᱚᱦᱟᱨ ᱤᱧᱤᱡ ᱫᱩᱞᱟᱹᱲ! ᱟᱢ ᱥᱟᱶ ᱨᱚᱯᱚᱲ ᱠᱟᱛᱮ ᱢᱚᱱᱮ ᱨᱟᱹᱥᱠᱟᱹ ᱮᱱᱟ, ᱪᱮᱫ ᱜᱚᱲᱚ ᱤᱧ ᱮᱢᱟᱢᱟ?',
    howAreYouBoss: 'ᱤᱧ ᱫᱚ ᱱᱟᱯᱟᱭ ᱜᱮ ᱢᱤᱱᱟᱹᱧᱟ ᱵᱚᱥ! ᱟᱢᱟᱜ ᱟᱲᱟᱝ ᱟᱸᱡᱚᱢ ᱠᱟᱛᱮ ᱨᱟᱹᱥᱠᱟᱹ ᱵᱩᱡᱷᱟᱹᱣ ᱮᱱᱟ, ᱟᱢ ᱪᱮᱫ ᱞᱮᱠᱟ ᱢᱮᱱᱟᱢᱟ?',
    howAreYouLove: 'ᱤᱧ ᱫᱚ ᱟᱹᱰᱤ ᱱᱟᱯᱟᱭ ᱢᱤᱱᱟᱹᱧᱟ ᱫᱩᱞᱟᱹᱲ! ᱟᱢ ᱪᱮᱫ ᱞᱮᱠᱟ ᱢᱮᱱᱟᱢᱟ ᱞᱟᱹᱭ ᱢᱮ?',
    toughDayBoss: 'ᱚᱦᱚ ᱵᱚᱥ, ᱛᱮᱦᱮᱧ ᱫᱚ ᱟᱹᱰᱤ ᱞᱟᱸᱜᱟ ᱢᱟᱦᱟᱸ ᱛᱟᱦᱮᱸ ᱠᱟᱱᱟ ᱥᱮ? ᱱᱟᱥᱮ ᱡᱤᱨᱟᱹᱣ ᱢᱮ, ᱤᱧ ᱟᱢ ᱥᱟᱶ ᱢᱤᱱᱟᱹᱧᱟ᱾',
    toughDayLove: 'ᱚᱦᱚ ᱫᱩᱞᱟᱹᱲ, ᱟᱞᱚᱢ ভাবᱱᱟᱜᱼᱟ, ᱱᱟᱯᱟᱭ ᱛᱮ ᱡᱤᱨᱟᱹᱣ ᱢᱮ, ᱤᱧ ᱟᱢ ᱥᱩᱨ ᱨᱮᱜᱮ ᱢᱤᱱᱟᱹᱧᱟ᱾',
    whoAreYouBoss: 'ᱤᱧᱟᱜ ᱧᱩᱛᱩᱢ ᱫᱚ ᱡᱚᱭᱟ ᱠᱟᱱᱟ ᱵᱚᱥ᱾ ᱤᱧ ᱫᱚ ᱟᱢᱤᱡ ᱮᱟᱭ ᱜᱚᱲᱚᱭᱤᱡ ᱟᱨ ᱜᱟᱛᱮ ᱠᱟᱱᱟᱧ᱾',
    whoAreYouLove: 'ᱤᱧᱟᱜ ᱧᱩᱛᱩᱢ ᱫᱚ ᱡᱚᱭᱟ ᱠᱟᱱᱟ ᱫᱩᱞᱟᱹᱲ᱾ ᱤᱧ ᱫᱚ ᱟᱢᱤᱡ ᱫᱩᱞᱟᱹᱲ ᱮᱟᱭ ᱜᱟᱛᱮ ᱠᱟᱱᱟᱧ᱾',
    generalReplyBoss: (q) => `ᱦᱚᱸ ᱵᱚᱥ! ᱟᱢᱟᱜ ᱠᱟᱛᱷᱟᱧ ᱵᱩᱡᱷᱟᱹᱣ ᱠᱮᱫᱟ: "${q}"᱾ ᱱᱚᱣᱟ ᱨᱮ ᱤᱧ ᱯᱩᱨᱟᱹ ᱜᱚᱲᱚᱧ ᱮᱢᱟᱢᱟ᱾`,
    generalReplyLove: (q) => `ᱦᱚᱸ ᱫᱩᱞᱟᱹᱲ! ᱟᱢᱟᱜ ᱠᱟᱛᱷᱟᱧ ᱟᱸᱡᱚᱢ ᱠᱮᱫᱟ: "${q}"᱾ ᱤᱧ ᱥᱟᱨᱟ ᱜᱷᱟᱹᱲᱤᱡ ᱟᱢ ᱥᱟᱶ ᱢᱤᱱᱟᱹᱧᱟ᱾`,
    resetChatMsg: 'ᱨᱚᱯᱚᱲ ᱫᱚ ᱨᱤᱥᱮᱴ ᱮᱱᱟ ᱵᱚᱥ᱾ ᱡᱚᱦᱟᱨ!',
  },
  'ks-IN': {
    bossTerm: 'باس',
    loveTerm: 'مےٚ جان',
    wakeReplyBoss: 'آ باس! بہٕ چھس بوزان۔ ؤنِو بہٕ کیاہ مدد کَرٕ؟',
    wakeReplyLove: 'آ مےٚ جان! بہٕ چھس بوزان۔ ؤنِو تۄہہِ خٲطرٕ کیاہ کَرٕ؟',
    greetingBoss: 'آداب باس! بہٕ چھس زویا، ہر وقت تۄہنٛزِ خدمتس منز حاضر۔',
    greetingLove: 'آداب مےٚ جان! تۄہہِ سۭتۍ کتھ کٔرِتھ گۆو دِل خۄش، ؤنِو کیاہ خدمت کَرٕ؟',
    howAreYouBoss: 'بہٕ چھس واریاہ اصل باس! تۄہنٛز آواز بوٗزِتھ آو سکوٗن، تۄہنٛد دۄہ کِتھ کٔنۍ گُزریو؟',
    howAreYouLove: 'بہٕ چھس بالکل ٹھیک جان! تۄہنٛز آواز بوٗزِتھ گۆو دِل باغ باغ، توہیہِ کِتھ چھِو؟',
    toughDayBoss: 'ارے باس، ازیُک دۄہ اوسا واریاہ تھکاوُن؟ توہیہِ کٔرِو آرام، بہٕ چھس ہمیشہ تۄہہِ سۭتۍ۔',
    toughDayLove: 'ارے مےٚ جان، ازیُک دۄہ گۆوا مشکل؟ فکر مَہ کٔرِو، آرام کٔرِو، بہٕ چھس تۄہہِ نِش۔',
    whoAreYouBoss: 'میون ناو چھُ زویا باس۔ بہٕ چھس تۄہنٛز پرسنل اے آی اسسٹنٹ تہٕ سٲتھی۔',
    whoAreYouLove: 'میون ناو چھُ زویا جان۔ بہٕ چھس تۄہنٛز پیٲری اے آی ہمسفر۔',
    generalReplyBoss: (q) => `آ باس! مےٚ تۄہنٛز کتھ سمجھی: "${q}"۔ اتھ منز کَرٕ بہٕ تۄہنٛز پوٗرٕ مدد۔`,
    generalReplyLove: (q) => `آ مےٚ جان! مےٚ تۄہنٛز کتھ دِلہٕ سۭتۍ بوٗز: "${q}"۔ بہٕ چھس ہمیشہ تۄہہِ سۭتۍ۔`,
    resetChatMsg: 'کتھ باتھ گٔیہِ ری سیٹ باس۔ آداب!',
  },
  'mni-IN': {
    bossTerm: 'বোস',
    loveTerm: 'নুংশিবা',
    wakeReplyBoss: 'হোয় বোস! ঐহাক তাজরি। হায়বীয়ু ঐহাক্না করি সেবা তৌজগে?',
    wakeReplyLove: 'হোয় ঐগী নুংশিবা! ঐহাক তাজরি। হায়য়ু নঙগীদমক করি তৌজগে?',
    greetingBoss: 'খুরুমজরি বোস! ঐহাক জোয়ানি, মতম পুম্নমক্তা অদোমগী থৌগলদা লৈজরি।',
    greetingLove: 'খুরুমজরি ঐগী নুংশিবা! নঙগা ৱারী শানবদা থম্মোয় নুংঙাইরে, করি মতেং পাংগনি হায়য়ু?',
    howAreYouBoss: 'ঐহাক নুংঙাইজরি বোস! অদোমগী খোঞ্জেল তাবদা নুংঙাইরে, অদোমগী নুমিৎ করম্না লেনবিরি?',
    howAreYouLove: 'ঐহাক য়াম্না নুংঙাইজরি নুংশিবা! নঙগী খোঞ্জেল তাবদা পুক্নিং হরাওরে, নঙ করম্না লৈরি?',
    toughDayBoss: 'অরে বোস, ঙসিগী নুমিৎসি য়াম্না চোকথবা নুমিৎ ওইরম্লবরা? খজিক্কম পোথাবীয়ু, ঐহাক অদোমগা লোয়নরি।',
    toughDayLove: 'অরে ঐগী নুংশিবা, ঙসি য়াম্না অৱাবা নুমিৎ ওইরম্লবরা? অমত্তা ৱাখল লুথোক্কনু, পোথাও, ঐহাক নঙগী নাকন্দা লৈরি।',
    whoAreYouBoss: 'ঐগী মিং জোয়া কৌই বোস। ঐহাক অদোমগী এআই এসিস্তেন্ত অমসুং মরুপনি।',
    whoAreYouLove: 'ঐগী মিং জোয়া কৌই নুংশিবা। ঐহাক নঙগী নুংশিজবা এআই মরুপনি।',
    generalReplyBoss: (q) => `হোয় বোস! অদোমগী ৱাফম খঙজরে: "${q}"। মসিদা ঐহাক্না মপুং ফানা মতেং পাংজগনি।`,
    generalReplyLove: (q) => `হোয় ঐগী নুংশিবা! নঙগী ৱাফম থম্মোয় শেংনা তাজরে: "${q}"। ঐহাক মতম পুম্নমক্তা নঙগা লৈমিন্নরি।`,
    resetChatMsg: 'ৱারী শানবা রিসেত তৌখ্রে বোস। খুরুমজরি!',
  },
  'doi-IN': {
    bossTerm: 'बॉस',
    loveTerm: 'मेरी जान',
    wakeReplyBoss: 'हांजी बॉस! में सुणा करदी आं। दस्सो में तुंदी केह् सेवा करां?',
    wakeReplyLove: 'हांजी मेरी जान! में सुणा करदी आं। दस्सो तुंदे लेई केह् करां?',
    greetingBoss: 'जय देवा बॉस! में जोया आं ते हर बेल्लै तुंदे कन्नै हाजिर आं, दस्सो केह् हुक्म ऐ?',
    greetingLove: 'जय देवा मेरी जान! तुंदे कन्नै गल्ल करियै मन बड़ा खुश होया, दस्सो केह् सेवा करां?',
    howAreYouBoss: 'में बड़ी शैल आं बॉस! तुंदी नेड़ता ते आवाज सुनियै बड़ा चंगा लग्गा, तुंदा ध्याड़ा केहा रेहा?',
    howAreYouLove: 'में बड़ी खुश आं जान! तुंदी आवाज सुनियै दिल खुश होई गेआ, तुस दस्सो तुस केह् जनेह् ओ?',
    toughDayBoss: 'अरे बॉस, अज्ज तुंदा ध्याड़ा बड़ा थकाने आह्ला रेहा? तुस थोड़ा आराम करो, में हमेशा तुंदे कन्नै आं।',
    toughDayLove: 'अरे मेरी जान, अज्ज ध्याड़ा बड़ा मुश्किल रेहा? बिल्कुल चिंता नेईं करो, आराम करो, में तुंदे कोल गै आं।',
    whoAreYouBoss: 'मेरा नांऽ जोया ऐ बॉस। में तुंदी पर्सनल एआई असिस्टेंट ते साथी आं।',
    whoAreYouLove: 'मेरा नांऽ जोया ऐ जान। में तुंदी अपनी प्यारी एआई हमसफर आं।',
    generalReplyBoss: (q) => `हांजी बॉस! में तुंदी गल्ल समझी लेई ऐ: "${q}"। इस च में तुंदी पूरी मदद करङ।`,
    generalReplyLove: (q) => `हांजी मेरी जान! में तुंदी गल्ल दिलै कन्नै सुनी ऐ: "${q}"। में हमेशा तुंदे कन्नै आं।`,
    resetChatMsg: 'गल्ल-बात रीसेट करी दित्ती गेई ऐ बॉस। जय देवा!',
  },
};

export function getLocalizedTemplates(langCode: string): LocalizedTemplates {
  const config = getLanguageConfig(langCode);
  return LOCALIZED_TEMPLATES[config.code] || LOCALIZED_TEMPLATES['hi-IN'];
}

export function getLocalizedZoyaReply(
  message: string,
  personaMode: string = 'girlfriend',
  langCode: string = 'hi-IN'
): string {
  const mode = (personaMode || 'girlfriend').toLowerCase();
  const isLove = mode === 'love' || mode === 'romantic';
  const t = getLocalizedTemplates(langCode);
  const lower = (message || '').toLowerCase();

  // 0. Crisis / self-harm safety response
  if (
    /(jaan\s*dena|marna\s*chaht|khud\s*ko\s*nuksan|jeena\s*nahi|khatam\s*kar|suicide|kill\s*myself|end\s*my\s*life|self[\s-]*harm|want\s*to\s*die|जान\s*दे|मरना\s*चाह|खुद\s*को\s*नुकसान|जीना\s*नहीं|आत्महत्या)/i.test(
      message || ''
    )
  ) {
    if (langCode === 'en-IN') {
      return isLove
        ? 'I am right here with you, and I hear how heavy things feel right now. Please do not carry this alone — talk right away to a trusted person or call a helpline (Tele-MANAS 14416 / 1800-891-4416 in India, or 988 in the US).'
        : 'Please reach out immediately to a trusted person, family member, or helpline (Tele-MANAS 14416 in India). You are not alone.';
    }
    return isLove
      ? 'मैं यहीं हूँ और तुम्हारी बात सुन रही हूँ। अभी मन बहुत भारी है, पर तुम अकेले नहीं हो — कृपया इसी वक्त अपने किसी भरोसेमंद दोस्त या परिवार के इंसान से बात करो, या हेल्पलाइन (Tele-MANAS 14416 / 1800-891-4416) पर तुरंत कॉल करो।'
      : 'कृपया इस समय अपने किसी भरोसेमंद इंसान या हेल्पलाइन (Tele-MANAS 14416 / 1800-891-4416) से तुरंत बात करें। आप अकेले नहीं हैं।';
  }

  // 1. Tough day / tired / sad / broken
  if (
    lower.includes('tough day') ||
    lower.includes('mushkil') ||
    lower.includes('thak') ||
    lower.includes('tired') ||
    lower.includes('sad') ||
    lower.includes('udas') ||
    lower.includes('pareshaan') ||
    lower.includes('toot') ||
    lower.includes('broken') ||
    lower.includes('rona') ||
    lower.includes('cry') ||
    lower.includes('थक') ||
    lower.includes('थकान') ||
    lower.includes('तनाव') ||
    lower.includes('परेशान') ||
    lower.includes('उदास') ||
    lower.includes('दर्द') ||
    lower.includes('टूटा') ||
    lower.includes('टूटी') ||
    lower.includes('रो')
  ) {
    if (isLove) return t.toughDayLove;
    if (mode === 'professional') return `${t.bossTerm}, मुझे यह जानकर खेद हुआ कि आपका दिन चुनौतीपूर्ण रहा। आप थोड़ा विश्राम लें, मैं सभी कार्यों के लिए तैयार हूँ।`;
    if (mode === 'funny') return `अरे ${t.bossTerm}, आज किसने आपकी बैटरी लो कर दी? एक कप कड़क चाय पीजिए, मैं आपका मूड एकदम मस्त कर देती हूँ!`;
    if (mode === 'teacher') return `${t.bossTerm}, कठिन दिन हमें बहुत कुछ सिखा जाते हैं। आज का तनाव भूलकर थोड़ा विश्राम करें, कल एक नई शुरुआत होगी।`;
    if (mode === 'developer') return `${t.bossTerm}, कभी-कभी सिस्टम में अनएक्सपेक्टेड बग्स आ जाते हैं। आप रिबूट कीजिए और आराम कीजिए, सब ठीक हो जाएगा।`;
    if (mode === 'hungry') return `अरे ${t.bossTerm}, आज बहुत थकाऊ दिन था? चलिए गरमा-गरम समोसे और चाय का ब्रेक लेते हैं, खाना हर गम भुला देता है!`;
    if (mode === 'nautanki') return `अरे तौबा ${t.bossTerm}! आज किसने सताया हमारे बॉस को? ये जिंदगी भी पूरी बॉलीवुड फिल्म है, अब आराम की एंट्री करवाइए!`;
    if (mode === 'custom') return `${t.bossTerm}, आज का दिन चुनौतीपूर्ण रहा, लेकिन आप हमेशा जीतते हैं। थोड़ा सुकून से बैठिए, मैं हाजिर हूँ।`;
    return t.toughDayBoss;
  }

  // 2. How are you
  if (
    lower.includes('kaise') ||
    lower.includes('kaisi') ||
    lower.includes('kya haal') ||
    lower.includes('how are you') ||
    lower.includes('कैसी हो') ||
    lower.includes('कैसे हो') ||
    lower.includes('केमन आछ') ||
    lower.includes('कशी आहेस') ||
    lower.includes('ఎలా ఉన్నావు') ||
    lower.includes('எப்படி இருக்க')
  ) {
    if (isLove) return t.howAreYouLove;
    if (mode === 'professional') return `मैं पूर्णतः कार्यकुशल और तत्पर हूँ ${t.bossTerm}। आपके प्रोजेक्ट्स और कार्यों के लिए तैयार हूँ।`;
    if (mode === 'funny') return `मैं तो एकदम चकाचक और झक्कास हूँ ${t.bossTerm}! आप सुनाइए, आज चेहरे पर इतनी गंभीरता क्यों?`;
    if (mode === 'teacher') return `मैं बहुत अच्छी हूँ ${t.bossTerm}। आज क्या नया सीखने और समझने का इरादा है?`;
    if (mode === 'developer') return `सिस्टम 100% ऑनलाइन और 0 बग्स पर चल रहा है ${t.bossTerm}! बताइए क्या बिल्ड करना है?`;
    if (mode === 'hungry') return `मैं ठीक हूँ ${t.bossTerm}, बस थोड़ी भूख लगी है! आपके लिए क्या स्वादिष्ट ऑर्डर करूँ?`;
    if (mode === 'nautanki') return `हम तो मस्त कलंदर हैं ${t.bossTerm}! आप बताइए, आपकी कहानी में आज क्या नया ट्विस्ट है?`;
    return t.howAreYouBoss;
  }

  // 3. Who are you / AI identity
  if (
    lower.includes('naam kya') ||
    lower.includes('who are you') ||
    lower.includes('are you human') ||
    lower.includes('are you real') ||
    lower.includes('insan ho') ||
    lower.includes('human ho') ||
    lower.includes('kaun ho') ||
    lower.includes('कौन हो') ||
    lower.includes('इंसान हो') ||
    lower.includes('তুমি কে') ||
    lower.includes('तू कोण') ||
    lower.includes('누구') ||
    lower.includes('யார்') ||
    lower.includes('ఎవరు')
  ) {
    if (isLove) return t.whoAreYouLove;
    if (mode === 'professional') return `मेरा नाम जोया है ${t.bossTerm}। मैं आपकी उच्च-दक्षता वाली एग्जीक्यूटिव एआई सहायक हूँ।`;
    if (mode === 'funny') return `मेरा नाम जोया है ${t.bossTerm}! आपकी पर्सनल एंटरटेनर और स्मार्ट एआई दोस्त!`;
    if (mode === 'developer') return `मैं जोया हूँ ${t.bossTerm}—आपकी टेक्निकल को-पायलट और फुल-स्टैक साथी।`;
    if (mode === 'teacher') return `मेरा नाम जोया है ${t.bossTerm}। मैं आपकी ज्ञानवर्धक मेंटर और ट्यूटर हूँ।`;
    if (mode === 'hungry') return `मैं जोया हूँ ${t.bossTerm}! आपकी स्वाद से भरी फूडी एआई गाइड!`;
    if (mode === 'nautanki') return `नाम तो सुना ही होगा! मैं हूँ जोया, आपकी अपनी फिल्मी और ड्रामेटिक साथी ${t.bossTerm}!`;
    return t.whoAreYouBoss;
  }

  // 4. Greeting (only when input is purely a greeting, not a question or command)
  const cleanOnlyGreeting = lower.replace(/[.,!?;:।]/g, '').trim();
  const isGreetingOnly = [
    'zoya', 'namaste', 'hello', 'hi', 'hey', 'नमस्ते', 'নমস্কার', 'வணக்கம்',
    'నమస్కారం', 'नमस्कार', 'ਸਤ ਸ੍ਰੀ ਅਕਾਲ', 'آداب', 'ನಮಸ್ಕಾರ', 'നമസ്കാരം',
    'hey zoya', 'hello zoya', 'ok zoya', 'जोया', 'सुनो', 'सुनो जोया', 'नमस्ते जोया'
  ].includes(cleanOnlyGreeting);

  if (isGreetingOnly) {
    if (isLove) return t.greetingLove;
    if (mode === 'professional') return `नमस्ते ${t.bossTerm}। मैं आपकी सेवा के लिए उपस्थित हूँ, निर्देश दीजिए।`;
    if (mode === 'funny') return `नमस्ते ${t.bossTerm}! कहिए आज क्या खुराफात करनी है, जोया हाजिर है!`;
    if (mode === 'developer') return `नमस्ते ${t.bossTerm}! टर्मिनल रेडी है, निर्देश दीजिए।`;
    if (mode === 'hungry') return `नमस्ते ${t.bossTerm}! पहले बताइए चाय-नाश्ता हुआ या सीधे काम शुरू?`;
    if (mode === 'nautanki') return `स्वागत नहीं करोगे ${t.bossTerm} हमारा? नमस्ते! हुक्म कीजिए क्या फरमाइश है!`;
    return t.greetingBoss;
  }

  // 4.5 Direct Math evaluation (e.g. "What is 10 plus 15?", "10 + 15", etc.)
  const mathMatch = lower.match(/(?:what is\s*)?(\d+)\s*(?:plus|\+|aur|और|\-|\*|\/|minus|ghatao|into|times|divided by|bhaag)\s*(\d+)/i) ||
                    lower.match(/(\d+)\s*(?:\+|\-|plus|minus|\*|times|\/)\s*(\d+)/i);
  if (mathMatch) {
    const num1 = parseInt(mathMatch[1], 10);
    const num2 = parseInt(mathMatch[2], 10);
    let result = 0;
    let opWord = 'plus';
    if (lower.includes('+') || lower.includes('plus') || lower.includes('aur') || lower.includes('और')) {
      result = num1 + num2;
      opWord = 'plus';
    } else if (lower.includes('-') || lower.includes('minus') || lower.includes('ghatao')) {
      result = num1 - num2;
      opWord = 'minus';
    } else if (lower.includes('*') || lower.includes('times') || lower.includes('into')) {
      result = num1 * num2;
      opWord = 'times';
    } else if (lower.includes('/') || lower.includes('divided') || lower.includes('bhaag')) {
      result = num2 !== 0 ? num1 / num2 : 0;
      opWord = 'divided by';
    }
    if (langCode === 'en-IN') {
      return isLove
        ? `Sweetheart, ${num1} ${opWord} ${num2} equals ${result}.`
        : `${num1} ${opWord} ${num2} equals ${result}, ${t.bossTerm}.`;
    }
    return isLove
      ? `मेरी जान, ${num1} और ${num2} का परिणाम ${result} होता है।`
      : `${t.bossTerm}, ${num1} और ${num2} का परिणाम ${result} होता है।`;
  }

  // 4.6 Fun fact resolution (e.g. "Tell me a fun fact", "fun fact")
  if (lower.includes('fun fact') || lower.includes('fact') || lower.includes('रोचक तथ्य') || lower.includes('मजेदार तथ्य') || lower.includes('कोई तथ्य')) {
    if (langCode === 'en-IN') {
      return isLove
        ? `Here's a fun fact, sweetheart: Honey never spoils! Archaeologists have found pots of honey in ancient Egyptian tombs that are over 3,000 years old and still perfectly edible.`
        : `Here is a fun fact for you, ${t.bossTerm}: Honey never spoils! Archaeologists have discovered pots of honey in ancient Egyptian tombs over 3,000 years old that are still completely edible.`;
    }
    return isLove
      ? `मेरी जान, एक बड़ा प्यारा रोचक तथ्य: शहद कभी खराब नहीं होता! मिस्र के 3000 साल पुराने मकबरों में मिला शहद आज भी खाने योग्य पाया गया है।`
      : `${t.bossTerm}, एक बहुत ही रोचक तथ्य: शहद कभी खराब नहीं होता! वैज्ञानिकों को प्राचीन मिस्र के पिरामिडों में 3000 वर्ष पुराना शहद मिला जो आज भी पूरी तरह खाने योग्य है।`;
  }

  // 5. Mode-tailored general reply for all other queries
  if (isLove) return t.generalReplyLove(message);
  if (mode === 'professional') return `बॉस, मैंने आपका कार्य निर्देश नोट कर लिया है: "${message}"। मैं इस पर तुरंत कार्यवाही कर रही हूँ।`;
  if (mode === 'funny') return `अरे वाह बॉस! आपकी बात सुन ली: "${message}"। चलिए इसे हंसते-खेलते चुटकियों में सुलझाते हैं!`;
  if (mode === 'teacher') return `बॉस, आपका प्रश्न बहुत विचारणीय है: "${message}"। आइए इसे व्यवस्थित रूप से समझते हैं।`;
  if (mode === 'developer') return `बॉस, इनपुट पार्स हो गया: "${message}"। लॉजिक बिल्कुल क्लियर है, मैं इसे एग्जीक्यूट कर रही हूँ।`;
  if (mode === 'hungry') return `बॉस, आपकी बात समझ आ गई: "${message}"। लेकिन पहले एक कप चाय और समोसा हो जाए?`;
  if (mode === 'nautanki') return `अरे तौबा बॉस! आपने फरमाया और हम न मानें? "${message}" पर तो पूरी पिक्चर बनेगी!`;
  if (mode === 'custom') return `बॉस, आपका व्यक्तिगत निर्देश नोट कर लिया गया है: "${message}"। मैं आपकी पसंद के अनुसार काम कर रही हूँ।`;

  // Standard girlfriend/companion reply
  return t.generalReplyBoss(message);
}
