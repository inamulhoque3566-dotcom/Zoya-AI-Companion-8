import fs from 'node:fs';
import path from 'node:path';
import {
  DEFAULT_MODE_MEMORIES,
  DEFAULT_MAIN_MEMORIES,
  DEFAULT_PERSONAL_MEMORIES,
  normalizeMemoryText,
  isPersonalPreferenceOrChoice,
  type MemoryItem,
  type MemoryLayer,
  type PersonalMemoryItem,
  type PersonalCategory,
} from './zoyaMemoryEngine.ts';
import { GoogleGenAI, ThinkingLevel } from '@google/genai';

const DATA_DIR = path.join(process.cwd(), 'data');
const MEMORY_FILE_PATH = path.join(DATA_DIR, 'zoya_memories_store.json');
const PERSONAL_MEMORY_FILE_PATH = path.join(DATA_DIR, 'zoya_personal_memories.json');

// In-memory cache for ultra-fast access
let memoryStore: Record<string, MemoryItem[]> = {};
let personalMemoryStore: PersonalMemoryItem[] = [];
let isInitialized = false;

export const ALL_STANDARD_MODES = [
  'girlfriend',
  'assistant',
  'autonomous',
  'creator',
  'love',
  'professional',
  'funny',
  'companion',
  'teacher',
  'developer',
  'hungry',
  'nautanki',
  'custom',
];

/**
 * Initializes the persistent memory store from disk
 */
export function initServerMemoryStore(): void {
  if (isInitialized) return;

  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }

    if (fs.existsSync(MEMORY_FILE_PATH)) {
      const raw = fs.readFileSync(MEMORY_FILE_PATH, 'utf-8');
      const parsed = JSON.parse(raw);
      if (typeof parsed === 'object' && parsed !== null) {
        memoryStore = parsed;
      }
    } else {
      memoryStore = JSON.parse(JSON.stringify(DEFAULT_MODE_MEMORIES));
      fs.writeFileSync(MEMORY_FILE_PATH, JSON.stringify(memoryStore, null, 2), 'utf-8');
    }

    let needsSave = false;
    for (const m of ALL_STANDARD_MODES) {
      if (!Array.isArray(memoryStore[m])) {
        memoryStore[m] = DEFAULT_MODE_MEMORIES[m] ? [...DEFAULT_MODE_MEMORIES[m]] : [];
        needsSave = true;
      } else {
        // Ensure zero cross-mode contamination in stored lists
        const clean = memoryStore[m].filter((item) => !item.mode || item.mode.toLowerCase() === m);
        if (clean.length !== memoryStore[m].length) {
          memoryStore[m] = clean;
          needsSave = true;
        }
      }
    }

    if (!Array.isArray(memoryStore['main_memory']) || memoryStore['main_memory'].length === 0) {
      memoryStore['main_memory'] = JSON.parse(JSON.stringify(DEFAULT_MAIN_MEMORIES));
      needsSave = true;
    }

    if (needsSave) {
      saveStoreToDisk();
    }

    if (fs.existsSync(PERSONAL_MEMORY_FILE_PATH)) {
      try {
        const rawPers = fs.readFileSync(PERSONAL_MEMORY_FILE_PATH, 'utf-8');
        const parsedPers = JSON.parse(rawPers);
        if (Array.isArray(parsedPers) && parsedPers.length > 0) {
          personalMemoryStore = parsedPers;
        } else {
          personalMemoryStore = JSON.parse(JSON.stringify(DEFAULT_PERSONAL_MEMORIES));
          savePersonalStoreToDisk();
        }
      } catch {
        personalMemoryStore = JSON.parse(JSON.stringify(DEFAULT_PERSONAL_MEMORIES));
        savePersonalStoreToDisk();
      }
    } else {
      personalMemoryStore = JSON.parse(JSON.stringify(DEFAULT_PERSONAL_MEMORIES));
      savePersonalStoreToDisk();
    }

    isInitialized = true;
  } catch (err) {
    console.error('[SERVER_MEMORY] Error initializing persistent store:', err);
    memoryStore = JSON.parse(JSON.stringify(DEFAULT_MODE_MEMORIES));
    memoryStore['main_memory'] = JSON.parse(JSON.stringify(DEFAULT_MAIN_MEMORIES));
    personalMemoryStore = JSON.parse(JSON.stringify(DEFAULT_PERSONAL_MEMORIES));
    isInitialized = true;
  }
}

function savePersonalStoreToDisk(): boolean {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    const tempPath = `${PERSONAL_MEMORY_FILE_PATH}.tmp`;
    fs.writeFileSync(tempPath, JSON.stringify(personalMemoryStore, null, 2), 'utf-8');
    fs.renameSync(tempPath, PERSONAL_MEMORY_FILE_PATH);
    return true;
  } catch (err) {
    console.error('[SERVER_MEMORY] Error writing personal store to disk:', err);
    return false;
  }
}

function saveStoreToDisk(): boolean {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    const tempPath = `${MEMORY_FILE_PATH}.tmp`;
    fs.writeFileSync(tempPath, JSON.stringify(memoryStore, null, 2), 'utf-8');
    fs.renameSync(tempPath, MEMORY_FILE_PATH);
    return true;
  } catch (err) {
    console.error('[SERVER_MEMORY] Error writing store to disk:', err);
    return false;
  }
}

export function normalizeMode(mode?: string): string {
  const m = (mode || 'girlfriend').trim().toLowerCase();
  if (m === 'romantic') return 'love';
  if (m === 'friend') return 'companion';
  return m;
}

/**
 * Returns strictly isolated memories for a specific mode
 */
export function getMemoriesForMode(mode: string): MemoryItem[] {
  initServerMemoryStore();
  const cleanMode = normalizeMode(mode);
  const list = memoryStore[cleanMode];
  if (Array.isArray(list)) {
    return list.filter((m) => !m.mode || m.mode.toLowerCase() === cleanMode);
  }
  memoryStore[cleanMode] = [];
  saveStoreToDisk();
  return [];
}

/**
 * Returns all memories across all modes
 */
export function getAllMemoriesGrouped(): Record<string, MemoryItem[]> {
  initServerMemoryStore();
  return JSON.parse(JSON.stringify(memoryStore));
}

/**
 * Saves or updates a memory item for a specific mode.
 * Prevents duplicate records, accidental overwrites, and cross-mode leakage.
 */
export function saveMemoryItem(
  item: Partial<MemoryItem> & { title: string; content: string; mode?: string }
): MemoryItem {
  initServerMemoryStore();
  const cleanMode = normalizeMode(item.mode);
  const existingList = memoryStore[cleanMode] || [];
  const now = new Date().toISOString();

  const normTitle = normalizeMemoryText(item.title);
  const normContent = normalizeMemoryText(item.content);

  let targetItem: MemoryItem;

  if (item.id) {
    const match = existingList.find((m) => m.id === item.id);
    targetItem = {
      id: item.id,
      mode: cleanMode,
      layer: (item.layer as MemoryLayer) || match?.layer || 'long_term',
      title: item.title.trim(),
      content: item.content.trim(),
      keywords: item.keywords || match?.keywords || [],
      pinned: item.pinned !== undefined ? item.pinned : (match?.pinned ?? false),
      importance: item.importance || match?.importance || 3,
      createdAt: match?.createdAt || now,
      updatedAt: now,
      source: item.source || match?.source || 'user_manual',
    };
    memoryStore[cleanMode] = existingList.some((m) => m.id === item.id)
      ? existingList.map((m) => (m.id === item.id ? targetItem : m))
      : [targetItem, ...existingList];
  } else {
    // Check for duplicate title or content within the same mode
    const existingIndex = existingList.findIndex(
      (m) =>
        normalizeMemoryText(m.title) === normTitle ||
        normalizeMemoryText(m.content) === normContent
    );

    if (existingIndex >= 0) {
      const match = existingList[existingIndex];
      const isExplicitCorrection = item.source === 'user_correction' || item.source === 'user_manual';
      targetItem = {
        ...match,
        mode: cleanMode,
        title: item.title.trim(),
        content: item.content.trim(),
        layer: (item.layer as MemoryLayer) || match.layer,
        importance: isExplicitCorrection
          ? item.importance || match.importance
          : Math.max(match.importance, item.importance || 3),
        pinned: isExplicitCorrection
          ? item.pinned !== undefined
            ? item.pinned
            : match.pinned
          : Boolean(match.pinned || item.pinned),
        updatedAt: now,
        source: item.source || 'user_correction',
      };
      existingList[existingIndex] = targetItem;
      memoryStore[cleanMode] = [...existingList];
    } else {
      targetItem = {
        id: `mem-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
        mode: cleanMode,
        layer: (item.layer as MemoryLayer) || 'long_term',
        title: item.title.trim(),
        content: item.content.trim(),
        keywords: item.keywords || [],
        pinned: Boolean(item.pinned),
        importance: item.importance || 3,
        createdAt: now,
        updatedAt: now,
        source: item.source || 'user_manual',
      };
      memoryStore[cleanMode] = [targetItem, ...existingList];
    }
  }

  saveStoreToDisk();
  return targetItem;
}

/**
 * Deletes a memory item by ID
 */
export function deleteMemoryItem(id: string, mode?: string): boolean {
  initServerMemoryStore();
  if (mode) {
    const cleanMode = normalizeMode(mode);
    const existing = memoryStore[cleanMode] || [];
    const filtered = existing.filter((m) => m.id !== id);
    if (filtered.length !== existing.length) {
      memoryStore[cleanMode] = filtered;
      saveStoreToDisk();
      return true;
    }
  } else {
    let found = false;
    for (const m of Object.keys(memoryStore)) {
      const existing = memoryStore[m] || [];
      const filtered = existing.filter((item) => item.id !== id);
      if (filtered.length !== existing.length) {
        memoryStore[m] = filtered;
        found = true;
      }
    }
    if (found) {
      saveStoreToDisk();
      return true;
    }
  }
  return false;
}

/**
 * Returns Central Main Memory items
 */
export function getMainMemories(): MemoryItem[] {
  initServerMemoryStore();
  return memoryStore['main_memory'] ? [...memoryStore['main_memory']] : [];
}

/**
 * Saves or updates an item in Central Main Memory (deduplicated)
 */
export function saveMainMemoryItem(
  item: Partial<MemoryItem> & { title: string; content: string }
): MemoryItem {
  initServerMemoryStore();
  const existing = memoryStore['main_memory'] || [];
  const now = new Date().toISOString();
  const normTitle = normalizeMemoryText(item.title);
  const normContent = normalizeMemoryText(item.content);

  let targetItem: MemoryItem;
  const match = existing.find(
    (m) =>
      (item.id && m.id === item.id) ||
      normalizeMemoryText(m.title) === normTitle ||
      normalizeMemoryText(m.content) === normContent
  );

  if (match) {
    targetItem = {
      id: match.id,
      mode: 'main_memory',
      layer: item.layer || match.layer || 'preference',
      title: item.title.trim(),
      content: item.content.trim(),
      keywords: item.keywords || match.keywords || [],
      pinned: item.pinned !== undefined ? item.pinned : (match.pinned ?? true),
      importance: Math.max(match.importance || 4, item.importance || 4),
      createdAt: match.createdAt || now,
      updatedAt: now,
      source: item.source || match.source || 'pipeline_transfer',
    };
    memoryStore['main_memory'] = [
      targetItem,
      ...existing.filter((m) => m.id !== match.id),
    ];
  } else {
    targetItem = {
      id: item.id || `main-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`,
      mode: 'main_memory',
      layer: item.layer || 'preference',
      title: item.title.trim(),
      content: item.content.trim(),
      keywords: item.keywords || [],
      pinned: item.pinned !== undefined ? item.pinned : true,
      importance: item.importance || 4,
      createdAt: now,
      updatedAt: now,
      source: item.source || 'pipeline_transfer',
    };
    memoryStore['main_memory'] = [targetItem, ...existing];
  }

  saveStoreToDisk();
  return targetItem;
}

/**
 * Deletes item from Central Main Memory
 */
export function deleteMainMemoryItem(id: string): boolean {
  initServerMemoryStore();
  const existing = memoryStore['main_memory'] || [];
  const filtered = existing.filter((m) => m.id !== id);
  if (filtered.length !== existing.length) {
    memoryStore['main_memory'] = filtered;
    saveStoreToDisk();
    return true;
  }
  return false;
}

/**
 * Retrieves Final Personal Memory items (5 categories)
 */
export function getPersonalMemories(category?: PersonalCategory): PersonalMemoryItem[] {
  initServerMemoryStore();
  if (category) {
    return personalMemoryStore.filter((p) => p.category === category);
  }
  return [...personalMemoryStore];
}

/**
 * Saves or updates a Personal Memory item in one of the 5 categories (deduplicated)
 */
export function savePersonalMemoryItem(
  item: Partial<PersonalMemoryItem> & { category: PersonalCategory; title: string; content: string }
): PersonalMemoryItem {
  initServerMemoryStore();
  const now = new Date().toISOString();
  const normTitle = normalizeMemoryText(item.title);
  const normContent = normalizeMemoryText(item.content);

  let target: PersonalMemoryItem;
  const matchIndex = personalMemoryStore.findIndex(
    (p) =>
      (item.id && p.id === item.id) ||
      (p.category === item.category &&
        (normalizeMemoryText(p.title) === normTitle ||
          normalizeMemoryText(p.content) === normContent))
  );

  if (matchIndex >= 0) {
    const match = personalMemoryStore[matchIndex];
    target = {
      ...match,
      category: item.category,
      title: item.title.trim(),
      content: item.content.trim(),
      importance: Math.max(match.importance || 4, item.importance || 4),
      updatedAt: now,
      source: item.source || match.source || 'pipeline_transfer',
      originMode: item.originMode || match.originMode || 'girlfriend',
    };
    personalMemoryStore = [
      target,
      ...personalMemoryStore.filter((_, idx) => idx !== matchIndex),
    ];
  } else {
    target = {
      id: item.id || `pers-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      category: item.category,
      title: item.title.trim(),
      content: item.content.trim(),
      importance: item.importance || 4,
      updatedAt: now,
      source: item.source || 'pipeline_transfer',
      originMode: item.originMode || 'girlfriend',
    };
    personalMemoryStore.unshift(target);
  }

  savePersonalStoreToDisk();
  return target;
}

/**
 * Deletes item from Final Personal Memory
 */
export function deletePersonalMemoryItem(id: string): boolean {
  initServerMemoryStore();
  const filtered = personalMemoryStore.filter((p) => p.id !== id);
  if (filtered.length !== personalMemoryStore.length) {
    personalMemoryStore = filtered;
    savePersonalStoreToDisk();
    return true;
  }
  return false;
}

/**
 * Transfers an eligible memory through the 3D pipeline into Central Main Memory and Final Personal Memory
 */
export function transferMemoryToPipeline(params: {
  sourceMode: string;
  memoryId?: string;
  targetCategory?: PersonalCategory;
  title: string;
  content: string;
  importance?: number;
}): { success: boolean; mainItem: MemoryItem; personalItem: PersonalMemoryItem } {
  initServerMemoryStore();
  const { sourceMode, title, content, importance = 4, targetCategory = 'preferences' } = params;
  const cleanMode = normalizeMode(sourceMode);

  // 1. Save into Central Main Memory
  const mainItem = saveMainMemoryItem({
    title,
    content,
    importance,
    layer: 'preference',
    source: 'pipeline_transfer',
  });

  // 2. Save into Final Personal Memory in target category
  const personalItem = savePersonalMemoryItem({
    category: targetCategory,
    title,
    content,
    importance,
    source: 'pipeline_transfer',
    originMode: cleanMode,
  });

  console.log(
    `[PIPELINE_TRANSFER] Transferred "${title}" from [${cleanMode}] -> [Central Main Memory] -> [Final Personal Memory (${targetCategory})]`
  );

  return { success: true, mainItem, personalItem };
}

/**
 * Server-side 2-Tier Hierarchical Memory Retrieval (Requirement 5):
 * 1. Checks active mode's isolated memory first.
 * 2. If missing, checks Central Main Memory and Final Personal Memory.
 */
export function retrieveMemoryHierarchicalServer(mode: string, query: string): {
  source: 'mode' | 'main' | 'personal' | 'none';
  found: boolean;
  matchedItem?: MemoryItem | PersonalMemoryItem;
  explanation: string;
} {
  initServerMemoryStore();
  const cleanMode = normalizeMode(mode);
  const tokens = (query || '')
    .toLowerCase()
    .replace(/[?,!.;:।]/g, ' ')
    .split(/\s+/)
    .filter((w) => w.length >= 2);

  // Step 1: Check active mode's memory first
  const modeMemories = getMemoriesForMode(cleanMode);
  const modeMatch = modeMemories.find((m) => {
    const t = m.title.toLowerCase();
    const c = m.content.toLowerCase();
    return tokens.some((tok) => t.includes(tok) || c.includes(tok));
  });

  if (modeMatch) {
    return {
      source: 'mode',
      found: true,
      matchedItem: modeMatch,
      explanation: `Found in ${cleanMode} mode isolated memory.`,
    };
  }

  // Step 2A: Check Central Main Memory
  const mainMemories = getMainMemories();
  const mainMatch = mainMemories.find((m) => {
    const t = m.title.toLowerCase();
    const c = m.content.toLowerCase();
    return tokens.some((tok) => t.includes(tok) || c.includes(tok));
  });

  if (mainMatch) {
    return {
      source: 'main',
      found: true,
      matchedItem: mainMatch,
      explanation: `Missing in ${cleanMode} mode; found in Central Main Memory.`,
    };
  }

  // Step 2B: Check Final Personal Memory
  const personalMemories = getPersonalMemories();
  const personalMatch = personalMemories.find((p) => {
    const t = p.title.toLowerCase();
    const c = p.content.toLowerCase();
    return tokens.some((tok) => t.includes(tok) || c.includes(tok));
  });

  if (personalMatch) {
    return {
      source: 'personal',
      found: true,
      matchedItem: personalMatch,
      explanation: `Missing in ${cleanMode} mode; found in Final Personal Memory (${personalMatch.category}).`,
    };
  }

  return {
    source: 'none',
    found: false,
    explanation: `No matching record in ${cleanMode} mode, Central Main Memory, or Final Personal Memory.`,
  };
}

/**
 * Returns comprehensive pipeline stats across all modes, Main Memory, and 5 Personal Memory categories
 */
export function getPipelineFullStats(): {
  status: string;
  modeCounts: Record<string, number>;
  mainCount: number;
  personalCount: number;
  personalByCategory: Record<PersonalCategory, PersonalMemoryItem[]>;
} {
  initServerMemoryStore();
  const modeCounts: Record<string, number> = {};
  for (const m of ALL_STANDARD_MODES) {
    modeCounts[m] = Array.isArray(memoryStore[m]) ? memoryStore[m].length : 0;
  }

  const personalByCategory: Record<PersonalCategory, PersonalMemoryItem[]> = {
    personal_data: personalMemoryStore.filter((p) => p.category === 'personal_data'),
    preferences: personalMemoryStore.filter((p) => p.category === 'preferences'),
    habits: personalMemoryStore.filter((p) => p.category === 'habits'),
    goals: personalMemoryStore.filter((p) => p.category === 'goals'),
    history: personalMemoryStore.filter((p) => p.category === 'history'),
  };

  return {
    status: 'RUNNING',
    modeCounts,
    mainCount: (memoryStore['main_memory'] || []).length,
    personalCount: personalMemoryStore.length,
    personalByCategory,
  };
}

/**
 * Clears all memories for a specific mode
 */
export function clearModeMemories(mode: string): boolean {
  initServerMemoryStore();
  const cleanMode = normalizeMode(mode);
  memoryStore[cleanMode] = [];
  saveStoreToDisk();
  return true;
}

/**
 * Builds formatted system instruction context for Gemini containing:
 * 1. Mode-isolated memories (checked FIRST for mode-specific style and rules).
 * 2. Central Main Memory & Final Personal Memory (checked for user's personal preferences, likes, dislikes, and choices).
 * Prevents duplicate entries and unwanted cross-mode leakage!
 */
export function buildMemorySystemPrompt(mode: string, incomingMemories?: any[]): string {
  initServerMemoryStore();
  const cleanMode = normalizeMode(mode);
  const storeMemories = getMemoriesForMode(cleanMode);

  let modeList = [...storeMemories];
  if (Array.isArray(incomingMemories) && incomingMemories.length > 0) {
    const existingTitles = new Set(modeList.map((m) => normalizeMemoryText(m.title)));
    for (const inc of incomingMemories) {
      if (
        inc &&
        inc.content &&
        (!inc.mode || normalizeMode(inc.mode) === cleanMode) &&
        !existingTitles.has(normalizeMemoryText(inc.title || ''))
      ) {
        modeList.push({
          id: inc.id || `inc-${Date.now()}`,
          mode: cleanMode,
          layer: inc.layer || inc.category || 'long_term',
          title: inc.title || 'Note',
          content: inc.content,
          pinned: Boolean(inc.pinned),
          importance: inc.importance || 3,
          createdAt: inc.createdAt || new Date().toISOString(),
          updatedAt: inc.updatedAt || new Date().toISOString(),
        });
      }
    }
  }

  const layerWeights: Record<string, number> = {
    instruction: 100,
    preference: 80,
    long_term: 60,
    knowledge: 50,
    recurring: 40,
    short_term: 20,
  };

  const sortedMode = [...modeList]
    .sort((a, b) => {
      const scoreA = (a.pinned ? 1000 : 0) + (layerWeights[a.layer] || 30) + (a.importance || 3);
      const scoreB = (b.pinned ? 1000 : 0) + (layerWeights[b.layer] || 30) + (b.importance || 3);
      return scoreB - scoreA;
    })
    .slice(0, 8);

  const modeLines = sortedMode
    .map((m) => {
      const tag = (m.layer || 'LONG_TERM').toUpperCase();
      const star = m.pinned ? '⭐ ' : '';
      return `  - [${tag}] ${star}${m.title}: ${m.content}`;
    })
    .join('\n');

  const mainMemories = getMainMemories().slice(0, 5);
  const personalDataItems = getPersonalMemories().slice(0, 8);

  const mainLines = mainMemories.map((m) => `  - [MAIN_MEMORY] ${m.title}: ${m.content}`).join('\n');
  const personalLines = personalDataItems
    .map((p) => `  - [PERSONAL_${p.category.toUpperCase()}] ${p.title}: ${p.content}`)
    .join('\n');

  let prompt = `\n\n### ZOYA 3D RUNNING MEMORY PIPELINE CONTEXT:\n`;
  prompt += `[TIER 1 - ACTIVE MODE MEMORY (${cleanMode.toUpperCase()} MODE - CHECK FIRST)]:\n`;
  if (sortedMode.length > 0) {
    prompt += `${modeLines}\n`;
  } else {
    prompt += `  (No mode-specific overrides. Follow standard persona tone.)\n`;
  }

  prompt += `\n[TIER 2 - CENTRAL MAIN MEMORY & FINAL PERSONAL MEMORY (CHECK WHEN MISSING IN TIER 1)]:\n`;
  if (mainMemories.length > 0 || personalDataItems.length > 0) {
    if (mainLines) prompt += `${mainLines}\n`;
    if (personalLines) prompt += `${personalLines}\n`;
  } else {
    prompt += `  (User profile defaults apply.)\n`;
  }

  prompt += `\n[MEMORY PIPELINE RULES]:
- Always check Tier 1 (${cleanMode} mode memory) first when answering questions.
- If the requested information is not in Tier 1, check Tier 2 (Central Main Memory and Final Personal Memory).
- Mode-specific instructions and roleplay stay isolated in Tier 1 and never leak across modes.
- User's personal preferences, likes, dislikes, choices, and habits in Tier 2 apply across modes when relevant.`;

  return prompt;
}

/**
 * Evaluates a user interaction and extracts durable memories:
 * - Saves mode-specific information ONLY in the active mode's memory.
 * - Routes genuine personal preferences, likes, dislikes, habits, and choices through Central Main Memory into Final Personal Memory.
 */
export async function extractAndPersistMemory(params: {
  userQuery: string;
  assistantReply?: string;
  personaMode?: string;
  language?: string;
  apiKey?: string;
}): Promise<{
  saved: boolean;
  memory?: MemoryItem;
  pipedToPersonal?: boolean;
  targetCategory?: PersonalCategory;
  reason?: string;
}> {
  const { userQuery, personaMode = 'girlfriend', apiKey } = params;
  const cleanMode = normalizeMode(personaMode);
  const q = userQuery.trim();

  if (q.length < 4) {
    return { saved: false, reason: 'Query too short' };
  }

  const explicitSavePhrases = [
    'याद रखना',
    'याद रखो',
    'याद रहे',
    'याद रख',
    'भूलना मत',
    'नोट कर लो',
    'नोट करो',
    'remember that',
    'remember this',
    'keep in mind',
    "don't forget",
    'note that',
    'mera naam',
    'my name is',
    'call me',
    'mujhe kehna',
    'mujhe bulana',
    'mujhe pasand hai',
    'mujhe napasand hai',
    'my favorite',
    'meri pasand',
    'i prefer',
    'i like',
    'i dislike',
    'i hate',
    'correction',
    'ye galat hai',
    'aise nahi',
    'instead of',
    'rule hai',
    'roj',
    'every day',
    'har din',
    'meri aadat',
    'mera routine',
  ];

  const lowerQ = q.toLowerCase();
  const hasSaveIntent = explicitSavePhrases.some((phrase) => lowerQ.includes(phrase));
  const effectiveKey = apiKey || process.env.GEMINI_API_KEY;

  if (effectiveKey) {
    try {
      const ai = new GoogleGenAI({
        apiKey: effectiveKey,
        httpOptions: { headers: { 'User-Agent': 'aistudio-build' } },
      });

      const extractionPrompt = `Analyze this conversation turn between a user and Zoya AI (${cleanMode} mode).
Determine if the user stated any permanent information, personal preference, like, dislike, choice, routine, rule, correction, or mode-specific fact that should be saved into memory.

User said: "${q}"
${params.assistantReply ? `Assistant replied: "${params.assistantReply}"` : ''}

Output strictly a JSON object with:
{
  "shouldSave": true | false,
  "layer": "short_term" | "long_term" | "preference" | "instruction" | "knowledge" | "recurring",
  "title": "Short title in 2-5 words",
  "content": "Precise statement of the fact, preference or instruction",
  "importance": 1 to 5,
  "isCorrection": true | false,
  "isPersonalPreferenceOrChoice": true | false,
  "personalCategory": "preferences" | "habits" | "personal_data" | "goals" | "history"
}
Rules:
- Set "isPersonalPreferenceOrChoice": true ONLY if the item is a user's personal preference, like, dislike, choice, habit, goal, or personal identity fact (NOT mode-specific roleplay, coding rules, or ordinary conversation).
- If no enduring information was given, set shouldSave to false.`;

      const aiCall = ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: extractionPrompt,
        config: {
          temperature: 0.1,
          responseMimeType: 'application/json',
          thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
        },
      });

      const timeoutPromise = new Promise<null>((resolve) => setTimeout(() => resolve(null), 3000));
      const res: any = await Promise.race([aiCall, timeoutPromise]);

      if (res && res.text) {
        const parsed = JSON.parse(res.text);
        if (parsed.shouldSave && parsed.title && parsed.content) {
          const validLayers: MemoryLayer[] = [
            'short_term',
            'long_term',
            'preference',
            'instruction',
            'knowledge',
            'recurring',
          ];
          const layer: MemoryLayer = validLayers.includes(parsed.layer) ? parsed.layer : 'long_term';

          const saved = saveMemoryItem({
            mode: cleanMode,
            layer,
            title: parsed.title,
            content: parsed.content,
            importance: Math.min(5, Math.max(1, Number(parsed.importance) || 3)),
            pinned: Boolean(parsed.isCorrection || parsed.importance >= 5),
            source: parsed.isCorrection ? 'user_correction' : 'automatic_chat',
          });

          const heuristicCheck = isPersonalPreferenceOrChoice({
            layer,
            title: parsed.title,
            content: parsed.content,
          });
          const shouldPipe = Boolean(parsed.isPersonalPreferenceOrChoice || heuristicCheck.eligible);
          const validCats: PersonalCategory[] = [
            'preferences',
            'habits',
            'personal_data',
            'goals',
            'history',
          ];
          const cat: PersonalCategory = validCats.includes(parsed.personalCategory)
            ? parsed.personalCategory
            : heuristicCheck.targetCategory;

          if (shouldPipe) {
            transferMemoryToPipeline({
              sourceMode: cleanMode,
              memoryId: saved.id,
              title: parsed.title,
              content: parsed.content,
              importance: Math.min(5, Math.max(1, Number(parsed.importance) || 4)),
              targetCategory: cat,
            });
          }

          return {
            saved: true,
            memory: saved,
            pipedToPersonal: shouldPipe,
            targetCategory: cat,
          };
        }
      }
    } catch (aiErr) {
      console.warn('[SERVER_MEMORY] Gemini extraction error, evaluating heuristic:', aiErr);
    }
  }

  if (hasSaveIntent) {
    let cleanContent = q
      .replace(/^(hey|hello|hi|zoya|जोया|नमस्ते जोया|सुनो जोया)\s*[,:]?\s*/i, '')
      .replace(/^(याद रखना|याद रखो|याद रहे|भूलना मत|note that|remember that|remember this)\s*[,:]?\s*/i, '')
      .trim();

    if (!cleanContent) cleanContent = q;

    const isInstruction =
      lowerQ.includes('rule') ||
      lowerQ.includes('correction') ||
      lowerQ.includes('galat') ||
      lowerQ.includes('mat kehna') ||
      lowerQ.includes('kehna');
    const isPreference =
      lowerQ.includes('pasand') ||
      lowerQ.includes('napasand') ||
      lowerQ.includes('favorite') ||
      lowerQ.includes('like') ||
      lowerQ.includes('dislike') ||
      lowerQ.includes('prefer') ||
      lowerQ.includes('पसंद') ||
      lowerQ.includes('नापसंद');
    const isRecurring =
      lowerQ.includes('roj') ||
      lowerQ.includes('every day') ||
      lowerQ.includes('har din') ||
      lowerQ.includes('routine') ||
      lowerQ.includes('आदत');

    const layer: MemoryLayer = isInstruction
      ? 'instruction'
      : isPreference
      ? 'preference'
      : isRecurring
      ? 'recurring'
      : 'long_term';
    const title = cleanContent.split(/[,.!?]/)[0].substring(0, 36) || 'महत्वपूर्ण जानकारी';

    const saved = saveMemoryItem({
      mode: cleanMode,
      layer,
      title,
      content: cleanContent,
      importance: 4,
      pinned: isInstruction || isPreference,
      source: isInstruction ? 'user_correction' : 'automatic_chat',
    });

    const prefCheck = isPersonalPreferenceOrChoice({
      layer,
      title,
      content: cleanContent,
    });

    if (prefCheck.eligible) {
      transferMemoryToPipeline({
        sourceMode: cleanMode,
        memoryId: saved.id,
        title,
        content: cleanContent,
        importance: 4,
        targetCategory: prefCheck.targetCategory,
      });
    }

    return {
      saved: true,
      memory: saved,
      pipedToPersonal: prefCheck.eligible,
      targetCategory: prefCheck.targetCategory,
    };
  }

  return { saved: false, reason: 'No enduring memory intent detected' };
}
