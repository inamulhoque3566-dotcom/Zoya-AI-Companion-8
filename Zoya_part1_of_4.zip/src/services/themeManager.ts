/**
 * Zoya Theme & Look & Feel Manager
 * Provides 8 fully functional themes:
 * - Dark (Default obsidian/deep space)
 * - Light (Clean crisp modern light)
 * - Purple (Royal amethyst neon)
 * - Blue (Deep sapphire cosmic)
 * - Cyan (Teal cyber electric)
 * - Pink (Vibrant rose quartz)
 * - Green (Emerald jade matrix)
 * - Multi-Color (Spectrum aurora gradient)
 * 
 * Supports:
 * - Immediate full-app reactive CSS variables & data-theme injection
 * - Persistent storage across app restarts (localStorage)
 * - Full Reduce Motion toggle (reduces nonessential animations, glowing pulses, rotations while preserving essential loading feedback)
 */

export type AppThemeId = 'dark' | 'light' | 'purple' | 'blue' | 'cyan' | 'pink' | 'green' | 'multi';

export interface AppThemeConfig {
  id: AppThemeId;
  name: string;
  nativeName: string;
  desc: string;
  previewColors: string[];
  vars: {
    '--theme-bg': string;
    '--theme-bg-gradient': string;
    '--theme-card-bg': string;
    '--theme-card-hover': string;
    '--theme-border': string;
    '--theme-border-active': string;
    '--theme-accent': string;
    '--theme-accent-text': string;
    '--theme-accent-glow': string;
    '--theme-text-primary': string;
    '--theme-text-secondary': string;
    '--theme-header-bg': string;
    '--theme-input-bg': string;
    '--theme-drawer-bg': string;
  };
}

export const APP_THEMES: Record<AppThemeId, AppThemeConfig> = {
  dark: {
    id: 'dark',
    name: 'Dark',
    nativeName: 'डार्क (मूल)',
    desc: 'Deep space obsidian with purple & cyan neon accents.',
    previewColors: ['#030718', '#13112c', '#7c4dff', '#06b6d4'],
    vars: {
      '--theme-bg': '#030718',
      '--theme-bg-gradient': 'linear-gradient(180deg, #030718 0%, #070d24 50%, #020512 100%)',
      '--theme-card-bg': '#13112c',
      '--theme-card-hover': '#1c183d',
      '--theme-border': '#3d2970',
      '--theme-border-active': '#7c4dff',
      '--theme-accent': '#7c4dff',
      '--theme-accent-text': '#9d6eff',
      '--theme-accent-glow': 'rgba(124, 77, 255, 0.35)',
      '--theme-text-primary': '#ffffff',
      '--theme-text-secondary': '#94a3b8',
      '--theme-header-bg': 'rgba(19, 17, 44, 0.92)',
      '--theme-input-bg': 'rgba(9, 9, 19, 0.95)',
      '--theme-drawer-bg': '#090913',
    },
  },
  light: {
    id: 'light',
    name: 'Light',
    nativeName: 'लाइट (उज्ज्वल)',
    desc: 'Clean, crisp modern light surface with rich indigo accents.',
    previewColors: ['#f8fafc', '#ffffff', '#6366f1', '#0ea5e9'],
    vars: {
      '--theme-bg': '#f8fafc',
      '--theme-bg-gradient': 'linear-gradient(180deg, #f8fafc 0%, #f1f5f9 50%, #e2e8f0 100%)',
      '--theme-card-bg': '#ffffff',
      '--theme-card-hover': '#f1f5f9',
      '--theme-border': '#cbd5e1',
      '--theme-border-active': '#6366f1',
      '--theme-accent': '#6366f1',
      '--theme-accent-text': '#4f46e5',
      '--theme-accent-glow': 'rgba(99, 102, 241, 0.25)',
      '--theme-text-primary': '#0f172a',
      '--theme-text-secondary': '#475569',
      '--theme-header-bg': 'rgba(255, 255, 255, 0.94)',
      '--theme-input-bg': '#ffffff',
      '--theme-drawer-bg': '#f8fafc',
    },
  },
  purple: {
    id: 'purple',
    name: 'Purple',
    nativeName: 'पर्पल (शाही बैंगनी)',
    desc: 'Royal amethyst & vibrant violet glows.',
    previewColors: ['#0e0724', '#1f1147', '#a855f7', '#d946ef'],
    vars: {
      '--theme-bg': '#0e0724',
      '--theme-bg-gradient': 'linear-gradient(180deg, #0e0724 0%, #1a0c40 50%, #0a041c 100%)',
      '--theme-card-bg': '#1f1147',
      '--theme-card-hover': '#2d1863',
      '--theme-border': '#6b21a8',
      '--theme-border-active': '#a855f7',
      '--theme-accent': '#a855f7',
      '--theme-accent-text': '#c084fc',
      '--theme-accent-glow': 'rgba(168, 85, 247, 0.4)',
      '--theme-text-primary': '#ffffff',
      '--theme-text-secondary': '#d8b4fe',
      '--theme-header-bg': 'rgba(31, 17, 71, 0.92)',
      '--theme-input-bg': 'rgba(14, 7, 36, 0.95)',
      '--theme-drawer-bg': '#0e0724',
    },
  },
  blue: {
    id: 'blue',
    name: 'Blue',
    nativeName: 'ब्लू (नीलम)',
    desc: 'Deep cosmic ocean & sapphire electric radiance.',
    previewColors: ['#030f24', '#0c234a', '#3b82f6', '#38bdf8'],
    vars: {
      '--theme-bg': '#030f24',
      '--theme-bg-gradient': 'linear-gradient(180deg, #030f24 0%, #07193b 50%, #020917 100%)',
      '--theme-card-bg': '#0c234a',
      '--theme-card-hover': '#13356e',
      '--theme-border': '#1d4ed8',
      '--theme-border-active': '#3b82f6',
      '--theme-accent': '#3b82f6',
      '--theme-accent-text': '#60a5fa',
      '--theme-accent-glow': 'rgba(59, 130, 246, 0.4)',
      '--theme-text-primary': '#ffffff',
      '--theme-text-secondary': '#93c5fd',
      '--theme-header-bg': 'rgba(12, 35, 74, 0.92)',
      '--theme-input-bg': 'rgba(3, 15, 36, 0.95)',
      '--theme-drawer-bg': '#030f24',
    },
  },
  cyan: {
    id: 'cyan',
    name: 'Cyan',
    nativeName: 'सियान (साइबर टील)',
    desc: 'Cyberpunk teal & energetic aqua neon streams.',
    previewColors: ['#02181c', '#08333b', '#06b6d4', '#22d3ee'],
    vars: {
      '--theme-bg': '#02181c',
      '--theme-bg-gradient': 'linear-gradient(180deg, #02181c 0%, #04282e 50%, #011014 100%)',
      '--theme-card-bg': '#08333b',
      '--theme-card-hover': '#0e4954',
      '--theme-border': '#0e7490',
      '--theme-border-active': '#06b6d4',
      '--theme-accent': '#06b6d4',
      '--theme-accent-text': '#22d3ee',
      '--theme-accent-glow': 'rgba(6, 182, 212, 0.4)',
      '--theme-text-primary': '#ffffff',
      '--theme-text-secondary': '#67e8f9',
      '--theme-header-bg': 'rgba(8, 51, 59, 0.92)',
      '--theme-input-bg': 'rgba(2, 24, 28, 0.95)',
      '--theme-drawer-bg': '#02181c',
    },
  },
  pink: {
    id: 'pink',
    name: 'Pink',
    nativeName: 'पिंक (गुलाबी मैजेंटा)',
    desc: 'Vibrant rose quartz & romantic neon magenta.',
    previewColors: ['#1c0515', '#3d0c2e', '#ec4899', '#f472b6'],
    vars: {
      '--theme-bg': '#1c0515',
      '--theme-bg-gradient': 'linear-gradient(180deg, #1c0515 0%, #2c0821 50%, #14030f 100%)',
      '--theme-card-bg': '#3d0c2e',
      '--theme-card-hover': '#571342',
      '--theme-border': '#be185d',
      '--theme-border-active': '#ec4899',
      '--theme-accent': '#ec4899',
      '--theme-accent-text': '#f472b6',
      '--theme-accent-glow': 'rgba(236, 72, 153, 0.4)',
      '--theme-text-primary': '#ffffff',
      '--theme-text-secondary': '#f472b6',
      '--theme-header-bg': 'rgba(61, 12, 46, 0.92)',
      '--theme-input-bg': 'rgba(28, 5, 21, 0.95)',
      '--theme-drawer-bg': '#1c0515',
    },
  },
  green: {
    id: 'green',
    name: 'Green',
    nativeName: 'ग्रीन (पन्ना जेड)',
    desc: 'Emerald matrix & jade organic luminescence.',
    previewColors: ['#03170e', '#0a3822', '#10b981', '#34d399'],
    vars: {
      '--theme-bg': '#03170e',
      '--theme-bg-gradient': 'linear-gradient(180deg, #03170e 0%, #062919 50%, #02100a 100%)',
      '--theme-card-bg': '#0a3822',
      '--theme-card-hover': '#0f4f31',
      '--theme-border': '#047857',
      '--theme-border-active': '#10b981',
      '--theme-accent': '#10b981',
      '--theme-accent-text': '#34d399',
      '--theme-accent-glow': 'rgba(16, 185, 129, 0.4)',
      '--theme-text-primary': '#ffffff',
      '--theme-text-secondary': '#6ee7b7',
      '--theme-header-bg': 'rgba(10, 56, 34, 0.92)',
      '--theme-input-bg': 'rgba(3, 23, 14, 0.95)',
      '--theme-drawer-bg': '#03170e',
    },
  },
  multi: {
    id: 'multi',
    name: 'Multi-Color',
    nativeName: 'मल्टी-कलर (इंद्रधनुष)',
    desc: 'Cosmic spectrum gradient with chromatic aurora shimmer.',
    previewColors: ['#08071e', '#17123d', '#ec4899', '#06b6d4'],
    vars: {
      '--theme-bg': '#08071e',
      '--theme-bg-gradient': 'linear-gradient(135deg, #0b0826 0%, #160a36 35%, #051630 70%, #041026 100%)',
      '--theme-card-bg': '#17123d',
      '--theme-card-hover': '#231b5c',
      '--theme-border': '#7c3aed',
      '--theme-border-active': '#06b6d4',
      '--theme-accent': '#8b5cf6',
      '--theme-accent-text': '#c084fc',
      '--theme-accent-glow': 'rgba(236, 72, 153, 0.35)',
      '--theme-text-primary': '#ffffff',
      '--theme-text-secondary': '#cbd5e1',
      '--theme-header-bg': 'rgba(23, 18, 61, 0.92)',
      '--theme-input-bg': 'rgba(8, 7, 30, 0.95)',
      '--theme-drawer-bg': '#08071e',
    },
  },
};

class ThemeManager {
  private currentTheme: AppThemeId = 'dark';
  private reduceMotion: boolean = false;

  constructor() {
    this.init();
  }

  private init() {
    if (typeof window === 'undefined') return;

    try {
      const savedTheme = localStorage.getItem('zoya_app_theme') as AppThemeId | null;
      if (savedTheme && APP_THEMES[savedTheme]) {
        this.currentTheme = savedTheme;
      }
    } catch {}

    try {
      const savedMotion = localStorage.getItem('zoya_reduce_motion');
      if (savedMotion !== null) {
        this.reduceMotion = savedMotion === 'true';
      }
    } catch {}

    this.applyToDOM();
  }

  public getTheme(): AppThemeId {
    return this.currentTheme;
  }

  public getThemeConfig(id: AppThemeId = this.currentTheme): AppThemeConfig {
    return APP_THEMES[id] || APP_THEMES.dark;
  }

  public setTheme(id: AppThemeId): void {
    if (!APP_THEMES[id]) return;
    this.currentTheme = id;
    try {
      localStorage.setItem('zoya_app_theme', id);
    } catch {}
    this.applyToDOM();
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('zoya-theme-changed', { detail: { theme: id } }));
    }
  }

  public isReduceMotion(): boolean {
    return this.reduceMotion;
  }

  public setReduceMotion(enabled: boolean): void {
    this.reduceMotion = enabled;
    try {
      localStorage.setItem('zoya_reduce_motion', String(enabled));
    } catch {}
    this.applyToDOM();
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('zoya-motion-changed', { detail: { reduceMotion: enabled } }));
    }
  }

  private applyToDOM(): void {
    if (typeof document === 'undefined') return;

    const root = document.documentElement;
    const config = this.getThemeConfig();

    // 1. Set theme data attribute
    root.setAttribute('data-theme', config.id);

    // 2. Apply CSS variables
    for (const [key, val] of Object.entries(config.vars)) {
      root.style.setProperty(key, val);
    }

    // 3. Set reduce-motion attribute
    root.setAttribute('data-reduce-motion', this.reduceMotion ? 'true' : 'false');
  }
}

export const themeManager = new ThemeManager();
