/**
 * Android Accessibility & Device Control Service
 * Integrates Web <-> Android Accessibility Bridge (com.openclaw.assistant.bridge.accessibility.AgentVoiceAccessibilityService)
 * 
 * Supports:
 * - Opening installed Android apps across the system
 * - Reading visible screen text & identifying interactive UI elements
 * - Clicking buttons and elements by text, ID, or coordinates
 * - Scrolling (up, down, forward, backward)
 * - Swiping and system gestures
 * - Typing text into focused fields (with strict password/PIN/OTP protection)
 * - System navigation (Back, Home, Recents, Notifications, Quick Settings, Screenshot)
 * - Direct voice command parsing and automation
 */

export interface AccessibilityNode {
  id: string;
  text: string;
  desc: string;
  class: string;
  clickable: boolean;
  bounds: string;
}

export interface ScreenState {
  packageName: string;
  nodesCount: number;
  nodes: AccessibilityNode[];
  timestamp: number;
}

export interface AccessibilityStatus {
  isAvailable: boolean;
  isAuthorized: boolean;
  isRunning: boolean;
  isNativeApk: boolean;
  serviceName: string;
  package: string;
  hasGestureSupport: boolean;
  hasWindowContentRetrieval: boolean;
  hasAppLaunchSupport: boolean;
  hasGlobalActionSupport: boolean;
  securityPolicy: {
    passwordProtection: boolean;
    bankingExclusion: boolean;
    manualUserAuthRequired: boolean;
  };
}

export interface AccessibilityBridgeStatus {
  bridgeAvailable: boolean;
  serviceConnected: boolean;
  serviceEnabledInSettings: boolean;
  currentPackage: string;
  sdkInt: number;
  lockScreenSupported: boolean;
  isDeviceLocked: boolean;
  isDeviceSecure: boolean;
}

export interface ActionResult {
  success: boolean;
  action: string;
  message: string;
  data?: any;
  error?: string;
  code?: string;
}

import { deviceSecurity } from './deviceSecurity';
import {
  BLOCKED_BANKING_PACKAGES,
  isPackageBlocked as isBankingPackageBlocked,
  isBrowserPackage,
  isBrowserHostBlocked,
  evaluateDeviceActionSafety,
  SAFETY_BLOCKED_MESSAGE,
} from './bankingSafetyConfig';

function getSafeStorage(key: string, defaultValue: string = ''): string {
  try {
    if (typeof localStorage !== 'undefined') {
      return localStorage.getItem(key) ?? defaultValue;
    }
  } catch {}
  return defaultValue;
}

function setSafeStorage(key: string, value: string): void {
  try {
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem(key, value);
    }
  } catch {}
}

class AndroidAccessibilityService {
  private simulatedScreen: ScreenState = {
    packageName: 'com.openclaw.assistant',
    nodesCount: 14,
    timestamp: Date.now(),
    nodes: [
      { id: 'w0:1', text: 'Zoya AI Assistant', desc: 'App Title Header', class: 'android.widget.TextView', clickable: false, bounds: '32,48,450,110' },
      { id: 'w0:2', text: 'Tap to Talk', desc: 'Main Voice Interaction Button', class: 'android.widget.Button', clickable: true, bounds: '360,780,664,1084' },
      { id: 'w0:3', text: 'Settings', desc: 'Open Settings Menu', class: 'android.widget.ImageButton', clickable: true, bounds: '912,48,992,128' },
      { id: 'w0:4', text: 'Menu', desc: 'Open Navigation Drawer', class: 'android.widget.ImageButton', clickable: true, bounds: '32,48,112,128' },
      { id: 'w0:5', text: 'Ask me anything...', desc: 'Text Query Input Box', class: 'android.widget.EditText', clickable: true, bounds: '48,1240,840,1320' },
      { id: 'w0:6', text: 'Send', desc: 'Submit Query', class: 'android.widget.Button', clickable: true, bounds: '864,1240,976,1320' },
      { id: 'w0:7', text: 'Chat', desc: 'Instant Answers Card', class: 'android.view.ViewGroup', clickable: true, bounds: '48,1340,320,1460' },
      { id: 'w0:8', text: 'Create Image', desc: 'Photo to Sketch Card', class: 'android.view.ViewGroup', clickable: true, bounds: '352,1340,672,1460' },
      { id: 'w0:9', text: 'Write', desc: 'Notes and Drafts Card', class: 'android.view.ViewGroup', clickable: true, bounds: '704,1340,976,1460' },
      { id: 'w0:10', text: 'Home', desc: 'Bottom Nav Home', class: 'android.widget.TextView', clickable: true, bounds: '60,1470,180,1520' },
      { id: 'w0:11', text: 'History', desc: 'Bottom Nav History', class: 'android.widget.TextView', clickable: true, bounds: '750,1470,860,1520' },
      { id: 'w0:12', text: 'Memory', desc: 'Bottom Nav Memory', class: 'android.widget.TextView', clickable: true, bounds: '880,1470,990,1520' },
    ]
  };

  /**
   * Check if running in native Android APK with bridge injected
   */
  public isNativeEnvironment(): boolean {
    return typeof window !== 'undefined' && 
      typeof window.AndroidBridge !== 'undefined' &&
      typeof window.AndroidBridge.executeAccessibilityAction === 'function';
  }

  /**
   * Query status of Accessibility Service
   */
  public getStatus(): AccessibilityStatus {
    const isNative = this.isNativeEnvironment();
    if (isNative && window.AndroidBridge?.getAccessibilityStatus) {
      try {
        const raw = window.AndroidBridge.getAccessibilityStatus();
        const parsed = JSON.parse(raw);
        return {
          isAvailable: true,
          isAuthorized: parsed.isAuthorized ?? false,
          isRunning: parsed.isRunning ?? false,
          isNativeApk: true,
          serviceName: parsed.serviceName || 'AgentVoiceAccessibilityService',
          package: parsed.package || 'com.openclaw.assistant',
          hasGestureSupport: true,
          hasWindowContentRetrieval: true,
          hasAppLaunchSupport: true,
          hasGlobalActionSupport: true,
          securityPolicy: parsed.securityPolicy || {
            passwordProtection: true,
            bankingExclusion: true,
            manualUserAuthRequired: true
          }
        };
      } catch (e) {
        console.warn('[ACCESSIBILITY] Error parsing native status:', e);
      }
  }

    // Web / Sideload Simulation Sandbox
    const localAuthorized = getSafeStorage('zoya_simulated_accessibility') === 'true';
    return {
      isAvailable: true,
      isAuthorized: localAuthorized,
      isRunning: localAuthorized,
      isNativeApk: false,
      serviceName: 'AgentVoiceAccessibilityService',
      package: 'com.openclaw.assistant',
      hasGestureSupport: true,
      hasWindowContentRetrieval: true,
      hasAppLaunchSupport: true,
      hasGlobalActionSupport: true,
      securityPolicy: {
        passwordProtection: true,
        bankingExclusion: true,
        manualUserAuthRequired: true
      }
    };
  }

  /**
   * Request user to open Android Accessibility Settings
   */
  public openAndroidAccessibilitySettings(): void {
    if (this.isNativeEnvironment() && window.AndroidBridge?.openAccessibilitySettings) {
      window.AndroidBridge.openAccessibilitySettings();
    } else {
      // In web preview, toggle simulation authorization and explain the Android flow
      const current = getSafeStorage('zoya_simulated_accessibility') === 'true';
      setSafeStorage('zoya_simulated_accessibility', (!current).toString());
    }
  }

  /**
   * Compatibility alias for openAndroidAccessibilitySettings
   */
  public openAccessibilitySettings(): boolean {
    this.openAndroidAccessibilitySettings();
    return this.isNativeEnvironment();
  }

  /**
   * Open Android App Info for Android 13+ "Allow restricted settings"
   */
  public openRestrictedSettings(): void {
    if (this.isNativeEnvironment() && window.AndroidBridge?.openRestrictedSettings) {
      window.AndroidBridge.openRestrictedSettings();
    } else {
      console.log('[ACCESSIBILITY] Sideloaded APK Guide: Settings > Apps > Zoya > ⋮ > Allow restricted settings');
    }
  }

  /**
   * Request system to exclude Zoya from battery optimization
   */
  public requestIgnoreBatteryOptimization(): void {
    if (this.isNativeEnvironment() && window.AndroidBridge?.requestIgnoreBatteryOptimization) {
      window.AndroidBridge.requestIgnoreBatteryOptimization();
    } else {
      setSafeStorage('zoya_battery_optimization_ignored', 'true');
    }
  }

  /**
   * Check if battery optimization is ignored
   */
  public isBatteryOptimizationIgnored(): boolean {
    if (this.isNativeEnvironment() && window.AndroidBridge?.isBatteryOptimizationIgnored) {
      try {
        return window.AndroidBridge.isBatteryOptimizationIgnored();
      } catch {
        return false;
      }
    }
    return getSafeStorage('zoya_battery_optimization_ignored') === 'true';
  }

  /**
   * Banking & UPI Blocklist for Safety
   */
  public getBankingBlocklist(): string[] {
    return Array.from(BLOCKED_BANKING_PACKAGES);
  }

  public isPackageBlocked(pkg: string): boolean {
    return isBankingPackageBlocked(pkg);
  }

  /**
   * Evaluates browser URL for Net Banking protection
   */
  public isBrowserUrlBlocked(url: string): boolean {
    return isBrowserHostBlocked(url).blocked;
  }

  /**
   * Dispatch raw action to Native Bridge or Simulation Engine
   */
  public async executeAction(actionPayload: Record<string, any>): Promise<ActionResult> {
    const isNative = this.isNativeEnvironment();
    const action = actionPayload.action || 'unknown';

    // 1. Strict Security Guard: Prevent any interaction with banking/financial apps or passwords
    const target = (actionPayload.text || actionPayload.app || '').toLowerCase();
    const targetUrl = actionPayload.url || actionPayload.currentUrl || '';

    const safetyCheck = evaluateDeviceActionSafety(target, targetUrl);
    if (!safetyCheck.isSafe) {
      return {
        success: false,
        action,
        message: safetyCheck.reason,
        code: 'SAFETY_BLOCKED_FINANCIAL',
        error: SAFETY_BLOCKED_MESSAGE,
      };
    }

    const isSensitiveKeyword = ['otp', 'cvv', 'card', 'pin', 'mpin', 'password'].some((kw) => target.includes(kw));
    if (isSensitiveKeyword && (action === 'type_text' || action === 'click_text')) {
      return {
        success: false,
        action,
        message: `${SAFETY_BLOCKED_MESSAGE}: Input represents sensitive credential or authentication PIN.`,
        code: 'SAFETY_BLOCKED_CREDENTIAL',
        error: SAFETY_BLOCKED_MESSAGE,
      };
    }

    // 2. Lock & Unlock device operations
    if (action === 'lock_device' || action === 'lock') {
      const lockRes = await deviceSecurity.lockDevice();
      return {
        success: lockRes.success,
        action: 'lock_device',
        message: lockRes.message,
        error: lockRes.error,
        code: lockRes.code
      };
    }

    if (action === 'unlock_device' || action === 'unlock') {
      const unlockRes = await deviceSecurity.requestUnlock();
      return {
        success: unlockRes.success,
        action: 'unlock_device',
        message: unlockRes.message,
        error: unlockRes.error,
        code: unlockRes.code
      };
    }

    // 3. Route to Native Bridge if in APK
    if (isNative && window.AndroidBridge?.executeAccessibilityAction) {
      try {
        const rawRes = window.AndroidBridge.executeAccessibilityAction(JSON.stringify(actionPayload));
        const parsed = JSON.parse(rawRes);
        return {
          success: parsed.success ?? false,
          action,
          message: parsed.message || (parsed.success ? 'Action executed' : 'Action failed'),
          data: parsed
        };
      } catch (err: any) {
        return {
          success: false,
          action,
          message: err?.message || 'Native bridge call failed',
          error: 'BRIDGE_ERROR'
        };
      }
    }

    // 3. Web Simulator Mode
    return this.simulateAction(actionPayload);
  }

  /**
   * Web Simulator Execution Handler
   */
  private simulateAction(payload: Record<string, any>): ActionResult {
    const action = payload.action;

    switch (action) {
      case 'read_screen':
        return {
          success: true,
          action,
          message: `Scanned screen: ${this.simulatedScreen.nodes.length} interactive UI elements detected across current view.`,
          data: { ...this.simulatedScreen, timestamp: Date.now() }
        };

      case 'open_app': {
        const app = payload.app || 'App';
        return {
          success: true,
          action,
          message: `Launched application: ${app} (Intent android.intent.action.MAIN dispatched)`,
          data: { app, launched: true }
        };
      }

      case 'click_text': {
        const text = payload.text || '';
        const found = this.simulatedScreen.nodes.find(n => 
          n.text.toLowerCase().includes(text.toLowerCase()) || 
          n.desc.toLowerCase().includes(text.toLowerCase())
        );
        if (found) {
          return {
            success: true,
            action,
            message: `Clicked element "${found.text}" [${found.class}] at coordinates (${found.bounds})`,
            data: { node: found }
          };
        }
        return {
          success: false,
          action,
          message: `UI element with text "${text}" was not visible on the current screen.`,
        };
      }

      case 'scroll': {
        const dir = payload.direction || 'down';
        return {
          success: true,
          action,
          message: `Dispatched continuous swipe gesture to scroll ${dir.toUpperCase()} (Duration: 350ms).`,
          data: { direction: dir }
        };
      }

      case 'swipe': {
        return {
          success: true,
          action,
          message: `Dispatched gesture swipe from (${payload.x1}, ${payload.y1}) to (${payload.x2}, ${payload.y2}).`,
          data: payload
        };
      }

      case 'type_text': {
        const text = payload.text || '';
        return {
          success: true,
          action,
          message: `Dispatched ACTION_SET_TEXT: typed "${text}" into currently focused input.`,
          data: { typed: text }
        };
      }

      case 'global_action': {
        const cmd = payload.command || 'back';
        return {
          success: true,
          action,
          message: `Triggered system-level navigation action: ${cmd.toUpperCase()} (GLOBAL_ACTION_${cmd.toUpperCase()})`,
          data: { command: cmd }
        };
      }

      default:
        return {
          success: true,
          action,
          message: `Accessibility action ${action} executed successfully.`,
          data: payload
        };
    }
  }

  /**
   * Natural Language Voice Command Matcher
   * Translates spoken commands (English & Hindi) into concrete accessibility actions
   */
  public matchVoiceCommand(query: string): { isAccessibilityCommand: boolean; actionPayload?: Record<string, any>; description: string } {
    const q = query.toLowerCase().trim();

    // Normalize punctuation and extra spaces
    const cleanQ = q.replace(/[.,!?;:।\-]/g, ' ').replace(/\s+/g, ' ').trim();

    // Guard against unlock phrases being falsely detected as lock (since 'unlock' contains 'lock' and 'अनलॉक करो' contains 'लॉक करो')
    const hasUnlockIntent = cleanQ.includes('unlock') || cleanQ.includes('अनलॉक');

    // 0. Device Unlock commands evaluated FIRST
    const isUnlockCommand =
      cleanQ === 'unlock' ||
      cleanQ === 'unlock phone' ||
      cleanQ === 'unlock screen' ||
      cleanQ === 'unlock device' ||
      cleanQ.includes('unlock my phone') ||
      cleanQ.includes('unlock the phone') ||
      cleanQ.includes('unlock this phone') ||
      cleanQ.includes('unlock my screen') ||
      cleanQ.includes('unlock the screen') ||
      cleanQ.includes('unlock my device') ||
      cleanQ.includes('unlock the device') ||
      cleanQ.includes('unlock my mobile') ||
      cleanQ.includes('unlock the mobile') ||
      cleanQ.includes('phone unlock karo') ||
      cleanQ.includes('phone unlock kar do') ||
      cleanQ.includes('screen unlock karo') ||
      cleanQ.includes('screen unlock kar do') ||
      cleanQ.includes('mobile unlock karo') ||
      cleanQ.includes('mobile unlock kar do') ||
      cleanQ.includes('unlock kar do') ||
      cleanQ.includes('unlock kardo') ||
      cleanQ.includes('unlock karo') ||
      cleanQ.includes('फोन अनलॉक करो') ||
      cleanQ.includes('फ़ोन अनलॉक करो') ||
      cleanQ.includes('फोन अनलॉक कर दो') ||
      cleanQ.includes('फ़ोन अनलॉक कर दो') ||
      cleanQ.includes('फोन अनलॉक करें') ||
      cleanQ.includes('फ़ोन अनलॉक करें') ||
      cleanQ.includes('स्क्रीन अनलॉक करो') ||
      cleanQ.includes('स्क्रीन अनलॉक कर दो') ||
      cleanQ.includes('स्क्रीन अनलॉक करें') ||
      cleanQ.includes('मोबाइल अनलॉक करो') ||
      cleanQ.includes('मोबाइल अनलॉक कर दो') ||
      cleanQ.includes('मोबाइल अनलॉक करें') ||
      cleanQ.includes('डिवाइस अनलॉक करो') ||
      cleanQ.includes('डिवाइस अनलॉक कर दो') ||
      cleanQ.includes('डिवाइस अनलॉक करें') ||
      cleanQ.includes('अनलॉक करो') ||
      cleanQ.includes('अनलॉक कर दो') ||
      cleanQ.includes('अनलॉक करें');

    if (isUnlockCommand) {
      return {
        isAccessibilityCommand: true,
        actionPayload: { action: 'unlock_device' },
        description: 'Initiating unlock challenge'
      };
    }

    // 0.1 Device Lock commands ("Zoya, lock my phone", "lock the screen", "phone lock karo", "फोन लॉक करो", "फ़ोन लॉक करो")
    const isLockCommand = 
      !hasUnlockIntent && (
        cleanQ === 'lock' ||
        cleanQ === 'lock device' ||
        cleanQ === 'lock phone' ||
        cleanQ === 'lock screen' ||
        cleanQ.includes('lock my phone') ||
        cleanQ.includes('lock the phone') ||
        cleanQ.includes('lock this phone') ||
        cleanQ.includes('lock phone now') ||
        cleanQ.includes('lock my screen') ||
        cleanQ.includes('lock the screen') ||
        cleanQ.includes('lock screen now') ||
        cleanQ.includes('lock my device') ||
        cleanQ.includes('lock the device') ||
        cleanQ.includes('lock this device') ||
        cleanQ.includes('lock device now') ||
        cleanQ.includes('lock my mobile') ||
        cleanQ.includes('lock the mobile') ||
        cleanQ.includes('lock mobile now') ||
        cleanQ.includes('phone lock karo') ||
        cleanQ.includes('phone lock kar do') ||
        cleanQ.includes('phone lock kardo') ||
        cleanQ.includes('phone lock karein') ||
        cleanQ.includes('screen lock karo') ||
        cleanQ.includes('screen lock kar do') ||
        cleanQ.includes('screen lock kardo') ||
        cleanQ.includes('screen lock karein') ||
        cleanQ.includes('mobile lock karo') ||
        cleanQ.includes('mobile lock kar do') ||
        cleanQ.includes('device lock karo') ||
        cleanQ.includes('device lock kar do') ||
        cleanQ.includes('lock kar do') ||
        cleanQ.includes('lock kardo') ||
        cleanQ.includes('lock karo') ||
        cleanQ.includes('फोन लॉक करो') ||
        cleanQ.includes('फ़ोन लॉक करो') ||
        cleanQ.includes('फोन लॉक कर दो') ||
        cleanQ.includes('फ़ोन लॉक कर दो') ||
        cleanQ.includes('फोन लॉक करदें') ||
        cleanQ.includes('फ़ोन लॉक करदें') ||
        cleanQ.includes('फोन लॉक करें') ||
        cleanQ.includes('फ़ोन लॉक करें') ||
        cleanQ.includes('स्क्रीन लॉक करो') ||
        cleanQ.includes('स्क्रीन लॉक कर दो') ||
        cleanQ.includes('स्क्रीन लॉक करें') ||
        cleanQ.includes('मोबाइल लॉक करो') ||
        cleanQ.includes('मोबाइल लॉक कर दो') ||
        cleanQ.includes('मोबाइल लॉक करें') ||
        cleanQ.includes('डिवाइस लॉक करो') ||
        cleanQ.includes('डिवाइस लॉक कर दो') ||
        cleanQ.includes('डिवाइस लॉक करें') ||
        cleanQ.includes('लॉक करो') ||
        cleanQ.includes('लॉक कर दो') ||
        cleanQ.includes('लॉक करें')
      );

    if (isLockCommand) {
      return {
        isAccessibilityCommand: true,
        actionPayload: { action: 'lock_device' },
        description: 'Locking device screen'
      };
    }

    // 1. Open App commands ("Open YouTube", "Open Camera", "Settings खोलो", "कैमरा खोलो", "YouTube चलाओ")
    const openAppMatch = q.match(/(?:open|launch|start|खोलो|शुरू करो)\s+([a-zA-Z0-9\u0900-\u097F\s]+)/i) ||
                         q.match(/([a-zA-Z0-9\u0900-\u097F\s]+)\s+(?:खोलो|चलाओ|खोलें)/i);
    if (openAppMatch) {
      const appName = openAppMatch[1].trim();
      if (appName && !['door', 'gate', 'lock', 'it', 'दरवाजा'].includes(appName)) {
        return {
          isAccessibilityCommand: true,
          actionPayload: { action: 'open_app', app: appName },
          description: `Opening ${appName}`
        };
      }
    }

    // 2. Scroll commands ("Scroll down", "नीचे स्क्रॉल करो", "Scroll up", "ऊपर जाओ")
    if (q.includes('scroll down') || q.includes('नीचे स्क्रॉल') || q.includes('नीचे करो') || q.includes('page down')) {
      return {
        isAccessibilityCommand: true,
        actionPayload: { action: 'scroll', direction: 'down' },
        description: 'Scrolling down'
      };
    }
    if (q.includes('scroll up') || q.includes('ऊपर स्क्रॉल') || q.includes('ऊपर करो') || q.includes('page up')) {
      return {
        isAccessibilityCommand: true,
        actionPayload: { action: 'scroll', direction: 'up' },
        description: 'Scrolling up'
      };
    }

    // 3. Navigation commands (Back, Home, Notifications, Recents, Screenshot)
    if (q === 'go back' || q === 'back' || q.includes('पीछे जाओ') || q.includes('वापस जाओ')) {
      return {
        isAccessibilityCommand: true,
        actionPayload: { action: 'global_action', command: 'back' },
        description: 'Navigating back'
      };
    }
    if (q === 'go home' || q === 'home screen' || q.includes('होम स्क्रीन') || q.includes('होम पर जाओ')) {
      return {
        isAccessibilityCommand: true,
        actionPayload: { action: 'global_action', command: 'home' },
        description: 'Going to Home Screen'
      };
    }
    if (q.includes('notifications') || q.includes('नोटिफिकेशन') || q.includes('notification shade')) {
      return {
        isAccessibilityCommand: true,
        actionPayload: { action: 'global_action', command: 'notifications' },
        description: 'Opening Notifications'
      };
    }
    if (q.includes('recent apps') || q.includes('recents') || q.includes('app switcher') || q.includes('टास्क बार') || q.includes('हाल के ऐप्स')) {
      return {
        isAccessibilityCommand: true,
        actionPayload: { action: 'global_action', command: 'recents' },
        description: 'Opening Recent Apps'
      };
    }
    if (q.includes('take screenshot') || q.includes('screenshot लो') || q.includes('स्क्रीनशॉट') || q.includes('स्क्रीन शॉट')) {
      return {
        isAccessibilityCommand: true,
        actionPayload: { action: 'global_action', command: 'screenshot' },
        description: 'Taking screenshot'
      };
    }

    // 4. Click commands ("Click Next", "Submit पर क्लिक करो", "कैमरा दबाओ", "Tap Send")
    const clickMatch = q.match(/(?:click|tap|press|दबाओ|क्लिक करो)\s+([a-zA-Z0-9\u0900-\u097F\s]+)/i) ||
                       q.match(/([a-zA-Z0-9\u0900-\u097F\s]+)\s+(?:पर क्लिक करो|दबाओ)/i);
    if (clickMatch) {
      const buttonText = clickMatch[1].trim();
      return {
        isAccessibilityCommand: true,
        actionPayload: { action: 'click_text', text: buttonText },
        description: `Clicking "${buttonText}"`
      };
    }

    // 5. Read Screen commands ("Read screen", "स्क्रीन पर क्या है", "What is on my screen")
    if (q.includes('read screen') || q.includes('स्क्रीन पढ़ो') || q.includes('what is on my screen') || q.includes('स्क्रीन पर क्या है') || q.includes('स्क्रीन देखो')) {
      return {
        isAccessibilityCommand: true,
        actionPayload: { action: 'read_screen' },
        description: 'Reading visible screen content'
      };
    }

    // 6. Type text commands ("Type hello world", "लिखो नमस्ते")
    const typeMatch = q.match(/(?:type|write|enter|लिखो|टाइप करो)\s+([a-zA-Z0-9\u0900-\u097F\s]+)/i);
    if (typeMatch) {
      const text = typeMatch[1].trim();
      return {
        isAccessibilityCommand: true,
        actionPayload: { action: 'type_text', text },
        description: `Typing "${text}"`
      };
    }

    // 7. Companion & Listening Control Commands ("stop listening", "return to the app", "listen")
    if (q.includes('stop listening') || q.includes('सुनना बंद करो') || q.includes('स्टॉप लिसनिंग') || q.includes('stop microphone')) {
      return {
        isAccessibilityCommand: true,
        actionPayload: { action: 'stop_listening' },
        description: 'Stopping background listening'
      };
    }

    if (q.includes('return to the app') || q.includes('return to app') || q.includes('ऐप में वापस') || q.includes('वापस ऐप खोलो') || q.includes('open zoya app') || q.includes('back to zoya')) {
      return {
        isAccessibilityCommand: true,
        actionPayload: { action: 'open_app', app: 'Zoya' },
        description: 'Returning to Zoya application'
      };
    }

    return { isAccessibilityCommand: false, description: '' };
  }
}

export const androidAccessibility = new AndroidAccessibilityService();
