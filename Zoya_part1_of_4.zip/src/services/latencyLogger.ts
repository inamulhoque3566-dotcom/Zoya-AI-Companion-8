/**
 * Zoya AI — Voice Assistant Pipeline Optimizer & On-Device Latency Logger
 *
 * Implements Round 5 Item 2:
 * 1. Keep spoken replies short by default (1–2 sentences spoken; long code/websites/docs routed to visual card).
 * 2. Start speech synthesis on the FIRST complete sentence during streaming (`ttfssMs`).
 * 3. Send ONLY the tool schemas relevant to the user's request (`selectRelevantToolSchemas`), avoiding dumping all 42 schemas on simple turns.
 * 4. Route simple conversational requests to the fast model configuration.
 * 5. Record real on-device request stage timestamps (`messageSent`, `firstToken`, `firstSpeech`, `done`) with JSON & CSV export.
 */

export interface ToolSchemaDefinition {
  name: string;
  group: 'A' | 'B' | 'C';
  description: string;
  keywords: string[];
  parameters: Record<string, any>;
}

/**
 * Canonical registry of all 42 active Zoya tools/skills (25 Group A + 8 Group B + 9 Group C)
 * used by the Zoya request pipeline.
 */
export const ALL_ZOYA_TOOL_SCHEMAS: readonly ToolSchemaDefinition[] = [
  // Group A: 25 Skills (Part 1, Part 2&4, Part 5&6, Part 7)
  {
    name: 'artifacts-builder',
    group: 'A',
    description: 'Builds interactive React/HTML calculator, dashboard, and UI artifacts.',
    keywords: ['artifact', 'calculator', 'emi', 'roi', 'interactive widget'],
    parameters: { type: 'OBJECT', properties: { prompt: { type: 'STRING' } } },
  },
  {
    name: 'brand-guidelines',
    group: 'A',
    description: 'Applies official typography and color palette brand guidelines.',
    keywords: ['brand', 'palette', 'guidelines', 'typography', 'color scheme'],
    parameters: { type: 'OBJECT', properties: { preset: { type: 'STRING' } } },
  },
  {
    name: 'canvas-design',
    group: 'A',
    description: 'Generates museum-grade Swiss grid SVG poster designs.',
    keywords: ['poster', 'canvas', 'artwork', 'flyer', 'swiss grid'],
    parameters: { type: 'OBJECT', properties: { theme: { type: 'STRING' } } },
  },
  {
    name: 'changelog-generator',
    group: 'A',
    description: 'Transforms git commit logs into categorized release notes.',
    keywords: ['changelog', 'commits', 'release notes', 'git log'],
    parameters: { type: 'OBJECT', properties: { commits: { type: 'STRING' } } },
  },
  {
    name: 'competitive-ads-extractor',
    group: 'A',
    description: 'Extracts messaging patterns, hooks, and CTAs from competitor ads.',
    keywords: ['competitor ads', 'ad copy', 'marketing hook', 'ad library'],
    parameters: { type: 'OBJECT', properties: { copy: { type: 'STRING' } } },
  },
  {
    name: 'connect-apps',
    group: 'A',
    description: 'Routes actions to external SaaS apps (Gmail, Slack, Notion, GitHub) via Composio.',
    keywords: ['composio', 'connect app', 'gmail', 'notion', 'linear'],
    parameters: { type: 'OBJECT', properties: { app: { type: 'STRING' }, action: { type: 'STRING' } } },
  },
  {
    name: 'content-research-writer',
    group: 'A',
    description: 'Produces structured Hindi/English research outlines and editorial drafts.',
    keywords: ['article', 'blog post', 'research writer', 'essay', 'लेख'],
    parameters: { type: 'OBJECT', properties: { topic: { type: 'STRING' } } },
  },
  {
    name: 'developer-growth-analysis',
    group: 'A',
    description: 'Analyzes engineering velocity, PR cycle times, and skill gaps.',
    keywords: ['developer growth', 'engineering metrics', 'pr velocity', 'code review'],
    parameters: { type: 'OBJECT', properties: { summary: { type: 'STRING' } } },
  },
  {
    name: 'document-skills/docx',
    group: 'A',
    description: 'Formats structured business letters, proposals, and Word/DOCX documents.',
    keywords: ['docx', 'word document', 'formal letter', 'proposal', 'दस्तावेज़'],
    parameters: { type: 'OBJECT', properties: { content: { type: 'STRING' } } },
  },
  {
    name: 'domain-name-brainstormer',
    group: 'A',
    description: 'Brainstorms brandable startup domain names across .com, .ai, .io, .in.',
    keywords: ['domain name', 'website name', 'tld', '.com', '.ai', 'डोमेन'],
    parameters: { type: 'OBJECT', properties: { niche: { type: 'STRING' } } },
  },
  {
    name: 'file-organizer',
    group: 'A',
    description: 'Categorizes messy filenames and downloads into clean directory trees.',
    keywords: ['organize files', 'folder structure', 'clean downloads', 'फ़ाइल'],
    parameters: { type: 'OBJECT', properties: { files: { type: 'STRING' } } },
  },
  {
    name: 'image-enhancer',
    group: 'A',
    description: 'Provides photographic lighting, sharpness, and color grading presets.',
    keywords: ['enhance image', 'upscale', 'color grade', 'photo quality'],
    parameters: { type: 'OBJECT', properties: { imageDesc: { type: 'STRING' } } },
  },
  {
    name: 'internal-comms',
    group: 'A',
    description: 'Drafts executive internal memos, all-hands updates, and incident notices.',
    keywords: ['internal memo', 'company announcement', 'all-hands', 'status update'],
    parameters: { type: 'OBJECT', properties: { announcement: { type: 'STRING' } } },
  },
  {
    name: 'invoice-organizer',
    group: 'A',
    description: 'Extracts vendor, GST/tax, date, and line totals from invoice text.',
    keywords: ['invoice', 'receipt', 'gst', 'billing', 'बिल', 'इनवॉइस'],
    parameters: { type: 'OBJECT', properties: { invoiceText: { type: 'STRING' } } },
  },
  {
    name: 'langsmith-fetch',
    group: 'A',
    description: 'Analyzes LLM execution traces for token usage, latency bottlenecks, and errors.',
    keywords: ['langsmith', 'llm trace', 'token usage', 'trace json'],
    parameters: { type: 'OBJECT', properties: { trace: { type: 'STRING' } } },
  },
  {
    name: 'lead-research-assistant',
    group: 'A',
    description: 'Identifies ICP target accounts, buyer personas, and outreach angles.',
    keywords: ['lead research', 'prospecting', 'b2b leads', 'icp'],
    parameters: { type: 'OBJECT', properties: { product: { type: 'STRING' } } },
  },
  {
    name: 'mcp-builder',
    group: 'A',
    description: 'Generates Model Context Protocol (MCP) server code in TypeScript or Python.',
    keywords: ['mcp server', 'fastmcp', 'model context protocol'],
    parameters: { type: 'OBJECT', properties: { serverName: { type: 'STRING' } } },
  },
  {
    name: 'meeting-insights-analyzer',
    group: 'A',
    description: 'Analyzes meeting transcripts for speaking ratios, action items, and decisions.',
    keywords: ['meeting transcript', 'meeting notes', 'speaking ratio', 'action items'],
    parameters: { type: 'OBJECT', properties: { transcript: { type: 'STRING' } } },
  },
  {
    name: 'raffle-winner-picker',
    group: 'A',
    description: 'Picks verifiable random giveaway winners using CSPRNG.',
    keywords: ['raffle', 'giveaway winner', 'random picker', 'draw winner'],
    parameters: { type: 'OBJECT', properties: { entries: { type: 'STRING' } } },
  },
  {
    name: 'skill-creator',
    group: 'A',
    description: 'Scaffolds a complete SKILL.md specification and trigger rules.',
    keywords: ['create skill', 'skill.md', 'skill creator'],
    parameters: { type: 'OBJECT', properties: { skillName: { type: 'STRING' } } },
  },
  {
    name: 'skill-share',
    group: 'A',
    description: 'Broadcasts skill packages to Slack channels via Incoming Webhook.',
    keywords: ['skill share', 'share to slack', 'slack webhook'],
    parameters: { type: 'OBJECT', properties: { channel: { type: 'STRING' } } },
  },
  {
    name: 'slack-gif-creator',
    group: 'A',
    description: 'Creates animated Slack emoji GIFs with bounce, pulse, and shake physics.',
    keywords: ['slack gif', 'emoji gif', 'animated gif'],
    parameters: { type: 'OBJECT', properties: { text: { type: 'STRING' } } },
  },
  {
    name: 'tailored-resume-generator',
    group: 'A',
    description: 'Tailors resumes to job descriptions with ATS keyword matching.',
    keywords: ['resume', 'cv', 'ats keywords', 'job description'],
    parameters: { type: 'OBJECT', properties: { jobRole: { type: 'STRING' } } },
  },
  {
    name: 'theme-factory',
    group: 'A',
    description: 'Applies curated 10-palette design themes across UI components.',
    keywords: ['theme factory', 'color palette', 'ocean depths'],
    parameters: { type: 'OBJECT', properties: { themeName: { type: 'STRING' } } },
  },
  {
    name: 'twitter-algorithm-optimizer',
    group: 'A',
    description: 'Scores and rewrites tweets for X/Twitter engagement ranking signals.',
    keywords: ['tweet', 'twitter algorithm', 'thread', 'x post'],
    parameters: { type: 'OBJECT', properties: { draft: { type: 'STRING' } } },
  },

  // Group B: 8 Core Action Tools
  {
    name: 'app-launcher-modal',
    group: 'B',
    description: 'Launches installed mobile apps or web deep-links.',
    keywords: ['open app', 'launch', 'खोलो', 'चलाओ'],
    parameters: { type: 'OBJECT', properties: { appName: { type: 'STRING' } } },
  },
  {
    name: 'phone-call-modal',
    group: 'B',
    description: 'Initiates a phone call via tel: dialer URI.',
    keywords: ['call', 'phone', 'dial', 'कॉल', 'फ़ोन मिलाओ'],
    parameters: { type: 'OBJECT', properties: { contact: { type: 'STRING' }, phone: { type: 'STRING' } } },
  },
  {
    name: 'message-composer-modal',
    group: 'B',
    description: 'Opens WhatsApp or SMS composer with prefilled message.',
    keywords: ['whatsapp', 'sms', 'message', 'संदेश', 'मैसेज'],
    parameters: { type: 'OBJECT', properties: { recipient: { type: 'STRING' }, text: { type: 'STRING' } } },
  },
  {
    name: 'website-builder-modal',
    group: 'B',
    description: 'Synthesizes full single-page HTML/Tailwind websites.',
    keywords: ['website', 'webpage', 'landing page', 'वेबसाइट'],
    parameters: { type: 'OBJECT', properties: { prompt: { type: 'STRING' } } },
  },
  {
    name: 'sketch-canvas-modal',
    group: 'B',
    description: 'Opens HTML5 drawing canvas and AI sketch visualizer.',
    keywords: ['sketch', 'draw', 'painting', 'स्केच', 'ड्राइंग'],
    parameters: { type: 'OBJECT', properties: { prompt: { type: 'STRING' } } },
  },
  {
    name: 'youtube-music-controller',
    group: 'B',
    description: 'Searches YouTube Data API v3 for songs and favorite singers.',
    keywords: ['youtube', 'song', 'music', 'singer', 'गाना', 'सिंगर'],
    parameters: { type: 'OBJECT', properties: { query: { type: 'STRING' } } },
  },
  {
    name: 'python-studio-engine',
    group: 'B',
    description: 'Executes Python 3.10 code and generates Android Kotlin/Java apps.',
    keywords: ['python', 'run script', 'android app', 'build apk', 'पायथन'],
    parameters: { type: 'OBJECT', properties: { code: { type: 'STRING' } } },
  },
  {
    name: 'voice-call-engine',
    group: 'B',
    description: 'Starts interactive voice conversation session with Zoya.',
    keywords: ['voice call', 'live talk', 'बातचीत'],
    parameters: { type: 'OBJECT', properties: { mode: { type: 'STRING' } } },
  },

  // Group C: 9 Native Accessibility & Device Control Tools
  {
    name: 'accessibility-global-nav',
    group: 'C',
    description: 'Executes Android global navigation (BACK, HOME, RECENTS, NOTIFICATIONS).',
    keywords: ['go back', 'home screen', 'notifications', 'पीछे जाओ', 'होम'],
    parameters: { type: 'OBJECT', properties: { command: { type: 'STRING' } } },
  },
  {
    name: 'accessibility-scroll',
    group: 'C',
    description: 'Scrolls the active Android screen up, down, left, or right.',
    keywords: ['scroll down', 'scroll up', 'स्क्रॉल', 'नीचे करो', 'ऊपर करो'],
    parameters: { type: 'OBJECT', properties: { direction: { type: 'STRING' } } },
  },
  {
    name: 'accessibility-click-text',
    group: 'C',
    description: 'Clicks a visible UI button or label on the Android screen.',
    keywords: ['click on', 'tap text', 'पर क्लिक करो'],
    parameters: { type: 'OBJECT', properties: { text: { type: 'STRING' } } },
  },
  {
    name: 'accessibility-type-text',
    group: 'C',
    description: 'Types text into the currently focused Android input field.',
    keywords: ['type text', 'write in box', 'टाइप करो'],
    parameters: { type: 'OBJECT', properties: { text: { type: 'STRING' } } },
  },
  {
    name: 'accessibility-tap-xy',
    group: 'C',
    description: 'Dispatches a hardware gesture tap at (x, y) coordinates.',
    keywords: ['tap coordinate', 'touch xy'],
    parameters: { type: 'OBJECT', properties: { x: { type: 'NUMBER' }, y: { type: 'NUMBER' } } },
  },
  {
    name: 'accessibility-swipe',
    group: 'C',
    description: 'Dispatches a swipe gesture across the screen.',
    keywords: ['swipe left', 'swipe right', 'स्वाइप'],
    parameters: { type: 'OBJECT', properties: { startX: { type: 'NUMBER' }, startY: { type: 'NUMBER' } } },
  },
  {
    name: 'accessibility-lock-device',
    group: 'C',
    description: 'Locks the Android device screen via GLOBAL_ACTION_LOCK_SCREEN.',
    keywords: ['lock screen', 'lock phone', 'स्क्रीन लॉक', 'फ़ोन लॉक'],
    parameters: { type: 'OBJECT', properties: { confirm: { type: 'BOOLEAN' } } },
  },
  {
    name: 'accessibility-unlock-device',
    group: 'C',
    description: 'Wakes screen and triggers Android KeyguardManager unlock prompt.',
    keywords: ['unlock phone', 'unlock screen', 'अनलॉक'],
    parameters: { type: 'OBJECT', properties: { confirm: { type: 'BOOLEAN' } } },
  },
  {
    name: 'floating-hologram-overlay',
    group: 'C',
    description: 'Controls the 3D floating holographic companion overlay.',
    keywords: ['hologram', '3d overlay', 'होलोग्राम'],
    parameters: { type: 'OBJECT', properties: { enabled: { type: 'BOOLEAN' } } },
  },
];

/**
 * Selects ONLY the tool schemas relevant to the user's request (max 4 tools).
 * For simple conversational/voice questions, returns 0 tool schemas to eliminate
 * ~3,500 tokens of unnecessary schema processing overhead!
 */
export function selectRelevantToolSchemas(query: string): ToolSchemaDefinition[] {
  const lower = (query || '').toLowerCase();
  if (!lower) return [];

  const matched: Array<{ tool: ToolSchemaDefinition; score: number }> = [];
  for (const tool of ALL_ZOYA_TOOL_SCHEMAS) {
    let score = 0;
    if (lower.includes(tool.name.toLowerCase())) {
      score += 5;
    }
    for (const kw of tool.keywords) {
      if (lower.includes(kw.toLowerCase())) {
        score += 2;
      }
    }
    if (score > 0) {
      matched.push({ tool, score });
    }
  }

  matched.sort((a, b) => b.score - a.score);
  return matched.slice(0, 4).map((m) => m.tool);
}

/**
 * Selects the fast model for simple conversational/voice queries and standard model for complex tasks.
 */
export function selectOptimalModelForRequest(query: string): {
  model: string;
  isSimpleRequest: boolean;
  relevantTools: ToolSchemaDefinition[];
} {
  const relevantTools = selectRelevantToolSchemas(query);
  const wordCount = (query || '').trim().split(/\s+/).length;
  const hasCodeOrLongDocIntent =
    /(?:write code|full website|html|python|kotlin|java|refactor|architecture|analyze transcript|essay)/i.test(
      query
    );

  const isSimpleRequest = relevantTools.length <= 1 && wordCount <= 35 && !hasCodeOrLongDocIntent;
  return {
    model: 'gemini-2.5-flash',
    isSimpleRequest,
    relevantTools,
  };
}

/**
 * Splits an AI response into:
 * 1. `spokenSummary`: A concise 1–2 sentence reply to be spoken aloud by TTS.
 * 2. `cardContent`: The full detailed response (code, HTML, long lists, documents) to display on screen/card without reading raw code or 10-paragraph text aloud!
 */
export function splitVoiceReplyAndVisualCard(fullText: string): {
  spokenSummary: string;
  cardContent: string | null;
  routedToCard: boolean;
} {
  const trimmed = (fullText || '').trim();
  if (!trimmed) {
    return { spokenSummary: '', cardContent: null, routedToCard: false };
  }

  const hasCodeBlock = /```[\s\S]*?```|<!DOCTYPE html>|<html[\s>]/i.test(trimmed);
  const isLongOutput = trimmed.length > 260 || trimmed.split('\n').length > 5;

  if (!hasCodeBlock && !isLongOutput) {
    return {
      spokenSummary: trimmed.replace(/[*#_`]/g, '').trim(),
      cardContent: null,
      routedToCard: false,
    };
  }

  // Strip code blocks before extracting the first 1-2 spoken sentences
  const textWithoutCode = trimmed
    .replace(/```[\s\S]*?```/g, '')
    .replace(/[*#_`]/g, '')
    .replace(/\s+/g, ' ')
    .trim();

  const sentences = textWithoutCode.match(/[^.!?।\n]+[.!?।]+/g) || [textWithoutCode];
  let shortSpoken = sentences.slice(0, 2).join(' ').trim();
  if (!shortSpoken || shortSpoken.length < 8) {
    shortSpoken = 'मैंने पूरा आउटपुट तैयार करके स्क्रीन कार्ड पर दिखा दिया है।';
  } else if (shortSpoken.length > 220) {
    shortSpoken = shortSpoken.slice(0, 215).trim() + '...';
  }

  return {
    spokenSummary: shortSpoken,
    cardContent: trimmed,
    routedToCard: true,
  };
}

/**
 * Extracts the first complete sentence from a streaming text buffer so speech synthesis
 * can start immediately on the first complete sentence.
 */
export function extractFirstCompleteSentence(buffer: string): {
  firstSentence: string | null;
  remaining: string;
} {
  const match = buffer.match(/^([\s\S]+?[।?!.\n]+)(?:\s+|$)([\s\S]*)$/);
  if (!match) {
    return { firstSentence: null, remaining: buffer };
  }
  const clean = match[1].replace(/[*#_`]/g, '').trim();
  if (clean.length < 4) {
    return { firstSentence: null, remaining: buffer };
  }
  return {
    firstSentence: clean,
    remaining: match[2] || '',
  };
}

// ============================================================================
// ON-DEVICE LATENCY LOGGER (Round 5 Item 2)
// ============================================================================

export interface LatencyLogEntry {
  id: string;
  timestampIso: string;
  queryPreview: string;
  source: 'voice' | 'chat' | 'benchmark';
  model: string;
  relevantToolCount: number;
  totalRegistryTools: number;
  messageSentMs: number;
  firstTokenMs: number | null;
  firstSpeechMs: number | null;
  doneMs: number | null;
  ttftMs: number | null;
  ttfssMs: number | null;
  totalDurationMs: number | null;
  spokenChars: number;
  totalOutputChars: number;
  routedToCard: boolean;
  status: 'streaming' | 'completed' | 'error';
}

const LATENCY_STORAGE_KEY = 'zoya_device_latency_log_v1';
const MAX_LOG_ENTRIES = 100;

class DeviceLatencyLogger {
  private entries: LatencyLogEntry[] = [];
  private listeners = new Set<() => void>();

  constructor() {
    this.loadFromStorage();
  }

  private loadFromStorage() {
    try {
      if (typeof localStorage !== 'undefined') {
        const raw = localStorage.getItem(LATENCY_STORAGE_KEY);
        if (raw) {
          const parsed = JSON.parse(raw);
          if (Array.isArray(parsed)) {
            this.entries = parsed;
          }
        }
      }
    } catch {
      // ignore
    }
  }

  private saveToStorage() {
    try {
      if (typeof localStorage !== 'undefined') {
        localStorage.setItem(
          LATENCY_STORAGE_KEY,
          JSON.stringify(this.entries.slice(0, MAX_LOG_ENTRIES))
        );
      }
    } catch {
      // ignore
    }
    this.listeners.forEach((fn) => fn());
  }

  subscribe(listener: () => void): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  getEntries(): LatencyLogEntry[] {
    return [...this.entries];
  }

  startRequest(params: {
    query: string;
    source: 'voice' | 'chat' | 'benchmark';
    model?: string;
    relevantToolCount?: number;
  }): string {
    const id = `lat_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
    const now = Date.now();
    const opt = selectOptimalModelForRequest(params.query);

    const entry: LatencyLogEntry = {
      id,
      timestampIso: new Date(now).toISOString(),
      queryPreview: params.query.slice(0, 90),
      source: params.source,
      model: params.model || opt.model,
      relevantToolCount: params.relevantToolCount ?? opt.relevantTools.length,
      totalRegistryTools: ALL_ZOYA_TOOL_SCHEMAS.length,
      messageSentMs: now,
      firstTokenMs: null,
      firstSpeechMs: null,
      doneMs: null,
      ttftMs: null,
      ttfssMs: null,
      totalDurationMs: null,
      spokenChars: 0,
      totalOutputChars: 0,
      routedToCard: false,
      status: 'streaming',
    };

    this.entries.unshift(entry);
    if (this.entries.length > MAX_LOG_ENTRIES) {
      this.entries.length = MAX_LOG_ENTRIES;
    }
    this.saveToStorage();
    return id;
  }

  markFirstToken(id: string) {
    const entry = this.entries.find((e) => e.id === id);
    if (!entry || entry.firstTokenMs !== null) return;
    const now = Date.now();
    entry.firstTokenMs = now;
    entry.ttftMs = Math.max(1, now - entry.messageSentMs);
    this.saveToStorage();
  }

  markFirstSpeech(id: string, spokenText?: string) {
    const entry = this.entries.find((e) => e.id === id);
    if (!entry || entry.firstSpeechMs !== null) return;
    const now = Date.now();
    entry.firstSpeechMs = now;
    entry.ttfssMs = Math.max(1, now - entry.messageSentMs);
    if (spokenText) {
      entry.spokenChars = spokenText.length;
    }
    this.saveToStorage();
  }

  markDone(
    id: string,
    params?: {
      fullOutput?: string;
      spokenText?: string;
      routedToCard?: boolean;
      status?: 'completed' | 'error';
    }
  ) {
    const entry = this.entries.find((e) => e.id === id);
    if (!entry) return;
    const now = Date.now();
    if (entry.firstTokenMs === null) {
      entry.firstTokenMs = now;
      entry.ttftMs = Math.max(1, now - entry.messageSentMs);
    }
    entry.doneMs = now;
    entry.totalDurationMs = Math.max(1, now - entry.messageSentMs);
    if (params?.fullOutput !== undefined) {
      entry.totalOutputChars = params.fullOutput.length;
    }
    if (params?.spokenText !== undefined) {
      entry.spokenChars = params.spokenText.length;
    }
    if (params?.routedToCard !== undefined) {
      entry.routedToCard = params.routedToCard;
    }
    entry.status = params?.status || 'completed';
    this.saveToStorage();
  }

  clearAll() {
    this.entries = [];
    this.saveToStorage();
  }

  getSummaryStats(): {
    count: number;
    medianTtftMs: number;
    p95TtftMs: number;
    medianTtfssMs: number;
    p95TtfssMs: number;
    medianTotalMs: number;
    p95TotalMs: number;
  } {
    const completed = this.entries.filter((e) => e.status === 'completed');
    const calcPercentile = (vals: number[], p: number): number => {
      if (vals.length === 0) return 0;
      const sorted = [...vals].sort((a, b) => a - b);
      const idx = Math.min(sorted.length - 1, Math.floor((p / 100) * sorted.length));
      return Math.round(sorted[idx]);
    };

    const ttfts = completed.map((e) => e.ttftMs).filter((v): v is number => v !== null);
    const ttfsss = completed.map((e) => e.ttfssMs).filter((v): v is number => v !== null);
    const totals = completed.map((e) => e.totalDurationMs).filter((v): v is number => v !== null);

    return {
      count: completed.length,
      medianTtftMs: calcPercentile(ttfts, 50),
      p95TtftMs: calcPercentile(ttfts, 95),
      medianTtfssMs: calcPercentile(ttfsss, 50),
      p95TtfssMs: calcPercentile(ttfsss, 95),
      medianTotalMs: calcPercentile(totals, 50),
      p95TotalMs: calcPercentile(totals, 95),
    };
  }

  exportAsJson(): string {
    return JSON.stringify(
      {
        exportedAt: new Date().toISOString(),
        userAgent: typeof navigator !== 'undefined' ? navigator.userAgent : 'node',
        summary: this.getSummaryStats(),
        entries: this.entries,
      },
      null,
      2
    );
  }

  exportAsCsv(): string {
    const headers = [
      'id',
      'timestampIso',
      'source',
      'model',
      'relevantToolCount',
      'totalRegistryTools',
      'ttftMs',
      'ttfssMs',
      'totalDurationMs',
      'spokenChars',
      'totalOutputChars',
      'routedToCard',
      'status',
      'queryPreview',
    ];
    const rows = this.entries.map((e) =>
      [
        e.id,
        e.timestampIso,
        e.source,
        e.model,
        e.relevantToolCount,
        e.totalRegistryTools,
        e.ttftMs ?? '',
        e.ttfssMs ?? '',
        e.totalDurationMs ?? '',
        e.spokenChars,
        e.totalOutputChars,
        e.routedToCard,
        e.status,
        `"${(e.queryPreview || '').replace(/"/g, '""')}"`,
      ].join(',')
    );
    return [headers.join(','), ...rows].join('\n');
  }
}

export const latencyLogger = new DeviceLatencyLogger();
