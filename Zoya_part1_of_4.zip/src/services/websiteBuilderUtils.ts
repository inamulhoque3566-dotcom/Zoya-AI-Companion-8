import JSZip from 'jszip';

export interface WebsiteAsset {
  path: string; // e.g. "./assets/hero-photo.png"
  name: string;
  mimeType: string;
  dataUrl: string;
}

export interface WebsiteProjectFiles {
  html: string;
  css: string;
  js: string;
  assets: WebsiteAsset[];
}

export interface ParsedSection {
  index: number;
  id: string;
  tagName: string;
  label: string;
  backgroundColor: string;
  color: string;
  padding: string;
  maxWidth: string;
  textAlign: string;
  layoutMode: 'block' | 'grid-2' | 'grid-3' | 'flex-row';
  gap: string;
}

export interface ParsedImage {
  index: number;
  src: string;
  alt: string;
  width: string;
  borderRadius: string;
  objectFit: string;
}

export interface CssColorVar {
  name: string;
  value: string;
  hexValue: string;
}

export interface ParsedElementInfo {
  path: string;
  tagName: string;
  text: string;
  color: string;
  fontSize: string;
  fontWeight: string;
  backgroundColor: string;
  isTextEditable: boolean;
}

export interface StreamedWebsiteParseResult {
  css: string;
  html: string;
  js: string;
  activePhase: 'connecting' | 'css' | 'html' | 'js' | 'complete';
  bodyFragmentHtml: string;
  completedSectionCount: number;
  isComplete: boolean;
}

function stripMarkdownFences(code: string): string {
  return (code || '')
    .replace(/^```[a-zA-Z0-9_-]*\s*\n?/gm, '')
    .replace(/\n?```\s*$/gm, '')
    .trimStart();
}

/**
 * Unified Website Intent Detection across voice, chat, Live mic, and home text input.
 */
export function isWebsiteIntentPrompt(text: string): boolean {
  const lower = (text || '').trim().toLowerCase();
  if (!lower) return false;
  return (
    lower.includes('website') ||
    lower.includes('वेबसाइट') ||
    lower.includes('वेब साइट') ||
    lower.includes('webpage') ||
    lower.includes('web page') ||
    lower.includes('web site') ||
    lower.includes('वेबपेज') ||
    lower.includes('वेब पेज') ||
    lower.includes('landing page') ||
    lower.includes('site bana') ||
    lower.includes('site banao') ||
    lower.includes('site banaye') ||
    lower.includes('site banana') ||
    /\b(build|make|create|design|generate|open)\s+(me\s+)?(a\s+|an\s+|my\s+|our\s+|new\s+)?(site|website|webpage|web\s+app)\b/i.test(
      lower
    ) ||
    /\b(portfolio|business|cafe|restaurant|shop|store|agency|clinic)\s+(site|ki\s+site|page|website)\b/i.test(
      lower
    ) ||
    /\b(meri|hamari|apni|ek)\s+[\w\s]{0,24}\bsite\s+(banao|bana|banana|banani|chahiye)\b/i.test(lower)
  );
}

export function isExplicitWebsiteEditIntent(text: string): boolean {
  const lower = (text || '').trim().toLowerCase();
  if (!lower) return false;
  return (
    /\b(change|edit|update|modify|replace|add|remove|delete|rename|translate|convert|fix|improve|adjust|resize|reorder|move|hide|show|color|colour|theme|background|font|button|header|footer|hero|section|menu|nav|navbar|logo|image|photo)\b/i.test(
      lower
    ) ||
    /\b(badlo|badal|karo|kar\s*do|hatao|hata\s*do|jodo|jod\s*do|dal\s*do|lagao|laga\s*do|likho|likh\s*do|chota|bada|rang|iska|iske|isme|website\s+mein)\b/i.test(
      lower
    ) ||
    /(बदलो|बदल|जोड़ो|हटाओ|डालो|रंग|सेक्शन|बटन|वेबसाइट में)/.test(text)
  );
}

export function extractBodyInnerForStreaming(partialHtml: string): string {
  if (!partialHtml) return '';
  const cleaned = partialHtml
    .replace(/<script\b[^>]*>[\s\S]*?(?:<\/script>|$)/gi, '')
    .replace(/<link\b[^>]*rel=["']?stylesheet["']?[^>]*>/gi, '');

  const bodyStartMatch = cleaned.match(/<body\b[^>]*>/i);
  let bodyContent = '';
  if (!bodyStartMatch || bodyStartMatch.index === undefined) {
    // Model hasn't reached <body> yet; check if direct HTML tags exist outside <head>
    const afterHead = cleaned.split(/<\/head>/i)[1];
    bodyContent = afterHead ? afterHead.replace(/<\/?html[^>]*>/gi, '') : '';
  } else {
    bodyContent = cleaned.slice(bodyStartMatch.index + bodyStartMatch[0].length);
    const bodyEndIdx = bodyContent.search(/<\/body>/i);
    if (bodyEndIdx !== -1) {
      bodyContent = bodyContent.slice(0, bodyEndIdx);
    }
  }

  // Trim incomplete trailing "<..." tag fragment so half-streamed attributes don't flash as raw text
  const lastOpenBracket = bodyContent.lastIndexOf('<');
  const lastCloseBracket = bodyContent.lastIndexOf('>');
  if (lastOpenBracket !== -1 && lastOpenBracket > lastCloseBracket) {
    bodyContent = bodyContent.slice(0, lastOpenBracket);
  }
  return bodyContent;
}

/**
 * Parses the delimited Gemini stream:
 * <<<FILE:styles.css>>> ... <<<FILE:index.html>>> ... <<<FILE:app.js>>> ... <<<END>>>
 */
export function parseStreamedWebsiteOutput(rawBuffer: string): StreamedWebsiteParseResult {
  const buf = (rawBuffer || '').replace(/\r\n/g, '\n');
  const cssMarker = '<<<FILE:styles.css>>>';
  const htmlMarker = '<<<FILE:index.html>>>';
  const jsMarker = '<<<FILE:app.js>>>';
  const endMarker = '<<<END>>>';

  const cssIdx = buf.indexOf(cssMarker);
  const htmlIdx = buf.indexOf(htmlMarker);
  const jsIdx = buf.indexOf(jsMarker);
  const endIdx = buf.indexOf(endMarker);

  let css = '';
  let html = '';
  let js = '';
  let activePhase: StreamedWebsiteParseResult['activePhase'] = 'connecting';

  if (cssIdx !== -1) {
    const start = cssIdx + cssMarker.length;
    const stop = htmlIdx !== -1 ? htmlIdx : jsIdx !== -1 ? jsIdx : endIdx !== -1 ? endIdx : buf.length;
    css = stripMarkdownFences(buf.slice(start, stop)).trimEnd();
    activePhase = 'css';
  }

  if (htmlIdx !== -1) {
    const start = htmlIdx + htmlMarker.length;
    const stop = jsIdx !== -1 ? jsIdx : endIdx !== -1 ? endIdx : buf.length;
    html = stripMarkdownFences(buf.slice(start, stop)).trimEnd();
    activePhase = 'html';
  }

  if (jsIdx !== -1) {
    const start = jsIdx + jsMarker.length;
    const stop = endIdx !== -1 ? endIdx : buf.length;
    js = stripMarkdownFences(buf.slice(start, stop)).trimEnd();
    activePhase = 'js';
  }

  // Fallback if model omitted markers somehow but output raw HTML
  if (cssIdx === -1 && htmlIdx === -1 && buf.includes('<html')) {
    html = stripMarkdownFences(buf);
    activePhase = 'html';
  }

  if (endIdx !== -1) {
    activePhase = 'complete';
  }

  const bodyFragmentHtml = extractBodyInnerForStreaming(html);
  const closedSectionMatches = bodyFragmentHtml.match(/<\/(header|section|footer)\s*>/gi);
  const completedSectionCount = closedSectionMatches ? closedSectionMatches.length : 0;

  return {
    css,
    html,
    js,
    activePhase,
    bodyFragmentHtml,
    completedSectionCount,
    isComplete: endIdx !== -1,
  };
}

function parseHtmlDocument(html: string): Document {
  const parser = new DOMParser();
  const safeHtml =
    html && html.trim()
      ? html
      : '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Custom Website</title><link rel="stylesheet" href="./styles.css"></head><body><main></main><script src="./app.js" defer></script></body></html>';
  return parser.parseFromString(safeHtml, 'text/html');
}

function serializeDocument(doc: Document): string {
  // Remove any leftover preview bridge nodes before serializing
  doc.getElementById('__zoya_preview_bridge')?.remove();
  doc.getElementById('__zoya_preview_bridge_style')?.remove();
  return `<!DOCTYPE html>\n${doc.documentElement.outerHTML}`;
}

function getEditableSectionElements(doc: Document): HTMLElement[] {
  const body = doc.body;
  if (!body) return [];
  const results: HTMLElement[] = [];

  for (const child of Array.from(body.children)) {
    const el = child as HTMLElement;
    const tag = el.tagName.toLowerCase();
    if (tag === 'script' || tag === 'style' || el.id === '__zoya_preview_bridge') continue;

    if (tag === 'main') {
      const mainChildren = Array.from(el.children) as HTMLElement[];
      if (mainChildren.length > 0) {
        for (const inner of mainChildren) {
          const innerTag = inner.tagName.toLowerCase();
          if (innerTag !== 'script' && innerTag !== 'style') {
            results.push(inner);
          }
        }
      } else {
        results.push(el);
      }
    } else {
      results.push(el);
    }
  }
  return results;
}

export function normalizeHexColor(input: string, fallback = '#0f172a'): string {
  const val = (input || '').trim();
  if (/^#[0-9a-f]{6}$/i.test(val)) return val.toLowerCase();
  if (/^#[0-9a-f]{3}$/i.test(val)) {
    const r = val[1];
    const g = val[2];
    const b = val[3];
    return `#${r}${r}${g}${g}${b}${b}`.toLowerCase();
  }
  const rgbMatch = val.match(/^rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)/i);
  if (rgbMatch) {
    const toHex = (n: number) => Math.max(0, Math.min(255, n)).toString(16).padStart(2, '0');
    return `#${toHex(Number(rgbMatch[1]))}${toHex(Number(rgbMatch[2]))}${toHex(Number(rgbMatch[3]))}`;
  }
  return fallback;
}

function detectLayoutMode(el: HTMLElement): ParsedSection['layoutMode'] {
  const display = el.style.display;
  const cols = el.style.gridTemplateColumns || '';
  if (display === 'flex') return 'flex-row';
  if (display === 'grid') {
    if (cols.includes('3')) return 'grid-3';
    return 'grid-2';
  }
  return 'block';
}

export function parseSectionsFromHtml(html: string): ParsedSection[] {
  if (!html.trim()) return [];
  const doc = parseHtmlDocument(html);
  const elements = getEditableSectionElements(doc);
  return elements.map((el, index) => {
    const tagName = el.tagName.toLowerCase();
    const heading = el.querySelector('h1, h2, h3, nav a, .logo, strong');
    const headingText = heading?.textContent?.trim().slice(0, 36);
    const label =
      headingText ||
      (el.id ? el.id.replace(/[-_]+/g, ' ') : `${tagName.toUpperCase()} ${index + 1}`);

    return {
      index,
      id: el.id || '',
      tagName,
      label,
      backgroundColor: el.style.backgroundColor || '',
      color: el.style.color || '',
      padding: el.style.padding || '',
      maxWidth: el.style.maxWidth || '',
      textAlign: el.style.textAlign || '',
      layoutMode: detectLayoutMode(el),
      gap: el.style.gap || '',
    };
  });
}

export function moveSectionInHtml(html: string, index: number, direction: -1 | 1): string {
  const doc = parseHtmlDocument(html);
  const sections = getEditableSectionElements(doc);
  const targetIndex = index + direction;
  if (index < 0 || index >= sections.length || targetIndex < 0 || targetIndex >= sections.length) {
    return html;
  }

  const current = sections[index];
  const sibling = sections[targetIndex];
  const parent = sibling.parentElement;
  if (!parent) return html;

  if (direction < 0) {
    parent.insertBefore(current, sibling);
  } else {
    parent.insertBefore(current, sibling.nextSibling);
  }
  return serializeDocument(doc);
}

export function duplicateSectionInHtml(html: string, index: number): string {
  const doc = parseHtmlDocument(html);
  const sections = getEditableSectionElements(doc);
  const target = sections[index];
  if (!target || !target.parentElement) return html;

  const clone = target.cloneNode(true) as HTMLElement;
  if (clone.id) {
    clone.id = `${clone.id}-copy-${Date.now().toString(36).slice(-3)}`;
  }
  target.parentElement.insertBefore(clone, target.nextSibling);
  return serializeDocument(doc);
}

export function deleteSectionInHtml(html: string, index: number): string {
  const doc = parseHtmlDocument(html);
  const sections = getEditableSectionElements(doc);
  const target = sections[index];
  if (!target) return html;
  target.remove();
  return serializeDocument(doc);
}

export function addCustomSectionToHtml(
  html: string,
  options: { title: string; body: string; backgroundColor?: string; textColor?: string }
): string {
  const doc = parseHtmlDocument(html);
  const section = doc.createElement('section');
  const slugId =
    (options.title || 'section')
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '')
      .slice(0, 24) || 'custom';
  section.id = `${slugId}-${Date.now().toString(36).slice(-3)}`;
  section.style.padding = '64px 24px';
  section.style.maxWidth = '1120px';
  section.style.margin = '0 auto';
  if (options.backgroundColor) section.style.backgroundColor = options.backgroundColor;
  if (options.textColor) section.style.color = options.textColor;

  const h2 = doc.createElement('h2');
  h2.textContent = options.title.trim() || 'New Section';
  h2.style.marginBottom = '16px';

  const p = doc.createElement('p');
  p.textContent = options.body.trim() || 'Add your content here.';
  p.style.lineHeight = '1.65';

  section.appendChild(h2);
  section.appendChild(p);

  const main = doc.body.querySelector('main');
  const footer = doc.body.querySelector('footer');
  if (main) {
    main.appendChild(section);
  } else if (footer && footer.parentElement === doc.body) {
    doc.body.insertBefore(section, footer);
  } else {
    const scriptEl = doc.body.querySelector('script');
    if (scriptEl) {
      doc.body.insertBefore(section, scriptEl);
    } else {
      doc.body.appendChild(section);
    }
  }

  return serializeDocument(doc);
}

export function updateSectionStyleInHtml(
  html: string,
  index: number,
  patch: Partial<{
    id: string;
    backgroundColor: string;
    color: string;
    padding: string;
    maxWidth: string;
    textAlign: string;
    layoutMode: ParsedSection['layoutMode'];
    gap: string;
  }>
): string {
  const doc = parseHtmlDocument(html);
  const sections = getEditableSectionElements(doc);
  const target = sections[index];
  if (!target) return html;

  if (patch.id !== undefined) {
    if (patch.id.trim()) target.id = patch.id.trim();
    else target.removeAttribute('id');
  }
  if (patch.backgroundColor !== undefined) {
    target.style.backgroundColor = patch.backgroundColor;
  }
  if (patch.color !== undefined) {
    target.style.color = patch.color;
  }
  if (patch.padding !== undefined) {
    target.style.padding = patch.padding;
  }
  if (patch.maxWidth !== undefined) {
    target.style.maxWidth = patch.maxWidth;
    if (patch.maxWidth) {
      target.style.marginLeft = 'auto';
      target.style.marginRight = 'auto';
    }
  }
  if (patch.textAlign !== undefined) {
    target.style.textAlign = patch.textAlign;
  }
  if (patch.gap !== undefined) {
    target.style.gap = patch.gap;
  }
  if (patch.layoutMode !== undefined) {
    if (patch.layoutMode === 'block') {
      target.style.display = 'block';
      target.style.gridTemplateColumns = '';
      target.style.flexWrap = '';
    } else if (patch.layoutMode === 'grid-2') {
      target.style.display = 'grid';
      target.style.gridTemplateColumns = 'repeat(2, minmax(0, 1fr))';
      target.style.gap = target.style.gap || '24px';
    } else if (patch.layoutMode === 'grid-3') {
      target.style.display = 'grid';
      target.style.gridTemplateColumns = 'repeat(3, minmax(0, 1fr))';
      target.style.gap = target.style.gap || '24px';
    } else if (patch.layoutMode === 'flex-row') {
      target.style.display = 'flex';
      target.style.flexWrap = 'wrap';
      target.style.alignItems = 'center';
      target.style.gap = target.style.gap || '20px';
    }
  }

  return serializeDocument(doc);
}

function findElementByPath(doc: Document, pathStr: string): HTMLElement | null {
  if (!pathStr) return null;
  const indices = pathStr
    .split('.')
    .map((p) => Number(p))
    .filter((n) => Number.isInteger(n) && n >= 0);

  let current: Element | null = doc.body;
  for (const idx of indices) {
    if (!current) return null;
    const validChildren: Element[] = Array.from(current.children).filter(
      (c) => c.id !== '__zoya_preview_bridge' && c.id !== '__zoya_preview_bridge_style'
    );
    current = validChildren[idx] || null;
  }
  return current as HTMLElement | null;
}

export function updateElementByPathInHtml(
  html: string,
  pathStr: string,
  patch: Partial<{
    text: string;
    color: string;
    backgroundColor: string;
    fontSize: string;
    fontWeight: string;
  }>
): string {
  const doc = parseHtmlDocument(html);
  const el = findElementByPath(doc, pathStr);
  if (!el) return html;

  if (patch.text !== undefined) {
    el.textContent = patch.text;
  }
  if (patch.color !== undefined) {
    el.style.color = patch.color;
  }
  if (patch.backgroundColor !== undefined) {
    el.style.backgroundColor = patch.backgroundColor;
  }
  if (patch.fontSize !== undefined) {
    el.style.fontSize = patch.fontSize;
  }
  if (patch.fontWeight !== undefined) {
    el.style.fontWeight = patch.fontWeight;
  }

  return serializeDocument(doc);
}

export function parseImagesFromHtml(html: string): ParsedImage[] {
  if (!html.trim()) return [];
  const doc = parseHtmlDocument(html);
  const imgs = Array.from(doc.body.querySelectorAll('img'));
  return imgs.map((img, index) => ({
    index,
    src: img.getAttribute('src') || '',
    alt: img.getAttribute('alt') || '',
    width: img.style.width || img.getAttribute('width') || '',
    borderRadius: img.style.borderRadius || '',
    objectFit: img.style.objectFit || '',
  }));
}

export function updateImageInHtml(
  html: string,
  index: number,
  patch: Partial<{
    src: string;
    alt: string;
    width: string;
    borderRadius: string;
    objectFit: string;
  }>
): string {
  const doc = parseHtmlDocument(html);
  const imgs = Array.from(doc.body.querySelectorAll('img'));
  const img = imgs[index];
  if (!img) return html;

  if (patch.src !== undefined) img.setAttribute('src', patch.src);
  if (patch.alt !== undefined) img.setAttribute('alt', patch.alt);
  if (patch.width !== undefined) {
    img.style.width = patch.width;
    img.removeAttribute('width');
  }
  if (patch.borderRadius !== undefined) img.style.borderRadius = patch.borderRadius;
  if (patch.objectFit !== undefined) img.style.objectFit = patch.objectFit;

  return serializeDocument(doc);
}

export function insertImageInSectionHtml(
  html: string,
  sectionIndex: number,
  image: { src: string; alt: string }
): string {
  const doc = parseHtmlDocument(html);
  const sections = getEditableSectionElements(doc);
  const target = sections[sectionIndex] || sections[0] || doc.body;
  if (!target) return html;

  const img = doc.createElement('img');
  img.setAttribute('src', image.src);
  img.setAttribute('alt', image.alt || 'Website image');
  img.style.width = '100%';
  img.style.maxWidth = '560px';
  img.style.borderRadius = '12px';
  img.style.objectFit = 'cover';
  img.style.display = 'block';
  img.style.margin = '16px auto';

  target.appendChild(img);
  return serializeDocument(doc);
}

export function parseCssColorVars(css: string): CssColorVar[] {
  if (!css) return [];
  const rootMatch = css.match(/:root\s*\{([\s\S]*?)\}/);
  if (!rootMatch) return [];
  const block = rootMatch[1];
  const vars: CssColorVar[] = [];
  const propRegex = /(--[a-zA-Z0-9_-]+)\s*:\s*([^;]+);/g;
  let m: RegExpExecArray | null;
  while ((m = propRegex.exec(block)) !== null) {
    const name = m[1].trim();
    const rawVal = m[2].trim();
    const looksLikeColor =
      /^#[0-9a-f]{3,8}$/i.test(rawVal) ||
      /^rgba?\(/i.test(rawVal) ||
      /^hsla?\(/i.test(rawVal) ||
      /(color|bg|surface|accent|primary|secondary|text|border|muted)/i.test(name);
    if (looksLikeColor && !rawVal.includes('gradient')) {
      vars.push({
        name,
        value: rawVal,
        hexValue: normalizeHexColor(rawVal, '#38bdf8'),
      });
    }
  }
  return vars;
}

export function updateCssColorVar(css: string, varName: string, nextValue: string): string {
  if (!css) return `:root {\n  ${varName}: ${nextValue};\n}\n`;
  const escaped = varName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const regex = new RegExp(`(${escaped}\\s*:\\s*)([^;]+)(;)`);
  if (regex.test(css)) {
    return css.replace(regex, `$1${nextValue}$3`);
  }
  if (/:root\s*\{/.test(css)) {
    return css.replace(/:root\s*\{/, `:root {\n  ${varName}: ${nextValue};`);
  }
  return `:root {\n  ${varName}: ${nextValue};\n}\n\n${css}`;
}

export function updateBodyPaletteOverride(
  css: string,
  patch: Partial<{ backgroundColor: string; color: string }>
): string {
  let next = css || '';
  const rules: string[] = [];
  if (patch.backgroundColor) rules.push(`background-color: ${patch.backgroundColor} !important;`);
  if (patch.color) rules.push(`color: ${patch.color} !important;`);
  if (rules.length === 0) return next;

  const markerStart = '/* ZOYA_PALETTE_OVERRIDE */';
  const markerEnd = '/* /ZOYA_PALETTE_OVERRIDE */';
  const block = `${markerStart}\nbody {\n  ${rules.join('\n  ')}\n}\n${markerEnd}`;
  const regex = new RegExp(
    `${markerStart.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}[\\s\\S]*?${markerEnd.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}`
  );
  if (regex.test(next)) {
    return next.replace(regex, block);
  }
  return `${next}\n\n${block}\n`;
}

function decodeBasicHtmlEntities(text: string): string {
  return text
    .replace(/&amp;/gi, '&')
    .replace(/&lt;/gi, '<')
    .replace(/&gt;/gi, '>')
    .replace(/&quot;/gi, '"')
    .replace(/&#39;|&apos;/gi, "'")
    .replace(/&nbsp;/gi, ' ')
    .trim();
}

export function extractTitleFromHtml(html: string, fallback = 'Custom Website'): string {
  if (!html.trim()) return fallback;
  const titleMatch = html.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
  if (titleMatch && titleMatch[1].trim()) {
    const decoded = decodeBasicHtmlEntities(titleMatch[1]);
    if (decoded) return decoded;
  }
  const h1Match = html.match(/<h1[^>]*>([\s\S]*?)<\/h1>/i);
  if (h1Match) {
    const clean = decodeBasicHtmlEntities(h1Match[1].replace(/<[^>]+>/g, ''));
    if (clean) return clean.slice(0, 60);
  }
  return fallback;
}

/**
 * Produces clean standalone files (index.html, styles.css, app.js, assets)
 * ready for offline viewing (`file://`), ZIP download, or static web publishing.
 * NEVER injects editor bridge scripts or inline preview hacks.
 */
export function buildStandaloneFiles(files: WebsiteProjectFiles): WebsiteProjectFiles {
  const doc = parseHtmlDocument(files.html);
  doc.getElementById('__zoya_preview_bridge')?.remove();
  doc.getElementById('__zoya_preview_bridge_style')?.remove();
  doc.querySelectorAll('[data-zoya-selected]').forEach((el) => el.removeAttribute('data-zoya-selected'));
  doc.querySelectorAll('[contenteditable]').forEach((el) => el.removeAttribute('contenteditable'));

  // Remove any accidental inline style/script copies left from older outputs
  doc.querySelectorAll('style[data-zoya-inlined="1"], script[data-zoya-inlined="1"]').forEach((n) => n.remove());

  const hasStylesheetLink = Array.from(doc.head.querySelectorAll('link[rel="stylesheet"]')).some((link) => {
    const href = (link.getAttribute('href') || '').trim();
    return href === './styles.css' || href === 'styles.css';
  });
  if (!hasStylesheetLink) {
    const link = doc.createElement('link');
    link.setAttribute('rel', 'stylesheet');
    link.setAttribute('href', './styles.css');
    doc.head.appendChild(link);
  }

  const hasAppScript = Array.from(doc.querySelectorAll('script[src]')).some((scr) => {
    const src = (scr.getAttribute('src') || '').trim();
    return src === './app.js' || src === 'app.js';
  });
  if (!hasAppScript) {
    const script = doc.createElement('script');
    script.setAttribute('src', './app.js');
    script.setAttribute('defer', '');
    doc.body.appendChild(script);
  }

  return {
    html: serializeDocument(doc),
    css: files.css || '',
    js: files.js || '',
    assets: files.assets || [],
  };
}

function replaceAssetRefsWithDataUrls(text: string, assets: WebsiteAsset[]): string {
  if (!text || !assets || assets.length === 0) return text;
  let out = text;
  for (const asset of assets) {
    if (!asset.path || !asset.dataUrl) continue;
    const bare = asset.path.replace(/^\.\//, '');
    out = out.split(asset.path).join(asset.dataUrl);
    out = out.split(bare).join(asset.dataUrl);
  }
  return out;
}

/**
 * Generates the interactive srcDoc used inside the Zoya Builder iframe preview.
 * Optionally attaches the click-to-select & inline text-edit bridge (ONLY for builder preview).
 */
export function assemblePreviewSrcDoc(options: {
  files: WebsiteProjectFiles;
  visualEditMode: boolean;
  selectedPath?: string | null;
}): string {
  const { files, visualEditMode, selectedPath } = options;
  const doc = parseHtmlDocument(files.html);

  // Strip external ./styles.css and ./app.js tags so inline CSS + JS work seamlessly in srcDoc
  doc.querySelectorAll('link[rel="stylesheet"]').forEach((link) => {
    const href = (link.getAttribute('href') || '').trim();
    if (href === './styles.css' || href === 'styles.css') link.remove();
  });
  doc.querySelectorAll('script[src]').forEach((scr) => {
    const src = (scr.getAttribute('src') || '').trim();
    if (src === './app.js' || src === 'app.js') scr.remove();
  });

  const resolvedCss = replaceAssetRefsWithDataUrls(files.css || '', files.assets);
  const styleEl = doc.createElement('style');
  styleEl.setAttribute('data-zoya-inlined', '1');
  styleEl.textContent = resolvedCss;
  doc.head.appendChild(styleEl);

  const bridgeStyle = doc.createElement('style');
  bridgeStyle.id = '__zoya_preview_bridge_style';
  bridgeStyle.textContent = `
    [data-zoya-selected="1"] {
      outline: 2px solid #22d3ee !important;
      outline-offset: 3px !important;
    }
    ${
      visualEditMode
        ? `
    body *:hover {
      outline: 1px dashed rgba(34, 211, 238, 0.55);
      outline-offset: 2px;
      cursor: pointer;
    }
    `
        : ''
    }
  `;
  doc.head.appendChild(bridgeStyle);

  // Rewrite ./assets/... references inside serialized DOM attributes
  let bodySerialized = serializeDocument(doc);
  bodySerialized = replaceAssetRefsWithDataUrls(bodySerialized, files.assets);

  const safeJs = (files.js || '').replace(/<\/script>/gi, '<\\/script>');
  const inlineJsTag = safeJs.trim()
    ? `<script data-zoya-inlined="1">\ntry {\n${safeJs}\n} catch (e) { console.warn('[Preview script]', e); }\n</script>`
    : '';

  const bridgeScript = `
<script id="__zoya_preview_bridge">
(function() {
  var visualEditMode = ${JSON.stringify(Boolean(visualEditMode))};
  var initialSelectedPath = ${JSON.stringify(selectedPath || '')};

  function getElementPath(el) {
    var parts = [];
    var cur = el;
    while (cur && cur !== document.body && cur.parentElement) {
      var siblings = Array.prototype.filter.call(cur.parentElement.children, function(c) {
        return c.id !== '__zoya_preview_bridge' && c.id !== '__zoya_preview_bridge_style';
      });
      var idx = siblings.indexOf(cur);
      if (idx === -1) return '';
      parts.unshift(idx);
      cur = cur.parentElement;
    }
    return cur === document.body ? parts.join('.') : '';
  }

  function findByPath(pathStr) {
    if (!pathStr) return null;
    var parts = pathStr.split('.');
    var cur = document.body;
    for (var i = 0; i < parts.length; i++) {
      if (!cur) return null;
      var siblings = Array.prototype.filter.call(cur.children, function(c) {
        return c.id !== '__zoya_preview_bridge' && c.id !== '__zoya_preview_bridge_style';
      });
      cur = siblings[Number(parts[i])] || null;
    }
    return cur;
  }

  function clearSelection() {
    var prev = document.querySelectorAll('[data-zoya-selected="1"]');
    for (var i = 0; i < prev.length; i++) {
      prev[i].removeAttribute('data-zoya-selected');
      prev[i].removeAttribute('contenteditable');
    }
  }

  function selectElement(el, enableInline) {
    if (!el || el === document.body || el === document.documentElement) return;
    clearSelection();
    el.setAttribute('data-zoya-selected', '1');
    var path = getElementPath(el);
    var cs = window.getComputedStyle(el);
    var hasDirectChildren = el.children && el.children.length > 0;
    var editable = !hasDirectChildren && el.tagName.toLowerCase() !== 'img' && el.tagName.toLowerCase() !== 'svg';
    if (visualEditMode && enableInline && editable) {
      el.setAttribute('contenteditable', 'true');
      try { el.focus(); } catch (_) {}
    }
    window.parent.postMessage({
      type: 'ZOYA_ELEMENT_SELECTED',
      payload: {
        path: path,
        tagName: el.tagName.toLowerCase(),
        text: editable ? (el.innerText || el.textContent || '') : '',
        color: cs.color,
        backgroundColor: cs.backgroundColor,
        fontSize: cs.fontSize,
        fontWeight: cs.fontWeight,
        isTextEditable: editable
      }
    }, '*');
  }

  if (initialSelectedPath) {
    var pre = findByPath(initialSelectedPath);
    if (pre) pre.setAttribute('data-zoya-selected', '1');
  }

  document.addEventListener('click', function(e) {
    if (!visualEditMode) return;
    var target = e.target;
    if (!target || target.id === '__zoya_preview_bridge') return;
    var anchor = target.closest ? target.closest('a') : null;
    if (anchor) e.preventDefault();
    e.stopPropagation();
    selectElement(target, true);
  }, true);

  document.addEventListener('blur', function(e) {
    if (!visualEditMode) return;
    var target = e.target;
    if (!target || target.getAttribute('contenteditable') !== 'true') return;
    var path = getElementPath(target);
    target.removeAttribute('contenteditable');
    if (path) {
      window.parent.postMessage({
        type: 'ZOYA_TEXT_EDITED',
        payload: {
          path: path,
          text: target.innerText || target.textContent || ''
        }
      }, '*');
    }
  }, true);
})();
</script>`;

  const closingBodyIdx = bodySerialized.lastIndexOf('</body>');
  if (closingBodyIdx !== -1) {
    return `${bodySerialized.slice(0, closingBodyIdx)}${inlineJsTag}${bridgeScript}${bodySerialized.slice(closingBodyIdx)}`;
  }
  return `${bodySerialized}${inlineJsTag}${bridgeScript}`;
}

/**
 * Generates the flicker-free streaming preview shell rendered during active code streaming.
 */
export const STREAMING_PREVIEW_SHELL_SRCDOC = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style id="zoya-live-base">
    * { box-sizing: border-box; }
    html, body { margin: 0; padding: 0; min-height: 100vh; font-family: system-ui, -apple-system, sans-serif; }
    .zoya-live-placeholder {
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 14px;
      padding: 32px 24px;
      background: #0f172a;
      color: #e2e8f0;
      text-align: center;
    }
    .zoya-live-badge {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      font-size: 12px;
      font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
      color: #67e8f9;
      background: rgba(34, 211, 238, 0.12);
      border: 1px solid rgba(34, 211, 238, 0.3);
      padding: 6px 12px;
      border-radius: 6px;
    }
    .zoya-live-dot {
      width: 8px;
      height: 8px;
      border-radius: 999px;
      background: #22d3ee;
      animation: zoyaPulseDot 1.1s ease-in-out infinite;
    }
    .zoya-live-title {
      font-size: 20px;
      font-weight: 700;
      color: #ffffff;
      max-width: 480px;
      margin: 0;
    }
    .zoya-live-step {
      font-size: 13px;
      color: #94a3b8;
      max-width: 440px;
      margin: 0;
    }
    .zoya-live-enter {
      animation: zoyaSectionReveal 0.28s ease-out;
    }
    @keyframes zoyaPulseDot {
      0%, 100% { opacity: 0.35; transform: scale(0.85); }
      50% { opacity: 1; transform: scale(1.15); }
    }
    @keyframes zoyaSectionReveal {
      from { opacity: 0.35; transform: translateY(8px); }
      to { opacity: 1; transform: translateY(0); }
    }
  </style>
  <style id="zoya-live-css"></style>
</head>
<body>
  <div id="zoya-live-root">
    <div class="zoya-live-placeholder">
      <div class="zoya-live-badge"><span class="zoya-live-dot"></span>LIVE BUILD STREAM</div>
      <p class="zoya-live-title" id="zoya-ph-title">Building your custom website...</p>
      <p class="zoya-live-step" id="zoya-ph-step">Streaming CSS design tokens and preparing sections...</p>
    </div>
  </div>
  <script>
    (function() {
      var staging = document.createElement('div');
      var hasMountedRealDom = false;

      function syncElementList(targetParent, sourceParent) {
        var nextNodes = Array.prototype.slice.call(sourceParent.childNodes);
        for (var i = 0; i < nextNodes.length; i++) {
          var nextChild = nextNodes[i];
          var curChild = targetParent.childNodes[i];
          if (!curChild) {
            var imported = document.importNode(nextChild, true);
            if (imported.nodeType === 1) {
              imported.classList.add('zoya-live-enter');
            }
            targetParent.appendChild(imported);
          } else if (curChild.nodeType === 1 && nextChild.nodeType === 1 && curChild.tagName === nextChild.tagName) {
            // Preserve identical completed sections without touching/flickering DOM
            if (curChild.outerHTML !== nextChild.outerHTML) {
              // If tag is <main> or wrapper with multiple children, sync inside smoothly
              if (nextChild.tagName.toLowerCase() === 'main' && curChild.children.length > 0 && nextChild.children.length > 0) {
                // Copy updated attributes if any
                for (var a = 0; a < nextChild.attributes.length; a++) {
                  var attr = nextChild.attributes[a];
                  if (curChild.getAttribute(attr.name) !== attr.value) {
                    curChild.setAttribute(attr.name, attr.value);
                  }
                }
                syncElementList(curChild, nextChild);
              } else {
                var rep = document.importNode(nextChild, true);
                targetParent.replaceChild(rep, curChild);
              }
            }
          } else {
            var swapped = document.importNode(nextChild, true);
            if (swapped.nodeType === 1) swapped.classList.add('zoya-live-enter');
            targetParent.replaceChild(swapped, curChild);
          }
        }
        while (targetParent.childNodes.length > nextNodes.length) {
          targetParent.removeChild(targetParent.lastChild);
        }
      }

      window.addEventListener('message', function(ev) {
        if (!ev || !ev.data || ev.data.type !== 'ZOYA_STREAM_PATCH') return;
        var styleNode = document.getElementById('zoya-live-css');
        var rootNode = document.getElementById('zoya-live-root');
        if (styleNode && typeof ev.data.css === 'string') {
          styleNode.textContent = ev.data.css;
        }
        if (!rootNode) return;

        var incomingHtml = typeof ev.data.bodyHtml === 'string' ? ev.data.bodyHtml : '';
        if (!incomingHtml.trim()) {
          if (!hasMountedRealDom) {
            var phTitle = document.getElementById('zoya-ph-title');
            var phStep = document.getElementById('zoya-ph-step');
            if (phTitle && ev.data.title) phTitle.textContent = ev.data.title;
            if (phStep && ev.data.step) phStep.textContent = ev.data.step;
          }
          return;
        }

        staging.innerHTML = incomingHtml;
        if (!hasMountedRealDom) {
          rootNode.innerHTML = '';
          hasMountedRealDom = true;
        }
        syncElementList(rootNode, staging);
      });
    })();
  </script>
</body>
</html>`;

export function toUrlSlug(title: string): string {
  const clean = (title || 'custom-website')
    .toLowerCase()
    .replace(/[^a-z0-9-]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 48);
  return clean || 'custom-website';
}

function dataUrlToUint8Array(dataUrl: string): Uint8Array | null {
  const match = dataUrl.match(/^data:([^;]+);base64,(.+)$/);
  if (!match) return null;
  const binary = atob(match[2]);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes;
}

export async function downloadWebsiteZip(options: {
  title: string;
  files: WebsiteProjectFiles;
}): Promise<{ fileName: string; fileCount: number }> {
  const standalone = buildStandaloneFiles(options.files);
  const zip = new JSZip();

  zip.file('index.html', standalone.html);
  zip.file('styles.css', standalone.css);
  zip.file('app.js', standalone.js);

  let assetCount = 0;
  for (const asset of standalone.assets) {
    if (!asset?.path || !asset?.dataUrl) continue;
    const relPath = asset.path.replace(/^\.\//, '');
    const bytes = dataUrlToUint8Array(asset.dataUrl);
    if (bytes) {
      zip.file(relPath, bytes);
      assetCount++;
    }
  }

  zip.file(
    'README.txt',
    `${options.title || 'Custom Website'}\n\nOffline & Hosting Instructions:\n1. Unzip this folder.\n2. Open index.html directly in any browser to view and use offline.\n3. Upload the entire folder (index.html, styles.css, app.js${assetCount > 0 ? ', assets/' : ''}) to any static web host.\n`
  );

  const blob = await zip.generateAsync({ type: 'blob' });
  const slug = toUrlSlug(options.title);
  const fileName = `${slug}-website.zip`;
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = fileName;
  document.body.appendChild(anchor);
  anchor.click();
  document.body.removeChild(anchor);
  setTimeout(() => URL.revokeObjectURL(url), 1000);

  return { fileName, fileCount: 4 + assetCount };
}
