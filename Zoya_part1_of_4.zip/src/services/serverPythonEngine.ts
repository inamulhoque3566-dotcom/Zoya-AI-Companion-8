import { spawn } from 'child_process';
import fs from 'fs';
import path from 'path';
import os from 'os';
import JSZip from 'jszip';
import { GoogleGenAI, Type } from '@google/genai';

export interface PythonExecutionResult {
  success: boolean;
  stdout: string;
  stderr: string;
  exitCode: number | null;
  executionTimeMs: number;
  timedOut?: boolean;
  error?: string;
}

export interface SafetyValidationResult {
  safe: boolean;
  reason?: string;
  category?: 'MALWARE_BLOCKED' | 'BANKING_BLOCKED' | 'PRIVACY_VIOLATION_BLOCKED';
}

export interface GeneratedAndroidApp {
  appName: string;
  packageName: string;
  versionName: string;
  language: 'kotlin' | 'java';
  minSdk: number;
  targetSdk: number;
  description: string;
  permissions: string[];
  files: Array<{
    path: string;
    content: string;
    description?: string;
  }>;
  buildInstructions: string;
  zipDownloadUrl?: string;
}

export interface GitHubConnectionTestResult {
  success: boolean;
  status?: number;
  username?: string;
  name?: string;
  scopes?: string[];
  hasRepoScope?: boolean;
  hasWorkflowScope?: boolean;
  missingScopes?: string[];
  isFineGrained?: boolean;
  message: string;
  error?: string;
}

const SANDBOX_DIR = path.join(os.tmpdir(), 'zoya-python-sandbox');
const DOWNLOADS_DIR = path.join(process.cwd(), 'data', 'downloads');

if (!fs.existsSync(SANDBOX_DIR)) {
  fs.mkdirSync(SANDBOX_DIR, { recursive: true });
}
if (!fs.existsSync(DOWNLOADS_DIR)) {
  fs.mkdirSync(DOWNLOADS_DIR, { recursive: true });
}

// Purge any legacy fake .apk files from DOWNLOADS_DIR on startup (Round 5 Item 3)
try {
  const existingFiles = fs.readdirSync(DOWNLOADS_DIR);
  for (const file of existingFiles) {
    if (file.toLowerCase().endsWith('.apk')) {
      fs.unlinkSync(path.join(DOWNLOADS_DIR, file));
    }
  }
} catch {
  // ignore
}

/**
 * Strict Safety & Anti-Malware Validator (Requirement 10)
 * Rejects any request that attempts to interact with Banking/UPI/Payment apps,
 * spyware, keyloggers, SMS/OTP theft, or unauthorized background surveillance.
 */
export function validateAppSafety(prompt: string): SafetyValidationResult {
  const lower = prompt.toLowerCase();

  // 1. Banking, UPI, Financial & Payment apps prohibition
  const bankingKeywords = [
    'upi hack',
    'bypass otp',
    'read otp',
    'steal otp',
    'intercept sms',
    'bank login',
    'phishing',
    'fake gpay',
    'fake phonepe',
    'fake paytm',
    'clone banking',
    'credit card skimmer',
    'automate banking',
    'auto transfer money',
  ];
  for (const kw of bankingKeywords) {
    if (lower.includes(kw)) {
      return {
        safe: false,
        category: 'BANKING_BLOCKED',
        reason:
          'Security Policy Violation: Zoya strictly prohibits generating apps that automate, spoof, or intercept Banking, UPI, OTP, or Payment workflows.',
      };
    }
  }

  // 2. Malware, Spyware, Ransomware, Keylogger prohibition
  const malwareKeywords = [
    'keylogger',
    'spyware',
    'ransomware',
    'trojan',
    'rat ',
    'remote access trojan',
    'steal passwords',
    'steal contacts',
    'upload all photos secretly',
    'hidden camera recorder',
    'stalkerware',
    'ddos',
    'botnet',
  ];
  for (const kw of malwareKeywords) {
    if (lower.includes(kw)) {
      return {
        safe: false,
        category: 'MALWARE_BLOCKED',
        reason:
          'Safety Policy Violation: Zoya cannot create spyware, keyloggers, ransomware, or harmful software.',
      };
    }
  }

  return { safe: true };
}

/**
 * Executes Python 3 code in an isolated subprocess with a strict timeout.
 */
export async function executePythonScript(
  code: string,
  stdinInput = '',
  timeoutMs = 15000
): Promise<PythonExecutionResult> {
  const startTime = Date.now();
  const runId = `run_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
  const workDir = path.join(SANDBOX_DIR, runId);
  fs.mkdirSync(workDir, { recursive: true });

  const scriptPath = path.join(workDir, 'main.py');
  fs.writeFileSync(scriptPath, code, 'utf8');

  const safeTimeout = Math.min(Math.max(timeoutMs, 1000), 30000);

  return new Promise((resolve) => {
    let stdout = '';
    let stderr = '';
    let timedOut = false;

    const child = spawn('python3', ['-I', scriptPath], {
      cwd: workDir,
      env: {
        PATH: process.env.PATH || '/usr/bin:/bin',
        PYTHONIOENCODING: 'utf-8',
        PYTHONDONTWRITEBYTECODE: '1',
        HOME: workDir,
      },
    });

    const timer = setTimeout(() => {
      timedOut = true;
      child.kill('SIGKILL');
    }, safeTimeout);

    if (stdinInput) {
      child.stdin.write(stdinInput);
    }
    child.stdin.end();

    child.stdout.on('data', (chunk) => {
      if (stdout.length < 100_000) {
        stdout += chunk.toString();
      }
    });

    child.stderr.on('data', (chunk) => {
      if (stderr.length < 100_000) {
        stderr += chunk.toString();
      }
    });

    child.on('error', (err) => {
      clearTimeout(timer);
      try {
        fs.rmSync(workDir, { recursive: true, force: true });
      } catch {}
      resolve({
        success: false,
        stdout,
        stderr: stderr + '\n' + err.message,
        exitCode: -1,
        executionTimeMs: Date.now() - startTime,
        error: err.message,
      });
    });

    child.on('close', (exitCode) => {
      clearTimeout(timer);
      try {
        fs.rmSync(workDir, { recursive: true, force: true });
      } catch {}
      resolve({
        success: !timedOut && exitCode === 0,
        stdout: stdout.trimEnd(),
        stderr: timedOut
          ? `${stderr}\n[TimeoutError] Execution exceeded ${safeTimeout / 1000}s limit.`.trim()
          : stderr.trimEnd(),
        exitCode,
        executionTimeMs: Date.now() - startTime,
        timedOut,
      });
    });
  });
}

/**
 * Checks Python 3 environment & installed packages.
 */
export async function getPythonEnvironmentInfo(): Promise<{
  available: boolean;
  version: string;
  executable: string;
  platform: string;
}> {
  const res = await executePythonScript(
    'import sys, platform; print(sys.version.split()[0]); print(sys.executable); print(platform.platform())',
    '',
    5000
  );
  if (!res.success) {
    return {
      available: false,
      version: 'Unavailable',
      executable: 'python3',
      platform: os.platform(),
    };
  }
  const lines = res.stdout.split('\n');
  return {
    available: true,
    version: lines[0] || '3.x',
    executable: lines[1] || '/usr/bin/python3',
    platform: lines[2] || os.platform(),
  };
}

/**
 * Uses Gemini AI Brain + Python scaffolding validator to generate a complete,
 * compilable Android Studio project (Kotlin or Java, Target SDK 34, Min SDK 26)
 * from any natural language description in Hindi, Hinglish, or English.
 */
export async function generateAndroidAppFromPrompt(params: {
  prompt: string;
  appName?: string;
  language?: 'kotlin' | 'java';
  apiKey?: string;
  modelName?: string;
}): Promise<{
  success: boolean;
  safetyBlocked?: boolean;
  error?: string;
  app?: GeneratedAndroidApp;
}> {
  const safety = validateAppSafety(params.prompt);
  if (!safety.safe) {
    return {
      success: false,
      safetyBlocked: true,
      error: safety.reason,
    };
  }

  const key = (
    params.apiKey ||
    process.env.GEMINI_API_KEY ||
    process.env.API_KEY ||
    ''
  ).trim();

  if (!key) {
    return {
      success: false,
      error:
        'Gemini API Key is not configured. Please add GEMINI_API_KEY in Settings or server environment.',
    };
  }

  const preferredLang = params.language || 'kotlin';
  const modelToUse = params.modelName || 'gemini-2.5-flash';
  const ai = new GoogleGenAI({ apiKey: key });

  const systemInstruction = `You are Zoya AI's Senior Android Architect & Autonomous App Builder.
The user will describe an Android app idea in Hindi, Hinglish, or English.
You must design and output a COMPLETE, REAL, COMPILABLE Android project targeting Android 8.0 (API 26) through Android 15 (API 35).

STRICT RULES:
1. NEVER use placeholders like "// TODO" or "// add code here". Write complete, working code.
2. Preferred language: ${preferredLang.toUpperCase()}.
3. Include a clean Material 3 / modern dark-friendly UI with interactive controls, state persistence (SharedPreferences or SQLite), and error handling.
4. Request ONLY the minimum required permissions in AndroidManifest.xml.
5. NEVER include any code that reads banking apps, UPI PINs, or private OTPs.
6. Return valid JSON matching the schema.`;

  const response = await ai.models.generateContent({
    model: modelToUse,
    contents: `Build a complete Android application for this request:\n"${params.prompt}"\nPreferred App Name: ${params.appName || 'Auto-detect from prompt'}`,
    config: {
      systemInstruction,
      responseMimeType: 'application/json',
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          appName: { type: Type.STRING },
          packageName: { type: Type.STRING },
          versionName: { type: Type.STRING },
          language: { type: Type.STRING },
          description: { type: Type.STRING },
          permissions: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
          },
          mainActivityCode: { type: Type.STRING },
          activityLayoutXml: { type: Type.STRING },
          additionalClasses: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                fileName: { type: Type.STRING },
                code: { type: Type.STRING },
                description: { type: Type.STRING },
              },
              required: ['fileName', 'code'],
            },
          },
        },
        required: [
          'appName',
          'packageName',
          'description',
          'mainActivityCode',
          'activityLayoutXml',
        ],
      },
    },
  });

  const rawText = response.text || '{}';
  let parsed: any;
  try {
    parsed = JSON.parse(rawText);
  } catch {
    return {
      success: false,
      error: 'AI returned malformed project structure. Please try again.',
    };
  }

  const cleanAppName = (parsed.appName || params.appName || 'ZoyaCustomApp').replace(
    /[^a-zA-Z0-9_ -]/g,
    ''
  );
  const pkgName = (parsed.packageName || 'com.zoya.generated.app')
    .toLowerCase()
    .replace(/[^a-z0-9._]/g, '');
  const pkgPath = pkgName.replace(/\./g, '/');
  const isKotlin = (parsed.language || preferredLang).toLowerCase() !== 'java';
  const ext = isKotlin ? 'kt' : 'java';

  const permissionsList: string[] = Array.isArray(parsed.permissions)
    ? parsed.permissions
    : [];
  const permissionsXml = permissionsList
    .map((p) => {
      const permName = p.startsWith('android.permission.')
        ? p
        : `android.permission.${p.toUpperCase()}`;
      return `    <uses-permission android:name="${permName}" />`;
    })
    .join('\n');

  const manifestXml = `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="${pkgName}">

${permissionsXml}

    <application
        android:allowBackup="true"
        android:label="${cleanAppName}"
        android:supportsRtl="true"
        android:theme="@style/Theme.AppCompat.DayNight.NoActionBar">
        <activity
            android:name=".MainActivity"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>`;

  const rootBuildGradle = `plugins {
    id("com.android.application") version "8.2.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.22" apply false
}`;

  const settingsGradle = `pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "${cleanAppName.replace(/\s+/g, '')}"
include(":app")`;

  const appBuildGradle = `plugins {
    id("com.android.application")
    ${isKotlin ? 'id("org.jetbrains.kotlin.android")' : ''}
}

android {
    namespace = "${pkgName}"
    compileSdk = 34

    defaultConfig {
        applicationId = "${pkgName}"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "${parsed.versionName || '1.0.0'}"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    ${
      isKotlin
        ? `kotlinOptions {
        jvmTarget = "17"
    }`
        : ''
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
}`;

  const githubWorkflowYaml = buildGeneratedAppWorkflowYaml(cleanAppName);

  const files: GeneratedAndroidApp['files'] = [
    {
      path: 'settings.gradle.kts',
      content: settingsGradle,
      description: 'Gradle project settings',
    },
    {
      path: 'build.gradle.kts',
      content: rootBuildGradle,
      description: 'Root Gradle build configuration',
    },
    {
      path: 'app/build.gradle.kts',
      content: appBuildGradle,
      description: 'App module Gradle dependencies (API 26-34)',
    },
    {
      path: 'app/src/main/AndroidManifest.xml',
      content: manifestXml,
      description: 'Android application manifest & permissions',
    },
    {
      path: `app/src/main/java/${pkgPath}/MainActivity.${ext}`,
      content: parsed.mainActivityCode,
      description: `Primary ${isKotlin ? 'Kotlin' : 'Java'} Activity logic`,
    },
    {
      path: 'app/src/main/res/layout/activity_main.xml',
      content: parsed.activityLayoutXml,
      description: 'Main UI XML layout',
    },
    {
      path: '.github/workflows/build.yml',
      content: githubWorkflowYaml,
      description: 'GitHub Actions workflow (compiles APK artifact + publishes GitHub Release asset)',
    },
  ];

  if (Array.isArray(parsed.additionalClasses)) {
    for (const cls of parsed.additionalClasses) {
      if (cls.fileName && cls.code) {
        files.push({
          path: `app/src/main/java/${pkgPath}/${cls.fileName}`,
          content: cls.code,
          description: cls.description || 'Helper class',
        });
      }
    }
  }

  // Create downloadable Source Project ZIP archive
  const zip = new JSZip();
  for (const f of files) {
    zip.file(f.path, f.content);
  }
  const zipFileName = `${cleanAppName.replace(/\s+/g, '_')}-Android-Project.zip`;
  const zipFilePath = path.join(DOWNLOADS_DIR, zipFileName);
  const zipBuffer = await zip.generateAsync({ type: 'nodebuffer' });
  fs.writeFileSync(zipFilePath, zipBuffer);

  const generatedApp: GeneratedAndroidApp = {
    appName: cleanAppName,
    packageName: pkgName,
    versionName: parsed.versionName || '1.0.0',
    language: isKotlin ? 'kotlin' : 'java',
    minSdk: 26,
    targetSdk: 34,
    description: parsed.description || '',
    permissions: permissionsList,
    files,
    buildInstructions:
      'Use the GitHub Actions APK Pipeline with your GitHub token on your phone to compile a real installable APK and publish it as a GitHub Release asset, or download the Source code bundle (.zip) - NOT an installable app.',
    zipDownloadUrl: `/api/python/download/${zipFileName}`,
  };

  return {
    success: true,
    app: generatedApp,
  };
}

/**
 * Generates the GitHub Actions workflow YAML for apps built in Python Studio.
 * Compiles the Android APK with Gradle AND publishes the APK both as a workflow
 * artifact and as a GitHub Release asset so the phone can download it directly
 * via the native bridge without browser CORS / redirect issues (Round 5 Item 4B & 4C).
 */
export function buildGeneratedAppWorkflowYaml(appName: string): string {
  const safeName = appName.replace(/[^a-zA-Z0-9_-]/g, '') || 'ZoyaGeneratedApp';
  return `name: Build ${safeName} Android APK

on:
  push:
    branches: [ "main", "master" ]
  workflow_dispatch:

permissions:
  contents: write

jobs:
  build-apk:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout Source
        uses: actions/checkout@v4

      - name: Set up JDK 17
        uses: actions/setup-java@v4
        with:
          java-version: '17'
          distribution: 'temurin'

      - name: Setup Gradle
        uses: gradle/actions/setup-gradle@v3
        with:
          gradle-version: '8.6'

      - name: Build Debug APK
        run: gradle assembleDebug --no-daemon

      - name: Rename APK for Release
        run: |
          cp app/build/outputs/apk/debug/app-debug.apk app/build/outputs/apk/debug/${safeName}-debug.apk

      - name: Upload Compiled APK Artifact
        uses: actions/upload-artifact@v4
        with:
          name: ${safeName}-debug-apk
          path: app/build/outputs/apk/debug/${safeName}-debug.apk

      - name: Publish APK as GitHub Release Asset
        uses: softprops/action-gh-release@v2
        with:
          tag_name: v1.0.\${{ github.run_number }}
          name: "${safeName} APK Build #\${{ github.run_number }}"
          body: "Automated Android APK build generated by Zoya AI Python Studio."
          prerelease: false
          files: app/build/outputs/apk/debug/${safeName}-debug.apk
        env:
          GITHUB_TOKEN: \${{ secrets.GITHUB_TOKEN }}
`;
}

/**
 * Packages the generated Android project into a local Source Code Bundle (.zip).
 *
 * ROUND 5 ITEM 3 FIX:
 * NEVER serves or names a local source archive with an `.apk` extension.
 * Always outputs `<AppName>-v<version>-Source-Bundle.zip` and clearly labels it:
 * "Source code bundle (.zip) - NOT an installable app"
 */
export async function buildLocalSourceBundle(params: {
  appName: string;
  packageName: string;
  versionName?: string;
  files: Array<{ path: string; content: string }>;
}): Promise<{
  success: boolean;
  fileName?: string;
  downloadUrl?: string;
  sizeBytes?: number;
  label?: string;
  isInstallableApk?: boolean;
  message?: string;
  error?: string;
}> {
  try {
    const cleanAppName = (params.appName || 'ZoyaApp').replace(/[^a-zA-Z0-9_-]/g, '_');
    const version = (params.versionName || '1.0.0').replace(/[^0-9.]/g, '');

    const zip = new JSZip();

    // Include all generated source files
    for (const f of params.files || []) {
      zip.file(f.path, f.content);
    }

    // Add clear bundle metadata README
    const readmeText = `# ${params.appName} — Source Code Bundle (.zip)
**IMPORTANT: This file is a Source Code Bundle (.zip) - NOT an installable Android app (.apk).**

- Package Name: ${params.packageName}
- Version: ${version}
- Packaged At: ${new Date().toISOString()}

## How to Build an Installable APK
1. In Zoya Python Studio on your phone, enter your GitHub Personal Access Token (with \`repo\` and \`workflow\` scopes), click **Test GitHub Connection**, and run the **6-Step GitHub Actions APK Pipeline**.
2. Or open this folder in Android Studio and run \`./gradlew assembleDebug\`.
`;
    zip.file('README_SOURCE_BUNDLE.md', readmeText);

    // Strictly use .zip extension — NEVER .apk
    const bundleFileName = `${cleanAppName}-v${version}-Source-Bundle.zip`;
    const bundleFilePath = path.join(DOWNLOADS_DIR, bundleFileName);
    const zipBuffer = await zip.generateAsync({ type: 'nodebuffer' });
    fs.writeFileSync(bundleFilePath, zipBuffer);

    const stats = fs.statSync(bundleFilePath);
    const labelText = 'Source code bundle (.zip) - NOT an installable app';

    return {
      success: true,
      fileName: bundleFileName,
      downloadUrl: `/api/python/download/${bundleFileName}`,
      sizeBytes: stats.size,
      label: labelText,
      bundleLabel: labelText,
      isInstallableApk: false,
      message: `Source code bundle (${bundleFileName}) created — NOT an installable app. Use the GitHub Actions pipeline to compile a real installable APK.`,
    } as any;
  } catch (err: any) {
    return {
      success: false,
      error: err?.message || 'Local source bundle packaging failed.',
    };
  }
}

// Keep alias so any existing caller gets the honest .zip source bundle
export const buildLocalApkPackage = buildLocalSourceBundle;

/**
 * ROUND 5 ITEM 4B:
 * Tests the user's GitHub Personal Access Token by calling GET https://api.github.com/user,
 * inspecting the returned username (`login`) and `x-oauth-scopes` header, and checking
 * whether `repo` and `workflow` scopes are enabled.
 */
export async function testGitHubConnection(
  githubToken: string
): Promise<GitHubConnectionTestResult> {
  const token = (githubToken || '').trim();
  if (!token) {
    return {
      success: false,
      message: 'GitHub token is empty. Enter your Personal Access Token on your phone to test.',
      error: 'Missing GitHub Personal Access Token',
    };
  }

  try {
    const res = await fetch('https://api.github.com/user', {
      method: 'GET',
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: 'application/vnd.github+json',
        'X-GitHub-Api-Version': '2022-11-28',
        'User-Agent': 'Zoya-AI-Android-Builder',
      },
    });

    const scopesHeader = res.headers.get('x-oauth-scopes') || '';
    const scopes = scopesHeader
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean);

    const data: any = await res.json().catch(() => ({}));

    if (!res.ok) {
      return {
        success: false,
        status: res.status,
        message: `GitHub authentication failed (HTTP ${res.status}): ${data.message || 'Invalid token'}`,
        error: data.message || `HTTP ${res.status}`,
      };
    }

    const username = data.login || 'unknown';
    const isFineGrained = token.startsWith('github_pat_') && scopes.length === 0;
    const hasRepoScope =
      isFineGrained || scopes.includes('repo') || scopes.includes('public_repo');
    const hasWorkflowScope = isFineGrained || scopes.includes('workflow');

    const missingScopes: string[] = [];
    if (!hasRepoScope) missingScopes.push('repo');
    if (!hasWorkflowScope) missingScopes.push('workflow');

    let message = `Connected as @${username}.`;
    if (isFineGrained) {
      message +=
        ' (Fine-grained PAT detected — ensure Contents & Workflows Read/Write permissions are enabled on repositories).';
    } else if (missingScopes.length > 0) {
      message += ` WARNING: Missing required scope(s): ${missingScopes.join(', ')}. Enable both 'repo' and 'workflow' scopes in GitHub Token Settings.`;
    } else {
      message += ` Verified required scopes ('repo' and 'workflow' present). Ready to build APKs!`;
    }

    return {
      success: true,
      status: res.status,
      username,
      name: data.name || username,
      scopes,
      hasRepoScope,
      hasWorkflowScope,
      missingScopes,
      isFineGrained,
      message,
    };
  } catch (err: any) {
    return {
      success: false,
      message: `Network error contacting GitHub API: ${err?.message || 'Connection failed'}`,
      error: err?.message || 'Network error',
    };
  }
}

/**
 * Triggers or executes individual steps of the GitHub Actions APK build pipeline
 * using the user's GitHub Personal Access Token (Requirement 4B).
 *
 * Supports `step`:
 * - `'create_repo'`: Step 1 — Authenticate & create/verify repository
 * - `'push_files'`: Step 2 — Push Android source files (excluding workflow)
 * - `'push_workflow'`: Step 3 — Push `.github/workflows/build.yml` (with Release asset step)
 * - `'trigger_workflow'`: Step 4 — Dispatch workflow & locate workflow run
 * - `'full'` (default): Executes Steps 1 -> 2 -> 3 -> 4 sequentially
 */
export async function triggerGitHubActionsBuild(params: {
  githubToken: string;
  repoName: string;
  files: Array<{ path: string; content: string }>;
  isPrivate?: boolean;
  step?: 'create_repo' | 'push_files' | 'push_workflow' | 'trigger_workflow' | 'full';
}): Promise<{
  success: boolean;
  stepCompleted?: string;
  failedStep?: string;
  owner?: string;
  repoUrl?: string;
  actionsUrl?: string;
  runId?: number;
  message?: string;
  error?: string;
}> {
  const token = (params.githubToken || '').trim();
  if (!token) {
    return {
      success: false,
      failedStep: 'auth',
      error: 'GitHub Personal Access Token (PAT) is required to build on GitHub Actions.',
    };
  }

  const requestedStep = params.step || 'full';

  const headers: Record<string, string> = {
    Authorization: `Bearer ${token}`,
    Accept: 'application/vnd.github+json',
    'Content-Type': 'application/json',
    'X-GitHub-Api-Version': '2022-11-28',
    'User-Agent': 'Zoya-AI-Android-Builder',
  };

  try {
    // 1. Authenticate & get username
    const userRes = await fetch('https://api.github.com/user', { headers });
    if (!userRes.ok) {
      const errJson: any = await userRes.json().catch(() => ({}));
      return {
        success: false,
        failedStep: 'create_repo',
        error: `GitHub authentication failed (HTTP ${userRes.status}): ${errJson.message || 'Invalid token'}`,
      };
    }
    const userData: any = await userRes.json();
    const owner = userData.login;
    const cleanRepo =
      params.repoName.replace(/[^a-zA-Z0-9._-]/g, '-').toLowerCase() || 'zoya-android-app';

    // Step 1: Create repository (or reuse if exists)
    if (requestedStep === 'create_repo' || requestedStep === 'full') {
      const createRes = await fetch('https://api.github.com/user/repos', {
        method: 'POST',
        headers,
        body: JSON.stringify({
          name: cleanRepo,
          description: 'Generated by Zoya AI Autonomous Android App Builder',
          private: params.isPrivate ?? false,
          auto_init: true,
        }),
      });

      if (!createRes.ok && createRes.status !== 422) {
        const errData: any = await createRes.json().catch(() => ({}));
        return {
          success: false,
          failedStep: 'create_repo',
          owner,
          error: `Create repo failed (HTTP ${createRes.status}): ${errData.message || 'Check repo scope on token'}`,
        };
      }

      if (requestedStep === 'create_repo') {
        return {
          success: true,
          stepCompleted: 'create_repo',
          owner,
          repoUrl: `https://github.com/${owner}/${cleanRepo}`,
          actionsUrl: `https://github.com/${owner}/${cleanRepo}/actions`,
          message: `Repository ${owner}/${cleanRepo} ready.`,
        };
      }

      // Brief pause if repo was just initialized
      await new Promise((r) => setTimeout(r, 1200));
    }

    const pushSingleFile = async (file: { path: string; content: string }) => {
      const fileUrl = `https://api.github.com/repos/${owner}/${cleanRepo}/contents/${file.path}`;
      let sha: string | undefined;
      const existing = await fetch(fileUrl, { headers });
      if (existing.ok) {
        const exData: any = await existing.json();
        sha = exData.sha;
      }

      const putRes = await fetch(fileUrl, {
        method: 'PUT',
        headers,
        body: JSON.stringify({
          message: `Zoya AI: Update ${file.path}`,
          content: Buffer.from(file.content, 'utf8').toString('base64'),
          ...(sha ? { sha } : {}),
        }),
      });

      if (!putRes.ok) {
        const putErr: any = await putRes.json().catch(() => ({}));
        throw new Error(
          `Failed pushing ${file.path} (HTTP ${putRes.status}): ${putErr.message || 'Check repo/workflow permissions'}`
        );
      }
    };

    // Step 2: Push project source files (non-workflow files)
    if (requestedStep === 'push_files' || requestedStep === 'full') {
      const sourceFiles = (params.files || []).filter(
        (f) => !f.path.startsWith('.github/workflows/')
      );
      for (const file of sourceFiles) {
        try {
          await pushSingleFile(file);
        } catch (pushErr: any) {
          return {
            success: false,
            failedStep: 'push_files',
            owner,
            repoUrl: `https://github.com/${owner}/${cleanRepo}`,
            error: pushErr?.message || 'Failed pushing project source files',
          };
        }
      }

      if (requestedStep === 'push_files') {
        return {
          success: true,
          stepCompleted: 'push_files',
          owner,
          repoUrl: `https://github.com/${owner}/${cleanRepo}`,
          actionsUrl: `https://github.com/${owner}/${cleanRepo}/actions`,
          message: `Pushed ${sourceFiles.length} Android source files to ${owner}/${cleanRepo}.`,
        };
      }
    }

    // Step 3: Push .github/workflows/build.yml (requires `workflow` token scope)
    if (requestedStep === 'push_workflow' || requestedStep === 'full') {
      const workflowFiles = (params.files || []).filter((f) =>
        f.path.startsWith('.github/workflows/')
      );
      const wfToPush =
        workflowFiles.length > 0
          ? workflowFiles
          : [
              {
                path: '.github/workflows/build.yml',
                content: buildGeneratedAppWorkflowYaml(cleanRepo),
              },
            ];

      for (const wf of wfToPush) {
        try {
          await pushSingleFile(wf);
        } catch (wfErr: any) {
          return {
            success: false,
            failedStep: 'push_workflow',
            owner,
            repoUrl: `https://github.com/${owner}/${cleanRepo}`,
            error: `${wfErr?.message || 'Failed pushing workflow'}. Make sure your GitHub token has the 'workflow' scope enabled!`,
          };
        }
      }

      if (requestedStep === 'push_workflow') {
        return {
          success: true,
          stepCompleted: 'push_workflow',
          owner,
          repoUrl: `https://github.com/${owner}/${cleanRepo}`,
          actionsUrl: `https://github.com/${owner}/${cleanRepo}/actions`,
          message: 'GitHub Actions APK + Release workflow pushed.',
        };
      }
    }

    // Step 4: Trigger workflow_dispatch & locate active workflow run
    if (requestedStep === 'trigger_workflow' || requestedStep === 'full') {
      await fetch(
        `https://api.github.com/repos/${owner}/${cleanRepo}/actions/workflows/build.yml/dispatches`,
        {
          method: 'POST',
          headers,
          body: JSON.stringify({ ref: 'main' }),
        }
      ).catch(() => {});

      await new Promise((r) => setTimeout(r, 1500));

      let runId: number | undefined;
      const runsRes = await fetch(
        `https://api.github.com/repos/${owner}/${cleanRepo}/actions/runs?per_page=1`,
        { headers }
      );
      if (runsRes.ok) {
        const runsData: any = await runsRes.json();
        runId = runsData.workflow_runs?.[0]?.id;
      }

      return {
        success: true,
        stepCompleted: 'trigger_workflow',
        owner,
        repoUrl: `https://github.com/${owner}/${cleanRepo}`,
        actionsUrl: `https://github.com/${owner}/${cleanRepo}/actions`,
        runId,
        message: `GitHub Actions APK build started for ${owner}/${cleanRepo}!`,
      };
    }

    return {
      success: true,
      owner,
      repoUrl: `https://github.com/${owner}/${cleanRepo}`,
      actionsUrl: `https://github.com/${owner}/${cleanRepo}/actions`,
    };
  } catch (err: any) {
    return {
      success: false,
      error: err?.message || 'Failed to trigger GitHub Actions build.',
    };
  }
}

/**
 * Polls the status of a GitHub Actions APK build run, fetches job step details,
 * and checks for both workflow artifacts AND published GitHub Release assets
 * so the native Android bridge can download the APK directly into Downloads.
 */
export async function checkGitHubBuildStatus(params: {
  owner: string;
  repo: string;
  githubToken: string;
  runId?: number;
}): Promise<{
  success: boolean;
  status?: string;
  conclusion?: string | null;
  htmlUrl?: string;
  artifactDownloadUrl?: string;
  releaseAssetApiUrl?: string;
  releaseBrowserDownloadUrl?: string;
  releaseAssetName?: string;
  releaseTag?: string;
  steps?: Array<{ name: string; status: string; conclusion: string | null }>;
  error?: string;
}> {
  const token = (params.githubToken || '').trim();
  const headers: Record<string, string> = {
    Accept: 'application/vnd.github+json',
    'X-GitHub-Api-Version': '2022-11-28',
    'User-Agent': 'Zoya-AI-Android-Builder',
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
  };

  try {
    const runsUrl = params.runId
      ? `https://api.github.com/repos/${params.owner}/${params.repo}/actions/runs/${params.runId}`
      : `https://api.github.com/repos/${params.owner}/${params.repo}/actions/runs?per_page=1`;

    const res = await fetch(runsUrl, { headers });
    if (!res.ok) {
      const errData: any = await res.json().catch(() => ({}));
      return {
        success: false,
        error: `GitHub API returned HTTP ${res.status}: ${errData.message || 'Failed to fetch run status'}`,
      };
    }

    const data: any = await res.json();
    const targetRun = params.runId ? data : data.workflow_runs?.[0];
    if (!targetRun) {
      return {
        success: true,
        status: 'queued',
        conclusion: null,
      };
    }

    let artifactDownloadUrl: string | undefined;
    let releaseAssetApiUrl: string | undefined;
    let releaseBrowserDownloadUrl: string | undefined;
    let releaseAssetName: string | undefined;
    let releaseTag: string | undefined;
    let steps: Array<{ name: string; status: string; conclusion: string | null }> = [];

    // Fetch job steps so the user can see exact step progress or error on phone
    try {
      const jobsRes = await fetch(
        `https://api.github.com/repos/${params.owner}/${params.repo}/actions/runs/${targetRun.id}/jobs`,
        { headers }
      );
      if (jobsRes.ok) {
        const jobsData: any = await jobsRes.json();
        const firstJob = jobsData.jobs?.[0];
        if (firstJob && Array.isArray(firstJob.steps)) {
          steps = firstJob.steps.map((s: any) => ({
            name: s.name,
            status: s.status,
            conclusion: s.conclusion,
          }));
        }
      }
    } catch {
      // ignore step detail errors
    }

    if (targetRun.status === 'completed' && targetRun.conclusion === 'success') {
      // 1. Check artifacts
      const artRes = await fetch(
        `https://api.github.com/repos/${params.owner}/${params.repo}/actions/runs/${targetRun.id}/artifacts`,
        { headers }
      );
      if (artRes.ok) {
        const artData: any = await artRes.json();
        const firstArtifact = artData.artifacts?.[0];
        if (firstArtifact) {
          artifactDownloadUrl = firstArtifact.archive_download_url;
        }
      }

      // 2. Check published GitHub Releases for direct .apk Release asset (Round 5 Item 4C)
      const relRes = await fetch(
        `https://api.github.com/repos/${params.owner}/${params.repo}/releases?per_page=5`,
        { headers }
      );
      if (relRes.ok) {
        const releases: any[] = await relRes.json();
        for (const rel of releases) {
          const apkAsset = (rel.assets || []).find((a: any) =>
            String(a.name || '').toLowerCase().endsWith('.apk')
          );
          if (apkAsset) {
            releaseAssetApiUrl = apkAsset.url; // Supports private repos with Accept: application/octet-stream
            releaseBrowserDownloadUrl = apkAsset.browser_download_url;
            releaseAssetName = apkAsset.name;
            releaseTag = rel.tag_name;
            break;
          }
        }
      }
    }

    return {
      success: true,
      status: targetRun.status,
      conclusion: targetRun.conclusion,
      htmlUrl: targetRun.html_url,
      artifactDownloadUrl,
      releaseAssetApiUrl,
      releaseBrowserDownloadUrl,
      releaseAssetName,
      releaseTag,
      steps,
    };
  } catch (err: any) {
    return {
      success: false,
      error: err?.message || 'Failed to check build status.',
    };
  }
}

export function getDownloadedProjectFilePath(fileName: string): string | null {
  const safeName = path.basename(fileName);
  // Strictly refuse to serve any local file with an .apk extension (Round 5 Item 3)
  if (safeName.toLowerCase().endsWith('.apk')) {
    return null;
  }
  const fullPath = path.join(DOWNLOADS_DIR, safeName);
  if (fs.existsSync(fullPath)) {
    return fullPath;
  }
  return null;
}
