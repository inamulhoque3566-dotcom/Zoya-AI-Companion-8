export interface ExtractedFile {
  id: string;
  name: string;
  path: string;
  directory: string;
  isDirectory: boolean;
  size: number; // uncompressed bytes
  compressedSize: number; // compressed bytes
  date: Date;
  extension: string;
  mimeType: string;
  isText: boolean;
  isImage: boolean;
  textContent?: string;
  dataUrl?: string;
  rawUint8Array?: Uint8Array;
  error?: string;
}

export interface ZipTreeNode {
  name: string;
  path: string;
  isDirectory: boolean;
  file?: ExtractedFile;
  children: Record<string, ZipTreeNode>;
  size: number;
  itemCount: number;
}

export interface ZipProcessProgress {
  phase: 'reading' | 'extracting' | 'processing' | 'completed' | 'error';
  currentFile: string;
  loadedFiles: number;
  totalFiles: number;
  percentage: number;
  bytesProcessed: number;
}

export interface ZipProcessResult {
  fileName: string;
  totalZipSize: number;
  uncompressedTotalSize: number;
  fileCount: number;
  folderCount: number;
  files: ExtractedFile[];
  tree: ZipTreeNode;
  extensionStats: Record<string, { count: number; totalSize: number }>;
  allProcessedWithoutErrors: boolean;
  processingTimeMs: number;
}

export interface SearchMatch {
  file: ExtractedFile;
  lineNumber: number;
  lineContent: string;
  matchIndex: number;
}
