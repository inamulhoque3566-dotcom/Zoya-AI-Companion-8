import React, { useState } from 'react';
import type { ExtractedFile, ZipProcessResult } from '../types/zip';
import { searchInFiles, exportFilesToZip } from '../services/zipProcessor';
import { STANDALONE_TYPESCRIPT_CODE, STANDALONE_JAVASCRIPT_CODE } from '../services/codeSnippet';
import { 
  Search, 
  Replace, 
  Download, 
  FileSpreadsheet, 
  Code2, 
  Copy, 
  Check, 
  Sparkles,
  ArrowRight,
  FolderArchive,
  RefreshCw
} from 'lucide-react';

interface BatchProcessingToolsProps {
  result: ZipProcessResult;
  files: ExtractedFile[];
  onSelectFile: (file: ExtractedFile) => void;
  onBulkUpdate: (updatedFiles: ExtractedFile[]) => void;
}

export const BatchProcessingTools: React.FC<BatchProcessingToolsProps> = ({
  result,
  files,
  onSelectFile,
  onBulkUpdate,
}) => {
  const [activeTab, setActiveTab] = useState<'search' | 'replace' | 'export' | 'code'>('search');

  // Search State
  const [searchQuery, setSearchQuery] = useState('');
  const [caseSensitive, setCaseSensitive] = useState(false);
  const [useRegex, setUseRegex] = useState(false);
  const [searchResults, setSearchResults] = useState<ReturnType<typeof searchInFiles>>([]);

  // Replace State
  const [replaceTarget, setReplaceTarget] = useState('');
  const [replacementString, setReplacementString] = useState('');
  const [replaceResultMsg, setReplaceResultMsg] = useState('');

  // Re-export ZIP State
  const [isExportingZip, setIsExportingZip] = useState(false);
  const [exportProgress, setExportProgress] = useState(0);

  // Code Tab State
  const [codeLanguage, setCodeLanguage] = useState<'ts' | 'js'>('ts');
  const [copiedCode, setCopiedCode] = useState(false);

  const handleExecuteSearch = (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!searchQuery.trim()) {
      setSearchResults([]);
      return;
    }
    const res = searchInFiles(files, searchQuery, useRegex, caseSensitive);
    setSearchResults(res);
  };

  const handleBulkReplace = () => {
    if (!replaceTarget) return;

    let modifiedFilesCount = 0;
    let totalReplacements = 0;

    const updated = files.map((file) => {
      if (file.isDirectory || !file.textContent) return file;

      if (file.textContent.includes(replaceTarget)) {
        const occurrences = file.textContent.split(replaceTarget).length - 1;
        totalReplacements += occurrences;
        modifiedFilesCount++;
        const newContent = file.textContent.split(replaceTarget).join(replacementString);
        return {
          ...file,
          textContent: newContent,
          size: new TextEncoder().encode(newContent).length,
        };
      }
      return file;
    });

    if (totalReplacements > 0) {
      onBulkUpdate(updated);
      setReplaceResultMsg(
        `सफलता: ${modifiedFilesCount} फ़ाइलों में ${totalReplacements} स्थानों पर परिवर्तन लागू किया गया!`
      );
    } else {
      setReplaceResultMsg('कोई मेल नहीं मिला (No matches found).');
    }
  };

  const handleDownloadZip = async () => {
    setIsExportingZip(true);
    setExportProgress(10);
    try {
      const blob = await exportFilesToZip(files, `processed_${result.fileName}`, (percent) => {
        setExportProgress(percent);
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `processed_${result.fileName}`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error('Failed to export zip:', err);
    } finally {
      setIsExportingZip(false);
      setExportProgress(0);
    }
  };

  const handleExportManifest = (format: 'json' | 'csv') => {
    if (format === 'json') {
      const manifest = {
        archiveName: result.fileName,
        fileCount: result.fileCount,
        folderCount: result.folderCount,
        uncompressedTotalSize: result.uncompressedTotalSize,
        exportedAt: new Date().toISOString(),
        files: files.map((f) => ({
          path: f.path,
          name: f.name,
          isDirectory: f.isDirectory,
          sizeBytes: f.size,
          mimeType: f.mimeType,
          date: f.date,
        })),
      };

      const blob = new Blob([JSON.stringify(manifest, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `manifest_${result.fileName.replace(/\.zip$/i, '')}.json`;
      a.click();
      URL.revokeObjectURL(url);
    } else {
      const headers = ['Path', 'Name', 'Type', 'Size (Bytes)', 'MIME Type', 'Date'];
      const rows = files.map((f) => [
        `"${f.path}"`,
        `"${f.name}"`,
        f.isDirectory ? 'Directory' : 'File',
        f.size,
        `"${f.mimeType}"`,
        `"${f.date?.toISOString() || ''}"`,
      ]);

      const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
      const blob = new Blob([csvContent], { type: 'text/csv' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `manifest_${result.fileName.replace(/\.zip$/i, '')}.csv`;
      a.click();
      URL.revokeObjectURL(url);
    }
  };

  const handleCopyCode = () => {
    const code = codeLanguage === 'ts' ? STANDALONE_TYPESCRIPT_CODE : STANDALONE_JAVASCRIPT_CODE;
    navigator.clipboard.writeText(code);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  return (
    <div className="bg-slate-900 rounded-xl border border-slate-800 overflow-hidden shadow-lg">
      {/* Tab headers */}
      <div className="flex items-center gap-1 p-2 bg-slate-950/90 border-b border-slate-800 overflow-x-auto text-xs font-medium">
        <button
          onClick={() => setActiveTab('search')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-colors shrink-0 ${
            activeTab === 'search'
              ? 'bg-sky-950/80 text-sky-300 border border-sky-800/60'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Search className="w-3.5 h-3.5" />
          <span>सभी फ़ाइलों में खोजें (Global Grep)</span>
        </button>

        <button
          onClick={() => setActiveTab('replace')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-colors shrink-0 ${
            activeTab === 'replace'
              ? 'bg-sky-950/80 text-sky-300 border border-sky-800/60'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Replace className="w-3.5 h-3.5" />
          <span>बैच बदलें (Bulk Replace)</span>
        </button>

        <button
          onClick={() => setActiveTab('export')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-colors shrink-0 ${
            activeTab === 'export'
              ? 'bg-sky-950/80 text-sky-300 border border-sky-800/60'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Download className="w-3.5 h-3.5" />
          <span>निर्यात व री-पैकिंग (Export &amp; Re-Zip)</span>
        </button>

        <button
          onClick={() => setActiveTab('code')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-colors shrink-0 ${
            activeTab === 'code'
              ? 'bg-sky-950/80 text-sky-300 border border-sky-800/60'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Code2 className="w-3.5 h-3.5 text-emerald-400" />
          <span>100% कम्प्लीट कोड/फ़ंक्शन (Standalone Code)</span>
        </button>
      </div>

      {/* Tab Panels */}
      <div className="p-4">
        {/* TAB 1: SEARCH */}
        {activeTab === 'search' && (
          <div className="space-y-4">
            <form onSubmit={handleExecuteSearch} className="flex flex-col sm:flex-row gap-2">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
                <input
                  type="text"
                  placeholder="सभी टेक्स्ट/कोड फाइलों के अंदर शब्द या कोड खोजें (Search inside all files)..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-xs bg-slate-950 border border-slate-800 rounded-lg text-slate-200 placeholder-slate-500 focus:outline-none focus:border-sky-500 font-mono"
                />
              </div>

              <div className="flex items-center gap-3 text-xs text-slate-400 shrink-0">
                <label className="flex items-center gap-1 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={caseSensitive}
                    onChange={(e) => setCaseSensitive(e.target.checked)}
                    className="rounded bg-slate-800 border-slate-700 text-sky-500"
                  />
                  <span>केस-संवेदी (Case sensitive)</span>
                </label>

                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-medium text-white bg-sky-600 hover:bg-sky-500 rounded-lg transition-colors shrink-0"
                >
                  खोजें (Search)
                </button>
              </div>
            </form>

            {searchResults.length > 0 ? (
              <div className="space-y-2">
                <div className="text-xs text-slate-400 font-mono flex items-center justify-between">
                  <span>{searchResults.length} परिणाम मिले:</span>
                  <span>क्लिक करके सीधे उस फ़ाइल पर जाएँ</span>
                </div>
                <div className="max-h-[300px] overflow-y-auto space-y-1.5 pr-1">
                  {searchResults.map((match, idx) => (
                    <div
                      key={idx}
                      onClick={() => onSelectFile(match.file)}
                      className="p-2.5 bg-slate-950/70 hover:bg-slate-800/80 rounded-lg border border-slate-800/80 cursor-pointer transition-colors group font-mono text-xs"
                    >
                      <div className="flex items-center justify-between text-[11px] text-sky-400 mb-1">
                        <span className="font-semibold group-hover:underline truncate">{match.file.path}</span>
                        <span className="text-slate-500 shrink-0">पंक्ति: {match.lineNumber}</span>
                      </div>
                      <div className="text-slate-300 truncate text-[11px] bg-slate-900/80 px-2 py-1 rounded border border-slate-800">
                        {match.lineContent}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ) : searchQuery.trim() ? (
              <div className="p-6 text-center text-xs text-slate-500 font-mono">
                &ldquo;{searchQuery}&rdquo; के लिए कोई परिणाम नहीं मिला।
              </div>
            ) : (
              <div className="text-xs text-slate-500 font-mono">
                ऊपर दिए गए बॉक्स में कोई भी स्ट्रिंग टाइप करें और पूरी ZIP के अंदर तुरंत खोजें।
              </div>
            )}
          </div>
        )}

        {/* TAB 2: BULK REPLACE */}
        {activeTab === 'replace' && (
          <div className="space-y-4">
            <div className="text-xs text-slate-400">
              यह टूल ZIP के अंदर मौजूद सभी टेक्स्ट/कोड फ़ाइलों में एक साथ किसी भी स्ट्रिंग को नई स्ट्रिंग से बदल देता है।
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  ढूंढें (Find Text):
                </label>
                <input
                  type="text"
                  placeholder="उदा. Zoya_small या पुराना नाम..."
                  value={replaceTarget}
                  onChange={(e) => setReplaceTarget(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-slate-950 border border-slate-800 rounded-lg text-slate-200 placeholder-slate-500 font-mono focus:outline-none focus:border-sky-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  इससे बदलें (Replace With):
                </label>
                <input
                  type="text"
                  placeholder="उदा. Zoya_pro या नया मान..."
                  value={replacementString}
                  onChange={(e) => setReplacementString(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-slate-950 border border-slate-800 rounded-lg text-slate-200 placeholder-slate-500 font-mono focus:outline-none focus:border-sky-500"
                />
              </div>
            </div>

            <div className="flex items-center justify-between pt-2">
              <button
                onClick={handleBulkReplace}
                disabled={!replaceTarget}
                className="flex items-center gap-2 px-4 py-2 text-xs font-medium text-white bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 disabled:cursor-not-allowed rounded-lg transition-colors"
              >
                <Replace className="w-4 h-4" />
                <span>सभी फ़ाइलों में एक साथ बदलें (Replace All in Entire ZIP)</span>
              </button>

              {replaceResultMsg && (
                <span className="text-xs font-mono text-emerald-300">{replaceResultMsg}</span>
              )}
            </div>
          </div>
        )}

        {/* TAB 3: EXPORT & RE-ZIP */}
        {activeTab === 'export' && (
          <div className="space-y-4">
            <div className="text-xs text-slate-400">
              निकाली गई फ़ाइलों को मूल संरचना के साथ वापस एक नई उच्च-गति संपीड़ित ZIP फ़ाइल में पैक करें या फ़ाइल मैनिफ़ेस्ट निर्यात करें।
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <div className="p-4 bg-slate-950/80 rounded-lg border border-slate-800 space-y-3">
                <div className="flex items-center gap-2 text-slate-200 text-sm font-semibold">
                  <FolderArchive className="w-4 h-4 text-sky-400" />
                  <span>पूरी ZIP पुनः डाउनलोड करें</span>
                </div>
                <p className="text-xs text-slate-400">
                  सभी 108+ फ़ाइलों को आपके किए गए किसी भी संपादन के साथ पुनः DEFLATE ZIP के रूप में संकलित करें।
                </p>
                <button
                  onClick={handleDownloadZip}
                  disabled={isExportingZip}
                  className="w-full flex items-center justify-center gap-2 px-3 py-2 text-xs font-medium text-white bg-sky-600 hover:bg-sky-500 disabled:opacity-60 rounded-lg transition-colors"
                >
                  {isExportingZip ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>कंप्रेस हो रहा है ({exportProgress}%)...</span>
                    </>
                  ) : (
                    <>
                      <Download className="w-3.5 h-3.5" />
                      <span>संसाधित ZIP डाउनलोड करें</span>
                    </>
                  )}
                </button>
              </div>

              <div className="p-4 bg-slate-950/80 rounded-lg border border-slate-800 space-y-3">
                <div className="flex items-center gap-2 text-slate-200 text-sm font-semibold">
                  <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
                  <span>JSON मैनिफ़ेस्ट निर्यात</span>
                </div>
                <p className="text-xs text-slate-400">
                  प्रत्येक फ़ाइल के पथ, आकार, माइम प्रकार और टाइमस्टैम्प की विस्तृत JSON सूची डाउनलोड करें।
                </p>
                <button
                  onClick={() => handleExportManifest('json')}
                  className="w-full flex items-center justify-center gap-2 px-3 py-2 text-xs font-medium text-emerald-300 bg-emerald-950/80 border border-emerald-800/60 hover:bg-emerald-900 rounded-lg transition-colors"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>JSON रिपोर्ट (.json)</span>
                </button>
              </div>

              <div className="p-4 bg-slate-950/80 rounded-lg border border-slate-800 space-y-3">
                <div className="flex items-center gap-2 text-slate-200 text-sm font-semibold">
                  <FileSpreadsheet className="w-4 h-4 text-amber-400" />
                  <span>CSV स्प्रेडशीट निर्यात</span>
                </div>
                <p className="text-xs text-slate-400">
                  एक्सेल या गूगल शीट्स में देखने योग्य पूरी फ़ाइल सूची का CSV प्रारूप।
                </p>
                <button
                  onClick={() => handleExportManifest('csv')}
                  className="w-full flex items-center justify-center gap-2 px-3 py-2 text-xs font-medium text-amber-300 bg-amber-950/80 border border-amber-800/60 hover:bg-amber-900 rounded-lg transition-colors"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>CSV तालिका (.csv)</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: STANDALONE CODE SNIPPET */}
        {activeTab === 'code' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="text-xs text-slate-400">
                उपयोगकर्ता द्वारा अनुरोधित 100% कम्प्लीट और त्रुटिहीन फ़ंक्शन कोड जिसे सीधे किसी भी प्रोजेक्ट में इस्तेमाल किया जा सकता है:
              </div>

              <div className="flex items-center gap-2">
                <div className="flex items-center p-0.5 bg-slate-950 border border-slate-800 rounded">
                  <button
                    onClick={() => setCodeLanguage('ts')}
                    className={`px-2 py-0.5 text-[11px] rounded transition-colors ${
                      codeLanguage === 'ts' ? 'bg-slate-800 text-sky-300' : 'text-slate-400'
                    }`}
                  >
                    TypeScript
                  </button>
                  <button
                    onClick={() => setCodeLanguage('js')}
                    className={`px-2 py-0.5 text-[11px] rounded transition-colors ${
                      codeLanguage === 'js' ? 'bg-slate-800 text-sky-300' : 'text-slate-400'
                    }`}
                  >
                    JavaScript
                  </button>
                </div>

                <button
                  onClick={handleCopyCode}
                  className="flex items-center gap-1.5 px-3 py-1 text-xs font-medium text-emerald-300 bg-emerald-950/80 border border-emerald-800/60 rounded hover:bg-emerald-900 transition-colors"
                >
                  {copiedCode ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedCode ? 'कॉपी हो गया!' : 'कोड कॉपी करें (Copy)'}</span>
                </button>
              </div>
            </div>

            <div className="relative max-h-[350px] overflow-auto bg-slate-950 p-4 rounded-lg border border-slate-800 font-mono text-xs text-slate-300 leading-relaxed">
              <pre>
                {codeLanguage === 'ts' ? STANDALONE_TYPESCRIPT_CODE : STANDALONE_JAVASCRIPT_CODE}
              </pre>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
