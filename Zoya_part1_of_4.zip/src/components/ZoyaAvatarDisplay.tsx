import React from 'react';
import { Anime3DAvatar } from '../data/anime3DAvatars';
import { ZoyaLiving3DAvatar } from './3d/ZoyaLiving3DAvatar';

export type AvatarStyle = 'classic';

interface ZoyaAvatarDisplayProps {
  avatarStyle: AvatarStyle;
  voiceStatus?: 'idle' | 'listening' | 'processing' | 'speaking';
  audioLevel?: number;
  onTapAvatar?: () => void;
  is3DAvatarActive?: boolean;
  active3DAvatar?: Anime3DAvatar | null;
  avatarScale?: number;
  avatarOffsetY?: number;
}

export const ZoyaAvatarDisplay: React.FC<ZoyaAvatarDisplayProps> = React.memo(({
  avatarStyle,
  voiceStatus = 'idle',
  audioLevel = 0,
  onTapAvatar,
  is3DAvatarActive = false,
  active3DAvatar = null,
  avatarScale = 1.0,
  avatarOffsetY = 0,
}) => {
  // Determine current active avatar key across both gallery 3D anime and classic styles
  const is3DAnimeSelected = Boolean(is3DAvatarActive && active3DAvatar);
  const currentAvatarKey = is3DAnimeSelected && active3DAvatar ? active3DAvatar.id : avatarStyle;

  return (
    <div className="relative flex flex-col items-center justify-center w-full max-w-3xl mx-auto h-full select-none overflow-visible">
      {/* Avatar Container - Centered squarely, prominent and clear in foreground */}
      <div
        className="relative z-10 cursor-pointer group flex items-center justify-center w-full h-full overflow-visible"
        title="Zoya AI 3D Living Avatar"
        data-testid="zoya-avatar-rig"
        data-avatar-style={avatarStyle}
        data-avatar-id={currentAvatarKey}
        data-voice-status={voiceStatus}
      >
        {/* Unified 3D Living Avatar Engine across ALL Avatars - Sized to use available screen space effectively */}
        <div
          data-testid={is3DAnimeSelected ? 'zoya-3d-anime-transparent-avatar' : 'zoya-living-3d-wrapper'}
          data-avatar-id={currentAvatarKey}
          className="relative h-full max-h-full max-w-full w-auto mx-auto flex items-center justify-center overflow-visible"
        >
          <ZoyaLiving3DAvatar
            key={currentAvatarKey}
            avatarId={currentAvatarKey}
            voiceStatus={voiceStatus}
            audioLevel={audioLevel}
            avatarScale={avatarScale}
            avatarOffsetY={avatarOffsetY}
            onTapAvatar={onTapAvatar}
            className="w-full h-full"
          />
        </div>
      </div>
    </div>
  );
});
