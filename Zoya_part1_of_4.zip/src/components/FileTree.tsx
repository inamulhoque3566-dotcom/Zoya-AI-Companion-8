import React, { useState, useMemo } from 'react';
import type { ExtractedFile, ZipTreeNode } from '../types/zip';
import { 
  Folder, 
  FolderOpen, 
  FileCode, 
  FileText, 
  Image as ImageIcon, 
  Binary, 
  ChevronRight, 
  ChevronDown, 
  Search, 
  List, 
  FolderTree, 
  SlidersHorizontal 
} from 'lucide-react';

interface FileTreeProps {
  tree: ZipTreeNode;
  files: ExtractedFile[];
  selectedFile: ExtractedFile | null;
  onSelectFile: (file: ExtractedFile) => void;
}

export const FileTree: React.FC<FileTreeProps> = ({
  tree,
  files,
  selectedFile,
  onSelectFile,
}) => {
  const [viewMode, setViewMode] = useState<'tree' | 'flat'>('tree');
  const [searchQuery, setSearchQuery] = useState('');
  const [filterExt, setFilterExt] = useState<string>('all');
  const [expandedPaths, setExpandedPaths] = useState<Record<string, boolean>>({
    '': true,
    'src/': true,
    'src': true,
  });

  const toggleExpand = (path: string) => {
    setExpandedPaths((prev) => ({
      ...prev,
      [path]: !prev[path],
    }));
  };

  const expandAll = () => {
    const next: Record<string, boolean> = {};
    const traverse = (node: ZipTreeNode) => {
      next[node.path] = true;
      Object.values(node.children).forEach(traverse);
    };
    traverse(tree);
    setExpandedPaths(next);
  };

  const collapseAll = () => {
    setExpandedPaths({ '': true });
  };

  // Get distinct extensions for quick filtering
  const extensions = useMemo(() => {
    const set = new Set<string>();
    files.forEach((f) => {
      if (!f.isDirectory && f.extension) {
        set.add(f.extension);
      }
    });
    return Array.from(set).sort();
  }, [files]);

  // Filtered files for Flat list view
  const filteredFlatFiles = useMemo(() => {
    return files.filter((file) => {
      if (file.isDirectory) return false;
      if (filterExt !== 'all' && file.extension !== filterExt) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        return file.path.toLowerCase().includes(q) || file.name.toLowerCase().includes(q);
      }
      return true;
    });
  }, [files, filterExt, searchQuery]);

  const formatBytes = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
  };

  const getFileIcon = (file: ExtractedFile) => {
    if (file.isImage) return <ImageIcon className="w-3.5 h-3.5 text-emerald-400 shrink-0" />;
    if (file.isText) return <FileCode className="w-3.5 h-3.5 text-sky-400 shrink-0" />;
    return <Binary className="w-3.5 h-3.5 text-amber-400 shrink-0" />;
  };

  // Recursive tree node renderer
  const renderTreeNode = (node: ZipTreeNode, depth: number = 0) => {
    const isExpanded = !!expandedPaths[node.path];
    const isRoot = node.name === 'root';
    const childrenList = Object.values(node.children).sort((a, b) => {
      // Folders first, then alphabetical
      if (a.isDirectory && !b.isDirectory) return -1;
      if (!a.isDirectory && b.isDirectory) return 1;
      return a.name.localeCompare(b.name);
    });

    if (isRoot) {
      return (
        <div className="space-y-0.5">
          {childrenList.map((child) => renderTreeNode(child, 0))}
        </div>
      );
    }

    if (node.isDirectory) {
      return (
        <div key={node.path} className="select-none">
          <div
            onClick={() => toggleExpand(node.path)}
            className="flex items-center gap-1.5 px-2 py-1.5 rounded hover:bg-slate-800/60 cursor-pointer text-slate-300 transition-colors text-xs font-mono"
            style={{ paddingLeft: `${depth * 14 + 8}px` }}
          >
            {isExpanded ? (
              <ChevronDown className="w-3.5 h-3.5 text-slate-500 shrink-0" />
            ) : (
              <ChevronRight className="w-3.5 h-3.5 text-slate-500 shrink-0" />
            )}
            {isExpanded ? (
              <FolderOpen className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            ) : (
              <Folder className="w-3.5 h-3.5 text-amber-400/80 shrink-0" />
            )}
            <span className="font-semibold text-slate-200 truncate">{node.name}</span>
            <span className="ml-auto text-[10px] text-slate-400 font-mono">
              {Object.keys(node.children).length} मद
            </span>
          </div>

          {isExpanded && (
            <div>
              {childrenList.map((child) => renderTreeNode(child, depth + 1))}
            </div>
          )}
        </div>
      );
    }

    // It's a file
    const file = node.file;
    if (!file) return null;

    const isSelected = selectedFile?.path === file.path;

    return (
      <div
        key={file.path}
        onClick={() => onSelectFile(file)}
        className={`flex items-center gap-1.5 px-2 py-1.5 rounded cursor-pointer transition-colors text-xs font-mono select-none ${
          isSelected
            ? 'bg-sky-950/80 text-sky-200 border-l-2 border-sky-400 font-medium'
            : 'text-slate-300 hover:bg-slate-800/60'
        }`}
        style={{ paddingLeft: `${depth * 14 + 18}px` }}
        title={`${file.path} (${formatBytes(file.size)})`}
      >
        {getFileIcon(file)}
        <span className="truncate">{node.name}</span>
        <span className="ml-auto text-[10px] text-slate-400 font-mono shrink-0">
          {formatBytes(file.size)}
        </span>
      </div>
    );
  };

  return (
    <div className="flex flex-col h-full bg-slate-900 rounded-xl border border-slate-800 overflow-hidden shadow-lg">
      {/* Top search & view toggle bar */}
      <div className="p-3 bg-slate-950/90 border-b border-slate-800 space-y-2">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-1 p-0.5 bg-slate-900 border border-slate-800 rounded-lg">
            <button
              onClick={() => setViewMode('tree')}
              className={`flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded transition-colors ${
                viewMode === 'tree'
                  ? 'bg-slate-800 text-sky-300 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <FolderTree className="w-3.5 h-3.5" />
              <span>ट्री (Tree)</span>
            </button>
            <button
              onClick={() => setViewMode('flat')}
              className={`flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded transition-colors ${
                viewMode === 'flat'
                  ? 'bg-slate-800 text-sky-300 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <List className="w-3.5 h-3.5" />
              <span>सूची (Flat)</span>
            </button>
          </div>

          {viewMode === 'tree' && (
            <div className="flex items-center gap-1 text-[11px] text-slate-400">
              <button
                onClick={expandAll}
                className="hover:text-slate-200 px-1 py-0.5 rounded hover:bg-slate-800 transition-colors"
              >
                सभी खोलें
              </button>
              <span>·</span>
              <button
                onClick={collapseAll}
                className="hover:text-slate-200 px-1 py-0.5 rounded hover:bg-slate-800 transition-colors"
              >
                बंद करें
              </button>
            </div>
          )}
        </div>

        {/* Search input */}
        <div className="relative">
          <Search className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-2.5" />
          <input
            type="text"
            placeholder="फ़ाइल खोजें (Search path/name)..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-8 pr-3 py-1.5 text-xs bg-slate-900 border border-slate-800 rounded-lg text-slate-200 placeholder-slate-500 focus:outline-none focus:border-sky-500"
          />
        </div>

        {/* Extension filter chips */}
        {viewMode === 'flat' && extensions.length > 0 && (
          <div className="flex items-center gap-1 overflow-x-auto pb-1 text-[11px] text-slate-400">
            <span className="shrink-0 text-slate-400 mr-1">एक्सटेंशन:</span>
            <button
              onClick={() => setFilterExt('all')}
              className={`px-1.5 py-0.5 rounded text-[10px] font-mono shrink-0 transition-colors ${
                filterExt === 'all' ? 'bg-sky-900/80 text-sky-200' : 'bg-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              सभी ({files.filter((f) => !f.isDirectory).length})
            </button>
            {extensions.slice(0, 8).map((ext) => (
              <button
                key={ext}
                onClick={() => setFilterExt(ext)}
                className={`px-1.5 py-0.5 rounded text-[10px] font-mono shrink-0 transition-colors ${
                  filterExt === ext ? 'bg-sky-900/80 text-sky-200' : 'bg-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                .{ext}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* List content container */}
      <div className="flex-1 overflow-y-auto p-2 space-y-0.5">
        {viewMode === 'tree' ? (
          renderTreeNode(tree)
        ) : filteredFlatFiles.length === 0 ? (
          <div className="p-6 text-center text-xs text-slate-400">
            कोई मेल खाती फ़ाइल नहीं मिली।
          </div>
        ) : (
          filteredFlatFiles.map((file) => {
            const isSelected = selectedFile?.path === file.path;
            return (
              <div
                key={file.path}
                onClick={() => onSelectFile(file)}
                className={`flex items-center gap-2 px-2.5 py-2 rounded cursor-pointer transition-colors text-xs font-mono ${
                  isSelected
                    ? 'bg-sky-950/80 text-sky-200 border-l-2 border-sky-400 font-medium'
                    : 'text-slate-300 hover:bg-slate-800/60'
                }`}
              >
                {getFileIcon(file)}
                <div className="flex-1 min-w-0">
                  <div className="truncate font-medium text-slate-200">{file.name}</div>
                  <div className="text-[10px] text-slate-400 truncate">{file.directory || '/'}</div>
                </div>
                <div className="text-[10px] text-slate-400 font-mono shrink-0 text-right">
                  {formatBytes(file.size)}
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Footer count */}
      <div className="px-3 py-2 bg-slate-950/90 border-t border-slate-800 text-[11px] text-slate-400 flex items-center justify-between font-mono">
        <span>कुल फ़ाइलें: {files.filter((f) => !f.isDirectory).length}</span>
        <span>फ़ोल्डर्स: {files.filter((f) => f.isDirectory).length}</span>
      </div>
    </div>
  );
};
