import React from 'react';
import { 
  Youtube, 
  PhoneCall, 
  MessageCircle, 
  Code2, 
  Palette, 
  Mic, 
  MessageSquare, 
  ChevronRight, 
  Heart, 
  Bot, 
  BookOpen, 
  Smile, 
  Volume2, 
  RotateCcw, 
  Activity, 
  Sparkles, 
  Check,
  Sliders,
} from 'lucide-react';
import type { AvatarStyle } from './ZoyaAvatarDisplay';

interface ZoyaQuickActionsPanelProps {
  onOpenAppLauncher: () => void;
  onOpenPhoneCall: () => void;
  onOpenMessageComposer: () => void;
  onOpenWebsiteBuilder: () => void;
  onOpenSketchCanvas: () => void;
  onOpenVoiceCall: () => void;
  onOpenTextChat: () => void;
  // Side Large Options Props
  personaMode: string;
  onSetPersonaMode: (mode: string) => void;
  avatarStyle: AvatarStyle;
  onSetAvatarStyle: (style: AvatarStyle) => void;
  onTestVoiceSpeech: () => void;
  onResetChat: () => void;
  onOpenDiagnostic: () => void;
  onOpenSettings: () => void;
  isSpeaking: boolean;
}

export const ZoyaQuickActionsPanel: React.FC<ZoyaQuickActionsPanelProps> = ({
  onOpenAppLauncher,
  onOpenPhoneCall,
  onOpenMessageComposer,
  onOpenWebsiteBuilder,
  onOpenSketchCanvas,
  onOpenVoiceCall,
  onOpenTextChat,
  personaMode,
  onSetPersonaMode,
  avatarStyle,
  onSetAvatarStyle,
  onTestVoiceSpeech,
  onResetChat,
  onOpenDiagnostic,
  onOpenSettings,
  isSpeaking,
}) => {
  const quickActions = [
    {
      id: 'app',
      title: 'Open an app',
      subtext: 'जैसे "YouTube kholo"',
      actionText: 'ऐप खोलें',
      icon: Youtube,
      color: 'from-red-500 via-rose-500 to-red-600',
      borderHover: 'hover:border-red-500/50',
      shadow: 'hover:shadow-[0_0_20px_rgba(239,68,68,0.25)]',
      onClick: onOpenAppLauncher,
    },
    {
      id: 'call',
      title: 'Call someone',
      subtext: 'जैसे "Mummy ko call karo"',
      actionText: 'कॉल लगाएँ',
      icon: PhoneCall,
      color: 'from-emerald-400 via-teal-500 to-green-600',
      borderHover: 'hover:border-emerald-500/50',
      shadow: 'hover:shadow-[0_0_20px_rgba(16,185,129,0.25)]',
      onClick: onOpenPhoneCall,
    },
    {
      id: 'message',
      title: 'Send a message',
      subtext: 'जैसे "Papa ko WhatsApp karo"',
      actionText: 'मैसेज भेजें',
      icon: MessageCircle,
      color: 'from-green-500 via-emerald-500 to-teal-600',
      borderHover: 'hover:border-green-500/50',
      shadow: 'hover:shadow-[0_0_20px_rgba(34,197,94,0.25)]',
      onClick: onOpenMessageComposer,
    },
    {
      id: 'website',
      title: 'Build a website',
      subtext: 'जैसे "ek cafe ki website banao"',
      actionText: 'वेबसाइट बनाएँ',
      icon: Code2,
      color: 'from-purple-500 via-indigo-600 to-purple-700',
      borderHover: 'hover:border-purple-500/50',
      shadow: 'hover:shadow-[0_0_20px_rgba(168,85,247,0.25)]',
      onClick: onOpenWebsiteBuilder,
    },
    {
      id: 'sketch',
      title: 'Sketch a photo',
      subtext: 'जैसे "drawing banao"',
      actionText: 'ड्राइंग स्टूडियो',
      icon: Palette,
      color: 'from-amber-400 via-orange-500 to-pink-500',
      borderHover: 'hover:border-amber-500/50',
      shadow: 'hover:shadow-[0_0_20px_rgba(245,158,11,0.25)]',
      onClick: onOpenSketchCanvas,
    },
    {
      id: 'voice',
      title: 'Talk to LIA / Zoya',
      subtext: 'Start a voice conversation',
      actionText: 'वॉयस कॉल शुरू करें',
      icon: Mic,
      color: 'from-sky-400 via-blue-500 to-indigo-600',
      borderHover: 'hover:border-sky-500/50',
      shadow: 'hover:shadow-[0_0_20px_rgba(56,189,248,0.25)]',
      onClick: onOpenVoiceCall,
    },
    {
      id: 'chat',
      title: 'Ask anything',
      subtext: 'Start a text conversation',
      actionText: 'चैट विंडो खोलें',
      icon: MessageSquare,
      color: 'from-pink-500 via-rose-500 to-fuchsia-600',
      borderHover: 'hover:border-pink-500/50',
      shadow: 'hover:shadow-[0_0_20px_rgba(236,72,153,0.25)]',
      onClick: onOpenTextChat,
    },
  ];

  const modes = [
    {
      id: 'girlfriend' as const,
      title: 'गर्लफ्रेंड मोड',
      desc: 'प्यार, अपनापन व फिक्र',
      endearment: '"बाबू", "डार्लिंग", "जान"',
      icon: Heart,
      color: 'border-pink-500 bg-pink-950/40 text-pink-200',
      activeBadge: 'bg-pink-500 text-white',
    },
    {
      id: 'assistant' as const,
      title: 'स्मार्ट असिस्टेंट',
      desc: 'दक्ष, तेज व उत्पादक',
      endearment: '"Boss", "Sir"',
      icon: Bot,
      color: 'border-sky-500 bg-sky-950/40 text-sky-200',
      activeBadge: 'bg-sky-500 text-white',
    },
    {
      id: 'study' as const,
      title: 'स्टडी पार्टनर',
      desc: 'पढ़ाई, नोट्स व सहायता',
      endearment: '"Scholar", "विद्यार्थी"',
      icon: BookOpen,
      color: 'border-amber-500 bg-amber-950/40 text-amber-200',
      activeBadge: 'bg-amber-500 text-white',
    },
    {
      id: 'friend' as const,
      title: 'बेस्ट फ्रेंड',
      desc: 'मस्ती, गपशप व दोस्ती',
      endearment: '"Buddy", "दोस्त"',
      icon: Smile,
      color: 'border-emerald-500 bg-emerald-950/40 text-emerald-200',
      activeBadge: 'bg-emerald-500 text-white',
    },
  ];

  return (
    <div className="w-full space-y-6">
      {/* SECTION 1: THE 7 QUICK ACTION CARDS */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-pink-400" />
            <h3 className="text-sm sm:text-base font-bold text-slate-100 tracking-tight">
              क्विक एक्शंस (Quick Actions)
            </h3>
          </div>
          <span className="text-[11px] font-mono text-slate-400">
            7 एक्टिव फीचर्स
          </span>
        </div>

        {/* 7 Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
          {quickActions.map((action) => {
            const Icon = action.icon;
            return (
              <div
                key={action.id}
                onClick={action.onClick}
                className={`p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800/90 ${action.borderHover} ${action.shadow} cursor-pointer transition-all duration-200 flex flex-col justify-between group hover:-translate-y-0.5`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div
                    className={`w-10 h-10 rounded-xl bg-gradient-to-tr ${action.color} flex items-center justify-center text-white shrink-0 shadow-md group-hover:scale-105 transition-transform`}
                  >
                    <Icon className="w-5 h-5" />
                  </div>
                  <span className="text-[10px] font-mono font-medium text-slate-400 px-2 py-0.5 rounded-full bg-slate-950 border border-slate-800/80 group-hover:text-slate-200">
                    {action.actionText}
                  </span>
                </div>

                <div className="mt-3">
                  <h4 className="text-sm font-bold text-slate-100 group-hover:text-white transition-colors">
                    {action.title}
                  </h4>
                  <p className="text-xs text-slate-400 mt-0.5 font-sans">
                    {action.subtext}
                  </p>
                </div>

                <div className="mt-3 pt-2.5 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400 group-hover:text-sky-300 transition-colors font-medium">
                  <span>शुरू करें</span>
                  <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* SECTION 2: SIDE / LARGE OPTIONS (साइड में दिखने वाले सभी बड़े ऑप्शन) */}
      <div className="space-y-4 pt-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sliders className="w-4 h-4 text-sky-400" />
            <h3 className="text-sm sm:text-base font-bold text-slate-100 tracking-tight">
              असिस्टेंट प्राथमिक मोड व सेटिंग्स (Persona &amp; Core Settings)
            </h3>
          </div>
          <span className="text-[11px] font-mono text-slate-400">
            वास्तविक फ़ंक्शन नियंत्रण
          </span>
        </div>

        {/* 4 Large Persona Mode Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {modes.map((m) => {
            const Icon = m.icon;
            const isSelected = personaMode === m.id;
            return (
              <div
                key={m.id}
                onClick={() => onSetPersonaMode(m.id)}
                className={`p-3.5 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between ${
                  isSelected
                    ? `${m.color} shadow-lg scale-[1.01]`
                    : 'bg-slate-900/80 border-slate-800 text-slate-400 hover:border-slate-700 hover:bg-slate-850'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Icon className="w-4 h-4 shrink-0" />
                    <span className="font-bold text-xs text-slate-100">{m.title}</span>
                  </div>
                  {isSelected && (
                    <span className="w-4 h-4 rounded-full bg-emerald-500 text-slate-950 flex items-center justify-center">
                      <Check className="w-2.5 h-2.5 stroke-[3]" />
                    </span>
                  )}
                </div>

                <div className="mt-2 text-xs text-slate-300">
                  {m.desc}
                </div>

                <div className="mt-2.5 pt-2 border-t border-slate-800/80 text-[10px] text-slate-400 font-mono">
                  संबोधन: <strong className="text-slate-200">{m.endearment}</strong>
                </div>
              </div>
            );
          })}
        </div>

        {/* Secondary Big Action Cards Row */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {/* Card 1: 3D Avatar Style Selector */}
          <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-200">3D अवतार स्टाइल</span>
              <span className="text-[10px] font-mono text-pink-400">लाइव रेंडर</span>
            </div>
            <p className="text-xs text-slate-400">
              क्लासिक 3D प्रिंसेस या मॉडर्न एनिमे अवतार में तुरंत स्विच करें:
            </p>
            <div className="grid grid-cols-1 gap-2">
              <button
                onClick={() => onSetAvatarStyle('classic')}
                className="py-2 px-3 rounded-xl border text-xs font-semibold bg-sky-950 border-sky-500 text-sky-200 shadow-sm flex items-center justify-center gap-2"
              >
                <Check className="w-3.5 h-3.5 text-sky-400" />
                <span>क्लासिक 3D (Active)</span>
              </button>
            </div>
          </div>

          {/* Card 2: Voice Pipeline Audio Test */}
          <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-3 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-200">वॉयस व स्पीच टेस्ट</span>
                <span className="text-[10px] font-mono text-emerald-400">
                  {isSpeaking ? 'बोल रही है...' : 'तैयार'}
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-1">
                टीटीएस स्पीच पाइपलाइन को टेस्ट करने के लिए आवाज़ सुनकर सत्यापित करें:
              </p>
            </div>

            <button
              onClick={onTestVoiceSpeech}
              className="w-full flex items-center justify-center gap-2 py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-colors shadow-sm"
            >
              <Volume2 className="w-3.5 h-3.5" />
              <span>आवाज़ टेस्ट चलाएँ (Speak)</span>
            </button>
          </div>

          {/* Card 3: System Diagnostics & Memory Reset */}
          <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-3 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-200">सिस्टम टूल्स व डायग्नोस्टिक</span>
                <span className="text-[10px] font-mono text-sky-400">हेल्थ रिपोर्ट</span>
              </div>
              <p className="text-xs text-slate-400 mt-1">
                माइक, ऑडियो व फाइल्स की हेल्थ चेक या बातचीत मेमोरी को रीसेट करें:
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={onOpenDiagnostic}
                className="flex-1 flex items-center justify-center gap-1.5 py-2 px-2.5 rounded-xl bg-slate-800 hover:bg-slate-750 border border-slate-700 text-slate-200 text-xs font-semibold transition-colors"
              >
                <Activity className="w-3.5 h-3.5 text-sky-400" />
                <span>हेल्थ चेक</span>
              </button>

              <button
                onClick={onResetChat}
                className="flex-1 flex items-center justify-center gap-1.5 py-2 px-2.5 rounded-xl bg-slate-800 hover:bg-slate-750 border border-slate-700 text-slate-200 text-xs font-semibold transition-colors"
                title="चैट मेमोरी साफ़ करें"
              >
                <RotateCcw className="w-3.5 h-3.5 text-amber-400" />
                <span>रीसेट चैट</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
