import React, { useEffect, useState } from 'react';
import { Square } from 'lucide-react';
import { micStateMachine, MicStateSnapshot } from '../../services/speech/MicStateMachine';
import { useGlobalMic } from '../../contexts/GlobalMicContext';
import { useAudioLevel } from '../../services/speech/audioLevelStore';

interface ZoyaSmallListeningIndicatorProps {
  recLanguage?: string;
  className?: string;
  variant?: 'floating' | 'inline';
  isHandsFreeActive?: boolean;
  onStopHandsFree?: () => void;
  personaMode?: string;
}

/**
 * Global corner mic indicator visible across EVERY mode, screen, tab, and modal.
 * - Mic ON (listening / silence / reconnecting): Green "सुन रहा है"
 * - User speaking: Subtle animated wave bars ("हल्का एनिमेशन")
 * - AI speaking: "बोल रहा है"
 * - Includes dedicated "बंद करें" Stop button right on the indicator.
 * - Mic OFF: Displays "माइक बंद".
 */
export const ZoyaSmallListeningIndicator: React.FC<ZoyaSmallListeningIndicatorProps> = ({
  className = '',
  variant = 'floating',
  isHandsFreeActive,
  onStopHandsFree,
}) => {
  const [snapshot, setSnapshot] = useState<MicStateSnapshot>(() => micStateMachine.getSnapshot());
  const {
    isGlobalMicOn,
    micPhase,
    isUserSpeaking,
    requestStopGlobalMic,
  } = useGlobalMic();
  const audioLevel = useAudioLevel();

  useEffect(() => {
    const unsubscribe = micStateMachine.subscribe((newSnap) => {
      setSnapshot(newSnap);
    });
    return unsubscribe;
  }, []);

  const micActive =
    typeof isHandsFreeActive === 'boolean'
      ? isHandsFreeActive || isGlobalMicOn || snapshot.handsFreeContinuous
      : isGlobalMicOn || snapshot.handsFreeContinuous;

  const aiSpeaking =
    micActive && (micPhase === 'ai_speaking' || snapshot.state === 'SPEAKING');

  const userSpeakingActive =
    micActive &&
    !aiSpeaking &&
    (micPhase === 'user_speaking' ||
      isUserSpeaking ||
      snapshot.isUserSpeaking ||
      Math.max(audioLevel, snapshot.audioLevel) > 0.035);

  const handleStop = () => {
    if (onStopHandsFree) {
      onStopHandsFree();
    } else {
      requestStopGlobalMic();
    }
  };

  const getBadgeContent = () => {
    if (!micActive) {
      if (snapshot.state === 'PAUSED_BY_CALL') {
        return {
          label: 'कॉल चालू है',
          dotClass: 'bg-amber-400 shadow-[0_0_8px_rgba(251,191,36,0.6)]',
          bgClass: 'bg-amber-950/85 border-amber-500/45 text-amber-100',
          pulse: false,
          userWave: false,
        };
      }
      return {
        label: 'माइक बंद',
        dotClass: 'bg-slate-500 shadow-none',
        bgClass: 'bg-slate-900/80 border-slate-700/60 text-slate-300',
        pulse: false,
        userWave: false,
      };
    }

    if (aiSpeaking) {
      return {
        label: 'बोल रहा है',
        dotClass: 'bg-purple-400 animate-pulse shadow-[0_0_12px_rgba(192,132,252,0.9)]',
        bgClass: 'bg-purple-950/90 border-purple-400/70 text-purple-100',
        pulse: true,
        userWave: false,
      };
    }

    // Active listening (also stays green "सुन रहा है" during silence or silent auto-reconnect)
    return {
      label: 'सुन रहा है',
      dotClass: userSpeakingActive
        ? 'bg-emerald-300 animate-ping shadow-[0_0_14px_rgba(52,211,153,1)]'
        : 'bg-emerald-400 animate-pulse shadow-[0_0_10px_rgba(52,211,153,0.9)]',
      bgClass: userSpeakingActive
        ? 'bg-emerald-900/95 border-emerald-300 text-emerald-50 shadow-[0_0_18px_rgba(16,185,129,0.45)] scale-[1.03]'
        : 'bg-emerald-950/90 border-emerald-400/65 text-emerald-100',
      pulse: true,
      userWave: userSpeakingActive,
    };
  };

  const badge = getBadgeContent();
  const isInline = variant === 'inline';

  return (
    <div
      aria-live="polite"
      aria-label={`माइक स्थिति: ${badge.label}`}
      data-testid="zoya-listening-status-indicator"
      className={
        isInline
          ? `inline-flex items-center select-none ${className}`
          : `fixed top-14 right-3 sm:top-16 sm:right-4 z-[9999] pointer-events-auto select-none transition-all duration-300 ease-out ${className}`
      }
      style={
        isInline
          ? undefined
          : {
              paddingTop: 'env(safe-area-inset-top, 0px)',
              paddingRight: 'env(safe-area-inset-right, 0px)',
            }
      }
    >
      <div
        className={`flex items-center gap-2 px-3 py-1.5 rounded-full border backdrop-blur-md text-[11.5px] font-medium tracking-wide shadow-lg ${badge.bgClass} transition-all duration-300`}
      >
        {/* Status Dot */}
        <span className="relative flex h-2.5 w-2.5 shrink-0">
          {badge.pulse && (
            <span
              className={`absolute inline-flex h-full w-full rounded-full opacity-75 ${badge.dotClass}`}
            />
          )}
          <span
            className={`relative inline-flex rounded-full h-2.5 w-2.5 transition-all duration-300 ${badge.dotClass}`}
          />
        </span>

        {/* Subtle Speaking Wave Animation when User Speaks */}
        {badge.userWave && (
          <span
            data-testid="user-speaking-animation"
            className="inline-flex items-end gap-[2px] h-3 mx-0.5"
            aria-hidden="true"
          >
            <span className="w-[2.5px] h-2 bg-emerald-300 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
            <span className="w-[2.5px] h-3 bg-emerald-200 rounded-full animate-bounce" style={{ animationDelay: '120ms' }} />
            <span className="w-[2.5px] h-2 bg-emerald-300 rounded-full animate-bounce" style={{ animationDelay: '240ms' }} />
          </span>
        )}

        {/* Hindi Status Text */}
        <span className="font-semibold text-[11.5px] leading-tight whitespace-nowrap">
          {badge.label}
        </span>

        {/* Dedicated Manual Stop Button directly on the corner indicator */}
        {micActive && (
          <button
            type="button"
            onClick={handleStop}
            data-testid="hands-free-stop-btn"
            className="ml-1 inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-rose-600/95 hover:bg-rose-500 text-white text-[10.5px] font-bold border border-rose-300/40 shadow-sm active:scale-95 transition-all cursor-pointer pointer-events-auto"
            title="माइक बंद करें"
          >
            <Square className="w-2.5 h-2.5 fill-white" />
            <span>बंद करें</span>
          </button>
        )}
      </div>
    </div>
  );
};
