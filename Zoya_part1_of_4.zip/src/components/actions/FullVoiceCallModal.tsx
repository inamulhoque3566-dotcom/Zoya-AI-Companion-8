import React, { useState, useEffect, useRef } from 'react';
import { 
  X, 
  Mic, 
  MicOff, 
  PhoneOff, 
  Volume2, 
  VolumeX, 
  Sparkles, 
  Heart,
  Bot
} from 'lucide-react';

import {
  getLanguageConfig,
  getLocalizedZoyaReply,
} from '../../services/languageConfig';
import { micStateMachine } from '../../services/speech/MicStateMachine';
import { agentClient } from '../../services/agent/agentClient';

import type {
  AvatarStyle,
} from '../ZoyaAvatarDisplay';
import {
  getIs3DAvatarEnabled,
  getSelected3DAvatar,
} from '../../data/anime3DAvatars';
import { BlinkingAvatarImage } from '../avatar/BlinkingAvatarImage';

interface FullVoiceCallModalProps {
  isOpen: boolean;
  onClose: () => void;
  avatarStyle: AvatarStyle;
  language?: string;
  personaMode?: string;
  onUserSpoke?: (text: string) => boolean | void;
}

export const FullVoiceCallModal: React.FC<FullVoiceCallModalProps> = ({
  isOpen,
  onClose,
  avatarStyle,
  language = 'hi-IN',
  personaMode = 'girlfriend',
  onUserSpoke,
}) => {
  const langConfig = getLanguageConfig(language);
  const [callDuration, setCallDuration] = useState(0);
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [lastZoyaReply, setLastZoyaReply] = useState(langConfig.sampleGreeting);

  const speechRecognitionRef = useRef<any>(null);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const activeAudioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    if (isOpen) {
      // Pause central mic and native wake word for exclusive full voice call audio
      micStateMachine.requestPauseForCall('voice_call');
      setCallDuration(0);
      setLastZoyaReply(langConfig.sampleGreeting);
      timerRef.current = setInterval(() => {
        setCallDuration((p) => p + 1);
      }, 1000);

      // Start initial greeting
      speakText(langConfig.sampleGreeting);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
      if (activeAudioRef.current) {
        try {
          activeAudioRef.current.pause();
          activeAudioRef.current.src = '';
        } catch {}
        activeAudioRef.current = null;
      }
      stopListening();
      micStateMachine.requestResumeAfterCall('voice_call');
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
      if (activeAudioRef.current) {
        try {
          activeAudioRef.current.pause();
          activeAudioRef.current.src = '';
        } catch {}
        activeAudioRef.current = null;
      }
      stopListening();
      micStateMachine.requestResumeAfterCall('voice_call');
    };
  }, [isOpen, langConfig.code]);

  const speakText = async (text: string) => {
    if (activeAudioRef.current) {
      try {
        activeAudioRef.current.pause();
        activeAudioRef.current.src = '';
      } catch {}
      activeAudioRef.current = null;
    }

    setIsSpeaking(true);
    try {
      let geminiApiKey = '';
      let elevenLabsVoiceId = '';
      try {
        geminiApiKey = localStorage.getItem('zoya_gemini_api_key') || '';
        elevenLabsVoiceId = localStorage.getItem('zoya_elevenlabs_voice_id') || '';
      } catch {}

      const res = await fetch('/api/tts', {
        method: 'POST',
        headers: agentClient.getOwnerFetchHeaders({ 'Content-Type': 'application/json' }),
        credentials: 'include',
        body: JSON.stringify({
          text,
          personaMode,
          language: langConfig.code,
          geminiApiKey: geminiApiKey || undefined,
          elevenLabsVoiceId: elevenLabsVoiceId || undefined,
        }),
      });

      const contentType = res.headers.get('content-type') || '';
      let data: any = null;
      if (contentType.includes('application/json')) {
        try {
          data = await res.json();
        } catch {}
      }

      if (data?.audioData) {
        const audio = new Audio(`data:${data.mimeType || 'audio/wav'};base64,${data.audioData}`);
          activeAudioRef.current = audio;
          audio.onended = () => {
            activeAudioRef.current = null;
            setIsSpeaking(false);
            startListening();
          };
          audio.onerror = () => {
            activeAudioRef.current = null;
            setIsSpeaking(false);
            startListening();
          };
          await audio.play();
          return;
        }
    } catch (err) {
      console.warn('[VOICE_CALL_MODAL] Neural TTS error:', err);
    }

    setIsSpeaking(false);
    startListening();
  };

  const startListening = () => {
    if (isMuted) return;
    const SpeechRec = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRec) return;

    try {
      const rec = new SpeechRec();
      rec.lang = langConfig.sttSupported ? langConfig.code : langConfig.fallbackVoiceLang;
      rec.continuous = false;
      rec.interimResults = true;

      rec.onstart = () => setIsListening(true);
      rec.onresult = (e: any) => {
        const text = e.results[0][0].transcript;
        setTranscript(text);
        if (e.results[0].isFinal) {
          handleIncomingVoice(text);
        }
      };
      rec.onerror = () => setIsListening(false);
      rec.onend = () => setIsListening(false);

      speechRecognitionRef.current = rec;
      rec.start();
    } catch {
      setIsListening(false);
    }
  };

  const stopListening = () => {
    if (speechRecognitionRef.current) {
      try {
        speechRecognitionRef.current.abort();
      } catch {}
      speechRecognitionRef.current = null;
    }
    setIsListening(false);
  };

  const handleIncomingVoice = async (text: string) => {
    stopListening();
    const handledExternally = onUserSpoke?.(text);
    if (handledExternally === true) {
      return;
    }

    let reply = '';
    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: text,
          personaMode,
          language: langConfig.code,
        }),
      });
      if (res.ok) {
        const data = await res.json();
        if (data?.reply) reply = data.reply;
      }
    } catch {}

    if (!reply) {
      reply = getLocalizedZoyaReply(text, personaMode, langConfig.code);
    }

    setLastZoyaReply(reply);
    speakText(reply);
  };

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60).toString().padStart(2, '0');
    const s = (secs % 60).toString().padStart(2, '0');
    return `${m}:${s}`;
  };

  const is3DActive = getIs3DAvatarEnabled();
  const activeAvatar = getSelected3DAvatar();
  const avatarId = is3DActive ? activeAvatar.id : avatarStyle;
  const avatarSrc = is3DActive
    ? activeAvatar.transparentPng
    : '/assets/images/zoya_new_avatar_transparent.png';

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/95 backdrop-blur-xl animate-fade-in">
      <div className="relative w-full max-w-md bg-gradient-to-b from-slate-900 to-slate-950 rounded-3xl border border-slate-800 shadow-2xl p-6 flex flex-col items-center justify-between min-h-[580px]">
        {/* Top Header */}
        <div className="w-full flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="font-mono text-emerald-400 font-bold">लाइव वॉयस कॉल (HD Voice)</span>
          </div>

          <div className="font-mono text-slate-300 bg-slate-950 px-3 py-1 rounded-full border border-slate-800">
            {formatTime(callDuration)}
          </div>
        </div>

        {/* Center Reactive 3D Avatar & Sound Orb */}
        <div className="relative my-6 flex flex-col items-center justify-center">
          {/* Animated Glow Halo */}
          <div
            className={`absolute w-56 h-56 sm:w-64 sm:h-64 rounded-full blur-3xl transition-all duration-500 pointer-events-none ${
              isSpeaking
                ? 'bg-pink-500/40 scale-125'
                : isListening
                ? 'bg-sky-500/40 scale-110'
                : 'bg-purple-500/25 scale-100'
            }`}
          />

          {/* Avatar Image with Natural Eyelid Blinking */}
          <div className="relative z-10 w-44 h-56 sm:w-52 sm:h-64 flex items-center justify-center">
            <BlinkingAvatarImage
              avatarId={avatarId}
              src={avatarSrc}
              alt="Zoya Live Call Avatar"
              imageClassName={`transition-transform duration-300 ${
                isSpeaking ? 'scale-105 animate-pulse' : ''
              }`}
            />
          </div>

          <div className="relative z-10 mt-3 text-center">
            <h3 className="text-lg font-bold text-slate-100 flex items-center justify-center gap-1.5">
              <span>जोया (Zoya)</span>
              <Sparkles className="w-4 h-4 text-pink-400" />
            </h3>
            <p className="text-xs text-slate-400 font-mono mt-0.5">
              {isSpeaking ? 'बोल रही है...' : isListening ? 'आपकी बात सुन रही है...' : 'लाइव कनेक्टेड'}
            </p>
          </div>
        </div>

        {/* Live Subtitle Transcript Banner */}
        <div className="w-full p-4 rounded-2xl bg-slate-900/90 border border-slate-800 text-center text-xs sm:text-sm text-slate-200 shadow-xl leading-relaxed">
          {transcript && isListening ? (
            <span className="text-sky-300 font-medium">आप बोल रहे हैं: &ldquo;{transcript}&rdquo;</span>
          ) : (
            <span>&ldquo;{lastZoyaReply}&rdquo;</span>
          )}
        </div>

        {/* Call Controls Dock */}
        <div className="w-full flex items-center justify-center gap-6 mt-4">
          <button
            onClick={() => {
              setIsMuted(!isMuted);
              if (!isMuted) stopListening();
              else startListening();
            }}
            className={`p-4 rounded-full border transition-colors ${
              isMuted
                ? 'bg-rose-950/80 border-rose-800 text-rose-300'
                : 'bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-800'
            }`}
            title="माइक म्यूट/अनम्यूट"
          >
            {isMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
          </button>

          <button
            onClick={onClose}
            className="w-16 h-16 rounded-full bg-red-600 hover:bg-red-500 text-white flex items-center justify-center shadow-[0_0_30px_rgba(239,68,68,0.5)] transition-transform hover:scale-105"
            title="कॉल समाप्त करें (End Call)"
          >
            <PhoneOff className="w-7 h-7" />
          </button>

          <button
            onClick={() => {
              startListening();
            }}
            className="p-4 rounded-full bg-slate-900 border border-slate-800 text-sky-400 hover:bg-slate-800 transition-colors"
            title="जोया से बात करें"
          >
            <Volume2 className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
};
