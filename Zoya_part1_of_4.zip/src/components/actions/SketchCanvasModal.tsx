import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  X,
  Download,
  Upload,
  Play,
  Pause,
  RotateCcw,
  Eye,
  Pencil,
  ChevronDown,
  ChevronUp,
  Image as ImageIcon,
  Layers,
  CheckCircle2,
  Sparkles,
} from 'lucide-react';
import {
  analyzePhotoForPencilDrawing,
  loadSketchImageFromFile,
  loadSketchImageFromDataUrl,
  renderStrokeSegment,
  createSampleTestPhotoDataUrl,
  PENCIL_STYLE_PROFILES,
  type AnalyzedPencilPlan,
  type DrawingStage,
  type PencilStyleId,
} from '../../services/image/pencilDrawingEngine';
import { Pencil3DStage, type PencilTargetState } from './Pencil3DStage';

interface SketchCanvasModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialFile?: File | null;
}

const STAGE_LABELS: Record<DrawingStage | 'complete', string> = {
  outlines: 'Stage 1/4 · Drawing Structural Outlines',
  details: 'Stage 2/4 · Sketching Facial & Fine Details',
  shading: 'Stage 3/4 · Layering Tonal Cross-Hatching',
  shadows: 'Stage 4/4 · Deepening Graphite Shadows',
  complete: 'Master Pencil Sketch Complete',
};

const STYLE_ORDER: PencilStyleId[] = [
  'realistic-graphite',
  'detailed-3d',
  'fine-line',
  'shaded-portrait',
];

const SPEED_OPTIONS = [0.5, 1, 2, 4] as const;

export const SketchCanvasModal: React.FC<SketchCanvasModalProps> = ({
  isOpen,
  onClose,
  initialFile = null,
}) => {
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const paperCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const lastInitialFileRef = useRef<File | null>(null);

  // Source photo state (kept separately from output sketch)
  const [sourceImage, setSourceImage] = useState<HTMLImageElement | null>(null);
  const [sourceDataUrl, setSourceDataUrl] = useState<string | null>(null);
  const [imageMeta, setImageMeta] = useState<{
    width: number;
    height: number;
    fileName: string;
  } | null>(null);

  // Analysis & Drawing Plan state
  const [pencilStyle, setPencilStyle] = useState<PencilStyleId>('realistic-graphite');
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [analysisProgress, setAnalysisProgress] = useState<number>(0);
  const [analysisLabel, setAnalysisLabel] = useState<string>('');
  const [plan, setPlan] = useState<AnalyzedPencilPlan | null>(null);

  // Playback HUD state (synced at throttled cadence from animation loop)
  const [isPaused, setIsPaused] = useState<boolean>(false);
  const [speed, setSpeed] = useState<number>(1);
  const [isComplete, setIsComplete] = useState<boolean>(false);
  const [drawProgressPct, setDrawProgressPct] = useState<number>(0);
  const [currentStage, setCurrentStage] = useState<DrawingStage | 'complete'>('outlines');
  const [strokeCountHud, setStrokeCountHud] = useState<{ done: number; total: number }>({
    done: 0,
    total: 0,
  });
  const [showOriginal, setShowOriginal] = useState<boolean>(false);
  const [dockCollapsed, setDockCollapsed] = useState<boolean>(false);
  const [finishedSketchUrl, setFinishedSketchUrl] = useState<string | null>(null);
  const [dragOver, setDragOver] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Refs shared with WebGL 3D Pencil & 2D Stroke Animation Loop
  const isPausedRef = useRef<boolean>(false);
  isPausedRef.current = isPaused;
  const speedRef = useRef<number>(1);
  speedRef.current = speed;

  const pencilTargetRef = useRef<PencilTargetState>({
    normX: 0.5,
    normY: 0.5,
    isTouching: false,
    isActive: false,
    isComplete: false,
    strokeAngleRad: 0,
    pressure: 0.5,
    stage: 'outlines',
  });

  // Mutable animation cursor
  const animCursorRef = useRef<{
    strokeIdx: number;
    strokeT: number;
    travelRemaining: number;
    travelFromX: number;
    travelFromY: number;
    travelToX: number;
    travelToY: number;
    finished: boolean;
  }>({
    strokeIdx: 0,
    strokeT: 0,
    travelRemaining: 0,
    travelFromX: 0.2,
    travelFromY: 0.2,
    travelToX: 0.2,
    travelToY: 0.2,
    finished: false,
  });

  const drawingRafRef = useRef<number>(0);

  // Helper: Draw clean cold-press cotton paper background & reset playback cursor
  const resetPaperAndCursor = useCallback((activePlan: AnalyzedPencilPlan) => {
    const canvas = paperCanvasRef.current;
    if (canvas) {
      if (canvas.width !== activePlan.width || canvas.height !== activePlan.height) {
        canvas.width = activePlan.width;
        canvas.height = activePlan.height;
      }
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.drawImage(activePlan.paperPatternCanvas, 0, 0, canvas.width, canvas.height);
      }
    }

    const firstPt = activePlan.strokes[0]?.points[0] || { x: 0.5, y: 0.5 };
    animCursorRef.current = {
      strokeIdx: 0,
      strokeT: 0,
      travelRemaining: 0.22,
      travelFromX: 0.85,
      travelFromY: 0.85,
      travelToX: firstPt.x,
      travelToY: firstPt.y,
      finished: false,
    };

    pencilTargetRef.current = {
      normX: firstPt.x,
      normY: firstPt.y,
      isTouching: false,
      isActive: true,
      isComplete: false,
      strokeAngleRad: 0,
      pressure: 0.5,
      stage: 'outlines',
    };

    setIsComplete(false);
    setFinishedSketchUrl(null);
    setIsPaused(false);
    setShowOriginal(false);
    setDrawProgressPct(0);
    setCurrentStage('outlines');
    setStrokeCountHud({ done: 0, total: activePlan.strokes.length });
  }, []);

  // Analyze uploaded HTMLImageElement and build stroke plan
  const runAnalysis = useCallback(
    async (img: HTMLImageElement, targetStyle: PencilStyleId) => {
      cancelAnimationFrame(drawingRafRef.current);
      setIsAnalyzing(true);
      setErrorMsg(null);
      setAnalysisProgress(8);
      setAnalysisLabel('Preparing image & cotton paper canvas...');
      setPlan(null);
      setFinishedSketchUrl(null);
      setIsComplete(false);

      try {
        const nextPlan = await analyzePhotoForPencilDrawing(img, targetStyle, (pct, lbl) => {
          setAnalysisProgress(pct);
          setAnalysisLabel(lbl);
        });
        setPlan(nextPlan);
        setIsAnalyzing(false);
      } catch (err) {
        console.error('[3D Pencil Engine] Analysis failed:', err);
        setIsAnalyzing(false);
        setErrorMsg('Could not analyze this image. Please try another photo.');
      }
    },
    []
  );

  // Load File -> HTMLImageElement -> Run Analysis
  const handleFile = useCallback(
    async (file: File) => {
      if (!file.type.startsWith('image/')) {
        setErrorMsg('Please select a valid photo (JPG, PNG, WEBP).');
        return;
      }
      setErrorMsg(null);
      setIsAnalyzing(true);
      setAnalysisProgress(4);
      setAnalysisLabel('Loading photo from device...');

      try {
        const img = await loadSketchImageFromFile(file);
        setSourceImage(img);
        setSourceDataUrl(img.src);
        setImageMeta({
          width: img.naturalWidth || img.width,
          height: img.naturalHeight || img.height,
          fileName: file.name,
        });
        await runAnalysis(img, pencilStyle);
      } catch (err) {
        console.error('[3D Pencil Engine] File load failed:', err);
        setIsAnalyzing(false);
        setErrorMsg('Failed to open selected photo. Please try another image.');
      }
    },
    [pencilStyle, runAnalysis]
  );

  // Load Built-in Sample Photo (Portrait / Object / Scenery)
  const handleSamplePreset = useCallback(
    async (preset: 'portrait' | 'object' | 'scenery') => {
      setErrorMsg(null);
      setIsAnalyzing(true);
      setAnalysisProgress(4);
      setAnalysisLabel(`Loading ${preset} reference photo...`);
      try {
        const url = createSampleTestPhotoDataUrl(preset);
        const img = await loadSketchImageFromDataUrl(url);
        setSourceImage(img);
        setSourceDataUrl(url);
        setImageMeta({
          width: img.naturalWidth || 720,
          height: img.naturalHeight || 720,
          fileName: `sample_${preset}.png`,
        });
        await runAnalysis(img, pencilStyle);
      } catch (err) {
        console.error('[3D Pencil Engine] Sample load failed:', err);
        setIsAnalyzing(false);
        setErrorMsg('Could not load sample photo.');
      }
    },
    [pencilStyle, runAnalysis]
  );

  // Handle incoming initialFile when opened from home action bar
  useEffect(() => {
    if (!isOpen) {
      cancelAnimationFrame(drawingRafRef.current);
      lastInitialFileRef.current = null;
      return;
    }
    if (initialFile && initialFile !== lastInitialFileRef.current) {
      lastInitialFileRef.current = initialFile;
      void handleFile(initialFile);
    }
  }, [isOpen, initialFile, handleFile]);

  // Keyboard shortcut: Space to Pause/Resume
  useEffect(() => {
    if (!isOpen || !plan) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Space' && !(e.target instanceof HTMLInputElement)) {
        e.preventDefault();
        if (!animCursorRef.current.finished) {
          setIsPaused((prev) => !prev);
        }
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [isOpen, plan]);

  // Progressive Stroke-by-Stroke Drawing Loop synchronized with 3D Pencil
  useEffect(() => {
    if (!isOpen || !plan) return;

    resetPaperAndCursor(plan);

    const canvas = paperCanvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx) return;

    const strokes = plan.strokes;
    const totalStrokes = strokes.length;
    if (totalStrokes === 0) {
      setIsComplete(true);
      setCurrentStage('complete');
      setDrawProgressPct(100);
      return;
    }

    // Total base drawing duration (~19 seconds at 1x speed across all 4 stages)
    const baseArcRate = Math.max(0.4, plan.totalArcLength / 18.5);
    let lastTs = performance.now();
    let lastHudSync = 0;

    const stepLoop = (now: number) => {
      const dt = Math.min(0.12, Math.max(0.001, (now - lastTs) / 1000));
      lastTs = now;

      const cur = animCursorRef.current;

      if (!cur.finished && !isPausedRef.current) {
        const curSpeed = speedRef.current;
        let arcBudget = baseArcRate * curSpeed * dt;

        // Handle smooth aerial travel hop between disconnected strokes
        if (cur.travelRemaining > 0) {
          const hopStep = dt * 6.5 * curSpeed;
          cur.travelRemaining = Math.max(0, cur.travelRemaining - hopStep);
          const hopProgress = 1 - cur.travelRemaining / 0.14;
          const eased = Math.min(1, Math.max(0, hopProgress));

          pencilTargetRef.current.normX =
            cur.travelFromX + (cur.travelToX - cur.travelFromX) * eased;
          pencilTargetRef.current.normY =
            cur.travelFromY + (cur.travelToY - cur.travelFromY) * eased;
          pencilTargetRef.current.isTouching = cur.travelRemaining === 0;
          pencilTargetRef.current.isActive = true;
          pencilTargetRef.current.isComplete = false;
        }

        if (cur.travelRemaining === 0) {
          // Draw progressive stroke segments within this frame's arc-length budget
          let safety = 0;
          while (arcBudget > 0 && cur.strokeIdx < totalStrokes && safety < 900) {
            safety++;
            const st = strokes[cur.strokeIdx];
            const stLen = Math.max(0.002, st.lengthNorm);

            // Speed multiplier slightly faster on dense shading passes so outlines feel deliberate & sculptural
            const stageBoost =
              st.stage === 'outlines'
                ? 0.9
                : st.stage === 'details'
                ? 1.05
                : st.stage === 'shading'
                ? 1.55
                : 1.45;

            const neededArc = (1 - cur.strokeT) * stLen;
            const stepArc = arcBudget * stageBoost;

            if (stepArc < neededArc) {
              const nextT = Math.min(1, cur.strokeT + stepArc / stLen);
              const pt = renderStrokeSegment(
                ctx,
                st,
                cur.strokeT,
                nextT,
                canvas.width,
                canvas.height
              );
              cur.strokeT = nextT;
              arcBudget = 0;

              const prevPt = st.points[Math.max(0, Math.floor(cur.strokeT * (st.points.length - 1)))];
              const pNext = st.points[Math.min(st.points.length - 1, Math.ceil(nextT * (st.points.length - 1)))];
              const ang = Math.atan2(pNext.y - prevPt.y, pNext.x - prevPt.x);

              pencilTargetRef.current.normX = pt.x;
              pencilTargetRef.current.normY = pt.y;
              pencilTargetRef.current.isTouching = true;
              pencilTargetRef.current.isActive = true;
              pencilTargetRef.current.isComplete = false;
              pencilTargetRef.current.strokeAngleRad = ang;
              pencilTargetRef.current.pressure = pt.pressure;
              pencilTargetRef.current.stage = st.stage;
            } else {
              // Finish current stroke cleanly
              const endPt = renderStrokeSegment(
                ctx,
                st,
                cur.strokeT,
                1.0,
                canvas.width,
                canvas.height
              );
              arcBudget -= neededArc / stageBoost;
              cur.strokeIdx++;
              cur.strokeT = 0;

              pencilTargetRef.current.normX = endPt.x;
              pencilTargetRef.current.normY = endPt.y;
              pencilTargetRef.current.isTouching = true;
              pencilTargetRef.current.stage = st.stage;

              if (cur.strokeIdx < totalStrokes) {
                const nextSt = strokes[cur.strokeIdx];
                const nextStart = nextSt.points[0];
                const jumpDist = Math.hypot(
                  nextStart.x - endPt.x,
                  nextStart.y - endPt.y
                );
                const isStructural =
                  nextSt.stage === 'outlines' || nextSt.stage === 'details';
                const hopThreshold = isStructural ? 0.085 : 0.28;
                // Visible pencil lift when moving across a significant region gap
                if (
                  jumpDist > hopThreshold &&
                  (isStructural || curSpeed < 2)
                ) {
                  cur.travelRemaining = 0.14;
                  cur.travelFromX = endPt.x;
                  cur.travelFromY = endPt.y;
                  cur.travelToX = nextStart.x;
                  cur.travelToY = nextStart.y;
                  break;
                }
              }
            }
          }

          // Completed all strokes!
          if (cur.strokeIdx >= totalStrokes) {
            cur.finished = true;
            pencilTargetRef.current.isTouching = false;
            pencilTargetRef.current.isActive = false;
            pencilTargetRef.current.isComplete = true;

            try {
              setFinishedSketchUrl(canvas.toDataURL('image/png'));
            } catch {}
            setIsComplete(true);
            setDrawProgressPct(100);
            setCurrentStage('complete');
            setStrokeCountHud({ done: totalStrokes, total: totalStrokes });
          }
        }
      } else if (isPausedRef.current && !cur.finished) {
        pencilTargetRef.current.isTouching = false;
      }

      // Throttled React HUD sync (~10Hz) so UI stays responsive with zero render stutter
      if (!cur.finished && now - lastHudSync > 95) {
        lastHudSync = now;
        const pct = Math.min(99, Math.round((cur.strokeIdx / totalStrokes) * 100));
        setDrawProgressPct(pct);
        setStrokeCountHud({ done: cur.strokeIdx, total: totalStrokes });
        const idxClamped = Math.min(totalStrokes - 1, cur.strokeIdx);
        setCurrentStage(strokes[idxClamped].stage);
      }

      drawingRafRef.current = requestAnimationFrame(stepLoop);
    };

    drawingRafRef.current = requestAnimationFrame(stepLoop);
    return () => cancelAnimationFrame(drawingRafRef.current);
  }, [isOpen, plan, resetPaperAndCursor]);

  const handleStyleSelect = (nextStyle: PencilStyleId) => {
    if (nextStyle === pencilStyle && plan) return;
    setPencilStyle(nextStyle);
    if (sourceImage) {
      void runAnalysis(sourceImage, nextStyle);
    }
  };

  const handleReplay = () => {
    if (!plan) return;
    resetPaperAndCursor(plan);
  };

  const handlePauseToggle = () => {
    if (isComplete) {
      handleReplay();
      return;
    }
    setIsPaused((prev) => !prev);
  };

  const handleDownloadSketch = () => {
    const canvas = paperCanvasRef.current;
    const url = finishedSketchUrl || canvas?.toDataURL('image/png');
    if (!url) return;
    const baseName = imageMeta?.fileName
      ? imageMeta.fileName.replace(/\.[^/.]+$/, '')
      : 'photo';
    const a = document.createElement('a');
    a.href = url;
    a.download = `${baseName}_${pencilStyle}_sketch.png`;
    a.click();
  };

  const handleDownloadOriginal = () => {
    if (!sourceDataUrl) return;
    const baseName = imageMeta?.fileName
      ? imageMeta.fileName.replace(/\.[^/.]+$/, '')
      : 'photo';
    const a = document.createElement('a');
    a.href = sourceDataUrl;
    a.download = `${baseName}_original.png`;
    a.click();
  };

  const handleDownloadComparison = () => {
    const sketchCanvas = paperCanvasRef.current;
    if (!sketchCanvas || !sourceImage) return;

    const pad = 32;
    const w = sketchCanvas.width;
    const h = sketchCanvas.height;
    const comp = document.createElement('canvas');
    comp.width = w * 2 + pad * 3;
    comp.height = h + pad * 2;
    const ctx = comp.getContext('2d');
    if (!ctx) return;

    ctx.fillStyle = '#140c2b';
    ctx.fillRect(0, 0, comp.width, comp.height);
    ctx.drawImage(sourceImage, pad, pad, w, h);
    ctx.drawImage(sketchCanvas, pad * 2 + w, pad, w, h);

    const baseName = imageMeta?.fileName
      ? imageMeta.fileName.replace(/\.[^/.]+$/, '')
      : 'photo';
    const a = document.createElement('a');
    a.href = comp.toDataURL('image/png');
    a.download = `${baseName}_before_after_sketch.png`;
    a.click();
  };

  if (!isOpen) return null;

  return (
    <div
      data-testid="sketch-3d-studio-modal"
      className="fixed inset-0 z-[60] flex items-center justify-center p-0 sm:p-4 bg-[#090418]/95 select-none overflow-hidden"
    >
      <input
        ref={fileInputRef}
        data-testid="sketch-photo-file-input"
        type="file"
        accept="image/jpeg,image/png,image/webp,image/jpg,image/heic,image/*"
        onChange={(e) => {
          const f = e.target.files?.[0];
          if (f) void handleFile(f);
          e.target.value = '';
        }}
        className="hidden"
      />

      <div
        className="relative w-full h-[100dvh] sm:h-[92vh] sm:max-w-5xl sm:rounded-[28px] border-0 sm:border border-purple-400/40 shadow-[0_25px_70px_rgba(0,0,0,0.9)] flex flex-col overflow-hidden"
        style={{
          background:
            'linear-gradient(175deg, #160a35 0%, #0f0724 52%, #0a041a 100%)',
        }}
      >
        {/* TOP HEADER BAR (Solid/RGBA surfaces, zero backdrop-filter over WebGL) */}
        <div className="relative z-30 flex items-center justify-between gap-2 px-3.5 sm:px-5 py-2.5 sm:py-3 border-b border-purple-500/30 bg-[#12082b]/95 shrink-0">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-gradient-to-tr from-purple-500 via-fuchsia-500 to-amber-400 p-[1.5px] shrink-0 shadow-[0_0_16px_rgba(168,85,247,0.45)]">
              <div className="w-full h-full rounded-[10px] bg-[#13082e] flex items-center justify-center text-amber-300">
                <Pencil className="w-4 h-4 sm:w-5 sm:h-5" />
              </div>
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <h3 className="text-sm sm:text-base font-extrabold text-white tracking-tight truncate">
                  3D Pencil Sketch Engine
                </h3>
                <span className="hidden sm:inline-flex text-[10px] font-bold px-2 py-0.5 rounded-full bg-purple-900/80 border border-purple-400/50 text-purple-200 uppercase tracking-wider shrink-0">
                  Live WebGL Artist
                </span>
              </div>
              <p className="text-[11px] text-purple-200/75 truncate">
                {plan
                  ? `${STAGE_LABELS[currentStage]} (${drawProgressPct}%)`
                  : 'Upload any photo to watch a 3D graphite pencil draw it stroke by stroke'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
            {sourceImage && (
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                data-testid="sketch-upload-another-btn"
                className="min-h-[38px] px-2.5 sm:px-3 py-1.5 rounded-xl bg-purple-900/70 hover:bg-purple-800/80 border border-purple-400/45 text-purple-100 text-xs font-bold flex items-center gap-1.5 transition-all active:scale-95 cursor-pointer"
                title="Upload another photo"
              >
                <Upload className="w-3.5 h-3.5 text-cyan-300" />
                <span className="hidden sm:inline">Change Photo</span>
              </button>
            )}

            {plan && (
              <button
                type="button"
                onClick={handleDownloadSketch}
                data-testid="sketch-download-btn"
                className="min-h-[38px] px-2.5 sm:px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-purple-600 to-fuchsia-600 hover:from-purple-500 hover:to-fuchsia-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-[0_0_14px_rgba(168,85,247,0.45)] transition-all active:scale-95 cursor-pointer"
                title="Download High-Res Pencil Sketch"
              >
                <Download className="w-3.5 h-3.5" />
                <span>{isComplete ? 'Save Sketch' : 'Save Snapshot'}</span>
              </button>
            )}

            <button
              type="button"
              onClick={onClose}
              data-testid="sketch-close-btn"
              className="w-9 h-9 rounded-xl bg-purple-950/80 hover:bg-purple-900 border border-purple-500/35 text-purple-200 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
              title="Close Studio"
            >
              <X className="w-4.5 h-4.5" />
            </button>
          </div>
        </div>

        {/* DRAWING STYLE SELECTOR BAR (4 Realistic Pencil Styles) */}
        {sourceImage && (
          <div className="relative z-30 px-3.5 sm:px-5 py-2 border-b border-purple-500/20 bg-[#100626]/95 flex items-center justify-between gap-2 overflow-x-auto no-scrollbar shrink-0">
            <div className="flex items-center gap-1.5 shrink-0">
              {STYLE_ORDER.map((id) => {
                const prof = PENCIL_STYLE_PROFILES[id];
                const active = pencilStyle === id;
                return (
                  <button
                    key={id}
                    type="button"
                    data-testid={`sketch-style-${id}`}
                    onClick={() => handleStyleSelect(id)}
                    className={`min-h-[34px] px-2.5 sm:px-3 py-1 rounded-xl text-[11px] sm:text-xs font-bold transition-all cursor-pointer whitespace-nowrap border ${
                      active
                        ? 'bg-gradient-to-r from-purple-600 via-violet-600 to-fuchsia-600 text-white border-purple-300/70 shadow-[0_0_12px_rgba(168,85,247,0.45)]'
                        : 'bg-[#1a0d3c] text-purple-200/80 border-purple-500/25 hover:border-purple-400/50 hover:text-white'
                    }`}
                    title={prof.description}
                  >
                    {prof.shortLabel}
                  </button>
                );
              })}
            </div>

            {plan && (
              <div className="hidden md:flex items-center gap-2 text-[11px] font-mono text-purple-200/80 shrink-0">
                <span>
                  Strokes: {strokeCountHud.done.toLocaleString()} /{' '}
                  {strokeCountHud.total.toLocaleString()}
                </span>
              </div>
            )}
          </div>
        )}

        {/* MAIN UNOBSTRUCTED DRAWING PAPER & 3D PENCIL STAGE */}
        <div
          className="relative flex-1 min-h-0 w-full flex items-center justify-center px-3 pt-2.5 pb-24 sm:px-6 sm:pt-4 sm:pb-24 overflow-hidden"
          onDragOver={(e) => {
            e.preventDefault();
            setDragOver(true);
          }}
          onDragLeave={() => setDragOver(false)}
          onDrop={(e) => {
            e.preventDefault();
            setDragOver(false);
            const f = e.dataTransfer.files?.[0];
            if (f) void handleFile(f);
          }}
        >
          {/* Ambient studio desk vignette */}
          <div
            className="pointer-events-none absolute inset-0"
            style={{
              background:
                'radial-gradient(circle at 50% 45%, rgba(91, 33, 182, 0.22) 0%, rgba(12, 6, 28, 0.96) 78%)',
            }}
          />

          {/* 1. UPLOAD / GALLERY SELECTION INTERFACE */}
          {!sourceImage && !isAnalyzing && (
            <div className="relative z-10 w-full max-w-lg flex flex-col items-center gap-4">
              <div
                onClick={() => fileInputRef.current?.click()}
                data-testid="sketch-upload-dropzone"
                className={`w-full p-6 sm:p-8 rounded-3xl border-2 border-dashed transition-all cursor-pointer flex flex-col items-center text-center ${
                  dragOver
                    ? 'border-cyan-300 bg-purple-900/50 scale-[1.01]'
                    : 'border-purple-400/50 hover:border-purple-300 bg-[#1a0c3d]/90 hover:bg-[#21104c]/95'
                } shadow-[0_20px_50px_rgba(0,0,0,0.6)]`}
              >
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-purple-500/30 to-fuchsia-500/30 border border-purple-300/45 flex items-center justify-center text-purple-100 mb-4 shadow-lg">
                  <Upload className="w-8 h-8" />
                </div>
                <h4 className="text-base sm:text-lg font-extrabold text-white mb-1.5">
                  Select or Drop Any Photo to Sketch
                </h4>
                <p className="text-xs sm:text-sm text-purple-200/80 max-w-sm leading-relaxed">
                  Upload portraits, objects, pets, or landscapes. Watch a realistic 3D graphite pencil draw outlines, facial details, and shading live.
                </p>

                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    fileInputRef.current?.click();
                  }}
                  data-testid="sketch-select-photo-btn"
                  className="mt-5 min-h-[44px] px-6 py-2.5 rounded-2xl bg-gradient-to-r from-purple-500 via-violet-500 to-fuchsia-500 hover:brightness-110 text-white text-sm font-extrabold shadow-[0_0_24px_rgba(168,85,247,0.5)] transition-all active:scale-95 cursor-pointer flex items-center gap-2"
                >
                  <ImageIcon className="w-4 h-4" />
                  <span>Open Gallery / Choose Photo</span>
                </button>
              </div>

              {/* Quick Test Photos (Portrait / Object / Scenery) */}
              <div className="w-full rounded-2xl bg-[#140930]/95 border border-purple-500/30 p-3 sm:p-3.5">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[11px] font-bold text-purple-200 uppercase tracking-wider flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                    Instant Studio Test Photos
                  </span>
                  <span className="text-[10px] text-purple-300/70">1-tap 3D sketch</span>
                </div>
                <div className="grid grid-cols-3 gap-2">
                  {(
                    [
                      { id: 'portrait', label: 'Portrait' },
                      { id: 'object', label: 'Still Life' },
                      { id: 'scenery', label: 'Scenery' },
                    ] as const
                  ).map((sample) => (
                    <button
                      key={sample.id}
                      type="button"
                      data-testid={`sketch-sample-${sample.id}`}
                      onClick={() => void handleSamplePreset(sample.id)}
                      className="min-h-[40px] px-3 py-2 rounded-xl bg-[#22114d] hover:bg-[#2d1766] border border-purple-400/35 text-xs font-bold text-purple-100 transition-all active:scale-95 cursor-pointer"
                    >
                      {sample.label}
                    </button>
                  ))}
                </div>
              </div>

              {errorMsg && (
                <div className="w-full px-4 py-2.5 rounded-xl bg-rose-950/90 border border-rose-500/50 text-xs text-rose-200 text-center">
                  {errorMsg}
                </div>
              )}
            </div>
          )}

          {/* 2. IMAGE ANALYSIS PROGRESS */}
          {isAnalyzing && (
            <div className="relative z-20 w-full max-w-sm p-6 rounded-3xl bg-[#150a34]/95 border border-purple-400/45 shadow-2xl flex flex-col items-center text-center">
              <div className="w-16 h-16 rounded-full border-4 border-purple-400/25 border-t-amber-300 animate-spin flex items-center justify-center mb-4">
                <Pencil className="w-6 h-6 text-purple-200" />
              </div>
              <h4 className="text-base font-extrabold text-white mb-1">
                Analyzing Photo & Generating Paths
              </h4>
              <p className="text-xs text-purple-200/85 mb-4">{analysisLabel}</p>
              <div className="w-full h-2 rounded-full bg-purple-950 overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-purple-400 via-fuchsia-400 to-amber-300 transition-all duration-200"
                  style={{ width: `${analysisProgress}%` }}
                />
              </div>
            </div>
          )}

          {/* 3. LIVE DRAWING PAPER + 3D WEBGL PENCIL STAGE */}
          {plan && !isAnalyzing && (
            <div className="relative w-full h-full flex items-center justify-center">
              {/* Top-left subtle progress pill (static icon, no pulsating dot) */}
              <div className="pointer-events-none absolute top-0 left-0 z-30 px-3 py-1.5 rounded-xl bg-[#12082c]/92 border border-purple-400/35 text-[11px] font-bold text-purple-100 flex items-center gap-2 shadow-lg">
                {isComplete ? (
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                ) : (
                  <Layers className="w-3.5 h-3.5 text-amber-300 shrink-0" />
                )}
                <span>{showOriginal ? 'Original Photo (Preserved)' : STAGE_LABELS[currentStage]}</span>
                <span className="font-mono text-purple-300">{drawProgressPct}%</span>
              </div>

              {/* Paper Sheet Frame (Aspect-ratio safe across Android mobile & desktop) */}
              <div className="relative flex items-center justify-center max-w-full max-h-full rounded-xl sm:rounded-2xl overflow-hidden shadow-[0_22px_60px_rgba(0,0,0,0.85),0_0_0_1px_rgba(255,255,255,0.12)] bg-[#f7f3e9]">
                <canvas
                  ref={paperCanvasRef}
                  width={plan.width}
                  height={plan.height}
                  data-testid="sketch-paper-canvas"
                  className="max-w-full max-h-[calc(100dvh-250px)] sm:max-h-[calc(92vh-250px)] w-auto h-auto block"
                />

                {/* Preserved Original Photo Overlay when comparing */}
                {showOriginal && sourceDataUrl && (
                  <img
                    src={sourceDataUrl}
                    alt="Original Uploaded Photo"
                    data-testid="sketch-original-overlay"
                    className="absolute inset-0 w-full h-full object-contain"
                  />
                )}
              </div>

              {/* 3D WebGL Graphite Pencil Stage overlaid cleanly across full studio area so barrel never clips */}
              <div
                className={`pointer-events-none absolute inset-0 z-20 transition-opacity duration-150 ${
                  showOriginal ? 'opacity-0' : 'opacity-100'
                }`}
              >
                <Pencil3DStage
                  paperElementRef={paperCanvasRef}
                  targetRef={pencilTargetRef}
                  pencilStyle={pencilStyle}
                />
              </div>
            </div>
          )}

          {/* 4. COLLAPSIBLE BOTTOM CONTROL DOCK (Zero Viewport Occlusion) */}
          {plan && !isAnalyzing && (
            <div className="absolute bottom-2.5 sm:bottom-3 left-1/2 -translate-x-1/2 z-30 flex flex-col items-center w-[min(96%,820px)]">
              <button
                type="button"
                onClick={() => setDockCollapsed((v) => !v)}
                className="mb-1 px-3 py-0.5 rounded-t-xl bg-[#190c3b]/95 border border-b-0 border-purple-400/40 text-[10px] font-bold text-purple-200 hover:text-white flex items-center gap-1 cursor-pointer"
              >
                {dockCollapsed ? (
                  <>
                    <ChevronUp className="w-3 h-3" />
                    <span>Show Controls</span>
                  </>
                ) : (
                  <>
                    <ChevronDown className="w-3 h-3" />
                    <span>Hide Controls</span>
                  </>
                )}
              </button>

              {!dockCollapsed && (
                <div className="w-full rounded-2xl bg-[#130930]/95 border border-purple-400/45 shadow-[0_12px_36px_rgba(0,0,0,0.8)] px-3 py-2 sm:px-4 sm:py-2.5 flex flex-wrap items-center justify-between gap-2">
                  {/* Playback Controls */}
                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={handlePauseToggle}
                      data-testid="sketch-play-pause-btn"
                      className="min-h-[38px] px-3 py-1.5 rounded-xl bg-gradient-to-r from-purple-600 to-violet-600 hover:from-purple-500 hover:to-violet-500 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer active:scale-95 transition-all"
                    >
                      {isComplete ? (
                        <>
                          <RotateCcw className="w-3.5 h-3.5" />
                          <span>Replay</span>
                        </>
                      ) : isPaused ? (
                        <>
                          <Play className="w-3.5 h-3.5" />
                          <span>Resume</span>
                        </>
                      ) : (
                        <>
                          <Pause className="w-3.5 h-3.5" />
                          <span>Pause</span>
                        </>
                      )}
                    </button>

                    <button
                      type="button"
                      onClick={handleReplay}
                      data-testid="sketch-restart-btn"
                      className="min-h-[38px] px-2.5 py-1.5 rounded-xl bg-[#20104a] hover:bg-[#2a1660] border border-purple-400/35 text-purple-100 text-xs font-semibold flex items-center gap-1 cursor-pointer active:scale-95 transition-all"
                      title="Restart drawing from first outline"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span className="hidden sm:inline">Restart</span>
                    </button>
                  </div>

                  {/* Speed Controls */}
                  <div className="flex items-center gap-1 bg-[#0d0522] p-1 rounded-xl border border-purple-500/25">
                    <span className="text-[10px] font-bold text-purple-300/80 px-1.5">
                      Speed
                    </span>
                    {SPEED_OPTIONS.map((sp) => (
                      <button
                        key={sp}
                        type="button"
                        data-testid={`sketch-speed-${sp}x`}
                        onClick={() => setSpeed(sp)}
                        className={`min-h-[28px] px-2 py-0.5 rounded-lg text-[11px] font-bold cursor-pointer transition-all ${
                          speed === sp
                            ? 'bg-purple-500 text-white shadow'
                            : 'text-purple-200/75 hover:text-white'
                        }`}
                      >
                        {sp}×
                      </button>
                    ))}
                  </div>

                  {/* Compare Original & Export Actions */}
                  <div className="flex items-center gap-1.5 flex-wrap">
                    {sourceDataUrl && (
                      <button
                        type="button"
                        onClick={() => setShowOriginal((prev) => !prev)}
                        data-testid="sketch-compare-btn"
                        className={`min-h-[38px] px-2.5 py-1.5 rounded-xl border text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-all ${
                          showOriginal
                            ? 'bg-amber-500/25 border-amber-400/60 text-amber-200'
                            : 'bg-[#20104a] border-purple-400/35 text-purple-100 hover:bg-[#2a1660]'
                        }`}
                        title="Toggle preserved original photo"
                      >
                        <Eye className="w-3.5 h-3.5 text-amber-300" />
                        <span>{showOriginal ? 'Show Sketch' : 'Original'}</span>
                      </button>
                    )}

                    {isComplete && sourceDataUrl && (
                      <>
                        <button
                          type="button"
                          onClick={handleDownloadComparison}
                          data-testid="sketch-download-compare-btn"
                          className="min-h-[38px] px-2.5 py-1.5 rounded-xl bg-[#20104a] hover:bg-[#2a1660] border border-purple-400/35 text-purple-100 text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
                          title="Download Before & After Side-by-Side"
                        >
                          <Download className="w-3.5 h-3.5 text-cyan-300" />
                          <span className="hidden sm:inline">Before/After</span>
                        </button>
                        <button
                          type="button"
                          onClick={handleDownloadOriginal}
                          data-testid="sketch-download-original-btn"
                          className="min-h-[38px] px-2.5 py-1.5 rounded-xl bg-[#20104a] hover:bg-[#2a1660] border border-purple-400/35 text-purple-100 text-xs font-semibold hidden md:flex items-center gap-1.5 cursor-pointer"
                          title="Save preserved original photo"
                        >
                          <ImageIcon className="w-3.5 h-3.5 text-purple-300" />
                          <span>Save Original</span>
                        </button>
                      </>
                    )}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
