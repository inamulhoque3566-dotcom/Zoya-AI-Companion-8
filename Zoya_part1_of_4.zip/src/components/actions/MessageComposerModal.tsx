import React, { useState } from 'react';
import { 
  X, 
  MessageCircle, 
  Send, 
  Smartphone, 
  Check, 
  Sparkles, 
  Share2,
  ExternalLink
} from 'lucide-react';

interface MessageComposerModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultRecipient?: string;
}

export const MessageComposerModal: React.FC<MessageComposerModalProps> = ({
  isOpen,
  onClose,
  defaultRecipient = 'Papa',
}) => {
  const [recipient, setRecipient] = useState(defaultRecipient);
  const [phoneInput, setPhoneInput] = useState('');
  const [message, setMessage] = useState('पापा, मैं ठीक हूँ! आप कब तक घर आओगे?');
  const [sentStatus, setSentStatus] = useState<string | null>(null);

  if (!isOpen) return null;

  const contacts = [
    { id: 'Papa', name: 'पापा (WhatsApp)', phone: '+919876512345', defaultMsg: 'पापा, मैं ठीक हूँ! आप कब तक घर आओगे?' },
    { id: 'Mummy', name: 'मम्मी (WhatsApp)', phone: '+919876543210', defaultMsg: 'मम्मी, मैंने खाना खा लिया है, आप चिंता मत करना ❤️' },
    { id: 'Friend', name: 'दोस्त', phone: '+919876599999', defaultMsg: 'हेलो भाई! आज शाम को मिलते हैं?' },
  ];

  const quickTemplates = [
    'पापा, मैं घर पहुँच गया हूँ।',
    'मम्मी, खाना बहुत स्वादिष्ट था ❤️',
    'क्या आप अभी फ्री हैं? कॉल करूँ?',
    'शुभ प्रभात! आपका दिन शुभ हो 🌸',
  ];

  const handleSelectContact = (c: typeof contacts[0]) => {
    setRecipient(c.id);
    setMessage(c.defaultMsg);
  };

  const handleSendWhatsApp = () => {
    if (!message.trim()) return;
    const encoded = encodeURIComponent(message);
    const targetPhone = phoneInput.replace(/[^0-9]/g, '') || (contacts.find((c) => c.id === recipient)?.phone.replace(/[^0-9]/g, '') || '');
    
    // Direct WhatsApp web or mobile deep link
    const waUrl = targetPhone 
      ? `https://api.whatsapp.com/send?phone=${targetPhone}&text=${encoded}`
      : `https://api.whatsapp.com/send?text=${encoded}`;
    
    window.open(waUrl, '_blank');
    setSentStatus('संदेश WhatsApp पर भेजा गया!');
    setTimeout(() => setSentStatus(null), 3000);
  };

  const handleSendSMS = () => {
    if (!message.trim()) return;
    const encoded = encodeURIComponent(message);
    window.open(`sms:?body=${encoded}`, '_self');
    setSentStatus('संदेश SMS ऐप पर भेजा गया!');
    setTimeout(() => setSentStatus(null), 3000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-md bg-slate-900 rounded-3xl border border-slate-800 shadow-2xl overflow-hidden flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-500 to-green-600 flex items-center justify-center text-white shadow-lg">
              <MessageCircle className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-100">
                मैसेज भेजें (Send a Message)
              </h3>
              <p className="text-xs text-slate-400">
                &ldquo;Papa ko WhatsApp karo&rdquo; या SMS भेजें
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-4">
          {/* Contact Selector */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-2">
              किसे संदेश भेजना है चुनें:
            </label>
            <div className="grid grid-cols-3 gap-2">
              {contacts.map((c) => (
                <button
                  key={c.id}
                  onClick={() => handleSelectContact(c)}
                  className={`p-2.5 rounded-xl border text-center transition-all ${
                    recipient === c.id
                      ? 'bg-emerald-950/80 border-emerald-500 text-emerald-200 shadow-sm'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <div className="font-semibold text-xs text-slate-200 truncate">{c.name}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Custom Phone Number input */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              फ़ोन नंबर (वैकल्पिक / WhatsApp Number):
            </label>
            <input
              type="text"
              placeholder="+91 XXXXX XXXXX"
              value={phoneInput}
              onChange={(e) => setPhoneInput(e.target.value)}
              className="w-full px-3 py-2 text-xs bg-slate-950 border border-slate-800 rounded-xl text-slate-200 font-mono focus:outline-none focus:border-emerald-500"
            />
          </div>

          {/* Message Textarea */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              संदेश लिखें (Message Content):
            </label>
            <textarea
              rows={3}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              className="w-full p-3 text-xs sm:text-sm bg-slate-950 border border-slate-800 rounded-xl text-slate-200 focus:outline-none focus:border-emerald-500 resize-none leading-relaxed"
            />
          </div>

          {/* Quick Templates */}
          <div>
            <div className="text-[11px] text-slate-400 mb-1.5 font-mono">त्वरित संदेश टेम्पलेट्स:</div>
            <div className="flex flex-wrap gap-1.5">
              {quickTemplates.map((t, idx) => (
                <button
                  key={idx}
                  onClick={() => setMessage(t)}
                  className="px-2.5 py-1 bg-slate-950 hover:bg-slate-800 border border-slate-800 rounded-lg text-[11px] text-slate-300 transition-colors text-left"
                >
                  {t}
                </button>
              ))}
            </div>
          </div>

          {/* Status Alert */}
          {sentStatus && (
            <div className="p-3 bg-emerald-950/80 border border-emerald-800/80 rounded-xl text-emerald-300 text-xs font-mono flex items-center gap-2">
              <Check className="w-4 h-4" />
              <span>{sentStatus}</span>
            </div>
          )}

          {/* Action Dispatch Buttons */}
          <div className="grid grid-cols-2 gap-3 pt-2">
            <button
              onClick={handleSendWhatsApp}
              className="py-3 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-500 hover:to-green-500 text-white text-xs font-bold transition-all shadow-lg flex items-center justify-center gap-2"
            >
              <MessageCircle className="w-4 h-4" />
              <span>WhatsApp पर भेजें</span>
            </button>

            <button
              onClick={handleSendSMS}
              className="py-3 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-white text-xs font-bold transition-all flex items-center justify-center gap-2"
            >
              <Smartphone className="w-4 h-4 text-sky-400" />
              <span>SMS ऐप में खोलें</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
