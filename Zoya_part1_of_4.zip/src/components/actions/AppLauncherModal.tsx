import React, { useState } from 'react';
import { 
  X, 
  Youtube, 
  MessageSquare, 
  Camera, 
  Music, 
  Calculator, 
  Compass, 
  Search, 
  ExternalLink,
  Play
} from 'lucide-react';

interface AppLauncherModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialApp?: string;
}

export const AppLauncherModal: React.FC<AppLauncherModalProps> = ({
  isOpen,
  onClose,
  initialApp = 'youtube',
}) => {
  const [activeTab, setActiveTab] = useState<string>(initialApp);
  const [youtubeQuery, setYoutubeQuery] = useState('lofi hindi songs');
  const [activeVideoId, setActiveVideoId] = useState('jfKfPfyJRdk'); // popular lofi stream
  const [calcDisplay, setCalcDisplay] = useState('0');

  if (!isOpen) return null;

  const apps = [
    { id: 'youtube', name: 'YouTube', color: 'from-red-500 to-rose-600', icon: Youtube, desc: 'वीडियो और गाने' },
    { id: 'music', name: 'म्यूजिक प्लेयर', color: 'from-amber-400 to-orange-500', icon: Music, desc: 'गाने और प्लेलिस्ट' },
    { id: 'camera', name: 'कैमरा', color: 'from-purple-500 to-indigo-600', icon: Camera, desc: 'फोटो व वीडियो' },
    { id: 'calculator', name: 'कैलकुलेटर', color: 'from-emerald-400 to-teal-600', icon: Calculator, desc: 'गणना व मैथ्स' },
    { id: 'browser', name: 'वेब सर्च', color: 'from-blue-500 to-cyan-500', icon: Compass, desc: 'गूगल ब्राउज़र' },
  ];

  const handleSearchYoutube = (e: React.FormEvent) => {
    e.preventDefault();
    if (youtubeQuery.trim()) {
      window.open(`https://www.youtube.com/results?search_query=${encodeURIComponent(youtubeQuery)}`, '_blank');
    }
  };

  const handleCalcClick = (val: string) => {
    if (val === 'C') {
      setCalcDisplay('0');
    } else if (val === '=') {
      try {
        // Safe math evaluation
        const sanitized = calcDisplay.replace(/[^0-9+\-*/.]/g, '');
        // eslint-disable-next-line no-eval
        const result = Function(`'use strict'; return (${sanitized})`)();
        setCalcDisplay(String(result));
      } catch {
        setCalcDisplay('Error');
      }
    } else {
      setCalcDisplay((prev) => (prev === '0' || prev === 'Error' ? val : prev + val));
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-2xl bg-slate-900 rounded-3xl border border-slate-800 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-red-500 to-rose-600 flex items-center justify-center text-white shadow-lg">
              <Youtube className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-100">
                ऐप लॉन्चर (Open an App)
              </h3>
              <p className="text-xs text-slate-400">
                &ldquo;YouTube kholo&rdquo;, कैमरा या म्यूजिक ऐप तुरंत चलाएं
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* App Selector Grid */}
        <div className="p-4 border-b border-slate-800 bg-slate-950/30 flex items-center gap-2 overflow-x-auto">
          {apps.map((app) => {
            const Icon = app.icon;
            const isSelected = activeTab === app.id;
            return (
              <button
                key={app.id}
                onClick={() => setActiveTab(app.id)}
                className={`flex items-center gap-2 px-3 py-2 rounded-xl border transition-all text-xs font-medium shrink-0 ${
                  isSelected
                    ? 'bg-slate-800 text-white border-slate-600 shadow-sm'
                    : 'bg-slate-950 text-slate-400 border-slate-800/80 hover:bg-slate-900'
                }`}
              >
                <div className={`w-5 h-5 rounded-lg bg-gradient-to-tr ${app.color} flex items-center justify-center text-white`}>
                  <Icon className="w-3 h-3" />
                </div>
                <span>{app.name}</span>
              </button>
            );
          })}
        </div>

        {/* App Content Body */}
        <div className="flex-1 overflow-y-auto p-6">
          {/* 1. YOUTUBE APP */}
          {activeTab === 'youtube' && (
            <div className="space-y-4">
              <form onSubmit={handleSearchYoutube} className="flex gap-2">
                <div className="relative flex-1">
                  <Search className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
                  <input
                    type="text"
                    value={youtubeQuery}
                    onChange={(e) => setYoutubeQuery(e.target.value)}
                    placeholder="YouTube पर वीडियो या गाने खोजें (उदा. Arijit Singh songs)..."
                    className="w-full pl-9 pr-3 py-2.5 text-xs sm:text-sm bg-slate-950 border border-slate-800 rounded-xl text-slate-200 focus:outline-none focus:border-red-500"
                  />
                </div>
                <button
                  type="submit"
                  className="px-4 py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-sm shrink-0"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>YouTube पर खोलें</span>
                </button>
              </form>

              {/* Live YouTube Player Embed */}
              <div className="w-full aspect-video rounded-2xl overflow-hidden border border-slate-800 bg-slate-950 shadow-inner">
                <iframe
                  className="w-full h-full"
                  src={`https://www.youtube-nocookie.com/embed/${activeVideoId}?autoplay=0`}
                  title="YouTube video player"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                />
              </div>

              {/* Recommended Quick Playlists */}
              <div className="grid grid-cols-3 gap-2 text-xs">
                {[
                  { title: 'हिंदी लो-फाई (Lofi)', id: 'jfKfPfyJRdk' },
                  { title: 'सुकून भरे गाने (Chill)', id: '5qap5aO4i9A' },
                  { title: 'क्लासिक मेलोडीज', id: 'DWcJFNfaw9c' },
                ].map((item) => (
                  <button
                    key={item.id}
                    onClick={() => setActiveVideoId(item.id)}
                    className="p-2.5 bg-slate-950/80 hover:bg-slate-800 border border-slate-800 rounded-xl text-left transition-colors flex items-center gap-2"
                  >
                    <Play className="w-3.5 h-3.5 text-red-400 shrink-0" />
                    <span className="truncate text-slate-300 text-[11px] font-medium">{item.title}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* 2. MUSIC APP */}
          {activeTab === 'music' && (
            <div className="space-y-4 text-center p-6 bg-slate-950 rounded-2xl border border-slate-800">
              <div className="w-16 h-16 mx-auto rounded-full bg-gradient-to-tr from-amber-400 to-orange-500 flex items-center justify-center text-white shadow-lg animate-pulse">
                <Music className="w-8 h-8" />
              </div>
              <div>
                <h4 className="text-base font-bold text-slate-100">जोया म्यूजिक लाउंज</h4>
                <p className="text-xs text-slate-400 mt-1">
                  Spotify, Gaana या YouTube Music पर अपने पसंदीदा गाने सुनें
                </p>
              </div>
              <div className="flex flex-wrap justify-center gap-3 pt-2">
                <button
                  onClick={() => window.open('https://open.spotify.com', '_blank')}
                  className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold transition-colors flex items-center gap-2"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>Spotify खोलें</span>
                </button>
                <button
                  onClick={() => window.open('https://music.youtube.com', '_blank')}
                  className="px-4 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-semibold transition-colors flex items-center gap-2"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>YouTube Music खोलें</span>
                </button>
              </div>
            </div>
          )}

          {/* 3. CALCULATOR APP */}
          {activeTab === 'calculator' && (
            <div className="max-w-xs mx-auto p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-3">
              <div className="w-full px-4 py-3 bg-slate-900 border border-slate-800 rounded-xl text-right font-mono text-xl font-bold text-slate-100 overflow-x-auto">
                {calcDisplay}
              </div>

              <div className="grid grid-cols-4 gap-2">
                {['C', '(', ')', '/', '7', '8', '9', '*', '4', '5', '6', '-', '1', '2', '3', '+', '0', '.', '='].map((btn) => (
                  <button
                    key={btn}
                    onClick={() => handleCalcClick(btn)}
                    className={`py-3 rounded-xl font-mono text-xs font-bold transition-colors ${
                      btn === '='
                        ? 'col-span-2 bg-emerald-600 hover:bg-emerald-500 text-white'
                        : btn === 'C'
                        ? 'bg-rose-900/60 hover:bg-rose-800 text-rose-200'
                        : ['/', '*', '-', '+'].includes(btn)
                        ? 'bg-sky-950 hover:bg-sky-900 text-sky-300 border border-sky-800/60'
                        : 'bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-800'
                    }`}
                  >
                    {btn}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* 4. CAMERA APP */}
          {activeTab === 'camera' && (
            <div className="p-8 text-center bg-slate-950 rounded-2xl border border-slate-800 space-y-3">
              <Camera className="w-12 h-12 text-purple-400 mx-auto animate-pulse" />
              <h4 className="text-sm font-semibold text-slate-200">सिस्टम कैमरा व सेल्फी मोड</h4>
              <p className="text-xs text-slate-400">
                डिवाइस कैमरा चालू करने या फोटो खींचने के लिए नीचे दिए गए बटन पर टैप करें।
              </p>
              <button
                onClick={() => {
                  navigator.mediaDevices.getUserMedia({ video: true })
                    .then((stream) => {
                      alert('कैमरा सफलतापूर्वक कनेक्ट हो गया है!');
                      stream.getTracks().forEach((t) => t.stop());
                    })
                    .catch((err) => alert('कैमरा परमिशन आवश्यक है: ' + err.message));
                }}
                className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-semibold transition-colors"
              >
                कैमरा प्रारंभ करें (Start Camera)
              </button>
            </div>
          )}

          {/* 5. BROWSER SEARCH */}
          {activeTab === 'browser' && (
            <div className="p-6 text-center bg-slate-950 rounded-2xl border border-slate-800 space-y-4">
              <Compass className="w-12 h-12 text-blue-400 mx-auto" />
              <h4 className="text-sm font-semibold text-slate-200">वेब सर्च व ब्राउज़र</h4>
              <p className="text-xs text-slate-400 max-w-sm mx-auto">
                इंटरनेट पर सीधे जानकारी खोजने के लिए ब्राउज़र विंडो खोलें।
              </p>
              <button
                onClick={() => window.open('https://www.google.com', '_blank')}
                className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold transition-colors flex items-center gap-2 mx-auto"
              >
                <ExternalLink className="w-4 h-4" />
                <span>Google पर खोजें</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
