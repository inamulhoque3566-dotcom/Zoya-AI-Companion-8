import React, { useState, useEffect, useRef } from 'react';
import {
  Users,
  Server,
  FileText,
  Trophy,
  Package,
  Share2,
  Film,
  Briefcase,
  Copy,
  Check,
  Download,
  ExternalLink,
  KeyRound,
  Play,
  Pause,
  RotateCcw,
  Sparkles,
  ShieldCheck,
  AlertTriangle,
  Send,
  Eye,
  Layers,
  ChevronRight,
  TrendingUp,
} from 'lucide-react';
import {
  Part5And6SkillPayload,
  LeadResearchPayload,
  McpBuilderPayload,
  MeetingInsightsPayload,
  RafflePickerPayload,
  SkillCreatorPayload,
  SkillSharePayload,
  SlackGifPayload,
  TailoredResumePayload,
} from '../../services/zoyaSkillsPart5And6';
import { getToolApiKey } from '../../services/toolApiKeysConfig';

interface Part5And6SkillOutputCardProps {
  payload: Part5And6SkillPayload;
  onOpenToolApiKeys?: () => void;
}

export const Part5And6SkillOutputCard: React.FC<Part5And6SkillOutputCardProps> = ({
  payload,
  onOpenToolApiKeys,
}) => {
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const handleCopy = (text: string, id: string) => {
    try {
      navigator.clipboard.writeText(text);
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 1800);
    } catch {}
  };

  const handleDownload = (filename: string, content: string, mime: string = 'text/plain') => {
    const blob = new Blob([content], { type: `${mime};charset=utf-8` });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // ==========================================================================
  // 1. LEAD RESEARCH ASSISTANT CARD
  // ==========================================================================
  if (payload.kind === 'lead-research-assistant') {
    const [activeTab, setActiveTab] = useState<'leads' | 'email' | 'icp'>('leads');
    const [selectedLeadIdx, setSelectedLeadIdx] = useState<number>(0);
    const curLead = payload.leads[selectedLeadIdx] || payload.leads[0];

    return (
      <div className="mt-3 rounded-2xl border border-sky-500/40 bg-[#0b1021] overflow-hidden shadow-xl text-slate-200 text-xs">
        {/* Header */}
        <div className="px-3.5 py-2.5 bg-[#101935] border-b border-sky-500/30 flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-lg bg-sky-500/20 text-sky-400 flex items-center justify-center font-bold">
              <Users className="w-3.5 h-3.5" />
            </div>
            <div>
              <div className="text-[13px] font-semibold text-sky-300 flex items-center gap-2">
                Lead Research & Outreach Intelligence
                <span className="text-[9px] font-mono uppercase px-1.5 py-0.5 rounded bg-amber-950/80 text-amber-300 border border-amber-500/40">
                  Sample Data / Synthetic Profiles
                </span>
              </div>
              <div className="text-[10px] text-slate-400">
                Target: {payload.targetMarket} · Zero Paid API (Heuristic Model Engine)
              </div>
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => handleDownload('crm_leads_sample.csv', payload.crmCsv, 'text/csv')}
              className="px-2.5 py-1 rounded-lg bg-sky-600/30 hover:bg-sky-600/50 text-sky-200 border border-sky-500/30 text-[11px] font-medium flex items-center gap-1 cursor-pointer transition-colors"
            >
              <Download className="w-3 h-3" />
              Sample CSV
            </button>
          </div>
        </div>

        {/* Tab buttons */}
        <div className="flex border-b border-sky-950/80 bg-[#090d1c] px-3 pt-2 gap-2">
          <button
            onClick={() => setActiveTab('leads')}
            className={`pb-1.5 px-2.5 font-medium border-b-2 text-[11px] cursor-pointer transition-all ${
              activeTab === 'leads'
                ? 'border-sky-400 text-sky-300 font-semibold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Qualified Leads ({payload.leads.length})
          </button>
          <button
            onClick={() => setActiveTab('email')}
            className={`pb-1.5 px-2.5 font-medium border-b-2 text-[11px] cursor-pointer transition-all ${
              activeTab === 'email'
                ? 'border-sky-400 text-sky-300 font-semibold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Outreach Email Draft
          </button>
          <button
            onClick={() => setActiveTab('icp')}
            className={`pb-1.5 px-2.5 font-medium border-b-2 text-[11px] cursor-pointer transition-all ${
              activeTab === 'icp'
                ? 'border-sky-400 text-sky-300 font-semibold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            ICP Profile
          </button>
        </div>

        {/* Tab Content */}
        <div className="p-3.5 space-y-3">
          {activeTab === 'leads' && (
            <div className="space-y-3">
              {/* Lead Selector Pills */}
              <div className="flex gap-2 overflow-x-auto pb-1">
                {payload.leads.map((lead, idx) => (
                  <button
                    key={lead.company}
                    onClick={() => setSelectedLeadIdx(idx)}
                    className={`px-3 py-1.5 rounded-xl border text-left shrink-0 cursor-pointer transition-all ${
                      selectedLeadIdx === idx
                        ? 'bg-sky-950/80 border-sky-400 text-sky-200 shadow-sm'
                        : 'bg-[#10152b] border-slate-800 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <div className="font-semibold text-[11px] flex items-center justify-between gap-2">
                      <span>{lead.company}</span>
                      <span className="text-[10px] text-amber-400 bg-amber-950/70 px-1.5 py-0.2 rounded">
                        ★ {lead.priorityScore}/10
                      </span>
                    </div>
                    <div className="text-[9.5px] text-slate-400 truncate max-w-[130px]">
                      {lead.industry}
                    </div>
                  </button>
                ))}
              </div>

              {/* Selected Lead Details */}
              <div className="p-3 rounded-xl bg-[#0e152e] border border-sky-900/60 space-y-2.5">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <div className="text-[14px] font-bold text-slate-100 flex items-center gap-2">
                      {curLead.company}
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-500/30">
                        Score: {curLead.priorityScore} / 10
                      </span>
                    </div>
                    <div className="text-[11px] text-sky-300 font-mono">
                      {curLead.size} · {curLead.industry}
                    </div>
                  </div>
                  <div className="text-[10.5px] text-slate-300 text-right">
                    <span className="text-slate-400">Target Role:</span>
                    <div className="font-semibold text-sky-200">{curLead.decisionMaker}</div>
                  </div>
                </div>

                <div className="space-y-1">
                  <div className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
                    Why They Are a Good Fit:
                  </div>
                  <ul className="space-y-1 pl-3 text-slate-300 list-disc">
                    {curLead.whyGoodFit.map((point, i) => (
                      <li key={i} className="text-[11px] leading-tight">
                        {point}
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="p-2 rounded-lg bg-sky-950/40 border border-sky-800/40 space-y-1">
                  <div className="text-[10px] font-semibold text-sky-400">
                    Targeted Value Proposition:
                  </div>
                  <div className="text-[11px] text-sky-100">{curLead.valueProposition}</div>
                </div>

                <div className="space-y-1">
                  <div className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
                    Conversation Starters:
                  </div>
                  {curLead.conversationStarters.map((starter, i) => (
                    <div
                      key={i}
                      className="text-[11px] text-slate-300 bg-[#090e21] p-2 rounded-lg border border-slate-800 flex items-center justify-between gap-2"
                    >
                      <span className="italic">"{starter}"</span>
                      <button
                        onClick={() => handleCopy(starter, `starter-${i}`)}
                        className="text-slate-400 hover:text-sky-300 p-1 cursor-pointer shrink-0"
                      >
                        {copiedId === `starter-${i}` ? (
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'email' && (
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[11px] text-slate-400">
                  Ready-to-send personalized cold outreach template:
                </span>
                <button
                  onClick={() => handleCopy(payload.outreachEmailSample, 'outreach-email')}
                  className="px-2.5 py-1 rounded-lg bg-sky-600/30 hover:bg-sky-600/50 text-sky-200 border border-sky-500/30 text-[11px] font-medium flex items-center gap-1 cursor-pointer"
                >
                  {copiedId === 'outreach-email' ? (
                    <>
                      <Check className="w-3 h-3 text-emerald-400" /> Copied
                    </>
                  ) : (
                    <>
                      <Copy className="w-3 h-3" /> Copy Email
                    </>
                  )}
                </button>
              </div>
              <pre className="p-3 rounded-xl bg-[#070b18] border border-sky-950 font-mono text-[11px] leading-relaxed text-slate-200 whitespace-pre-wrap select-text">
                {payload.outreachEmailSample}
              </pre>
            </div>
          )}

          {activeTab === 'icp' && (
            <div className="p-3 rounded-xl bg-[#0e152e] border border-sky-900/60 space-y-2">
              <div className="font-semibold text-sky-300 text-[12px]">
                Target ICP Specification
              </div>
              <div className="grid grid-cols-2 gap-2 text-[11px]">
                <div>
                  <span className="text-slate-400">Company Size:</span>{' '}
                  <span className="text-slate-200">{payload.icpSummary.companySize}</span>
                </div>
                <div>
                  <span className="text-slate-400">Geography:</span>{' '}
                  <span className="text-slate-200">{payload.icpSummary.geography}</span>
                </div>
              </div>
              <div>
                <span className="text-slate-400 text-[10px] uppercase font-semibold">
                  Key Pain Points Solved:
                </span>
                <div className="flex flex-wrap gap-1.5 mt-1">
                  {payload.icpSummary.painPoints.map((p, i) => (
                    <span
                      key={i}
                      className="px-2 py-0.5 rounded-full bg-sky-950 text-sky-300 border border-sky-800 text-[10px]"
                    >
                      {p}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  // ==========================================================================
  // 2. MCP BUILDER CARD
  // ==========================================================================
  if (payload.kind === 'mcp-builder') {
    const [codeTab, setCodeTab] = useState<'ts' | 'py' | 'eval'>('ts');

    const activeCode =
      codeTab === 'ts'
        ? payload.typescriptCode
        : codeTab === 'py'
        ? payload.pythonFastMcpCode
        : payload.evaluationXml;

    const fileExt = codeTab === 'ts' ? 'ts' : codeTab === 'py' ? 'py' : 'xml';
    const mime = codeTab === 'eval' ? 'application/xml' : 'text/plain';

    return (
      <div className="mt-3 rounded-2xl border border-indigo-500/40 bg-[#0c0d22] overflow-hidden shadow-xl text-slate-200 text-xs">
        {/* Header */}
        <div className="px-3.5 py-2.5 bg-[#141535] border-b border-indigo-500/30 flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-lg bg-indigo-500/20 text-indigo-400 flex items-center justify-center font-bold">
              <Server className="w-3.5 h-3.5" />
            </div>
            <div>
              <div className="text-[13px] font-semibold text-indigo-300">
                MCP Server & XML Evaluation Harness
              </div>
              <div className="text-[10px] text-slate-400">
                Server: <span className="font-mono text-indigo-200">{payload.serverName}</span> · Protocol: {payload.protocolVersion}
              </div>
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => handleDownload(`${payload.serverName}.${fileExt}`, activeCode, mime)}
              className="px-2.5 py-1 rounded-lg bg-indigo-600/30 hover:bg-indigo-600/50 text-indigo-200 border border-indigo-500/30 text-[11px] font-medium flex items-center gap-1 cursor-pointer transition-colors"
            >
              <Download className="w-3 h-3" />
              Download
            </button>
            <button
              onClick={() => handleCopy(activeCode, 'mcp-code')}
              className="px-2.5 py-1 rounded-lg bg-[#1e204a] hover:bg-[#282b63] text-indigo-200 border border-indigo-500/30 text-[11px] font-medium flex items-center gap-1 cursor-pointer"
            >
              {copiedId === 'mcp-code' ? (
                <>
                  <Check className="w-3 h-3 text-emerald-400" /> Copied
                </>
              ) : (
                <>
                  <Copy className="w-3 h-3" /> Copy
                </>
              )}
            </button>
          </div>
        </div>

        {/* Code Tabs */}
        <div className="flex border-b border-indigo-950/80 bg-[#080918] px-3 pt-2 gap-2">
          <button
            onClick={() => setCodeTab('ts')}
            className={`pb-1.5 px-2.5 font-medium border-b-2 text-[11px] cursor-pointer transition-all ${
              codeTab === 'ts'
                ? 'border-indigo-400 text-indigo-300 font-semibold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            TypeScript SDK (Node.js)
          </button>
          <button
            onClick={() => setCodeTab('py')}
            className={`pb-1.5 px-2.5 font-medium border-b-2 text-[11px] cursor-pointer transition-all ${
              codeTab === 'py'
                ? 'border-indigo-400 text-indigo-300 font-semibold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Python FastMCP
          </button>
          <button
            onClick={() => setCodeTab('eval')}
            className={`pb-1.5 px-2.5 font-medium border-b-2 text-[11px] cursor-pointer transition-all ${
              codeTab === 'eval'
                ? 'border-indigo-400 text-indigo-300 font-semibold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            XML Evaluation Harness
          </button>
        </div>

        {/* Quality checklist */}
        <div className="px-3.5 py-2 bg-[#090b1c] border-b border-indigo-950 flex flex-wrap gap-2">
          {payload.qualityChecklist.map((c, i) => (
            <span
              key={i}
              className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-950/60 text-emerald-300 border border-emerald-500/30 flex items-center gap-1"
            >
              <Check className="w-2.5 h-2.5" />
              {c.check}
            </span>
          ))}
        </div>

        {/* Code Viewer */}
        <div className="p-3">
          <pre className="p-3 rounded-xl bg-[#060714] border border-indigo-950/90 font-mono text-[10.5px] leading-relaxed text-indigo-100 overflow-x-auto max-h-64 select-text">
            {activeCode}
          </pre>
        </div>
      </div>
    );
  }

  // ==========================================================================
  // 3. MEETING INSIGHTS ANALYZER CARD
  // ==========================================================================
  if (payload.kind === 'meeting-insights-analyzer') {
    const [selectedPatternIdx, setSelectedPatternIdx] = useState<number>(0);
    const pattern = payload.patterns[selectedPatternIdx] || payload.patterns[0];

    return (
      <div className="mt-3 rounded-2xl border border-amber-500/40 bg-[#141008] overflow-hidden shadow-xl text-slate-200 text-xs">
        {/* Header */}
        <div className="px-3.5 py-2.5 bg-[#211a0d] border-b border-amber-500/30 flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold">
              <TrendingUp className="w-3.5 h-3.5" />
            </div>
            <div>
              <div className="text-[13px] font-semibold text-amber-300 flex items-center gap-2">
                Meeting Communication Insights
                <span className="text-[9px] font-mono uppercase px-1.5 py-0.5 rounded bg-amber-950/80 text-amber-300 border border-amber-500/40">
                  Rough Heuristic Estimates
                </span>
              </div>
              <div className="text-[10px] text-slate-400">
                {payload.meetingTitle} · Local Behavioral Parser (Granola/Fireflies Rejected)
              </div>
            </div>
          </div>
          <button
            onClick={() => handleDownload('meeting_insights.md', payload.markdownReport, 'text/markdown')}
            className="px-2.5 py-1 rounded-lg bg-amber-600/30 hover:bg-amber-600/50 text-amber-200 border border-amber-500/30 text-[11px] font-medium flex items-center gap-1 cursor-pointer"
          >
            <Download className="w-3 h-3" />
            Report
          </button>
        </div>

        {/* Formula Explanation Note */}
        <div className="px-3 py-1.5 bg-[#181207] border-b border-amber-950/80 text-[10px] text-amber-300/80 flex items-center gap-1.5">
          <span className="font-semibold text-amber-400">Formula Breakdown:</span>
          <span>Speaking % = (words / total) * 100 · Directness = 10 - 1.2 × hedges · Filler = count / minutes</span>
        </div>

        {/* 4 Metric Badges */}
        <div className="p-3 grid grid-cols-4 gap-2 bg-[#0e0b05] border-b border-amber-950">
          <div className="p-2 rounded-xl bg-[#1a1409] border border-amber-900/50 text-center">
            <div className="text-[9.5px] text-slate-400 uppercase">Speaking Ratio</div>
            <div className="text-[14px] font-bold text-amber-300 mt-0.5">{payload.userSpeakingPercentage}%</div>
            <div className="text-[8.5px] text-emerald-400">Balanced</div>
          </div>
          <div className="p-2 rounded-xl bg-[#1a1409] border border-amber-900/50 text-center">
            <div className="text-[9.5px] text-slate-400 uppercase">Directness</div>
            <div className="text-[14px] font-bold text-amber-300 mt-0.5">{payload.conflictAvoidanceScore}/10</div>
            <div className="text-[8.5px] text-amber-400">Hedging Noted</div>
          </div>
          <div className="p-2 rounded-xl bg-[#1a1409] border border-amber-900/50 text-center">
            <div className="text-[9.5px] text-slate-400 uppercase">Filler Words</div>
            <div className="text-[14px] font-bold text-amber-300 mt-0.5">{payload.fillerWordsPerMin}/min</div>
            <div className="text-[8.5px] text-slate-400">{payload.fillerWordCount} total</div>
          </div>
          <div className="p-2 rounded-xl bg-[#1a1409] border border-amber-900/50 text-center">
            <div className="text-[9.5px] text-slate-400 uppercase">Active Listen</div>
            <div className="text-[14px] font-bold text-emerald-400 mt-0.5">{payload.activeListeningScore}/10</div>
            <div className="text-[8.5px] text-emerald-300">Strong</div>
          </div>
        </div>

        {/* Pattern Details */}
        <div className="p-3.5 space-y-3">
          <div className="flex gap-2">
            {payload.patterns.map((p, idx) => (
              <button
                key={p.name}
                onClick={() => setSelectedPatternIdx(idx)}
                className={`px-3 py-1.5 rounded-xl border text-left cursor-pointer transition-all ${
                  selectedPatternIdx === idx
                    ? 'bg-amber-950/80 border-amber-400 text-amber-200'
                    : 'bg-[#151006] border-slate-800 text-slate-400'
                }`}
              >
                <div className="font-semibold text-[11px]">{p.name}</div>
                <div className="text-[9.5px] text-slate-400">{p.frequency}</div>
              </button>
            ))}
          </div>

          {/* Quotes Comparison */}
          {pattern && (
            <div className="p-3 rounded-xl bg-[#1a1409] border border-amber-900/60 space-y-2.5">
              <div className="text-[12px] font-semibold text-amber-200">{pattern.finding}</div>
              {pattern.examples.map((ex, i) => (
                <div key={i} className="p-2.5 rounded-lg bg-[#0e0a04] border border-amber-950 space-y-1.5">
                  <div className="flex items-center justify-between text-[10px] text-amber-400/80 font-mono">
                    <span>{ex.meetingName}</span>
                    <span>Timestamp: {ex.timestamp}</span>
                  </div>
                  <div>
                    <span className="text-[10px] font-semibold text-rose-400 uppercase">What Happened:</span>
                    <div className="text-[11px] text-rose-200 italic pl-1 mt-0.5">{ex.actualQuote}</div>
                  </div>
                  <div>
                    <span className="text-[10px] font-semibold text-amber-400 uppercase">Why It Matters:</span>
                    <div className="text-[11px] text-slate-300 pl-1 mt-0.5">{ex.whyItMatters}</div>
                  </div>
                  <div className="pt-1 border-t border-amber-950">
                    <span className="text-[10px] font-semibold text-emerald-400 uppercase">Better Approach:</span>
                    <div className="text-[11px] text-emerald-200 font-medium pl-1 mt-0.5">{ex.betterApproach}</div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    );
  }

  // ==========================================================================
  // 4. RAFFLE WINNER PICKER CARD
  // ==========================================================================
  if (payload.kind === 'raffle-winner-picker') {
    return (
      <div className="mt-3 rounded-2xl border border-yellow-500/40 bg-[#161204] overflow-hidden shadow-xl text-slate-200 text-xs">
        {/* Header */}
        <div className="px-3.5 py-2.5 bg-[#261f06] border-b border-yellow-500/30 flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-lg bg-yellow-500/20 text-yellow-400 flex items-center justify-center font-bold">
              <Trophy className="w-3.5 h-3.5" />
            </div>
            <div>
              <div className="text-[13px] font-semibold text-yellow-300">
                Cryptographically Fair Raffle Winner
              </div>
              <div className="text-[10px] text-slate-400">
                {payload.giveawayTitle} · Web Crypto CSPRNG
              </div>
            </div>
          </div>
          <span className="px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-500/30 text-[10px] font-semibold">
            100% Unbiased ✓
          </span>
        </div>

        {/* Winner Announcement Banner */}
        <div className="p-4 bg-gradient-to-b from-yellow-950/40 to-[#120f03] text-center space-y-2 border-b border-yellow-950">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-yellow-500/20 text-yellow-300 border border-yellow-500/40 font-bold text-[11px]">
            <Sparkles className="w-3.5 h-3.5 text-yellow-400" />
            WINNER SELECTED!
          </div>

          <div className="text-xl sm:text-2xl font-extrabold text-white tracking-wide">
            {payload.winners[0]?.name || 'Sarah Johnson'}
          </div>
          <div className="text-[11px] text-yellow-200/80 font-mono">
            {payload.winners[0]?.entryDetail || 'Verified Contestant Entry'}
          </div>
        </div>

        {/* Runner-ups */}
        <div className="p-3.5 space-y-2.5">
          <div className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
            Verified Runner-Ups:
          </div>
          <div className="grid grid-cols-2 gap-2">
            {payload.runnerUps.map((ru) => (
              <div
                key={ru.rank}
                className="p-2 rounded-xl bg-[#201908] border border-yellow-900/50 flex items-center justify-between gap-1"
              >
                <div>
                  <div className="text-[9.5px] text-yellow-400 font-semibold">Rank #{ru.rank}</div>
                  <div className="text-[11px] text-slate-200 font-medium truncate max-w-[140px]">{ru.name}</div>
                </div>
              </div>
            ))}
          </div>

          {/* Audit Proof Box */}
          <div className="p-2.5 rounded-xl bg-[#0d0a02] border border-yellow-950 space-y-1">
            <div className="text-[9.5px] font-semibold text-slate-400 uppercase">Cryptographic Audit Proof:</div>
            <div className="grid grid-cols-2 gap-2 text-[10px] text-slate-300 font-mono">
              <div>
                <span className="text-slate-500">Seed:</span> {payload.cryptoSeedHex}
              </div>
              <div>
                <span className="text-slate-500">Timestamp:</span> {payload.timestampUtc.slice(11, 19)} UTC
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // ==========================================================================
  // 5. SKILL CREATOR CARD
  // ==========================================================================
  if (payload.kind === 'skill-creator') {
    return (
      <div className="mt-3 rounded-2xl border border-teal-500/40 bg-[#071714] overflow-hidden shadow-xl text-slate-200 text-xs">
        {/* Header */}
        <div className="px-3.5 py-2.5 bg-[#0d2621] border-b border-teal-500/30 flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-lg bg-teal-500/20 text-teal-400 flex items-center justify-center font-bold">
              <Package className="w-3.5 h-3.5" />
            </div>
            <div>
              <div className="text-[13px] font-semibold text-teal-300">
                Modular Skill Package Created
              </div>
              <div className="text-[10px] text-slate-400 font-mono">
                /{payload.skillName}/SKILL.md
              </div>
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => handleDownload('SKILL.md', payload.skillMdContent, 'text/markdown')}
              className="px-2.5 py-1 rounded-lg bg-teal-600/30 hover:bg-teal-600/50 text-teal-200 border border-teal-500/30 text-[11px] font-medium flex items-center gap-1 cursor-pointer"
            >
              <Download className="w-3 h-3" />
              SKILL.md
            </button>
            <button
              onClick={() => handleCopy(payload.skillMdContent, 'skill-md')}
              className="px-2.5 py-1 rounded-lg bg-[#143932] hover:bg-[#1a4a41] text-teal-200 border border-teal-500/30 text-[11px] font-medium flex items-center gap-1 cursor-pointer"
            >
              {copiedId === 'skill-md' ? (
                <>
                  <Check className="w-3 h-3 text-emerald-400" /> Copied
                </>
              ) : (
                <>
                  <Copy className="w-3 h-3" /> Copy
                </>
              )}
            </button>
          </div>
        </div>

        {/* Validation Badges */}
        <div className="px-3.5 py-2 bg-[#04100e] border-b border-teal-950 flex flex-wrap gap-2 text-[10px]">
          <span className="px-2 py-0.5 rounded-full bg-emerald-950/80 text-emerald-300 border border-emerald-500/30 flex items-center gap-1">
            <Check className="w-2.5 h-2.5" /> YAML Frontmatter
          </span>
          <span className="px-2 py-0.5 rounded-full bg-emerald-950/80 text-emerald-300 border border-emerald-500/30 flex items-center gap-1">
            <Check className="w-2.5 h-2.5" /> Hyphen-Case Name
          </span>
          <span className="px-2 py-0.5 rounded-full bg-emerald-950/80 text-emerald-300 border border-emerald-500/30 flex items-center gap-1">
            <Check className="w-2.5 h-2.5" /> 3rd-Person Imperative
          </span>
        </div>

        {/* Directory Layout & SKILL.md preview */}
        <div className="p-3.5 space-y-3">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1">
              <span className="text-[10px] font-semibold text-slate-400 uppercase">Directory Tree:</span>
              <pre className="p-2.5 rounded-xl bg-[#040e0c] border border-teal-950 font-mono text-[10.5px] text-teal-200 leading-tight">
                {payload.directoryTree}
              </pre>
            </div>
            <div className="space-y-1">
              <span className="text-[10px] font-semibold text-slate-400 uppercase">Package Command:</span>
              <pre className="p-2.5 rounded-xl bg-[#040e0c] border border-teal-950 font-mono text-[10.5px] text-slate-300 leading-tight">
                {payload.packageCommand}
              </pre>
            </div>
          </div>

          <div className="space-y-1">
            <span className="text-[10px] font-semibold text-slate-400 uppercase">SKILL.md Source:</span>
            <pre className="p-3 rounded-xl bg-[#030a09] border border-teal-950 font-mono text-[10px] text-slate-300 leading-relaxed overflow-x-auto max-h-48 select-text">
              {payload.skillMdContent}
            </pre>
          </div>
        </div>
      </div>
    );
  }

  // ==========================================================================
  // 6. SKILL SHARE CARD (Free Slack Webhook Integration)
  // ==========================================================================
  if (payload.kind === 'skill-share') {
    const [broadcastStatus, setBroadcastStatus] = useState<'idle' | 'broadcasting' | 'success' | 'error'>('idle');
    const [broadcastMsg, setBroadcastMsg] = useState<string>('');

    const handleBroadcastToSlack = async () => {
      const webhookUrl = getToolApiKey('slack_webhook_url');
      if (!webhookUrl) {
        setBroadcastStatus('error');
        setBroadcastMsg('Free Slack Webhook URL is missing. Please save it in Settings > Tools API.');
        return;
      }

      setBroadcastStatus('broadcasting');
      try {
        const res = await fetch('/api/tools/slack-broadcast', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            webhookUrl,
            payload: JSON.parse(payload.slackBlocksJson),
          }),
        });

        const data = await res.json();
        if (res.ok && data.success) {
          setBroadcastStatus('success');
          setBroadcastMsg('Skill announced to Slack channel successfully!');
        } else {
          setBroadcastStatus('error');
          setBroadcastMsg(data.error || 'Failed to post message to Slack.');
        }
      } catch (err: any) {
        setBroadcastStatus('error');
        setBroadcastMsg(err.message || 'Network error reaching server proxy.');
      }
    };

    return (
      <div className="mt-3 rounded-2xl border border-emerald-500/40 bg-[#061710] overflow-hidden shadow-xl text-slate-200 text-xs">
        {/* Header */}
        <div className="px-3.5 py-2.5 bg-[#0a271b] border-b border-emerald-500/30 flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold">
              <Share2 className="w-3.5 h-3.5" />
            </div>
            <div>
              <div className="text-[13px] font-semibold text-emerald-300">
                Skill Share (Slack Integration)
              </div>
              <div className="text-[10px] text-slate-400">
                Free Slack Incoming Webhook · Rube Replaced
              </div>
            </div>
          </div>
          <button
            onClick={() => handleCopy(payload.slackBlocksJson, 'slack-json')}
            className="px-2.5 py-1 rounded-lg bg-[#0e3b29] hover:bg-[#134d36] text-emerald-200 border border-emerald-500/30 text-[11px] font-medium flex items-center gap-1 cursor-pointer"
          >
            {copiedId === 'slack-json' ? (
              <>
                <Check className="w-3 h-3 text-emerald-400" /> Copied
              </>
            ) : (
              <>
                <Copy className="w-3 h-3" /> Copy Slack JSON
              </>
            )}
          </button>
        </div>

        {/* Webhook Status Banner */}
        <div className="p-3.5 space-y-3">
          {payload.slackWebhookConfigured ? (
            <div className="p-3 rounded-xl bg-emerald-950/60 border border-emerald-500/40 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-emerald-300 text-[12px] flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  Free Slack Webhook Active
                </span>
                <span className="text-[10.5px] font-mono text-emerald-400/90">{payload.maskedWebhook}</span>
              </div>
              <p className="text-[11px] text-slate-300">
                Target recommendation: <span className="font-mono text-emerald-200">{payload.channelRecommendation}</span>
              </p>
              <div className="flex items-center gap-2 pt-1">
                <button
                  onClick={handleBroadcastToSlack}
                  disabled={broadcastStatus === 'broadcasting'}
                  className="px-3.5 py-1.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-[11px] flex items-center gap-1.5 cursor-pointer disabled:opacity-50 transition-colors"
                >
                  <Send className="w-3.5 h-3.5" />
                  {broadcastStatus === 'broadcasting' ? 'Posting to Slack...' : 'Broadcast to Slack Channel'}
                </button>
                {broadcastStatus === 'success' && (
                  <span className="text-[11px] text-emerald-400 font-semibold">{broadcastMsg}</span>
                )}
                {broadcastStatus === 'error' && (
                  <span className="text-[11px] text-rose-400 font-semibold">{broadcastMsg}</span>
                )}
              </div>
            </div>
          ) : (
            <div className="p-3 rounded-xl bg-amber-950/60 border border-amber-500/40 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-amber-300 text-[12px] flex items-center gap-1.5">
                  <AlertTriangle className="w-4 h-4 text-amber-400" />
                  PENDING — Free API key required
                </span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-900 text-amber-200">
                  Slack Webhook Needed
                </span>
              </div>
              <p className="text-[11px] text-slate-300 leading-relaxed">
                Skill is packaged and Block Kit JSON is generated. To broadcast directly to your Slack channel, enter your free Slack Incoming Webhook URL in Settings &gt; Tools API.
              </p>
              <div className="flex items-center gap-2 pt-1">
                <button
                  onClick={onOpenToolApiKeys}
                  className="px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-[11px] flex items-center gap-1 cursor-pointer transition-colors"
                >
                  <KeyRound className="w-3.5 h-3.5" />
                  Open Settings &gt; Tools API
                </button>
              </div>
            </div>
          )}

          {/* Formatted Block Preview */}
          <div className="space-y-1">
            <span className="text-[10px] font-semibold text-slate-400 uppercase">
              Slack Block Kit JSON:
            </span>
            <pre className="p-2.5 rounded-xl bg-[#030b08] border border-emerald-950 font-mono text-[10px] text-emerald-200 leading-tight max-h-40 overflow-y-auto select-text">
              {payload.slackBlocksJson}
            </pre>
          </div>
        </div>
      </div>
    );
  }

  // ==========================================================================
  // 7. SLACK GIF CREATOR CARD
  // ==========================================================================
  if (payload.kind === 'slack-gif-creator') {
    const canvasRef = useRef<HTMLCanvasElement | null>(null);
    const [isPlaying, setIsPlaying] = useState<boolean>(true);
    const [selectedPrimitive, setSelectedPrimitive] = useState<SlackGifPayload['primitive']>(payload.primitive);
    const frameIndexRef = useRef<number>(0);
    const animIdRef = useRef<number | null>(null);

    // Live HTML5 Canvas rendering for Slack Animation Primitives
    useEffect(() => {
      const canvas = canvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      const w = canvas.width;
      const h = canvas.height;
      let frame = 0;

      const render = () => {
        ctx.clearRect(0, 0, w, h);

        // Dark background with subtle grid
        ctx.fillStyle = '#0f172a';
        ctx.fillRect(0, 0, w, h);

        const cx = w / 2;
        const cy = h / 2;

        ctx.save();

        if (selectedPrimitive === 'bounce') {
          const t = (frame % 20) / 19;
          const bounceY = Math.abs(Math.sin(t * Math.PI)) * (h * 0.35);
          ctx.translate(cx, cy + (h * 0.2) - bounceY);
        } else if (selectedPrimitive === 'shake') {
          const shakeX = Math.sin(frame * 0.9) * (w * 0.08);
          const shakeY = Math.cos(frame * 1.2) * (h * 0.04);
          ctx.translate(cx + shakeX, cy + shakeY);
        } else if (selectedPrimitive === 'spin') {
          ctx.translate(cx, cy);
          ctx.rotate((frame * 0.15) % (Math.PI * 2));
        } else if (selectedPrimitive === 'pulse') {
          const scale = 1.0 + Math.sin(frame * 0.25) * 0.25;
          ctx.translate(cx, cy);
          ctx.scale(scale, scale);
        } else if (selectedPrimitive === 'kaleidoscope') {
          ctx.translate(cx, cy);
          ctx.rotate(frame * 0.05);
          for (let k = 0; k < 4; k++) {
            ctx.rotate(Math.PI / 2);
            ctx.fillStyle = '#818cf8';
            ctx.beginPath();
            ctx.arc(w * 0.2, 0, w * 0.08, 0, Math.PI * 2);
            ctx.fill();
          }
        }

        // Draw center emoji
        ctx.font = `${Math.floor(w * 0.4)}px serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(payload.emoji, 0, 0);

        ctx.restore();

        // Caption if present
        if (payload.caption) {
          ctx.fillStyle = '#f8fafc';
          ctx.font = 'bold 12px sans-serif';
          ctx.textAlign = 'center';
          ctx.fillText(payload.caption, cx, h - 12);
        }

        frameIndexRef.current = frame;
        frame++;

        if (isPlaying) {
          animIdRef.current = requestAnimationFrame(render);
        }
      };

      animIdRef.current = requestAnimationFrame(render);

      return () => {
        if (animIdRef.current) cancelAnimationFrame(animIdRef.current);
      };
    }, [isPlaying, selectedPrimitive, payload.emoji, payload.caption]);

    return (
      <div className="mt-3 rounded-2xl border border-pink-500/40 bg-[#190914] overflow-hidden shadow-xl text-slate-200 text-xs">
        {/* Header */}
        <div className="px-3.5 py-2.5 bg-[#2d0f23] border-b border-pink-500/30 flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-lg bg-pink-500/20 text-pink-400 flex items-center justify-center font-bold">
              <Film className="w-3.5 h-3.5" />
            </div>
            <div>
              <div className="text-[13px] font-semibold text-pink-300">
                Slack GIF Creator & Validator
              </div>
              <div className="text-[10px] text-slate-400">
                Target: {payload.gifType === 'emoji' ? 'Emoji GIF (<64KB, 128x128)' : 'Message GIF (<2MB, 480x480)'}
              </div>
            </div>
          </div>
          <span className="px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-500/30 text-[10px] font-semibold">
            Slack Compliant ✓
          </span>
        </div>

        {/* Live Canvas Preview + Primitive Controls */}
        <div className="p-3.5 space-y-3">
          <div className="flex flex-col sm:flex-row items-center gap-4">
            {/* Canvas Box */}
            <div className="relative p-2 rounded-2xl bg-black/60 border border-pink-900/60 flex items-center justify-center">
              <canvas
                ref={canvasRef}
                width={payload.dimensions.width > 200 ? 180 : 128}
                height={payload.dimensions.height > 200 ? 180 : 128}
                className="rounded-xl shadow-lg"
              />
              <button
                onClick={() => setIsPlaying(!isPlaying)}
                className="absolute bottom-3 right-3 p-1.5 rounded-lg bg-pink-600/80 hover:bg-pink-600 text-white cursor-pointer"
                title={isPlaying ? 'Pause' : 'Play'}
              >
                {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
              </button>
            </div>

            {/* Primitive Selector */}
            <div className="space-y-2 flex-1 w-full">
              <div className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
                Animation Primitives:
              </div>
              <div className="grid grid-cols-3 gap-1.5">
                {(['bounce', 'shake', 'spin', 'pulse', 'kaleidoscope'] as const).map((prim) => (
                  <button
                    key={prim}
                    onClick={() => setSelectedPrimitive(prim)}
                    className={`px-2.5 py-1.5 rounded-lg border text-center capitalize cursor-pointer transition-all ${
                      selectedPrimitive === prim
                        ? 'bg-pink-950 border-pink-400 text-pink-200 font-bold'
                        : 'bg-[#1f0b19] border-slate-800 text-slate-400'
                    }`}
                  >
                    {prim}
                  </button>
                ))}
              </div>

              {/* Slack Limits Checklist */}
              <div className="p-2 rounded-xl bg-[#12050e] border border-pink-950 space-y-1 text-[10.5px]">
                <div className="flex justify-between text-slate-300">
                  <span>Size Limit:</span>
                  <span className="font-semibold text-emerald-400">
                    {payload.estimatedSizeKb} KB / {payload.sizeLimitKb} KB max
                  </span>
                </div>
                <div className="flex justify-between text-slate-300">
                  <span>Dimensions:</span>
                  <span className="font-mono text-pink-300">
                    {payload.dimensions.width}x{payload.dimensions.height}
                  </span>
                </div>
                <div className="flex justify-between text-slate-300">
                  <span>Color Quantization:</span>
                  <span className="text-slate-200">{payload.colorCount} colors</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // ==========================================================================
  // 8. TAILORED RESUME GENERATOR CARD
  // ==========================================================================
  if (payload.kind === 'tailored-resume-generator') {
    const [resumeTab, setResumeTab] = useState<'md' | 'plain' | 'prep'>('md');

    return (
      <div className="mt-3 rounded-2xl border border-blue-500/40 bg-[#091122] overflow-hidden shadow-xl text-slate-200 text-xs">
        {/* Header */}
        <div className="px-3.5 py-2.5 bg-[#0f1d3b] border-b border-blue-500/30 flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-lg bg-blue-500/20 text-blue-400 flex items-center justify-center font-bold">
              <Briefcase className="w-3.5 h-3.5" />
            </div>
            <div>
              <div className="text-[13px] font-semibold text-blue-300">
                Tailored ATS Resume Generator
              </div>
              <div className="text-[10px] text-slate-400">
                Target: {payload.targetJobTitle} ({payload.companyName})
              </div>
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => handleDownload('tailored_resume.md', payload.fullMarkdownResume, 'text/markdown')}
              className="px-2.5 py-1 rounded-lg bg-blue-600/30 hover:bg-blue-600/50 text-blue-200 border border-blue-500/30 text-[11px] font-medium flex items-center gap-1 cursor-pointer"
            >
              <Download className="w-3 h-3" />
              MD
            </button>
            <button
              onClick={() => handleCopy(payload.fullMarkdownResume, 'resume-md')}
              className="px-2.5 py-1 rounded-lg bg-[#192b52] hover:bg-[#203768] text-blue-200 border border-blue-500/30 text-[11px] font-medium flex items-center gap-1 cursor-pointer"
            >
              {copiedId === 'resume-md' ? (
                <>
                  <Check className="w-3 h-3 text-emerald-400" /> Copied
                </>
              ) : (
                <>
                  <Copy className="w-3 h-3" /> Copy
                </>
              )}
            </button>
          </div>
        </div>

        {/* ATS Score & Tabs */}
        <div className="px-3.5 py-2 bg-[#060c18] border-b border-blue-950 flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="text-[10px] uppercase font-semibold text-slate-400">ATS Match Score:</span>
            <span className="px-2.5 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-500/40 font-bold text-[11px]">
              {payload.atsMatchScore}% Compatible
            </span>
          </div>

          <div className="flex gap-2">
            <button
              onClick={() => setResumeTab('md')}
              className={`px-2 py-0.5 rounded-lg text-[10.5px] cursor-pointer ${
                resumeTab === 'md' ? 'bg-blue-950 text-blue-300 font-bold' : 'text-slate-400'
              }`}
            >
              Formatted
            </button>
            <button
              onClick={() => setResumeTab('plain')}
              className={`px-2 py-0.5 rounded-lg text-[10.5px] cursor-pointer ${
                resumeTab === 'plain' ? 'bg-blue-950 text-blue-300 font-bold' : 'text-slate-400'
              }`}
            >
              Plain Text (ATS)
            </button>
            <button
              onClick={() => setResumeTab('prep')}
              className={`px-2 py-0.5 rounded-lg text-[10.5px] cursor-pointer ${
                resumeTab === 'prep' ? 'bg-blue-950 text-blue-300 font-bold' : 'text-slate-400'
              }`}
            >
              Interview Guide
            </button>
          </div>
        </div>

        {/* Tab Content */}
        <div className="p-3.5 space-y-3">
          {resumeTab === 'md' && (
            <div className="space-y-3">
              {/* ATS Keywords */}
              <div>
                <span className="text-[10px] font-semibold text-slate-400 uppercase">
                  Matched ATS Keywords:
                </span>
                <div className="flex flex-wrap gap-1.5 mt-1">
                  {payload.matchedAtsKeywords.map((kw, i) => (
                    <span
                      key={i}
                      className="px-2 py-0.5 rounded-md bg-blue-950 text-blue-200 border border-blue-800 text-[10px]"
                    >
                      {kw}
                    </span>
                  ))}
                </div>
              </div>

              {/* Formatted Resume Preview */}
              <div className="p-3 rounded-xl bg-[#070e1c] border border-blue-900/60 font-sans text-[11px] text-slate-200 leading-relaxed space-y-2 select-text max-h-60 overflow-y-auto">
                <div className="font-bold text-[13px] text-white">{payload.candidateName}</div>
                <div className="italic text-slate-400">{payload.professionalSummary}</div>
                <div className="font-bold text-blue-300 pt-1">Professional Experience Highlights:</div>
                <ul className="list-disc pl-4 space-y-1.5 text-slate-300">
                  {payload.experienceHighlights[0]?.bullets.map((b, i) => (
                    <li key={i}>
                      <span className="font-bold text-blue-200">{b.actionVerb}</span> {b.what}{' '}
                      <span className="text-emerald-300 font-semibold">{b.impactResult}</span>.
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          )}

          {resumeTab === 'plain' && (
            <pre className="p-3 rounded-xl bg-[#040810] border border-blue-950 font-mono text-[10.5px] text-slate-300 leading-relaxed max-h-60 overflow-y-auto select-text whitespace-pre-wrap">
              {payload.plainTextAtsResume}
            </pre>
          )}

          {resumeTab === 'prep' && (
            <div className="p-3 rounded-xl bg-[#070e1c] border border-blue-900/60 space-y-2.5">
              <div>
                <span className="text-[10px] font-semibold text-emerald-400 uppercase">
                  Interview Talking Points:
                </span>
                <ul className="list-disc pl-4 space-y-1 text-slate-300 text-[11px] mt-1">
                  {payload.interviewTalkingPoints.map((tp, i) => (
                    <li key={i}>{tp}</li>
                  ))}
                </ul>
              </div>
              <div className="pt-1 border-t border-blue-950">
                <span className="text-[10px] font-semibold text-blue-400 uppercase">
                  Cover Letter Opening Hooks:
                </span>
                <div className="space-y-1.5 mt-1">
                  {payload.coverLetterHooks.map((hook, i) => (
                    <div key={i} className="p-2 rounded-lg bg-[#040810] text-[11px] italic text-slate-300">
                      "{hook}"
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  return null;
};
