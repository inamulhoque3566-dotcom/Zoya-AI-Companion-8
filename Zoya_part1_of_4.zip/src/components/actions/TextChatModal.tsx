import React, { useState, useRef, useEffect } from 'react';
import {
  X,
  Send,
  MessageSquare,
  Sparkles,
  User,
  RotateCcw,
  Wrench,
} from 'lucide-react';

import {
  getLanguageConfig,
  getLocalizedTemplates,
  getLocalizedZoyaReply,
} from '../../services/languageConfig';
import {
  detectPart1SkillIntent,
  executePart1Skill,
  Part1SkillOutput,
} from '../../services/zoyaSkillsPart1';
import {
  detectPart2And4SkillIntent,
  executePart2And4Skill,
} from '../../services/zoyaSkillsPart2And4';
import {
  detectPart5And6SkillIntent,
  executePart5And6Skill,
  Part5And6SkillPayload,
} from '../../services/zoyaSkillsPart5And6';
import {
  detectPart7SkillIntent,
  executePart7Skill,
  Part7SkillPayload,
} from '../../services/zoyaSkillsPart7';
import { Part1SkillOutputCard } from './Part1SkillOutputCard';
import { Part5And6SkillOutputCard } from './Part5And6SkillOutputCard';
import { Part7SkillOutputCard } from './Part7SkillOutputCard';
import { zoyaMemory } from '../../services/zoyaMemoryEngine';
import { isWebsiteIntentPrompt } from '../../services/websiteBuilderUtils';
import {
  latencyLogger,
  selectOptimalModelForRequest,
  splitVoiceReplyAndVisualCard,
  extractFirstCompleteSentence,
} from '../../services/latencyLogger';

interface TextChatModalProps {
  isOpen: boolean;
  onClose: () => void;
  personaMode: string;
  language?: string;
  onSpeakText?: (text: string) => void;
  onOpenToolApiKeys?: () => void;
  onOpenWebsiteBuilder?: (prompt: string) => void;
  initialPrompt?: string;
  onClearInitialPrompt?: () => void;
}

interface ChatMessage {
  id: string;
  sender: 'user' | 'zoya';
  text: string;
  time: string;
  skillOutput?: Part1SkillOutput;
  part56Output?: Part5And6SkillPayload;
  part7Output?: Part7SkillPayload;
}

const PART7_SKILL_QUICK_CHIPS = [
  {
    label: '🎨 Theme Factory (10 Palettes)',
    prompt: 'theme-factory show theme showcase and apply Ocean Depths color palette',
  },
  {
    label: '📈 Twitter Algorithm Optimizer',
    prompt: 'twitter-algorithm-optimizer optimize tweet: We shipped a major update to our audio pipeline today. Check it out.',
  },
];

const PART56_SKILL_QUICK_CHIPS = [
  {
    label: '🎯 Lead Research Assistant',
    prompt: 'lead-research-assistant find leads for cloud workflow automation software',
  },
  {
    label: '⚙️ MCP Server Builder',
    prompt: 'mcp-builder create workflow MCP server with TypeScript and FastMCP',
  },
  {
    label: '🎙️ Meeting Insights Analyzer',
    prompt: 'meeting-insights-analyzer analyze transcript and check conflict avoidance and speaking ratio',
  },
  {
    label: '🎉 Raffle Winner Picker',
    prompt: 'raffle-winner-picker pick a winner for giveaway with cryptographic fairness',
  },
  {
    label: '📦 Skill Creator',
    prompt: 'skill-creator create skill data-pipeline-optimizer with SKILL.md structure',
  },
  {
    label: '📢 Skill Share (Slack)',
    prompt: 'skill-share post new skill announcement to Slack channel via webhook',
  },
  {
    label: '🎞️ Slack GIF Creator',
    prompt: 'slack-gif-creator make an emoji gif with bounce and shake animation',
  },
  {
    label: '📄 Tailored Resume Generator',
    prompt: 'tailored-resume-generator tailor resume for Senior Full Stack Engineer with ATS keywords',
  },
];

const PART1_SKILL_QUICK_CHIPS = [
  {
    label: '⚡ Build Interactive Artifact',
    prompt: 'Build an interactive EMI & ROI calculator artifact',
  },
  {
    label: '🎨 Canvas Poster Design',
    prompt: 'Create a poster about Chromatic Silence & Modern Architecture',
  },
  {
    label: '📋 Generate Changelog',
    prompt:
      'Summarize these commits into a changelog:\nfeat: add interactive artifacts builder in chat\nfeat: add Canvas Design poster generator\nfix: resolve double-arm animation ghosting\nchore: update internal build scripts',
  },
  {
    label: '📢 Extract Competitor Ads',
    prompt: 'Analyze competitor ads for SaaS productivity tools and extract messaging patterns',
  },
  {
    label: '🖌️ Brand Guidelines',
    prompt: 'Apply Anthropic official warm brand guidelines style',
  },
  {
    label: '🔌 Connect Apps (Composio)',
    prompt: 'Connect Gmail and send an email summary to team@company.com',
  },
];

export const TextChatModal: React.FC<TextChatModalProps> = ({
  isOpen,
  onClose,
  personaMode,
  language = 'hi-IN',
  onSpeakText,
  onOpenToolApiKeys,
  onOpenWebsiteBuilder,
  initialPrompt,
  onClearInitialPrompt,
}) => {
  const langConfig = getLanguageConfig(language);
  const templates = getLocalizedTemplates(langConfig.code);

  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'init-1',
      sender: 'zoya',
      text: langConfig.sampleGreeting,
      time: 'Now',
    },
  ]);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  const lastDispatchedPromptRef = useRef<string>('');

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  useEffect(() => {
    const greeting =
      personaMode === 'love'
        ? templates.wakeReplyLove
        : personaMode === 'girlfriend'
        ? templates.wakeReplyBoss
        : `${templates.bossTerm}, ${langConfig.sampleGreeting}`;

    setMessages((prev) => {
      if (prev.length <= 1) {
        return [
          {
            id: `init-${personaMode}-${Date.now()}`,
            sender: 'zoya',
            text: greeting,
            time: 'Now',
          },
        ];
      }
      return prev;
    });
  }, [personaMode, langConfig.code]);

  const handleSend = async (textToSend?: string) => {
    const text = (textToSend ?? inputText).trim();
    if (!text) return;

    const nowTime = new Date().toLocaleTimeString([], {
      hour: '2-digit',
      minute: '2-digit',
    });

    const userMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      sender: 'user',
      text,
      time: nowTime,
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!textToSend) {
      setInputText('');
    }

    if (onOpenWebsiteBuilder && isWebsiteIntentPrompt(text)) {
      onClose();
      onOpenWebsiteBuilder(text);
      return;
    }

    // 0a. Check if the user prompt triggers any of the Part 7 Skills
    const detectedPart7 = detectPart7SkillIntent(text);
    if (detectedPart7) {
      setIsTyping(true);
      setTimeout(() => {
        const skillResult = executePart7Skill(detectedPart7, text, langConfig.code);
        setIsTyping(false);
        const zoyaSkillMsg: ChatMessage = {
          id: `zoya-skill7-${Date.now()}`,
          sender: 'zoya',
          text: skillResult.chatText,
          time: new Date().toLocaleTimeString([], {
            hour: '2-digit',
            minute: '2-digit',
          }),
          part7Output: skillResult.payload,
        };
        setMessages((prev) => [...prev, zoyaSkillMsg]);
        onSpeakText?.(skillResult.spokenSummary);
      }, 200);
      return;
    }

    // 0b. Check if the user prompt triggers any of the 8 Part 5 & Part 6 Skills
    const detectedPart56 = detectPart5And6SkillIntent(text);
    if (detectedPart56) {
      setIsTyping(true);
      setTimeout(() => {
        const skillResult = executePart5And6Skill(detectedPart56, text, langConfig.code);
        setIsTyping(false);
        const zoyaSkillMsg: ChatMessage = {
          id: `zoya-skill56-${Date.now()}`,
          sender: 'zoya',
          text: skillResult.chatText,
          time: new Date().toLocaleTimeString([], {
            hour: '2-digit',
            minute: '2-digit',
          }),
          part56Output: skillResult.payload,
        };
        setMessages((prev) => [...prev, zoyaSkillMsg]);
        onSpeakText?.(skillResult.spokenSummary);
      }, 200);
      return;
    }

    // 1. Check if the user prompt triggers any of the 9 Part 2 & Part 4 Skills (Hindi Mobile Text Mode)
    const detectedPart24Skill = detectPart2And4SkillIntent(text);
    if (detectedPart24Skill) {
      setIsTyping(true);
      setTimeout(() => {
        const skillResult = executePart2And4Skill(detectedPart24Skill, text);
        setIsTyping(false);
        const zoyaSkillMsg: ChatMessage = {
          id: `zoya-skill24-${Date.now()}`,
          sender: 'zoya',
          text: skillResult.chatText,
          time: new Date().toLocaleTimeString([], {
            hour: '2-digit',
            minute: '2-digit',
          }),
        };
        setMessages((prev) => [...prev, zoyaSkillMsg]);
        onSpeakText?.(skillResult.spokenSummary);
      }, 200);
      return;
    }

    // 2. Check if the user prompt triggers any of the 6 Part 1 Skills
    const detectedSkill = detectPart1SkillIntent(text);
    if (detectedSkill) {
      setIsTyping(true);
      setTimeout(() => {
        const skillResult = executePart1Skill(detectedSkill, text);
        setIsTyping(false);
        const zoyaSkillMsg: ChatMessage = {
          id: `zoya-skill-${Date.now()}`,
          sender: 'zoya',
          text: skillResult.chatText,
          time: new Date().toLocaleTimeString([], {
            hour: '2-digit',
            minute: '2-digit',
          }),
          skillOutput: skillResult.output,
        };
        setMessages((prev) => [...prev, zoyaSkillMsg]);
        onSpeakText?.(skillResult.spokenSummary);
      }, 220);
      return;
    }

    // 2. Standard AI conversational query with Hierarchical Memory Retrieval + Streaming Latency Logging
    setIsTyping(true);
    let replyText = '';
    const opt = selectOptimalModelForRequest(text);
    const reqLogId = latencyLogger.startRequest({
      query: text,
      source: 'chat',
      model: opt.model,
      relevantToolCount: opt.relevantTools.length,
    });
    let firstSpeechTriggered = false;

    try {
      await zoyaMemory.retrieveHierarchical(personaMode, text);
      const userMemories = await zoyaMemory.getMemories(personaMode);

      const res = await fetch('/api/chat-stream', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: text,
          personaMode,
          language: langConfig.code,
          memories: userMemories,
          relevantToolNames: opt.relevantTools.map((t) => t.name),
          fastMode: opt.isSimpleRequest,
        }),
      });

      if (res.ok && res.body) {
        const reader = res.body.getReader();
        const decoder = new TextDecoder();
        let buffer = '';
        let sentenceBuffer = '';
        let firstTokenMarked = false;

        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          buffer += decoder.decode(value, { stream: true });
          const lines = buffer.split('\n');
          buffer = lines.pop() || '';

          for (const line of lines) {
            const trimmed = line.trim();
            if (!trimmed.startsWith('data:')) continue;
            const dataStr = trimmed.replace(/^data:\s*/, '').trim();
            if (dataStr === '[DONE]') break;

            try {
              const parsed = JSON.parse(dataStr);
              if (parsed.text) {
                if (!firstTokenMarked) {
                  firstTokenMarked = true;
                  latencyLogger.markFirstToken(reqLogId);
                }
                replyText += parsed.text;
                sentenceBuffer += parsed.text;

                if (!firstSpeechTriggered) {
                  const { firstSentence } = extractFirstCompleteSentence(sentenceBuffer);
                  if (firstSentence && !/```|<html|<!DOCTYPE/i.test(firstSentence)) {
                    firstSpeechTriggered = true;
                    latencyLogger.markFirstSpeech(reqLogId, firstSentence);
                    onSpeakText?.(firstSentence);
                  }
                }
              }
            } catch {
              // ignore
            }
          }
        }
      }
    } catch {
      // Fallback handled below
    }

    if (!replyText) {
      replyText = getLocalizedZoyaReply(text, personaMode, langConfig.code);
    }

    const split = splitVoiceReplyAndVisualCard(replyText);
    if (!firstSpeechTriggered && split.spokenSummary) {
      latencyLogger.markFirstSpeech(reqLogId, split.spokenSummary);
      onSpeakText?.(split.spokenSummary);
    }

    latencyLogger.markDone(reqLogId, {
      fullOutput: replyText,
      spokenText: split.spokenSummary,
      routedToCard: split.routedToCard,
      status: 'completed',
    });

    // Automatically extract and persist mode memories & route personal preferences to Final Personal Memory
    zoyaMemory.extractFromConversation(text, replyText, personaMode, langConfig.code);

    setIsTyping(false);
    const zoyaMsg: ChatMessage = {
      id: `zoya-${Date.now()}`,
      sender: 'zoya',
      text: replyText,
      time: new Date().toLocaleTimeString([], {
        hour: '2-digit',
        minute: '2-digit',
      }),
    };

    setMessages((prev) => [...prev, zoyaMsg]);
  };

  useEffect(() => {
    if (isOpen && initialPrompt && initialPrompt.trim() && initialPrompt !== lastDispatchedPromptRef.current) {
      lastDispatchedPromptRef.current = initialPrompt;
      handleSend(initialPrompt);
      onClearInitialPrompt?.();
    }
    if (!isOpen) {
      lastDispatchedPromptRef.current = '';
    }
  }, [isOpen, initialPrompt]);

  if (!isOpen) return null;

  const handleClear = () => {
    setMessages([
      {
        id: 'new-1',
        sender: 'zoya',
        text: templates.resetChatMsg,
        time: 'Now',
      },
    ]);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-950/85 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-lg bg-slate-900 rounded-3xl border border-slate-800 shadow-2xl overflow-hidden flex flex-col h-[88vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-800 bg-slate-950/60 shrink-0">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-pink-500 to-rose-600 flex items-center justify-center text-white shadow-lg shrink-0">
              <MessageSquare className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <h3 className="text-sm sm:text-base font-bold text-slate-100 flex items-center gap-1.5 truncate">
                <span>Zoya Chat & Skills Studio</span>
                <Sparkles className="w-4 h-4 text-pink-400 shrink-0" />
              </h3>
              <p className="text-[11px] text-slate-400 truncate">
                Ask anything or use Artifacts, Poster, Changelog, Ads & Connect skills
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            {onOpenToolApiKeys && (
              <button
                onClick={onOpenToolApiKeys}
                className="p-2 rounded-xl text-purple-300 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
                title="Tool API Keys"
              >
                <Wrench className="w-4 h-4" />
              </button>
            )}
            <button
              onClick={handleClear}
              className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
              title="चैट साफ़ करें"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Messages Stream */}
        <div className="flex-1 overflow-y-auto p-3.5 sm:p-4 space-y-3 bg-slate-950/40">
          {messages.map((m) => {
            const isUser = m.sender === 'user';
            return (
              <div
                key={m.id}
                className={`flex gap-2.5 ${
                  m.skillOutput ? 'max-w-[96%]' : 'max-w-[86%]'
                } ${isUser ? 'ml-auto flex-row-reverse' : 'mr-auto'}`}
              >
                <div
                  className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold shrink-0 mt-1 shadow-sm ${
                    isUser
                      ? 'bg-sky-600 text-white'
                      : 'bg-gradient-to-tr from-pink-500 to-indigo-500 text-white'
                  }`}
                >
                  {isUser ? <User className="w-3.5 h-3.5" /> : 'Z'}
                </div>

                <div
                  className={`p-3.5 rounded-2xl text-xs sm:text-sm leading-relaxed whitespace-pre-wrap shadow-md min-w-0 flex-1 ${
                    isUser
                      ? 'bg-sky-600 text-white rounded-tr-none'
                      : 'bg-slate-900 border border-slate-800 text-slate-100 rounded-tl-none'
                  }`}
                >
                  <p>{m.text}</p>

                  {m.skillOutput && (
                    <Part1SkillOutputCard
                      output={m.skillOutput}
                      onOpenToolApiKeys={onOpenToolApiKeys}
                    />
                  )}

                  {m.part56Output && (
                    <Part5And6SkillOutputCard
                      payload={m.part56Output}
                      onOpenToolApiKeys={onOpenToolApiKeys}
                    />
                  )}

                  {m.part7Output && (
                    <Part7SkillOutputCard payload={m.part7Output} />
                  )}

                  <div
                    className={`text-[10px] mt-1.5 text-right font-mono ${
                      isUser ? 'text-sky-200' : 'text-slate-500'
                    }`}
                  >
                    {m.time}
                  </div>
                </div>
              </div>
            );
          })}

          {isTyping && (
            <div className="flex gap-2.5 max-w-[80%] mr-auto items-center">
              <div className="w-7 h-7 rounded-full bg-gradient-to-tr from-pink-500 to-indigo-500 flex items-center justify-center text-white text-xs font-bold">
                Z
              </div>
              <div className="p-3 bg-slate-900 border border-slate-800 rounded-2xl rounded-tl-none flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-pink-400 animate-bounce" />
                <span className="w-2 h-2 rounded-full bg-pink-400 animate-bounce [animation-delay:0.2s]" />
                <span className="w-2 h-2 rounded-full bg-pink-400 animate-bounce [animation-delay:0.4s]" />
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Part 7, Part 5 & 6, and Part 1 Skills Quick Suggestion Chips */}
        <div className="px-3.5 py-2 border-t border-slate-800/80 bg-slate-950/70 flex items-center gap-1.5 overflow-x-auto text-[11px] shrink-0">
          {PART7_SKILL_QUICK_CHIPS.map((chip, idx) => (
            <button
              key={`skill7-${idx}`}
              type="button"
              onClick={() => handleSend(chip.prompt)}
              className="px-2.5 py-1 rounded-full bg-violet-950/90 hover:bg-violet-900 border border-violet-500/50 text-violet-200 whitespace-nowrap transition-colors cursor-pointer font-medium"
            >
              {chip.label}
            </button>
          ))}
          {PART56_SKILL_QUICK_CHIPS.map((chip, idx) => (
            <button
              key={`skill56-${idx}`}
              type="button"
              onClick={() => handleSend(chip.prompt)}
              className="px-2.5 py-1 rounded-full bg-sky-950/90 hover:bg-sky-900 border border-sky-500/50 text-sky-200 whitespace-nowrap transition-colors cursor-pointer font-medium"
            >
              {chip.label}
            </button>
          ))}
          {PART1_SKILL_QUICK_CHIPS.map((skillChip, idx) => (
            <button
              key={`skill-${idx}`}
              type="button"
              onClick={() => handleSend(skillChip.prompt)}
              className="px-2.5 py-1 rounded-full bg-purple-950/80 hover:bg-purple-900 border border-purple-500/40 text-purple-200 whitespace-nowrap transition-colors cursor-pointer font-medium"
            >
              {skillChip.label}
            </button>
          ))}
          {[
            'तुम क्या कर सकती हो?',
            'एक शायरी सुनाओ',
            'कैसी हो जोया?',
          ].map((chip, idx) => (
            <button
              key={`chat-${idx}`}
              type="button"
              onClick={() => handleSend(chip)}
              className="px-2.5 py-1 rounded-full bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 whitespace-nowrap transition-colors cursor-pointer"
            >
              {chip}
            </button>
          ))}
        </div>

        {/* Input Bar */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSend();
          }}
          className="p-3 border-t border-slate-800 bg-slate-950 flex items-center gap-2 shrink-0"
        >
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder="Ask Zoya or trigger a skill (e.g. 'Create a poster about...', 'Build a calculator')..."
            className="flex-1 px-4 py-2.5 text-xs sm:text-sm bg-slate-900 border border-slate-800 rounded-xl text-slate-100 placeholder-slate-500 focus:outline-none focus:border-pink-500"
          />
          <button
            type="submit"
            disabled={!inputText.trim()}
            className="p-2.5 rounded-xl bg-pink-600 hover:bg-pink-500 disabled:opacity-40 text-white transition-colors shrink-0 shadow-md cursor-pointer"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
