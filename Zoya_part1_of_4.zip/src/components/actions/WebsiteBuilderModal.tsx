import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  ArrowLeft,
  X,
  Code2,
  Eye,
  Columns2,
  Download,
  Copy,
  Check,
  RefreshCw,
  CheckCircle2,
  AlertTriangle,
  Mic,
  MicOff,
  Send,
  Globe,
  ExternalLink,
  Share2,
  Layers,
  Type,
  Palette,
  Image as ImageIcon,
  ArrowUp,
  ArrowDown,
  CopyPlus,
  Trash2,
  Plus,
  Monitor,
  Tablet,
  Smartphone,
  MousePointerClick,
  FilePlus2,
  ShieldCheck,
  Upload,
  PanelRightClose,
  PanelRightOpen,
} from 'lucide-react';
import { getDecryptedSecretSync } from '../../services/secretVault';
import {
  WebsiteAsset,
  WebsiteProjectFiles,
  ParsedSection,
  ParsedImage,
  CssColorVar,
  ParsedElementInfo,
  STREAMING_PREVIEW_SHELL_SRCDOC,
  parseStreamedWebsiteOutput,
  parseSectionsFromHtml,
  moveSectionInHtml,
  duplicateSectionInHtml,
  deleteSectionInHtml,
  addCustomSectionToHtml,
  updateSectionStyleInHtml,
  updateElementByPathInHtml,
  parseImagesFromHtml,
  updateImageInHtml,
  insertImageInSectionHtml,
  parseCssColorVars,
  updateCssColorVar,
  updateBodyPaletteOverride,
  extractTitleFromHtml,
  buildStandaloneFiles,
  assemblePreviewSrcDoc,
  downloadWebsiteZip,
  normalizeHexColor,
} from '../../services/websiteBuilderUtils';

export type BuilderStatus = 'blank' | 'streaming' | 'ready' | 'error';

export interface WebsiteBuilderState {
  status: BuilderStatus;
  mode: 'create' | 'edit';
  title: string;
  projectLabel: string;
  lastPrompt: string;
  activePhase: 'connecting' | 'css' | 'html' | 'js' | 'complete';
  progress: number;
  currentStep: string;
  completedSectionCount: number;
  files: WebsiteProjectFiles;
  streamingBodyHtml: string;
  publishedSite: PublishedSiteState | null;
  error: string | null;
}

export interface PublishedSiteState {
  slug: string;
  title: string;
  publicPath: string;
  publicUrl: string;
  customDomain: string | null;
  verificationToken: string | null;
  domainVerified: boolean;
  httpsStatus: 'active' | 'pending_dns' | 'unconfigured';
  dnsGuide?: {
    domain: string;
    isApex: boolean;
    targetHost: string;
    records: Array<{ type: string; host: string; value: string; note: string }>;
    httpsSteps: string[];
  };
  verifyMessage?: string;
  diagnostics?: {
    txtMatched: boolean;
    cnameMatched: boolean;
    aRecords: string[];
    cnameRecords: string[];
    txtRecords: string[];
  };
}

export interface VoiceWebsiteTriggerResult {
  started: boolean;
  mode: 'create' | 'edit';
  needsClarification: boolean;
  clarifyingQuestion: string;
}

const LEGACY_STORAGE_KEY = 'zoya_website_builder_active_job_v2';

function purgeLegacyPresetsStorage(): void {
  try {
    if (typeof localStorage !== 'undefined') {
      localStorage.removeItem(LEGACY_STORAGE_KEY);
    }
  } catch {
    // Ignore storage cleanup error
  }
}
purgeLegacyPresetsStorage();

function createBlankState(): WebsiteBuilderState {
  return {
    status: 'blank',
    mode: 'create',
    title: '',
    projectLabel: '',
    lastPrompt: '',
    activePhase: 'connecting',
    progress: 0,
    currentStep: 'Waiting for your website description',
    completedSectionCount: 0,
    files: { html: '', css: '', js: '', assets: [] },
    streamingBodyHtml: '',
    publishedSite: null,
    error: null,
  };
}

function computeProgressAndStep(
  parsed: ReturnType<typeof parseStreamedWebsiteOutput>,
  mode: 'create' | 'edit'
): { progress: number; currentStep: string } {
  if (parsed.activePhase === 'complete') {
    return {
      progress: 100,
      currentStep: mode === 'edit' ? 'Changes applied' : 'Website build complete',
    };
  }
  if (parsed.activePhase === 'js') {
    return {
      progress: Math.min(97, 80 + Math.floor(parsed.js.length / 130)),
      currentStep: 'Step 3/3: Streaming interactive JavaScript...',
    };
  }
  if (parsed.activePhase === 'html') {
    const secCount = parsed.completedSectionCount;
    return {
      progress: Math.min(79, 36 + secCount * 8 + Math.floor(parsed.html.length / 260)),
      currentStep:
        secCount > 0
          ? `Step 2/3: Streaming HTML & rendering section ${secCount} in preview...`
          : 'Step 2/3: Streaming HTML structure & page content...',
    };
  }
  if (parsed.activePhase === 'css') {
    return {
      progress: Math.min(35, 12 + Math.floor(parsed.css.length / 95)),
      currentStep: 'Step 1/3: Streaming CSS layout & color system...',
    };
  }
  return {
    progress: 6,
    currentStep: mode === 'edit' ? 'Connecting & preparing edits...' : 'Starting build from blank canvas...',
  };
}

type StateSubscriber = (state: WebsiteBuilderState) => void;

class WebsiteBuilderController {
  private state: WebsiteBuilderState = createBlankState();
  private subscribers = new Set<StateSubscriber>();
  private abortController: AbortController | null = null;
  private modalOpen = false;

  public setModalOpen(open: boolean): void {
    this.modalOpen = open;
  }

  public isModalOpen(): boolean {
    return this.modalOpen;
  }

  public hasGeneratedSite(): boolean {
    return Boolean(this.state.files.html.trim());
  }

  public getState(): WebsiteBuilderState {
    return {
      ...this.state,
      files: {
        ...this.state.files,
        assets: [...this.state.files.assets],
      },
    };
  }

  public subscribe(cb: StateSubscriber): () => void {
    this.subscribers.add(cb);
    cb(this.getState());
    return () => {
      this.subscribers.delete(cb);
    };
  }

  private emit(): void {
    const snap = this.getState();
    for (const sub of this.subscribers) {
      sub(snap);
    }
  }

  public resetToBlankCanvas(): void {
    if (this.abortController) {
      this.abortController.abort();
      this.abortController = null;
    }
    this.state = createBlankState();
    this.emit();
  }

  public updateFiles(updater: (prev: WebsiteProjectFiles) => WebsiteProjectFiles, nextTitle?: string): void {
    const nextFiles = updater(this.state.files);
    const derivedTitle = nextTitle ?? extractTitleFromHtml(nextFiles.html, this.state.title || 'Custom Website');
    this.state = {
      ...this.state,
      status: nextFiles.html.trim() ? 'ready' : this.state.status,
      title: derivedTitle,
      files: nextFiles,
    };
    this.emit();
  }

  public updateTitle(title: string): void {
    this.state = { ...this.state, title };
    this.emit();
  }

  public setPublishedSite(
    updater:
      | PublishedSiteState
      | null
      | ((prev: PublishedSiteState | null) => PublishedSiteState | null)
  ): void {
    const nextPublished =
      typeof updater === 'function' ? updater(this.state.publishedSite) : updater;
    this.state = { ...this.state, publishedSite: nextPublished };
    this.emit();
  }

  public async streamWebsite(options: {
    prompt: string;
    forceCreateFromBlank?: boolean;
  }): Promise<{ ok: boolean; mode: 'create' | 'edit'; error?: string }> {
    const cleanPrompt = (options.prompt || '').trim();
    if (!cleanPrompt) {
      return { ok: false, mode: 'create', error: 'Describe the website you want to build or change.' };
    }

    if (this.abortController) {
      this.abortController.abort();
    }
    const controller = new AbortController();
    this.abortController = controller;

    const shouldEdit = !options.forceCreateFromBlank && this.hasGeneratedSite();
    const mode: 'create' | 'edit' = shouldEdit ? 'edit' : 'create';
    const previousFiles = this.getState().files;

    let languageHint = '';
    try {
      languageHint = localStorage.getItem('zoya_language') || '';
    } catch {
      languageHint = '';
    }
    const geminiApiKey =
      getDecryptedSecretSync('zoya_gemini_api_key') ||
      getDecryptedSecretSync('zoya_api_key') ||
      '';

    this.state = {
      status: 'streaming',
      mode,
      title: mode === 'edit' ? this.state.title : cleanPrompt.slice(0, 54),
      projectLabel: mode === 'edit' ? this.state.projectLabel || this.state.title : cleanPrompt,
      lastPrompt: cleanPrompt,
      activePhase: 'connecting',
      progress: 5,
      currentStep: mode === 'edit' ? 'Applying changes to website...' : 'Initializing blank canvas & connecting...',
      completedSectionCount: 0,
      files: mode === 'edit' ? previousFiles : { html: '', css: '', js: '', assets: [] },
      streamingBodyHtml: '',
      publishedSite: mode === 'edit' ? this.state.publishedSite : null,
      error: null,
    };
    this.emit();

    let rawBuffer = '';
    let finishedSuccessfully = false;
    let streamErrorMessage: string | null = null;

    try {
      const response = await fetch('/api/website-builder/stream', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        signal: controller.signal,
        body: JSON.stringify({
          prompt: cleanPrompt,
          mode,
          language: languageHint,
          geminiApiKey: geminiApiKey || undefined,
          currentFiles:
            mode === 'edit'
              ? {
                  html: previousFiles.html,
                  css: previousFiles.css,
                  js: previousFiles.js,
                }
              : undefined,
        }),
      });

      if (!response.ok || !response.body) {
        let serverMsg = `Server error (${response.status})`;
        try {
          const errJson = await response.json();
          if (errJson?.error) serverMsg = errJson.error;
        } catch {
          // Ignore JSON parse fallback
        }
        throw new Error(serverMsg);
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let sseBuffer = '';

      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        sseBuffer += decoder.decode(value, { stream: true });

        const events = sseBuffer.split('\n\n');
        sseBuffer = events.pop() || '';

        for (const evt of events) {
          const lines = evt.split('\n');
          for (const line of lines) {
            if (!line.startsWith('data: ')) continue;
            const payloadStr = line.slice(6).trim();
            if (!payloadStr || payloadStr === '[DONE]') continue;

            try {
              const payload = JSON.parse(payloadStr);
              if (payload.type === 'chunk' && typeof payload.text === 'string') {
                rawBuffer += payload.text;
                const parsed = parseStreamedWebsiteOutput(rawBuffer);
                const nextTitle = parsed.html
                  ? extractTitleFromHtml(parsed.html, this.state.title || cleanPrompt.slice(0, 54))
                  : this.state.title;
                const { progress, currentStep } = computeProgressAndStep(parsed, mode);

                this.state = {
                  ...this.state,
                  status: 'streaming',
                  title: nextTitle,
                  activePhase: parsed.activePhase,
                  progress: Math.max(this.state.progress, progress),
                  currentStep,
                  completedSectionCount: parsed.completedSectionCount,
                  streamingBodyHtml: parsed.bodyFragmentHtml,
                  files: {
                    html: parsed.html || (mode === 'edit' ? previousFiles.html : ''),
                    css: parsed.css || (mode === 'edit' ? previousFiles.css : ''),
                    js: parsed.js || (mode === 'edit' ? previousFiles.js : ''),
                    assets: previousFiles.assets,
                  },
                };
                this.emit();
              } else if (payload.type === 'done') {
                finishedSuccessfully = true;
              } else if (payload.type === 'error') {
                streamErrorMessage = payload.message || 'Streaming website generation failed.';
              }
            } catch {
              // Ignore malformed partial SSE line
            }
          }
        }
      }

      if (streamErrorMessage) {
        throw new Error(streamErrorMessage);
      }

      const finalParsed = parseStreamedWebsiteOutput(rawBuffer);
      if (!finalParsed.html.trim()) {
        throw new Error(
          finishedSuccessfully
            ? 'The model did not produce HTML markup. Please rephrase your request and try again.'
            : 'Stream ended before website HTML finished generating. Please retry.'
        );
      }

      const finalStandalone = buildStandaloneFiles({
        html: finalParsed.html,
        css: finalParsed.css,
        js: finalParsed.js,
        assets: previousFiles.assets,
      });

      this.state = {
        ...this.state,
        status: 'ready',
        mode,
        title: extractTitleFromHtml(finalStandalone.html, cleanPrompt.slice(0, 54)),
        projectLabel: this.state.projectLabel || cleanPrompt,
        activePhase: 'complete',
        progress: 100,
        currentStep: mode === 'edit' ? 'Changes applied live (100%)' : 'Website ready (100%)',
        completedSectionCount: finalParsed.completedSectionCount,
        streamingBodyHtml: '',
        files: finalStandalone,
        error: null,
      };
      this.emit();
      return { ok: true, mode };
    } catch (err: any) {
      if (err?.name === 'AbortError') {
        return { ok: false, mode, error: 'Cancelled' };
      }
      const errMsg = err?.message || 'Unable to generate website.';
      this.state = {
        ...this.state,
        status: previousFiles.html.trim() ? 'ready' : 'error',
        currentStep: 'Build interrupted',
        files: previousFiles,
        streamingBodyHtml: '',
        error: errMsg,
      };
      this.emit();
      return { ok: false, mode, error: errMsg };
    } finally {
      if (this.abortController === controller) {
        this.abortController = null;
      }
    }
  }
}

export const websiteBuilderController = new WebsiteBuilderController();

export function isWaitingForWebsiteRequirements(): boolean {
  return websiteBuilderController.isModalOpen();
}

export async function triggerVoiceWebsiteBuild(
  prompt: string,
  options?: { forceNew?: boolean }
): Promise<VoiceWebsiteTriggerResult> {
  const clean = (prompt || '').trim();
  const wasOpen = websiteBuilderController.isModalOpen();
  const hasExisting = websiteBuilderController.hasGeneratedSite();
  const forceCreate = options?.forceNew ?? !wasOpen;
  const mode: 'create' | 'edit' = !forceCreate && hasExisting ? 'edit' : 'create';
  if (!clean) {
    return {
      started: false,
      mode,
      needsClarification: false,
      clarifyingQuestion: '',
    };
  }
  void websiteBuilderController.streamWebsite({
    prompt: clean,
    forceCreateFromBlank: forceCreate,
  });
  return {
    started: true,
    mode,
    needsClarification: false,
    clarifyingQuestion: '',
  };
}

interface WebsiteBuilderModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialPrompt?: string;
}

export const WebsiteBuilderModal: React.FC<WebsiteBuilderModalProps> = ({
  isOpen,
  onClose,
  initialPrompt = '',
}) => {
  const [builderState, setBuilderState] = useState<WebsiteBuilderState>(() =>
    websiteBuilderController.getState()
  );
  const [promptInput, setPromptInput] = useState('');
  const [viewMode, setViewMode] = useState<'split' | 'preview' | 'code'>('split');
  const [deviceMode, setDeviceMode] = useState<'desktop' | 'tablet' | 'mobile'>('desktop');
  const [activeCodeTab, setActiveCodeTab] = useState<'styles.css' | 'index.html' | 'app.js'>('index.html');
  const [inspectorTab, setInspectorTab] = useState<'sections' | 'element' | 'colors' | 'images'>('sections');
  const [showInspector, setShowInspector] = useState(() =>
    typeof window !== 'undefined' ? window.innerWidth >= 1024 : true
  );
  const [visualEditMode, setVisualEditMode] = useState(true);
  const [selectedElement, setSelectedElement] = useState<ParsedElementInfo | null>(null);
  const [selectedSectionIndex, setSelectedSectionIndex] = useState<number>(0);

  // Add Section inline form
  const [showAddSectionForm, setShowAddSectionForm] = useState(false);
  const [newSectionTitle, setNewSectionTitle] = useState('');
  const [newSectionBody, setNewSectionBody] = useState('');

  // Add New Image inline form
  const [newImgTargetSection, setNewImgTargetSection] = useState(0);
  const [newImgAlt, setNewImgAlt] = useState('');

  // Voice recording inside the builder
  const [isListeningVoice, setIsListeningVoice] = useState(false);
  const [voiceError, setVoiceError] = useState<string | null>(null);
  const speechRecRef = useRef<any>(null);

  // Status feedback (replaces window.alert)
  const [toastMsg, setToastMsg] = useState<{ type: 'success' | 'error' | 'info'; text: string } | null>(null);
  const [isExportingZip, setIsExportingZip] = useState(false);

  // Publish & Custom Domain Modal State (publishedSite stored persistently in websiteBuilderController)
  const [showPublishPanel, setShowPublishPanel] = useState(false);
  const [isPublishing, setIsPublishing] = useState(false);
  const publishedSite = builderState.publishedSite;
  const setPublishedSite = (
    updater:
      | PublishedSiteState
      | null
      | ((prev: PublishedSiteState | null) => PublishedSiteState | null)
  ) => websiteBuilderController.setPublishedSite(updater);
  const [copiedUrl, setCopiedUrl] = useState(false);
  const [copiedDnsKey, setCopiedDnsKey] = useState<string | null>(null);
  const [domainInput, setDomainInput] = useState('');
  const [isSavingDomain, setIsSavingDomain] = useState(false);
  const [isVerifyingDomain, setIsVerifyingDomain] = useState(false);
  const [domainError, setDomainError] = useState<string | null>(null);

  // Live streaming iframe & code editor refs
  const streamIframeRef = useRef<HTMLIFrameElement | null>(null);
  const codeTextareaRef = useRef<HTMLTextAreaElement | null>(null);
  const streamPatchTimerRef = useRef<number | null>(null);
  const lastInitialPromptRef = useRef<string>('');
  const uploadForExistingImgIndexRef = useRef<number | null>(null);
  const replaceImageFileInputRef = useRef<HTMLInputElement | null>(null);
  const insertImageFileInputRef = useRef<HTMLInputElement | null>(null);

  const showToast = (type: 'success' | 'error' | 'info', text: string) => {
    setToastMsg({ type, text });
    window.setTimeout(() => {
      setToastMsg((prev) => (prev?.text === text ? null : prev));
    }, 4000);
  };

  useEffect(() => {
    const unsub = websiteBuilderController.subscribe((next) => {
      setBuilderState(next);
    });
    return unsub;
  }, []);

  useEffect(() => {
    websiteBuilderController.setModalOpen(isOpen);
    if (!isOpen && speechRecRef.current) {
      try {
        speechRecRef.current.stop();
      } catch {
        // ignore
      }
      setIsListeningVoice(false);
    }
    return () => {
      websiteBuilderController.setModalOpen(false);
    };
  }, [isOpen]);

  // Pre-fill prompt input only if canvas is blank when opened
  useEffect(() => {
    if (
      isOpen &&
      builderState.status === 'blank' &&
      initialPrompt &&
      initialPrompt !== lastInitialPromptRef.current
    ) {
      lastInitialPromptRef.current = initialPrompt;
      setPromptInput(initialPrompt);
    }
  }, [isOpen, initialPrompt, builderState.status]);

  // Auto-follow streaming code tab while generating
  useEffect(() => {
    if (builderState.status !== 'streaming') return;
    if (builderState.activePhase === 'css') setActiveCodeTab('styles.css');
    else if (builderState.activePhase === 'html') setActiveCodeTab('index.html');
    else if (builderState.activePhase === 'js') setActiveCodeTab('app.js');
  }, [builderState.status, builderState.activePhase]);

  // Auto-scroll streamed code editor to follow incoming tokens live
  useEffect(() => {
    if (!isOpen || builderState.status !== 'streaming') return;
    const ta = codeTextareaRef.current;
    if (ta) {
      ta.scrollTop = ta.scrollHeight;
    }
  }, [isOpen, builderState.status, builderState.files.css, builderState.files.html, builderState.files.js, activeCodeTab]);

  const postStreamPatchToIframe = () => {
    const win = streamIframeRef.current?.contentWindow;
    if (win) {
      win.postMessage(
        {
          type: 'ZOYA_STREAM_PATCH',
          css: builderState.files.css,
          bodyHtml: builderState.streamingBodyHtml,
          title: builderState.projectLabel || builderState.title || 'Building your custom website...',
          step: builderState.currentStep,
        },
        '*'
      );
    }
  };

  // Send section-by-section live patches into the streaming iframe without full reload flicker
  useEffect(() => {
    if (!isOpen || builderState.status !== 'streaming') return;
    if (streamPatchTimerRef.current) {
      window.clearTimeout(streamPatchTimerRef.current);
    }
    streamPatchTimerRef.current = window.setTimeout(postStreamPatchToIframe, 85);

    return () => {
      if (streamPatchTimerRef.current) {
        window.clearTimeout(streamPatchTimerRef.current);
      }
    };
  }, [
    isOpen,
    builderState.status,
    builderState.files.css,
    builderState.streamingBodyHtml,
    builderState.currentStep,
    builderState.projectLabel,
    builderState.title,
  ]);

  // Listen for click-to-select & inline text-edit messages from preview iframe
  useEffect(() => {
    const handleMessage = (ev: MessageEvent) => {
      if (!ev?.data) return;
      if (ev.data.type === 'ZOYA_ELEMENT_SELECTED' && ev.data.payload) {
        setSelectedElement(ev.data.payload as ParsedElementInfo);
        setInspectorTab('element');
        setShowInspector(true);
      } else if (ev.data.type === 'ZOYA_TEXT_EDITED' && ev.data.payload) {
        const { path, text } = ev.data.payload as { path: string; text: string };
        if (path) {
          websiteBuilderController.updateFiles((prev) => ({
            ...prev,
            html: updateElementByPathInHtml(prev.html, path, { text }),
          }));
          setSelectedElement((prev) => (prev && prev.path === path ? { ...prev, text } : prev));
        }
      }
    };
    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, []);

  const parsedSections: ParsedSection[] = useMemo(
    () => (builderState.status === 'ready' ? parseSectionsFromHtml(builderState.files.html) : []),
    [builderState.status, builderState.files.html]
  );

  const parsedImages: ParsedImage[] = useMemo(
    () => (builderState.status === 'ready' ? parseImagesFromHtml(builderState.files.html) : []),
    [builderState.status, builderState.files.html]
  );

  const parsedCssVars: CssColorVar[] = useMemo(
    () => parseCssColorVars(builderState.files.css),
    [builderState.files.css]
  );

  const activeSection = parsedSections[selectedSectionIndex] || parsedSections[0] || null;

  const interactivePreviewSrcDoc = useMemo(() => {
    if (!builderState.files.html.trim() || builderState.status === 'streaming') return '';
    return assemblePreviewSrcDoc({
      files: builderState.files,
      visualEditMode,
      selectedPath: selectedElement?.path || null,
    });
  }, [builderState.files, builderState.status, visualEditMode, selectedElement?.path]);

  const handleSubmitPrompt = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const cmd = promptInput.trim();
    if (!cmd) return;
    setPromptInput('');
    setSelectedElement(null);
    await websiteBuilderController.streamWebsite({ prompt: cmd });
  };

  const handleToggleVoiceCommand = () => {
    setVoiceError(null);
    if (isListeningVoice) {
      try {
        speechRecRef.current?.stop();
      } catch {
        // ignore
      }
      setIsListeningVoice(false);
      return;
    }

    const SpeechRec = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRec) {
      setVoiceError('Browser voice dictation is unavailable here. Use the prompt box or Zoya main mic.');
      return;
    }

    try {
      const rec = new SpeechRec();
      speechRecRef.current = rec;
      let lang = 'en-US';
      try {
        const savedLang = localStorage.getItem('zoya_language');
        if (savedLang === 'hi' || savedLang === 'hi-IN') lang = 'hi-IN';
      } catch {
        // ignore
      }
      rec.lang = lang;
      rec.interimResults = true;
      rec.continuous = false;

      let finalSpoken = '';
      rec.onresult = (event: any) => {
        let interim = '';
        for (let i = event.resultIndex; i < event.results.length; i++) {
          const t = event.results[i][0]?.transcript || '';
          if (event.results[i].isFinal) finalSpoken += t + ' ';
          else interim += t;
        }
        setPromptInput((finalSpoken + interim).trim());
      };

      rec.onerror = (err: any) => {
        setIsListeningVoice(false);
        if (err?.error === 'not-allowed') {
          setVoiceError('Microphone permission denied. Allow microphone access or type your prompt.');
        } else {
          setVoiceError(`Voice recognition stopped (${err?.error || 'error'}).`);
        }
      };

      rec.onend = () => {
        setIsListeningVoice(false);
        const spoken = finalSpoken.trim();
        if (spoken) {
          setPromptInput('');
          void websiteBuilderController.streamWebsite({ prompt: spoken });
        }
      };

      rec.start();
      setIsListeningVoice(true);
    } catch (err: any) {
      setIsListeningVoice(false);
      setVoiceError(err?.message || 'Unable to start voice recognition.');
    }
  };

  const handleResetBlankCanvas = () => {
    websiteBuilderController.resetToBlankCanvas();
    setPromptInput('');
    setSelectedElement(null);
    setSelectedSectionIndex(0);
    setPublishedSite(null);
    setShowPublishPanel(false);
  };

  const handleDownloadZip = async () => {
    if (!builderState.files.html.trim()) return;
    setIsExportingZip(true);
    try {
      const res = await downloadWebsiteZip({
        title: builderState.title || extractTitleFromHtml(builderState.files.html),
        files: builderState.files,
      });
      showToast('success', `Downloaded ${res.fileName} (${res.fileCount} files, offline ready)`);
    } catch (err: any) {
      showToast('error', err?.message || 'ZIP export failed.');
    } finally {
      setIsExportingZip(false);
    }
  };

  const handlePublishSite = async () => {
    if (!builderState.files.html.trim()) return;
    setIsPublishing(true);
    setShowPublishPanel(true);
    setDomainError(null);
    try {
      const standalone = buildStandaloneFiles(builderState.files);
      const res = await fetch('/api/published-sites', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: builderState.title || extractTitleFromHtml(standalone.html),
          existingSlug: publishedSite?.slug || undefined,
          files: standalone,
        }),
      });
      const data = await res.json();
      if (!res.ok || !data?.success) {
        throw new Error(data?.error || 'Publish failed');
      }
      const origin = typeof window !== 'undefined' ? window.location.origin : '';
      const resolvedUrl = `${origin}${data.publicPath}`;
      setPublishedSite((prev) => ({
        slug: data.site.slug,
        title: data.site.title,
        publicPath: data.publicPath,
        publicUrl: resolvedUrl,
        customDomain: data.site.customDomain || null,
        verificationToken: data.site.verificationToken || null,
        domainVerified: Boolean(data.site.domainVerified),
        httpsStatus: data.site.httpsStatus || 'unconfigured',
        dnsGuide: prev?.dnsGuide,
      }));
      showToast('success', `Published live at ${data.publicPath}`);
    } catch (err: any) {
      showToast('error', err?.message || 'Failed to publish website.');
    } finally {
      setIsPublishing(false);
    }
  };

  const handleCopyPublicUrl = async () => {
    if (!publishedSite?.publicUrl) return;
    try {
      await navigator.clipboard.writeText(publishedSite.publicUrl);
      setCopiedUrl(true);
      setTimeout(() => setCopiedUrl(false), 2000);
    } catch {
      showToast('error', 'Clipboard copy unavailable.');
    }
  };

  const handleSharePublicUrl = async () => {
    if (!publishedSite?.publicUrl) return;
    if (typeof navigator !== 'undefined' && typeof navigator.share === 'function') {
      try {
        await navigator.share({
          title: publishedSite.title,
          url: publishedSite.publicUrl,
        });
        return;
      } catch {
        // Fallback to copy
      }
    }
    await handleCopyPublicUrl();
    showToast('info', 'Public link copied to clipboard.');
  };

  const handleConnectDomain = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!publishedSite?.slug) return;
    const domain = domainInput.trim();
    if (!domain) return;
    setIsSavingDomain(true);
    setDomainError(null);
    try {
      const res = await fetch(`/api/published-sites/${encodeURIComponent(publishedSite.slug)}/domain`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ domain }),
      });
      const data = await res.json();
      if (!res.ok || !data?.success) {
        throw new Error(data?.error || 'Could not attach custom domain.');
      }
      setPublishedSite((prev) =>
        prev
          ? {
              ...prev,
              customDomain: data.site.customDomain,
              verificationToken: data.site.verificationToken,
              domainVerified: Boolean(data.site.domainVerified),
              httpsStatus: data.site.httpsStatus,
              dnsGuide: data.dnsGuide,
              verifyMessage: undefined,
            }
          : prev
      );
      showToast('info', `DNS records generated for ${data.site.customDomain}`);
    } catch (err: any) {
      setDomainError(err?.message || 'Domain connection failed.');
    } finally {
      setIsSavingDomain(false);
    }
  };

  const handleVerifyDomain = async () => {
    if (!publishedSite?.slug) return;
    setIsVerifyingDomain(true);
    setDomainError(null);
    try {
      const res = await fetch(
        `/api/published-sites/${encodeURIComponent(publishedSite.slug)}/verify-domain`,
        { method: 'POST' }
      );
      const data = await res.json();
      if (!res.ok || !data?.success) {
        throw new Error(data?.error || 'DNS verification request failed.');
      }
      setPublishedSite((prev) =>
        prev
          ? {
              ...prev,
              domainVerified: Boolean(data.verified),
              httpsStatus: data.site.httpsStatus,
              verifyMessage: data.message,
              diagnostics: data.diagnostics,
            }
          : prev
      );
    } catch (err: any) {
      setDomainError(err?.message || 'DNS verification error.');
    } finally {
      setIsVerifyingDomain(false);
    }
  };

  const handleDisconnectDomain = async () => {
    if (!publishedSite?.slug) return;
    setDomainError(null);
    try {
      const res = await fetch(`/api/published-sites/${encodeURIComponent(publishedSite.slug)}/domain`, {
        method: 'DELETE',
      });
      const data = await res.json();
      if (res.ok && data?.success) {
        setDomainInput('');
        setPublishedSite((prev) =>
          prev
            ? {
                ...prev,
                customDomain: null,
                verificationToken: null,
                domainVerified: false,
                httpsStatus: 'unconfigured',
                dnsGuide: undefined,
                verifyMessage: undefined,
                diagnostics: undefined,
              }
            : prev
        );
      }
    } catch {
      setDomainError('Could not remove custom domain.');
    }
  };

  const handleImageFileUpload = (file: File, target: { kind: 'replace'; index: number } | { kind: 'insert'; sectionIndex: number }) => {
    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = typeof reader.result === 'string' ? reader.result : '';
      if (!dataUrl) return;
      const safeName = `${Date.now().toString(36)}-${file.name.replace(/[^a-zA-Z0-9._-]/g, '_')}`;
      const assetPath = `./assets/${safeName}`;
      const asset: WebsiteAsset = {
        path: assetPath,
        name: safeName,
        mimeType: file.type || 'image/png',
        dataUrl,
      };
      websiteBuilderController.updateFiles((prev) => {
        const nextAssets = [...prev.assets, asset];
        const nextHtml =
          target.kind === 'replace'
            ? updateImageInHtml(prev.html, target.index, { src: assetPath })
            : insertImageInSectionHtml(prev.html, target.sectionIndex, {
                src: assetPath,
                alt: newImgAlt.trim() || file.name,
              });
        return { ...prev, html: nextHtml, assets: nextAssets };
      });
      if (target.kind === 'insert') {
        setNewImgAlt('');
      }
      showToast('success', `Added image ${safeName} to assets/`);
    };
    reader.readAsDataURL(file);
  };

  if (!isOpen) return null;

  const isBlank = builderState.status === 'blank';
  const isStreaming = builderState.status === 'streaming';
  const hasSite = Boolean(builderState.files.html.trim()) && builderState.status !== 'blank';

  const currentCodeValue =
    activeCodeTab === 'styles.css'
      ? builderState.files.css
      : activeCodeTab === 'app.js'
      ? builderState.files.js
      : builderState.files.html;

  const deviceFrameWidthClass =
    deviceMode === 'mobile'
      ? 'w-[390px] max-w-full'
      : deviceMode === 'tablet'
      ? 'w-[768px] max-w-full'
      : 'w-full';

  return (
    <div
      className="fixed inset-0 z-50 flex flex-col bg-[#080a0f] text-slate-100 select-none"
      role="dialog"
      aria-label="Website Builder Studio"
    >
      {/* Hidden file inputs for image uploads */}
      <input
        ref={replaceImageFileInputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={(e) => {
          const f = e.target.files?.[0];
          const idx = uploadForExistingImgIndexRef.current;
          e.target.value = '';
          if (f && idx !== null) {
            handleImageFileUpload(f, { kind: 'replace', index: idx });
          }
        }}
      />
      <input
        ref={insertImageFileInputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={(e) => {
          const f = e.target.files?.[0];
          e.target.value = '';
          if (f) {
            handleImageFileUpload(f, { kind: 'insert', sectionIndex: newImgTargetSection });
          }
        }}
      />

      {/* Top Studio Header Bar with Prominent Back Button */}
      <header className="flex flex-wrap items-center justify-between gap-2 border-b border-white/10 bg-[#0d1118] px-3 py-2.5 sm:px-4">
        <div className="flex items-center gap-2.5 min-w-0">
          <button
            type="button"
            onClick={onClose}
            data-testid="website-builder-back-btn"
            aria-label="Back to home screen"
            className="inline-flex items-center gap-1.5 rounded-md border border-white/15 bg-black/50 px-2.5 py-1.5 text-xs font-medium text-slate-100 hover:bg-white/10 hover:text-white whitespace-nowrap shrink-0 cursor-pointer"
          >
            <ArrowLeft className="h-3.5 w-3.5" />
            Back
          </button>

          <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-md border border-cyan-500/40 bg-cyan-500/10 text-cyan-300">
            <Code2 className="h-4 w-4" />
          </div>
          {hasSite ? (
            <input
              type="text"
              value={builderState.title}
              onChange={(e) => websiteBuilderController.updateTitle(e.target.value)}
              aria-label="Website Title"
              className="w-36 sm:w-56 truncate rounded-md border border-white/10 bg-black/40 px-2.5 py-1 text-sm font-medium text-white focus:border-cyan-400 focus:outline-none"
            />
          ) : (
            <span className="text-sm font-semibold tracking-tight text-white whitespace-nowrap truncate max-w-[42vw]">
              {isStreaming && builderState.projectLabel
                ? `Building: ${builderState.projectLabel}`
                : 'Build a website'}
            </span>
          )}
        </div>

        {/* Center View & Device Controls when active */}
        {hasSite || isStreaming ? (
          <div className="flex flex-wrap items-center gap-1.5">
            <div className="inline-flex rounded-md border border-white/10 bg-black/40 p-0.5">
              <button
                type="button"
                onClick={() => setViewMode('split')}
                className={`inline-flex items-center gap-1 rounded px-2 py-1 text-xs font-medium whitespace-nowrap ${
                  viewMode === 'split' ? 'bg-cyan-500/20 text-cyan-200' : 'text-slate-400 hover:text-white'
                }`}
              >
                <Columns2 className="h-3.5 w-3.5" />
                Split
              </button>
              <button
                type="button"
                onClick={() => setViewMode('preview')}
                className={`inline-flex items-center gap-1 rounded px-2 py-1 text-xs font-medium whitespace-nowrap ${
                  viewMode === 'preview' ? 'bg-cyan-500/20 text-cyan-200' : 'text-slate-400 hover:text-white'
                }`}
              >
                <Eye className="h-3.5 w-3.5" />
                Preview
              </button>
              <button
                type="button"
                onClick={() => setViewMode('code')}
                className={`inline-flex items-center gap-1 rounded px-2 py-1 text-xs font-medium whitespace-nowrap ${
                  viewMode === 'code' ? 'bg-cyan-500/20 text-cyan-200' : 'text-slate-400 hover:text-white'
                }`}
              >
                <Code2 className="h-3.5 w-3.5" />
                Code
              </button>
            </div>

            {viewMode !== 'code' && (
              <div className="hidden md:inline-flex rounded-md border border-white/10 bg-black/40 p-0.5">
                <button
                  type="button"
                  onClick={() => setDeviceMode('desktop')}
                  title="Desktop View"
                  className={`rounded p-1 ${deviceMode === 'desktop' ? 'bg-white/15 text-white' : 'text-slate-400 hover:text-white'}`}
                >
                  <Monitor className="h-3.5 w-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() => setDeviceMode('tablet')}
                  title="Tablet View"
                  className={`rounded p-1 ${deviceMode === 'tablet' ? 'bg-white/15 text-white' : 'text-slate-400 hover:text-white'}`}
                >
                  <Tablet className="h-3.5 w-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() => setDeviceMode('mobile')}
                  title="Mobile View"
                  className={`rounded p-1 ${deviceMode === 'mobile' ? 'bg-white/15 text-white' : 'text-slate-400 hover:text-white'}`}
                >
                  <Smartphone className="h-3.5 w-3.5" />
                </button>
              </div>
            )}

            {builderState.status === 'ready' && (
              <button
                type="button"
                onClick={() => setVisualEditMode((v) => !v)}
                className={`inline-flex items-center gap-1 rounded-md border px-2 py-1 text-xs font-medium whitespace-nowrap ${
                  visualEditMode
                    ? 'border-emerald-500/40 bg-emerald-500/15 text-emerald-200'
                    : 'border-white/10 bg-black/40 text-slate-300 hover:text-white'
                }`}
                title="Click elements in preview to edit text & styles inline"
              >
                <MousePointerClick className="h-3.5 w-3.5" />
                {visualEditMode ? 'Inline Edit: ON' : 'Inline Edit: OFF'}
              </button>
            )}
          </div>
        ) : null}

        {/* Right Primary Actions: Blank Reset, Download ZIP, Publish, Inspector Toggle */}
        <div className="flex flex-wrap items-center gap-1.5">
          {(hasSite || isStreaming || builderState.status === 'error') && (
            <button
              type="button"
              onClick={handleResetBlankCanvas}
              data-testid="website-builder-new-blank-btn"
              className="inline-flex items-center gap-1 rounded-md border border-white/15 bg-black/40 px-2.5 py-1.5 text-xs font-medium text-slate-200 hover:bg-white/10 whitespace-nowrap"
            >
              <FilePlus2 className="h-3.5 w-3.5" />
              New Blank
            </button>
          )}

          {builderState.status === 'ready' && (
            <>
              <button
                type="button"
                onClick={handleDownloadZip}
                disabled={isExportingZip}
                className="inline-flex items-center gap-1.5 rounded-md border border-white/15 bg-slate-800/80 px-2.5 py-1.5 text-xs font-medium text-white hover:bg-slate-700 disabled:opacity-50 whitespace-nowrap"
              >
                <Download className="h-3.5 w-3.5" />
                {isExportingZip ? 'Packaging...' : 'Download ZIP'}
              </button>

              <button
                type="button"
                onClick={handlePublishSite}
                disabled={isPublishing}
                className="inline-flex items-center gap-1.5 rounded-md bg-cyan-500 px-3 py-1.5 text-xs font-semibold text-slate-950 hover:bg-cyan-400 disabled:opacity-50 whitespace-nowrap"
              >
                <Globe className="h-3.5 w-3.5" />
                {publishedSite ? 'Update Live Site' : 'Publish'}
              </button>

              <button
                type="button"
                onClick={() => setShowInspector((s) => !s)}
                data-testid="website-builder-customize-btn"
                className={`inline-flex items-center gap-1.5 rounded-md border px-2.5 py-1.5 text-xs font-medium whitespace-nowrap ${
                  showInspector
                    ? 'border-cyan-500/40 bg-cyan-500/15 text-cyan-200'
                    : 'border-white/15 bg-black/40 text-slate-200 hover:bg-white/10 hover:text-white'
                }`}
                title={showInspector ? 'Hide Custom Editor' : 'Open Custom Editor'}
              >
                {showInspector ? <PanelRightClose className="h-3.5 w-3.5" /> : <PanelRightOpen className="h-3.5 w-3.5" />}
                Customize
              </button>
            </>
          )}
        </div>
      </header>

      {/* Live Build Progress Strip: Shows Website Target, Current Step & Exact Percentage */}
      {(isStreaming || builderState.status === 'ready') && (
        <div
          data-testid="website-build-progress-bar"
          className="border-b border-white/10 bg-[#0b0f17] px-3 py-2 sm:px-4 space-y-1.5"
        >
          <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
            <div className="flex items-center gap-2 min-w-0">
              {isStreaming ? (
                <RefreshCw className="h-3.5 w-3.5 shrink-0 animate-spin text-cyan-400" />
              ) : (
                <CheckCircle2 className="h-3.5 w-3.5 shrink-0 text-emerald-400" />
              )}
              <span className="font-medium text-white truncate">
                {builderState.mode === 'edit' ? 'Updating: ' : 'Building: '}
                <span className="text-cyan-300">
                  {builderState.projectLabel || builderState.lastPrompt || builderState.title}
                </span>
              </span>
              <span className="hidden sm:inline text-slate-500">·</span>
              <span className="text-slate-300 truncate">{builderState.currentStep}</span>
            </div>
            <div className="flex items-center gap-2 shrink-0 font-mono">
              {builderState.completedSectionCount > 0 && (
                <span className="text-[11px] text-slate-400">
                  {builderState.completedSectionCount} sections
                </span>
              )}
              <span
                data-testid="website-build-percentage"
                className={`font-semibold ${
                  isStreaming ? 'text-cyan-300' : 'text-emerald-300'
                }`}
              >
                {builderState.progress}%
              </span>
            </div>
          </div>
          <div className="h-1.5 w-full overflow-hidden rounded-full bg-white/10">
            <div
              className={`h-full transition-all duration-300 ${
                isStreaming ? 'bg-cyan-400' : 'bg-emerald-400'
              }`}
              style={{ width: `${Math.max(4, Math.min(100, builderState.progress))}%` }}
            />
          </div>
        </div>
      )}

      {/* Inline Toast / Error Bar */}
      {(toastMsg || builderState.error) && (
        <div
          className={`flex items-center justify-between gap-2 border-b px-4 py-2 text-xs ${
            builderState.error || toastMsg?.type === 'error'
              ? 'border-red-500/30 bg-red-950/60 text-red-200'
              : toastMsg?.type === 'success'
              ? 'border-emerald-500/30 bg-emerald-950/60 text-emerald-200'
              : 'border-cyan-500/30 bg-cyan-950/60 text-cyan-200'
          }`}
        >
          <div className="flex items-center gap-2 min-w-0">
            {builderState.error || toastMsg?.type === 'error' ? (
              <AlertTriangle className="h-4 w-4 shrink-0" />
            ) : (
              <CheckCircle2 className="h-4 w-4 shrink-0" />
            )}
            <span className="truncate">{builderState.error || toastMsg?.text}</span>
          </div>
          {builderState.error && builderState.lastPrompt && (
            <button
              type="button"
              onClick={() => void websiteBuilderController.streamWebsite({ prompt: builderState.lastPrompt })}
              className="rounded border border-red-400/40 bg-red-500/20 px-2.5 py-1 text-xs font-medium text-white hover:bg-red-500/30 whitespace-nowrap"
            >
              Retry Build
            </button>
          )}
        </div>
      )}

      {/* Published Link Bar (Quick access once published even if modal closed) */}
      {publishedSite && !showPublishPanel && builderState.status === 'ready' && (
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-emerald-500/20 bg-emerald-950/30 px-4 py-1.5 text-xs">
          <div className="flex items-center gap-2 min-w-0">
            <Globe className="h-3.5 w-3.5 shrink-0 text-emerald-400" />
            <span className="text-emerald-200 whitespace-nowrap">Live URL:</span>
            <a
              href={publishedSite.publicUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="truncate font-mono text-cyan-300 underline hover:text-cyan-200"
            >
              {publishedSite.publicUrl}
            </a>
            {publishedSite.customDomain && (
              <span className="rounded border border-white/15 bg-black/40 px-2 py-0.5 text-[11px] text-slate-200 whitespace-nowrap">
                {publishedSite.customDomain} ({publishedSite.httpsStatus === 'active' ? 'HTTPS Active' : 'Pending DNS'})
              </span>
            )}
          </div>
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={handleCopyPublicUrl}
              className="inline-flex items-center gap-1 rounded border border-white/15 bg-black/40 px-2 py-1 text-xs text-slate-200 hover:bg-white/10 whitespace-nowrap"
            >
              {copiedUrl ? <Check className="h-3 w-3 text-emerald-400" /> : <Copy className="h-3 w-3" />}
              {copiedUrl ? 'Copied' : 'Copy Link'}
            </button>
            <button
              type="button"
              onClick={() => setShowPublishPanel(true)}
              className="rounded border border-cyan-500/30 bg-cyan-500/15 px-2 py-1 text-xs text-cyan-200 hover:bg-cyan-500/25 whitespace-nowrap"
            >
              Share & Custom Domain
            </button>
          </div>
        </div>
      )}

      {/* MAIN WORKSPACE */}
      <div className="flex flex-1 min-h-0 overflow-hidden">
        {isBlank ? (
          /* BLANK CANVAS INITIAL STATE — ZERO TEMPLATES, ZERO PRESETS, ZERO SAMPLE CARDS */
          <main className="flex flex-1 flex-col items-center justify-center p-4 sm:p-8 bg-[#080a0f]">
            <div className="w-full max-w-2xl rounded-xl border border-dashed border-white/15 bg-[#0d1118] p-6 sm:p-8">
              <div className="mb-4 flex items-center gap-2 text-xs font-mono uppercase tracking-wider text-slate-400">
                <span className="inline-block h-2 w-2 rounded-full bg-cyan-400" />
                Blank Canvas · Ready for Your Website
              </div>

              <h1 className="text-xl sm:text-2xl font-semibold tracking-tight text-white">
                Describe the exact website you want to build
              </h1>
              <p className="mt-2 text-sm text-slate-400">
                Speak or type the business, sections, language, colors, and features you need. Code streams live while every section appears in the preview.
              </p>

              <form onSubmit={handleSubmitPrompt} className="mt-6 space-y-3">
                <textarea
                  value={promptInput}
                  onChange={(e) => setPromptInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      void handleSubmitPrompt();
                    }
                  }}
                  rows={4}
                  placeholder="Describe your website in English, Hindi, or any language — business type, sections, color scheme, layout, interactive features..."
                  className="w-full resize-none rounded-lg border border-white/15 bg-black/50 p-3.5 text-sm text-white placeholder-slate-500 focus:border-cyan-400 focus:outline-none"
                />

                {voiceError && (
                  <p className="text-xs text-amber-300">{voiceError}</p>
                )}

                <div className="flex flex-wrap items-center justify-between gap-2">
                  <button
                    type="button"
                    onClick={handleToggleVoiceCommand}
                    className={`inline-flex items-center gap-2 rounded-lg border px-3.5 py-2 text-xs font-medium whitespace-nowrap ${
                      isListeningVoice
                        ? 'border-red-500/60 bg-red-500/20 text-red-200'
                        : 'border-white/15 bg-black/40 text-slate-200 hover:bg-white/10'
                    }`}
                  >
                    {isListeningVoice ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
                    {isListeningVoice ? 'Stop Listening' : 'Speak Website Description'}
                  </button>

                  <button
                    type="submit"
                    disabled={!promptInput.trim()}
                    className="inline-flex items-center gap-2 rounded-lg bg-cyan-500 px-4 py-2 text-sm font-semibold text-slate-950 hover:bg-cyan-400 disabled:opacity-40 whitespace-nowrap"
                  >
                    <Send className="h-4 w-4" />
                    Build From Blank Canvas
                  </button>
                </div>
              </form>
            </div>
          </main>
        ) : (
          /* ACTIVE BUILDER WORKSPACE: CODE STREAM/EDITOR + LIVE SECTION-BY-SECTION PREVIEW + CUSTOM INSPECTOR */
          <>
            <div className="flex flex-1 min-w-0 min-h-0 flex-col">
              <div className="flex flex-1 min-h-0 flex-col lg:flex-row">
                {/* CODE STREAM & LIVE CODE EDITOR PANE */}
                {(viewMode === 'split' || viewMode === 'code') && (
                  <section
                    aria-label="Live Code Panel"
                    className={`flex flex-col border-b lg:border-b-0 lg:border-r border-white/10 bg-[#0b0e14] min-h-0 ${
                      viewMode === 'code' ? 'flex-1' : 'h-[42%] lg:h-auto lg:w-[40%]'
                    }`}
                  >
                    <div className="flex items-center justify-between border-b border-white/10 px-2.5 py-1.5 bg-[#0f131b]">
                      <div className="flex items-center gap-1">
                        {(['styles.css', 'index.html', 'app.js'] as const).map((tab) => (
                          <button
                            key={tab}
                            type="button"
                            onClick={() => setActiveCodeTab(tab)}
                            className={`rounded px-2.5 py-1 font-mono text-xs whitespace-nowrap ${
                              activeCodeTab === tab
                                ? 'bg-cyan-500/20 text-cyan-200 border border-cyan-500/30'
                                : 'text-slate-400 hover:text-white'
                            }`}
                          >
                            {tab}
                          </button>
                        ))}
                      </div>
                      <div className="flex items-center gap-2">
                        {isStreaming && (
                          <span className="inline-flex items-center gap-1 rounded border border-cyan-500/40 bg-cyan-500/15 px-1.5 py-0.5 font-mono text-[10px] font-semibold text-cyan-200 whitespace-nowrap">
                            <span className="h-1.5 w-1.5 rounded-full bg-cyan-300 animate-pulse" />
                            LIVE
                          </span>
                        )}
                        <span className="font-mono text-[11px] tabular-nums text-slate-400 whitespace-nowrap">
                          {currentCodeValue.length} chars
                        </span>
                      </div>
                    </div>

                    <textarea
                      ref={codeTextareaRef}
                      value={currentCodeValue}
                      readOnly={isStreaming}
                      spellCheck={false}
                      aria-label={`${activeCodeTab} code editor`}
                      onChange={(e) => {
                        const nextVal = e.target.value;
                        websiteBuilderController.updateFiles((prev) => ({
                          ...prev,
                          html: activeCodeTab === 'index.html' ? nextVal : prev.html,
                          css: activeCodeTab === 'styles.css' ? nextVal : prev.css,
                          js: activeCodeTab === 'app.js' ? nextVal : prev.js,
                        }));
                      }}
                      className="flex-1 w-full resize-none bg-[#090c11] p-3 font-mono text-xs leading-relaxed text-slate-200 focus:outline-none select-text"
                      placeholder={isStreaming ? `Streaming ${activeCodeTab}...` : `Edit ${activeCodeTab}...`}
                    />
                  </section>
                )}

                {/* LIVE PREVIEW PANE */}
                {(viewMode === 'split' || viewMode === 'preview') && (
                  <section
                    aria-label="Live Website Preview"
                    className="flex flex-1 min-w-0 min-h-0 flex-col items-center justify-start overflow-auto bg-[#131722] p-2 sm:p-3"
                  >
                    <div
                      className={`h-full min-h-[300px] ${deviceFrameWidthClass} overflow-hidden rounded-lg border border-white/15 bg-white shadow-xl transition-all`}
                    >
                      {isStreaming ? (
                        <iframe
                          ref={streamIframeRef}
                          onLoad={postStreamPatchToIframe}
                          title="Streaming Live Website Preview"
                          srcDoc={STREAMING_PREVIEW_SHELL_SRCDOC}
                          sandbox="allow-scripts allow-same-origin"
                          className="h-full w-full border-0 bg-white"
                        />
                      ) : (
                        <iframe
                          title="Interactive Website Preview"
                          srcDoc={interactivePreviewSrcDoc}
                          sandbox="allow-scripts allow-same-origin allow-forms"
                          className="h-full w-full border-0 bg-white"
                        />
                      )}
                    </div>
                  </section>
                )}
              </div>

              {/* BOTTOM VOICE & TEXT CONTINUOUS CHANGE BAR */}
              <form
                onSubmit={handleSubmitPrompt}
                className="flex flex-wrap sm:flex-nowrap items-center gap-2 border-t border-white/10 bg-[#0d1118] px-3 py-2"
              >
                <button
                  type="button"
                  onClick={handleToggleVoiceCommand}
                  disabled={isStreaming}
                  title="Speak changes to apply live"
                  className={`inline-flex shrink-0 items-center gap-1.5 rounded-md border px-2.5 py-1.5 text-xs font-medium whitespace-nowrap ${
                    isListeningVoice
                      ? 'border-red-500/60 bg-red-500/20 text-red-200'
                      : 'border-white/15 bg-black/40 text-slate-200 hover:bg-white/10'
                  }`}
                >
                  {isListeningVoice ? <MicOff className="h-3.5 w-3.5" /> : <Mic className="h-3.5 w-3.5" />}
                  {isListeningVoice ? 'Listening...' : 'Voice Edit'}
                </button>

                <input
                  type="text"
                  value={promptInput}
                  onChange={(e) => setPromptInput(e.target.value)}
                  disabled={isStreaming}
                  placeholder="Describe any change (add section, change layout/colors, translate text, edit features)..."
                  className="min-w-0 flex-1 rounded-md border border-white/15 bg-black/50 px-3 py-1.5 text-xs sm:text-sm text-white placeholder-slate-500 focus:border-cyan-400 focus:outline-none"
                />

                <button
                  type="submit"
                  disabled={isStreaming || !promptInput.trim()}
                  className="inline-flex shrink-0 items-center gap-1.5 rounded-md bg-cyan-500 px-3 py-1.5 text-xs font-semibold text-slate-950 hover:bg-cyan-400 disabled:opacity-40 whitespace-nowrap"
                >
                  <Send className="h-3.5 w-3.5" />
                  Apply Change
                </button>
              </form>
            </div>

            {/* RIGHT FULL CUSTOM EDITOR INSPECTOR (Docked on Desktop, Slide-Over Drawer on Mobile/Tablet) */}
            {builderState.status === 'ready' && showInspector && (
              <aside
                aria-label="Custom Website Editor"
                className="fixed inset-y-0 right-0 z-40 w-80 max-w-[90vw] shadow-2xl lg:static lg:z-auto lg:shadow-none shrink-0 border-l border-white/10 bg-[#0d1118] flex flex-col min-h-0 overflow-hidden"
              >
                <div className="flex items-center justify-between border-b border-white/10 bg-[#0a0d13] px-3 py-2 lg:hidden">
                  <span className="text-xs font-semibold text-white">Custom Website Editor</span>
                  <button
                    type="button"
                    onClick={() => setShowInspector(false)}
                    className="rounded p-1 text-slate-400 hover:bg-white/10 hover:text-white"
                    aria-label="Close Custom Editor"
                  >
                    <X className="h-4 w-4" />
                  </button>
                </div>
                <div className="grid grid-cols-4 border-b border-white/10 bg-[#0a0d13]">
                  {(
                    [
                      { id: 'sections', label: 'Sections', Icon: Layers },
                      { id: 'element', label: 'Text', Icon: Type },
                      { id: 'colors', label: 'Colors', Icon: Palette },
                      { id: 'images', label: 'Images', Icon: ImageIcon },
                    ] as const
                  ).map(({ id, label, Icon }) => (
                    <button
                      key={id}
                      type="button"
                      onClick={() => setInspectorTab(id)}
                      className={`flex flex-col items-center gap-0.5 py-2 text-[11px] font-medium border-b-2 ${
                        inspectorTab === id
                          ? 'border-cyan-400 text-cyan-200 bg-white/5'
                          : 'border-transparent text-slate-400 hover:text-white'
                      }`}
                    >
                      <Icon className="h-3.5 w-3.5" />
                      {label}
                    </button>
                  ))}
                </div>

                <div className="flex-1 overflow-y-auto p-3 space-y-4 text-xs">
                  {/* TAB 1: SECTIONS & LAYOUT */}
                  {inspectorTab === 'sections' && (
                    <>
                      <div className="flex items-center justify-between">
                        <span className="font-semibold text-slate-200">
                          Page Sections ({parsedSections.length})
                        </span>
                        <button
                          type="button"
                          onClick={() => setShowAddSectionForm((v) => !v)}
                          className="inline-flex items-center gap-1 rounded border border-cyan-500/40 bg-cyan-500/15 px-2 py-1 text-[11px] text-cyan-200 hover:bg-cyan-500/25"
                        >
                          <Plus className="h-3 w-3" />
                          Add Section
                        </button>
                      </div>

                      {showAddSectionForm && (
                        <div className="space-y-2 rounded-lg border border-cyan-500/30 bg-black/40 p-2.5">
                          <input
                            type="text"
                            value={newSectionTitle}
                            onChange={(e) => setNewSectionTitle(e.target.value)}
                            placeholder="Section heading..."
                            className="w-full rounded border border-white/15 bg-black/50 px-2 py-1 text-xs text-white"
                          />
                          <textarea
                            rows={2}
                            value={newSectionBody}
                            onChange={(e) => setNewSectionBody(e.target.value)}
                            placeholder="Section paragraph text..."
                            className="w-full resize-none rounded border border-white/15 bg-black/50 px-2 py-1 text-xs text-white"
                          />
                          <div className="flex justify-end gap-1.5">
                            <button
                              type="button"
                              onClick={() => setShowAddSectionForm(false)}
                              className="rounded border border-white/10 px-2 py-1 text-[11px] text-slate-300"
                            >
                              Cancel
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                websiteBuilderController.updateFiles((prev) => ({
                                  ...prev,
                                  html: addCustomSectionToHtml(prev.html, {
                                    title: newSectionTitle || 'New Section',
                                    body: newSectionBody || 'Section details.',
                                  }),
                                }));
                                setNewSectionTitle('');
                                setNewSectionBody('');
                                setShowAddSectionForm(false);
                              }}
                              className="rounded bg-cyan-500 px-2.5 py-1 text-[11px] font-semibold text-slate-950"
                            >
                              Insert Section
                            </button>
                          </div>
                        </div>
                      )}

                      <div className="space-y-1.5">
                        {parsedSections.map((sec) => (
                          <div
                            key={`${sec.index}-${sec.id}`}
                            onClick={() => setSelectedSectionIndex(sec.index)}
                            className={`flex items-center justify-between gap-1 rounded-md border px-2 py-1.5 cursor-pointer ${
                              activeSection?.index === sec.index
                                ? 'border-cyan-500/50 bg-cyan-500/10 text-white'
                                : 'border-white/10 bg-black/30 text-slate-300 hover:border-white/25'
                            }`}
                          >
                            <div className="min-w-0">
                              <div className="truncate font-medium">{sec.label}</div>
                              <div className="font-mono text-[10px] text-slate-500">
                                &lt;{sec.tagName}&gt;{sec.id ? ` #${sec.id}` : ''}
                              </div>
                            </div>
                            <div className="flex items-center gap-0.5 shrink-0">
                              <button
                                type="button"
                                title="Move Up"
                                disabled={sec.index === 0}
                                onClick={(e) => {
                                  e.stopPropagation();
                                  websiteBuilderController.updateFiles((prev) => ({
                                    ...prev,
                                    html: moveSectionInHtml(prev.html, sec.index, -1),
                                  }));
                                  setSelectedSectionIndex(Math.max(0, sec.index - 1));
                                }}
                                className="rounded p-1 hover:bg-white/10 disabled:opacity-30"
                              >
                                <ArrowUp className="h-3 w-3" />
                              </button>
                              <button
                                type="button"
                                title="Move Down"
                                disabled={sec.index === parsedSections.length - 1}
                                onClick={(e) => {
                                  e.stopPropagation();
                                  websiteBuilderController.updateFiles((prev) => ({
                                    ...prev,
                                    html: moveSectionInHtml(prev.html, sec.index, 1),
                                  }));
                                  setSelectedSectionIndex(Math.min(parsedSections.length - 1, sec.index + 1));
                                }}
                                className="rounded p-1 hover:bg-white/10 disabled:opacity-30"
                              >
                                <ArrowDown className="h-3 w-3" />
                              </button>
                              <button
                                type="button"
                                title="Duplicate Section"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  websiteBuilderController.updateFiles((prev) => ({
                                    ...prev,
                                    html: duplicateSectionInHtml(prev.html, sec.index),
                                  }));
                                }}
                                className="rounded p-1 hover:bg-white/10"
                              >
                                <CopyPlus className="h-3 w-3" />
                              </button>
                              <button
                                type="button"
                                title="Delete Section"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  websiteBuilderController.updateFiles((prev) => ({
                                    ...prev,
                                    html: deleteSectionInHtml(prev.html, sec.index),
                                  }));
                                  setSelectedSectionIndex(0);
                                }}
                                className="rounded p-1 text-red-400 hover:bg-red-500/15"
                              >
                                <Trash2 className="h-3 w-3" />
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>

                      {activeSection && (
                        <div className="space-y-3 border-t border-white/10 pt-3">
                          <div className="font-semibold text-slate-200">
                            Layout & Style: {activeSection.label}
                          </div>

                          <div className="grid grid-cols-2 gap-2">
                            <label className="space-y-1">
                              <span className="text-[11px] text-slate-400">Section Bg</span>
                              <div className="flex items-center gap-1.5">
                                <input
                                  type="color"
                                  value={normalizeHexColor(activeSection.backgroundColor, '#0f172a')}
                                  onChange={(e) =>
                                    websiteBuilderController.updateFiles((prev) => ({
                                      ...prev,
                                      html: updateSectionStyleInHtml(prev.html, activeSection.index, {
                                        backgroundColor: e.target.value,
                                      }),
                                    }))
                                  }
                                  className="h-7 w-8 cursor-pointer rounded border border-white/15 bg-transparent"
                                />
                                <input
                                  type="text"
                                  value={activeSection.backgroundColor}
                                  placeholder="auto"
                                  onChange={(e) =>
                                    websiteBuilderController.updateFiles((prev) => ({
                                      ...prev,
                                      html: updateSectionStyleInHtml(prev.html, activeSection.index, {
                                        backgroundColor: e.target.value,
                                      }),
                                    }))
                                  }
                                  className="min-w-0 flex-1 rounded border border-white/15 bg-black/40 px-1.5 py-1 font-mono text-[11px]"
                                />
                              </div>
                            </label>

                            <label className="space-y-1">
                              <span className="text-[11px] text-slate-400">Text Color</span>
                              <div className="flex items-center gap-1.5">
                                <input
                                  type="color"
                                  value={normalizeHexColor(activeSection.color, '#f8fafc')}
                                  onChange={(e) =>
                                    websiteBuilderController.updateFiles((prev) => ({
                                      ...prev,
                                      html: updateSectionStyleInHtml(prev.html, activeSection.index, {
                                        color: e.target.value,
                                      }),
                                    }))
                                  }
                                  className="h-7 w-8 cursor-pointer rounded border border-white/15 bg-transparent"
                                />
                                <input
                                  type="text"
                                  value={activeSection.color}
                                  placeholder="auto"
                                  onChange={(e) =>
                                    websiteBuilderController.updateFiles((prev) => ({
                                      ...prev,
                                      html: updateSectionStyleInHtml(prev.html, activeSection.index, {
                                        color: e.target.value,
                                      }),
                                    }))
                                  }
                                  className="min-w-0 flex-1 rounded border border-white/15 bg-black/40 px-1.5 py-1 font-mono text-[11px]"
                                />
                              </div>
                            </label>
                          </div>

                          <div className="grid grid-cols-2 gap-2">
                            <label className="space-y-1">
                              <span className="text-[11px] text-slate-400">Layout Mode</span>
                              <select
                                value={activeSection.layoutMode}
                                onChange={(e) =>
                                  websiteBuilderController.updateFiles((prev) => ({
                                    ...prev,
                                    html: updateSectionStyleInHtml(prev.html, activeSection.index, {
                                      layoutMode: e.target.value as ParsedSection['layoutMode'],
                                    }),
                                  }))
                                }
                                className="w-full rounded border border-white/15 bg-black/50 px-2 py-1 text-xs text-white"
                              >
                                <option value="block">Block / Stack</option>
                                <option value="grid-2">2 Columns Grid</option>
                                <option value="grid-3">3 Columns Grid</option>
                                <option value="flex-row">Flex Row Wrap</option>
                              </select>
                            </label>

                            <label className="space-y-1">
                              <span className="text-[11px] text-slate-400">Alignment</span>
                              <select
                                value={activeSection.textAlign || 'left'}
                                onChange={(e) =>
                                  websiteBuilderController.updateFiles((prev) => ({
                                    ...prev,
                                    html: updateSectionStyleInHtml(prev.html, activeSection.index, {
                                      textAlign: e.target.value,
                                    }),
                                  }))
                                }
                                className="w-full rounded border border-white/15 bg-black/50 px-2 py-1 text-xs text-white"
                              >
                                <option value="left">Left</option>
                                <option value="center">Center</option>
                                <option value="right">Right</option>
                              </select>
                            </label>
                          </div>

                          <div className="grid grid-cols-2 gap-2">
                            <label className="space-y-1">
                              <span className="text-[11px] text-slate-400">Padding</span>
                              <input
                                type="text"
                                value={activeSection.padding}
                                placeholder="e.g. 64px 24px"
                                onChange={(e) =>
                                  websiteBuilderController.updateFiles((prev) => ({
                                    ...prev,
                                    html: updateSectionStyleInHtml(prev.html, activeSection.index, {
                                      padding: e.target.value,
                                    }),
                                  }))
                                }
                                className="w-full rounded border border-white/15 bg-black/40 px-2 py-1 font-mono text-[11px]"
                              />
                            </label>
                            <label className="space-y-1">
                              <span className="text-[11px] text-slate-400">Max Width</span>
                              <input
                                type="text"
                                value={activeSection.maxWidth}
                                placeholder="e.g. 1200px"
                                onChange={(e) =>
                                  websiteBuilderController.updateFiles((prev) => ({
                                    ...prev,
                                    html: updateSectionStyleInHtml(prev.html, activeSection.index, {
                                      maxWidth: e.target.value,
                                    }),
                                  }))
                                }
                                className="w-full rounded border border-white/15 bg-black/40 px-2 py-1 font-mono text-[11px]"
                              />
                            </label>
                          </div>
                        </div>
                      )}
                    </>
                  )}

                  {/* TAB 2: TEXT & ELEMENT */}
                  {inspectorTab === 'element' && (
                    <>
                      {!selectedElement ? (
                        <div className="rounded-lg border border-dashed border-white/15 bg-black/30 p-4 text-slate-400">
                          Turn on <strong className="text-slate-200">Inline Edit: ON</strong> and click any heading, paragraph, button, or card in the live preview to edit its text inline or customize its styling here.
                        </div>
                      ) : (
                        <div className="space-y-3">
                          <div className="flex items-center justify-between">
                            <span className="font-mono text-xs text-cyan-300">
                              &lt;{selectedElement.tagName}&gt;
                            </span>
                            <button
                              type="button"
                              onClick={() => setSelectedElement(null)}
                              className="text-[11px] text-slate-400 hover:text-white"
                            >
                              Clear
                            </button>
                          </div>

                          {selectedElement.isTextEditable && (
                            <label className="block space-y-1">
                              <span className="text-[11px] text-slate-400">Text Content</span>
                              <textarea
                                rows={4}
                                value={selectedElement.text}
                                onChange={(e) => {
                                  const nextText = e.target.value;
                                  setSelectedElement((prev) =>
                                    prev ? { ...prev, text: nextText } : prev
                                  );
                                  websiteBuilderController.updateFiles((prev) => ({
                                    ...prev,
                                    html: updateElementByPathInHtml(prev.html, selectedElement.path, {
                                      text: nextText,
                                    }),
                                  }));
                                }}
                                className="w-full rounded border border-white/15 bg-black/50 p-2 text-xs text-white focus:border-cyan-400 focus:outline-none"
                              />
                            </label>
                          )}

                          <div className="grid grid-cols-2 gap-2">
                            <label className="space-y-1">
                              <span className="text-[11px] text-slate-400">Text Color</span>
                              <input
                                type="color"
                                value={normalizeHexColor(selectedElement.color, '#ffffff')}
                                onChange={(e) => {
                                  const val = e.target.value;
                                  setSelectedElement((prev) => (prev ? { ...prev, color: val } : prev));
                                  websiteBuilderController.updateFiles((prev) => ({
                                    ...prev,
                                    html: updateElementByPathInHtml(prev.html, selectedElement.path, {
                                      color: val,
                                    }),
                                  }));
                                }}
                                className="h-8 w-full cursor-pointer rounded border border-white/15 bg-transparent"
                              />
                            </label>
                            <label className="space-y-1">
                              <span className="text-[11px] text-slate-400">Background</span>
                              <input
                                type="color"
                                value={normalizeHexColor(selectedElement.backgroundColor, '#0f172a')}
                                onChange={(e) => {
                                  const val = e.target.value;
                                  setSelectedElement((prev) =>
                                    prev ? { ...prev, backgroundColor: val } : prev
                                  );
                                  websiteBuilderController.updateFiles((prev) => ({
                                    ...prev,
                                    html: updateElementByPathInHtml(prev.html, selectedElement.path, {
                                      backgroundColor: val,
                                    }),
                                  }));
                                }}
                                className="h-8 w-full cursor-pointer rounded border border-white/15 bg-transparent"
                              />
                            </label>
                          </div>

                          <div className="grid grid-cols-2 gap-2">
                            <label className="space-y-1">
                              <span className="text-[11px] text-slate-400">Font Size</span>
                              <input
                                type="text"
                                value={selectedElement.fontSize}
                                onChange={(e) => {
                                  const val = e.target.value;
                                  setSelectedElement((prev) => (prev ? { ...prev, fontSize: val } : prev));
                                  websiteBuilderController.updateFiles((prev) => ({
                                    ...prev,
                                    html: updateElementByPathInHtml(prev.html, selectedElement.path, {
                                      fontSize: val,
                                    }),
                                  }));
                                }}
                                className="w-full rounded border border-white/15 bg-black/40 px-2 py-1 font-mono text-[11px]"
                              />
                            </label>
                            <label className="space-y-1">
                              <span className="text-[11px] text-slate-400">Font Weight</span>
                              <select
                                value={selectedElement.fontWeight}
                                onChange={(e) => {
                                  const val = e.target.value;
                                  setSelectedElement((prev) =>
                                    prev ? { ...prev, fontWeight: val } : prev
                                  );
                                  websiteBuilderController.updateFiles((prev) => ({
                                    ...prev,
                                    html: updateElementByPathInHtml(prev.html, selectedElement.path, {
                                      fontWeight: val,
                                    }),
                                  }));
                                }}
                                className="w-full rounded border border-white/15 bg-black/50 px-2 py-1 text-xs text-white"
                              >
                                <option value="400">Regular (400)</option>
                                <option value="500">Medium (500)</option>
                                <option value="600">Semibold (600)</option>
                                <option value="700">Bold (700)</option>
                              </select>
                            </label>
                          </div>
                        </div>
                      )}
                    </>
                  )}

                  {/* TAB 3: COLORS */}
                  {inspectorTab === 'colors' && (
                    <div className="space-y-3">
                      <div className="font-semibold text-slate-200">Theme CSS Color Variables</div>
                      {parsedCssVars.length === 0 ? (
                        <div className="space-y-2 rounded border border-white/10 bg-black/30 p-3">
                          <p className="text-slate-400">
                            No `:root` color variables detected in styles.css. Set global page background & text colors directly:
                          </p>
                          <div className="grid grid-cols-2 gap-2">
                            <label className="space-y-1">
                              <span className="text-[11px] text-slate-400">Page Background</span>
                              <input
                                type="color"
                                defaultValue="#0f172a"
                                onChange={(e) =>
                                  websiteBuilderController.updateFiles((prev) => ({
                                    ...prev,
                                    css: updateBodyPaletteOverride(prev.css, {
                                      backgroundColor: e.target.value,
                                    }),
                                  }))
                                }
                                className="h-8 w-full cursor-pointer rounded border border-white/15 bg-transparent"
                              />
                            </label>
                            <label className="space-y-1">
                              <span className="text-[11px] text-slate-400">Page Text</span>
                              <input
                                type="color"
                                defaultValue="#f8fafc"
                                onChange={(e) =>
                                  websiteBuilderController.updateFiles((prev) => ({
                                    ...prev,
                                    css: updateBodyPaletteOverride(prev.css, { color: e.target.value }),
                                  }))
                                }
                                className="h-8 w-full cursor-pointer rounded border border-white/15 bg-transparent"
                              />
                            </label>
                          </div>
                        </div>
                      ) : (
                        <div className="space-y-2">
                          {parsedCssVars.map((cVar) => (
                            <div
                              key={cVar.name}
                              className="flex items-center justify-between gap-2 rounded border border-white/10 bg-black/30 px-2.5 py-1.5"
                            >
                              <div className="min-w-0">
                                <div className="truncate font-mono text-[11px] text-slate-200">
                                  {cVar.name}
                                </div>
                                <div className="font-mono text-[10px] text-slate-500">{cVar.value}</div>
                              </div>
                              <input
                                type="color"
                                value={cVar.hexValue}
                                aria-label={cVar.name}
                                onChange={(e) =>
                                  websiteBuilderController.updateFiles((prev) => ({
                                    ...prev,
                                    css: updateCssColorVar(prev.css, cVar.name, e.target.value),
                                  }))
                                }
                                className="h-7 w-9 shrink-0 cursor-pointer rounded border border-white/15 bg-transparent"
                              />
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  )}

                  {/* TAB 4: IMAGES */}
                  {inspectorTab === 'images' && (
                    <div className="space-y-3">
                      <div className="font-semibold text-slate-200">
                        Images ({parsedImages.length})
                      </div>

                      {parsedImages.map((img) => (
                        <div
                          key={img.index}
                          className="space-y-2 rounded-lg border border-white/10 bg-black/35 p-2.5"
                        >
                          <div className="flex items-center justify-between gap-2">
                            <span className="font-mono text-[11px] text-cyan-300">
                              Image #{img.index + 1}
                            </span>
                            <button
                              type="button"
                              onClick={() => {
                                uploadForExistingImgIndexRef.current = img.index;
                                replaceImageFileInputRef.current?.click();
                              }}
                              className="inline-flex items-center gap-1 rounded border border-white/15 bg-white/5 px-2 py-0.5 text-[11px] text-white hover:bg-white/10"
                            >
                              <Upload className="h-3 w-3" />
                              Upload File
                            </button>
                          </div>

                          <input
                            type="text"
                            value={img.src}
                            placeholder="Image URL or ./assets/..."
                            onChange={(e) =>
                              websiteBuilderController.updateFiles((prev) => ({
                                ...prev,
                                html: updateImageInHtml(prev.html, img.index, { src: e.target.value }),
                              }))
                            }
                            className="w-full rounded border border-white/15 bg-black/50 px-2 py-1 font-mono text-[11px]"
                          />

                          <input
                            type="text"
                            value={img.alt}
                            placeholder="Alt description..."
                            onChange={(e) =>
                              websiteBuilderController.updateFiles((prev) => ({
                                ...prev,
                                html: updateImageInHtml(prev.html, img.index, { alt: e.target.value }),
                              }))
                            }
                            className="w-full rounded border border-white/15 bg-black/50 px-2 py-1 text-xs"
                          />

                          <div className="grid grid-cols-2 gap-1.5">
                            <input
                              type="text"
                              value={img.borderRadius}
                              placeholder="Radius e.g. 12px"
                              onChange={(e) =>
                                websiteBuilderController.updateFiles((prev) => ({
                                  ...prev,
                                  html: updateImageInHtml(prev.html, img.index, {
                                    borderRadius: e.target.value,
                                  }),
                                }))
                              }
                              className="rounded border border-white/15 bg-black/50 px-2 py-1 font-mono text-[11px]"
                            />
                            <select
                              value={img.objectFit || 'cover'}
                              onChange={(e) =>
                                websiteBuilderController.updateFiles((prev) => ({
                                  ...prev,
                                  html: updateImageInHtml(prev.html, img.index, {
                                    objectFit: e.target.value,
                                  }),
                                }))
                              }
                              className="rounded border border-white/15 bg-black/50 px-2 py-1 text-[11px]"
                            >
                              <option value="cover">Cover</option>
                              <option value="contain">Contain</option>
                              <option value="fill">Fill</option>
                            </select>
                          </div>
                        </div>
                      ))}

                      {/* Upload & Insert a new image into any section */}
                      <div className="space-y-2 rounded-lg border border-dashed border-white/15 bg-black/25 p-2.5">
                        <div className="font-medium text-slate-200">Add Image to Section</div>
                        {parsedSections.length > 0 && (
                          <select
                            value={newImgTargetSection}
                            onChange={(e) => setNewImgTargetSection(Number(e.target.value))}
                            className="w-full rounded border border-white/15 bg-black/50 px-2 py-1 text-xs"
                          >
                            {parsedSections.map((sec) => (
                              <option key={sec.index} value={sec.index}>
                                {sec.label}
                              </option>
                            ))}
                          </select>
                        )}
                        <input
                          type="text"
                          value={newImgAlt}
                          onChange={(e) => setNewImgAlt(e.target.value)}
                          placeholder="Image alt label..."
                          className="w-full rounded border border-white/15 bg-black/50 px-2 py-1 text-xs"
                        />
                        <button
                          type="button"
                          onClick={() => insertImageFileInputRef.current?.click()}
                          className="flex w-full items-center justify-center gap-1.5 rounded border border-cyan-500/40 bg-cyan-500/15 py-1.5 text-xs font-medium text-cyan-200 hover:bg-cyan-500/25"
                        >
                          <Upload className="h-3.5 w-3.5" />
                          Choose Local Image & Insert
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </aside>
            )}
          </>
        )}
      </div>

      {/* PUBLISH & CUSTOM DOMAIN OVERLAY MODAL */}
      {showPublishPanel && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4">
          <div className="w-full max-w-xl max-h-[90vh] overflow-y-auto rounded-xl border border-white/15 bg-[#0f131b] p-5 text-slate-100 shadow-2xl space-y-5">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="flex items-center gap-2">
                <Globe className="h-5 w-5 text-cyan-400" />
                <h2 className="text-base font-semibold text-white">
                  Publish & Custom Domain
                </h2>
              </div>
              <button
                type="button"
                onClick={() => setShowPublishPanel(false)}
                className="rounded p-1 text-slate-400 hover:bg-white/10 hover:text-white"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {isPublishing && !publishedSite ? (
              <div className="flex items-center gap-2 py-6 text-sm text-cyan-200">
                <RefreshCw className="h-4 w-4 animate-spin" />
                Publishing your standalone website files...
              </div>
            ) : publishedSite ? (
              <>
                {/* Public URL Box */}
                <div className="space-y-2 rounded-lg border border-emerald-500/30 bg-emerald-950/25 p-3.5">
                  <div className="flex items-center gap-1.5 text-xs font-semibold text-emerald-300">
                    <CheckCircle2 className="h-4 w-4" />
                    Public Website Live
                  </div>
                  <div className="flex items-center gap-2 rounded border border-white/15 bg-black/50 px-2.5 py-2">
                    <span className="flex-1 truncate font-mono text-xs text-cyan-200 select-all">
                      {publishedSite.publicUrl}
                    </span>
                    <button
                      type="button"
                      onClick={handleCopyPublicUrl}
                      className="inline-flex items-center gap-1 rounded border border-white/15 bg-white/10 px-2 py-1 text-xs text-white hover:bg-white/20 whitespace-nowrap"
                    >
                      {copiedUrl ? <Check className="h-3 w-3 text-emerald-400" /> : <Copy className="h-3 w-3" />}
                      {copiedUrl ? 'Copied' : 'Copy'}
                    </button>
                    <button
                      type="button"
                      onClick={handleSharePublicUrl}
                      className="inline-flex items-center gap-1 rounded border border-white/15 bg-white/10 px-2 py-1 text-xs text-white hover:bg-white/20 whitespace-nowrap"
                    >
                      <Share2 className="h-3 w-3" />
                      Share
                    </button>
                  </div>
                  <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                    <a
                      href={publishedSite.publicUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 rounded bg-emerald-500 px-3 py-1.5 text-xs font-semibold text-slate-950 hover:bg-emerald-400"
                    >
                      <ExternalLink className="h-3.5 w-3.5" />
                      Open Live Site
                    </a>
                    <button
                      type="button"
                      onClick={handlePublishSite}
                      disabled={isPublishing}
                      className="rounded border border-white/15 bg-black/40 px-3 py-1.5 text-xs text-slate-200 hover:bg-white/10"
                    >
                      {isPublishing ? 'Republishing...' : 'Push Latest Edits'}
                    </button>
                  </div>
                </div>

                {/* Custom Domain Section */}
                <div className="space-y-3 rounded-lg border border-white/15 bg-black/30 p-3.5">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5 text-sm font-semibold text-white">
                      <ShieldCheck className="h-4 w-4 text-cyan-400" />
                      Custom Domain & Automatic HTTPS
                    </div>
                    {publishedSite.customDomain && (
                      <span
                        className={`rounded px-2 py-0.5 text-[11px] font-medium ${
                          publishedSite.httpsStatus === 'active'
                            ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                            : 'bg-amber-500/20 text-amber-200 border border-amber-500/30'
                        }`}
                      >
                        {publishedSite.httpsStatus === 'active' ? 'HTTPS Active' : 'Pending DNS'}
                      </span>
                    )}
                  </div>

                  <form onSubmit={handleConnectDomain} className="flex gap-2">
                    <input
                      type="text"
                      value={domainInput}
                      onChange={(e) => setDomainInput(e.target.value)}
                      placeholder="yourdomain.com or www.yourdomain.com"
                      className="min-w-0 flex-1 rounded-md border border-white/15 bg-black/50 px-3 py-1.5 font-mono text-xs text-white placeholder-slate-500 focus:border-cyan-400 focus:outline-none"
                    />
                    <button
                      type="submit"
                      disabled={isSavingDomain || !domainInput.trim()}
                      className="rounded-md bg-cyan-500 px-3 py-1.5 text-xs font-semibold text-slate-950 hover:bg-cyan-400 disabled:opacity-40 whitespace-nowrap"
                    >
                      {isSavingDomain ? 'Saving...' : 'Connect Domain'}
                    </button>
                  </form>

                  {domainError && <p className="text-xs text-red-300">{domainError}</p>}

                  {publishedSite.customDomain && (
                    <div className="space-y-3 border-t border-white/10 pt-3 text-xs">
                      <div className="flex items-center justify-between">
                        <span className="font-mono text-cyan-200">{publishedSite.customDomain}</span>
                        <button
                          type="button"
                          onClick={handleDisconnectDomain}
                          className="text-[11px] text-red-400 hover:underline"
                        >
                          Remove Domain
                        </button>
                      </div>

                      {publishedSite.dnsGuide && (
                        <div className="space-y-2">
                          <div className="font-medium text-slate-200">
                            Add these DNS records at your domain registrar:
                          </div>
                          <div className="space-y-1.5">
                            {publishedSite.dnsGuide.records.map((rec, i) => (
                              <div
                                key={i}
                                className="rounded border border-white/10 bg-black/50 p-2 font-mono text-[11px] space-y-1"
                              >
                                <div className="flex flex-wrap items-center justify-between gap-2 text-cyan-300">
                                  <div className="flex flex-wrap items-center gap-2">
                                    <span className="rounded bg-white/10 px-1.5 py-0.5 text-white">
                                      {rec.type}
                                    </span>
                                    <span>Host: {rec.host}</span>
                                  </div>
                                  <button
                                    type="button"
                                    onClick={async () => {
                                      try {
                                        await navigator.clipboard.writeText(rec.host);
                                        setCopiedDnsKey(`host-${i}`);
                                        setTimeout(() => setCopiedDnsKey(null), 1600);
                                      } catch {}
                                    }}
                                    className="rounded border border-white/15 bg-white/5 px-1.5 py-0.5 text-[10px] text-slate-200 hover:bg-white/15"
                                  >
                                    {copiedDnsKey === `host-${i}` ? 'Copied' : 'Copy Host'}
                                  </button>
                                </div>
                                <div className="flex items-center justify-between gap-2">
                                  <span className="break-all text-slate-200">Value: {rec.value}</span>
                                  <button
                                    type="button"
                                    onClick={async () => {
                                      try {
                                        await navigator.clipboard.writeText(rec.value);
                                        setCopiedDnsKey(`val-${i}`);
                                        setTimeout(() => setCopiedDnsKey(null), 1600);
                                      } catch {}
                                    }}
                                    className="shrink-0 rounded border border-white/15 bg-white/5 px-1.5 py-0.5 text-[10px] text-slate-200 hover:bg-white/15"
                                  >
                                    {copiedDnsKey === `val-${i}` ? 'Copied' : 'Copy Value'}
                                  </button>
                                </div>
                                <div className="font-sans text-[11px] text-slate-400">{rec.note}</div>
                              </div>
                            ))}
                          </div>
                          <ul className="list-disc pl-4 space-y-1 text-[11px] text-slate-400">
                            {publishedSite.dnsGuide.httpsSteps.map((step, i) => (
                              <li key={i}>{step}</li>
                            ))}
                          </ul>
                        </div>
                      )}

                      {publishedSite.verifyMessage && (
                        <div
                          className={`rounded border p-2 text-xs ${
                            publishedSite.domainVerified
                              ? 'border-emerald-500/30 bg-emerald-950/40 text-emerald-200'
                              : 'border-amber-500/30 bg-amber-950/40 text-amber-200'
                          }`}
                        >
                          {publishedSite.verifyMessage}
                        </div>
                      )}

                      <button
                        type="button"
                        onClick={handleVerifyDomain}
                        disabled={isVerifyingDomain}
                        className="inline-flex items-center gap-1.5 rounded border border-cyan-500/40 bg-cyan-500/15 px-3 py-1.5 text-xs font-medium text-cyan-200 hover:bg-cyan-500/25"
                      >
                        <RefreshCw className={`h-3.5 w-3.5 ${isVerifyingDomain ? 'animate-spin' : ''}`} />
                        {isVerifyingDomain ? 'Checking DNS...' : 'Verify DNS & Activate HTTPS'}
                      </button>
                    </div>
                  )}
                </div>
              </>
            ) : null}
          </div>
        </div>
      )}
    </div>
  );
};
