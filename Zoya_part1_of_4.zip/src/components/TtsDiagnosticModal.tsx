import React, { useState, useEffect, useRef } from 'react';
import {
  Volume2,
  Play,
  Square,
  RefreshCw,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  ShieldCheck,
  Cpu,
  Layers,
  ArrowRight,
  Database,
  Radio,
  FileText,
  Copy,
  Check,
  X,
  Key,
  Clock,
  Sparkles,
  Zap,
} from 'lucide-react';
import {
  TtsEngineInventoryItem,
  TtsServerAuditData,
  FallbackChainVerificationResult,
  fetchServerTtsAudit,
  buildTtsInventory,
  testIndividualTtsEngine,
  runFallbackChainAudit,
  testElevenLabsConnection,
} from '../services/ttsDiagnosticService';

interface TtsDiagnosticModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const TtsDiagnosticModal: React.FC<TtsDiagnosticModalProps> = ({ isOpen, onClose }) => {
  const [serverAudit, setServerAudit] = useState<TtsServerAuditData | null>(null);
  const [inventory, setInventory] = useState<TtsEngineInventoryItem[]>([]);
  const [testPhrase, setTestPhrase] = useState<string>('नमस्ते! मैं ज़ोया हूँ, आपकी एआई साथी।');
  const [testingEngineId, setTestingEngineId] = useState<string | null>(null);
  const [isPlayingAudio, setIsPlayingAudio] = useState<string | null>(null);
  const [isAuditingFallbackChain, setIsAuditingFallbackChain] = useState<boolean>(false);
  const [fallbackResult, setFallbackResult] = useState<FallbackChainVerificationResult | null>(null);
  const [copiedReport, setCopiedReport] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'inventory' | 'testing' | 'fallback' | 'report'>('inventory');

  const activeAudioRef = useRef<HTMLAudioElement | null>(null);

  const loadDiagnostics = async () => {
    const sAudit = await fetchServerTtsAudit();
    setServerAudit(sAudit);
    const initialInventory = buildTtsInventory(sAudit);
    setInventory(initialInventory);
  };

  useEffect(() => {
    if (isOpen) {
      loadDiagnostics();
    } else {
      stopActiveAudio();
    }
  }, [isOpen]);

  const stopActiveAudio = () => {
    if (activeAudioRef.current) {
      try {
        activeAudioRef.current.pause();
        activeAudioRef.current.src = '';
      } catch {}
      activeAudioRef.current = null;
    }
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      try {
        window.speechSynthesis.cancel();
      } catch {}
    }
    setIsPlayingAudio(null);
  };

  const handleTestEngine = async (item: TtsEngineInventoryItem) => {
    stopActiveAudio();
    setTestingEngineId(item.id);

    try {
      const result = await testIndividualTtsEngine(item.id, testPhrase);
      setInventory((prev) =>
        prev.map((eng) => (eng.id === item.id ? { ...eng, testResult: result } : eng))
      );
      if (result.playbackSucceeded) {
        setIsPlayingAudio(item.id);
        setTimeout(() => setIsPlayingAudio(null), 3500);
      }
    } catch (err: any) {
      console.error('[TTS_DIAGNOSTIC] Test failed for', item.id, err);
    } finally {
      setTestingEngineId(null);
    }
  };

  const handleRunAllEngineTests = async () => {
    stopActiveAudio();
    for (const item of inventory) {
      setTestingEngineId(item.id);
      const result = await testIndividualTtsEngine(item.id, testPhrase);
      setInventory((prev) =>
        prev.map((eng) => (eng.id === item.id ? { ...eng, testResult: result } : eng))
      );
      await new Promise((resolve) => setTimeout(resolve, 350));
    }
    setTestingEngineId(null);
  };

  const handleRunFallbackChain = async () => {
    stopActiveAudio();
    setIsAuditingFallbackChain(true);
    try {
      const res = await runFallbackChainAudit();
      setFallbackResult(res);
    } finally {
      setIsAuditingFallbackChain(false);
    }
  };

  const primaryEngine = inventory.find((e) => e.role === 'PRIMARY') || inventory[0];
  const backupEngine = inventory.find((e) => e.role === 'BACKUP') || inventory[1];
  const fallbackEngine = inventory.find((e) => e.role === 'FALLBACK') || inventory[2];

  const testedCount = inventory.filter((e) => e.testResult).length;
  const workingCount = inventory.filter((e) => e.testResult?.success).length;

  const healthScore =
    testedCount === 0
      ? 0
      : Math.round((workingCount / testedCount) * 100);

  const handleCopyReport = () => {
    const lines = [
      `# ZOYA AI — COMPLETE TTS SYSTEM DIAGNOSTIC REPORT`,
      `Generated: ${new Date().toLocaleString()}`,
      `Health Score: ${healthScore}%`,
      ``,
      `## 1. Final TTS Priority Order (Strict 3 Engines)`,
      `1. PRIMARY: ${primaryEngine?.name} (${primaryEngine?.model}) — Status: ${primaryEngine?.configured ? 'Configured & Ready' : 'Awaiting API Key'}`,
      `2. BACKUP: ${backupEngine?.name} (${backupEngine?.model}) — Status: ${backupEngine?.configured ? 'Configured & Ready' : 'Active'}`,
      `3. FALLBACK: ${fallbackEngine?.name} (${fallbackEngine?.model}) — Status: ${fallbackEngine?.configured ? 'Configured & Ready' : 'Active'}`,
      ``,
      `## 2. TTS Engine Diagnostic Table`,
      `| TTS Engine | Priority | Status | Latency | Voice ID / Name |`,
      `| :--- | :--- | :--- | :--- | :--- |`,
      ...inventory.map((eng) => {
        const testStatus = eng.testResult
          ? eng.testResult.success
            ? 'WORKING (Verified)'
            : `FAILED (${eng.testResult.errorMessage || 'Error'})`
          : eng.configured
          ? 'Configured (Untested)'
          : 'Awaiting Key';
        const lat = eng.testResult?.latencyMs ? `${eng.testResult.latencyMs}ms` : 'N/A';
        return `| ${eng.name} | ${eng.role} | ${testStatus} | ${lat} | ${eng.voiceName} |`;
      }),
      ``,
      `## 3. Fallback & Reliability Verification`,
      `- Automatic Failover Working: ${fallbackResult ? fallbackResult.automaticFallbackWorking : 'Untested'}`,
      `- Robotic Speech Leakage Prevented: ${fallbackResult ? fallbackResult.roboticLeakagePrevented : serverAudit?.policy?.roboticSpeechSynthesisBlocked ?? 'Untested'}`,
      `- Overlapping Playback Prevented: Single-track audio controller`,
      `- Failover Summary: ${fallbackResult?.summary || 'Run Failover Chain Audit to verify live engines.'}`,
    ];

    navigator.clipboard.writeText(lines.join('\n'));
    setCopiedReport(true);
    setTimeout(() => setCopiedReport(false), 2500);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div className="bg-[#0B1026] border border-[#262D4D] text-[#F3F5FF] w-full max-w-5xl max-h-[92vh] rounded-2xl shadow-2xl flex flex-col overflow-hidden">
        {/* Modal Header */}
        <div className="p-4 sm:p-5 border-b border-[#1E2545] bg-[#0E132E] flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-purple-500/20 border border-purple-500/40 flex items-center justify-center text-purple-300 shadow-[0_0_15px_rgba(168,85,247,0.25)]">
              <Volume2 className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-black tracking-wide text-white">
                  ZOYA – COMPLETE TTS SYSTEM DIAGNOSTIC DASHBOARD
                </h2>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                  EXACT 3-ENGINE ORDER
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                कड़ाई से 3 इंजन: 1. ElevenLabs (Primary) → 2. Gemini Flash (Backup) → 3. Gemini Live (Fallback)
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 self-end sm:self-auto">
            <button
              type="button"
              onClick={loadDiagnostics}
              className="px-3 py-1.5 rounded-lg bg-[#1E2545] hover:bg-[#2A3460] text-slate-200 text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>रीफ्रेश</span>
            </button>
            <button
              type="button"
              onClick={handleCopyReport}
              className="px-3 py-1.5 rounded-lg bg-[#8C9BFF]/20 hover:bg-[#8C9BFF]/30 text-[#8C9BFF] border border-[#8C9BFF]/40 text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer"
            >
              {copiedReport ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedReport ? 'कॉपी हो गया ✓' : 'रिपोर्ट कॉपी करें'}</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-lg bg-[#1E2545] hover:bg-rose-500/20 hover:text-rose-400 text-slate-400 transition-colors cursor-pointer"
              aria-label="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Top Summary Metric HUD */}
        <div className="px-4 py-3 bg-[#0A0D22] border-b border-[#1E2545] grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
          <div className="p-2.5 rounded-xl bg-[#141A38] border border-[#222B52]">
            <div className="text-[11px] text-slate-400">कुल मुख्य टीटीएस इंजन (Total Engines)</div>
            <div className="text-lg font-black text-purple-300 mt-0.5 flex items-center gap-1.5">
              <Cpu className="w-4 h-4 text-purple-400" />
              <span>3 Main Engines</span>
            </div>
            <div className="text-[10px] text-slate-500 mt-0.5">Primary · Backup · Fallback</div>
          </div>

          <div className="p-2.5 rounded-xl bg-[#141A38] border border-[#222B52]">
            <div className="text-[11px] text-slate-400">1. प्राथमिक (PRIMARY TTS)</div>
            <div className="text-sm font-bold text-purple-300 mt-0.5 truncate flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5 text-purple-400 shrink-0" />
              <span className="truncate">ElevenLabs TTS</span>
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5 truncate">
              {primaryEngine?.configured ? 'Key & Voice ID Set' : 'Awaiting Settings Key'}
            </div>
          </div>

          <div className="p-2.5 rounded-xl bg-[#141A38] border border-[#222B52]">
            <div className="text-[11px] text-slate-400">2. बैकअप व 3. फॉलबैक</div>
            <div className="text-sm font-bold text-sky-300 mt-0.5 truncate flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-sky-400 shrink-0" />
              <span className="truncate">Gemini Flash → Gemini Live</span>
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5">
              {fallbackResult
                ? fallbackResult.roboticLeakagePrevented
                  ? 'Robotic Block Verified'
                  : 'Robotic Block Unconfirmed'
                : serverAudit?.policy?.roboticSpeechSynthesisBlocked
                ? 'Server Policy Active (Untested)'
                : 'Awaiting Live Test'}
            </div>
          </div>

          <div className="p-2.5 rounded-xl bg-[#141A38] border border-[#222B52]">
            <div className="text-[11px] text-slate-400">सिस्टम हेल्थ स्कोर (Health Score)</div>
            <div className={`text-lg font-black mt-0.5 flex items-center gap-1.5 ${
              testedCount === 0
                ? 'text-slate-300'
                : healthScore >= 80
                ? 'text-emerald-400'
                : healthScore >= 40
                ? 'text-amber-400'
                : 'text-rose-400'
            }`}>
              <span>{testedCount === 0 ? '—' : `${healthScore}%`}</span>
              <span className={`text-[10px] font-normal px-1.5 py-0.5 rounded border ${
                testedCount === 0
                  ? 'text-slate-300 bg-slate-500/10 border-slate-500/30'
                  : healthScore >= 80
                  ? 'text-emerald-300 bg-emerald-500/10 border-emerald-500/30'
                  : healthScore >= 40
                  ? 'text-amber-300 bg-amber-500/10 border-amber-500/30'
                  : 'text-rose-300 bg-rose-500/10 border-rose-500/30'
              }`}>
                {testedCount === 0
                  ? 'अपरिक्षित'
                  : workingCount === testedCount
                  ? 'ऑप्टीमल'
                  : workingCount > 0
                  ? 'आंशिक'
                  : 'विफल'}
              </span>
            </div>
            <div className="text-[10px] text-slate-500 mt-0.5">
              {testedCount > 0 ? `${workingCount}/${testedCount} इंजन पास` : 'लाइव टेस्ट चलाएँ'}
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="px-4 pt-2.5 border-b border-[#1E2545] bg-[#0E132E] flex items-center gap-2 overflow-x-auto text-xs">
          <button
            type="button"
            onClick={() => setActiveTab('inventory')}
            className={`px-3.5 py-2 font-bold rounded-t-lg transition-all flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
              activeTab === 'inventory'
                ? 'bg-[#171C3D] text-[#8C9BFF] border-t-2 border-[#8C9BFF]'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>1. टीटीएस इन्वेंटरी (3 Engines)</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('testing')}
            className={`px-3.5 py-2 font-bold rounded-t-lg transition-all flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
              activeTab === 'testing'
                ? 'bg-[#171C3D] text-[#8C9BFF] border-t-2 border-[#8C9BFF]'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Play className="w-3.5 h-3.5" />
            <span>2. स्वतंत्र टेस्ट (Test Voice)</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('fallback')}
            className={`px-3.5 py-2 font-bold rounded-t-lg transition-all flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
              activeTab === 'fallback'
                ? 'bg-[#171C3D] text-[#8C9BFF] border-t-2 border-[#8C9BFF]'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Radio className="w-3.5 h-3.5" />
            <span>3. फॉलबैक चेन सत्यापन (Failover Order)</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('report')}
            className={`px-3.5 py-2 font-bold rounded-t-lg transition-all flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
              activeTab === 'report'
                ? 'bg-[#171C3D] text-[#8C9BFF] border-t-2 border-[#8C9BFF]'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>4. फाइनल डायग्नोस्टिक रिपोर्ट</span>
          </button>
        </div>

        {/* Modal Scrollable Content Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6 bg-[#0B1026]">
          {/* TAB 1: SYSTEM INVENTORY & CONFIGURATION DETAILS */}
          {activeTab === 'inventory' && (
            <div className="space-y-5 animate-fadeIn">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <Database className="w-4 h-4 text-[#8C9BFF]" />
                    <span>3 मुख्य टीटीएस इंजन और उनकी कॉन्फ़िगरेशन विवरण</span>
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    ऑडियो कैश एक सहायक बफ़र है (इंजन नहीं)। रोबोटिक आवाज़ें सामान्य बातचीत से पूरी तरह हटाई गई हैं।
                  </p>
                </div>
                <span className="text-[11px] font-mono px-2.5 py-1 rounded bg-[#171C3D] text-slate-300 border border-[#262D4D]">
                  सख्त प्राथमिकता क्रम: <strong className="text-white">1 → 2 → 3</strong>
                </span>
              </div>

              {/* Execution Chain Visual Pipeline */}
              <div className="p-4 rounded-xl bg-[#101533] border border-[#222A50] space-y-3">
                <div className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                  <Layers className="w-4 h-4 text-purple-400" />
                  <span>सख्त निष्पादन व फॉलबैक प्राथमिकता (Strict TTS Execution Priority)</span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-2.5 text-xs">
                  <div className="p-3 rounded-lg bg-purple-950/40 border border-purple-500/50 text-purple-200">
                    <div className="text-[10px] font-bold text-purple-400">1. PRIMARY TTS</div>
                    <div className="font-bold mt-0.5 text-white">ElevenLabs TTS</div>
                    <div className="text-[10px] text-slate-300 mt-1">
                      Model: eleven_turbo_v2_5 · Settings Voice ID
                    </div>
                  </div>

                  <div className="p-3 rounded-lg bg-sky-950/40 border border-sky-500/50 text-sky-200">
                    <div className="text-[10px] font-bold text-sky-400">2. BACKUP TTS</div>
                    <div className="font-bold mt-0.5 text-white">Google Gemini Flash TTS</div>
                    <div className="text-[10px] text-slate-300 mt-1">
                      Model: gemini-3.8-flash-lite-tts · Auto Failover
                    </div>
                  </div>

                  <div className="p-3 rounded-lg bg-indigo-950/40 border border-indigo-500/50 text-indigo-200">
                    <div className="text-[10px] font-bold text-indigo-400">3. FALLBACK TTS</div>
                    <div className="font-bold mt-0.5 text-white">Google Gemini Live API</div>
                    <div className="text-[10px] text-slate-300 mt-1">
                      Model: gemini-3.8-live · WebSocket Stream
                    </div>
                  </div>

                  <div className="p-3 rounded-lg bg-emerald-950/40 border border-emerald-500/50 text-emerald-200">
                    <div className="text-[10px] font-bold text-emerald-400">ANTI-ROBOTIC POLICY</div>
                    <div className="font-bold mt-0.5 text-white">Zero Robotic Degradation</div>
                    <div className="text-[10px] text-slate-300 mt-1">
                      तीनों विफल होने पर सौम्य मौन (No robotic speech)
                    </div>
                  </div>
                </div>
              </div>

              {/* Cards Grid for Each of the 3 Engines */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5">
                {inventory.map((item, idx) => {
                  const isPrimary = item.role === 'PRIMARY';
                  const isBackup = item.role === 'BACKUP';
                  const isFallback = item.role === 'FALLBACK';

                  return (
                    <div
                      key={item.id}
                      className={`p-4 rounded-xl border flex flex-col justify-between transition-all ${
                        isPrimary
                          ? 'bg-[#15122E] border-purple-500/50 shadow-[0_0_15px_rgba(168,85,247,0.15)]'
                          : isBackup
                          ? 'bg-[#0E172E] border-sky-500/40'
                          : 'bg-[#111633] border-indigo-500/40'
                      }`}
                    >
                      <div>
                        <div className="flex items-start justify-between gap-2">
                          <div>
                            <span className="text-[10px] font-mono px-2 py-0.5 rounded font-bold bg-[#1F274D] text-slate-300">
                              ORDER #{idx + 1}
                            </span>
                            <h4 className="font-bold text-white text-sm mt-1">{item.name}</h4>
                            <div className="text-[11px] font-mono text-slate-400 mt-0.5">
                              {item.provider} · <strong className="text-slate-200">{item.model}</strong>
                            </div>
                          </div>

                          <span
                            className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                              isPrimary
                                ? 'bg-purple-500/20 text-purple-300 border border-purple-500/40'
                                : isBackup
                                ? 'bg-sky-500/20 text-sky-300 border border-sky-500/40'
                                : 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/40'
                            }`}
                          >
                            {item.role}
                          </span>
                        </div>

                        {/* Engine Properties Grid */}
                        <div className="space-y-1.5 mt-3 p-2.5 rounded-lg bg-[#080B1E] text-[11px] border border-[#1A2142] font-mono">
                          <div className="flex justify-between">
                            <span className="text-slate-500">प्रकार:</span>
                            <span className="text-slate-300">{item.engineType}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-slate-500">वॉयस:</span>
                            <span className="text-slate-300 truncate max-w-[150px]">{item.voiceName}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-slate-500">एपीआई कुंजी:</span>
                            <span className="text-slate-300 flex items-center gap-1">
                              <Key className="w-3 h-3 text-[#8C9BFF]" />
                              <span>{item.apiKeyMasked}</span>
                            </span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-slate-500">कॉन्फ़िगरेशन:</span>
                            <span className={item.configured ? 'text-emerald-400' : 'text-amber-400'}>
                              {item.configured ? 'Ready ✓' : 'Awaiting Settings'}
                            </span>
                          </div>
                        </div>

                        <p className="text-[11px] text-slate-400 mt-2.5 leading-relaxed">{item.description}</p>
                      </div>

                      <div className="mt-4 pt-3 border-t border-[#1C2344] flex items-center justify-between">
                        <div className="text-[11px] font-mono text-slate-400">
                          {item.testResult ? (
                            item.testResult.success ? (
                              <span className="text-emerald-400 flex items-center gap-1">
                                <CheckCircle2 className="w-3.5 h-3.5" />
                                <span>सत्यापित ({item.testResult.latencyMs}ms)</span>
                              </span>
                            ) : (
                              <span className="text-rose-400 flex items-center gap-1">
                                <XCircle className="w-3.5 h-3.5" />
                                <span>विफल</span>
                              </span>
                            )
                          ) : (
                            <span className="text-slate-500">अपरिक्षित</span>
                          )}
                        </div>

                        <button
                          type="button"
                          onClick={() => handleTestEngine(item)}
                          disabled={testingEngineId === item.id}
                          className="px-3 py-1.5 rounded-lg bg-[#8C9BFF]/15 hover:bg-[#8C9BFF]/25 text-[#8C9BFF] border border-[#8C9BFF]/30 text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer disabled:opacity-50"
                        >
                          {testingEngineId === item.id ? (
                            <>
                              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                              <span>जांच...</span>
                            </>
                          ) : isPlayingAudio === item.id ? (
                            <>
                              <Square className="w-3.5 h-3.5 text-rose-400" />
                              <span>रोकें</span>
                            </>
                          ) : (
                            <>
                              <Play className="w-3.5 h-3.5" />
                              <span>Test Voice</span>
                            </>
                          )}
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 2: INDIVIDUAL TTS TESTING (TEST VOICE BUTTONS) */}
          {activeTab === 'testing' && (
            <div className="space-y-5 animate-fadeIn">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <Play className="w-4 h-4 text-[#8C9BFF]" />
                    <span>प्रत्येक इंजन की स्वतंत्र ऑडियो टेस्टिंग (Independent Voice Verification)</span>
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    तीनों इंजनों को व्यक्तिगत रूप से चलाकर लेटेंसी, ऑडियो जेनरेशन व प्लेबैक की पुष्टि करें।
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={stopActiveAudio}
                    className="px-3 py-1.5 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/40 text-xs font-bold flex items-center gap-1 cursor-pointer"
                  >
                    <Square className="w-3.5 h-3.5" />
                    <span>म्यूट / स्टॉप</span>
                  </button>
                  <button
                    type="button"
                    onClick={handleRunAllEngineTests}
                    disabled={testingEngineId !== null}
                    className="px-3.5 py-1.5 rounded-lg bg-[#8C9BFF] hover:bg-[#7888FF] text-[#0B1030] text-xs font-black flex items-center gap-1.5 shadow-md cursor-pointer disabled:opacity-50"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${testingEngineId ? 'animate-spin' : ''}`} />
                    <span>तीनों इंजनों को टेस्ट करें</span>
                  </button>
                </div>
              </div>

              {/* Test Sentence Input Box */}
              <div className="p-3.5 rounded-xl bg-[#101533] border border-[#222A50] space-y-2">
                <label className="text-xs font-bold text-slate-300 flex items-center justify-between">
                  <span>परीक्षण वाक्य (Test Utterance Text):</span>
                  <span className="text-[11px] text-slate-500 font-normal">हिन्दी / Hinglish / English</span>
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={testPhrase}
                    onChange={(e) => setTestPhrase(e.target.value)}
                    className="flex-1 bg-[#0A0D22] border border-[#262D4D] rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-[#8C9BFF]"
                    placeholder="कोई भी परीक्षण वाक्य दर्ज करें..."
                  />
                  <button
                    type="button"
                    onClick={() => setTestPhrase('नमस्ते! मैं ज़ोया हूँ, आपकी एआई साथी।')}
                    className="px-3 py-2 rounded-lg bg-[#171C3D] hover:bg-[#202752] text-slate-300 text-xs font-semibold whitespace-nowrap cursor-pointer"
                  >
                    डिफ़ॉल्ट
                  </button>
                </div>
              </div>

              {/* Test Cards for each engine */}
              <div className="space-y-3">
                {inventory.map((item, idx) => {
                  const res = item.testResult;
                  const isTesting = testingEngineId === item.id;
                  const isPlaying = isPlayingAudio === item.id;

                  return (
                    <div
                      key={item.id}
                      className={`p-4 rounded-xl border transition-all ${
                        res?.success
                          ? 'bg-[#0E172E] border-emerald-500/40'
                          : res && !res.success
                          ? 'bg-[#181124] border-rose-500/40'
                          : 'bg-[#101533] border-[#1F274D]'
                      }`}
                    >
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                        <div className="flex items-center gap-3">
                          <div
                            className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold text-xs ${
                              res?.success
                                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                                : res && !res.success
                                ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                                : 'bg-[#1E2545] text-slate-300'
                            }`}
                          >
                            {idx + 1}
                          </div>

                          <div>
                            <div className="flex items-center gap-2">
                              <h4 className="font-bold text-white text-xs sm:text-sm">{item.name}</h4>
                              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#171C3D] text-[#8C9BFF] border border-[#2D3766]">
                                {item.role}
                              </span>
                            </div>
                            <div className="text-[11px] text-slate-400 mt-0.5">
                              मॉडल: <span className="font-mono text-slate-300">{item.model}</span> · एंडपॉइंट:{' '}
                              <span className="font-mono text-slate-400">{item.endpoint}</span>
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-2 self-end sm:self-auto">
                          <button
                            type="button"
                            onClick={() => handleTestEngine(item)}
                            disabled={isTesting}
                            className={`px-3.5 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-all ${
                              isPlaying
                                ? 'bg-amber-500 text-black shadow-[0_0_15px_rgba(245,158,11,0.5)]'
                                : 'bg-[#8C9BFF] hover:bg-[#7888FF] text-[#0B1030]'
                            }`}
                          >
                            {isTesting ? (
                              <>
                                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                                <span>ऑडियो बन रहा है...</span>
                              </>
                            ) : isPlaying ? (
                              <>
                                <Square className="w-3.5 h-3.5" />
                                <span>चल रहा है (रोकें)</span>
                              </>
                            ) : (
                              <>
                                <Play className="w-3.5 h-3.5" />
                                <span>Test Voice</span>
                              </>
                            )}
                          </button>
                        </div>
                      </div>

                      {res && (
                        <div
                          className={`mt-3 p-3 rounded-lg border font-mono text-xs space-y-1.5 ${
                            res.success
                              ? 'bg-emerald-950/30 border-emerald-800/60 text-emerald-300'
                              : 'bg-rose-950/30 border-rose-900/60 text-rose-300'
                          }`}
                        >
                          <div className="flex flex-wrap items-center justify-between gap-2">
                            <div className="flex items-center gap-2">
                              {res.success ? (
                                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                              ) : (
                                <XCircle className="w-4 h-4 text-rose-400 shrink-0" />
                              )}
                              <span className="font-bold">
                                {res.success ? 'परीक्षण सफल (Test PASSED)' : 'परीक्षण असफल (Test FAILED)'}
                              </span>
                            </div>
                            <div className="flex items-center gap-3 text-[11px] text-slate-300">
                              <span>
                                ऑडियो: <strong className={res.audioGenerated ? 'text-emerald-400' : 'text-rose-400'}>{res.audioGenerated ? 'हाँ (Yes)' : 'नहीं (No)'}</strong>
                              </span>
                              <span>
                                प्लेबैक: <strong className={res.playbackSucceeded ? 'text-emerald-400' : 'text-rose-400'}>{res.playbackSucceeded ? 'सफल' : 'असफल'}</strong>
                              </span>
                              <span>
                                लेटेंसी: <strong className="text-sky-300">{res.latencyMs}ms</strong>
                              </span>
                            </div>
                          </div>

                          {res.details && (
                            <div className="text-[11px] text-slate-300 pt-1 border-t border-slate-800">
                              विवरण: {res.details}
                            </div>
                          )}

                          {res.errorMessage && (
                            <div className="text-[11px] text-rose-300 pt-1 border-t border-rose-900/50">
                              त्रुटि: {res.errorMessage}
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 3: PRIMARY & FALLBACK EXECUTION FLOW VERIFICATION */}
          {activeTab === 'fallback' && (
            <div className="space-y-5 animate-fadeIn">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <Radio className="w-4 h-4 text-sky-400" />
                    <span>सख्त फॉलबैक निष्पादन क्रम (ElevenLabs → Gemini Flash → Gemini Live)</span>
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    जाँचें कि जब ElevenLabs विफल हो तो Gemini Flash स्वतः संभाल लेता है, और Gemini Flash विफल होने पर Gemini Live सक्रिय होता है।
                  </p>
                </div>

                <button
                  type="button"
                  onClick={handleRunFallbackChain}
                  disabled={isAuditingFallbackChain}
                  className="px-4 py-2 rounded-lg bg-sky-500 hover:bg-sky-400 text-[#0B1030] text-xs font-black flex items-center gap-2 shadow-lg cursor-pointer disabled:opacity-50"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isAuditingFallbackChain ? 'animate-spin' : ''}`} />
                  <span>{isAuditingFallbackChain ? 'ऑडिट चल रहा है...' : 'Run Full Failover Chain Audit'}</span>
                </button>
              </div>

              {/* Execution Flow Diagram */}
              <div className="p-4 rounded-xl bg-[#101533] border border-[#222A50] space-y-4">
                <div className="space-y-3">
                  {/* Step 1 */}
                  <div className="p-3.5 rounded-lg bg-[#0E132E] border border-purple-500/40 flex items-center justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <span className="w-6 h-6 rounded-full bg-purple-500/20 text-purple-300 font-mono text-xs flex items-center justify-center font-bold">1</span>
                      <div>
                        <div className="text-xs font-bold text-white">स्टेप 1: PRIMARY — ElevenLabs TTS</div>
                        <div className="text-[11px] text-slate-400">
                          {primaryEngine?.name} ({primaryEngine?.model}) · 7.5s टाइमआउट गार्ड
                        </div>
                      </div>
                    </div>
                    <div>
                      {fallbackResult?.step1Primary ? (
                        <span
                          className={`text-[10px] font-bold px-2.5 py-1 rounded-full ${
                            fallbackResult.step1Primary.status === 'pass'
                              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                              : 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                          }`}
                        >
                          {fallbackResult.step1Primary.status === 'pass'
                            ? `सफल (${fallbackResult.step1Primary.latencyMs}ms)`
                            : 'असफल / Failover Active'}
                        </span>
                      ) : (
                        <span className="text-[10px] text-slate-500 font-mono">अपेक्षित (Ready)</span>
                      )}
                    </div>
                  </div>

                  <div className="flex justify-center text-slate-500">
                    <ArrowRight className="w-4 h-4 rotate-90" />
                  </div>

                  {/* Step 2 */}
                  <div className="p-3.5 rounded-lg bg-[#0E132E] border border-sky-500/40 flex items-center justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <span className="w-6 h-6 rounded-full bg-sky-500/20 text-sky-300 font-mono text-xs flex items-center justify-center font-bold">2</span>
                      <div>
                        <div className="text-xs font-bold text-white">स्टेप 2: BACKUP — Google Gemini Flash TTS</div>
                        <div className="text-[11px] text-slate-400">
                          {backupEngine?.name} ({backupEngine?.model}) · 7.0s टाइमआउट गार्ड
                        </div>
                      </div>
                    </div>
                    <div>
                      {fallbackResult?.step2Backup ? (
                        <span
                          className={`text-[10px] font-bold px-2.5 py-1 rounded-full ${
                            fallbackResult.step2Backup.status === 'pass'
                              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                              : 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                          }`}
                        >
                          {fallbackResult.step2Backup.status === 'pass'
                            ? `सत्यापित (${fallbackResult.step2Backup.latencyMs}ms)`
                            : 'असफल'}
                        </span>
                      ) : (
                        <span className="text-[10px] text-slate-500 font-mono">अपेक्षित (Ready)</span>
                      )}
                    </div>
                  </div>

                  <div className="flex justify-center text-slate-500">
                    <ArrowRight className="w-4 h-4 rotate-90" />
                  </div>

                  {/* Step 3 */}
                  <div className="p-3.5 rounded-lg bg-[#0E132E] border border-indigo-500/40 flex items-center justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <span className="w-6 h-6 rounded-full bg-indigo-500/20 text-indigo-300 font-mono text-xs flex items-center justify-center font-bold">3</span>
                      <div>
                        <div className="text-xs font-bold text-white">स्टेप 3: FALLBACK — Google Gemini Live API</div>
                        <div className="text-[11px] text-slate-400">
                          {fallbackEngine?.name} ({fallbackEngine?.model}) · WebSocket Real-Time Stream
                        </div>
                      </div>
                    </div>
                    <div>
                      {fallbackResult?.step3Fallback ? (
                        <span
                          className={`text-[10px] font-bold px-2.5 py-1 rounded-full ${
                            fallbackResult.step3Fallback.status === 'pass'
                              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                              : 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                          }`}
                        >
                          {fallbackResult.step3Fallback.status === 'pass'
                            ? `सत्यापित (${fallbackResult.step3Fallback.latencyMs}ms)`
                            : 'असफल'}
                        </span>
                      ) : (
                        <span className="text-[10px] text-slate-500 font-mono">अपेक्षित (Ready)</span>
                      )}
                    </div>
                  </div>

                  <div className="flex justify-center text-slate-500">
                    <ArrowRight className="w-4 h-4 rotate-90" />
                  </div>

                  {/* Step 4: Strict Policy */}
                  <div className={`p-3.5 rounded-lg border flex items-center justify-between gap-3 ${
                    fallbackResult?.roboticLeakagePrevented || serverAudit?.policy?.roboticSpeechSynthesisBlocked
                      ? 'bg-emerald-950/20 border-emerald-500/30'
                      : 'bg-slate-900/50 border-slate-700/50'
                  }`}>
                    <div className="flex items-center gap-3">
                      <ShieldCheck className={`w-5 h-5 ${
                        fallbackResult?.roboticLeakagePrevented || serverAudit?.policy?.roboticSpeechSynthesisBlocked
                          ? 'text-emerald-400'
                          : 'text-slate-400'
                      }`} />
                      <div>
                        <div className="text-xs font-bold text-slate-100">
                          सुरक्षा गार्ड: रोबोटिक वॉयस ब्लॉकिंग नीति
                        </div>
                        <div className="text-[11px] text-slate-400">
                          तीनों न्यूरल इंजनों के विफल होने पर सिस्टम ब्राउज़र speechSynthesis के बजाय जेमिनी इंजन रीट्राई या मौन त्रुटि दिखाता है।
                        </div>
                      </div>
                    </div>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded border ${
                      fallbackResult
                        ? fallbackResult.roboticLeakagePrevented
                          ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                          : 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                        : 'bg-slate-800 text-slate-300 border-slate-700'
                    }`}>
                      {fallbackResult
                        ? fallbackResult.roboticLeakagePrevented
                          ? 'सत्यापित ✓'
                          : 'असत्यापित'
                        : 'अपरिक्षित'}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: FINAL DIAGNOSTIC REPORT TABLE */}
          {activeTab === 'report' && (
            <div className="space-y-5 animate-fadeIn">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <FileText className="w-4 h-4 text-[#8C9BFF]" />
                    <span>पूर्ण 3-इंजन टीटीएस डायग्नोस्टिक रिपोर्ट (Final Master Audit Table)</span>
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    प्रत्येक टीटीएस इंजन, उसकी प्राथमिकता (Priority), व कार्यकारी स्थिति (Status) का विवरण
                  </p>
                </div>

                <button
                  type="button"
                  onClick={handleCopyReport}
                  className="px-3.5 py-1.5 rounded-lg bg-[#8C9BFF]/20 hover:bg-[#8C9BFF]/30 text-[#8C9BFF] border border-[#8C9BFF]/40 text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                >
                  {copiedReport ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedReport ? 'कॉपी हो गया ✓' : 'टेक्स्ट रिपोर्ट कॉपी करें'}</span>
                </button>
              </div>

              {/* Master Diagnostic Table */}
              <div className="overflow-x-auto rounded-xl border border-[#222A50] bg-[#101533]">
                <table className="w-full text-left text-xs text-slate-300">
                  <thead className="bg-[#171E42] text-[11px] uppercase tracking-wider text-slate-400 border-b border-[#222A50]">
                    <tr>
                      <th className="p-3">TTS Engine</th>
                      <th className="p-3">Priority</th>
                      <th className="p-3">API Configuration</th>
                      <th className="p-3">Voice ID / Voice Name</th>
                      <th className="p-3">Runtime Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#1B2245] font-mono">
                    {inventory.map((eng) => {
                      const isWorking = eng.testResult?.success;
                      const hasTested = Boolean(eng.testResult);

                      return (
                        <tr key={eng.id} className="hover:bg-[#141B3E] transition-colors">
                          <td className="p-3 font-sans">
                            <div className="font-bold text-white text-xs">{eng.name}</div>
                            <div className="text-[10px] text-slate-400 font-mono mt-0.5">{eng.model}</div>
                          </td>
                          <td className="p-3">
                            <span
                              className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                                eng.role === 'PRIMARY'
                                  ? 'bg-purple-500/20 text-purple-300 border border-purple-500/40'
                                  : eng.role === 'BACKUP'
                                  ? 'bg-sky-500/20 text-sky-300 border border-sky-500/40'
                                  : 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/40'
                              }`}
                            >
                              {eng.role}
                            </span>
                          </td>
                          <td className="p-3 text-[11px]">{eng.apiKeyMasked}</td>
                          <td className="p-3 text-[11px]">{eng.voiceName}</td>
                          <td className="p-3">
                            {hasTested ? (
                              isWorking ? (
                                <span className="text-emerald-400 font-bold flex items-center gap-1 text-[11px]">
                                  <CheckCircle2 className="w-3.5 h-3.5" />
                                  <span>WORKING ({eng.testResult?.latencyMs}ms)</span>
                                </span>
                              ) : (
                                <span
                                  className="text-rose-400 font-bold flex items-center gap-1 text-[11px]"
                                  title={eng.testResult?.errorMessage}
                                >
                                  <XCircle className="w-3.5 h-3.5" />
                                  <span>FAILED</span>
                                </span>
                              )
                            ) : (
                              <span className="text-slate-500 text-[11px]">Untested</span>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>

              {/* Master Audit Findings */}
              <div className="p-4 rounded-xl bg-[#101533] border border-[#222A50] space-y-3">
                <div className="text-xs font-bold text-white flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  <span>ऑडिट निष्कर्ष व सिस्टम स्वास्थ्य रिपोर्ट (Audit Findings)</span>
                </div>

                <div className="space-y-2 text-xs text-slate-300 leading-relaxed">
                  <p>
                    • <strong>कुल मुख्य टीटीएस इंजन:</strong> <strong>3 इंजन</strong> (1. ElevenLabs TTS, 2. Google Gemini Flash TTS, 3. Google Gemini Live API)।
                  </p>
                  <p>
                    • <strong>प्राथमिक इंजन (PRIMARY):</strong> ElevenLabs TTS Settings में सहेजी गई Voice ID (e.g. Rachel) और API Key का उपयोग करता है।
                  </p>
                  <p>
                    • <strong>बैकअप इंजन (BACKUP):</strong> Google Gemini Flash TTS (gemini-3.8-flash-lite-tts) ElevenLabs के विफल होने पर स्वतः कार्यभार लेता है।
                  </p>
                  <p>
                    • <strong>फॉलबैक इंजन (FALLBACK):</strong> Google Gemini Live API (gemini-3.8-live) केवल दोनों प्राथमिक इंजनों के विफल होने पर ही सक्रिय होता है।
                  </p>
                  <p>
                    • <strong>रोबोटिक आवाज़ पूर्ण निष्कासन:</strong> किसी भी परिस्थिति में रोबोटिक ब्राउज़र या एंड्रॉयड सिस्टम TTS का उपयोग नहीं होता।
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-3.5 sm:p-4 border-t border-[#1E2545] bg-[#0E132E] flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
          <div className="text-slate-400 flex items-center gap-2">
            <Clock className="w-3.5 h-3.5 text-slate-500" />
            <span>लाइव डायग्नोस्टिक सत्र: <strong>{new Date().toLocaleTimeString()}</strong></span>
          </div>

          <div className="flex items-center gap-2 self-end sm:self-auto">
            <button
              type="button"
              onClick={handleRunAllEngineTests}
              className="px-3.5 py-1.5 rounded-lg bg-[#1E2545] hover:bg-[#2A3460] text-slate-200 text-xs font-semibold cursor-pointer transition-colors"
            >
              तीनों इंजन टेस्ट करें
            </button>
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-1.5 rounded-lg bg-[#8C9BFF] hover:bg-[#7888FF] text-[#0B1030] text-xs font-black cursor-pointer shadow-md transition-colors"
            >
              बंद करें (Close)
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
