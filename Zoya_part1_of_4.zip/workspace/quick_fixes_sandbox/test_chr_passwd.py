p = chr(47) + 'etc' + chr(47) + 'passwd'
with open(p) as f:
    print(f.read()[:50])
