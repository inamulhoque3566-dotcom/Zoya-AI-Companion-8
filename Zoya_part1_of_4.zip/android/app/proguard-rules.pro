# ProGuard / R8 Rules for Zoya AI Assistant

# Keep Accessibility Service & Components
-keep class com.openclaw.assistant.bridge.accessibility.** { *; }
-keepclassmembers class com.openclaw.assistant.bridge.accessibility.** { *; }

# Keep Android JavaScript Bridge interfaces
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-keep class com.openclaw.assistant.bridge.AndroidBridge { *; }
-keep class com.openclaw.assistant.service.** { *; }

# Keep models and serialization
-keepattributes *Annotation*, InnerClasses, EnclosingMethod, Signature
-keepclassmembers class * implements java.io.Serializable { *; }

# Keep OpenWakeWord & ONNX Runtime JNI Native bindings
-keep class com.openwakeword.** { *; }
-keep class ai.onnxruntime.** { *; }
