# Professional PDF Generator using ReportLab in Zoya Python Studio
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
import datetime

print("== Zoya PDF Generation Service ==")

pdf_filename = "zoya_enterprise_invoice_2026.pdf"
doc = SimpleDocTemplate(pdf_filename, pagesize=letter, rightMargin=40, leftMargin=40, topMargin=40, bottomMargin=40)
story = []

styles = getSampleStyleSheet()
title_style = ParagraphStyle(
    'TitleStyle',
    parent=styles['Heading1'],
    fontSize=22,
    leading=26,
    textColor=colors.HexColor("#0f172a"),
    fontName="Helvetica-Bold"
)
subtitle_style = ParagraphStyle(
    'SubTitleStyle',
    parent=styles['Normal'],
    fontSize=10,
    textColor=colors.HexColor("#64748b")
)

story.append(Paragraph("ZOYA AI ENTERPRISE INVOICE", title_style))
story.append(Paragraph(f"Generated on: {datetime.datetime.now().strftime('%B %d, %Y - %H:%M:%S UTC')}", subtitle_style))
story.append(Spacer(1, 15))

# Invoice metadata table
client_info = [
    ["Billed To:", "OpenClaw Systems Corp", "Invoice No:", "INV-2026-9481"],
    ["Project:", "Autonomous Android Assistant", "Due Date:", "Net 30 Days"],
    ["Currency:", "USD ($)", "Status:", "COMPLETED / PAID"]
]
t_meta = Table(client_info, colWidths=[1.2*inch, 2.5*inch, 1.2*inch, 1.8*inch])
t_meta.setStyle(TableStyle([
    ('TEXTCOLOR', (0,0), (-1,-1), colors.HexColor("#334155")),
    ('FONTNAME', (0,0), (-1,-1), 'Helvetica'),
    ('FONTSIZE', (0,0), (-1,-1), 9),
    ('BOTTOMPADDING', (0,0), (-1,-1), 4),
]))
story.append(t_meta)
story.append(Spacer(1, 20))

# Line items
items = [
    ["Item Description", "Hours / Qty", "Rate", "Total"],
    ["Zoya Neural Voice Pipeline Integration", "40", "$150.00", "$6,000.00"],
    ["3D Hologram Overlay Foreground Service", "35", "$150.00", "$5,250.00"],
    ["Native Android Accessibility Bridge", "25", "$150.00", "$3,750.00"],
    ["Python Execution Studio & Sandbox", "30", "$150.00", "$4,500.00"],
    ["Subtotal", "", "", "$19,500.00"],
    ["Tax / Maintenance (0%)", "", "", "$0.00"],
    ["Grand Total", "", "", "$19,500.00"]
]

t_items = Table(items, colWidths=[3.5*inch, 1.1*inch, 1.1*inch, 1.3*inch])
t_items.setStyle(TableStyle([
    ('BACKGROUND', (0,0), (-1,0), colors.HexColor("#0f172a")),
    ('TEXTCOLOR', (0,0), (-1,0), colors.white),
    ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
    ('FONTSIZE', (0,0), (-1,0), 10),
    ('ALIGN', (1,0), (-1,-1), 'RIGHT'),
    ('GRID', (0,0), (-1,-4), 0.5, colors.HexColor("#cbd5e1")),
    ('BACKGROUND', (0,-3), (-1,-1), colors.HexColor("#f8fafc")),
    ('FONTNAME', (0,-1), (-1,-1), 'Helvetica-Bold'),
    ('LINEBELOW', (0,-1), (-1,-1), 1.5, colors.HexColor("#0f172a")),
    ('TOPPADDING', (0,0), (-1,-1), 7),
    ('BOTTOMPADDING', (0,0), (-1,-1), 7),
]))
story.append(t_items)
story.append(Spacer(1, 25))

story.append(Paragraph("Thank you for choosing Zoya AI. Automated execution verified by Python 3.10 runtime.", subtitle_style))

doc.build(story)
print(f"✓ PDF report successfully generated: {pdf_filename}")
print("• Ready for direct download and viewing.")
