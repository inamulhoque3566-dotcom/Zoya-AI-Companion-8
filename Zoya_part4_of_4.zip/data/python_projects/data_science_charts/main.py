# Data Science & Matplotlib Visualization in Zoya Python Studio
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg') # Safe headless rendering
import matplotlib.pyplot as plt

print("== Zoya Data Analysis Engine ==")

# 1. Generate statistical dataset with NumPy
np.random.seed(42)
days = 30
dates = pd.date_range("2026-10-01", periods=days)
growth_rate = np.random.normal(1.05, 0.08, days).cumprod() * 1000
traffic = np.random.poisson(lam=1200, size=days)

df = pd.DataFrame({
    "Date": dates,
    "Revenue_USD": np.round(growth_rate, 2),
    "Daily_Visitors": traffic
})

print(f"Generated {len(df)} days of operational metrics:")
print(df.tail(5).to_string(index=False))

print(f"\nSummary Statistics:")
print(f"• Total Revenue: $${df['Revenue_USD'].sum():,.2f}")
print(f"• Mean Daily Revenue: $${df['Revenue_USD'].mean():,.2f}")
print(f"• Max Single-day Traffic: {df['Daily_Visitors'].max():,} visitors")

# 2. Render multi-panel chart
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11, 4.5))

ax1.plot(df["Date"], df["Revenue_USD"], color="#00e5ff", linewidth=2.5, marker='o', markersize=4)
ax1.set_title("Revenue Growth Trajectory (October 2026)", fontsize=11, fontweight="bold")
ax1.set_ylabel("Revenue (USD)")
ax1.grid(True, linestyle="--", alpha=0.3)
ax1.tick_params(axis='x', rotation=35)

ax2.hist(df["Daily_Visitors"], bins=8, color="#8b5cf6", edgecolor="#ffffff", alpha=0.85)
ax2.set_title("Visitor Traffic Distribution", fontsize=11, fontweight="bold")
ax2.set_xlabel("Daily Visitors")
ax2.set_ylabel("Frequency (Days)")
ax2.grid(True, linestyle="--", alpha=0.3)

plt.tight_layout()
chart_path = "sales_analytics_chart.png"
plt.savefig(chart_path, dpi=160, bbox_inches="tight")
print(f"\n✓ Visualization saved successfully to: {chart_path}")
