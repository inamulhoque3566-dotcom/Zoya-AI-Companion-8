---
name: data-science-skill
description: Analytical data science, regression models, and statistical analysis charts.
version: 1.0.0
tags: [datascience, statistics, charts]
---
