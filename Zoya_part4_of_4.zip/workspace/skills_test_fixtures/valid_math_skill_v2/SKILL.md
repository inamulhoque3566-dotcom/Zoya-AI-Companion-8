---
name: valid-math-skill
description: High performance numerical utilities and fast matrix algebra computations v2.
version: 2.0.0
tags: [math, numerical, algebra, fast]
---
# Valid Math Skill v2
Added multiply and power operations.
