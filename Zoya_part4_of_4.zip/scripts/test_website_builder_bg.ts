/**
 * End-to-End Verification Script for Website Builder Upgrade:
 * 1. Understand Before Building (asks for missing purpose, design, content, functionality)
 * 2. Custom Website Generation (builds custom index.html, styles.css, app.js per user instructions)
 * 3. Real 1% -> 100% Progress & Stages (Planning -> Generating -> Building -> Completed)
 * 4. Background Processing & Resume Without Duplicate Jobs
 * 5. Error Handling & Recovery
 */

const BASE_URL = 'http://localhost:3000';

async function sleep(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function runTests() {
  console.log('=== Starting Website Builder Requirement & Custom Generation Verification ===\n');

  // TEST 1: Incomplete voice command ("Hello Zoya, build a website") -> Understand Before Building
  console.log('[TEST 1] Giving incomplete voice command: "Hello Zoya, build a website"...');
  const step1Res = await fetch(`${BASE_URL}/api/website-builder/jobs`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      prompt: 'build a website',
      forceNew: true,
      confirmStart: false,
    }),
  });
  if (!step1Res.ok) {
    throw new Error(`POST /api/website-builder/jobs failed with HTTP ${step1Res.status}`);
  }
  const step1Data = await step1Res.json();
  const initialJob = step1Data.job;

  console.log(` -> Job ID: ${initialJob.jobId}`);
  console.log(` -> Status: ${initialJob.status} (Stage: ${initialJob.stageLabel})`);
  console.log(` -> Needs Clarification: ${step1Data.needsClarification}`);
  console.log(` -> Missing Fields: ${initialJob.requirements.missingFields.join(', ')}`);
  console.log(` -> Zoya Clarifying Question: ${step1Data.clarifyingQuestion}`);

  if (initialJob.status !== 'awaiting_requirements' || !step1Data.needsClarification) {
    throw new Error(
      `Expected status 'awaiting_requirements' and needsClarification=true for incomplete command, got status=${initialJob.status}`
    );
  }
  if (initialJob.requirements.missingFields.length === 0) {
    throw new Error('Expected missingFields to list missing requirement pillars');
  }
  console.log(' [PASS] Zoya checks requirements first and asks for missing details before building.\n');

  // TEST 2: Supplying complete custom requirements (Purpose, Design, Content, Functionality) -> Starts 1% to 100% build
  console.log('[TEST 2] Supplying user custom requirements for "NovaTech Robotics Academy"...');
  const customReply =
    'Build a website for "NovaTech Robotics Academy" to showcase hands-on robotics courses. Use a dark neon cyber design style. Include sections and content for AI Drone Lab, Humanoid Robotics Bootcamp, and Autonomous Rover Workshop. Add an interactive booking form, a cost calculator estimator, and live search filter.';

  const step2Res = await fetch(`${BASE_URL}/api/website-builder/jobs`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      jobId: initialJob.jobId,
      prompt: customReply,
      forceNew: false,
      confirmStart: false,
    }),
  });
  const step2Data = await step2Res.json();
  const buildJob = step2Data.job;

  console.log(` -> Same Job ID Transitioned: ${buildJob.jobId}`);
  console.log(` -> New Status: ${buildJob.status} (${buildJob.progress}% - ${buildJob.stageLabel})`);
  console.log(` -> Extracted Brand: ${buildJob.requirements.brandName}`);
  console.log(` -> Extracted Design: ${buildJob.requirements.designStyle}`);
  console.log(` -> Extracted Functionalities: ${buildJob.requirements.functionalities.join(' | ')}`);

  if (buildJob.jobId !== initialJob.jobId) {
    throw new Error('Expected follow-up requirements to update and start the same awaiting job');
  }
  if (step2Data.needsClarification || buildJob.status === 'awaiting_requirements') {
    throw new Error('Expected complete requirements to start the build immediately');
  }
  console.log(' [PASS] Complete requirements understood and real 1% -> 100% build started.\n');

  // TEST 3: Background continuation & reopening Build a Website mid-build without starting a duplicate
  console.log('[TEST 3] Simulating navigating to home screen & reopening Build a Website mid-build...');
  await sleep(650);

  const reopenMidRes = await fetch(`${BASE_URL}/api/website-builder/jobs`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      prompt: customReply,
      forceNew: false,
    }),
  });
  const reopenMidData = await reopenMidRes.json();
  console.log(
    ` -> Reopened Job ID: ${reopenMidData.job.jobId}, Reused: ${reopenMidData.reused}, Current Progress: ${reopenMidData.job.progress}% (${reopenMidData.job.stageLabel})`
  );

  if (reopenMidData.job.jobId !== buildJob.jobId || !reopenMidData.reused) {
    throw new Error('Reopening Build a Website started a duplicate job instead of resuming active job!');
  }
  console.log(' [PASS] Background build continued and resumed same job without duplicate.\n');

  // TEST 4: Track real progress stages (Planning -> Generating -> Building -> Completed 100%) & verify custom generated website
  console.log('[TEST 4] Tracking real progress counter to 100% and verifying custom website output...');
  const observedStages = new Set<string>([buildJob.stageLabel, reopenMidData.job.stageLabel]);
  const observedProgress: number[] = [buildJob.progress, reopenMidData.job.progress];

  let finalJob = reopenMidData.job;
  const startWait = Date.now();
  while (finalJob.status !== 'completed' && finalJob.status !== 'failed') {
    if (Date.now() - startWait > 15000) {
      throw new Error('Timed out waiting for background website build to reach 100%');
    }
    await sleep(280);
    const pollRes = await fetch(`${BASE_URL}/api/website-builder/jobs/${buildJob.jobId}`);
    const pollData = await pollRes.json();
    finalJob = pollData.job;
    observedStages.add(finalJob.stageLabel);
    if (observedProgress[observedProgress.length - 1] !== finalJob.progress) {
      observedProgress.push(finalJob.progress);
      console.log(
        `   [Progress Tick] ${finalJob.progress}% | Stage: ${finalJob.stageLabel} | ${finalJob.currentStepDetail}`
      );
    }
  }

  if (finalJob.status !== 'completed' || finalJob.progress !== 100) {
    throw new Error(`Expected 100% completed job, got status=${finalJob.status}, progress=${finalJob.progress}`);
  }

  const fileNames = finalJob.files.map((f: any) => f.name);
  console.log(` -> Observed Progress Values: ${observedProgress.join('% -> ')}%`);
  console.log(` -> Observed Stages: ${Array.from(observedStages).join(', ')}`);
  console.log(` -> Generated Files: ${fileNames.join(', ')}`);

  // Verify the generated HTML/CSS/JS is genuinely customized to "NovaTech Robotics Academy" and NOT a generic cafe demo
  const htmlContent: string = finalJob.html;
  const jsFile = finalJob.files.find((f: any) => f.name === 'app.js')?.content || '';
  if (!htmlContent.includes('NovaTech Robotics Academy')) {
    throw new Error('Generated HTML does not contain the user custom brand "NovaTech Robotics Academy"');
  }
  if (!htmlContent.includes('AI Drone Lab') || !htmlContent.includes('Humanoid Robotics Bootcamp')) {
    throw new Error('Generated HTML does not contain the user requested custom content sections');
  }
  if (
    !htmlContent.includes('id="booking-section"') ||
    !htmlContent.includes('id="calculator-section"') ||
    !htmlContent.includes('id="catalog-search"')
  ) {
    throw new Error('Generated HTML does not include the user requested interactive booking, calculator, and search filter modules');
  }
  if (!jsFile.includes('NovaTech Robotics Academy')) {
    throw new Error('Generated app.js is not customized for the user brand');
  }
  console.log(' [PASS] Custom website generated at 100% with user brand, design, content, and working interactive features.\n');

  // TEST 5: Reopening Build a Website after 100% completion returns the completed custom website without duplicate
  console.log('[TEST 5] Reopening Build a Website after 100% completion...');
  const reopenDoneRes = await fetch(`${BASE_URL}/api/website-builder/jobs`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ prompt: customReply, forceNew: false }),
  });
  const reopenDoneData = await reopenDoneRes.json();
  if (
    reopenDoneData.job.jobId !== buildJob.jobId ||
    !reopenDoneData.reused ||
    reopenDoneData.job.progress !== 100
  ) {
    throw new Error('Failed to preserve completed custom website when reopening modal');
  }
  console.log(' [PASS] Completed custom website preserved without starting a duplicate.\n');

  // TEST 6: Error Reporting & Recovery
  console.log('[TEST 6] Testing failure reporting and recovery endpoint...');
  const errStartRes = await fetch(`${BASE_URL}/api/website-builder/jobs`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      prompt: 'Build a custom site __simulate_build_error__',
      forceNew: true,
      confirmStart: true,
    }),
  });
  const errStartData = await errStartRes.json();
  let errJob = errStartData.job;

  const waitErrStart = Date.now();
  while (errJob.status !== 'failed' && errJob.status !== 'completed') {
    if (Date.now() - waitErrStart > 10000) {
      throw new Error('Timed out waiting for simulated error');
    }
    await sleep(250);
    const r = await fetch(`${BASE_URL}/api/website-builder/jobs/${errJob.jobId}`);
    errJob = (await r.json()).job;
  }

  if (errJob.status !== 'failed' || !errJob.error) {
    throw new Error(`Expected job status 'failed' with error message, got ${errJob.status}`);
  }
  console.log(` -> Actual Error Captured at ${errJob.progress}%: "${errJob.error}"`);

  const retryRes = await fetch(`${BASE_URL}/api/website-builder/jobs/${errJob.jobId}/retry`, {
    method: 'POST',
  });
  let recoveredJob = (await retryRes.json()).job;
  const waitRecoverStart = Date.now();
  while (recoveredJob.status !== 'completed' && recoveredJob.status !== 'failed') {
    if (Date.now() - waitRecoverStart > 15000) {
      throw new Error('Timed out waiting for recovered job to complete');
    }
    await sleep(250);
    const r = await fetch(`${BASE_URL}/api/website-builder/jobs/${recoveredJob.jobId}`);
    recoveredJob = (await r.json()).job;
  }

  if (recoveredJob.status !== 'completed' || recoveredJob.progress !== 100) {
    throw new Error(`Expected recovered job to reach 100% completed, got ${recoveredJob.status}`);
  }
  console.log(` -> Recovered Job Completed: ${recoveredJob.progress}% (${recoveredJob.stageLabel})`);
  console.log(' [PASS] Failure reporting and recovery verified.\n');

  console.log('=== ALL 6 WEBSITE BUILDER REQUIREMENT & CUSTOM GENERATION TESTS PASSED ===');
}

runTests().catch((err) => {
  console.error('TEST FAILED:', err);
  process.exit(1);
});
