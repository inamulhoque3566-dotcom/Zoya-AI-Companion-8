const sharp = require('sharp');
const path = require('path');

async function inspectSegmentationSlices() {
  // Let's inspect width of foreground at various heights
  const srcPath = path.join(__dirname, '../src/assets/images/zoya_3d_sweater_glasses_1793764031303.jpg');
  const { data: origRgb, info } = await sharp(srcPath).removeAlpha().raw().toBuffer({ resolveWithObject: true });
  const W = info.width, H = info.height;

  // Let's run the exact same segmentation and inspect rows:
  const rowBg = new Array(H);
  for (let y = 0; y < H; y++) {
    let r = 0, g = 0, b = 0, c = 0;
    for (let x = 0; x < 15; x++) {
      const i1 = (y * W + x) * 3;
      const i2 = (y * W + (W - 1 - x)) * 3;
      r += origRgb[i1] + origRgb[i2];
      g += origRgb[i1 + 1] + origRgb[i2 + 1];
      b += origRgb[i1 + 2] + origRgb[i2 + 2];
      c += 2;
    }
    rowBg[y] = [r / c, g / c, b / c];
  }

  const skirtHem = new Int32Array(W).fill(0);
  for (let x = 185; x <= 585; x++) {
    for (let y = 1100; y <= 1225; y++) {
      const idx = (y * W + x) * 3;
      const r = origRgb[idx], g = origRgb[idx + 1], b = origRgb[idx + 2];
      const isBrown = (r > 35 && g > 25 && b > 20 && r > g && g >= b - 8 && (r - b) >= 6);
      if (isBrown) skirtHem[x] = y;
    }
  }
  for (let x = 190; x <= 580; x++) {
    if (skirtHem[x] === 0 && skirtHem[x - 1] > 0 && skirtHem[x + 1] > 0) {
      skirtHem[x] = Math.round((skirtHem[x - 1] + skirtHem[x + 1]) / 2);
    }
  }

  const isBg = new Uint8Array(W * H);
  for (let y = 0; y < H; y++) {
    const [bgR, bgG, bgB] = rowBg[y];
    for (let x = 0; x < W; x++) {
      const idx = y * W + x;
      const idx3 = idx * 3;
      const r = origRgb[idx3], g = origRgb[idx3 + 1], b = origRgb[idx3 + 2];

      if (y < 28 || y > 1361 || x < 185 || x > 585) {
        isBg[idx] = 1;
        continue;
      }

      const hemY = skirtHem[x];
      const isBelowSkirt = (hemY > 0 && y > hemY) || (hemY === 0 && y >= 1180);
      if (isBelowSkirt) {
        const inLeftLeg = (x >= 324 && x <= 378 && y <= 1361);
        const inRightLeg = (x >= 398 && x <= 456 && y <= 1361);
        const inShoeBase = (y >= 1335 && y <= 1361 && x >= 324 && x <= 458);

        if (!inLeftLeg && !inRightLeg && !inShoeBase) {
          isBg[idx] = 1;
          continue;
        }

        const dist = Math.sqrt((r - bgR) ** 2 + (g - bgG) ** 2 + (b - bgB) ** 2);
        const chroma = Math.max(Math.abs(r - g), Math.abs(r - b), Math.abs(g - b));
        const isShoeDark = (r < 95 && g < 95 && b < 95);
        const isSkin = (r > 120 && g > 90 && b > 80 && (r - g) > 10);
        
        if (isShoeDark || isSkin) {
          isBg[idx] = 0;
        } else if (dist < 18 && chroma <= 4) {
          isBg[idx] = 1;
        } else {
          isBg[idx] = 0;
        }
        continue;
      }

      const dist = Math.sqrt((r - bgR) ** 2 + (g - bgG) ** 2 + (b - bgB) ** 2);
      const chroma = Math.max(Math.abs(r - g), Math.abs(r - b), Math.abs(g - b));
      const warmth = (r - b) + (r - g);

      if (dist < 24 && chroma <= 6 && warmth <= 4) {
        isBg[idx] = 1;
      } else if (dist < 36 && chroma <= 4 && warmth <= 2) {
        isBg[idx] = 1;
      } else {
        isBg[idx] = 0;
      }
    }
  }

  const bgConnected = new Uint8Array(W * H);
  const queue = new Int32Array(W * H);
  let qHead = 0, qTail = 0;

  for (let x = 0; x < W; x++) {
    bgConnected[x] = 1; queue[qTail++] = x;
    const bIdx = (H - 1) * W + x;
    bgConnected[bIdx] = 1; queue[qTail++] = bIdx;
  }
  for (let y = 1; y < H - 1; y++) {
    const lIdx = y * W;
    bgConnected[lIdx] = 1; queue[qTail++] = lIdx;
    const rIdx = y * W + (W - 1);
    bgConnected[rIdx] = 1; queue[qTail++] = rIdx;
  }

  while (qHead < qTail) {
    const curr = queue[qHead++];
    const neighbors = [curr - 1, curr + 1, curr - W, curr + W];
    for (let k = 0; k < 4; k++) {
      const nIdx = neighbors[k];
      const nx = nIdx % W;
      const ny = Math.floor(nIdx / W);
      if (nx >= 0 && nx < W && ny >= 0 && ny < H) {
        if (bgConnected[nIdx] === 0 && isBg[nIdx] === 1) {
          bgConnected[nIdx] = 1;
          queue[qTail++] = nIdx;
        }
      }
    }
  }

  // Check slices across the body:
  console.log('--- Row Spans (Foreground [minX..maxX]) ---');
  for (const y of [50, 100, 180, 250, 350, 450, 550, 700, 900, 1100, 1170, 1220, 1280, 1345, 1360]) {
    let rowMin = -1, rowMax = -1, fgCount = 0;
    for (let x = 0; x < W; x++) {
      if (bgConnected[y * W + x] === 0) {
        if (rowMin === -1) rowMin = x;
        rowMax = x;
        fgCount++;
      }
    }
    console.log(`y=${y}: span=[${rowMin}..${rowMax}] (width=${rowMax - rowMin + 1}, fgCount=${fgCount})`);
  }
}
inspectSegmentationSlices().catch(console.error);
