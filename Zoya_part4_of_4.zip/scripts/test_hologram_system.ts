import {
  hologramManager,
  ALL_22_HOLOGRAM_STYLES,
  ZoyaHologramStyleDefinition,
  ZoyaHologramConfig,
} from '../src/services/zoyaHologramManager';
import fs from 'fs';
import path from 'path';

let passed = 0;
let failed = 0;

function assert(condition: boolean, message: string) {
  if (condition) {
    console.log(`  ✓ ${message}`);
    passed++;
  } else {
    console.error(`  ✗ FAIL: ${message}`);
    failed++;
  }
}

async function runTests() {
  console.log('====================================================');
  console.log('ZOYA 3D FLOATING HOLOGRAPHIC COMPANION TEST SUITE');
  console.log('====================================================\n');

  // Test Suite 1: All 22 Reference Styles Verification
  console.log('Suite 1: 22 Reference Hologram Styles Blueprint');
  assert(
    ALL_22_HOLOGRAM_STYLES.length === 22,
    `Exactly 22 reference hologram styles defined (Actual: ${ALL_22_HOLOGRAM_STYLES.length})`
  );

  let allResAssetsExist = true;
  for (let i = 1; i <= 22; i++) {
    const filename = `holo_ref_${i.toString().padStart(2, '0')}.png`;
    const resPath = path.join(process.cwd(), 'android', 'app', 'src', 'main', 'res', 'drawable-nodpi', filename);
    if (!fs.existsSync(resPath)) {
      console.error(`Missing drawable asset: ${resPath}`);
      allResAssetsExist = false;
    }
  }
  assert(
    allResAssetsExist,
    'All 22 reference images copied into android/app/src/main/res/drawable-nodpi/ as holo_ref_01.png to holo_ref_22.png'
  );

  let allWebAssetsExist = true;
  for (let i = 1; i <= 22; i++) {
    const filename = `holo_ref_${i.toString().padStart(2, '0')}.png`;
    const webPath = path.join(process.cwd(), 'public', 'assets', 'hologram', filename);
    if (!fs.existsSync(webPath)) {
      console.error(`Missing web asset: ${webPath}`);
      allWebAssetsExist = false;
    }
  }
  assert(
    allWebAssetsExist,
    'All 22 reference images mirrored in public/assets/hologram/ for web companion settings audit'
  );

  // Style Specific Checks
  const style01 = ALL_22_HOLOGRAM_STYLES[0];
  assert(
    style01.index === 1 && style01.name === 'Cosmic Flame Vortex' && style01.primaryColor === '#FF007F',
    'Style #01: Cosmic Flame Vortex features magenta-cyan plasma spiral blades'
  );

  const style02 = ALL_22_HOLOGRAM_STYLES[1];
  assert(
    style02.index === 2 && style02.name === 'Imperial Gold Sovereign' && style02.primaryColor === '#FFD700',
    'Style #02: Imperial Gold Sovereign features sovereign gold crown & orbital sun rings'
  );

  const style03 = ALL_22_HOLOGRAM_STYLES[2];
  assert(
    style03.index === 3 && style03.name === 'Prismatic Dual Diamond' && style03.ringStyle === 'prismatic_diamond',
    'Style #03: Prismatic Dual Diamond features 3D twin diamond crystal prism'
  );

  // Test Suite 2: Hologram Manager Configuration & Subscriptions
  console.log('\nSuite 2: Hologram Manager State & Subscriptions');
  const initialConfig = hologramManager.getConfig();
  assert(initialConfig.enabled === true, 'Hologram enabled by default');
  assert(initialConfig.baseSizePx >= 90 && initialConfig.baseSizePx <= 220, `Base size valid (${initialConfig.baseSizePx}px)`);
  assert(initialConfig.speakingEnlargeRatio >= 1.1 && initialConfig.speakingEnlargeRatio <= 1.6, `Speaking enlarge ratio valid (${initialConfig.speakingEnlargeRatio}x)`);

  let receivedConfig: ZoyaHologramConfig | null = null;
  const unsubscribe = hologramManager.subscribe((cfg) => {
    receivedConfig = cfg;
  });

  hologramManager.setStyle('style_02');
  assert(
    hologramManager.getConfig().selectedStyleIndex === 2,
    'Style successfully updated to style_02 (Imperial Gold Sovereign)'
  );
  unsubscribe();

  // Test Suite 3: Dynamic Speaking Enlargement (Phase 5)
  console.log('\nSuite 3: Dynamic Speaking Enlargement & State Scaling');
  const baseSize = 360;
  const enlargeRatio = 1.35;
  hologramManager.updateConfig({ sizePx: baseSize, speakingEnlargeRatio: enlargeRatio });

  const idleScale = 1.0;
  const speakingScale = enlargeRatio;
  assert(
    Math.round(baseSize * idleScale) === 360,
    `Idle size is ${baseSize * idleScale}px`
  );
  assert(
    Math.round(baseSize * speakingScale) === 486,
    `Speaking size automatically enlarges to ${Math.round(baseSize * speakingScale)}px (+35% enlargement)`
  );

  // Test Suite 4: Voice State Broadcast & Bridge Payload (Phase 5)
  console.log('\nSuite 4: Voice State Synchronization');
  hologramManager.notifyVoiceState('idle', 0);
  assert(true, 'Dispatched idle voice state');

  hologramManager.notifyVoiceState('listening', 0.85);
  assert(true, 'Dispatched listening voice state with audioLevel 0.85 (RMS audio reactivity)');

  hologramManager.notifyVoiceState('processing', 0);
  assert(true, 'Dispatched processing voice state (fast counter-rotating rings)');

  hologramManager.notifyVoiceState('speaking', 0.95);
  assert(true, 'Dispatched speaking voice state (smooth scale expansion)');

  hologramManager.notifyVoiceState('error', 0);
  assert(true, 'Dispatched error voice state (amber/red alert boundary)');

  // Test Suite 5: Android Kotlin Service & Manifest Alignment (Phases 2-6)
  console.log('\nSuite 5: Android Manifest & Kotlin Overlay Service Verification');
  const manifestPath = path.join(process.cwd(), 'android', 'app', 'src', 'main', 'AndroidManifest.xml');
  const manifestContent = fs.readFileSync(manifestPath, 'utf-8');
  assert(
    manifestContent.includes('android.permission.SYSTEM_ALERT_WINDOW'),
    'AndroidManifest.xml declares SYSTEM_ALERT_WINDOW'
  );
  assert(
    manifestContent.includes('android.permission.RECORD_AUDIO'),
    'AndroidManifest.xml declares RECORD_AUDIO'
  );
  assert(
    manifestContent.includes('android.permission.FOREGROUND_SERVICE_MICROPHONE'),
    'AndroidManifest.xml declares FOREGROUND_SERVICE_MICROPHONE'
  );
  assert(
    manifestContent.includes('ZoyaHologramOverlayService'),
    'AndroidManifest.xml registers ZoyaHologramOverlayService with microphone type'
  );

  const kotlinServicePath = path.join(
    process.cwd(),
    'android',
    'app',
    'src',
    'main',
    'java',
    'com',
    'openclaw',
    'assistant',
    'service',
    'ZoyaHologramOverlayService.kt'
  );
  assert(fs.existsSync(kotlinServicePath), 'ZoyaHologramOverlayService.kt exists');
  const kotlinContent = fs.readFileSync(kotlinServicePath, 'utf-8');
  assert(
    kotlinContent.includes('TYPE_APPLICATION_OVERLAY') && kotlinContent.includes('HologramCanvasView'),
    'ZoyaHologramOverlayService implements WindowManager TYPE_APPLICATION_OVERLAY with hardware-accelerated HologramCanvasView'
  );
  assert(
    kotlinContent.includes('"ZOYA"') || kotlinContent.includes('drawText("ZOYA"'),
    'ZoyaHologramOverlayService renders centered "ZOYA" wordmark in canvas on all styles'
  );
  assert(
    kotlinContent.includes('drawStyle01_FlameVortex') &&
    kotlinContent.includes('drawStyle02_ImperialGold') &&
    kotlinContent.includes('drawStyle22_CosmicGalaxy'),
    'ZoyaHologramOverlayService contains dedicated native canvas renderers for all 22 reference styles'
  );
  assert(
    kotlinContent.includes('ACTION_SCREEN_OFF') && kotlinContent.includes('pauseAnimation'),
    'ZoyaHologramOverlayService pauses frame animation when screen is off to preserve battery and GPU'
  );

  console.log('\n====================================================');
  console.log(`TEST RESULTS: ${passed} PASSED, ${failed} FAILED`);
  console.log('====================================================');

  if (failed > 0) {
    process.exit(1);
  }
}

runTests().catch((err) => {
  console.error('Test execution error:', err);
  process.exit(1);
}
);
