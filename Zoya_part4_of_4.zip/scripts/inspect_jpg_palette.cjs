const sharp = require('sharp');

async function inspectJpgPalette() {
  const jpg = await sharp('pristine_sources/avatar_midnight_gold_zari_saree.jpg')
    .raw()
    .toBuffer({ resolveWithObject: true });

  const w = jpg.info.width;
  const h = jpg.info.height;

  // Let's sample colors across the background in the JPG:
  // e.g. (x=50, y=50), (x=950, y=50), (x=50, y=1400), (x=950, y=1400)
  const samples = [
    [50, 50], [950, 50], [50, 700], [950, 700], [50, 1400], [950, 1400]
  ];
  console.log('JPG background samples [r, g, b]:');
  for (const [x, y] of samples) {
    const idx = (y * w + x) * 3;
    console.log(`(${x}, ${y}): [${jpg.data[idx]}, ${jpg.data[idx+1]}, ${jpg.data[idx+2]}]`);
  }

  // Now let's inspect the sheer fabric of the saree vs background in the JPG:
  // In the JPG, is the background dark indigo/navy? [2..10, 5..15, 20..35]?
  // In the saree, the saree fabric itself is dark chiffon, but with golden embroidery and drape!
  // And in file_00000000c0d4821189e14bf178224f8d_f1687d5b.png, what was it?
  const png = await sharp('public/assets/aistudio/file_00000000c0d4821189e14bf178224f8d_f1687d5b.png')
    .raw()
    .toBuffer({ resolveWithObject: true });

  // Let's check why there were 338 non-zero border pixels in the PNG:
  console.log('PNG border pixels:');
  for (let x = 0; x < w; x++) {
    const a0 = png.data[x * 4 + 3];
    const aBottom = png.data[((h - 1) * w + x) * 4 + 3];
    if (aBottom > 0) {
      console.log(`Bottom row x=${x}: rgba=(${png.data[((h-1)*w+x)*4]}, ${png.data[((h-1)*w+x)*4+1]}, ${png.data[((h-1)*w+x)*4+2]}, ${aBottom})`);
      break;
    }
  }
}

inspectJpgPalette().catch(console.error);
