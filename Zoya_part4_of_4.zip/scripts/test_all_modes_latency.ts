import http from 'http';

interface ModeTest {
  mode: string;
  name: string;
  query: string;
  language: string;
}

const TESTS: ModeTest[] = [
  { mode: 'girlfriend', name: 'GF Mode', query: 'आज ऑफिस में बहुत काम था, बहुत थक गया हूँ', language: 'hi-IN' },
  { mode: 'love', name: 'Love Mode', query: 'तुम मेरे लिए कितनी ख़ास हो?', language: 'hi-IN' },
  { mode: 'professional', name: 'Professional Mode', query: 'What are the main benefits of cloud computing?', language: 'en-IN' },
  { mode: 'funny', name: 'Funny Mode', query: 'मुझे कोई मजेदार चुटकुला सुनाओ जो हंसा दे', language: 'hi-IN' },
  { mode: 'companion', name: 'Companion Mode', query: 'आज मेरा किसी काम में मन नहीं लग रहा है, क्या करूँ?', language: 'hi-IN' },
  { mode: 'teacher', name: 'Teacher Mode', query: 'फोटोसिंथेसिस क्या होता है, आसान शब्दों में समझाओ', language: 'hi-IN' },
  { mode: 'developer', name: 'Developer Mode', query: 'React me useEffect aur useMemo me kya difference hai?', language: 'hi-IN' },
  { mode: 'hungry', name: 'Hungry Mode', query: 'शाम के नाश्ते में क्या खाना चाहिए?', language: 'hi-IN' },
  { mode: 'nautanki', name: 'Nautanki Mode', query: 'आज मौसम बहुत सुहाना है, कुछ फिल्मी अंदाज में कहो', language: 'hi-IN' },
  { mode: 'custom', name: 'Custom Mode', query: 'टाइम मैनेजमेंट के लिए 2 सबसे अच्छी टिप्स बताओ', language: 'hi-IN' },
];

function streamPost(payload: any): Promise<{ ttft: number; totalTime: number; text: string }> {
  return new Promise((resolve, reject) => {
    const postData = JSON.stringify(payload);
    const t0 = Date.now();
    let ttft: number | null = null;
    let fullText = '';

    const req = http.request(
      'http://localhost:3000/api/chat-stream',
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(postData),
        },
      },
      (res) => {
        let buffer = '';
        res.on('data', (chunk) => {
          buffer += chunk.toString();
          const lines = buffer.split('\n');
          buffer = lines.pop() || '';

          for (const line of lines) {
            const trimmed = line.trim();
            if (!trimmed.startsWith('data:')) continue;
            const dataStr = trimmed.replace(/^data:\s*/, '').trim();
            if (dataStr === '[DONE]') continue;
            try {
              const parsed = JSON.parse(dataStr);
              if (parsed.text) {
                if (ttft === null) {
                  ttft = Date.now() - t0;
                }
                fullText += parsed.text;
              }
            } catch {}
          }
        });

        res.on('end', () => {
          const totalTime = Date.now() - t0;
          resolve({
            ttft: ttft || totalTime,
            totalTime,
            text: fullText.trim(),
          });
        });
      }
    );

    req.on('error', reject);
    req.write(postData);
    req.end();
  });
}

async function runTests() {
  console.log('===============================================================');
  console.log('       ZOYA AI — ALL 10 MODES LATENCY & ACCURACY AUDIT        ');
  console.log('===============================================================\n');

  const results: any[] = [];
  const GENERIC_FILLERS = [
    'haanji boss',
    'main sun rahi hoon',
    'bataiye kya madad',
    'yes boss, i\'m listening',
    'kya hukum hai',
    'kya seva karoon',
    'maine aapki baat samajh li hai',
  ];

  for (const t of TESTS) {
    try {
      const res = await streamPost({
        message: t.query,
        personaMode: t.mode,
        language: t.language,
      });

      const lowerText = res.text.toLowerCase();
      const isFillerOnly = GENERIC_FILLERS.some(f => lowerText === f || (lowerText.startsWith(f) && lowerText.length < 40));
      const hasRealAnswer = res.text.length > 20 && !isFillerOnly;

      results.push({
        Mode: t.name,
        'Response Time (TTFT)': `${res.ttft}ms`,
        'Total Duration': `${res.totalTime}ms`,
        'Has Substantive Answer': hasRealAnswer ? 'YES (PASS)' : 'NO (FAIL)',
        AnswerSnippet: res.text.slice(0, 70) + (res.text.length > 70 ? '...' : ''),
      });

      console.log(`[PASS] ${t.name.padEnd(18)} | TTFT: ${String(res.ttft).padStart(5)}ms | Total: ${String(res.totalTime).padStart(5)}ms | Answer: "${res.text.slice(0, 65)}..."`);
    } catch (err: any) {
      console.error(`[FAIL] ${t.name} errored:`, err.message);
      results.push({
        Mode: t.name,
        'Response Time (TTFT)': 'ERROR',
        'Total Duration': 'ERROR',
        'Has Substantive Answer': 'NO (FAIL)',
        AnswerSnippet: err.message,
      });
    }
  }

  console.log('\n===============================================================');
  console.log('                     FINAL BENCHMARK TABLE                     ');
  console.log('===============================================================');
  console.table(results.map(r => ({
    Mode: r.Mode,
    TTFT: r['Response Time (TTFT)'],
    Total: r['Total Duration'],
    Status: r['Has Substantive Answer'],
    Sample: r.AnswerSnippet,
  })));

  // Test Error Handling on Unintelligible Speech
  console.log('\n--- Testing Error Handling on Unintelligible Input ---');
  const emptyRes = await streamPost({ message: '...', personaMode: 'girlfriend', language: 'hi-IN' });
  console.log('Unintelligible speech ("...") handled with repeat prompt:', `"${emptyRes.text}"`);
}

runTests();
