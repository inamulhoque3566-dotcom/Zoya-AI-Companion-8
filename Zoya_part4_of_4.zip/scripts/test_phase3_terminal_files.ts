/**
 * Phase 3 Automated Verification Test Suite
 * Terminal & Project Files Subsystems
 */
import fs from 'fs';
import path from 'path';
import { terminalManager } from '../src/services/agent/terminalManager';
import { fileManager, generateUnifiedDiff } from '../src/services/agent/fileManager';
import { agentPermissionGuard } from '../src/services/agent/agentPermissionGuard';

interface TestResult {
  num: number;
  name: string;
  expected: string;
  actual: string;
  pass: boolean;
}

const results: TestResult[] = [];

function recordTest(num: number, name: string, expected: string, actual: string, pass: boolean) {
  results.push({ num, name, expected, actual, pass });
  const status = pass ? '\x1b[32mPASS\x1b[0m' : '\x1b[31mFAIL\x1b[0m';
  console.log(`[Test ${num}] ${name}: ${status}`);
  if (!pass) {
    console.log(`   Expected: ${expected}`);
    console.log(`   Actual:   ${actual}`);
  }
}

async function runTests() {
  console.log('====================================================');
  console.log('PHASE 3: TERMINAL & PROJECT FILES SUBSYSTEM TESTS');
  console.log('====================================================\n');

  const workspaceRoot = terminalManager.getWorkspaceRoot();
  console.log(`Using Workspace Root: ${workspaceRoot}\n`);

  // TEST 1: Terminal Real Command Execution
  try {
    const res = await terminalManager.executeCommand('echo "Hello Terminal Subsystem"', {
      bypassPermissionCheck: true
    });
    const pass = res.exitCode === 0 && res.stdout.includes('Hello Terminal Subsystem');
    recordTest(
      1,
      'Terminal executes command and captures stdout',
      'exitCode: 0, stdout containing "Hello Terminal Subsystem"',
      `exitCode: ${res.exitCode}, stdout: "${res.stdout.trim()}"`,
      pass
    );
  } catch (err: any) {
    recordTest(1, 'Terminal executes command and captures stdout', 'exitCode 0', `Error: ${err.message}`, false);
  }

  // TEST 2: Terminal Persistent Directory Navigation
  try {
    const subDirPath = path.join(workspaceRoot, 'test_nav_dir');
    if (!fs.existsSync(subDirPath)) fs.mkdirSync(subDirPath, { recursive: true });

    const navRes = await terminalManager.executeCommand('cd test_nav_dir', { bypassPermissionCheck: true });
    const currentRel = terminalManager.getRelativeCwd();
    const pass = navRes.exitCode === 0 && (currentRel === 'test_nav_dir' || currentRel.endsWith('test_nav_dir'));
    recordTest(
      2,
      'Terminal persistent directory navigation with "cd"',
      'Relative CWD equals "test_nav_dir"',
      `Relative CWD: "${currentRel}" (stdout: ${navRes.stdout})`,
      pass
    );
  } catch (err: any) {
    recordTest(2, 'Terminal persistent directory navigation with "cd"', 'test_nav_dir', `Error: ${err.message}`, false);
  }

  // TEST 3: Terminal Confinement (Blocks Escaping Workspace Root)
  try {
    let escapeFailed = false;
    let actualMsg = '';
    try {
      terminalManager.setCwd('../../../../../etc');
    } catch (err: any) {
      escapeFailed = true;
      actualMsg = err.message;
    }
    const cwdAfter = terminalManager.getCwd();
    const pass = escapeFailed && cwdAfter.startsWith(workspaceRoot);
    recordTest(
      3,
      'Terminal directory navigation blocks escaping workspace root',
      'Threw navigation error and stayed confined inside workspace',
      `Caught: "${actualMsg}", current CWD: ${cwdAfter}`,
      pass
    );
  } catch (err: any) {
    recordTest(3, 'Terminal directory navigation blocks escaping workspace root', 'Navigation error', `Error: ${err.message}`, false);
  } finally {
    // Reset cwd back to workspace root
    terminalManager.setCwd('.');
  }

  // TEST 4: Terminal Command Error & Stderr Capture
  try {
    const errRes = await terminalManager.executeCommand('nonexistent_command_xyz_404', {
      bypassPermissionCheck: true
    });
    const pass = errRes.exitCode !== 0 && (errRes.stderr.includes('not found') || errRes.stderr.includes('nonexistent_command_xyz_404'));
    recordTest(
      4,
      'Terminal captures non-zero exit code and stderr on failure',
      'exitCode != 0 with command not found in stderr',
      `exitCode: ${errRes.exitCode}, stderr: "${errRes.stderr.trim()}"`,
      pass
    );
  } catch (err: any) {
    recordTest(4, 'Terminal captures non-zero exit code and stderr on failure', 'exitCode != 0', `Error: ${err.message}`, false);
  }

  // TEST 5: Terminal Timeout Handling
  try {
    const startT = Date.now();
    const timeoutRes = await terminalManager.executeCommand('sleep 5', {
      bypassPermissionCheck: true,
      timeoutMs: 800
    });
    const duration = Date.now() - startT;
    const pass = timeoutRes.exitCode === 124 && timeoutRes.stderr.includes('COMMAND TIMEOUT');
    recordTest(
      5,
      'Terminal enforces execution timeout (800ms limit)',
      'exitCode 124 and COMMAND TIMEOUT message',
      `exitCode: ${timeoutRes.exitCode}, duration: ${duration}ms, stderr: "${timeoutRes.stderr.trim()}"`,
      pass
    );
  } catch (err: any) {
    recordTest(5, 'Terminal enforces execution timeout (800ms limit)', 'exitCode 124', `Error: ${err.message}`, false);
  }

  // TEST 6: Command History Tracking & Snippets
  try {
    const history = terminalManager.getHistory(10);
    const pass = history.length >= 4 && history.some((h) => h.command.includes('echo "Hello Terminal Subsystem"'));
    recordTest(
      6,
      'Terminal records history with metadata and output snippets',
      'History contains >= 4 entries with commands recorded',
      `History count: ${history.length}, latest: "${history[0]?.command}"`,
      pass
    );
  } catch (err: any) {
    recordTest(6, 'Terminal records history', 'Recorded history', `Error: ${err.message}`, false);
  }

  // TEST 7: Clear Terminal History
  try {
    terminalManager.clearHistory();
    const historyAfter = terminalManager.getHistory(10);
    const pass = historyAfter.length === 0;
    recordTest(
      7,
      'Terminal clearHistory() resets the stored command history',
      'History length: 0',
      `History length: ${historyAfter.length}`,
      pass
    );
  } catch (err: any) {
    recordTest(7, 'Terminal clearHistory()', '0 items', `Error: ${err.message}`, false);
  }

  // TEST 8: Secret Masking in Terminal Output
  try {
    const secretRes = await terminalManager.executeCommand('echo "API_KEY=AIzaSyD4j5k6l7m8n9o0p1q2r3s4t5u6v7w8x9y"', {
      bypassPermissionCheck: true
    });
    const pass = !secretRes.stdout.includes('AIzaSyD4j5k6l7m8n9o0p1q2r3s4t5u6v7w8x9y') && secretRes.stdout.includes('REDACTED');
    recordTest(
      8,
      'Terminal masks detected API keys and secrets in output',
      'Key is masked with [REDACTED_GOOGLE_API_KEY]',
      `stdout: "${secretRes.stdout.trim()}"`,
      pass
    );
  } catch (err: any) {
    recordTest(8, 'Terminal masks secrets', 'Masked output', `Error: ${err.message}`, false);
  }

  // TEST 9: File Tree Generation
  try {
    // Ensure files exist in workspace for tree verification
    const sampleDir = path.join(workspaceRoot, 'sample_module');
    if (!fs.existsSync(sampleDir)) fs.mkdirSync(sampleDir, { recursive: true });
    fs.writeFileSync(path.join(sampleDir, 'index.ts'), 'export const version = "1.0.0";\n', 'utf-8');

    const tree = fileManager.getFileTree('', 4);
    const pass = tree.type === 'directory' && Array.isArray(tree.children) && tree.children.length > 0;
    recordTest(
      9,
      'FileManager generates recursive workspace file tree structure',
      'Tree node with directory type and children array',
      `Root name: "${tree.name}", children count: ${tree.children?.length}`,
      pass
    );
  } catch (err: any) {
    recordTest(9, 'FileManager generates file tree', 'Valid tree node', `Error: ${err.message}`, false);
  }

  // TEST 10: File Creation & Writing
  try {
    const filePath = 'sample_module/math.ts';
    const content = 'export function add(a: number, b: number): number {\n  return a + b;\n}\n';
    const writeRes = await fileManager.writeFile(filePath, content, { bypassPermission: true });
    const pass = writeRes.path === filePath && (writeRes.changeType === 'create' || writeRes.changeType === 'modify');
    recordTest(
      10,
      'FileManager writes file and tracks creation record',
      `File written at '${filePath}'`,
      `path: "${writeRes.path}", changeType: "${writeRes.changeType}"`,
      pass
    );
  } catch (err: any) {
    recordTest(10, 'FileManager writes file', 'Success', `Error: ${err.message}`, false);
  }

  // TEST 11: File Reading
  try {
    const fileData = fileManager.readFile('sample_module/math.ts');
    const pass = fileData.content.includes('export function add') && fileData.size > 0;
    recordTest(
      11,
      'FileManager reads file content and metadata accurately',
      'File content containing "export function add" and size > 0',
      `Size: ${fileData.size} bytes, content snippet: "${fileData.content.trim().slice(0, 40)}"`,
      pass
    );
  } catch (err: any) {
    recordTest(11, 'FileManager reads file', 'Content retrieved', `Error: ${err.message}`, false);
  }

  // TEST 12: Unified Diff Generation on File Edit
  try {
    const filePath = 'sample_module/math.ts';
    const updatedContent = 'export function add(a: number, b: number): number {\n  // Added docstring\n  return a + b;\n}\n\nexport function multiply(a: number, b: number): number {\n  return a * b;\n}\n';
    const writeRes2 = await fileManager.writeFile(filePath, updatedContent, { bypassPermission: true });
    const diff = fileManager.getFileDiff(filePath);
    const pass = diff.includes('--- a/sample_module/math.ts') &&
                 diff.includes('+++ b/sample_module/math.ts') &&
                 diff.includes('+export function multiply');
    recordTest(
      12,
      'FileManager computes unified diff with standard additions and deletions',
      'Unified diff containing "--- a/", "+++ b/", and "+export function multiply"',
      `Diff snippet:\n${diff.split('\n').slice(0, 6).join('\n')}`,
      pass
    );
  } catch (err: any) {
    recordTest(12, 'FileManager computes unified diff', 'Valid diff', `Error: ${err.message}`, false);
  }

  // TEST 13: File Change Tracking Summary
  try {
    const changedList = fileManager.getChangedFiles();
    const pass = changedList.some((c) => c.path === 'sample_module/math.ts');
    recordTest(
      13,
      'FileManager tracks list of modified/created files in session',
      'List contains "sample_module/math.ts"',
      `Tracked count: ${changedList.length}, includes target: ${pass}`,
      pass
    );
  } catch (err: any) {
    recordTest(13, 'FileManager tracks changed files', 'Target in list', `Error: ${err.message}`, false);
  }

  // TEST 14: File Revert Capability
  try {
    const filePath = 'sample_module/math.ts';
    await fileManager.revertFile(filePath);
    const reverted = fileManager.readFile(filePath);
    // Previous content shouldn't have multiply function
    const pass = !reverted.content.includes('export function multiply');
    recordTest(
      14,
      'FileManager reverts modified file to previous snapshot',
      'Reverted content does not contain newly added "multiply" function',
      `Content contains multiply: ${reverted.content.includes('export function multiply')}`,
      pass
    );
  } catch (err: any) {
    recordTest(14, 'FileManager reverts modified file', 'Reverted content', `Error: ${err.message}`, false);
  }

  // TEST 15: File Deletion with Record
  try {
    const tempFile = 'sample_module/temp_to_delete.txt';
    await fileManager.writeFile(tempFile, 'temporary text', { bypassPermission: true });
    const delRes = await fileManager.deletePath(tempFile, { bypassPermission: true });
    const exists = fs.existsSync(path.join(workspaceRoot, tempFile));
    const pass = delRes.deleted && !exists;
    recordTest(
      15,
      'FileManager deletes file and registers removal in change log',
      'deleted: true and file removed from disk',
      `deleted: ${delRes.deleted}, exists: ${exists}`,
      pass
    );
  } catch (err: any) {
    recordTest(15, 'FileManager deletes file', 'File removed', `Error: ${err.message}`, false);
  }

  // TEST 16: Path Traversal Confinement
  try {
    let trapped = false;
    let errMessage = '';
    try {
      fileManager.readFile('../../../etc/shadow');
    } catch (err: any) {
      trapped = true;
      errMessage = err.message;
    }
    recordTest(
      16,
      'FileManager blocks path traversal outside workspace root',
      'Throws access denied error for "../../../etc/shadow"',
      `Trapped: ${trapped}, message: "${errMessage}"`,
      trapped
    );
  } catch (err: any) {
    recordTest(16, 'FileManager blocks path traversal', 'Access denied', `Error: ${err.message}`, false);
  }

  // TEST 17: Security Gate Check on Terminal Command (Immediate Block)
  try {
    const blockedRes = await terminalManager.executeCommand('cat /etc/passwd', { bypassPermissionCheck: false });
    const pass = blockedRes.exitCode === 126 && blockedRes.stderr.includes('SECURITY BLOCK');
    recordTest(
      17,
      'Security Gate intercepts and blocks sensitive system access ("cat /etc/passwd")',
      'exitCode 126 and SECURITY BLOCK in stderr',
      `exitCode: ${blockedRes.exitCode}, stderr: "${blockedRes.stderr.trim()}"`,
      pass
    );
  } catch (err: any) {
    recordTest(17, 'Security Gate intercepts dangerous command', 'Blocked with 126', `Error: ${err.message}`, false);
  }

  // TEST 18: Security Gate Approval Denial Flow
  try {
    // Start command that requires approval in background
    const execPromise = terminalManager.executeCommand('npm install test-package-xyz', {
      bypassPermissionCheck: false,
      taskId: 'test_phase3_task'
    });

    // Wait a brief tick for approval to be registered
    await new Promise((r) => setTimeout(r, 50));
    const pending = agentPermissionGuard.getPendingApprovals();
    const targetApproval = pending.find((p) => p.taskId === 'test_phase3_task');

    let resolved = false;
    if (targetApproval) {
      resolved = agentPermissionGuard.resolveApproval(targetApproval.id, false, 'test_user');
    }

    const res = await execPromise;
    const pass = resolved && res.exitCode === 126 && res.stderr.includes('Action denied');
    recordTest(
      18,
      'Security Gate handles approval lifecycle (denial halts execution)',
      'exitCode 126 and Action denied message',
      `resolved: ${resolved}, exitCode: ${res.exitCode}, stderr: "${res.stderr.trim()}"`,
      pass
    );
  } catch (err: any) {
    recordTest(18, 'Security Gate handles approval lifecycle', 'Halted with 126', `Error: ${err.message}`, false);
  }

  // SUMMARY
  console.log('\n====================================================');
  console.log('PHASE 3 TEST EXECUTION SUMMARY');
  console.log('====================================================');
  const passedCount = results.filter((r) => r.pass).length;
  const failedCount = results.filter((r) => !r.pass).length;
  console.log(`Total Tests Run: ${results.length}`);
  console.log(`Passed:          ${passedCount}`);
  console.log(`Failed:          ${failedCount}`);
  console.log(`Status:          ${failedCount === 0 ? 'ALL TESTS PASSED' : 'SOME TESTS FAILED'}`);
  console.log('====================================================');

  if (failedCount > 0) {
    process.exit(1);
  }
}

runTests().catch((err) => {
  console.error('Fatal test runner error:', err);
  process.exit(1);
});
