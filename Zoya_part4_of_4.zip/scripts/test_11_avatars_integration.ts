import fs from 'fs';
import path from 'path';
import { ANIME_3D_AVATARS, getAllAvatars, getSelected3DAvatar, save3DAvatarId } from '../src/data/anime3DAvatars';
import { getAvatarAnatomy, ALL_AVATARS_ANATOMY } from '../src/data/avatarAnatomy';
import { AVATAR_GLB_LIST } from '../src/data/avatarGlbConfig';

console.log('=== TEST SUITE: 11 AVATARS INTEGRATION VERIFICATION ===\n');

// 1. Check Total Avatar Count
const allAvatars = getAllAvatars();
console.log(`[CHECK 1] Total Avatars in ANIME_3D_AVATARS: ${ANIME_3D_AVATARS.length}`);
console.log(`[CHECK 1] Total Avatars via getAllAvatars(): ${allAvatars.length}`);
if (allAvatars.length < 15) {
  console.error(`FAIL: Expected at least 15 avatars, found ${allAvatars.length}`);
  process.exit(1);
}
console.log('PASS: Remaining avatars count matches 15.\n');

// 2. Check remaining new avatars specifically and assert removed ones do not exist
const newIds = [
  'avatar_urban_crop_hoodie',
  'avatar_white_ruffle_babydoll',
  'avatar_pink_athleisure_track',
  'avatar_pastel_blue_knit_shorts',
  'avatar_slate_blue_regal_kurta',
  'avatar_midnight_gold_zari_saree',
  'avatar_nautical_denim_shorts',
];

const deletedAvatarIds = [
  'avatar_scarlet_peasant_cargo',
  'avatar_violet_ruffle_cocktail',
  'avatar_black_lace_mermaid_saree',
  'avatar_parisian_beret_skater',
  'elegant_saree',
];

for (const id of deletedAvatarIds) {
  if (allAvatars.some((a) => a.id === id)) {
    console.error(`FAIL: Avatar ${id} should have been removed!`);
    process.exit(1);
  }
}
console.log('PASS: All 5 specified avatars verified completely removed.\n');

console.log('[CHECK 2] Verifying registration and assets for all 11 new avatars:');
let missingAssets = 0;

for (const id of newIds) {
  const avatar = allAvatars.find((a) => a.id === id);
  if (!avatar) {
    console.error(`FAIL: Avatar ${id} not found in registered avatars!`);
    missingAssets++;
    continue;
  }

  // Check transparentPng file on disk
  const transDiskPath = path.join('public', avatar.transparentPng.replace(/^\//, ''));
  if (!fs.existsSync(transDiskPath)) {
    console.error(`FAIL: Missing transparent PNG on disk: ${transDiskPath}`);
    missingAssets++;
  }

  // Check thumbnail file on disk
  const thumbDiskPath = path.join('public', avatar.thumbnail.replace(/^\//, ''));
  if (!fs.existsSync(thumbDiskPath)) {
    console.error(`FAIL: Missing thumbnail on disk: ${thumbDiskPath}`);
    missingAssets++;
  }

  // Check anatomy
  const anatomy = getAvatarAnatomy(id);
  if (!anatomy || anatomy.id !== id) {
    console.error(`FAIL: Anatomy config mismatch for ${id}`);
    missingAssets++;
  }

  // Check modular folder
  const modBody = path.join('public', 'assets', 'images', 'avatars_modular', id, 'body_skin.png');
  if (!fs.existsSync(modBody)) {
    console.error(`FAIL: Missing modular body_skin.png at ${modBody}`);
    missingAssets++;
  }

  console.log(`  ✓ ${id}: Registered, assets verified (${anatomy.widthPx}x${anatomy.heightPx}, AR=${anatomy.aspectRatio.toFixed(3)})`);
}

if (missingAssets > 0) {
  console.error(`FAIL: Encountered ${missingAssets} missing assets.`);
  process.exit(1);
}
console.log('PASS: All 11 new avatars have verified registered assets.\n');

// 3. Verify Existing 8 Avatars were NOT damaged or removed
console.log('[CHECK 3] Verifying 8 pre-existing avatars remain intact:');
const existingIds = [
  'boho_mini_dress',
  'peasant_blouse_skirt',
  'pink_knit_maxi',
  'floral_palazzo_pants',
  'red_cardigan_floral',
  'plum_royal_anarkali',
  'ivory_floral_anarkali',
  'classic',
];

for (const id of existingIds) {
  const avatar = allAvatars.find((a) => a.id === id);
  if (!avatar) {
    console.error(`FAIL: Pre-existing avatar ${id} was accidentally removed!`);
    process.exit(1);
  }
  const anatomy = getAvatarAnatomy(id);
  if (!anatomy) {
    console.error(`FAIL: Pre-existing avatar ${id} anatomy is missing!`);
    process.exit(1);
  }
  console.log(`  ✓ Preserved: ${avatar.name} (${avatar.id})`);
}
console.log('PASS: All 8 existing avatars preserved 100% intact.\n');

// 4. Test Selection and Fallback Resolution
console.log('[CHECK 4] Testing avatar selection and fallback:');
for (const id of newIds) {
  const selected = getSelected3DAvatar(id);
  if (selected.id !== id) {
    console.error(`FAIL: Selection of ${id} resolved to ${selected.id}`);
    process.exit(1);
  }
}
// Test that deleted avatar IDs safely fallback to default avatar
for (const id of deletedAvatarIds) {
  const selected = getSelected3DAvatar(id);
  if (deletedAvatarIds.includes(selected.id)) {
    console.error(`FAIL: Fallback for deleted avatar ${id} returned a deleted avatar!`);
    process.exit(1);
  }
  console.log(`  ✓ Fallback verified for removed avatar "${id}" -> resolves safely to "${selected.id}"`);
}
console.log('PASS: Selection and fallback resolvers work seamlessly for all avatars.\n');

// 5. Test GLB list sync
console.log(`[CHECK 5] AVATAR_GLB_LIST count: ${AVATAR_GLB_LIST.length}`);
console.log('PASS: AVATAR_GLB_LIST updated successfully.\n');

console.log('=== ALL AVATAR INTEGRATION CHECKS PASSED (100% SUCCESS) ===');
