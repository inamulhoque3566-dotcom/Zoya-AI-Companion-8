import { execSync } from 'child_process';
import path from 'path';

interface SuiteResult {
  suite: string;
  command: string;
  exitCode: number;
}

const results: SuiteResult[] = [];

const suites = [
  { name: 'TypeScript Typecheck (tsc --noEmit)', cmd: 'npx tsc --noEmit' },
  { name: 'Production Build (Vite + esbuild)', cmd: 'npm run build' },
  { name: 'Phase 1: Agent Core & Auth', cmd: 'npx tsx scripts/test_phase1_agent_core.ts' },
  { name: 'Phase 2: Security & Sandboxing', cmd: 'npx tsx scripts/test_phase2_security.ts' },
  { name: 'Phase 3: Terminal & Files', cmd: 'npx tsx scripts/test_phase3_terminal_files.ts' },
  { name: 'Phase 4: Agent Skills Engine', cmd: 'npx tsx scripts/test_phase4_skills.ts' },
  { name: 'Phase 5: MCP Client Integration', cmd: 'npx tsx scripts/test_phase5_mcp.ts' },
  { name: 'Phase 6: UI & State Integration', cmd: 'npx tsx scripts/test_phase6_ui.ts' },
  { name: 'Phase 7: Tests 1 to 4 (Import, Scan, Exec, MCP)', cmd: 'npx tsx scripts/run_phase7_tests_1_to_4.ts' },
  { name: 'Phase 7: Tests 5 to 8 (Terminal, Files, Multi-file, TestFix)', cmd: 'npx tsx scripts/run_phase7_tests_5_to_8.ts' },
  { name: 'Phase 7: Tests 9 to 10 (Build, Skill Removal)', cmd: 'npx tsx scripts/run_phase7_tests_9_to_10.ts' },
];

for (const s of suites) {
  let code = 0;
  try {
    execSync(s.cmd, { stdio: 'pipe', encoding: 'utf8', timeout: 90000 });
  } catch (err: any) {
    code = err.status || 1;
  }
  results.push({ suite: s.name, command: s.cmd, exitCode: code });
}

console.log('\n========================================================================================');
console.log('| Suite Name                                   | Status                       | Exit |');
console.log('========================================================================================');
for (const r of results) {
  const namePad = r.suite.padEnd(45, ' ');
  const statusPad = (r.exitCode === 0 ? 'PASS' : 'FAIL').padEnd(28, ' ');
  const exitPad = String(r.exitCode).padStart(4, ' ');
  console.log(`| ${namePad} | ${statusPad} | ${exitPad} |`);
}
console.log('========================================================================================\n');
