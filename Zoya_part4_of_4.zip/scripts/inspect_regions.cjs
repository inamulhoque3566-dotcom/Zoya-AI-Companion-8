const sharp = require('sharp');
const path = require('path');

async function inspectRegions() {
  const src = path.join(__dirname, '../src/assets/images/zoya_3d_sweater_glasses_1793764031303.jpg');
  const { data, info } = await sharp(src).removeAlpha().raw().toBuffer({ resolveWithObject: true });
  const W = info.width, H = info.height;

  // Let's sample a horizontal scanline across hair at y=100 (x from 280 to 480)
  console.log('--- Hair scan at y=100 ---');
  for (let x = 280; x <= 480; x += 20) {
    const idx = (100 * W + x) * 3;
    console.log(`x=${x}: [${data[idx]}, ${data[idx+1]}, ${data[idx+2]}]`);
  }

  // Let's sample a horizontal scanline across sweater at y=350 (x from 250 to 520)
  console.log('--- Sweater scan at y=350 ---');
  for (let x = 250; x <= 520; x += 20) {
    const idx = (350 * W + x) * 3;
    console.log(`x=${x}: [${data[idx]}, ${data[idx+1]}, ${data[idx+2]}]`);
  }

  // Let's sample across skirt at y=800 (x from 200 to 560)
  console.log('--- Skirt scan at y=800 ---');
  for (let x = 200; x <= 560; x += 30) {
    const idx = (800 * W + x) * 3;
    console.log(`x=${x}: [${data[idx]}, ${data[idx+1]}, ${data[idx+2]}]`);
  }

  // Let's sample across socks/shoes at y=1240, 1290, 1340
  console.log('--- Legs/Socks/Shoes ---');
  for (const y of [1220, 1260, 1310, 1345]) {
    console.log(`y=${y}:`);
    for (let x = 320; x <= 450; x += 15) {
      const idx = (y * W + x) * 3;
      console.log(`  x=${x}: [${data[idx]}, ${data[idx+1]}, ${data[idx+2]}]`);
    }
  }
}
inspectRegions().catch(console.error);
