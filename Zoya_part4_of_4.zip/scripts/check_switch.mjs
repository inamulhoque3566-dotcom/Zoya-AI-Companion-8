import { chromium } from 'playwright';

async function test() {
  const browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
  const page = await browser.newPage({ viewport: { width: 420, height: 860 } });
  await page.goto('http://localhost:3000', { waitUntil: 'networkidle' });
  await page.waitForTimeout(1000);

  const initialId = await page.evaluate(() => {
    return document.querySelector('[data-testid="zoya-avatar-rig"]')?.getAttribute('data-avatar-id');
  });
  console.log('Initial avatar id:', initialId);

  // Switch to traditional_saree via window.__zoyaSelectAvatar
  await page.evaluate(() => {
    if (typeof window.__zoyaSelectAvatar === 'function') {
      window.__zoyaSelectAvatar('traditional_saree');
    }
  });
  await page.waitForTimeout(1500);

  const switchedId = await page.evaluate(() => {
    return document.querySelector('[data-testid="zoya-avatar-rig"]')?.getAttribute('data-avatar-id');
  });
  console.log('After switching to traditional_saree:', switchedId);

  await browser.close();
}

test().catch(console.error);
