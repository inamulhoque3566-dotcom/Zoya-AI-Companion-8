import sharp from 'sharp';
import fs from 'fs';
import path from 'path';

const outDir = path.join(process.cwd(), 'public', 'assets', 'images', 'avatars_modular', 'avatar_pastel_blue_knit_shorts');

async function processEyes() {
  console.log('[EYES] Starting eye extraction and alpha mask generation...');

  // 1. Resize generated 1024x1024 closed and half-closed faces back to face_crop size (300x250)
  // Let's inspect where the eyes are in the 1024x1024 images
  // In the 1024 image:
  // Left eye (viewer's left): around x = 370, y = 300
  // Right eye (viewer's right): around x = 650, y = 340
  
  // Let's extract eyes with exact feature matching
  const cropFace = await sharp('public/assets/images/avatars_modular/avatar_pastel_blue_knit_shorts/face_crop.png')
    .ensureAlpha()
    .raw()
    .toBuffer({ resolveWithObject: true });

  const closedFace = await sharp('src/assets/images/face_closed_eyes_1794411100565.jpg')
    .resize(300, 250, { fit: 'fill' })
    .ensureAlpha()
    .raw()
    .toBuffer({ resolveWithObject: true });

  const halfFace = await sharp('src/assets/images/face_half_closed_eyes_1794411121897.jpg')
    .resize(300, 250, { fit: 'fill' })
    .ensureAlpha()
    .raw()
    .toBuffer({ resolveWithObject: true });

  console.log('Resized closedFace and halfFace to 300x250');

  // Let's create the eye patch bounding box relative to face_crop (300x250):
  // Left: 80, Top: 40, Width: 160, Height: 65
  // In full image (941x1672):
  // X = 330 + 80 = 410, Y = 100 + 40 = 140, Width = 160, Height = 65
  const eyeLeft = 80;
  const eyeTop = 40;
  const eyeW = 160;
  const eyeH = 65;

  // Build a radial/feathered alpha mask for each eye (so skin around eyes blends 100% seamlessly)
  // Left eye center in eye patch: (38, 24), radiusX = 26, radiusY = 18
  // Right eye center in eye patch: (116, 35), radiusX = 28, radiusY = 19
  const maskData = Buffer.alloc(eyeW * eyeH);

  for (let y = 0; y < eyeH; y++) {
    for (let x = 0; x < eyeW; x++) {
      // Distance to left eye center
      const dx1 = (x - 38) / 28;
      const dy1 = (y - 24) / 19;
      const d1 = Math.sqrt(dx1 * dx1 + dy1 * dy1);

      // Distance to right eye center
      const dx2 = (x - 116) / 30;
      const dy2 = (y - 35) / 20;
      const d2 = Math.sqrt(dx2 * dx2 + dy2 * dy2);

      const d = Math.min(d1, d2);

      let alpha = 0;
      if (d <= 0.7) {
        alpha = 255;
      } else if (d < 1.05) {
        // Smooth cosine falloff
        const t = (d - 0.7) / (1.05 - 0.7);
        alpha = Math.round(255 * 0.5 * (1 + Math.cos(t * Math.PI)));
      }
      maskData[y * eyeW + x] = alpha;
    }
  }

  // Generate eyes_closed.png (transparent PNG with exact feathered eyes)
  const extractClosedEyePatch = await sharp('src/assets/images/face_closed_eyes_1794411100565.jpg')
    .resize(300, 250, { fit: 'fill' })
    .extract({ left: eyeLeft, top: eyeTop, width: eyeW, height: eyeH })
    .ensureAlpha()
    .raw()
    .toBuffer({ resolveWithObject: true });

  const closedEyeBuf = Buffer.alloc(eyeW * eyeH * 4);
  for (let i = 0; i < eyeW * eyeH; i++) {
    closedEyeBuf[i * 4 + 0] = extractClosedEyePatch.data[i * 4 + 0];
    closedEyeBuf[i * 4 + 1] = extractClosedEyePatch.data[i * 4 + 1];
    closedEyeBuf[i * 4 + 2] = extractClosedEyePatch.data[i * 4 + 2];
    closedEyeBuf[i * 4 + 3] = maskData[i];
  }

  const eyesClosedPath = path.join(outDir, 'eyes_closed.png');
  await sharp(closedEyeBuf, { raw: { width: eyeW, height: eyeH, channels: 4 } })
    .png()
    .toFile(eyesClosedPath);

  // Generate eyes_half.png (transparent PNG for half-blink frame)
  const extractHalfEyePatch = await sharp('src/assets/images/face_half_closed_eyes_1794411121897.jpg')
    .resize(300, 250, { fit: 'fill' })
    .extract({ left: eyeLeft, top: eyeTop, width: eyeW, height: eyeH })
    .ensureAlpha()
    .raw()
    .toBuffer({ resolveWithObject: true });

  const halfEyeBuf = Buffer.alloc(eyeW * eyeH * 4);
  for (let i = 0; i < eyeW * eyeH; i++) {
    halfEyeBuf[i * 4 + 0] = extractHalfEyePatch.data[i * 4 + 0];
    halfEyeBuf[i * 4 + 1] = extractHalfEyePatch.data[i * 4 + 1];
    halfEyeBuf[i * 4 + 2] = extractHalfEyePatch.data[i * 4 + 2];
    halfEyeBuf[i * 4 + 3] = maskData[i];
  }

  const eyesHalfPath = path.join(outDir, 'eyes_half.png');
  await sharp(halfEyeBuf, { raw: { width: eyeW, height: eyeH, channels: 4 } })
    .png()
    .toFile(eyesHalfPath);

  // Also create a composite preview on face_crop to inspect open, half, closed
  await sharp('public/assets/images/avatars_modular/avatar_pastel_blue_knit_shorts/face_crop.png')
    .composite([{ input: eyesClosedPath, left: eyeLeft, top: eyeTop }])
    .png()
    .toFile(path.join(outDir, 'preview_face_closed.png'));

  await sharp('public/assets/images/avatars_modular/avatar_pastel_blue_knit_shorts/face_crop.png')
    .composite([{ input: eyesHalfPath, left: eyeLeft, top: eyeTop }])
    .png()
    .toFile(path.join(outDir, 'preview_face_half.png'));

  console.log('[EYES] Created eyes_closed.png and eyes_half.png at:', outDir);
  console.log('[EYES] Eye position relative to full 941x1672 image:', {
    cropW: eyeW,
    cropH: eyeH,
    eyeCenterX: 330 + eyeLeft + eyeW / 2, // 330 + 80 + 80 = 490
    eyeCenterY: 100 + eyeTop + eyeH / 2,  // 100 + 40 + 32.5 = 172.5
  });
}

processEyes().catch(console.error);
