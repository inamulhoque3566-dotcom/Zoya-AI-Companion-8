import {
  encryptSecret,
  decryptSecret,
  storeEncryptedSecret,
  getDecryptedSecretSync,
} from '../src/services/secretVault.js';

async function runVaultVerification() {
  console.log('================================================================');
  console.log('ZOYA WEB CRYPTO SECRET VAULT & KEYSTORE SECURITY TEST');
  console.log('================================================================');

  // Test 1: Sensitive API Key Roundtrip
  console.log('Test 1: Testing Web Crypto AES-GCM 256-bit encrypt/decrypt roundtrip...');
  const sampleKey = 'sk-live-proj-9876543210-secure-gemini-token';
  const ciphertext = await encryptSecret(sampleKey);
  console.log('  -> Ciphertext starts with prefix:', ciphertext.startsWith('enc_v1:'));
  console.log('  -> Ciphertext length:', ciphertext.length);
  console.log('  -> Ciphertext preview:', ciphertext.slice(0, 45) + '...');
  
  if (ciphertext === sampleKey) {
    throw new Error('Ciphertext matches plaintext! Encryption failed.');
  }

  // Test 2: Decrypt
  console.log('\nTest 2: Decrypting ciphertext payload...');
  const decrypted = await decryptSecret(ciphertext);
  if (decrypted !== sampleKey) {
    throw new Error(`Decrypted text mismatch! Expected "${sampleKey}", got "${decrypted}"`);
  }
  console.log('  -> [PASS] Decrypted text matches original plaintext key exactly.');

  // Test 3: Multiple realistic keys
  console.log('\nTest 3: Testing roundtrip on multiple credentials...');
  const keysToTest = [
    'ghp_abcdef1234567890XYZW_classic_pat',
    'xoxb-123456789012-1234567890123-abcdefghijklmnopqrstuvwx',
    'https://hooks.slack.com/services/T000/B000/XXXX',
    'composio_auth_live_998877665544332211',
  ];

  for (const k of keysToTest) {
    const enc = await encryptSecret(k);
    const dec = await decryptSecret(enc);
    if (dec !== k) {
      throw new Error(`Roundtrip failed for ${k.slice(0, 10)}...`);
    }
  }
  console.log(`  -> [PASS] Verified all ${keysToTest.length} credential types.`);

  // Test 4: Ephemeral memory vault
  console.log('\nTest 4: Ephemeral in-memory storage test...');
  await storeEncryptedSecret('TEST_MEM_KEY', 'my-ephemeral-secret');
  const cachedVal = getDecryptedSecretSync('TEST_MEM_KEY');
  if (cachedVal !== 'my-ephemeral-secret') {
    throw new Error(`Cached value mismatch: ${cachedVal}`);
  }
  console.log('  -> [PASS] In-memory synchronous access verified.');

  console.log('\n================================================================');
  console.log('ALL VAULT TESTS PASSED: Web Crypto AES-GCM 256 validated.');
  console.log('SECURITY ARCHITECTURE DISCLOSURE:');
  console.log('1. Web App: PBKDF2 device entropy + AES-GCM 256-bit encryption.');
  console.log('   Provides defense-in-depth against plain log/storage snooping.');
  console.log('   Client-side secret isolation without server or hardware Keystore');
  console.log('   is obfuscated envelope protection.');
  console.log('2. Native Android APK: Hardware-backed AndroidKeyStore with');
  console.log('   EncryptedSharedPreferences (AES256-GCM + MasterKey AES256-SIV).');
  console.log('================================================================\n');
}

runVaultVerification().catch((err) => {
  console.error('Vault verification failed:', err);
  process.exit(1);
});
