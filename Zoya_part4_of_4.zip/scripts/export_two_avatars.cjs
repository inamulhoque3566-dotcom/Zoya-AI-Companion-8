const sharp = require('sharp');
const fs = require('fs');
const path = require('path');

async function exportFinalAssets() {
  console.log('=== EXPORTING PERFECT CLEAN AVATAR ASSETS ===');

  // 1. Process Avatar A: Pink Athleisure Tracksuit
  console.log('Processing Pink Athleisure Tracksuit...');
  // From test_pink_u2net.png, extract 768x1364 from top=0
  const pinkPngBuf = await sharp('test_pink_u2net.png')
    .extract({ left: 0, top: 0, width: 768, height: 1364 })
    .png({ compressionLevel: 8 })
    .toBuffer();

  // Save to transparent path
  fs.writeFileSync('public/assets/images/avatars_3d/transparent/avatar_pink_athleisure_track.png', pinkPngBuf);
  // Save to modular path
  fs.writeFileSync('public/assets/images/avatars_modular/avatar_pink_athleisure_track/body_skin.png', pinkPngBuf);

  // Generate card preview JPG on dark navy background
  const pinkCardBg = await sharp({
    create: { width: 768, height: 1364, channels: 3, background: { r: 10, g: 15, b: 30 } }
  }).jpeg({ quality: 92 }).toBuffer();

  const pinkPreviewJpg = await sharp(pinkCardBg)
    .composite([{ input: pinkPngBuf, blend: 'over' }])
    .jpeg({ quality: 92 })
    .toBuffer();

  fs.writeFileSync('public/assets/images/avatars_3d/avatar_pink_athleisure_track.jpg', pinkPreviewJpg);
  console.log('✓ Pink Athleisure exported to transparent, modular, and card preview');

  // 2. Process Avatar B: White Satin Ruffle Babydoll
  console.log('Processing White Satin Ruffle Babydoll...');
  const whitePngBuf = await sharp('test_white_u2net.png')
    .png({ compressionLevel: 8 })
    .toBuffer();

  // Save to transparent path
  fs.writeFileSync('public/assets/images/avatars_3d/transparent/avatar_white_ruffle_babydoll.png', whitePngBuf);
  // Save to modular path
  fs.writeFileSync('public/assets/images/avatars_modular/avatar_white_ruffle_babydoll/body_skin.png', whitePngBuf);

  // Generate card preview JPG on dark navy background
  const whiteCardBg = await sharp({
    create: { width: 1024, height: 1536, channels: 3, background: { r: 10, g: 15, b: 30 } }
  }).jpeg({ quality: 92 }).toBuffer();

  const whitePreviewJpg = await sharp(whiteCardBg)
    .composite([{ input: whitePngBuf, blend: 'over' }])
    .jpeg({ quality: 92 })
    .toBuffer();

  fs.writeFileSync('public/assets/images/avatars_3d/avatar_white_ruffle_babydoll.jpg', whitePreviewJpg);
  console.log('✓ White Satin Babydoll exported to transparent, modular, and card preview');

  // 3. Generate Zoomed-on-Feet Magenta Proofs
  fs.mkdirSync('proof_artifacts', { recursive: true });

  // Pink feet zoom (y: 950 to 1364, x: 200 to 568)
  const pinkMagentaBg = await sharp({
    create: { width: 768, height: 1364, channels: 4, background: { r: 255, g: 0, b: 255, alpha: 1 } }
  }).png().toBuffer();

  const pinkMagentaFull = await sharp(pinkMagentaBg)
    .composite([{ input: pinkPngBuf }])
    .png()
    .toBuffer();

  await sharp(pinkMagentaFull)
    .extract({ left: 180, top: 900, width: 408, height: 464 })
    .toFile('proof_artifacts/avatar_a_pink_feet_zoom_magenta.png');

  // White feet zoom (y: 1100 to 1536, x: 350 to 674)
  const whiteMagentaBg = await sharp({
    create: { width: 1024, height: 1536, channels: 4, background: { r: 255, g: 0, b: 255, alpha: 1 } }
  }).png().toBuffer();

  const whiteMagentaFull = await sharp(whiteMagentaBg)
    .composite([{ input: whitePngBuf }])
    .png()
    .toBuffer();

  await sharp(whiteMagentaFull)
    .extract({ left: 340, top: 1100, width: 344, height: 436 })
    .toFile('proof_artifacts/avatar_b_white_feet_zoom_magenta.png');

  console.log('✓ Zoomed-on-feet magenta proofs created.');
}

exportFinalAssets().catch(console.error);
