const fs = require('fs');
const path = require('path');
const sharp = require('sharp');

/**
 * MASTER AVATAR BACKGROUND & GROUND SHADOW CLEANER
 * 
 * Rules:
 * 1. Complete Background Removal:
 *    - Remove original embedded background, white/grey floor shadows, white patches under feet/hem.
 *    - Remove isolated floating pixels (like black pixel islands near arm/torso).
 *    - Remove all border remnants (T, B, L, R).
 * 2. True Transparent Background:
 *    - Preserves exact PNG alpha channel with transparent background.
 * 3. 100% Avatar Fidelity:
 *    - Preserves head, hair, face, clothes, colors, body proportions, shoes, heels, and toes.
 *    - Preserves white clothes (beret, sweater, pleated skirt, babydoll dress, white shoes).
 */

const AVATAR_SPECS = [
  {
    id: 'avatar_parisian_beret_skater',
    file: 'public/assets/images/avatars_3d/transparent/avatar_parisian_beret_skater.png',
    type: 'skirt_legs',
    footLeft: 320,
    footRight: 505,
    maxFootY: 1350,
    legGap: { minY: 960, maxY: 1240, minX: 366, maxX: 438 }
  },
  {
    id: 'avatar_nautical_denim_shorts',
    file: 'public/assets/images/avatars_3d/transparent/avatar_nautical_denim_shorts.png',
    type: 'shorts_legs',
    footLeft: 315,
    footRight: 456,
    maxFootY: 1324,
    legGap: { minY: 920, maxY: 1220, minX: 355, maxX: 418 }
  },
  {
    id: 'avatar_pink_athleisure_track',
    file: 'public/assets/images/avatars_3d/transparent/avatar_pink_athleisure_track.png',
    type: 'shorts_legs',
    footLeft: 315,
    footRight: 446,
    maxFootY: 1345,
    legGap: { minY: 900, maxY: 1230, minX: 350, maxX: 415 }
  },
  {
    id: 'avatar_violet_ruffle_cocktail',
    file: 'public/assets/images/avatars_3d/transparent/avatar_violet_ruffle_cocktail.png',
    type: 'skirt_legs',
    footLeft: 325,
    footRight: 462,
    maxFootY: 1352,
    legGap: { minY: 940, maxY: 1230, minX: 360, maxX: 435 }
  },
  {
    id: 'elegant_saree',
    file: 'public/assets/images/elegant_saree_avatar_transparent.png',
    type: 'saree_gown',
    hemRight: 648,
    maxFootY: 1358
  },
  {
    id: 'avatar_urban_crop_hoodie',
    file: 'public/assets/images/avatars_3d/transparent/avatar_urban_crop_hoodie.png',
    type: 'pants_legs',
    footLeft: 290,
    footRight: 645,
    maxFootY: 1640
  },
  {
    id: 'avatar_white_ruffle_babydoll',
    file: 'public/assets/images/avatars_3d/transparent/avatar_white_ruffle_babydoll.png',
    type: 'skirt_legs',
    footLeft: 470,
    footRight: 615,
    maxFootY: 1515,
    legGap: { minY: 1050, maxY: 1360, minX: 505, maxX: 575 }
  },
  {
    id: 'avatar_scarlet_peasant_cargo',
    file: 'public/assets/images/avatars_3d/transparent/avatar_scarlet_peasant_cargo.png',
    type: 'skirt_legs',
    footLeft: 465,
    footRight: 610,
    maxFootY: 1520,
    legGap: { minY: 1040, maxY: 1360, minX: 510, maxX: 565 }
  },
  {
    id: 'avatar_pastel_blue_knit_shorts',
    file: 'public/assets/images/avatars_3d/transparent/avatar_pastel_blue_knit_shorts.png',
    type: 'shorts_legs',
    footLeft: 400,
    footRight: 575,
    maxFootY: 1650,
    legGap: { minY: 1050, maxY: 1450, minX: 450, maxX: 520 }
  },
  {
    id: 'avatar_slate_blue_regal_kurta',
    file: 'public/assets/images/avatars_3d/transparent/avatar_slate_blue_regal_kurta.png',
    type: 'saree_gown',
    hemRight: 680,
    maxFootY: 1655
  },
  {
    id: 'avatar_midnight_gold_zari_saree',
    file: 'public/assets/images/avatars_3d/transparent/avatar_midnight_gold_zari_saree.png',
    type: 'saree_gown',
    hemRight: 840,
    maxFootY: 1520
  },
  {
    id: 'avatar_black_lace_mermaid_saree',
    file: 'public/assets/images/avatars_3d/transparent/avatar_black_lace_mermaid_saree.png',
    type: 'saree_gown',
    hemRight: 825,
    maxFootY: 1520
  },
  {
    id: 'boho_mini_dress',
    file: 'public/assets/images/avatars_3d/transparent/avatar_boho_mini_dress.png',
    type: 'skirt_legs',
    footLeft: 380,
    footRight: 505,
    maxFootY: 1205
  },
  {
    id: 'peasant_blouse_skirt',
    file: 'public/assets/images/avatars_3d/transparent/avatar_peasant_blouse_skirt.png',
    type: 'saree_gown',
    hemRight: 550,
    maxFootY: 1320
  },
  {
    id: 'pink_knit_maxi',
    file: 'public/assets/images/avatars_3d/transparent/avatar_pink_knit_maxi.png',
    type: 'saree_gown',
    hemRight: 615,
    maxFootY: 1345
  },
  {
    id: 'floral_palazzo_pants',
    file: 'public/assets/images/avatars_3d/transparent/avatar_floral_palazzo_pants.png',
    type: 'pants_legs',
    footLeft: 190,
    footRight: 575,
    maxFootY: 1352
  },
  {
    id: 'red_cardigan_floral',
    file: 'public/assets/images/avatars_3d/transparent/avatar_red_cardigan_floral.png',
    type: 'skirt_legs',
    footLeft: 395,
    footRight: 520,
    maxFootY: 1128
  },
  {
    id: 'plum_royal_anarkali',
    file: 'public/assets/images/avatars_3d/transparent/avatar_plum_royal_anarkali.png',
    type: 'saree_gown',
    hemRight: 745,
    maxFootY: 1208
  },
  {
    id: 'ivory_floral_anarkali',
    file: 'public/assets/images/avatars_3d/transparent/avatar_ivory_floral_anarkali.png',
    type: 'saree_gown',
    hemRight: 655,
    maxFootY: 1308
  },
  {
    id: 'classic',
    file: 'public/assets/images/zoya_new_avatar_transparent.png',
    type: 'skirt_legs',
    footLeft: 320,
    footRight: 460,
    maxFootY: 1358
  }
];

async function processAvatar(spec) {
  if (!fs.existsSync(spec.file)) {
    console.warn(`File not found: ${spec.file}`);
    return;
  }

  const { data, info } = await sharp(spec.file).raw().toBuffer({ resolveWithObject: true });
  const W = info.width, H = info.height;
  const out = Buffer.from(data);

  // 1. Remove outer image borders (top, bottom, left, right 2px perimeter)
  for (let x = 0; x < W; x++) {
    for (let y = 0; y < 3; y++) {
      out[(y * W + x) * 4 + 3] = 0;
      out[((H - 1 - y) * W + x) * 4 + 3] = 0;
    }
  }
  for (let y = 0; y < H; y++) {
    for (let x = 0; x < 3; x++) {
      out[(y * W + x) * 4 + 3] = 0;
      out[(y * W + (W - 1 - x)) * 4 + 3] = 0;
    }
  }

  // 2. Clear ground surfaces, floor shadows, and white patches
  const yBottomStart = Math.floor(H * 0.75);
  for (let y = 0; y < H; y++) {
    for (let x = 0; x < W; x++) {
      const idx = (y * W + x) * 4;
      const a = out[idx + 3];
      if (a === 0) continue;

      const r = out[idx], g = out[idx + 1], b = out[idx + 2];
      const isNeutral = Math.abs(r - g) <= 12 && Math.abs(r - b) <= 12 && Math.abs(g - b) <= 12;

      // Rule A: Outside horizontal feet/shoe bounds in the lower section
      if (spec.footLeft !== undefined && spec.footRight !== undefined) {
        if (y >= yBottomStart) {
          if (x < spec.footLeft - 10 || x > spec.footRight + 10) {
            out[idx + 3] = 0;
            continue;
          }
        }
      }

      // Rule B: Outside hem bounds for long gowns/sarees
      if (spec.hemRight !== undefined) {
        if (y >= yBottomStart && x > spec.hemRight + 8) {
          out[idx + 3] = 0;
          continue;
        }
      }

      // Rule C: Beneath the lowest shoe/foot sole (floor plane)
      if (spec.maxFootY !== undefined && y > spec.maxFootY) {
        out[idx + 3] = 0;
        continue;
      }

      // Rule D: Between-legs background air gap (crotch to ankles)
      if (spec.legGap) {
        const { minY, maxY, minX, maxX } = spec.legGap;
        if (y >= minY && y <= maxY && x >= minX && x <= maxX) {
          // If light neutral background or pure white studio wall
          if (isNeutral && r >= 195) {
            out[idx + 3] = 0;
            continue;
          }
        }
      }

      // Rule E: Bottom white shadow remnants (floor patches under soles)
      if (y >= H * 0.92 && isNeutral && r >= 210) {
        // If it is on the outer edges of the feet
        if (spec.footLeft !== undefined && (x < spec.footLeft + 5 || x > spec.footRight - 5)) {
          out[idx + 3] = 0;
          continue;
        }
      }
    }
  }

  // 3. Connected Component Analysis to remove isolated floating pixel islands (like black marks near arms)
  const visited = new Uint8Array(W * H);
  const components = [];
  for (let y = 0; y < H; y++) {
    for (let x = 0; x < W; x++) {
      const idx = y * W + x;
      if (visited[idx] || out[idx * 4 + 3] < 30) continue;

      let size = 0;
      const coords = [];
      const queue = [x, y];
      visited[idx] = 1;
      let head = 0;

      while (head < queue.length) {
        const cx = queue[head++], cy = queue[head++];
        size++;
        coords.push(cy * W + cx);

        const neighbors = [
          [cx - 1, cy], [cx + 1, cy], [cx, cy - 1], [cx, cy + 1]
        ];
        for (const [nx, ny] of neighbors) {
          if (nx >= 0 && nx < W && ny >= 0 && ny < H) {
            const nidx = ny * W + nx;
            if (!visited[nidx] && out[nidx * 4 + 3] >= 30) {
              visited[nidx] = 1;
              queue.push(nx, ny);
            }
          }
        }
      }
      components.push({ size, coords });
    }
  }

  components.sort((a, b) => b.size - a.size);

  // If there are multiple components, keep only significant body parts (main body > 20000 px, or accessories connected)
  // Zero out all small floating islands (size < 4000 pixels)
  if (components.length > 1) {
    const mainBodySize = components[0].size;
    for (let i = 1; i < components.length; i++) {
      const comp = components[i];
      // If it is smaller than 2% of the main body, it is floating background/logo/shadow noise
      if (comp.size < Math.min(5000, mainBodySize * 0.03)) {
        for (const pixelIdx of comp.coords) {
          out[pixelIdx * 4 + 3] = 0;
        }
      }
    }
  }

  // 4. Edge softening (clean 1px natural alpha blending)
  // To avoid any jagged 1-bit alpha staircasing or white halos
  const alphaSnapshot = new Uint8Array(W * H);
  for (let i = 0; i < W * H; i++) {
    alphaSnapshot[i] = out[i * 4 + 3];
  }

  for (let y = 1; y < H - 1; y++) {
    for (let x = 1; x < W - 1; x++) {
      const idx = y * W + x;
      const a = alphaSnapshot[idx];
      if (a === 255) {
        // Count transparent neighbors
        let transNeighbors = 0;
        if (alphaSnapshot[idx - 1] === 0) transNeighbors++;
        if (alphaSnapshot[idx + 1] === 0) transNeighbors++;
        if (alphaSnapshot[idx - W] === 0) transNeighbors++;
        if (alphaSnapshot[idx + W] === 0) transNeighbors++;

        if (transNeighbors >= 2) {
          // Feather boundary pixel
          out[idx * 4 + 3] = 180;
        } else if (transNeighbors === 1) {
          out[idx * 4 + 3] = 220;
        }
      }
    }
  }

  // 5. Save pristine Full HD transparent PNG
  await sharp(out, { raw: { width: W, height: H, channels: 4 } })
    .png({ compressionLevel: 9 })
    .toFile(spec.file);

  console.log(`[MASTER_CLEAN] Successfully processed and cleaned: ${spec.id} (${W}x${H})`);
}

async function main() {
  console.log(`Cleaning all ${AVATAR_SPECS.length} avatar assets...`);
  for (const spec of AVATAR_SPECS) {
    await processAvatar(spec);
  }
  console.log('All avatar assets cleaned successfully!');
}

main().catch(err => {
  console.error('Error during avatar background cleanup:', err);
  process.exit(1);
});
