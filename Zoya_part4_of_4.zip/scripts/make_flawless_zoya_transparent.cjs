const sharp = require('sharp');
const fs = require('fs');
const path = require('path');

async function createFlawlessZoya() {
  const srcPath = path.join(__dirname, '../src/assets/images/zoya_3d_sweater_glasses_1793764031303.jpg');
  const destPublic = path.join(__dirname, '../public/assets/images/anime_princess_3d_transparent.png');

  const { data: rgb, info } = await sharp(srcPath).removeAlpha().raw().toBuffer({ resolveWithObject: true });
  const W = info.width;
  const H = info.height;
  console.log(`Processing image: ${W}x${H}`);

  // 1. Build row background color model from the outermost 15 pixels on left and right
  const bgRowL = new Array(H);
  const bgRowR = new Array(H);
  for (let y = 0; y < H; y++) {
    let rL = 0, gL = 0, bL = 0;
    let rR = 0, gR = 0, bR = 0;
    for (let x = 0; x < 15; x++) {
      const idxL = (y * W + x) * 3;
      const idxR = (y * W + (W - 1 - x)) * 3;
      rL += rgb[idxL]; gL += rgb[idxL + 1]; bL += rgb[idxL + 2];
      rR += rgb[idxR]; gR += rgb[idxR + 1]; bR += rgb[idxR + 2];
    }
    bgRowL[y] = [rL / 15, gL / 15, bL / 15];
    bgRowR[y] = [rR / 15, gR / 15, bR / 15];
  }

  // Exact function to test if a pixel is studio background
  const isBgPixel = (x, y) => {
    // Top of head starts at y=28; bottom of shoes ends at y=1362
    if (y < 28 || y > 1362) return true;
    // Lateral margins: hair & clothes are strictly within x in [195..575]
    if (x < 195 || x > 575) return true;

    // Around head: hair is strictly within x in [265..510]
    if (y >= 28 && y <= 220 && (x < 266 || x > 508)) {
      return true;
    }

    const idx = (y * W + x) * 3;
    const r = rgb[idx], g = rgb[idx + 1], b = rgb[idx + 2];

    const t = x / (W - 1);
    const expR = bgRowL[y][0] * (1 - t) + bgRowR[y][0] * t;
    const expG = bgRowL[y][1] * (1 - t) + bgRowR[y][1] * t;
    const expB = bgRowL[y][2] * (1 - t) + bgRowR[y][2] * t;

    const dist = Math.sqrt((r - expR) ** 2 + (g - expG) ** 2 + (b - expB) ** 2);
    const chroma = Math.max(Math.abs(r - g), Math.abs(r - b), Math.abs(g - b));

    // Studio backdrop criteria:
    if (dist < 40 && chroma <= 7) return true;
    if (dist < 28 && chroma <= 9) return true;
    if (dist < 18 && chroma <= 12) return true;

    return false;
  };

  // 2. Skirt hem detection for each column x
  // Skirt is brown fabric: r > 40, r > g, r > b, chroma > 8
  const skirtHem = new Int32Array(W).fill(0);
  for (let x = 190; x <= 580; x++) {
    for (let y = 1120; y <= 1225; y++) {
      const idx = (y * W + x) * 3;
      const r = rgb[idx], g = rgb[idx + 1], b = rgb[idx + 2];
      if (r > 42 && r > g + 2 && (r - b) >= 10) {
        skirtHem[x] = y;
      }
    }
  }
  // Fill any 1px gap in skirt hem
  for (let x = 195; x <= 575; x++) {
    if (skirtHem[x] === 0 && skirtHem[x - 1] > 0 && skirtHem[x + 1] > 0) {
      skirtHem[x] = Math.round((skirtHem[x - 1] + skirtHem[x + 1]) / 2);
    }
  }

  // Exact function for leg/shoe foreground:
  const isInsideLegOrShoe = (x, y) => {
    if (y < 1180 || y > 1362) return false;

    // Left leg / sock / shoe:
    let isLeft = false;
    if (y < 1260) {
      // Bare skin calf
      isLeft = (x >= 327 && x <= 372);
    } else if (y <= 1305) {
      // White/grey ribbed sock
      isLeft = (x >= 327 && x <= 377);
    } else {
      // Black Mary Jane shoe
      isLeft = (x >= 321 && x <= 388);
    }
    if (isLeft) return true;

    // Right leg / sock / shoe:
    let isRight = false;
    if (y < 1260) {
      // Bare skin calf
      isRight = (x >= 406 && x <= 452);
    } else if (y <= 1305) {
      // White/grey ribbed sock
      isRight = (x >= 401 && x <= 453);
    } else {
      // Black Mary Jane shoe
      isRight = (x >= 394 && x <= 463);
    }
    if (isRight) return true;

    return false;
  };

  // 3. Mark background mask:
  const bgMask = new Uint8Array(W * H);
  const queue = new Int32Array(W * H);
  let qHead = 0, qTail = 0;

  const markBg = (x, y) => {
    const idx = y * W + x;
    if (bgMask[idx] === 0) {
      bgMask[idx] = 1;
      queue[qTail++] = idx;
    }
  };

  // Seed with outer boundaries
  for (let x = 0; x < W; x++) {
    markBg(x, 0);
    markBg(x, H - 1);
    for (let y = 0; y < 28; y++) markBg(x, y);
    for (let y = 1362; y < H; y++) markBg(x, y);
  }
  for (let y = 0; y < H; y++) {
    markBg(0, y);
    markBg(W - 1, y);
    for (let x = 0; x < 195; x++) markBg(x, y);
    for (let x = 575; x < W; x++) markBg(x, y);
  }

  // Mark all pixels below skirt hem that are NOT inside leg/shoe envelopes
  for (let y = 1180; y <= 1362; y++) {
    for (let x = 195; x <= 575; x++) {
      const hem = skirtHem[x];
      const isBelowHem = (hem > 0 && y > hem) || (hem === 0);
      if (isBelowHem) {
        if (!isInsideLegOrShoe(x, y)) {
          markBg(x, y);
        }
      }
    }
  }

  // 4. Flood fill outer background into background candidates
  while (qHead < qTail) {
    const curr = queue[qHead++];
    const cx = curr % W;
    const cy = Math.floor(curr / W);

    const neighbors = [curr - 1, curr + 1, curr - W, curr + W];
    for (let k = 0; k < 4; k++) {
      const nIdx = neighbors[k];
      const nx = nIdx % W;
      const ny = Math.floor(nIdx / W);

      if (nx >= 0 && nx < W && ny >= 0 && ny < H && bgMask[nIdx] === 0) {
        if (isBgPixel(nx, ny)) {
          markBg(nx, ny);
        }
      }
    }
  }

  console.log(`Background pixels marked: ${qTail}`);

  // 5. Build alpha channel with soft anti-aliased edge
  const outRgba = new Uint8Array(W * H * 4);

  for (let y = 0; y < H; y++) {
    const [rL, gL, bL] = bgRowL[y];
    const [rR, gR, bR] = bgRowR[y];

    for (let x = 0; x < W; x++) {
      const idx = y * W + x;
      const idx3 = idx * 3;
      const idx4 = idx * 4;

      const r = rgb[idx3];
      const g = rgb[idx3 + 1];
      const b = rgb[idx3 + 2];

      if (bgMask[idx] === 1) {
        // Pure background -> transparent
        outRgba[idx4] = 0;
        outRgba[idx4 + 1] = 0;
        outRgba[idx4 + 2] = 0;
        outRgba[idx4 + 3] = 0;
        continue;
      }

      // Check distance to boundary for sub-pixel anti-aliasing
      let bgCount = 0;
      for (let dy = -1; dy <= 1; dy++) {
        for (let dx = -1; dx <= 1; dx++) {
          const ny = y + dy, nx = x + dx;
          if (ny >= 0 && ny < H && nx >= 0 && nx < W) {
            if (bgMask[ny * W + nx] === 1) bgCount++;
          }
        }
      }

      let alpha = 255;
      if (bgCount > 0) {
        const t = x / (W - 1);
        const expR = rL * (1 - t) + rR * t;
        const expG = gL * (1 - t) + gR * t;
        const expB = bL * (1 - t) + bR * t;
        const dist = Math.sqrt((r - expR) ** 2 + (g - expG) ** 2 + (b - expB) ** 2);
        if (dist < 32) {
          alpha = Math.round(Math.max(30, Math.min(255, (dist / 32) * 255)));
        } else {
          alpha = Math.round(255 - (bgCount / 9) * 40);
        }
      }

      outRgba[idx4] = r;
      outRgba[idx4 + 1] = g;
      outRgba[idx4 + 2] = b;
      outRgba[idx4 + 3] = alpha;
    }
  }

  // 6. Write to destination
  await sharp(outRgba, {
    raw: { width: W, height: H, channels: 4 }
  })
    .png()
    .toFile(destPublic);

  console.log(`Successfully generated flawless transparent PNG at: ${destPublic}`);
}

createFlawlessZoya().catch(console.error);
