const sharp = require('sharp');
const fs = require('fs');

async function testKeyer(inputPath, outputPath) {
  const { data, info } = await sharp(inputPath).raw().toBuffer({ resolveWithObject: true });
  const W = info.width;
  const H = info.height;

  // Sample background color from corners
  let bgR = 0, bgG = 0, bgB = 0, count = 0;
  const samplePts = [
    [5, 5], [W - 6, 5], [5, H - 6], [W - 6, H - 6],
    [5, Math.floor(H / 2)], [W - 6, Math.floor(H / 2)]
  ];
  for (const [x, y] of samplePts) {
    const idx = (y * W + x) * 3;
    bgR += data[idx];
    bgG += data[idx + 1];
    bgB += data[idx + 2];
    count++;
  }
  bgR /= count;
  bgG /= count;
  bgB /= count;
  console.log(`Input ${inputPath} - Sampled bg: (${bgR.toFixed(1)}, ${bgG.toFixed(1)}, ${bgB.toFixed(1)})`);

  const outRgba = new Uint8Array(W * H * 4);

  // We can measure color distance to the green background
  // Green background has G high, R moderate/high, B low, and G - B is very high (> 120)
  for (let y = 0; y < H; y++) {
    for (let x = 0; x < W; x++) {
      const idx3 = (y * W + x) * 3;
      const idx4 = (y * W + x) * 4;

      let r = data[idx3];
      let g = data[idx3 + 1];
      let b = data[idx3 + 2];

      const dr = r - bgR;
      const dg = g - bgG;
      const db = b - bgB;
      const dist = Math.sqrt(dr * dr + dg * dg + db * db);

      // Chroma metric: green excess over blue and red
      const gExcess = g - Math.max(r * 0.75, b * 1.2);

      let alpha = 255;
      if (dist < 45 || (g > 190 && b < 100 && gExcess > 40)) {
        alpha = 0;
      } else if (dist < 75) {
        // Soft transition edge
        alpha = Math.round(((dist - 45) / 30) * 255);
        // Despill fringe
        if (g > Math.max(r, b)) {
          g = Math.round((r + b) / 2);
        }
      } else {
        alpha = 255;
        // Minor despill for slight green bounce
        if (g > Math.max(r, b) && b < 140) {
          const maxRB = Math.max(r, b);
          g = Math.min(g, maxRB + 8);
        }
      }

      outRgba[idx4] = r;
      outRgba[idx4 + 1] = g;
      outRgba[idx4 + 2] = b;
      outRgba[idx4 + 3] = alpha;
    }
  }

  await sharp(outRgba, {
    raw: { width: W, height: H, channels: 4 }
  })
    .png()
    .toFile(outputPath);

  console.log(`Saved: ${outputPath}`);
}

async function run() {
  await testKeyer('src/assets/images/avatar_1_greenscreen_1793679037942.jpg', '/app/applet/public/assets/images/test_key_av1.png');
  await testKeyer('src/assets/images/avatar_2_greenscreen_1793679056206.jpg', '/app/applet/public/assets/images/test_key_av2.png');
  await testKeyer('src/assets/images/avatar_3_greenscreen_1793679076357.jpg', '/app/applet/public/assets/images/test_key_av3.png');
  await testKeyer('src/assets/images/avatar_7_greenscreen_1793679014639.jpg', '/app/applet/public/assets/images/test_key_av7.png');
}

run().catch(console.error);
