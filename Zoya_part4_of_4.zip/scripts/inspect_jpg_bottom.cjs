const sharp = require('sharp');

async function inspectJpgBottom() {
  const { data, info } = await sharp('pristine_sources/avatar_midnight_gold_zari_saree.jpg')
    .raw()
    .toBuffer({ resolveWithObject: true });

  const w = info.width;
  const h = info.height;

  // Let's inspect rows 1480 to 1535 around center (x=350..650)
  console.log('Inspecting pristine_sources/avatar_midnight_gold_zari_saree.jpg at y=1500..1535:');
  for (let y = 1500; y < h; y += 5) {
    let colors = [];
    for (let x = 400; x < 600; x += 15) {
      const idx = (y * w + x) * 3;
      colors.push(`[${data[idx]},${data[idx+1]},${data[idx+2]}]`);
    }
    console.log(`y=${y}:`, colors.slice(0, 7).join(' '));
  }

  // Also check source PNG: public/assets/aistudio/file_00000000c0d4821189e14bf178224f8d_f1687d5b.png
  const srcPng = await sharp('public/assets/aistudio/file_00000000c0d4821189e14bf178224f8d_f1687d5b.png')
    .raw()
    .toBuffer({ resolveWithObject: true });

  console.log('\nInspecting public/assets/aistudio/file_00000000c0d4821189e14bf178224f8d_f1687d5b.png:');
  for (let y = 1500; y < h; y += 5) {
    let alphas = [];
    for (let x = 400; x < 600; x += 15) {
      const idx = (y * w + x) * 4;
      alphas.push(`a=${srcPng.data[idx+3]}`);
    }
    console.log(`SRC y=${y}:`, alphas.slice(0, 7).join(' '));
  }
}

inspectJpgBottom().catch(console.error);
