const sharp = require('sharp');

async function findLoosePixelsA() {
  const { data, info } = await sharp('public/assets/images/avatars_3d/transparent/avatar_pastel_blue_knit_shorts.png')
    .raw()
    .toBuffer({ resolveWithObject: true });

  const w = info.width;
  const h = info.height;

  // Print any pixels where y > 950 and (x < 360 or x > 640)
  console.log('--- Checking outliers outside leg column (x < 360 or x > 630) for y > 950 ---');
  let outlierCount = 0;
  for (let y = 950; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const idx = (y * w + x) * 4;
      const a = data[idx + 3];
      if (a > 5) {
        if (x < 370 || x > 620) {
          outlierCount++;
          if (outlierCount <= 25) {
            console.log(`Outlier pixel at (${x}, ${y}): rgba=(${data[idx]}, ${data[idx+1]}, ${data[idx+2]}, ${a})`);
          }
        }
      }
    }
  }
  console.log('Total outliers outside [370..620] below y=950:', outlierCount);

  // Now let's check between the legs and right around the right leg
  // Right leg in image coordinates: avatar's right leg is on the LEFT of the image (x ~ 390..470), avatar's left leg is on the RIGHT of the image (x ~ 500..580).
  // Or in viewer's perspective: 'next to the right leg' might mean screen-right (x ~ 570..650) or avatar's right leg.
  // Let's check color of pixels on borders of legs!
  console.log('\n--- Checking dark/black or fringe pixels near ankles (y > 1400) ---');
  for (let y = 1400; y < h; y += 15) {
    const rowPixels = [];
    for (let x = 380; x < 600; x++) {
      const idx = (y * w + x) * 4;
      const a = data[idx + 3];
      if (a > 0) {
        const r = data[idx], g = data[idx+1], b = data[idx+2];
        // Check if very dark (black sliver)
        if (r < 50 && g < 50 && b < 50) {
          rowPixels.push(`dark@x=${x}(a=${a})`);
        }
      }
    }
    if (rowPixels.length > 0) {
      console.log(`y=${y}:`, rowPixels.slice(0, 8).join(', '));
    }
  }
}

findLoosePixelsA().catch(console.error);
