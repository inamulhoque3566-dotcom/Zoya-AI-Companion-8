/**
 * Quick Fixes Verification Script
 * Validates all 5 Phase 3 Quick Fixes with real executions and raw output.
 */
import fs from 'fs';
import path from 'path';
import http from 'http';
import { spawnSync } from 'child_process';
import { AgentAuthManager } from '../src/services/agent/agentAuth';
import { AgentPermissionGuard, agentPermissionGuard } from '../src/services/agent/agentPermissionGuard';
import { AgentToolExecutor } from '../src/services/agent/agentTools';
import { AgentCore } from '../src/services/agent/agentCore';

const WORKSPACE = path.join(process.cwd(), 'workspace', 'quick_fixes_sandbox');
if (!fs.existsSync(WORKSPACE)) {
  fs.mkdirSync(WORKSPACE, { recursive: true });
}

function realHttpRequest(options: {
  path: string;
  method?: string;
  headers?: Record<string, string>;
  body?: string;
}): Promise<{ statusCode: number; headers: http.IncomingHttpHeaders; body: string }> {
  return new Promise((resolve, reject) => {
    const req = http.request(
      {
        hostname: '127.0.0.1',
        port: 3000,
        path: options.path,
        method: options.method || 'GET',
        headers: options.headers || {},
      },
      (res) => {
        let body = '';
        res.on('data', (chunk) => (body += chunk));
        res.on('end', () => {
          resolve({
            statusCode: res.statusCode || 0,
            headers: res.headers,
            body,
          });
        });
      }
    );
    req.on('error', reject);
    if (options.body) {
      req.write(options.body);
    }
    req.end();
  });
}

async function runQuickFixes() {
  console.log('================================================================');
  console.log('⚡ RUNNING PHASE 3 QUICK FIXES VERIFICATION');
  console.log('================================================================\n');

  let passed = 0;
  let failed = 0;

  function assert(condition: boolean, title: string, details?: string) {
    if (condition) {
      console.log(`✅ PASS: ${title}`);
      passed++;
    } else {
      console.error(`❌ FAIL: ${title} - ${details || ''}`);
      failed++;
    }
  }

  const OWNER_PASSPHRASE = 'OwnerSecurePassphrase2026!';
  const setupCode = AgentAuthManager.getOrCreateSetupCode();
  try {
    AgentAuthManager.setOwnerPassphraseWithSetupCode(OWNER_PASSPHRASE, setupCode);
  } catch {}

  // -------------------------------------------------------------------
  // FIX 1: BOOTSTRAP REAL HTTP SOCKET & PAIRING CODE ENFORCEMENT
  // -------------------------------------------------------------------
  console.log('--- FIX 1: Bootstrap Real HTTP Requests & Loopback Distrust ---');

  // 1a. Real HTTP GET to /api/agent/auth/token WITHOUT pairing code
  const res1a = await realHttpRequest({ path: '/api/agent/auth/token' });
  console.log(`[1a Real HTTP Request without pairing code]:`);
  console.log(`   Status Code: ${res1a.statusCode}`);
  console.log(`   Response Body: ${res1a.body.trim()}`);
  assert(
    res1a.statusCode === 403 && res1a.body.includes('PAIRING_CODE_REQUIRED'),
    'Loopback without pairing code rejected with HTTP 403 PAIRING_CODE_REQUIRED'
  );

  // 1b. Real HTTP POST to obtain a fresh pairing code with owner passphrase
  const pairCodeRes = await realHttpRequest({
    path: '/api/agent/auth/pairing-code',
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
    },
    body: JSON.stringify({ passphrase: OWNER_PASSPHRASE }),
  });
  let pairData: any = {};
  try { pairData = JSON.parse(pairCodeRes.body); } catch {}
  const pairingCode = pairData.pairingCode;
  console.log(`[1b Obtained Pairing Code from /api/agent/auth/pairing-code]:`);
  console.log(`   Status Code: ${pairCodeRes.statusCode}`);
  console.log(`   Pairing Code: ${pairingCode}`);
  assert(pairCodeRes.statusCode === 200 && Boolean(pairingCode), 'Obtained one-time pairing code');

  // 1c. Real HTTP GET with valid single-use pairing code
  const res1c = await realHttpRequest({
    path: '/api/agent/auth/token',
    headers: { 'x-agent-pairing-code': pairingCode },
  });
  let tokenData: any = {};
  try { tokenData = JSON.parse(res1c.body); } catch {}
  console.log(`[1c Real HTTP Request with valid pairing code]:`);
  console.log(`   Status Code: ${res1c.statusCode}`);
  console.log(`   Response Body: ${res1c.body.trim()}`);
  assert(
    res1c.statusCode === 200 && tokenData.success === true && Boolean(tokenData.token),
    'Bootstrap with single-use pairing code returns token (HTTP 200)'
  );

  // 1d. Replay the consumed pairing code
  const res1d = await realHttpRequest({
    path: '/api/agent/auth/token',
    headers: { 'x-agent-pairing-code': pairingCode },
  });
  console.log(`[1d Real HTTP Request replaying consumed pairing code]:`);
  console.log(`   Status Code: ${res1d.statusCode}`);
  console.log(`   Response Body: ${res1d.body.trim()}`);
  assert(
    res1d.statusCode === 403 && res1d.body.includes('PAIRING_CODE_REQUIRED'),
    'Reused pairing code is rejected (single-use enforced)'
  );

  // -------------------------------------------------------------------
  // FIX 2: OS-LEVEL SECRET PROTECTION (as appuser with guard bypassed)
  // -------------------------------------------------------------------
  console.log('\n--- FIX 2: OS-Level Secret Protection as appuser (UID 1000) ---');

  // 2a. Run cat /root/.zoya/agent_user_secret.json as appuser
  const catProc = spawnSync('su', ['-s', '/bin/bash', 'appuser', '-c', 'cat /root/.zoya/agent_user_secret.json']);
  const catStderr = (catProc.stderr || '').toString().trim();
  const catStdout = (catProc.stdout || '').toString().trim();
  console.log(`[2a OS command: cat /root/.zoya/agent_user_secret.json]:`);
  console.log(`   Exit Code: ${catProc.status}`);
  console.log(`   Stderr: "${catStderr}"`);
  console.log(`   Stdout: "${catStdout}"`);
  assert(
    catProc.status !== 0 && catStderr.includes('Permission denied'),
    'OS denies appuser cat /root/.zoya/agent_user_secret.json (Permission denied)'
  );

  // 2b. Run ls /root/.zoya as appuser
  const lsProc = spawnSync('su', ['-s', '/bin/bash', 'appuser', '-c', 'ls /root/.zoya']);
  const lsStderr = (lsProc.stderr || '').toString().trim();
  const lsStdout = (lsProc.stdout || '').toString().trim();
  console.log(`[2b OS command: ls /root/.zoya]:`);
  console.log(`   Exit Code: ${lsProc.status}`);
  console.log(`   Stderr: "${lsStderr}"`);
  console.log(`   Stdout: "${lsStdout}"`);
  assert(
    lsProc.status !== 0 && lsStderr.includes('Permission denied'),
    'OS denies appuser ls /root/.zoya (Permission denied)'
  );

  // -------------------------------------------------------------------
  // FIX 3: SCRIPT-FILE BYPASS & APPROVAL SCRIPT PREVIEW
  // -------------------------------------------------------------------
  console.log('\n--- FIX 3: Script-File Bypass & Approval Content Preview ---');

  // 3a. Write python script that builds "/etc/passwd" via chr()
  const chrScriptFile = path.join(WORKSPACE, 'test_chr_passwd.py');
  fs.writeFileSync(
    chrScriptFile,
    `p = chr(47) + 'etc' + chr(47) + 'passwd'\nwith open(p) as f:\n    print(f.read()[:50])\n`,
    'utf8'
  );

  // Inspect the command via AgentPermissionGuard
  const guard = AgentPermissionGuard.getInstance();
  const chrInspection = guard.inspectCommand('python3 test_chr_passwd.py', WORKSPACE);
  console.log(`[3a chr() bypass script inspection]:`);
  console.log(`   Level: ${chrInspection.level}`);
  console.log(`   isBlocked: ${chrInspection.isBlocked}`);
  console.log(`   Reason: "${chrInspection.reason}"`);
  assert(
    chrInspection.level === 'BLOCKED' && chrInspection.isBlocked === true,
    'Script building "/etc/passwd" via chr() is detected and BLOCKED'
  );

  // Attempt real execution via AgentToolExecutor
  const executor = new AgentToolExecutor({
    workspaceRoot: WORKSPACE,
    commandTimeoutMs: 5000,
    maxOutputChars: 5000,
    autoApprove: true,
  });
  const execChrRes = await executor.executeTool('run_command', { command: 'python3 test_chr_passwd.py' });
  console.log(`[3a Real execution of chr() script via run_command]:`);
  console.log(`   Success: ${execChrRes.success}`);
  console.log(`   Error: "${execChrRes.error}"`);
  console.log(`   Output: "${execChrRes.output.slice(0, 90)}..."`);
  assert(
    execChrRes.success === false && execChrRes.error === 'SECURITY_BLOCKED',
    'Executing chr() bypass script is rejected with SECURITY_BLOCKED'
  );

  // 3b. Legitimate script: show content preview and SHA-256 in approval
  const legitScriptFile = path.join(WORKSPACE, 'legit_test.py');
  const legitContent = `print("Fibonacci demo")\na, b = 0, 1\nfor _ in range(6):\n    print(a, end=" ")\n    a, b = b, a + b\nprint()\n`;
  fs.writeFileSync(legitScriptFile, legitContent, 'utf8');

  const legitEval = guard.evaluateToolCall('run_command', { command: 'python3 legit_test.py' }, WORKSPACE);
  console.log(`[3b Legitimate script inspection for approval]:`);
  console.log(`   Level: ${legitEval.level}`);
  console.log(`   isBlocked: ${legitEval.isBlocked}`);
  console.log(`   Needs Approval: ${legitEval.needsApproval}`);
  console.log(`   Approval Warning/Details:\n${legitEval.warning}`);
  assert(
    legitEval.level === 'ASK_APPROVAL' &&
      Boolean(legitEval.warning) &&
      legitEval.warning!.includes('SHA-256:') &&
      legitEval.warning!.includes('SCRIPT PREVIEW') &&
      legitEval.warning!.includes('Fibonacci demo'),
    'Approval request includes SHA-256 hash and script content preview'
  );

  // -------------------------------------------------------------------
  // FIX 4: NETWORK ISOLATION (unshare -n)
  // -------------------------------------------------------------------
  console.log('\n--- FIX 4: Subprocess Outbound Network Isolation ---');

  // Subprocess ping test via isolated execution
  const pingProc = spawnSync('unshare', ['-n', '-S', '1000', '-G', '1000', 'ping', '-c', '1', '8.8.8.8']);
  const pingStderr = (pingProc.stderr || '').toString().trim();
  console.log(`[4a Outbound ping inside unshare -n namespace]:`);
  console.log(`   Exit Code: ${pingProc.status}`);
  console.log(`   Stderr: "${pingStderr}"`);
  assert(
    pingProc.status === 2 && pingStderr.includes('Network is unreachable'),
    'Outbound internet is blocked by kernel network namespace (Network is unreachable)'
  );

  // Subprocess curl localhost port 3000 test
  const curlProc = spawnSync('unshare', ['-n', '-S', '1000', '-G', '1000', 'curl', '-m', '1', 'http://127.0.0.1:3000']);
  const curlStderr = (curlProc.stderr || '').toString().trim();
  console.log(`[4b Localhost reachability inside unshare -n namespace]:`);
  console.log(`   Exit Code: ${curlProc.status}`);
  console.log(`   Stderr: "${curlStderr}"`);
  assert(
    curlProc.status === 7 && curlStderr.includes('connect'),
    'Localhost port 3000 is unreachable inside unshare -n namespace'
  );

  // -------------------------------------------------------------------
  // FIX 5: AGENT LOOP STEP ORDER (Plan step must come first)
  // -------------------------------------------------------------------
  console.log('\n--- FIX 5: Agent Loop Step Order ---');

  const agent = new AgentCore({
    workspaceRoot: WORKSPACE,
    maxRetries: 2,
    commandTimeoutMs: 10000,
    autoApprove: true,
  });

  const task = await agent.runTask('Write a python file called hello.py that prints Hello World, then run it.');
  console.log(`[5a Agent Task Result]:`);
  console.log(`   Status: ${task.status}`);
  console.log(`   Total Logged Steps: ${task.logs.length}`);
  console.log(`   Step Phases in Order:`);
  task.logs.forEach((log, idx) => {
    console.log(`     Step ${idx + 1} (${log.phase}): ${log.description.slice(0, 70)}...`);
  });

  const firstPhase = task.logs[0]?.phase;
  assert(
    firstPhase === 'plan',
    `First step phase is "plan" (Actual: "${firstPhase}")`
  );

  // -------------------------------------------------------------------
  // SUMMARY
  // -------------------------------------------------------------------
  console.log('\n================================================================');
  console.log(`QUICK FIXES SUMMARY: ${passed} PASSED, ${failed} FAILED`);
  console.log('================================================================');

  if (failed > 0) {
    process.exit(1);
  }
}

runQuickFixes().catch((err) => {
  console.error('Quick fixes suite crashed:', err);
  process.exit(1);
});
