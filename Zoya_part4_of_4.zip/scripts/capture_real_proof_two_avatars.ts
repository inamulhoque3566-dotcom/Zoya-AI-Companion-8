import { chromium } from 'playwright';
import path from 'path';
import fs from 'fs';

async function captureProofTwoAvatars() {
  console.log('=== LAUNCHING PLAYWRIGHT TO CAPTURE REAL PROOF SCREENSHOTS FOR COZY PASTEL & MIDNIGHT SAREE ===');
  fs.mkdirSync('proof_artifacts', { recursive: true });

  const browser = await chromium.launch({
    headless: true,
    args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage'],
  });

  const context = await browser.newContext({
    viewport: { width: 412, height: 915 },
    deviceScaleFactor: 2,
  });

  const page = await context.newPage();

  // 1. Cozy Pastel (avatar_pastel_blue_knit_shorts) on Home Screen
  console.log('1. Loading Home Screen with Avatar A (Cozy Pastel)...');
  await page.goto('http://localhost:3000/', { waitUntil: 'domcontentloaded' });
  await page.evaluate(() => {
    localStorage.setItem('zoya_selected_3d_avatar_id', 'avatar_pastel_blue_knit_shorts');
    localStorage.setItem('zoya_avatar_style', 'classic');
  });
  await page.reload({ waitUntil: 'networkidle' });
  await page.waitForTimeout(3500);

  await page.screenshot({ path: 'proof_artifacts/real_homescreen_avatar_a_cozy_pastel.png' });
  console.log('✓ Captured proof_artifacts/real_homescreen_avatar_a_cozy_pastel.png');

  // 2. Open Settings and capture Avatar A card
  console.log('2. Opening Settings modal to capture Cozy Pastel card...');
  const settingsBtn = page.locator('button:has(.lucide-settings), button[aria-label="Settings"]').first();
  if (await settingsBtn.isVisible()) {
    await settingsBtn.click();
  } else {
    await page.evaluate(() => {
      const btn = Array.from(document.querySelectorAll('button')).find(b => b.innerHTML.includes('lucide-settings'));
      if (btn) btn.click();
    });
  }
  await page.waitForTimeout(2000);

  // Navigate to avatar section if needed
  const avatarNavBtn = page.locator('button:has-text("3D अवतार"), button:has-text("Avatar")').first();
  if (await avatarNavBtn.isVisible()) {
    await avatarNavBtn.click();
    await page.waitForTimeout(1000);
  }

  const pastelCard = page.locator('text=Pastel Blue Knit & Pink Shorts, text=Cozy Pastel').first();
  if (await pastelCard.isVisible()) {
    await pastelCard.scrollIntoViewIfNeeded();
    await page.waitForTimeout(1000);
    const cardBox = pastelCard.locator('xpath=ancestor::div[contains(@class, "rounded")]').first();
    if (await cardBox.isVisible()) {
      await cardBox.screenshot({ path: 'proof_artifacts/real_settings_card_avatar_a_cozy_pastel.png' });
    } else {
      await page.screenshot({ path: 'proof_artifacts/real_settings_card_avatar_a_cozy_pastel.png' });
    }
  } else {
    await page.screenshot({ path: 'proof_artifacts/real_settings_card_avatar_a_cozy_pastel.png' });
  }
  console.log('✓ Captured proof_artifacts/real_settings_card_avatar_a_cozy_pastel.png');

  // 3. Locate Midnight Gold Zari Saree card in Settings
  console.log('3. Locating Midnight Gold Zari Saree card in Settings...');
  const sareeCard = page.locator('text=Midnight Black & Gold Zari Saree, text=Midnight Saree').first();
  if (await sareeCard.isVisible()) {
    await sareeCard.scrollIntoViewIfNeeded();
    await page.waitForTimeout(1000);
    const cardBox = sareeCard.locator('xpath=ancestor::div[contains(@class, "rounded")]').first();
    if (await cardBox.isVisible()) {
      await cardBox.screenshot({ path: 'proof_artifacts/real_settings_card_avatar_b_midnight_saree.png' });
    } else {
      await page.screenshot({ path: 'proof_artifacts/real_settings_card_avatar_b_midnight_saree.png' });
    }
    // Select it
    const selectBtn = sareeCard.locator('xpath=ancestor::div[contains(@class, "rounded")]//button').first();
    if (await selectBtn.isVisible()) {
      await selectBtn.click();
      await page.waitForTimeout(1000);
    }
  } else {
    await page.screenshot({ path: 'proof_artifacts/real_settings_card_avatar_b_midnight_saree.png' });
  }
  console.log('✓ Captured proof_artifacts/real_settings_card_avatar_b_midnight_saree.png');

  // 4. Midnight Gold Zari Saree on Home Screen
  console.log('4. Loading Home Screen with Avatar B (Midnight Saree)...');
  await page.evaluate(() => {
    localStorage.setItem('zoya_selected_3d_avatar_id', 'avatar_midnight_gold_zari_saree');
  });
  await page.reload({ waitUntil: 'networkidle' });
  await page.waitForTimeout(3500);

  await page.screenshot({ path: 'proof_artifacts/real_homescreen_avatar_b_midnight_saree.png' });
  console.log('✓ Captured proof_artifacts/real_homescreen_avatar_b_midnight_saree.png');

  await browser.close();
  console.log('=== PROOF SCREENSHOTS CAPTURED ===');
}

captureProofTwoAvatars().catch(err => {
  console.error('Error in captureProofTwoAvatars:', err);
  process.exit(1);
});
