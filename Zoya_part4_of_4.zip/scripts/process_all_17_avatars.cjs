const fs = require('fs');
const path = require('path');
const { processAvatarFlawless } = require('./universal_avatar_processor.cjs');

const AVATAR_TASKS = [
  // 7 New user uploaded avatars + Sapphire
  {
    id: 'boho_mini_dress',
    src: 'public/assets/aistudio/1794057080707_73517bc8.png',
    outPng: 'public/assets/images/avatars_3d/transparent/avatar_boho_mini_dress.png',
    fullJpg: 'public/assets/images/avatars_3d/avatar_boho_mini_dress.jpg',
  },
  {
    id: 'peasant_blouse_skirt',
    src: 'public/assets/aistudio/1794056986583_b7a662a3.png',
    outPng: 'public/assets/images/avatars_3d/transparent/avatar_peasant_blouse_skirt.png',
    fullJpg: 'public/assets/images/avatars_3d/avatar_peasant_blouse_skirt.jpg',
  },
  {
    id: 'lilac_tulle_ruffle',
    src: 'public/assets/aistudio/1794056527889_f4b10bae.png',
    outPng: 'public/assets/images/avatars_3d/transparent/avatar_lilac_tulle_ruffle.png',
    fullJpg: 'public/assets/images/avatars_3d/avatar_lilac_tulle_ruffle.jpg',
  },
  {
    id: 'pink_knit_maxi',
    src: 'public/assets/aistudio/1794056632068_9dccffa9.png',
    outPng: 'public/assets/images/avatars_3d/transparent/avatar_pink_knit_maxi.png',
    fullJpg: 'public/assets/images/avatars_3d/avatar_pink_knit_maxi.jpg',
  },
  {
    id: 'midnight_black_floral',
    src: 'public/assets/aistudio/1794057213070_1ed45c90.png',
    outPng: 'public/assets/images/avatars_3d/transparent/avatar_midnight_black_floral.png',
    fullJpg: 'public/assets/images/avatars_3d/avatar_midnight_black_floral.jpg',
  },
  {
    id: 'floral_palazzo_pants',
    src: 'public/assets/aistudio/1794056834343_4889389a.png',
    outPng: 'public/assets/images/avatars_3d/transparent/avatar_floral_palazzo_pants.png',
    fullJpg: 'public/assets/images/avatars_3d/avatar_floral_palazzo_pants.jpg',
  },
  {
    id: 'blush_pink_gown',
    src: 'public/assets/aistudio/1794056407655_d33eafd1.png',
    outPng: 'public/assets/images/avatars_3d/transparent/avatar_blush_pink_gown.png',
    fullJpg: 'public/assets/images/avatars_3d/avatar_blush_pink_gown.jpg',
  },
  {
    id: 'sapphire_celestial_gown',
    src: 'public/assets/aistudio/1794056299352_9ca40e49.png',
    outPng: 'public/assets/images/avatars_3d/transparent/avatar_sapphire_celestial_gown.png',
    fullJpg: 'public/assets/images/avatars_3d/avatar_sapphire_celestial_gown.jpg',
  },
  // Existing collection avatars
  {
    id: 'red_cardigan_floral',
    src: 'public/assets/images/avatars_3d/avatar_red_cardigan_floral.jpg',
    outPng: 'public/assets/images/avatars_3d/transparent/avatar_red_cardigan_floral.png',
  },
  {
    id: 'daisy_gingham',
    src: 'public/assets/images/avatars_3d/avatar_daisy_gingham.jpg',
    outPng: 'public/assets/images/avatars_3d/transparent/avatar_daisy_gingham.png',
  },
  {
    id: 'brown_scarf_tiered',
    src: 'public/assets/images/avatars_3d/avatar_brown_scarf_tiered.jpg',
    outPng: 'public/assets/images/avatars_3d/transparent/avatar_brown_scarf_tiered.png',
  },
  {
    id: 'plum_royal_anarkali',
    src: 'public/assets/images/avatars_3d/avatar_plum_royal_anarkali.jpg',
    outPng: 'public/assets/images/avatars_3d/transparent/avatar_plum_royal_anarkali.png',
  },
  {
    id: 'ivory_floral_anarkali',
    src: 'public/assets/images/avatars_3d/avatar_ivory_floral_anarkali.jpg',
    outPng: 'public/assets/images/avatars_3d/transparent/avatar_ivory_floral_anarkali.png',
  },
  {
    id: 'classic',
    src: 'public/assets/images/zoya_3d_sweater_glasses.jpg',
    outPng: 'public/assets/images/zoya_new_avatar_transparent.png',
  },
  {
    id: 'elegant_saree',
    src: 'public/assets/images/elegant_saree_avatar.jpg',
    outPng: 'public/assets/images/elegant_saree_avatar_transparent.png',
  },
          ];

async function main() {
  console.log(`Starting processing of ${AVATAR_TASKS.length} avatars...`);
  const sharp = require('sharp');
  for (const t of AVATAR_TASKS) {
    if (!fs.existsSync(t.src)) {
      console.warn(`Source missing: ${t.src}`);
      continue;
    }
    // Also copy fullJpg if needed
    if (t.fullJpg && !fs.existsSync(t.fullJpg)) {
      await sharp(t.src).jpeg({ quality: 95 }).toFile(t.fullJpg);
    }
    await processAvatarFlawless(t.src, t.outPng);
  }
  console.log('All avatars processed flawlessly!');
}

main().catch(console.error);
