const fs = require('fs');
const path = require('path');
const sharp = require('sharp');

const NEW_AVATARS = [
  {
    id: 'red_cardigan_floral',
    file: 'public/assets/aistudio/1793883596254_50a8f058.png',
    name: 'Red Cardigan & Floral Skirt',
    japaneseName: 'フレンチ カーディガン',
    tag: 'Chic Parisian',
    outfit: 'Red Knit Cardigan, White Lace Top & Floral Mini Skirt',
    desc: 'क्लासिक रेड निट कार्डिगन, वाइट लेस कैमी, फ्लोरल मिनी स्कर्ट, पर्ल नेकलेस, वाइट सॉक्स व रेड मैरी जेन हील्स।',
    eyeBox: { xPct: 0.50, yPct: 0.126, wPct: 0.22, hPct: 0.055 },
    neckY: 0.20,
    waistY: 0.36,
    hipY: 0.45,
    kneeY: 0.65,
    shoesY: 0.88,
  },
  {
    id: 'pink_knit_maxi',
    file: 'public/assets/aistudio/1793883380339_ae6c4ef2.png',
    name: 'Pink Knit & Cream Maxi',
    japaneseName: 'ピンク ニット マキシ',
    tag: 'Cozy Elegance',
    outfit: 'Dusty Mauve Crop Knit & Tiered Cream Maxi Skirt',
    desc: 'सॉफ्ट डस्टी मौवे क्रॉप्ड निट स्वेटर, हाई-वेस्टेड क्रीम फ्लोई मैक्सी स्कर्ट व न्यूड हील्स।',
    eyeBox: { xPct: 0.50, yPct: 0.115, wPct: 0.22, hPct: 0.055 },
    neckY: 0.19,
    waistY: 0.35,
    hipY: 0.44,
    kneeY: 0.65,
    shoesY: 0.90,
  },
  {
    id: 'daisy_gingham',
    file: 'public/assets/aistudio/1793883444975_4352873a.png',
    name: 'Sage Daisy Gingham Dress',
    japaneseName: 'デイジー ギンガム',
    tag: 'Cottagecore Daisy',
    outfit: 'Sage Green Gingham Tiered Dress & Daisy Braid',
    desc: 'सेज ग्रीन गिंगहैम टायर्ड सुंद्रेस, क्रॉसबॉडी बैग, डेज़ी हेयर क्लिप्स व फ्लोई समर स्टाइल।',
    eyeBox: { xPct: 0.54, yPct: 0.138, wPct: 0.22, hPct: 0.055 },
    neckY: 0.22,
    waistY: 0.42,
    hipY: 0.52,
    kneeY: 0.70,
    shoesY: 0.91,
  },
  {
    id: 'brown_scarf_tiered',
    file: 'public/assets/aistudio/1793883537447_d9b97d51.png',
    name: 'Boho Brown Scarf & Skirt',
    japaneseName: 'ボヘミアン スカーフ',
    tag: 'Autumn Bohemian',
    outfit: 'White Baby Crop Tee, Brown Fringe Scarf & Tiered Skirt',
    desc: 'वाइट क्रॉप टी, फ्रिंज्ड ब्राउन वूलन स्कार्फ, वेवी रिकरैक ट्रिम वाली ब्राउन टायर्ड स्कर्ट।',
    eyeBox: { xPct: 0.51, yPct: 0.118, wPct: 0.22, hPct: 0.055 },
    neckY: 0.20,
    waistY: 0.38,
    hipY: 0.46,
    kneeY: 0.68,
    shoesY: 0.89,
  },
  {
    id: 'plum_royal_anarkali',
    file: 'public/assets/aistudio/1793869903811_42e1b547.png',
    name: 'Royal Plum Zari Anarkali',
    japaneseName: 'ロイヤル プラム',
    tag: 'Heritage Royalty',
    outfit: 'Plum Zari Embroidered Anarkali Gown & Dupatta',
    desc: 'रॉयल प्लम वेलवेट-सिल्क अनारकली, स्वर्णिम जरी वर्क, मैचिंग फ्लोई दुपट्टा व झुमका ईयररिंग्स।',
    eyeBox: { xPct: 0.42, yPct: 0.182, wPct: 0.22, hPct: 0.055 },
    neckY: 0.25,
    waistY: 0.40,
    hipY: 0.50,
    kneeY: 0.70,
    shoesY: 0.92,
  },
  {
    id: 'ivory_floral_anarkali',
    file: 'public/assets/aistudio/1793869666658_42148b56.png',
    name: 'Ivory & Rose Floral Anarkali',
    japaneseName: 'アイボリー フローラル',
    tag: 'Graceful Pastel',
    outfit: 'Ivory Embroidered Anarkali with Rose Floral Dupatta',
    desc: 'एलिगेंट आइवरी चिकनकारी अनारकली, रोज़ पिंक फ्लोरल प्रिंटेड दुपट्टा व पर्ल नेकलेस।',
    eyeBox: { xPct: 0.50, yPct: 0.110, wPct: 0.22, hPct: 0.055 },
    neckY: 0.20,
    waistY: 0.38,
    hipY: 0.48,
    kneeY: 0.70,
    shoesY: 0.90,
  },
  {
    id: 'blush_pink_gown',
    file: 'public/assets/aistudio/1793869560293_4be065f2.png',
    name: 'Blush Pink Embroidered Gown',
    japaneseName: 'ブラッシュ ピンク',
    tag: 'Ethereal Romance',
    outfit: 'Blush Pink Embroidered Flared Gown with Tassels',
    desc: 'पेस्टल ब्लश पिंक जरी-थ्रेड एम्ब्रॉयडरी फ्लेयर्ड गाउन, डोरी टैसेल्स व मैचिंग सिल्क दुपट्टा।',
    eyeBox: { xPct: 0.48, yPct: 0.105, wPct: 0.22, hPct: 0.055 },
    neckY: 0.18,
    waistY: 0.38,
    hipY: 0.48,
    kneeY: 0.70,
    shoesY: 0.92,
  },
  {
    id: 'midnight_black_floral',
    file: 'public/assets/aistudio/1793870006620_fd914766.png',
    name: 'Midnight Black Tiered Dress',
    japaneseName: 'ミッドナイト フローラル',
    tag: 'Midnight Chiffon',
    outfit: 'Black Multi-Tiered Chiffon Maxi with Pink Florals',
    desc: 'मिडनाइट ब्लैक टायर्ड शिफॉन ड्रेस, पिंक फ्लोरल माइक्रो-प्रिंट्स, स्क्वायर नेकलाइन व हील्स।',
    eyeBox: { xPct: 0.50, yPct: 0.112, wPct: 0.22, hPct: 0.055 },
    neckY: 0.19,
    waistY: 0.38,
    hipY: 0.48,
    kneeY: 0.70,
    shoesY: 0.90,
  },
];

async function removeBackgroundStudio(inputPath) {
  const img = sharp(inputPath);
  const { data, info } = await img.raw().toBuffer({ resolveWithObject: true });
  const W = info.width, H = info.height;

  // 1. Build row background model from outer columns (x=2..12 and x=W-13..W-3)
  const bgRow = new Array(H);
  for (let y = 0; y < H; y++) {
    let r = 0, g = 0, b = 0, count = 0;
    for (let x = 2; x <= 12; x++) {
      const i1 = (y * W + x) * info.channels;
      const i2 = (y * W + (W - 1 - x)) * info.channels;
      r += data[i1] + data[i2];
      g += data[i1 + 1] + data[i2 + 1];
      b += data[i1 + 2] + data[i2 + 2];
      count += 2;
    }
    bgRow[y] = [r / count, g / count, b / count];
  }

  // 2. High-precision color distance metric to background gradient
  const isBgCandidate = (x, y) => {
    const idx = (y * W + x) * info.channels;
    const r = data[idx], g = data[idx + 1], b = data[idx + 2];
    const [bgR, bgG, bgB] = bgRow[y];
    const dr = r - bgR, dg = g - bgG, db = b - bgB;
    const dist = Math.sqrt(dr * dr + dg * dg + db * db);

    // Studio violet/navy background has B > R and B > G, and low brightness
    const isDarkViolet = b > r && b > g && (r < 45 && g < 40 && b < 100);
    return dist < 36 || (dist < 48 && isDarkViolet);
  };

  const isBg = new Uint8Array(W * H);
  const queue = new Int32Array(W * H);
  let qHead = 0, qTail = 0;

  // Seed all 4 outer borders
  for (let x = 0; x < W; x++) {
    if (isBgCandidate(x, 0)) { isBg[x] = 1; queue[qTail++] = x; }
    const botIdx = (H - 1) * W + x;
    if (isBgCandidate(x, H - 1)) { isBg[botIdx] = 1; queue[qTail++] = botIdx; }
  }
  for (let y = 0; y < H; y++) {
    const lIdx = y * W;
    if (isBgCandidate(0, y)) { isBg[lIdx] = 1; queue[qTail++] = lIdx; }
    const rIdx = y * W + (W - 1);
    if (isBgCandidate(W - 1, y)) { isBg[rIdx] = 1; queue[qTail++] = rIdx; }
  }

  // BFS flood fill
  const dx = [-1, 1, 0, 0];
  const dy = [0, 0, -1, 1];
  while (qHead < qTail) {
    const curr = queue[qHead++];
    const cx = curr % W;
    const cy = Math.floor(curr / W);

    for (let i = 0; i < 4; i++) {
      const nx = cx + dx[i];
      const ny = cy + dy[i];
      if (nx >= 0 && nx < W && ny >= 0 && ny < H) {
        const nIdx = ny * W + nx;
        if (!isBg[nIdx] && isBgCandidate(nx, ny)) {
          isBg[nIdx] = 1;
          queue[qTail++] = nIdx;
        }
      }
    }
  }

  // Also check interior gaps (e.g., between legs or armpits) that match background color exactly
  for (let y = Math.floor(H * 0.4); y < H - 20; y++) {
    for (let x = Math.floor(W * 0.25); x < Math.floor(W * 0.75); x++) {
      const idx = y * W + x;
      if (!isBg[idx]) {
        const idxC = idx * info.channels;
        const r = data[idxC], g = data[idxC + 1], b = data[idxC + 2];
        const [bgR, bgG, bgB] = bgRow[y];
        const dist = Math.sqrt((r - bgR) ** 2 + (g - bgG) ** 2 + (b - bgB) ** 2);
        // If it matches background closely and has dark violet tint, fill it
        if (dist < 26 && b > r && b > g) {
          // Flood fill this enclosed pocket
          let pocketHead = 0, pocketTail = 0;
          const pocketQ = [idx];
          isBg[idx] = 1;
          while (pocketHead < pocketQ.length) {
            const pcurr = pocketQ[pocketHead++];
            const px = pcurr % W;
            const py = Math.floor(pcurr / W);
            for (let i = 0; i < 4; i++) {
              const pnx = px + dx[i];
              const pny = py + dy[i];
              if (pnx >= 0 && pnx < W && pny >= 0 && pny < H) {
                const pnIdx = pny * W + pnx;
                if (!isBg[pnIdx]) {
                  const pnC = pnIdx * info.channels;
                  const pr = data[pnC], pg = data[pnC + 1], pb = data[pnC + 2];
                  const [pbgR, pbgG, pbgB] = bgRow[pny];
                  const pdist = Math.sqrt((pr - pbgR) ** 2 + (pg - pbgG) ** 2 + (pb - pbgB) ** 2);
                  if (pdist < 32 && pb > pr && pb > pg) {
                    isBg[pnIdx] = 1;
                    pocketQ.push(pnIdx);
                  }
                }
              }
            }
          }
        }
      }
    }
  }

  // 3. Alpha edge smoothing / soft feathering
  const alphaMap = new Uint8Array(W * H);
  for (let y = 0; y < H; y++) {
    for (let x = 0; x < W; x++) {
      const idx = y * W + x;
      if (isBg[idx]) {
        alphaMap[idx] = 0;
      } else {
        // Check if on boundary
        let bgNeighbor = false;
        for (let i = 0; i < 4; i++) {
          const nx = x + dx[i];
          const ny = y + dy[i];
          if (nx >= 0 && nx < W && ny >= 0 && ny < H && isBg[ny * W + nx]) {
            bgNeighbor = true;
            break;
          }
        }
        alphaMap[idx] = bgNeighbor ? 180 : 255;
      }
    }
  }

  // Assemble RGBA with color despill on edge
  const outRgba = new Uint8Array(W * H * 4);
  for (let y = 0; y < H; y++) {
    for (let x = 0; x < W; x++) {
      const idx = y * W + x;
      const idxC = idx * info.channels;
      const idx4 = idx * 4;
      let r = data[idxC], g = data[idxC + 1], b = data[idxC + 2];
      const a = alphaMap[idx];

      if (a > 0 && a < 255) {
        // Despill slight background blue tinge
        if (b > Math.max(r, g)) {
          b = Math.round((r + g) / 2);
        }
      }

      outRgba[idx4] = r;
      outRgba[idx4 + 1] = g;
      outRgba[idx4 + 2] = b;
      outRgba[idx4 + 3] = a;
    }
  }

  return { rgbaBuffer: outRgba, width: W, height: H, rawRgb: data, channels: info.channels };
}

// Generate eyelid closed blendshape overlay for natural eye blinking
async function generateEyesClosedOverlay(rgbaBuffer, W, H, eyeBox, outPath) {
  const eyeCenterX = Math.round(eyeBox.xPct * W);
  const eyeCenterY = Math.round(eyeBox.yPct * H);
  const eyeW = Math.round(eyeBox.wPct * W);
  const eyeH = Math.round(eyeBox.hPct * H);

  const startX = Math.max(0, eyeCenterX - Math.floor(eyeW / 2));
  const startY = Math.max(0, eyeCenterY - Math.floor(eyeH / 2));
  const endX = Math.min(W - 1, startX + eyeW);
  const endY = Math.min(H - 1, startY + eyeH);
  const cropW = endX - startX;
  const cropH = endY - startY;

  const eyeRgba = new Uint8Array(cropW * cropH * 4);

  // Sample skin tone above eyelid to paint closed eyelids
  let skinR = 240, skinG = 205, skinB = 195;
  let count = 0;
  for (let y = Math.max(0, startY - 8); y < startY; y++) {
    for (let x = startX + 10; x < endX - 10; x++) {
      const idx = (y * W + x) * 4;
      skinR += rgbaBuffer[idx];
      skinG += rgbaBuffer[idx + 1];
      skinB += rgbaBuffer[idx + 2];
      count++;
    }
  }
  if (count > 0) {
    skinR = Math.round(skinR / count);
    skinG = Math.round(skinG / count);
    skinB = Math.round(skinB / count);
  }

  for (let cy = 0; cy < cropH; cy++) {
    const y = startY + cy;
    for (let cx = 0; cx < cropW; cx++) {
      const x = startX + cx;
      const srcIdx = (y * W + x) * 4;
      const dstIdx = (cy * cropW + cx) * 4;

      const r = rgbaBuffer[srcIdx];
      const g = rgbaBuffer[srcIdx + 1];
      const b = rgbaBuffer[srcIdx + 2];
      const a = rgbaBuffer[srcIdx + 3];

      // Eyelid line is horizontal curve with dark eyelashes
      const relY = cy / cropH; // 0..1
      const isEyelash = (relY >= 0.42 && relY <= 0.62) && (r < 75 && g < 55 && b < 55);

      // Radial feathering toward edges
      const distFromCenter = Math.hypot((cx - cropW / 2) / (cropW / 2), (cy - cropH / 2) / (cropH / 2));
      const featherAlpha = Math.max(0, Math.min(1, 1 - (distFromCenter - 0.4) / 0.6));

      if (a > 0 && featherAlpha > 0) {
        if (isEyelash) {
          // Closed lash line
          eyeRgba[dstIdx] = Math.round(r * 0.7);
          eyeRgba[dstIdx + 1] = Math.round(g * 0.7);
          eyeRgba[dstIdx + 2] = Math.round(b * 0.7);
          eyeRgba[dstIdx + 3] = Math.round(255 * featherAlpha);
        } else if (relY >= 0.15 && relY <= 0.85) {
          // Soft closed eyelid skin
          eyeRgba[dstIdx] = Math.round(skinR * 0.98);
          eyeRgba[dstIdx + 1] = Math.round(skinG * 0.96);
          eyeRgba[dstIdx + 2] = Math.round(skinB * 0.95);
          eyeRgba[dstIdx + 3] = Math.round(245 * featherAlpha);
        } else {
          eyeRgba[dstIdx + 3] = 0;
        }
      } else {
        eyeRgba[dstIdx + 3] = 0;
      }
    }
  }

  await sharp(eyeRgba, { raw: { width: cropW, height: cropH, channels: 4 } })
    .png()
    .toFile(outPath);

  return { cropW, cropH, eyeCenterX, eyeCenterY };
}

async function main() {
  console.log('=== CREATING FULL HD 3D ANIMATED AVATARS FROM REFERENCE PHOTOS ===');

  fs.mkdirSync('public/assets/images/avatars_3d/transparent', { recursive: true });

  const generatedConfigs = [];

  for (const config of NEW_AVATARS) {
    console.log(`\nProcessing avatar: ${config.id} (${config.name})...`);
    const { rgbaBuffer, width: W, height: H, rawRgb, channels } = await removeBackgroundStudio(config.file);

    // 1. Save Full HD Transparent PNG
    const transparentPath = `public/assets/images/avatars_3d/transparent/avatar_${config.id}.png`;
    await sharp(rgbaBuffer, { raw: { width: W, height: H, channels: 4 } })
      .png({ quality: 100, compressionLevel: 8 })
      .toFile(transparentPath);
    console.log(`  -> Saved transparent avatar: ${transparentPath}`);

    // 2. Save Full HD JPG Preview Thumbnail
    const jpgPath = `public/assets/images/avatars_3d/avatar_${config.id}.jpg`;
    await sharp(config.file)
      .jpeg({ quality: 95 })
      .toFile(jpgPath);
    console.log(`  -> Saved preview thumbnail: ${jpgPath}`);

    // 3. Create Modular Directory
    const modularDir = `public/assets/images/avatars_modular/${config.id}`;
    fs.mkdirSync(modularDir, { recursive: true });

    // 4. Save body_skin.png (Base unbroken body & outfit)
    const bodySkinPath = `${modularDir}/body_skin.png`;
    await sharp(rgbaBuffer, { raw: { width: W, height: H, channels: 4 } })
      .png({ quality: 100 })
      .toFile(bodySkinPath);

    // 5. Generate Segments for outfit_top, outfit_bottom, outfit_shoes
    const topYPx = Math.round(config.neckY * H);
    const waistYPx = Math.round(config.waistY * H);
    const hipYPx = Math.round(config.hipY * H);
    const kneeYPx = Math.round(config.kneeY * H);
    const shoesYPx = Math.round(config.shoesY * H);

    const topRgba = new Uint8Array(W * H * 4);
    const bottomRgba = new Uint8Array(W * H * 4);
    const shoesRgba = new Uint8Array(W * H * 4);

    for (let y = 0; y < H; y++) {
      for (let x = 0; x < W; x++) {
        const idx = (y * W + x) * 4;
        const a = rgbaBuffer[idx + 3];
        if (a === 0) continue;

        if (y >= topYPx && y < waistYPx) {
          topRgba[idx] = rgbaBuffer[idx];
          topRgba[idx + 1] = rgbaBuffer[idx + 1];
          topRgba[idx + 2] = rgbaBuffer[idx + 2];
          topRgba[idx + 3] = a;
        } else if (y >= waistYPx && y < shoesYPx) {
          bottomRgba[idx] = rgbaBuffer[idx];
          bottomRgba[idx + 1] = rgbaBuffer[idx + 1];
          bottomRgba[idx + 2] = rgbaBuffer[idx + 2];
          bottomRgba[idx + 3] = a;
        } else if (y >= shoesYPx) {
          shoesRgba[idx] = rgbaBuffer[idx];
          shoesRgba[idx + 1] = rgbaBuffer[idx + 1];
          shoesRgba[idx + 2] = rgbaBuffer[idx + 2];
          shoesRgba[idx + 3] = a;
        }
      }
    }

    await sharp(topRgba, { raw: { width: W, height: H, channels: 4 } }).png().toFile(`${modularDir}/outfit_top.png`);
    await sharp(bottomRgba, { raw: { width: W, height: H, channels: 4 } }).png().toFile(`${modularDir}/outfit_bottom.png`);
    await sharp(shoesRgba, { raw: { width: W, height: H, channels: 4 } }).png().toFile(`${modularDir}/outfit_shoes.png`);

    // 6. Generate Eye Blinking Overlay
    const eyeRes = await generateEyesClosedOverlay(rgbaBuffer, W, H, config.eyeBox, `${modularDir}/eyes_closed.png`);
    console.log(`  -> Generated eyelid blendshape: ${modularDir}/eyes_closed.png (${eyeRes.cropW}x${eyeRes.cropH})`);

    generatedConfigs.push({
      ...config,
      width: W,
      height: H,
      aspectRatio: W / H,
      eyeRes,
    });
  }

  // Save manifest of generated avatars for quick integration
  fs.writeFileSync('public/assets/images/avatars_modular/generated_manifest.json', JSON.stringify(generatedConfigs, null, 2));
  console.log('\n=== ALL 8 FULL HD 3D AVATARS SUCCESSFULLY CREATED ===');
}

main().catch(console.error);
