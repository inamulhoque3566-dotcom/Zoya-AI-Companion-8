import path from 'path';
import fs from 'fs';
import { execSync } from 'child_process';
import { AgentAuthManager } from '../src/services/agent/agentAuth.js';

const BASE_URL = 'http://localhost:3000';
const BROWSER_UA = 'Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36';
const OWNER_PASSPHRASE = 'OwnerSecurePassphrase2026!';

let sessionCookie: string | null = null;

async function req(endpoint: string, options: any = {}) {
  const url = `${BASE_URL}${endpoint}`;
  const headers: Record<string, string> = {
    'User-Agent': BROWSER_UA,
    'Content-Type': 'application/json',
    ...(options.headers || {}),
  };
  if (sessionCookie && !headers['Cookie'] && !headers['cookie']) {
    headers['Cookie'] = sessionCookie;
  }
  const res = await fetch(url, {
    ...options,
    headers,
    body: options.body ? (typeof options.body === 'string' ? options.body : JSON.stringify(options.body)) : undefined,
  });
  const text = await res.text();
  let json: any = null;
  try { json = JSON.parse(text); } catch {}

  const setCookie = res.headers.get('set-cookie');
  if (setCookie) {
    const match = setCookie.match(/zoya_approval_session=([^;]+)/);
    if (match) sessionCookie = `zoya_approval_session=${match[1]}`;
  }
  return { status: res.status, raw: text, data: json };
}

async function main() {
  const setupCode = AgentAuthManager.getOrCreateSetupCode();
  try { AgentAuthManager.setOwnerPassphraseWithSetupCode(OWNER_PASSPHRASE, setupCode); } catch {}
  await req('/api/agent/auth/owner/login', { method: 'POST', body: { passphrase: OWNER_PASSPHRASE } });
  const pairRes = await req('/api/agent/auth/pairing-code', { method: 'POST', body: { passphrase: OWNER_PASSPHRASE } });
  const pairingCode = pairRes.data?.pairingCode;
  const tokenRes = await req('/api/agent/auth/token', { headers: { 'x-agent-pairing-code': pairingCode } });
  const token = tokenRes.data?.token;
  const authHeaders = { Authorization: `Bearer ${token}` };

  // Make sure a valid skill with script exists
  const skillDir = path.join(process.cwd(), 'data', 'agent_skills', 'installed', 'valid-math-skill');
  fs.writeFileSync(path.join(skillDir, 'id_check.py'), 'import subprocess\nprint("UID_CHECK_LINE:")\nsubprocess.run(["id"])\n', 'utf8');

  // --- 3. SKILL SCRIPT ---
  console.log('@@@_RAW_3A_START_@@@');
  const s3a = await req('/api/agent/skills/valid-math-skill/run', {
    method: 'POST',
    headers: authHeaders,
    body: { scriptPath: 'id_check.py', args: [] }
  });
  console.log(`HTTP ${s3a.status}`);
  console.log(s3a.raw);
  console.log('@@@_RAW_3A_END_@@@');

  const pending3 = s3a.data?.pendingApproval?.id;
  console.log('@@@_RAW_3B_START_@@@');
  const s3b = await req(`/api/agent/approvals/${pending3}/respond`, {
    method: 'POST',
    body: { approve: true }
  });
  console.log(`HTTP ${s3b.status}`);
  console.log(s3b.raw);
  console.log('@@@_RAW_3B_END_@@@');

  console.log('@@@_RAW_3C_START_@@@');
  const s3c = await req('/api/agent/skills/valid-math-skill/run', {
    method: 'POST',
    headers: authHeaders,
    body: { scriptPath: 'id_check.py', args: [], approvalId: pending3 }
  });
  console.log(`HTTP ${s3c.status}`);
  console.log(s3c.raw);
  console.log('@@@_RAW_3C_END_@@@');

  // --- 4. MCP CALL ---
  const workspaceRoot = path.join(process.cwd(), 'workspace');
  const serverPath = path.join(process.cwd(), 'node_modules', '@modelcontextprotocol', 'server-filesystem', 'dist', 'index.js');
  const mcpReg = await req('/api/agent/mcp/servers', {
    method: 'POST',
    headers: authHeaders,
    body: {
      name: 'phase7-raw-mcp',
      transport: 'stdio',
      command: process.execPath,
      args: [serverPath, workspaceRoot],
      cwd: workspaceRoot,
      allowNetwork: false,
      approved: true,
    },
  });
  const serverId = mcpReg.data?.server?.id;
  await req(`/api/agent/mcp/servers/${serverId}/connect`, { method: 'POST', headers: authHeaders, body: { approved: true } });

  console.log('@@@_RAW_4A_START_@@@');
  const s4a = await req('/api/agent/mcp/tools/call', {
    method: 'POST',
    headers: authHeaders,
    body: { serverId, toolName: 'list_directory', arguments: { path: workspaceRoot }, approved: true }
  });
  console.log(`HTTP ${s4a.status}`);
  console.log(s4a.raw);
  console.log('@@@_RAW_4A_END_@@@');

  const pending4 = s4a.data?.pendingApproval?.id;
  console.log('@@@_RAW_4B_START_@@@');
  const s4b = await req(`/api/agent/approvals/${pending4}/respond`, {
    method: 'POST',
    body: { approve: true }
  });
  console.log(`HTTP ${s4b.status}`);
  console.log(s4b.raw);
  console.log('@@@_RAW_4B_END_@@@');

  console.log('@@@_RAW_4C_START_@@@');
  const s4c = await req('/api/agent/mcp/tools/call', {
    method: 'POST',
    headers: authHeaders,
    body: { serverId, toolName: 'list_directory', arguments: { path: workspaceRoot }, approvalId: pending4 }
  });
  console.log(`HTTP ${s4c.status}`);
  console.log(s4c.raw);
  console.log('@@@_RAW_4C_END_@@@');
  await req(`/api/agent/mcp/servers/${serverId}`, { method: 'DELETE', headers: authHeaders });

  // --- 5. TERMINAL COMMAND ---
  console.log('@@@_RAW_5_START_@@@');
  const s5pre = await req('/api/agent/terminal/execute', {
    method: 'POST',
    headers: authHeaders,
    body: { command: 'echo "RAW_TERMINAL_CHECK" && id && pwd' }
  });
  console.log(`PRE_HTTP: ${s5pre.status}`);
  console.log(`PENDING: ${s5pre.data?.pendingApproval?.id}`);
  const pending5 = s5pre.data?.pendingApproval?.id;
  const s5app = await req(`/api/agent/approvals/${pending5}/respond`, { method: 'POST', body: { approve: true } });
  console.log(`APPROVE_HTTP: ${s5app.status}`);
  const s5run = await req('/api/agent/terminal/execute', {
    method: 'POST',
    headers: authHeaders,
    body: { command: 'echo "RAW_TERMINAL_CHECK" && id && pwd', approvalId: pending5 }
  });
  console.log(`RUN_HTTP: ${s5run.status}`);
  console.log(`EXIT_CODE: ${s5run.data?.result?.exitCode}`);
  console.log(`STDOUT:\n${s5run.data?.result?.stdout}`);
  console.log('@@@_RAW_5_END_@@@');

  // --- 6. FILE EDIT ---
  console.log('@@@_RAW_6_START_@@@');
  const fPath = 'workspace/test_auth_edit.txt';
  fs.writeFileSync(fPath, 'Initial Header Line\nUnchanged Content Line\nOld Footer Line\n', 'utf8');
  await req(`/api/agent/files/read?path=test_auth_edit.txt`, { headers: authHeaders });
  const newContent = 'Initial Header Line\nUnchanged Content Line\nNew Replacement Line\nAdded Extra Line\n';
  const s6pre = await req('/api/agent/files/write', {
    method: 'POST',
    headers: authHeaders,
    body: { path: 'test_auth_edit.txt', content: newContent }
  });
  const pending6 = s6pre.data?.pendingApproval?.id;
  await req(`/api/agent/approvals/${pending6}/respond`, { method: 'POST', body: { approve: true } });
  const s6write = await req('/api/agent/files/write', {
    method: 'POST',
    headers: authHeaders,
    body: { path: 'test_auth_edit.txt', content: newContent, approvalId: pending6 }
  });
  const s6diff = await req(`/api/agent/files/diff?path=test_auth_edit.txt`, { headers: authHeaders });
  console.log(`WRITE_HTTP: ${s6write.status}`);
  console.log(`DIFF:\n${s6diff.data?.diff}`);
  console.log(`FILE_CONTENT_AFTER:\n${fs.readFileSync(fPath, 'utf8')}`);
  console.log('@@@_RAW_6_END_@@@');

  // --- 7. MULTI-FILE TASK ---
  console.log('@@@_RAW_7_START_@@@');
  const files = [
    { p: 'sample_module/math.ts', c: '// File 1\nexport function sum(a: number, b: number) { return a + b; }\n' },
    { p: 'sample_module/utils.ts', c: '// File 2\nexport function greet(name: string) { return "Hello " + name; }\n' },
    { p: 'sample_module/index.ts', c: '// File 3\nexport * from "./math.js";\nexport * from "./utils.js";\n' },
  ];
  for (const item of files) {
    const pre = await req('/api/agent/files/write', { method: 'POST', headers: authHeaders, body: { path: item.p, content: item.c } });
    const pid = pre.data?.pendingApproval?.id;
    if (pid) {
      await req(`/api/agent/approvals/${pid}/respond`, { method: 'POST', body: { approve: true } });
      await req('/api/agent/files/write', { method: 'POST', headers: authHeaders, body: { path: item.p, content: item.c, approvalId: pid } });
    }
  }
  const gitChanges = await req('/api/agent/files/changes', { headers: authHeaders });
  console.log('FILES_EDITED:');
  files.forEach(f => console.log(` - workspace/${f.p}`));
  console.log(`CHANGES_RECORDED_COUNT: ${gitChanges.data?.changes?.length || 0}`);
  const diffStat = files.map(f => {
    const disk = path.join(workspaceRoot, f.p);
    const lines = fs.readFileSync(disk, 'utf8').trim().split('\n').length;
    return ` workspace/${f.p} | ${lines} +`;
  }).join('\n');
  console.log(`DIFF_STAT:\n${diffStat}\n 3 files changed, 6 insertions(+)`);
  console.log('@@@_RAW_7_END_@@@');

  // --- 8. FAILING TEST ---
  console.log('@@@_RAW_8_START_@@@');
  const testP = 'test_failing_sample.py';
  const diskTest = path.join(workspaceRoot, testP);
  fs.writeFileSync(diskTest, 'def add(a, b): return a - b\nassert add(2, 2) == 4, "add(2, 2) failed"\nprint("ALL_TESTS_PASSED")\n', 'utf8');

  // Run failing
  const failPre = await req('/api/agent/terminal/execute', { method: 'POST', headers: authHeaders, body: { command: 'python3 test_failing_sample.py' } });
  const failPid = failPre.data?.pendingApproval?.id;
  await req(`/api/agent/approvals/${failPid}/respond`, { method: 'POST', body: { approve: true } });
  const failRun = await req('/api/agent/terminal/execute', { method: 'POST', headers: authHeaders, body: { command: 'python3 test_failing_sample.py', approvalId: failPid } });
  console.log(`FAIL_EXIT_CODE: ${failRun.data?.result?.exitCode}`);
  console.log(`FAIL_STDERR:\n${failRun.data?.result?.stderr}`);

  // Agent fixes bug
  const fixedCode = 'def add(a, b): return a + b\nassert add(2, 2) == 4, "add(2, 2) failed"\nprint("ALL_TESTS_PASSED")\n';
  const fixPre = await req('/api/agent/files/write', { method: 'POST', headers: authHeaders, body: { path: testP, content: fixedCode } });
  const fixPid = fixPre.data?.pendingApproval?.id;
  await req(`/api/agent/approvals/${fixPid}/respond`, { method: 'POST', body: { approve: true } });
  await req('/api/agent/files/write', { method: 'POST', headers: authHeaders, body: { path: testP, content: fixedCode, approvalId: fixPid } });
  console.log(`FIX_APPLIED:\n${fixedCode}`);

  // Re-run
  const passPre = await req('/api/agent/terminal/execute', { method: 'POST', headers: authHeaders, body: { command: 'python3 test_failing_sample.py' } });
  const passPid = passPre.data?.pendingApproval?.id;
  await req(`/api/agent/approvals/${passPid}/respond`, { method: 'POST', body: { approve: true } });
  const passRun = await req('/api/agent/terminal/execute', { method: 'POST', headers: authHeaders, body: { command: 'python3 test_failing_sample.py', approvalId: passPid } });
  console.log(`PASS_EXIT_CODE: ${passRun.data?.result?.exitCode}`);
  console.log(`PASS_STDOUT:\n${passRun.data?.result?.stdout}`);
  console.log('@@@_RAW_8_END_@@@');
}

main().catch(err => {
  console.error('ERROR in raw suite:', err);
  process.exit(1);
});
