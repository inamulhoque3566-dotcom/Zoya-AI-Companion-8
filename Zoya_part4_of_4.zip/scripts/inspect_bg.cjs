const sharp = require('sharp');
const path = require('path');

async function inspect() {
  const src = path.join(__dirname, '../src/assets/images/zoya_3d_sweater_glasses_1793764031303.jpg');
  const { data, info } = await sharp(src).removeAlpha().raw().toBuffer({ resolveWithObject: true });
  const W = info.width, H = info.height;
  console.log('Size:', W, 'x', H);
  
  for (const y of [10, 100, 300, 500, 700, 900, 1100, 1200, 1300, 1360]) {
    const iL = (y * W + 10) * 3;
    const iR = (y * W + W - 11) * 3;
    console.log('y=' + y + ': Left [' + data[iL] + ',' + data[iL+1] + ',' + data[iL+2] + '] Right [' + data[iR] + ',' + data[iR+1] + ',' + data[iR+2] + ']');
  }
}
inspect().catch(console.error);
