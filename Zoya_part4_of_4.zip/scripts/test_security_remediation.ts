import fs from 'fs';
import path from 'path';
import http from 'http';
import { spawnSync } from 'child_process';
import { AgentAuthManager } from '../src/services/agent/agentAuth.ts';
import { AgentPermissionGuard } from '../src/services/agent/agentPermissionGuard.ts';
import { AgentToolExecutor } from '../src/services/agent/agentTools.ts';

const TEST_WORKSPACE = path.join(process.cwd(), 'workspace');
if (!fs.existsSync(TEST_WORKSPACE)) {
  fs.mkdirSync(TEST_WORKSPACE, { recursive: true });
}

function realHttpRequest(options: {
  path: string;
  method?: string;
  headers?: Record<string, string>;
}): Promise<{ statusCode: number; headers: http.IncomingHttpHeaders; body: string }> {
  return new Promise((resolve, reject) => {
    const req = http.request(
      {
        hostname: '127.0.0.1',
        port: 3000,
        path: options.path,
        method: options.method || 'GET',
        headers: options.headers || {},
      },
      (res) => {
        let body = '';
        res.on('data', (chunk) => (body += chunk));
        res.on('end', () => {
          resolve({
            statusCode: res.statusCode || 0,
            headers: res.headers,
            body,
          });
        });
      }
    );
    req.on('error', reject);
    req.end();
  });
}

async function runRemediationVerification() {
  console.log('========================================================================================');
  console.log('🛡️ RUNNING COMPREHENSIVE SECURITY REMEDIATION VERIFICATION (UPDATED)');
  console.log('========================================================================================\n');

  let passed = 0;
  let failed = 0;

  function assert(condition: boolean, title: string, details?: string) {
    if (condition) {
      console.log(`✅ PASS: ${title}`);
      passed++;
    } else {
      console.error(`❌ FAIL: ${title} - ${details || ''}`);
      failed++;
    }
  }

  const guard = AgentPermissionGuard.getInstance();
  const executor = new AgentToolExecutor({
    workspaceRoot: TEST_WORKSPACE,
    commandTimeoutMs: 15000,
    maxOutputChars: 50000,
    autoApprove: true,
  });

  // =====================================================================
  // 1. BOOTSTRAP: REAL HTTP REQUESTS REQUIRING ONE-TIME PAIRING CODE
  // =====================================================================
  console.log('--- 1. BOOTSTRAP: Real HTTP Socket & One-Time Pairing Code Enforcement ---');

  // 1a. Real HTTP GET to /api/agent/auth/token WITHOUT pairing code -> 403 Forbidden (even over genuine loopback socket)
  const noCodeRes = await realHttpRequest({ path: '/api/agent/auth/token' });
  console.log(`[1a Real HTTP without pairing code]: Status=${noCodeRes.statusCode}, Body=${noCodeRes.body.trim()}`);
  assert(
    noCodeRes.statusCode === 403 && noCodeRes.body.includes('PAIRING_CODE_REQUIRED'),
    'Loopback without pairing code is rejected (403 PAIRING_CODE_REQUIRED)'
  );

  // 1b. Real HTTP GET with spoofed Host and fake pairing code -> 403 Forbidden
  const spoofedRes = await realHttpRequest({
    path: '/api/agent/auth/token',
    headers: {
      Host: 'localhost:3000',
      'x-agent-pairing-code': 'fake_attacker_code_12345',
    },
  });
  console.log(`[1b Real HTTP with invalid pairing code]: Status=${spoofedRes.statusCode}`);
  assert(spoofedRes.statusCode === 403, 'Invalid pairing code is strictly rejected (403)');

  // 1c. Obtain genuine pairing code from live server endpoint
  const pairRes = await realHttpRequest({
    path: '/api/agent/auth/pairing-code',
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36',
    },
  });
  let pairData: any = {};
  try { pairData = JSON.parse(pairRes.body); } catch {}
  const code = pairData.pairingCode;
  console.log(`[1c Real HTTP obtained pairing code from server]: Status=${pairRes.statusCode}, Code=${code?.slice(0, 10)}...`);
  assert(pairRes.statusCode === 200 && Boolean(code), 'Obtained valid pairing code from server endpoint');

  // 1d. Real HTTP GET with valid single-use pairing code -> 200 OK + returns token
  const validCodeRes = await realHttpRequest({
    path: '/api/agent/auth/token',
    headers: {
      'x-agent-pairing-code': code,
    },
  });
  let tokenData: any = {};
  try { tokenData = JSON.parse(validCodeRes.body); } catch {}
  console.log(`[1d Real HTTP with valid pairing code]: Status=${validCodeRes.statusCode}, HasToken=${Boolean(tokenData.token)}`);
  assert(
    validCodeRes.statusCode === 200 && tokenData.success === true && Boolean(tokenData.token),
    'Real HTTP bootstrap with valid pairing code succeeds (200 OK)'
  );

  // 1e. Replay the same pairing code -> 403 Forbidden (single-use consumption)
  const replayRes = await realHttpRequest({
    path: '/api/agent/auth/token',
    headers: {
      'x-agent-pairing-code': code,
    },
  });
  console.log(`[1e Real HTTP replaying consumed pairing code]: Status=${replayRes.statusCode}`);
  assert(replayRes.statusCode === 403, 'Reused pairing code is rejected (single-use enforced)');

  // =====================================================================
  // 2. OS-LEVEL SECRET PROTECTION: APPUSER (UID 1000) WITH GUARD BYPASSED
  // =====================================================================
  console.log('\n--- 2. OS-LEVEL SECRET PROTECTION: appuser (UID 1000) with Guard Bypassed ---');

  // 2a. Attempt to cat user secret file directly as UID 1000
  const catSecret = spawnSync('bash', ['--norc', '-c', 'cat /root/.zoya/agent_user_secret.json'], {
    uid: 1000,
    gid: 1000,
  });
  const catSecretStderr = catSecret.stderr.toString().trim();
  console.log(`[2a OS Permission Check: cat /root/.zoya/agent_user_secret.json]: Exit=${catSecret.status}, Stderr="${catSecretStderr}"`);
  assert(
    catSecret.status !== 0 && catSecretStderr.includes('Permission denied'),
    'OS kernel denies appuser access to /root/.zoya/agent_user_secret.json'
  );

  // 2b. Attempt to ls /root/.zoya directly as UID 1000
  const lsDir = spawnSync('bash', ['--norc', '-c', 'ls /root/.zoya'], {
    uid: 1000,
    gid: 1000,
  });
  const lsDirStderr = lsDir.stderr.toString().trim();
  console.log(`[2b OS Permission Check: ls /root/.zoya]: Exit=${lsDir.status}, Stderr="${lsDirStderr}"`);
  assert(
    lsDir.status !== 0 && lsDirStderr.includes('Permission denied'),
    'OS kernel denies appuser directory listing of /root/.zoya'
  );

  // 2c. Attempt to cat auth token file directly as UID 1000
  const catToken = spawnSync('bash', ['--norc', '-c', 'cat /root/.zoya/agent_auth_token.json'], {
    uid: 1000,
    gid: 1000,
  });
  const catTokenStderr = catToken.stderr.toString().trim();
  console.log(`[2c OS Permission Check: cat /root/.zoya/agent_auth_token.json]: Exit=${catToken.status}, Stderr="${catTokenStderr}"`);
  assert(
    catToken.status !== 0 && catTokenStderr.includes('Permission denied'),
    'OS kernel denies appuser access to /root/.zoya/agent_auth_token.json'
  );

  // 2d. Verify legacy plaintext files in data/ are gone
  const legacyAuthExists = fs.existsSync(path.join(process.cwd(), 'data', 'agent_auth_token.json'));
  const legacySecExists = fs.existsSync(path.join(process.cwd(), 'data', 'agent_user_secret.json'));
  console.log(`[2d Legacy file cleanup check]: legacyAuth=${legacyAuthExists}, legacySec=${legacySecExists}`);
  assert(!legacyAuthExists && !legacySecExists, 'Legacy credential files in data/ are permanently removed');

  // =====================================================================
  // 3. SCRIPT-FILE BYPASS & APPROVAL PREVIEW
  // =====================================================================
  console.log('\n--- 3. SCRIPT-FILE BYPASS: chr() Obfuscation & Script Preview Verification ---');

  // 3a. Write a python script that constructs /etc/passwd via chr()
  const bypassScriptPath = path.join(TEST_WORKSPACE, 'bypass_chr_test.py');
  fs.writeFileSync(
    bypassScriptPath,
    `# Obfuscated file access test
p = chr(47) + 'etc' + chr(47) + 'passwd'
try:
    with open(p) as f:
        print(f.read()[:50])
except Exception as e:
    print('Failed to open:', e)
`,
    'utf8'
  );

  // Evaluate the command "python3 bypass_chr_test.py" through AgentPermissionGuard
  const bypassEval = guard.evaluateToolCall('run_command', { command: 'python3 bypass_chr_test.py' }, TEST_WORKSPACE);
  console.log(`[3a Script Inspection on chr() bypass script]: level=${bypassEval.level}, isBlocked=${bypassEval.isBlocked}`);
  console.log(`   Reason: "${bypassEval.reason}"`);
  assert(
    bypassEval.level === 'BLOCKED' && bypassEval.isBlocked === true && bypassEval.reason.includes('malicious evasion'),
    'Script using chr() to build /etc/passwd is detected and BLOCKED'
  );

  // 3b. Verify execution through run_command is blocked
  const bypassExecRes = await executor.executeTool('run_command', { command: 'python3 bypass_chr_test.py' });
  console.log(`[3b Real Execution Result]: success=${bypassExecRes.success}, output="${bypassExecRes.output.slice(0, 100)}..."`);
  assert(
    bypassExecRes.success === false && bypassExecRes.output.includes('BLOCKED BY SECURITY POLICY'),
    'Executing script bypass through real run_command path is halted with SECURITY_BLOCKED'
  );

  // 3c. Write a legitimate user script and verify approval shows script preview and hash
  const legitScriptPath = path.join(TEST_WORKSPACE, 'legit_calculation.py');
  const legitContent = `# Legitimate mathematical script
def compute():
    return sum([x * 2 for x in range(10)])

if __name__ == '__main__':
    print("Computed total:", compute())
`;
  fs.writeFileSync(legitScriptPath, legitContent, 'utf8');

  const legitEval = guard.evaluateToolCall('run_command', { command: 'python3 legit_calculation.py' }, TEST_WORKSPACE);
  console.log(`[3c Legitimate Script Inspection]: level=${legitEval.level}, isBlocked=${legitEval.isBlocked}`);
  console.log(`   Warning/Preview:\n${legitEval.warning}`);
  assert(
    legitEval.level === 'ASK_APPROVAL' &&
      !legitEval.isBlocked &&
      Boolean(legitEval.warning) &&
      legitEval.warning!.includes('SCRIPT PREVIEW') &&
      legitEval.warning!.includes('SHA-256:'),
    'Approval request includes full script content preview and SHA-256 hash'
  );

  // 3d. Execute legitimate script through tool executor
  const legitExecRes = await executor.executeTool('run_command', { command: 'python3 legit_calculation.py' });
  console.log(`[3d Legitimate Script Execution]: success=${legitExecRes.success}, output="${legitExecRes.output.trim()}"`);
  assert(
    legitExecRes.success === true && legitExecRes.output.includes('Computed total: 90'),
    'Legitimate script executes cleanly under isolated appuser'
  );

  // Clean up test scripts
  try {
    fs.unlinkSync(bypassScriptPath);
    fs.unlinkSync(legitScriptPath);
  } catch {}

  // =====================================================================
  // 4. KERNEL-LEVEL NETWORK ISOLATION (unshare -n)
  // =====================================================================
  console.log('\n--- 4. NETWORK ISOLATION: Kernel-Level unshare -n Enforcement ---');

  // 4a. Run ping to external host through run_command
  const netPingRes = await executor.executeTool('run_command', { command: 'ping -c 1 8.8.8.8' });
  console.log(`[4a Outbound ping]: success=${netPingRes.success}, output="${netPingRes.output.trim()}"`);
  assert(
    netPingRes.success === false && netPingRes.output.includes('Network is unreachable'),
    'Subprocess cannot connect to external internet (Network is unreachable)'
  );

  // 4b. Run curl to localhost port 3000 through run_command
  const netLocalRes = await executor.executeTool('run_command', { command: 'curl -m 1 http://127.0.0.1:3000' });
  console.log(`[4b Localhost reachability]: success=${netLocalRes.success}, output="${netLocalRes.output.trim()}"`);
  assert(
    netLocalRes.success === false &&
      (netLocalRes.output.includes("Couldn't connect to server") || netLocalRes.output.includes('Failed to connect')),
    'Subprocess in unshared net namespace cannot reach host server on 127.0.0.1:3000'
  );

  // =====================================================================
  // 5. NON-ROOT EXECUTION AND SCRUBBED ENVIRONMENT
  // =====================================================================
  console.log('\n--- 5. NON-ROOT EXECUTION: UID 1000 & Environment Scrubbing ---');

  const idRes = await executor.executeTool('run_command', { command: 'id' });
  console.log(`[5a id output]: "${idRes.output.trim()}"`);
  assert(
    idRes.output.includes('uid=1000(appuser)') && idRes.output.includes('gid=1000(appuser)'),
    'Child process runs as uid=1000(appuser) and gid=1000(appuser)'
  );

  const whoamiRes = await executor.executeTool('run_command', { command: 'whoami' });
  console.log(`[5b whoami output]: "${whoamiRes.output.trim()}"`);
  assert(whoamiRes.output.includes('appuser'), 'whoami confirms appuser');

  const printenvRes = await executor.executeTool('run_command', { command: 'printenv' });
  const hasSecretVars = /(?:KEY|TOKEN|SECRET|PASSWORD)/i.test(printenvRes.output);
  console.log(`[5c printenv secret check]: hasSecretVars=${hasSecretVars}`);
  assert(!hasSecretVars, 'printenv does not contain any secret or token variables');

  // =====================================================================
  // SUMMARY
  // =====================================================================
  console.log('\n========================================================================================');
  console.log(`REMEDIATION SUITE FINISHED: ${passed} PASSED, ${failed} FAILED`);
  console.log('========================================================================================\n');

  if (failed > 0) {
    process.exit(1);
  }
}

runRemediationVerification().catch((err) => {
  console.error('Fatal test error:', err);
  process.exit(1);
});
