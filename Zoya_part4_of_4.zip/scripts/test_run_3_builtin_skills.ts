import { routeSkillIntent } from '../src/services/skillRouter.js';
import { executePart1Skill } from '../src/services/zoyaSkillsPart1.js';
import { executePart2And4Skill } from '../src/services/zoyaSkillsPart2And4.js';

console.log('================================================================');
console.log('🧪 TESTING 3 REAL BUILT-IN ZOYA ASSISTANT SKILLS (skillRouter)');
console.log('================================================================\n');

// Built-in Skill 1: brand-guidelines
console.log('--- BUILT-IN SKILL 1: brand-guidelines ---');
const query1 = '/brand show active palette and typography';
const intent1 = routeSkillIntent(query1);
console.log(`Routed Intent: ${intent1}`);
const res1 = executePart1Skill('brand-guidelines', query1);
console.log('Spoken Summary:', res1.spokenSummary);
console.log('Preset Name:', (res1.output as any)?.preset?.name);
console.log('Palette Colors:', (res1.output as any)?.preset?.colors);

// Built-in Skill 2: changelog-generator
console.log('\n--- BUILT-IN SKILL 2: changelog-generator ---');
const query2 = '/changelog v2.4.0 added security guards and audit logs';
const intent2 = routeSkillIntent(query2);
console.log(`Routed Intent: ${intent2}`);
const res2 = executePart1Skill('changelog-generator', query2);
console.log('Spoken Summary:', res2.spokenSummary);
console.log('Version Title:', (res2.output as any)?.versionTitle);
console.log('Release Date:', (res2.output as any)?.releaseDate);
console.log('Sections Count:', (res2.output as any)?.sections?.length);

// Built-in Skill 3: domain-name-brainstormer
console.log('\n--- BUILT-IN SKILL 3: domain-name-brainstormer ---');
const query3 = 'domain-name-brainstormer AI code audit and security verification';
const intent3 = routeSkillIntent(query3);
console.log(`Routed Intent: ${intent3}`);
const res3 = executePart2And4Skill('domain-name-brainstormer', query3);
console.log('Spoken Summary:', res3.spokenSummary);
console.log('Chat Output Preview:\n' + res3.chatText.slice(0, 320) + '...');

console.log('\n================================================================');
console.log('✅ 3 BUILT-IN SKILLS EXECUTED WITH REAL OUTPUT.');
console.log('================================================================');
