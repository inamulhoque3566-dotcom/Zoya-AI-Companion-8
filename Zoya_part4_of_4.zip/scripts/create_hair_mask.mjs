import sharp from 'sharp';
import path from 'path';

const imgPath = path.join(process.cwd(), 'public', 'assets', 'images', 'avatars_3d', 'transparent', 'avatar_pastel_blue_knit_shorts.png');
const outDir = path.join(process.cwd(), 'public', 'assets', 'images', 'avatars_modular', 'avatar_pastel_blue_knit_shorts');

async function generateHairMask() {
  console.log('[HAIR MASK] Reading source image:', imgPath);
  const { data, info } = await sharp(imgPath).raw().toBuffer({ resolveWithObject: true });
  const w = info.width;  // 941
  const h = info.height; // 1672

  // Create grayscale mask buffer (1 channel, 8-bit)
  const mask = Buffer.alloc(w * h, 0);

  // Hair color detection and spatial weighting
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const idx = (y * w + x) * 4;
      const r = data[idx];
      const g = data[idx + 1];
      const b = data[idx + 2];
      const a = data[idx + 3];

      // Must be visible pixel
      if (a < 25) continue;

      // Strictly upper body where hair exists (y between 120 and 950)
      if (y < 120 || y > 945) continue;

      // Strict skin exclusion (peachy tones have R > B by at least 10)
      if (r > b + 10 && r > 140) continue;

      // Strict pink shorts exclusion (pink has R > G and R > B)
      if (y > 600 && y < 850 && r > b - 15 && r > 180) continue;

      // Strict thigh/leg exclusion:
      // Thighs are centered between x = 325 and 630 for y > 750
      if (y > 750 && x > 335 && x < 620) {
        // If it looks like skin or legs
        if (r > 160 && (r > b - 15)) continue;
      }

      // Strict sweater exclusion (neutral grey-white stripes)
      if (y > 220 && y < 450 && x > 330 && x < 680) {
        if (Math.abs(r - b) < 16 && Math.abs(r - g) < 14 && r > 175) continue;
      }

      // Bent arm sweater sleeve on viewer's left (x between 170 and 340, y between 90 and 260)
      if (y < 260 && x > 170 && x < 350) {
        if (Math.abs(r - b) < 18 && Math.abs(r - g) < 14 && r > 180) continue;
      }

      // Right forearm/wrist on viewer's right (x between 650 and 780, y between 240 and 340)
      if (y > 240 && y < 340 && x > 650 && x < 780) {
        if (Math.abs(r - b) < 18 && Math.abs(r - g) < 14 && r > 180) continue;
      }

      // Hair color criteria:
      // Sky blue hair has Blue distinctly higher than Red
      const isHairBlue = (b > r + 15) && (b > 115) && (g > 105);
      const isDarkBlueTip = (b > r + 28) && (b > 90);
      if (!isHairBlue && !isDarkBlueTip) continue;

      // Vertical weighting:
      // Hair near scalp (y <= 140) = 0
      // Smooth gradient increasing down to hair tips
      let verticalWeight = 0;
      if (y <= 140) {
        verticalWeight = 0;
      } else if (y < 350) {
        verticalWeight = Math.pow((y - 140) / (350 - 140), 1.6) * 0.35;
      } else if (y < 850) {
        verticalWeight = 0.35 + 0.65 * ((y - 350) / (850 - 350));
      } else {
        // Tips
        const taper = Math.max(0, 1.0 - (y - 890) / 55);
        verticalWeight = Math.min(1.0, 1.0 * taper);
      }

      // Lateral weighting:
      // Outer hair sways freely, bangs near face stay steady
      let lateralMultiplier = 1.0;
      if (x < 360 || x > 590) {
        lateralMultiplier = 1.25;
      } else if (x > 420 && x < 540 && y < 250) {
        // Forehead bangs
        lateralMultiplier = 0.15;
      }

      const finalWeight = Math.min(1.0, Math.max(0, verticalWeight * lateralMultiplier));
      mask[y * w + x] = Math.round(finalWeight * 255);
    }
  }

  // Soft feathering with blur
  const hairMaskPath = path.join(outDir, 'hair_mask.png');
  await sharp(mask, { raw: { width: w, height: h, channels: 1 } })
    .blur(2.5)
    .png()
    .toFile(hairMaskPath);

  console.log('[HAIR MASK] Refined hair_mask.png saved successfully.');
}

generateHairMask().catch(console.error);
