const sharp = require('sharp');
const path = require('path');

async function findSkirtHem() {
  const { data, info } = await sharp(path.join(__dirname, '../src/assets/images/zoya_3d_sweater_glasses_1793764031303.jpg'))
    .raw()
    .toBuffer({ resolveWithObject: true });

  const getPixel = (x, y) => {
    const idx = (y * info.width + x) * info.channels;
    return [data[idx], data[idx + 1], data[idx + 2]];
  };

  for (let y = 1150; y <= 1220; y += 5) {
    let brownCount = 0;
    for (let x = 250; x <= 520; x++) {
      const [r, g, b] = getPixel(x, y);
      // Brown skirt: r in [90, 160], g in [60, 120], b in [50, 110], with r > g && g > b
      if (r > 70 && r < 180 && g > 45 && g < 140 && b > 35 && b < 130 && r > g && g >= b - 5) {
        brownCount++;
      }
    }
    console.log(`y=${y}: brownCount=${brownCount}`);
  }
}

findSkirtHem().catch(console.error);
