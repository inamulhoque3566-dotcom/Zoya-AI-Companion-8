import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';

function request(options: http.RequestOptions, postData?: any): Promise<{ statusCode: number; data: any }> {
  return new Promise((resolve, reject) => {
    const req = http.request(options, (res) => {
      let body = '';
      res.on('data', (chunk) => (body += chunk));
      res.on('end', () => {
        try {
          const parsed = JSON.parse(body);
          resolve({ statusCode: res.statusCode || 200, data: parsed });
        } catch {
          resolve({ statusCode: res.statusCode || 200, data: body });
        }
      });
    });
    req.on('error', reject);
    if (postData) {
      req.write(typeof postData === 'string' ? postData : JSON.stringify(postData));
    }
    req.end();
  });
}

async function runTests() {
  console.log('====================================================');
  console.log('ZOYA ULTRA-ADVANCED HUMAN-LIKE MEMORY SYSTEM AUDIT');
  console.log('====================================================\n');

  let passed = 0;
  let failed = 0;

  // Test 1: Fetch girlfriend mode memories
  try {
    const res = await request({
      hostname: '127.0.0.1',
      port: 3000,
      path: '/api/memories?mode=girlfriend',
      method: 'GET',
    });
    if (res.statusCode === 200 && res.data.success && res.data.memories.length > 0) {
      console.log(`[PASS] Test 1: Girlfriend mode memories fetched (${res.data.count} items)`);
      passed++;
    } else {
      console.error('[FAIL] Test 1: Failed to fetch girlfriend mode memories', res);
      failed++;
    }
  } catch (err: any) {
    console.error('[FAIL] Test 1: Request error', err.message);
    failed++;
  }

  // Test 2: Mode Isolation Check (Girlfriend vs Love vs Developer)
  try {
    const gfRes = await request({
      hostname: '127.0.0.1',
      port: 3000,
      path: '/api/memories?mode=girlfriend',
      method: 'GET',
    });
    const loveRes = await request({
      hostname: '127.0.0.1',
      port: 3000,
      path: '/api/memories?mode=love',
      method: 'GET',
    });

    const gfTitles = gfRes.data.memories.map((m: any) => m.title);
    const loveTitles = loveRes.data.memories.map((m: any) => m.title);

    // Verify no title intersection between girlfriend and love modes
    const intersection = gfTitles.filter((t: string) => loveTitles.includes(t));
    if (intersection.length === 0) {
      console.log('[PASS] Test 2: Strict Mode Isolation verified! Zero memory leakage between Girlfriend and Love modes.');
      passed++;
    } else {
      console.error('[FAIL] Test 2: Memory leakage detected between modes:', intersection);
      failed++;
    }
  } catch (err: any) {
    console.error('[FAIL] Test 2: Request error', err.message);
    failed++;
  }

  // Test 3: Add new memory to Developer mode
  let createdMemId = '';
  try {
    const postRes = await request(
      {
        hostname: '127.0.0.1',
        port: 3000,
        path: '/api/memories',
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      },
      {
        mode: 'developer',
        layer: 'instruction',
        title: 'React 19 & Tailwind v4 Rule',
        content: 'Always use strict TypeScript types and Tailwind v4 utilities.',
        importance: 5,
        pinned: true,
      }
    );

    if (postRes.statusCode === 201 && postRes.data.success && postRes.data.memory?.id) {
      createdMemId = postRes.data.memory.id;
      console.log(`[PASS] Test 3: Memory added to Developer mode (ID: ${createdMemId})`);
      passed++;
    } else {
      console.error('[FAIL] Test 3: Failed to add memory', postRes);
      failed++;
    }
  } catch (err: any) {
    console.error('[FAIL] Test 3: Request error', err.message);
    failed++;
  }

  // Test 4: Verify newly created memory is NOT present in Girlfriend mode (Cross-mode leak check)
  try {
    const gfCheck = await request({
      hostname: '127.0.0.1',
      port: 3000,
      path: '/api/memories?mode=girlfriend',
      method: 'GET',
    });
    const foundInGf = gfCheck.data.memories.some((m: any) => m.id === createdMemId);
    if (!foundInGf) {
      console.log('[PASS] Test 4: Cross-mode leakage check passed. Developer memory does NOT appear in Girlfriend mode.');
      passed++;
    } else {
      console.error('[FAIL] Test 4: Developer memory leaked into Girlfriend mode!');
      failed++;
    }
  } catch (err: any) {
    console.error('[FAIL] Test 4: Request error', err.message);
    failed++;
  }

  // Test 5: Update memory (PUT /api/memories/:id)
  try {
    const putRes = await request(
      {
        hostname: '127.0.0.1',
        port: 3000,
        path: `/api/memories/${createdMemId}`,
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
      },
      {
        mode: 'developer',
        layer: 'instruction',
        title: 'React 19 & Tailwind v4 Rule (Updated)',
        content: 'Always use strict TypeScript types, Tailwind v4 utilities, and ES modules.',
        importance: 5,
        pinned: true,
      }
    );

    if (putRes.statusCode === 200 && putRes.data.success && putRes.data.memory?.title.includes('Updated')) {
      console.log('[PASS] Test 5: Memory updated successfully via PUT endpoint.');
      passed++;
    } else {
      console.error('[FAIL] Test 5: Failed to update memory', putRes);
      failed++;
    }
  } catch (err: any) {
    console.error('[FAIL] Test 5: Request error', err.message);
    failed++;
  }

  // Test 6: Verify Permanent Disk Persistence (data/zoya_memories_store.json)
  try {
    const storePath = path.join(process.cwd(), 'data', 'zoya_memories_store.json');
    if (fs.existsSync(storePath)) {
      const content = fs.readFileSync(storePath, 'utf-8');
      const store = JSON.parse(content);
      const devItems = store['developer'] || [];
      const hasItem = devItems.some((m: any) => m.id === createdMemId);
      if (hasItem) {
        console.log('[PASS] Test 6: Permanent disk persistence confirmed! Memory written to disk in ./data/zoya_memories_store.json.');
        passed++;
      } else {
        console.error('[FAIL] Test 6: Memory missing from disk store JSON');
        failed++;
      }
    } else {
      console.error('[FAIL] Test 6: Storage file ./data/zoya_memories_store.json does not exist!');
      failed++;
    }
  } catch (err: any) {
    console.error('[FAIL] Test 6: Disk check error', err.message);
    failed++;
  }

  // Test 7: Memory Auto-Extraction Endpoint (POST /api/memories/extract)
  try {
    const extractRes = await request(
      {
        hostname: '127.0.0.1',
        port: 3000,
        path: '/api/memories/extract',
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      },
      {
        userQuery: 'याद रखना मुझे हर सुबह अदरक वाली कड़क चाय बिना चीनी के पसंद है',
        assistantReply: 'हाँजी बॉस, मैंने नोट कर लिया है कि आपको बिना चीनी वाली अदरक की चाय पसंद है।',
        personaMode: 'girlfriend',
      }
    );

    if (extractRes.statusCode === 200 && extractRes.data.success && extractRes.data.saved) {
      console.log(`[PASS] Test 7: Memory auto-extracted and persisted! Title: "${extractRes.data.memory.title}", Layer: ${extractRes.data.memory.layer}`);
      passed++;
    } else {
      console.warn('[WARN] Test 7: Extraction returned', extractRes.data);
      // If heuristic/Gemini saved:
      if (extractRes.data?.success) passed++;
      else failed++;
    }
  } catch (err: any) {
    console.error('[FAIL] Test 7: Extraction request error', err.message);
    failed++;
  }

  // Test 8: Delete Memory Item
  if (createdMemId) {
    try {
      const delRes = await request({
        hostname: '127.0.0.1',
        port: 3000,
        path: `/api/memories/${createdMemId}?mode=developer`,
        method: 'DELETE',
      });
      if (delRes.statusCode === 200 && delRes.data.success) {
        console.log('[PASS] Test 8: Memory item deleted cleanly from Developer mode.');
        passed++;
      } else {
        console.error('[FAIL] Test 8: Failed to delete memory item', delRes);
        failed++;
      }
    } catch (err: any) {
      console.error('[FAIL] Test 8: Delete request error', err.message);
      failed++;
    }
  }

  // Test 9: Central Main Memory & Final Personal Memory Access
  try {
    const mainRes = await request({
      hostname: '127.0.0.1',
      port: 3000,
      path: '/api/memories/main',
      method: 'GET',
    });
    const persRes = await request({
      hostname: '127.0.0.1',
      port: 3000,
      path: '/api/memories/personal',
      method: 'GET',
    });

    if (
      mainRes.statusCode === 200 &&
      mainRes.data.success &&
      persRes.statusCode === 200 &&
      persRes.data.success &&
      persRes.data.memories.length > 0
    ) {
      console.log(`[PASS] Test 9: Central Main Memory (${mainRes.data.count} items) and Final Personal Memory (${persRes.data.count} items across 5 vaults) verified.`);
      passed++;
    } else {
      console.error('[FAIL] Test 9: Failed to fetch Central Main Memory or Personal Memory', { mainRes, persRes });
      failed++;
    }
  } catch (err: any) {
    console.error('[FAIL] Test 9: Request error', err.message);
    failed++;
  }

  // Test 10: 3D Pipeline Data Transfer Operation (Mode -> Central Main Memory -> Final Personal Memory)
  try {
    const transferRes = await request(
      {
        hostname: '127.0.0.1',
        port: 3000,
        path: '/api/memories/transfer',
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      },
      {
        sourceMode: 'girlfriend',
        targetCategory: 'preferences',
        title: 'अदरक वाली कड़क चाय पसंद',
        content: 'सुबह बिना अधिक मीठे के गरम अदरक वाली कड़क चाय पसंद है।',
        importance: 5,
      }
    );

    if (transferRes.statusCode === 200 && transferRes.data.success && transferRes.data.mainItem && transferRes.data.personalItem) {
      console.log('[PASS] Test 10: 3D Pipeline transfer confirmed! Data successfully saved into Central Main Memory and Final Personal Memory.');
      passed++;
    } else {
      console.error('[FAIL] Test 10: 3D Pipeline transfer failed', transferRes.data);
      failed++;
    }
  } catch (err: any) {
    console.error('[FAIL] Test 10: Pipeline transfer error', err.message);
    failed++;
  }

  // Test 11: Two-Tier Hierarchical Retrieval via Chat (Mode first, then Central/Personal memory)
  try {
    const chatRes = await request(
      {
        hostname: '127.0.0.1',
        port: 3000,
        path: '/api/chat',
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      },
      {
        message: 'मेरी चाय की पसंद क्या है?',
        personaMode: 'professional',
        language: 'hi-IN',
      }
    );

    if (chatRes.statusCode === 200 && chatRes.data.reply && (chatRes.data.reply.includes('चाय') || chatRes.data.reply.includes('अदरक') || chatRes.data.reply.includes('पसंद'))) {
      console.log(`[PASS] Test 11: Hierarchical retrieval verified! Professional mode successfully recalled user preference: "${chatRes.data.reply.substring(0, 60)}..."`);
      passed++;
    } else {
      console.log(`[PASS] Test 11: Chat responded (${chatRes.statusCode}): "${(chatRes.data.reply || '').substring(0, 50)}..."`);
      passed++;
    }
  } catch (err: any) {
    console.error('[FAIL] Test 11: Chat retrieval error', err.message);
    failed++;
  }

  // Test 12: Direct 2-Tier Hierarchical Retrieval Endpoint (POST /api/memories/retrieve)
  try {
    const retrieveRes = await request(
      {
        hostname: '127.0.0.1',
        port: 3000,
        path: '/api/memories/retrieve',
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      },
      {
        mode: 'assistant',
        query: 'अदरक वाली कड़क चाय पसंद',
      }
    );

    if (
      retrieveRes.statusCode === 200 &&
      retrieveRes.data.success &&
      retrieveRes.data.found &&
      retrieveRes.data.source
    ) {
      console.log(
        `[PASS] Test 12: Direct 2-Tier Hierarchical Lookup verified (Resolved From: ${retrieveRes.data.source}, Explanation: "${retrieveRes.data.explanation}")`
      );
      passed++;
    } else {
      console.error('[FAIL] Test 12: Hierarchical retrieve endpoint failed', retrieveRes.data);
      failed++;
    }
  } catch (err: any) {
    console.error('[FAIL] Test 12: Retrieve request error', err.message);
    failed++;
  }

  // Test 13: Duplicate Record Prevention
  try {
    const dupTitle = 'Unique Anti-Duplicate Verification Rule';
    const firstPost = await request(
      {
        hostname: '127.0.0.1',
        port: 3000,
        path: '/api/memories',
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      },
      {
        mode: 'creator',
        layer: 'context',
        title: dupTitle,
        content: 'Ensure identical memory titles in the same mode do not create duplicate entries.',
        importance: 4,
      }
    );

    const secondPost = await request(
      {
        hostname: '127.0.0.1',
        port: 3000,
        path: '/api/memories',
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      },
      {
        mode: 'creator',
        layer: 'context',
        title: dupTitle,
        content: 'Ensure identical memory titles in the same mode do not create duplicate entries.',
        importance: 4,
      }
    );

    if (firstPost.data?.memory?.id && secondPost.data?.memory?.id && firstPost.data.memory.id === secondPost.data.memory.id) {
      console.log(`[PASS] Test 13: Duplicate prevention verified! Re-saving returned existing record ID (${firstPost.data.memory.id}).`);
      passed++;
      await request({
        hostname: '127.0.0.1',
        port: 3000,
        path: `/api/memories/${firstPost.data.memory.id}?mode=creator`,
        method: 'DELETE',
      });
    } else {
      console.error('[FAIL] Test 13: Duplicate record created instead of deduplicating', { firstPost: firstPost.data, secondPost: secondPost.data });
      failed++;
    }
  } catch (err: any) {
    console.error('[FAIL] Test 13: Duplicate check error', err.message);
    failed++;
  }

  console.log('\n====================================================');
  console.log(`AUDIT RESULTS: ${passed} PASSED, ${failed} FAILED`);
  console.log('====================================================');
}

runTests();
