import http from 'http';
import path from 'path';
import fs from 'fs';
import { AgentAuthManager } from '../src/services/agent/agentAuth.js';

const BASE_URL = 'http://localhost:3000';
const BROWSER_UA = 'Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36';
const OWNER_PASSPHRASE = 'OwnerSecurePassphrase2026!';

let sessionCookie: string | null = null;

async function req(endpoint: string, options: any = {}) {
  const url = `${BASE_URL}${endpoint}`;
  const headers: Record<string, string> = {
    'User-Agent': BROWSER_UA,
    'Content-Type': 'application/json',
    ...(options.headers || {}),
  };
  if (sessionCookie && !headers['Cookie'] && !headers['cookie']) {
    headers['Cookie'] = sessionCookie;
  }
  const res = await fetch(url, {
    ...options,
    headers,
    body: options.body ? (typeof options.body === 'string' ? options.body : JSON.stringify(options.body)) : undefined,
  });
  const text = await res.text();
  let json: any = null;
  try {
    json = JSON.parse(text);
  } catch {}

  const setCookie = res.headers.get('set-cookie');
  if (setCookie) {
    const match = setCookie.match(/zoya_approval_session=([^;]+)/);
    if (match) {
      sessionCookie = `zoya_approval_session=${match[1]}`;
    }
  }

  return { status: res.status, headers: res.headers, raw: text, data: json };
}

async function runTests1To4() {
  console.log('--- BOOTSTRAP: AUTH & SESSION ---');
  const setupCode = AgentAuthManager.getOrCreateSetupCode();
  try {
    AgentAuthManager.setOwnerPassphraseWithSetupCode(OWNER_PASSPHRASE, setupCode);
  } catch {}

  await req('/api/agent/auth/owner/login', {
    method: 'POST',
    body: { passphrase: OWNER_PASSPHRASE },
  });

  const pairRes = await req('/api/agent/auth/pairing-code', {
    method: 'POST',
    body: { passphrase: OWNER_PASSPHRASE },
  });
  const pairingCode = pairRes.data?.pairingCode;

  const tokenRes = await req('/api/agent/auth/token', {
    headers: { 'x-agent-pairing-code': pairingCode },
  });
  const token = tokenRes.data?.token;

  const authHeaders = {
    Authorization: `Bearer ${token}`,
  };

  console.log(`[AUTH] Session Established. Token: ${token.slice(0, 16)}...`);
  console.log(`[AUTH] Approval Cookie: ${sessionCookie}\n`);

  // ========================================================================
  // TEST 1: Import an external skill from GitHub
  // ========================================================================
  console.log('=== TEST 1: Import External Skill from GitHub ===');
  const gitImportRes = await req('/api/agent/skills/import/git', {
    method: 'POST',
    headers: authHeaders,
    body: {
      repoUrl: 'https://github.com/anthropics/skills',
      subpath: 'skills/algorithmic-art',
    },
  });
  const qId = gitImportRes.data?.quarantineId;
  console.log(`[TEST 1 STATUS]: ${gitImportRes.status}`);
  console.log(`[TEST 1 RAW]: ${gitImportRes.raw}`);
  const pass1 = gitImportRes.status === 200 && Boolean(qId);
  console.log(`[TEST 1 RESULT]: ${pass1 ? 'PASS' : 'FAIL'}\n`);

  // ========================================================================
  // TEST 2: Validate and install it (show scan report)
  // ========================================================================
  console.log('=== TEST 2: Validate & Install Skill (Scan Report) ===');
  const scanRes = await req(`/api/agent/skills/scan/${qId}`, {
    headers: authHeaders,
  });
  console.log(`[TEST 2 SCAN STATUS]: ${scanRes.status}`);
  console.log(`[TEST 2 SCAN REPORT]: ${scanRes.raw}`);

  const installRes = await req(`/api/agent/skills/install/${qId}`, {
    method: 'POST',
    headers: authHeaders,
  });
  console.log(`[TEST 2 INSTALL STATUS]: ${installRes.status}`);
  console.log(`[TEST 2 INSTALL RAW]: ${installRes.raw}`);
  const skillId = installRes.data?.skill?.id || 'algorithmic-art';
  const pass2 = scanRes.status === 200 && installRes.status === 200 && installRes.data?.success === true;
  console.log(`[TEST 2 RESULT]: ${pass2 ? 'PASS' : 'FAIL'}\n`);

  // ========================================================================
  // TEST 3: Enable it and run one of its scripts (with approval)
  // ========================================================================
  console.log('=== TEST 3: Enable & Run Skill Script (with Approval) ===');
  const enableRes = await req(`/api/agent/skills/${skillId}/enable`, {
    method: 'POST',
    headers: authHeaders,
  });
  console.log(`[TEST 3 ENABLE STATUS]: ${enableRes.status}`);

  // Create test script in installed skill that prints id
  const idScript = path.join(process.cwd(), 'data', 'agent_skills', 'installed', skillId, 'id_test.py');
  fs.writeFileSync(idScript, 'import subprocess\nsubprocess.run(["id"])\n', 'utf8');

  // Trigger unapproved run
  const runPre = await req(`/api/agent/skills/${skillId}/run`, {
    method: 'POST',
    headers: authHeaders,
    body: {
      scriptPath: 'id_test.py',
      args: [],
    },
  });
  console.log(`[TEST 3 RUN PRE STATUS]: ${runPre.status}`);
  const pending3 = runPre.data?.pendingApproval?.id;

  // Approve via cookie
  await req(`/api/agent/approvals/${pending3}/respond`, {
    method: 'POST',
    body: { approve: true },
  });

  // Run with approvalId
  const runPost = await req(`/api/agent/skills/${skillId}/run`, {
    method: 'POST',
    headers: authHeaders,
    body: {
      scriptPath: 'id_test.py',
      args: [],
      approvalId: pending3,
    },
  });
  console.log(`[TEST 3 RUN POST STATUS]: ${runPost.status}`);
  const pass3 = enableRes.status === 200 && runPre.status === 202 && runPost.status === 200 && runPost.data?.result?.stdout?.includes('uid=1000(appuser)');
  console.log(`[TEST 3 RESULT]: ${pass3 ? 'PASS' : 'FAIL'}\n`);

  // ========================================================================
  // TEST 4: Import and connect the real MCP server (@modelcontextprotocol/server-filesystem) and call one tool
  // ========================================================================
  console.log('=== TEST 4: Connect Real Filesystem MCP & Call Tool ===');
  const workspaceRoot = path.join(process.cwd(), 'workspace');
  const serverPath = path.join(process.cwd(), 'node_modules', '@modelcontextprotocol', 'server-filesystem', 'dist', 'index.js');

  const mcpReg = await req('/api/agent/mcp/servers', {
    method: 'POST',
    headers: authHeaders,
    body: {
      name: 'phase7-fs-mcp',
      transport: 'stdio',
      command: process.execPath,
      args: [serverPath, workspaceRoot],
      cwd: workspaceRoot,
      allowNetwork: false,
      approved: true,
    },
  });
  const serverId = mcpReg.data?.server?.id;
  console.log(`[TEST 4 MCP REG STATUS]: ${mcpReg.status}`);

  const mcpConnect = await req(`/api/agent/mcp/servers/${serverId}/connect`, {
    method: 'POST',
    headers: authHeaders,
    body: { approved: true },
  });
  console.log(`[TEST 4 MCP CONNECT STATUS]: ${mcpConnect.status}`);

  // Try calling tool with approved: true in body (should be refused with 202)
  const toolPre = await req('/api/agent/mcp/tools/call', {
    method: 'POST',
    headers: authHeaders,
    body: {
      serverId,
      toolName: 'list_directory',
      arguments: { path: workspaceRoot },
      approved: true,
    },
  });
  console.log(`[TEST 4 TOOL PRE STATUS]: ${toolPre.status}`);
  const pending4 = toolPre.data?.pendingApproval?.id;

  // Approve via cookie
  await req(`/api/agent/approvals/${pending4}/respond`, {
    method: 'POST',
    body: { approve: true },
  });

  // Call with approvalId
  const toolPost = await req('/api/agent/mcp/tools/call', {
    method: 'POST',
    headers: authHeaders,
    body: {
      serverId,
      toolName: 'list_directory',
      arguments: { path: workspaceRoot },
      approvalId: pending4,
    },
  });
  console.log(`[TEST 4 TOOL POST STATUS]: ${toolPost.status}`);

  // Cleanup MCP server
  await req(`/api/agent/mcp/servers/${serverId}`, {
    method: 'DELETE',
    headers: authHeaders,
  });

  const pass4 = mcpConnect.status === 200 && toolPre.status === 202 && toolPost.status === 200 && toolPost.data?.success === true;
  console.log(`[TEST 4 RESULT]: ${pass4 ? 'PASS' : 'FAIL'}\n`);

  if (!pass1 || !pass2 || !pass3 || !pass4) {
    process.exit(1);
  }
}

runTests1To4().catch((err) => {
  console.error('Tests 1-4 crashed:', err);
  process.exit(1);
});
