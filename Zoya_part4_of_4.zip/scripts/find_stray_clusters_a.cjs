const sharp = require('sharp');

async function findStrayClustersA() {
  const { data, info } = await sharp('public/assets/aistudio/file_00000000eb7881fa8a888c25bfc4c0f7_32dd4f88.png')
    .raw()
    .toBuffer({ resolveWithObject: true });

  const w = info.width;
  const h = info.height;

  // Let's inspect where stray pixels are
  console.log('--- Scanning where pixels exist outside expected leg bounds below y=950 ---');
  // Group by (x_bracket, y_bracket)
  const grid = {};
  for (let y = 950; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const idx = (y * w + x) * 4;
      const a = data[idx + 3];
      if (a > 20 && (x < 370 || x > 620)) {
        const key = `${Math.floor(x / 50) * 50},${Math.floor(y / 50) * 50}`;
        grid[key] = (grid[key] || 0) + 1;
      }
    }
  }

  console.log('Stray clusters (x_bin, y_bin -> count):', grid);

  // Also check around ankles and shoes (y > 1500, x=350..650)
  console.log('\n--- Checking around shoes/ankles (y > 1550) for ground shadow or leftover artifacts ---');
  let groundShadowCount = 0;
  for (let y = 1600; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const idx = (y * w + x) * 4;
      const a = data[idx + 3];
      const r = data[idx], g = data[idx+1], b = data[idx+2];
      if (a > 5) {
        // Check if dark or grey ground shadow
        if (y > 1660 || (Math.abs(r - g) < 15 && Math.abs(g - b) < 15 && r < 120)) {
          groundShadowCount++;
          if (groundShadowCount <= 10) {
            console.log(`Potential ground shadow at (${x}, ${y}): rgba=(${r},${g},${b},${a})`);
          }
        }
      }
    }
  }
  console.log('Total ground shadow / dark pixels near bottom:', groundShadowCount);
}

findStrayClustersA().catch(console.error);
