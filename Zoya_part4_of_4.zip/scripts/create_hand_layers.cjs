const sharp = require('sharp');
const path = require('path');

async function createIndependentHandLayers() {
  const src = path.join(__dirname, '../public/assets/images/anime_princess_3d_transparent.png');
  const { data, info } = await sharp(src).raw().toBuffer({ resolveWithObject: true });
  const W = info.width, H = info.height;

  // Left hand region in full image: x in [330..388], y in [500..575]
  // Right hand region in full image: x in [382..440], y in [500..575]
  // Let's create an exact cutout of left hand and right hand with feathered edges
  const makePart = async (x0, y0, w, h, isLeft) => {
    const partRgba = new Uint8Array(w * h * 4);
    for (let py = 0; py < h; py++) {
      const y = y0 + py;
      for (let px = 0; px < w; px++) {
        const x = x0 + px;
        const srcIdx = (y * W + x) * 4;
        const destIdx = (py * w + px) * 4;

        let a = data[srcIdx + 3];
        // Feather the boundary edges (top, bottom, and inner split)
        const dEdgeX = Math.min(px, w - 1 - px);
        const dEdgeY = Math.min(py, h - 1 - py);
        let feather = Math.min(1, Math.min(dEdgeX / 4, dEdgeY / 4));
        
        partRgba[destIdx] = data[srcIdx];
        partRgba[destIdx + 1] = data[srcIdx + 1];
        partRgba[destIdx + 2] = data[srcIdx + 2];
        partRgba[destIdx + 3] = Math.round(a * feather);
      }
    }
    return sharp(partRgba, { raw: { width: w, height: h, channels: 4 } }).png().toBuffer();
  };

  const leftHandBuf = await makePart(325, 498, 64, 76, true);
  await sharp(leftHandBuf).toFile(path.join(__dirname, '../public/assets/images/zoya_hand_left.png'));

  const rightHandBuf = await makePart(380, 498, 64, 76, false);
  await sharp(rightHandBuf).toFile(path.join(__dirname, '../public/assets/images/zoya_hand_right.png'));

  console.log('Saved zoya_hand_left.png and zoya_hand_right.png');
}

createIndependentHandLayers().catch(console.error);
