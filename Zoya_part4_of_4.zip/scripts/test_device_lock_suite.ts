const store: Record<string, string> = {};
(globalThis as any).localStorage = {
  getItem: (k: string) => store[k] ?? null,
  setItem: (k: string, v: string) => { store[k] = String(v); },
  removeItem: (k: string) => { delete store[k]; },
  clear: () => { for (const k in store) delete store[k]; }
};

import { androidAccessibility } from '../src/services/androidAccessibility';
import { deviceSecurity } from '../src/services/deviceSecurity';

async function runDeviceLockSuite() {
  console.log('===============================================================');
  console.log('  ZOYA DEVICE LOCK & SECURITY — SYSTEM VERIFICATION SUITE');
  console.log('===============================================================\n');

  let passedTests = 0;
  let totalTests = 0;

  function assert(condition: boolean, desc: string, details?: any) {
    totalTests++;
    if (condition) {
      passedTests++;
      console.log(`  [PASS] ${desc}`);
      if (details) console.log(`         ->`, details);
    } else {
      console.error(`  [FAIL] ${desc}`);
      if (details) console.error(`         -> Details:`, details);
    }
  }

  // -------------------------------------------------------------------------
  // TEST 1: VOICE DEVICE LOCK COMMAND PARSING (ENGLISH & HINDI)
  // -------------------------------------------------------------------------
  console.log('\n--- TEST 1: Voice Device Lock Commands (English & Hindi) ---');
  
  const lockQueries = [
    'Zoya, lock my phone.',
    'lock my phone',
    'lock the screen',
    'lock phone now',
    'phone lock karo',
    'screen lock karo',
    'फोन लॉक करो',
    'फ़ोन लॉक करो', // With Devanagari nuqta (\u095E)
    'स्क्रीन लॉक करो',
    'फोन लॉक कर दो',
    'फ़ोन लॉक कर दो',
    'मोबाइल लॉक करो',
    'लॉक करो'
  ];

  for (const q of lockQueries) {
    const match = androidAccessibility.matchVoiceCommand(q);
    assert(
      match.isAccessibilityCommand && match.actionPayload?.action === 'lock_device',
      `Command: "${q}" recognized as lock_device`,
      match
    );
  }

  // -------------------------------------------------------------------------
  // TEST 2: PIN & PASSWORD SETUP ENROLLMENT DISPATCH
  // -------------------------------------------------------------------------
  console.log('\n--- TEST 2: Official PIN & Password Setup (Zero Credential Retention) ---');
  
  const pinEnroll = await deviceSecurity.openSecurityEnrollment('pin');
  assert(pinEnroll.success, 'PIN Setup intent launches official Android security action', pinEnroll.message);

  const pwdEnroll = await deviceSecurity.openSecurityEnrollment('password');
  assert(pwdEnroll.success, 'Password Setup intent launches official Android security action', pwdEnroll.message);

  // -------------------------------------------------------------------------
  // TEST 3: FACE & FINGERPRINT BIOMETRIC HARDWARE DETECTION
  // -------------------------------------------------------------------------
  console.log('\n--- TEST 3: Hardware Support & Biometric Enrollment Verification ---');
  
  const secStatus = await deviceSecurity.getSecurityStatus();
  assert(
    typeof secStatus.hasFingerprintHardware === 'boolean' && typeof secStatus.hasFaceHardware === 'boolean',
    'Biometric hardware detection accurately typed and retrieved',
    {
      fingerprint: secStatus.hasFingerprintHardware ? secStatus.fingerprintStatus : 'no_hardware',
      face: secStatus.hasFaceHardware ? secStatus.faceStatus : 'no_hardware'
    }
  );

  const fpEnroll = await deviceSecurity.openSecurityEnrollment('fingerprint');
  assert(fpEnroll.success, 'Fingerprint enrollment intent launched', fpEnroll.message);

  const faceEnroll = await deviceSecurity.openSecurityEnrollment('face');
  assert(faceEnroll.success, 'Face enrollment intent launched', faceEnroll.message);

  // -------------------------------------------------------------------------
  // TEST 4: UNLOCK CHALLENGE & KEYGUARD VERIFICATION
  // -------------------------------------------------------------------------
  console.log('\n--- TEST 4: Official Android Keyguard Unlock Challenge ---');
  
  const unlockRes = await deviceSecurity.requestUnlock();
  assert(unlockRes.success, 'Unlock challenge initiated officially without bypassing screen lock', unlockRes.message);

  // -------------------------------------------------------------------------
  // TEST 5: ACCESSIBILITY SERVICE STATES & RELIABILITY
  // -------------------------------------------------------------------------
  console.log('\n--- TEST 5: Accessibility States & Reliability ---');

  // Test with Accessibility disabled
  localStorage.setItem('zoya_simulated_accessibility', 'false');
  const disabledLockRes = await deviceSecurity.lockDevice();
  assert(
    !disabledLockRes.success && disabledLockRes.code === 'ACCESSIBILITY_REQUIRED',
    'Accurate failure reported when Accessibility Service is disabled',
    disabledLockRes
  );

  // Test with Accessibility enabled
  localStorage.setItem('zoya_simulated_accessibility', 'true');
  const enabledLockRes = await deviceSecurity.lockDevice();
  assert(
    enabledLockRes.success,
    'Lock screen succeeds when Accessibility Service is authorized',
    enabledLockRes
  );

  // Test unlock voice queries
  const unlockQueries = [
    'unlock my phone',
    'unlock the screen',
    'phone unlock karo',
    'फोन अनलॉक करो',
    'फ़ोन अनलॉक करो',
    'स्क्रीन अनलॉक करो'
  ];

  for (const q of unlockQueries) {
    const match = androidAccessibility.matchVoiceCommand(q);
    assert(
      match.isAccessibilityCommand && match.actionPayload?.action === 'unlock_device',
      `Unlock Command: "${q}" recognized as unlock_device`,
      match
    );
  }

  // -------------------------------------------------------------------------
  // SUMMARY
  // -------------------------------------------------------------------------
  console.log('\n===============================================================');
  console.log(`  TEST RESULTS: ${passedTests} / ${totalTests} PASSED (${Math.round((passedTests / totalTests) * 100)}%)`);
  console.log('===============================================================\n');

  if (passedTests === totalTests) {
    process.exit(0);
  } else {
    process.exit(1);
  }
}

runDeviceLockSuite().catch((err) => {
  console.error('Test Suite encountered unhandled error:', err);
  process.exit(1);
});
