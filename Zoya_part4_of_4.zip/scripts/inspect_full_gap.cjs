const sharp = require('sharp');

async function inspectFullGap() {
  const { data, info } = await sharp('public/assets/images/avatars_3d/transparent/avatar_pastel_blue_knit_shorts.png')
    .raw()
    .toBuffer({ resolveWithObject: true });

  const w = info.width;
  const h = info.height;

  // Let's print out what x=450 to x=540 looks like for y=1360 to 1540
  console.log('Columns 450..540 from y=1360..1540:');
  for (let y = 1360; y <= 1540; y += 10) {
    let line = `y=${y}: `;
    for (let x = 450; x <= 540; x += 3) {
      const idx = (y * w + x) * 4;
      const r = data[idx], g = data[idx+1], b = data[idx+2], a = data[idx+3];
      if (a === 0) line += '.';
      else if (r < 55 && g < 55 && b < 55) line += '#';
      else if (r > 200 && g > 150 && b > 140) line += 'S'; // Skin
      else if (r > 190 && g > 140 && b > 170) line += 'P'; // Pink shoe/sock
      else line += 'o';
    }
    console.log(line);
  }
}

inspectFullGap().catch(console.error);
