const sharp = require('sharp');
const path = require('path');

async function analyzeAnatomy() {
  const { data, info } = await sharp(path.join(__dirname, '../src/assets/images/zoya_3d_sweater_glasses_1793764031303.jpg'))
    .raw()
    .toBuffer({ resolveWithObject: true });

  console.log('Original image info:', info.width, info.height);

  // Let's examine the background color at the very corners:
  // (0,0), (767,0), (0, 1375), (767, 1375)
  const getPixel = (x, y) => {
    const idx = (y * info.width + x) * info.channels;
    return [data[idx], data[idx + 1], data[idx + 2]];
  };

  console.log('Top-Left bg:', getPixel(5, 5));
  console.log('Top-Right bg:', getPixel(760, 5));
  console.log('Bottom-Left bg:', getPixel(5, 1370));
  console.log('Bottom-Right bg:', getPixel(760, 1370));
  console.log('Mid-Left bg (y=1250):', getPixel(50, 1250));
  console.log('Mid-Right bg (y=1250):', getPixel(700, 1250));

  // Around y=1200..1365:
  // Let's print slices across x from 300 to 480 at y = 1220 (legs/socks), y = 1290 (top of shoes), y = 1340 (sole of shoes), y = 1365 (under shoes)
  for (const y of [1210, 1240, 1270, 1300, 1330, 1350, 1362, 1368]) {
    console.log(`\n--- y = ${y} ---`);
    let rowSummary = [];
    for (let x = 320; x <= 460; x += 5) {
      const [r, g, b] = getPixel(x, y);
      // classify
      let type = 'BG';
      // White socks: high brightness, low saturation
      // Brown skirt: r ~ 80..130, g ~ 50..90, b ~ 40..80
      // Black shoes: low brightness (r<60, g<60, b<60)
      if (r < 55 && g < 55 && b < 55) type = 'SHOE';
      else if (r > 210 && g > 210 && b > 210) type = 'SOCK/WHITE';
      else if (r > 190 && g > 185 && b > 180) type = 'BG-LIGHT';
      else if (r > 160 && g > 155 && b > 150) type = 'BG-MID';
      rowSummary.push(`${x}:${type}(${r},${g},${b})`);
    }
    console.log(rowSummary.join(' | '));
  }
}

analyzeAnatomy().catch(console.error);
