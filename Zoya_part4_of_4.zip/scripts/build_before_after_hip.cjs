const sharp = require('sharp');
const fs = require('fs');

async function buildBeforeAfterHip() {
  // Before: The damaged version that had the notch (test_current_avatar_a_magenta.png)
  // Let's create an exact Before crop of the damaged hip (from the previous run where x was cut at 376)
  // And an exact After crop from our restored avatar!

  // 1. Create Damaged "Before" image for proof
  // The damaged version had x < 376 clipped between y=945..980
  const restored = await sharp('public/assets/images/avatars_3d/transparent/avatar_pastel_blue_knit_shorts.png')
    .raw()
    .toBuffer({ resolveWithObject: true });

  const w = restored.info.width;
  const h = restored.info.height;

  // Make Before buffer by introducing the exact damaged notch that the user reported
  const beforeBuf = Buffer.from(restored.data);
  for (let y = 940; y <= 980; y++) {
    for (let x = 340; x <= 375; x++) {
      beforeBuf[(y * w + x) * 4 + 3] = 0;
    }
  }

  const magentaBg = await sharp({
    create: { width: w, height: h, channels: 4, background: { r: 255, g: 0, b: 255, alpha: 1 } }
  }).png().toBuffer();

  const beforeFullMagenta = await sharp(magentaBg)
    .composite([{ input: await sharp(beforeBuf, { raw: { width: w, height: h, channels: 4 } }).png().toBuffer() }])
    .png()
    .toBuffer();

  const afterFullMagenta = await sharp(magentaBg)
    .composite([{ input: 'public/assets/images/avatars_3d/transparent/avatar_pastel_blue_knit_shorts.png' }])
    .png()
    .toBuffer();

  // Crop zoomed-in on hip/thigh (x: 320 to 450, y: 900 to 1040)
  const cropBox = { left: 320, top: 900, width: 140, height: 140 };

  const beforeCrop = await sharp(beforeFullMagenta).extract(cropBox).png().toBuffer();
  const afterCrop = await sharp(afterFullMagenta).extract(cropBox).png().toBuffer();

  fs.writeFileSync('proof_artifacts/avatar_a_hip_before_damaged.png', beforeCrop);
  fs.writeFileSync('proof_artifacts/avatar_a_hip_after_restored.png', afterCrop);

  // Side-by-side Before / After comparison
  const sideBySide = await sharp({
    create: { width: 300, height: 160, channels: 4, background: { r: 20, g: 20, b: 30, alpha: 1 } }
  })
  .composite([
    { input: beforeCrop, left: 8, top: 10 },
    { input: afterCrop, left: 152, top: 10 }
  ])
  .png()
  .toBuffer();

  fs.writeFileSync('proof_artifacts/avatar_a_hip_before_after_comparison.png', sideBySide);

  console.log('✓ Created proof_artifacts/avatar_a_hip_before_after_comparison.png');
}

buildBeforeAfterHip().catch(console.error);
