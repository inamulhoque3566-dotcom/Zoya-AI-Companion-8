import sharp from 'sharp';
import fs from 'fs';
import path from 'path';

// Avatar definitions with hairstyle vertical bounds and face exclusion zones
const AVATAR_HAIR_PROFILES = {
  boho_mini_dress: {
    // Ponytail & side strands down to shoulders
    hairBottomY: 380,
    faceWidth: 55,
    faceHeight: 90,
    maxWeight: 0.85,
    hairColorCheck: (r, g, b, a) => a > 30 && (r < 110 && g < 80 && b < 80),
  },
  peasant_blouse_skirt: {
    // Long wavy hair down over shoulders
    hairBottomY: 520,
    faceWidth: 52,
    faceHeight: 95,
    maxWeight: 0.9,
    hairColorCheck: (r, g, b, a) => a > 30 && (r < 140 && g < 130 && b < 145),
  },
  pink_knit_maxi: {
    // Long wavy brown hair down to chest
    hairBottomY: 540,
    faceWidth: 50,
    faceHeight: 90,
    maxWeight: 0.9,
    hairColorCheck: (r, g, b, a) => a > 30 && (r < 125 && g < 100 && b < 95),
  },
  floral_palazzo_pants: {
    // Long dark flowing hair down to waist
    hairBottomY: 580,
    faceWidth: 52,
    faceHeight: 90,
    maxWeight: 0.92,
    hairColorCheck: (r, g, b, a) => a > 30 && (r < 155 && g < 135 && b < 140),
  },
  red_cardigan_floral: {
    // Long brown hair past shoulders
    hairBottomY: 440,
    faceWidth: 56,
    faceHeight: 90,
    maxWeight: 0.88,
    hairColorCheck: (r, g, b, a) => a > 30 && (r < 125 && g < 105 && b < 95),
  },
  plum_royal_anarkali: {
    // Long dark brown hair down over shoulders
    hairBottomY: 500,
    faceWidth: 52,
    faceHeight: 95,
    maxWeight: 0.9,
    hairColorCheck: (r, g, b, a) => a > 30 && (r < 140 && g < 115 && b < 110),
  },
  ivory_floral_anarkali: {
    // Long dark wavy hair down over shoulders
    hairBottomY: 520,
    faceWidth: 50,
    faceHeight: 95,
    maxWeight: 0.9,
    hairColorCheck: (r, g, b, a) => a > 30 && (r < 95 && g < 75 && b < 65),
  },
  classic: {
    // Signature bob with bangs down to collarbone
    hairBottomY: 460,
    faceWidth: 65,
    faceHeight: 110,
    maxWeight: 0.85,
    hairColorCheck: (r, g, b, a) => a > 30 && (r < 140 && g < 110 && b < 90),
  },
  avatar_urban_crop_hoodie: {
    // Red braided hair down over chest
    hairBottomY: 600,
    faceWidth: 58,
    faceHeight: 100,
    maxWeight: 0.9,
    hairColorCheck: (r, g, b, a) => a > 30 && (r > 100 && g < 65 && b < 70),
  },
  avatar_white_ruffle_babydoll: {
    // Dark wavy hair down to chest
    hairBottomY: 560,
    faceWidth: 62,
    faceHeight: 105,
    maxWeight: 0.9,
    hairColorCheck: (r, g, b, a) => a > 30 && (r < 80 && g < 65 && b < 65),
  },
  avatar_pink_athleisure_track: {
    // Pink short bob
    hairBottomY: 360,
    faceWidth: 55,
    faceHeight: 95,
    maxWeight: 0.82,
    hairColorCheck: (r, g, b, a) => a > 30 && (r > 110 && g < 110 && b < 125),
  },
  avatar_slate_blue_regal_kurta: {
    // Voluminous dark hair down to chest
    hairBottomY: 540,
    faceWidth: 60,
    faceHeight: 105,
    maxWeight: 0.9,
    hairColorCheck: (r, g, b, a) => a > 30 && (r < 110 && g < 100 && b < 105),
  },
  avatar_midnight_gold_zari_saree: {
    // Dark wavy hair down over shoulders
    hairBottomY: 530,
    faceWidth: 62,
    faceHeight: 105,
    maxWeight: 0.9,
    hairColorCheck: (r, g, b, a) => a > 30 && (r < 80 && g < 75 && b < 85),
  },
  avatar_nautical_denim_shorts: {
    // Dark brown wavy hair down over shoulders
    hairBottomY: 520,
    faceWidth: 62,
    faceHeight: 105,
    maxWeight: 0.9,
    hairColorCheck: (r, g, b, a) => a > 30 && (r < 75 && g < 65 && b < 75),
  },
};

async function run() {
  const { ANIME_3D_AVATARS } = await import('../src/data/anime3DAvatars.ts');
  const { ALL_AVATARS_ANATOMY } = await import('../src/data/avatarAnatomy.ts');

  for (const avatar of ANIME_3D_AVATARS) {
    const avatarId = avatar.id;
    console.log(`\n=== PROCESSING ASSETS FOR: ${avatarId} (${avatar.name}) ===`);

    const anatomy = ALL_AVATARS_ANATOMY[avatarId];
    if (!anatomy) {
      console.warn(`No anatomy found for ${avatarId}, skipping.`);
      continue;
    }

    const modularDir = path.join(process.cwd(), 'public', anatomy.modularPath);
    if (!fs.existsSync(modularDir)) {
      fs.mkdirSync(modularDir, { recursive: true });
    }

    // 1. Process eyes_half.png
    const eyesClosedPath = path.join(modularDir, 'eyes_closed.png');
    const eyesHalfPath = path.join(modularDir, 'eyes_half.png');

    if (fs.existsSync(eyesClosedPath)) {
      if (avatarId === 'avatar_pastel_blue_knit_shorts' && fs.existsSync(eyesHalfPath)) {
        console.log(`✓ Keeping existing custom eyes_half.png for ${avatarId}`);
      } else {
        const { data: closedData, info: closedInfo } = await sharp(eyesClosedPath)
          .ensureAlpha()
          .raw()
          .toBuffer({ resolveWithObject: true });

        const halfData = Buffer.alloc(closedInfo.width * closedInfo.height * 4);
        const w = closedInfo.width;
        const h = closedInfo.height;

        // Create natural half-blink: upper eyelid down ~50%, soft feathered gradient
        for (let y = 0; y < h; y++) {
          // Vertical factor for half blink:
          // Top portion (y < 0.40 * h): full eyelid coverage
          // Mid portion (0.40 * h <= y < 0.70 * h): smooth feathering
          // Bottom portion (y >= 0.70 * h): open eye area
          let yFactor = 0;
          const yRel = y / h;
          if (yRel < 0.40) {
            yFactor = 1.0;
          } else if (yRel < 0.70) {
            yFactor = 0.5 * (1 + Math.cos(((yRel - 0.40) / 0.30) * Math.PI));
          } else {
            yFactor = 0.08; // Keep faint hint of lower lid/crease
          }

          for (let x = 0; x < w; x++) {
            const idx = (y * w + x) * 4;
            halfData[idx + 0] = closedData[idx + 0];
            halfData[idx + 1] = closedData[idx + 1];
            halfData[idx + 2] = closedData[idx + 2];
            halfData[idx + 3] = Math.round(closedData[idx + 3] * yFactor);
          }
        }

        await sharp(halfData, { raw: { width: w, height: h, channels: 4 } })
          .png()
          .toFile(eyesHalfPath);
        console.log(`✓ Created eyes_half.png (${w}x${h}) for ${avatarId}`);
      }
    } else {
      console.warn(`! Missing eyes_closed.png for ${avatarId}`);
    }

    // 2. Process hair_mask.png
    const hairMaskPath = path.join(modularDir, 'hair_mask.png');
    if (avatarId === 'avatar_pastel_blue_knit_shorts' && fs.existsSync(hairMaskPath)) {
      console.log(`✓ Keeping existing perfected hair_mask.png for ${avatarId}`);
      continue;
    }

    const profile = AVATAR_HAIR_PROFILES[avatarId];
    if (!profile) {
      console.log(`No hair profile for ${avatarId}, skipping mask.`);
      continue;
    }

    const transparentPath = path.join(process.cwd(), 'public', avatar.transparentPng);
    if (!fs.existsSync(transparentPath)) {
      console.warn(`! Missing transparent PNG for ${avatarId}: ${transparentPath}`);
      continue;
    }

    const { data: rawData, info: rawInfo } = await sharp(transparentPath)
      .ensureAlpha()
      .raw()
      .toBuffer({ resolveWithObject: true });

    const w = rawInfo.width;
    const h = rawInfo.height;

    // Find head top
    let topY = 0;
    for (let y = 0; y < h; y++) {
      let found = false;
      for (let x = 0; x < w; x++) {
        if (rawData[(y * w + x) * 4 + 3] > 30) {
          topY = y;
          found = true;
          break;
        }
      }
      if (found) break;
    }

    const eyeX = Math.round(anatomy.eyeLandmarks?.eyeCenterX || w / 2);
    const eyeY = Math.round(anatomy.eyeLandmarks?.eyeCenterY || topY + 160);
    const hairBottomY = profile.hairBottomY;
    const anchorY = topY + 65; // Scalp anchor: 0 movement
    const mask = Buffer.alloc(w * h, 0);

    let hairPixelCount = 0;

    for (let y = 0; y < h; y++) {
      // Must be above hair bottom and below scalp anchor
      if (y < topY || y > hairBottomY) continue;

      for (let x = 0; x < w; x++) {
        const idx = (y * w + x) * 4;
        const r = rawData[idx + 0];
        const g = rawData[idx + 1];
        const b = rawData[idx + 2];
        const a = rawData[idx + 3];

        if (a < 30) continue;

        // Central Face Exclusion:
        // Exclude forehead down to chin, between inner cheeks
        const distFromCenterX = Math.abs(x - eyeX);
        const distFromCenterY = y - eyeY;
        const isCenterFace =
          distFromCenterX < profile.faceWidth &&
          distFromCenterY > -30 &&
          distFromCenterY < profile.faceHeight;

        if (isCenterFace) continue;

        // Scalp anchorage: 0 weight near top of head
        if (y <= anchorY) continue;

        // Check if pixel matches hair profile
        if (profile.hairColorCheck(r, g, b, a)) {
          // Vertical gradient: 0 at anchorY, increasing to 1.0 at hairBottomY
          const vertProgress = (y - anchorY) / (hairBottomY - anchorY);
          let vertWeight = Math.pow(vertProgress, 1.35);

          // Lateral boost: Outer strands sway slightly more than inner strands
          let lateralMultiplier = 1.0;
          if (distFromCenterX > profile.faceWidth + 25) {
            lateralMultiplier = 1.2;
          }

          const weight = Math.min(1.0, vertWeight * lateralMultiplier * profile.maxWeight);
          mask[y * w + x] = Math.round(weight * 255);
          hairPixelCount++;
        }
      }
    }

    // Soft feathering blur to guarantee smooth, non-tearing vertex deformation
    await sharp(mask, { raw: { width: w, height: h, channels: 1 } })
      .blur(2.2)
      .png()
      .toFile(hairMaskPath);

    console.log(`✓ Saved hair_mask.png (${hairPixelCount} hair pixels) for ${avatarId}`);
  }

  console.log('\n[COMPLETED] All 15 avatars now have eyes_closed, eyes_half, and hair_mask!');
}

run().catch(console.error);
