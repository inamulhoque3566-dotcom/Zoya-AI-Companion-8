const sharp = require('sharp');

async function inspectRemovedHem() {
  const src = await sharp('public/assets/aistudio/file_00000000c0d4821189e14bf178224f8d_f1687d5b.png')
    .raw()
    .toBuffer({ resolveWithObject: true });

  const cur = await sharp('public/assets/images/avatars_3d/transparent/avatar_midnight_gold_zari_saree.png')
    .raw()
    .toBuffer({ resolveWithObject: true });

  const w = src.info.width;
  const h = src.info.height;

  console.log('Pixels present in SRC but missing in CUR at bottom (y=1450..1536):');
  // Sample several rows
  for (let y = 1450; y < h; y += 15) {
    let missingSpans = [];
    let startX = -1;
    for (let x = 0; x < w; x++) {
      const idx = (y * w + x) * 4;
      const as = src.data[idx + 3];
      const ac = cur.data[idx + 3];
      if (as > 30 && ac === 0) {
        if (startX === -1) startX = x;
      } else {
        if (startX !== -1) {
          const sampleR = src.data[(y * w + startX) * 4];
          const sampleG = src.data[(y * w + startX) * 4 + 1];
          const sampleB = src.data[(y * w + startX) * 4 + 2];
          missingSpans.push(`[${startX}..${x-1}: rgb(${sampleR},${sampleG},${sampleB})]`);
          startX = -1;
        }
      }
    }
    if (startX !== -1) {
      missingSpans.push(`[${startX}..${w-1}]`);
    }
    console.log(`y=${y}:`, missingSpans.join(', '));
  }
}

inspectRemovedHem().catch(console.error);
