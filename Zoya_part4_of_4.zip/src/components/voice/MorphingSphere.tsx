import React, { useEffect, useRef } from 'react';
import { AssistantState } from '../../services/speech/SpeechTypes';
import { audioLevelStore } from '../../services/speech/audioLevelStore';

interface MorphingSphereProps {
  state: AssistantState;
  audioLevel?: number; // 0..1 target loudness
  size?: number; // dimension in px (default 120)
  onClick?: () => void;
  className?: string;
}

function getAnimationPeriodMs(state: AssistantState): [number, number] {
  switch (state) {
    case AssistantState.IDLE:
      return [6000, 3500];
    case AssistantState.LISTENING:
      return [3500, 1400];
    case AssistantState.PROCESSING:
    case AssistantState.THINKING:
      return [9000, 4500];
    case AssistantState.PREPARING_SPEECH:
    case AssistantState.SPEAKING:
      return [4000, 1800];
    case AssistantState.ERROR:
      return [2500, 800];
    default:
      return [6000, 3500];
  }
}

function getAudioWeight(state: AssistantState): number {
  switch (state) {
    case AssistantState.LISTENING:
      return 1.0;
    case AssistantState.SPEAKING:
    case AssistantState.PREPARING_SPEECH:
      return 0.7;
    case AssistantState.THINKING:
    case AssistantState.PROCESSING:
      return 0.2;
    default:
      return 0.0;
  }
}

function getHarmonicsSlow(state: AssistantState): [number, number] {
  switch (state) {
    case AssistantState.IDLE:
      return [2, 0.045];
    case AssistantState.LISTENING:
      return [3, 0.06];
    case AssistantState.PROCESSING:
    case AssistantState.THINKING:
      return [2, 0.09];
    case AssistantState.PREPARING_SPEECH:
    case AssistantState.SPEAKING:
      return [3, 0.07];
    case AssistantState.ERROR:
      return [5, 0.12];
    default:
      return [2, 0.045];
  }
}

function getHarmonicsFast(state: AssistantState, audio: number): [number, number] {
  let k = 5;
  let baseAmp = 0.018;

  switch (state) {
    case AssistantState.IDLE:
      k = 5;
      baseAmp = 0.018;
      break;
    case AssistantState.LISTENING:
      k = 6;
      baseAmp = 0.035;
      break;
    case AssistantState.THINKING:
    case AssistantState.PROCESSING:
      k = 4;
      baseAmp = 0.04;
      break;
    case AssistantState.PREPARING_SPEECH:
    case AssistantState.SPEAKING:
      k = 5;
      baseAmp = 0.05;
      break;
    case AssistantState.ERROR:
      k = 8;
      baseAmp = 0.08;
      break;
  }
  const amp = baseAmp + 0.13 * audio;
  return [k, amp];
}

interface RGB {
  r: number;
  g: number;
  b: number;
}

function getStateRgb(state: AssistantState): RGB {
  switch (state) {
    case AssistantState.IDLE:
      return { r: 154, g: 160, b: 166 }; // #9AA0A6
    case AssistantState.LISTENING:
      return { r: 52, g: 211, b: 153 }; // #34D399
    case AssistantState.PROCESSING:
    case AssistantState.THINKING:
      return { r: 251, g: 191, b: 36 }; // #FBBF24
    case AssistantState.PREPARING_SPEECH:
    case AssistantState.SPEAKING:
      return { r: 96, g: 165, b: 250 }; // #60A5FA
    case AssistantState.ERROR:
      return { r: 239, g: 68, b: 68 }; // #EF4444
    default:
      return { r: 154, g: 160, b: 166 };
  }
}

/**
 * Organic audio-reactive MorphingSphere visualizer
 * Faithfully mirrors MorphingSphere.kt from openclaw-assistant
 */
export const MorphingSphere: React.FC<MorphingSphereProps> = ({
  state,
  audioLevel = 0,
  size = 120,
  onClick,
  className = '',
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const propAudioLevelRef = useRef(audioLevel);
  propAudioLevelRef.current = audioLevel;

  // Animation values kept in ref to persist across frames
  const animRef = useRef({
    phaseSlow: 0,
    phaseFast: 0,
    audioSmooth: 0,
    currentRgb: getStateRgb(state),
    lastTime: performance.now(),
  });

  useEffect(() => {
    let animationFrameId: number;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Retina display scaling
    const dpr = window.devicePixelRatio || 1;
    canvas.width = size * dpr;
    canvas.height = size * dpr;

    const render = (time: number) => {
      const dt = Math.min(64, time - animRef.current.lastTime);
      animRef.current.lastTime = time;

      const [slowPeriod, fastPeriod] = getAnimationPeriodMs(state);

      // Advance phases
      animRef.current.phaseSlow += (dt / slowPeriod) * 2 * Math.PI;
      animRef.current.phaseFast += (dt / fastPeriod) * 2 * Math.PI;
      if (animRef.current.phaseSlow > 2 * Math.PI) animRef.current.phaseSlow -= 2 * Math.PI;
      if (animRef.current.phaseFast > 2 * Math.PI) animRef.current.phaseFast -= 2 * Math.PI;

      // Smooth audio (prefers explicit prop if non-zero, otherwise live store)
      const currentAudioInput = propAudioLevelRef.current > 0 ? propAudioLevelRef.current : audioLevelStore.get();
      const targetAudio = Math.min(1, Math.max(0, currentAudioInput)) * getAudioWeight(state);
      animRef.current.audioSmooth += (targetAudio - animRef.current.audioSmooth) * 0.22;

      // Smooth color transition
      const targetRgb = getStateRgb(state);
      animRef.current.currentRgb.r += (targetRgb.r - animRef.current.currentRgb.r) * 0.12;
      animRef.current.currentRgb.g += (targetRgb.g - animRef.current.currentRgb.g) * 0.12;
      animRef.current.currentRgb.b += (targetRgb.b - animRef.current.currentRgb.b) * 0.12;

      const { r, g, b } = animRef.current.currentRgb;
      const rgbStr = `${Math.round(r)}, ${Math.round(g)}, ${Math.round(b)}`;

      // Setup drawing coordinate system
      ctx.save();
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.scale(dpr, dpr);

      const center = { x: size / 2, y: size / 2 };
      const baseRadius = (size / 2) * 0.78;

      const [kSlow, ampSlow] = getHarmonicsSlow(state);
      const [kFast, ampFast] = getHarmonicsFast(state, animRef.current.audioSmooth);

      const samples = 96;
      ctx.beginPath();
      for (let i = 0; i <= samples; i++) {
        const theta = (i / samples) * 2 * Math.PI;
        const r1 = ampSlow * Math.sin(kSlow * theta + animRef.current.phaseSlow);
        const r2 = ampFast * Math.sin(kFast * theta + animRef.current.phaseFast);
        const r3 =
          0.05 *
          animRef.current.audioSmooth *
          Math.cos(7 * theta - animRef.current.phaseFast * 1.7);
        const radius = baseRadius * (1 + r1 + r2 + r3);
        const px = center.x + radius * Math.cos(theta);
        const py = center.y + radius * Math.sin(theta);
        if (i === 0) {
          ctx.moveTo(px, py);
        } else {
          ctx.lineTo(px, py);
        }
      }
      ctx.closePath();

      // 1. Outer glow halo (audio-reactive)
      const glowRadius = baseRadius * (1.15 + 0.3 * animRef.current.audioSmooth);
      const glowGrad = ctx.createRadialGradient(center.x, center.y, baseRadius * 0.4, center.x, center.y, glowRadius);
      glowGrad.addColorStop(0, `rgba(${rgbStr}, 0.35)`);
      glowGrad.addColorStop(1, `rgba(${rgbStr}, 0)`);

      ctx.save();
      ctx.fillStyle = glowGrad;
      ctx.beginPath();
      ctx.arc(center.x, center.y, glowRadius, 0, 2 * Math.PI);
      ctx.fill();
      ctx.restore();

      // 2. Core fill - radial gradient from white-tinted highlight to state color
      const highlightX = center.x - baseRadius * 0.2;
      const highlightY = center.y - baseRadius * 0.25;
      const coreGrad = ctx.createRadialGradient(
        highlightX,
        highlightY,
        baseRadius * 0.1,
        center.x,
        center.y,
        baseRadius * 1.35
      );
      coreGrad.addColorStop(0, `rgba(255, 255, 255, 0.95)`);
      coreGrad.addColorStop(0.35, `rgba(${rgbStr}, 0.85)`);
      coreGrad.addColorStop(0.75, `rgba(${rgbStr}, 0.6)`);
      coreGrad.addColorStop(1, `rgba(${rgbStr}, 0.28)`);

      ctx.fillStyle = coreGrad;
      ctx.fill();

      // 3. Rim stroke for crisp definition
      ctx.lineWidth = 1.5;
      ctx.strokeStyle = `rgba(${rgbStr}, 0.8)`;
      ctx.stroke();

      ctx.restore();

      animationFrameId = requestAnimationFrame(render);
    };

    animationFrameId = requestAnimationFrame(render);

    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, [state, size]);

  return (
    <div
      onClick={onClick}
      className={`relative inline-flex items-center justify-center cursor-pointer select-none transition-transform duration-200 active:scale-95 ${className}`}
      style={{ width: size, height: size }}
      title={
        state === AssistantState.SPEAKING
          ? 'बोल रही हूँ (रोकने के लिए टैप करें)'
          : state === AssistantState.LISTENING
          ? 'माइक चालू है (रोकने के लिए टैप करें)'
          : 'माइक दबाकर बोलें'
      }
    >
      <canvas
        ref={canvasRef}
        style={{ width: `${size}px`, height: `${size}px` }}
        className="pointer-events-none"
      />
    </div>
  );
};
