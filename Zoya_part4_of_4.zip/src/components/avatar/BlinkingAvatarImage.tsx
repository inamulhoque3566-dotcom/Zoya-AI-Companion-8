import React, { useMemo, useState, useEffect, useRef } from 'react';
import { getAvatarAnatomy } from '../../data/avatarAnatomy';

export interface BlinkingAvatarImageProps {
  avatarId: string;
  src: string;
  alt: string;
  className?: string;
  imageClassName?: string;
  loading?: 'lazy' | 'eager';
  onError?: (e: React.SyntheticEvent<HTMLImageElement, Event>) => void;
}

type BlinkPhase = 'open' | 'half' | 'closed';

/**
 * Living Avatar Image Component for Settings Cards & Grid Previews
 * - Grounded organic breathing (anchored at feet, zero floating).
 * - Biological 3-stage simultaneous eyelid blink ('open' -> 'half' -> 'closed' -> 'half' -> 'open')
 *   every 3-6 seconds with natural double-blinking.
 * - Leaves 100% of the original face, hair, outfit, and colors pristine.
 */
export const BlinkingAvatarImage: React.FC<BlinkingAvatarImageProps> = ({
  avatarId,
  src,
  alt,
  className = '',
  imageClassName = '',
  loading = 'lazy',
  onError,
}) => {
  const anatomy = useMemo(() => getAvatarAnatomy(avatarId), [avatarId]);
  const [blinkPhase, setBlinkPhase] = useState<BlinkPhase>('open');
  const timerRef = useRef<any>(null);

  const eyesClosedSrc = anatomy?.modularPath ? `${anatomy.modularPath}/eyes_closed.png` : null;
  const eyesHalfSrc = anatomy?.modularPath ? `${anatomy.modularPath}/eyes_half.png` : null;

  // Preload eye textures to prevent any flicker during blink transitions
  useEffect(() => {
    if (eyesClosedSrc) {
      const img = new Image();
      img.src = eyesClosedSrc;
    }
    if (eyesHalfSrc) {
      const img = new Image();
      img.src = eyesHalfSrc;
    }
  }, [eyesClosedSrc, eyesHalfSrc]);

  useEffect(() => {
    let isMounted = true;

    const executeBlinkCycle = (onDone: () => void) => {
      // Phase 1: Closing half (50ms)
      setBlinkPhase(eyesHalfSrc ? 'half' : 'closed');
      timerRef.current = setTimeout(() => {
        if (!isMounted) return;
        // Phase 2: Fully closed (90ms)
        setBlinkPhase('closed');
        timerRef.current = setTimeout(() => {
          if (!isMounted) return;
          // Phase 3: Opening half (50ms)
          setBlinkPhase(eyesHalfSrc ? 'half' : 'open');
          timerRef.current = setTimeout(() => {
            if (!isMounted) return;
            // Phase 4: Fully open
            setBlinkPhase('open');
            onDone();
          }, 50);
        }, 90);
      }, 50);
    };

    const scheduleNextBlink = () => {
      // Natural 3.0 to 6.0 seconds interval
      const delayMs = (3.0 + Math.random() * 3.0) * 1000;
      timerRef.current = setTimeout(() => {
        if (!isMounted) return;
        executeBlinkCycle(() => {
          if (!isMounted) return;
          // ~16% probability of natural rapid double blink
          if (Math.random() < 0.16) {
            timerRef.current = setTimeout(() => {
              if (!isMounted) return;
              executeBlinkCycle(() => {
                if (!isMounted) return;
                scheduleNextBlink();
              });
            }, 120);
          } else {
            scheduleNextBlink();
          }
        });
      }, delayMs);
    };

    scheduleNextBlink();

    return () => {
      isMounted = false;
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, [avatarId, eyesHalfSrc]);

  // Aspect ratio calculation
  const aspectRatioStyle = useMemo(() => {
    if (anatomy?.widthPx && anatomy?.heightPx) {
      return { aspectRatio: `${anatomy.widthPx} / ${anatomy.heightPx}` };
    }
    return undefined;
  }, [anatomy]);

  // Eye landmarks calculation for eyelid overlay (exact pixel coordinates)
  const eyeStyle = useMemo(() => {
    if (!anatomy?.eyeLandmarks || !anatomy.widthPx || !anatomy.heightPx) return null;
    const { cropW, cropH, eyeCenterX, eyeCenterY } = anatomy.eyeLandmarks;
    const leftPercent = ((eyeCenterX - cropW / 2) / anatomy.widthPx) * 100;
    const topPercent = ((eyeCenterY - cropH / 2) / anatomy.heightPx) * 100;
    const widthPercent = (cropW / anatomy.widthPx) * 100;
    const heightPercent = (cropH / anatomy.heightPx) * 100;

    return {
      left: `${leftPercent}%`,
      top: `${topPercent}%`,
      width: `${widthPercent}%`,
      height: `${heightPercent}%`,
    };
  }, [anatomy]);

  // Select active eye image source based on current biological blink phase
  const activeEyeSrc = useMemo(() => {
    if (blinkPhase === 'closed') return eyesClosedSrc;
    if (blinkPhase === 'half') return eyesHalfSrc || eyesClosedSrc;
    return null;
  }, [blinkPhase, eyesClosedSrc, eyesHalfSrc]);

  return (
    <div className={`relative w-full h-full flex items-end justify-center select-none overflow-visible ${className}`}>
      {/* Living Grounded Container with subtle breathing */}
      <div
        className="relative max-w-full max-h-full h-full w-auto flex items-end justify-center overflow-visible zoya-card-breathe"
        style={aspectRatioStyle}
      >
        <img
          src={src}
          alt={alt}
          className={`w-full h-full object-contain object-bottom pointer-events-none select-none transition-transform duration-300 ${imageClassName}`}
          style={{
            imageRendering: 'auto',
          }}
          loading={loading}
          onError={onError}
          decoding="async"
        />

        {/* Biological Simultaneous Eyelid Overlay */}
        {eyeStyle && activeEyeSrc && blinkPhase !== 'open' && (
          <img
            src={activeEyeSrc}
            alt=""
            aria-hidden="true"
            className="absolute pointer-events-none select-none transition-opacity duration-75 opacity-100"
            style={{
              ...eyeStyle,
              objectFit: 'fill',
              zIndex: 3,
            }}
            loading="eager"
            decoding="sync"
          />
        )}
      </div>
    </div>
  );
};
