import React, { useEffect, useState } from 'react';
import {
  ArrowLeft,
  Instagram,
  LayoutGrid,
  Phone,
  MessageSquareText,
  Globe,
  Pencil,
  Mic,
  Volume2,
  Code,
  Terminal,
  Sliders,
  Sparkles,
  RotateCcw,
  Activity,
  History,
  Brain,
} from 'lucide-react';
import {
  websiteBuilderController,
  type WebsiteBuilderState,
} from './actions/WebsiteBuilderModal';

interface ZoyaMenuDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenInstagramGrowth?: () => void;
  onOpenAppLauncher: () => void;
  onOpenPhoneCall: () => void;
  onOpenMessageComposer: () => void;
  onOpenWebsiteBuilder: () => void;
  onOpenSketchCanvas: () => void;
  onOpenVoiceCall: () => void;
  onOpenTextChat: () => void;
  onOpenPythonStudio?: () => void;
  onOpenCodingAgent?: () => void;
  onOpenSettings: () => void;
  onOpenHologramSettings?: () => void;
  onResetChat: () => void;
  onOpenDiagnostic: () => void;
  onOpenHistory?: () => void;
  onOpenMemory?: () => void;
  onOpen14LivingAvatarsShowcase?: () => void;
  personaMode: string;
}

const CosmicBokehParticles: React.FC = () => (
  <div className="pointer-events-none absolute inset-0 overflow-hidden z-0" aria-hidden="true">
    {/* Deep Cosmic Ambient Glow Orbs */}
    <div className="absolute -top-16 left-1/4 w-72 h-72 rounded-full bg-[#7c3aed]/35 blur-[80px]" />
    <div className="absolute top-[28%] -left-12 w-64 h-64 rounded-full bg-[#6d28d9]/40 blur-[70px]" />
    <div className="absolute top-[48%] right-[-10%] w-80 h-80 rounded-full bg-[#9333ea]/45 blur-[85px]" />
    <div className="absolute bottom-[14%] left-[35%] w-96 h-64 rounded-full bg-[#a855f7]/50 blur-[75px]" />

    {/* Vertical & Diagonal Neon Light Streaks Between Cards */}
    <div className="absolute top-[15%] left-[49.5%] w-[3px] h-[62%] bg-gradient-to-b from-transparent via-[#e879f9]/65 to-transparent blur-[2px]" />
    <div className="absolute top-[25%] left-[48.5%] w-[10px] h-[45%] bg-gradient-to-b from-transparent via-[#c084fc]/35 to-transparent blur-[6px]" />

    {/* Glowing Bokeh Orbs & Starlight Specks (Especially in Lower Right & Edges as in Reference) */}
    <span className="absolute top-[11%] left-[21%] w-1.5 h-1.5 rounded-full bg-white/80 shadow-[0_0_6px_#fff]" />
    <span className="absolute top-[12.5%] left-[44%] w-1 h-1 rounded-full bg-purple-200/70" />
    <span className="absolute top-[14%] right-[2%] w-1 h-1 rounded-full bg-white/75" />
    <span className="absolute top-[27%] left-[49.8%] w-2 h-2 rounded-full bg-pink-200/90 blur-[0.5px] shadow-[0_0_10px_#f472b6]" />
    <span className="absolute top-[52%] left-[49.8%] w-1.5 h-1.5 rounded-full bg-purple-100/90 shadow-[0_0_8px_#e879f9]" />
    <span className="absolute top-[66%] left-[49.6%] w-2 h-2 rounded-full bg-pink-200/95 shadow-[0_0_12px_#f472b6]" />

    {/* Lower-Right Starfield & Bokeh Cluster (Beside Python Studio Card) */}
    <span className="absolute top-[71%] left-[53%] w-2.5 h-2.5 rounded-full bg-purple-200/80 blur-[1px] shadow-[0_0_10px_#e9d5ff]" />
    <span className="absolute top-[74%] left-[60%] w-3.5 h-3.5 rounded-full bg-pink-200/75 blur-[2px] shadow-[0_0_14px_#f472b6]" />
    <span className="absolute top-[70.5%] left-[79%] w-1.5 h-1.5 rounded-full bg-white/90 shadow-[0_0_6px_#fff]" />
    <span className="absolute top-[73.5%] left-[78.5%] w-1.5 h-1.5 rounded-full bg-white/85 shadow-[0_0_6px_#fff]" />
    <span className="absolute top-[74.5%] left-[80%] w-1 h-1 rounded-full bg-white/75" />
    <span className="absolute top-[75.2%] left-[83%] w-1 h-1 rounded-full bg-purple-100/80" />
    <span className="absolute top-[76%] left-[97%] w-1.5 h-1.5 rounded-full bg-white/90 shadow-[0_0_6px_#fff]" />
    <span className="absolute top-[78%] left-[74%] w-1 h-1 rounded-full bg-purple-100/70" />
    <span className="absolute top-[79%] left-[93%] w-1.5 h-1.5 rounded-full bg-white/85 shadow-[0_0_6px_#fff]" />
    <span className="absolute top-[80.5%] left-[53%] w-2.5 h-2.5 rounded-full bg-purple-200/70 blur-[1px]" />
    <span className="absolute top-[81%] left-[65%] w-2 h-2 rounded-full bg-purple-100/80 blur-[0.5px]" />
    <span className="absolute top-[81.5%] left-[72.5%] w-2 h-2 rounded-full bg-white/90 shadow-[0_0_8px_#fff]" />
    <span className="absolute top-[80.8%] left-[82.5%] w-2 h-2 rounded-full bg-white/85 shadow-[0_0_8px_#fff]" />
    <span className="absolute top-[83%] left-[96%] w-1 h-1 rounded-full bg-white/75" />
    <span className="absolute top-[86%] left-[15.5%] w-1.5 h-1.5 rounded-full bg-white/80" />
    <span className="absolute top-[87.5%] left-[74%] w-2 h-2 rounded-full bg-purple-200/75 blur-[1px]" />
    <span className="absolute top-[88%] left-[37%] w-1 h-1 rounded-full bg-purple-200/70" />

    {/* Horizontal Glowing Neon Flare Streak Across Utility Row */}
    <div className="absolute top-[83.2%] left-[44%] right-[4%] h-[2px] bg-gradient-to-r from-transparent via-white/90 to-transparent shadow-[0_0_14px_#f472b6,0_0_24px_#c084fc]" />
    <div className="absolute top-[82.8%] left-[38%] right-[2%] h-[8px] bg-gradient-to-r from-transparent via-[#e879f9]/55 to-transparent blur-[5px]" />
  </div>
);

const GoldenHome3DIcon: React.FC<{ className?: string }> = ({ className = 'w-6 h-6' }) => (
  <svg viewBox="0 0 32 32" fill="none" className={className} aria-hidden="true">
    <defs>
      <linearGradient id="homeGoldRoof" x1="16" y1="3" x2="16" y2="18" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#fef08a" />
        <stop offset="55%" stopColor="#facc15" />
        <stop offset="100%" stopColor="#eab308" />
      </linearGradient>
      <linearGradient id="homeGoldBody" x1="16" y1="12" x2="16" y2="28" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#fde047" />
        <stop offset="50%" stopColor="#fbbf24" />
        <stop offset="100%" stopColor="#d97706" />
      </linearGradient>
    </defs>
    {/* House Main Body */}
    <path
      d="M7 14.5L16 7L25 14.5V25.5C25 26.6 24.1 27.5 23 27.5H19V20.5C19 19.7 18.3 19 17.5 19H14.5C13.7 19 13 19.7 13 20.5V27.5H9C7.9 27.5 7 26.6 7 25.5V14.5Z"
      fill="url(#homeGoldBody)"
    />
    {/* Roof Overhang */}
    <path
      d="M4.2 15.8L14.7 6.3C15.4 5.6 16.6 5.6 17.3 6.3L27.8 15.8C28.4 16.3 28.1 17.3 27.2 17.3H25.2L16 9.1L6.8 17.3H4.8C3.9 17.3 3.6 16.3 4.2 15.8Z"
      fill="url(#homeGoldRoof)"
    />
  </svg>
);

export const ZoyaMenuDrawer: React.FC<ZoyaMenuDrawerProps> = ({
  isOpen,
  onClose,
  onOpenInstagramGrowth,
  onOpenAppLauncher,
  onOpenPhoneCall,
  onOpenMessageComposer,
  onOpenWebsiteBuilder,
  onOpenSketchCanvas,
  onOpenVoiceCall,
  onOpenTextChat,
  onOpenPythonStudio,
  onOpenCodingAgent,
  onOpenSettings,
  onOpenHologramSettings,
  onResetChat,
  onOpenDiagnostic,
  onOpenHistory,
  onOpenMemory,
  onOpen14LivingAvatarsShowcase,
}) => {
  const [websiteState, setWebsiteState] = useState<WebsiteBuilderState>(() =>
    websiteBuilderController.getState()
  );

  useEffect(() => {
    return websiteBuilderController.subscribe((next) => setWebsiteState(next));
  }, []);

  if (!isOpen) return null;

  // Exact 9 Quick Action Cards in exact order, titles, subtitles, and icons from the reference screenshot
  const quickActions = [
    {
      id: 'instagram_growth',
      title: 'Instagram Growth',
      subtext: 'Auto-post 1 reel + 1 photo daily',
      icon: Instagram,
      onClick: () => {
        if (onOpenInstagramGrowth) {
          onOpenInstagramGrowth();
        } else {
          onOpenSettings();
        }
      },
    },
    {
      id: 'app',
      title: 'Open an app',
      subtext: '"YouTube kholo"',
      icon: LayoutGrid,
      onClick: onOpenAppLauncher,
    },
    {
      id: 'call',
      title: 'Call someone',
      subtext: '"Mummy ko call karo"',
      icon: Phone,
      onClick: onOpenPhoneCall,
    },
    {
      id: 'message',
      title: 'Send a message',
      subtext: '"Papa ko WhatsApp karo"',
      icon: MessageSquareText,
      onClick: onOpenMessageComposer,
    },
    {
      id: 'website',
      title: 'Build a website',
      subtext:
        websiteState.status === 'streaming'
          ? `Website building… ${websiteState.progress}%`
          : websiteState.status === 'ready'
          ? `Ready (100%) · ${websiteState.title || 'Open finished site'}`
          : '"ek cafe ki website banao"',
      icon: Globe,
      onClick: onOpenWebsiteBuilder,
    },
    {
      id: 'sketch',
      title: 'Sketch a photo',
      subtext: '"drawing banao"',
      icon: Pencil,
      onClick: onOpenSketchCanvas,
    },
    {
      id: 'voice',
      title: 'Talk to LIA',
      subtext: 'Start a voice conversation',
      icon: Mic,
      onClick: onOpenVoiceCall,
    },
    {
      id: 'chat',
      title: 'Ask anything',
      subtext: 'Start a text conversation',
      icon: MessageSquareText,
      onClick: onOpenTextChat,
    },
    {
      id: 'python',
      title: 'Python Studio',
      subtext: 'Code, Matplotlib, Pandas & APIs',
      icon: Code,
      onClick: onOpenPythonStudio || onOpenWebsiteBuilder,
    },
    {
      id: 'coding_agent',
      title: 'Coding Agent',
      subtext: 'Autonomous workspace & tools',
      icon: Terminal,
      onClick: onOpenCodingAgent,
    },
    {
      id: 'living_avatars_14',
      title: '14 Living Avatars',
      subtext: 'Static camera • Breeze & blinks',
      icon: Sparkles,
      onClick: onOpen14LivingAvatarsShowcase || onOpenSettings,
    },
  ];

  return (
    <div
      data-testid="zoya-menu-drawer"
      className="fixed inset-0 z-50 w-full h-[100dvh] flex flex-col animate-fade-in select-none overflow-hidden"
    >
      {/* Backdrop */}
      <div
        onClick={onClose}
        className="fixed inset-0 bg-[#0d0422]/90 backdrop-blur-md transition-opacity"
      />

      {/* Full-Viewport Mobile-Responsive Cosmic Menu Container */}
      <div
        className="relative w-full h-full z-10 flex flex-col overflow-hidden"
        style={{
          background:
            'linear-gradient(180deg, #1b0a42 0%, #311073 28%, #581c9c 62%, #7628c9 82%, #4a148c 94%, #24094e 100%)',
          boxShadow: '0 0 50px rgba(124, 58, 237, 0.45)',
          paddingTop: 'env(safe-area-inset-top, 0px)',
          paddingBottom: 'env(safe-area-inset-bottom, 0px)',
          paddingLeft: 'env(safe-area-inset-left, 0px)',
          paddingRight: 'env(safe-area-inset-right, 0px)',
        }}
      >
        <CosmicBokehParticles />

        {/* Smooth Vertical Scroll Region Filling 100% Available Screen Area */}
        <div
          data-testid="zoya-menu-scroll-container"
          className="relative z-10 flex-1 min-h-0 w-full overflow-y-auto overflow-x-hidden overscroll-contain flex flex-col justify-between gap-3 px-2.5 min-[360px]:px-3.5 sm:px-5 md:px-6 py-2.5 min-[360px]:py-3 sm:py-4"
        >
          {/* TOP + CARDS SECTION */}
          <div className="flex flex-col shrink-0">
            {/* 1. Top Pill Header Bar: Back Arrow + "Quick actions" */}
            <div
              className="w-full rounded-[22px] min-[360px]:rounded-[26px] p-2 sm:p-2.5 flex items-center gap-2.5 min-[360px]:gap-3.5 relative overflow-hidden shrink-0"
              style={{
                background:
                  'linear-gradient(180deg, rgba(58, 31, 120, 0.92) 0%, rgba(26, 13, 62, 0.96) 55%, rgba(16, 7, 42, 0.98) 100%)',
                border: '1.5px solid rgba(165, 180, 252, 0.85)',
                boxShadow:
                  '0 0 18px rgba(139, 92, 246, 0.65), 0 0 6px rgba(56, 189, 248, 0.45), inset 0 1px 2px rgba(255, 255, 255, 0.35)',
              }}
            >
              {/* Top Specular Neon Highlight */}
              <div className="pointer-events-none absolute top-0 left-8 right-8 h-[1.5px] bg-gradient-to-r from-transparent via-cyan-200/80 to-transparent" />

              <button
                type="button"
                onClick={onClose}
                data-testid="menu-back-button"
                className="w-10 h-10 sm:w-11 sm:h-11 rounded-[13px] flex items-center justify-center text-white shrink-0 active:scale-95 transition-transform cursor-pointer"
                style={{
                  background: 'linear-gradient(180deg, #6336e8 0%, #4320a8 100%)',
                  border: '1px solid rgba(196, 181, 253, 0.55)',
                  boxShadow: '0 2px 8px rgba(0, 0, 0, 0.35), inset 0 1px 1px rgba(255, 255, 255, 0.3)',
                }}
                title="Back"
              >
                <ArrowLeft className="w-5 h-5 text-white stroke-[2.4]" />
              </button>

              <h2 className="text-[18px] min-[360px]:text-[20px] sm:text-[22px] font-extrabold tracking-tight text-white drop-shadow-[0_1px_4px_rgba(0,0,0,0.5)] truncate">
                Quick actions
              </h2>
            </div>

            {/* 2. Subtitle */}
            <p className="text-[11px] min-[380px]:text-[11.5px] sm:text-[12.5px] text-purple-100/95 font-normal tracking-tight px-1 mt-1.5 mb-2 leading-snug shrink-0">
              Tap one to start. Say it the way you would to a friend - Hindi, English or both.
            </p>

            {/* 3. Responsive Grid of Quick Action Cards */}
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2 min-[360px]:gap-2.5 sm:gap-3 auto-rows-fr">
              {quickActions.map((action) => {
                const Icon = action.icon;
                const isPhoneIcon = action.id === 'call';
                return (
                  <button
                    key={action.id}
                    type="button"
                    data-testid={`quick-action-${action.id}`}
                    onClick={() => {
                      onClose();
                      action.onClick?.();
                    }}
                    className="relative w-full min-w-0 h-full rounded-[18px] min-[360px]:rounded-[20px] sm:rounded-[22px] p-2.5 min-[360px]:p-3 sm:p-3.5 text-left flex flex-col justify-between min-h-[86px] min-[360px]:min-h-[94px] sm:min-h-[108px] transition-all duration-150 active:scale-[0.98] group cursor-pointer overflow-hidden"
                    style={{
                      background:
                        'linear-gradient(165deg, rgba(147, 94, 249, 0.94) 0%, rgba(103, 47, 214, 0.95) 42%, rgba(49, 20, 118, 0.97) 80%, rgba(29, 11, 76, 0.98) 100%)',
                      border: '1.5px solid rgba(196, 181, 253, 0.85)',
                      boxShadow:
                        '0 4px 16px rgba(46, 16, 101, 0.6), 0 0 12px rgba(167, 139, 250, 0.35), inset 0 1px 1.5px rgba(255, 255, 255, 0.45)',
                    }}
                  >
                    {/* Top Edge Gloss Highlight */}
                    <div className="pointer-events-none absolute top-0 left-4 right-4 h-[1px] bg-gradient-to-r from-transparent via-white/60 to-transparent" />

                    {/* Top-Left Translucent Purple Icon Box */}
                    <div
                      className="w-8 h-8 min-[360px]:w-9 min-[360px]:h-9 sm:w-10 sm:h-10 rounded-[11px] min-[360px]:rounded-[12px] sm:rounded-[13px] flex items-center justify-center text-white shrink-0 group-hover:scale-105 transition-transform"
                      style={{
                        background:
                          'linear-gradient(145deg, rgba(167, 139, 250, 0.65) 0%, rgba(124, 58, 237, 0.65) 100%)',
                        border: '1px solid rgba(233, 213, 255, 0.5)',
                        boxShadow:
                          '0 2px 8px rgba(30, 11, 75, 0.35), inset 0 1px 1px rgba(255, 255, 255, 0.35)',
                      }}
                    >
                      <Icon
                        className={`w-[17px] h-[17px] min-[360px]:w-[18px] min-[360px]:h-[18px] sm:w-5 sm:h-5 text-white stroke-[2.2] ${
                          isPhoneIcon ? 'fill-white' : ''
                        }`}
                      />
                    </div>

                    {/* Card Title & Subtitle */}
                    <div className="mt-2 min-w-0 w-full">
                      <h3 className="text-[12.5px] min-[360px]:text-[13.5px] sm:text-[14.5px] font-extrabold text-white leading-tight tracking-tight drop-shadow-[0_1px_2px_rgba(0,0,0,0.4)] break-words">
                        {action.title}
                      </h3>
                      <p
                        className={`text-[10px] min-[360px]:text-[10.5px] sm:text-[11.5px] mt-0.5 leading-tight line-clamp-2 break-words ${
                          action.id === 'website' && websiteState.status === 'streaming'
                            ? 'text-cyan-200 font-semibold'
                            : action.id === 'website' && websiteState.status === 'ready'
                            ? 'text-emerald-200 font-semibold'
                            : 'text-purple-100/90 font-normal'
                        }`}
                      >
                        {action.subtext}
                      </p>
                      {action.id === 'website' && websiteState.status === 'streaming' && (
                        <div className="mt-1.5 h-1 w-full overflow-hidden rounded-full bg-black/40">
                          <div
                            className="h-full bg-cyan-300 transition-all duration-300"
                            style={{ width: `${Math.max(6, websiteState.progress)}%` }}
                          />
                        </div>
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* BOTTOM UTILITIES + NEON NAVIGATION BAR SECTION */}
          <div className="relative z-10 mt-1 flex flex-col gap-2 shrink-0 w-full">
            {/* 4. Hindi Utility Links Row: सेटिंग्स | 3D होलोग्राम | रीसेट | हेल्थ चेक | टीटीएस जांच */}
            <div className="flex flex-wrap items-center justify-center sm:justify-between gap-x-2 min-[380px]:gap-x-3 gap-y-1.5 px-1 py-0.5 text-[11px] min-[380px]:text-[11.5px] sm:text-[12.5px] font-medium text-purple-100 w-full">
              <button
                type="button"
                data-testid="menu-util-settings"
                onClick={() => {
                  onClose();
                  onOpenSettings();
                }}
                className="inline-flex items-center justify-center gap-1.5 min-h-[36px] px-2 py-1 rounded-xl hover:text-white active:scale-95 transition-all cursor-pointer whitespace-nowrap"
              >
                <Sliders className="w-3.5 h-3.5 text-[#c4b5fd] shrink-0" />
                <span>सेटिंग्स</span>
              </button>

              <button
                type="button"
                data-testid="menu-util-hologram"
                onClick={() => {
                  onClose();
                  if (onOpenHologramSettings) {
                    onOpenHologramSettings();
                  } else {
                    onOpenSettings();
                  }
                }}
                className="inline-flex items-center justify-center gap-1.5 min-h-[36px] px-2 py-1 rounded-xl hover:text-cyan-200 active:scale-95 transition-all cursor-pointer whitespace-nowrap"
              >
                <Sparkles className="w-3.5 h-3.5 text-[#22d3ee] fill-[#22d3ee]/30 shrink-0" />
                <span>3D होलोग्राम</span>
              </button>

              <button
                type="button"
                data-testid="menu-util-reset"
                onClick={() => {
                  onResetChat();
                  onClose();
                }}
                className="inline-flex items-center justify-center gap-1.5 min-h-[36px] px-2 py-1 rounded-xl hover:text-amber-200 active:scale-95 transition-all cursor-pointer whitespace-nowrap"
              >
                <RotateCcw className="w-3.5 h-3.5 text-[#fbbf24] shrink-0" />
                <span>रीसेट</span>
              </button>

              <button
                type="button"
                data-testid="menu-util-diagnostic"
                onClick={() => {
                  onClose();
                  onOpenDiagnostic();
                }}
                className="inline-flex items-center justify-center gap-1.5 min-h-[36px] px-2 py-1 rounded-xl hover:text-emerald-200 active:scale-95 transition-all cursor-pointer whitespace-nowrap"
              >
                <Activity className="w-3.5 h-3.5 text-[#34d399] shrink-0" />
                <span>हेल्थ चेक</span>
              </button>

              <button
                type="button"
                data-testid="menu-util-tts-diagnostic"
                onClick={() => {
                  onClose();
                  window.dispatchEvent(new CustomEvent('open-tts-diagnostic'));
                }}
                className="inline-flex items-center justify-center gap-1.5 min-h-[36px] px-2 py-1 rounded-xl hover:text-[#8C9BFF] active:scale-95 transition-all cursor-pointer whitespace-nowrap"
              >
                <Volume2 className="w-3.5 h-3.5 text-[#8C9BFF] shrink-0" />
                <span>टीटीएस जांच</span>
              </button>
            </div>

            {/* 5. Bottom 4-Tab Neon Navigation Bar: Home | Chat | History | Memory */}
            <nav
              aria-label="Quick Actions Bottom Navigation"
              className="relative w-full rounded-[24px] min-[360px]:rounded-[28px] p-1 min-[360px]:p-1.5 grid grid-cols-4 gap-1 items-center"
              style={{
                background:
                  'linear-gradient(180deg, rgba(22, 10, 56, 0.96) 0%, rgba(8, 3, 24, 0.99) 60%, rgba(4, 2, 14, 1) 100%)',
                border: '1.5px solid rgba(103, 232, 249, 0.8)',
                boxShadow:
                  '0 0 24px rgba(168, 85, 247, 0.75), 0 0 10px rgba(34, 211, 238, 0.55), inset 0 0 14px rgba(139, 92, 246, 0.35)',
              }}
            >
              {/* Top & Bottom Specular Neon Glow Highlights on Nav Pill */}
              <div className="pointer-events-none absolute -top-[1px] left-10 right-10 h-[2px] bg-gradient-to-r from-transparent via-amber-200/90 to-transparent shadow-[0_0_10px_#fde047]" />
              <div className="pointer-events-none absolute -bottom-[1px] left-12 right-12 h-[2px] bg-gradient-to-r from-transparent via-pink-400/90 to-transparent shadow-[0_0_10px_#f472b6]" />

              {/* Tab 1: Home (Active) */}
              <button
                type="button"
                data-testid="menu-nav-home"
                onClick={onClose}
                className="relative min-w-0 w-full min-h-[48px] flex flex-col items-center justify-center py-1.5 px-1 min-[360px]:px-2 rounded-[18px] min-[360px]:rounded-[22px] active:scale-95 transition-all cursor-pointer"
                style={{
                  background:
                    'linear-gradient(180deg, rgba(67, 32, 150, 0.85) 0%, rgba(28, 12, 74, 0.95) 65%, rgba(16, 6, 44, 0.98) 100%)',
                  border: '1.2px solid rgba(192, 132, 252, 0.8)',
                  boxShadow:
                    '0 0 14px rgba(168, 85, 247, 0.5), inset 0 1px 1px rgba(255, 255, 255, 0.35)',
                }}
              >
                <div className="drop-shadow-[0_0_8px_rgba(251,191,36,0.85)]">
                  <GoldenHome3DIcon className="w-5 h-5 min-[360px]:w-6 min-[360px]:h-6" />
                </div>
                <span className="text-[10.5px] min-[360px]:text-[11.5px] sm:text-[12.5px] font-extrabold text-[#facc15] tracking-tight mt-0.5 drop-shadow-[0_0_6px_rgba(250,204,21,0.5)] truncate max-w-full">
                  Home
                </span>
                {/* Glowing Yellow Bottom Indicator */}
                <span className="absolute -bottom-[2px] w-7 min-[360px]:w-8 h-[3px] rounded-full bg-gradient-to-r from-amber-300 via-yellow-300 to-amber-400 shadow-[0_0_10px_#facc15]" />
              </button>

              {/* Tab 2: Chat */}
              <div className="relative min-w-0 flex items-center justify-center">
                <div className="pointer-events-none absolute left-0 top-2 bottom-2 w-[1px] bg-purple-300/25" />
                <button
                  type="button"
                  data-testid="menu-nav-chat"
                  onClick={() => {
                    onClose();
                    onOpenTextChat();
                  }}
                  className="w-full min-w-0 min-h-[48px] flex flex-col items-center justify-center py-1.5 px-1 min-[360px]:px-2 rounded-[18px] min-[360px]:rounded-[20px] text-purple-100 hover:text-white active:scale-95 transition-all cursor-pointer"
                >
                  <svg
                    viewBox="0 0 24 24"
                    fill="none"
                    className="w-5 h-5 min-[360px]:w-6 min-[360px]:h-6 text-purple-100 drop-shadow-[0_0_5px_rgba(216,180,254,0.5)]"
                    stroke="currentColor"
                    strokeWidth="2.1"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z" />
                  </svg>
                  <span className="text-[10.5px] min-[360px]:text-[11.5px] sm:text-[12.5px] font-bold text-white tracking-tight mt-0.5 truncate max-w-full">
                    Chat
                  </span>
                </button>
              </div>

              {/* Tab 3: History */}
              <div className="relative min-w-0 flex items-center justify-center">
                <div className="pointer-events-none absolute left-0 top-2 bottom-2 w-[1px] bg-purple-300/25" />
                <button
                  type="button"
                  data-testid="menu-nav-history"
                  onClick={() => {
                    onClose();
                    if (onOpenHistory) {
                      onOpenHistory();
                    }
                  }}
                  className="w-full min-w-0 min-h-[48px] flex flex-col items-center justify-center py-1.5 px-1 min-[360px]:px-2 rounded-[18px] min-[360px]:rounded-[20px] text-purple-100 hover:text-white active:scale-95 transition-all cursor-pointer"
                >
                  <History className="w-5 h-5 min-[360px]:w-6 min-[360px]:h-6 text-purple-100 stroke-[2.2] drop-shadow-[0_0_5px_rgba(216,180,254,0.5)]" />
                  <span className="text-[10.5px] min-[360px]:text-[11.5px] sm:text-[12.5px] font-bold text-white tracking-tight mt-0.5 truncate max-w-full">
                    History
                  </span>
                </button>
              </div>

              {/* Tab 4: Memory */}
              <div className="relative min-w-0 flex items-center justify-center">
                <div className="pointer-events-none absolute left-0 top-2 bottom-2 w-[1px] bg-purple-300/25" />
                <button
                  type="button"
                  data-testid="menu-nav-memory"
                  onClick={() => {
                    onClose();
                    if (onOpenMemory) {
                      onOpenMemory();
                    } else {
                      onOpenSettings();
                    }
                  }}
                  className="w-full min-w-0 min-h-[48px] flex flex-col items-center justify-center py-1.5 px-1 min-[360px]:px-2 rounded-[18px] min-[360px]:rounded-[20px] text-purple-100 hover:text-white active:scale-95 transition-all cursor-pointer"
                >
                  <Brain className="w-5 h-5 min-[360px]:w-6 min-[360px]:h-6 text-purple-100 stroke-[2.1] drop-shadow-[0_0_5px_rgba(216,180,254,0.5)]" />
                  <span className="text-[10.5px] min-[360px]:text-[11.5px] sm:text-[12.5px] font-bold text-white tracking-tight mt-0.5 truncate max-w-full">
                    Memory
                  </span>
                </button>
              </div>
            </nav>
          </div>
        </div>
      </div>
    </div>
  );
};
