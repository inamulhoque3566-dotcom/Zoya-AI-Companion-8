import React, { useEffect } from 'react';

export interface ZoyaMemoryViewProps {
  onBack?: () => void;
  onClose?: () => void;
  activePersonaMode?: string;
  currentPersonaMode?: string;
  onSelectPersonaMode?: (mode: string) => void;
  isInsideModal?: boolean;
  isFullscreen?: boolean;
  onOpenChat?: () => void;
  onOpenHistory?: () => void;
}

/**
 * ZoyaMemoryView — Settings Memory System (3D Emerald & Gold Reference Design)
 * Renders the exact same complete 3D Memory System as the Main Screen Memory System:
 * - Dark green and black futuristic background (#020906) with neon emerald, turquoise, and golden lighting
 * - Top Memory System information panel (87% Neural Path Efficiency & 3.29 Data Density) + rotating 3D Top Sphere
 * - Central neural network with continuous data-transfer animations
 * - Four memory identity sections: Zoya, Tara, Soyat, and Inamui
 * - Four individual 3D memory spheres rotating at full speed
 * - Large central 3D memory sphere rotating at full speed
 * - Animated neon data flowing from the 4 spheres into the central sphere and down into Long-Term Memory
 * - Memory Flow panel on the left & Creative Memory Activity panel on the right
 * - Important Files & Person / Likes panels
 * - Bottom Long-Term Memory storage structure & Chat, History, Memory navigation
 */
export const ZoyaMemoryView: React.FC<ZoyaMemoryViewProps> = ({
  onBack,
  onClose,
  onSelectPersonaMode,
  onOpenChat,
  onOpenHistory,
}) => {
  const effectiveBack = onBack || onClose || (() => {});

  useEffect(() => {
    const handleMsg = (e: MessageEvent) => {
      if (!e.data || typeof e.data !== 'object') return;
      if (e.data.type === 'ZOYA_BACK_TO_SETTINGS' || e.data.type === 'ZOYA_CLOSE_MEMORY') {
        effectiveBack();
      } else if (e.data.type === 'ZOYA_SELECT_MODE' && typeof e.data.mode === 'string') {
        onSelectPersonaMode?.(e.data.mode);
      } else if (e.data.type === 'ZOYA_NAV') {
        if (e.data.tab === 'chat') {
          effectiveBack();
          onOpenChat?.();
        } else if (e.data.tab === 'history') {
          effectiveBack();
          onOpenHistory?.();
        }
      }
    };

    window.addEventListener('message', handleMsg);
    return () => window.removeEventListener('message', handleMsg);
  }, [effectiveBack, onSelectPersonaMode, onOpenChat, onOpenHistory]);

  return (
    <div className="relative w-full h-full bg-[#020906] flex flex-col items-center justify-center overflow-hidden select-none text-white">
      <iframe
        src="/memory-system.html?context=settings"
        title="Settings Memory System — Zoya AI"
        className="w-full h-full border-0 bg-[#020906]"
        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope"
      />
    </div>
  );
};

