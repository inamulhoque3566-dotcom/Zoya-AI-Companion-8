import React from 'react';
import { Mic, MicOff, Sparkles, Volume2 } from 'lucide-react';
import { AssistantState } from '../services/speech/SpeechTypes';
import { MorphingSphere } from './voice/MorphingSphere';

interface ZoyaVoiceControllerProps {
  isListening: boolean;
  isSpeaking: boolean;
  isThinking?: boolean;
  isHandsFreeMode?: boolean;
  assistantState?: AssistantState;
  audioLevel?: number;
  liveTranscript?: string;
  onStartListening: () => void;
  onStopListening: () => void;
  onInterrupt?: () => void;
}

export const ZoyaVoiceController: React.FC<ZoyaVoiceControllerProps> = ({
  isListening,
  isSpeaking,
  isThinking = false,
  isHandsFreeMode = false,
  assistantState,
  audioLevel = 0,
  liveTranscript,
  onStartListening,
  onStopListening,
  onInterrupt,
}) => {
  // Resolve unified state from assistantState or legacy boolean flags
  const resolvedState: AssistantState =
    assistantState ??
    (isListening
      ? AssistantState.LISTENING
      : isSpeaking
      ? AssistantState.SPEAKING
      : isThinking
      ? AssistantState.THINKING
      : AssistantState.IDLE);

  const getStatusLabel = () => {
    switch (resolvedState) {
      case AssistantState.LISTENING:
        return isHandsFreeMode ? 'सुन रहा है... (बंद करने के लिए टैप करें)' : 'सुन रही हूँ... बोलिए';
      case AssistantState.PROCESSING:
        return 'आवाज़ समझ रही हूँ...';
      case AssistantState.THINKING:
        return 'ज़ोया सोच रही है...';
      case AssistantState.PREPARING_SPEECH:
      case AssistantState.SPEAKING:
        return isHandsFreeMode ? 'ज़ोया बोल रही है... (रोकने के लिए बोलें या टैप करें)' : 'जोया बोल रही है... (टैप करके रोकें)';
      case AssistantState.ERROR:
        return 'पुनः प्रयास करें';
      default:
        return isHandsFreeMode ? 'एक बार माइक दबाकर हैंड्स-फ़्री शुरू करें' : 'माइक दबाकर बोलें';
    }
  };

  const handleClick = () => {
    if (resolvedState === AssistantState.SPEAKING || resolvedState === AssistantState.PREPARING_SPEECH) {
      if (onInterrupt) {
        onInterrupt();
      } else {
        onStopListening();
      }
      return;
    }

    if (resolvedState === AssistantState.LISTENING) {
      onStopListening();
      return;
    }

    onStartListening();
  };

  return (
    <div className="w-full flex flex-col items-center justify-center gap-3 pb-6 pt-2 select-none">
      {/* Live Transcript / Subtitle Pill */}
      {liveTranscript && (
        <div className="max-w-md px-4 py-2 rounded-2xl bg-slate-900/85 backdrop-blur-md border border-slate-700/60 shadow-xl text-center animate-fade-in mx-4">
          <p className="text-xs sm:text-sm text-sky-200 font-medium line-clamp-2">
            {liveTranscript}
          </p>
        </div>
      )}

      {/* Main Interactive Controller: Organic Morphing Sphere & Mic Toggle */}
      <div className="relative flex flex-col items-center justify-center">
        {/* Animated Ripple Waves when Listening */}
        {resolvedState === AssistantState.LISTENING && (
          <>
            <div className="absolute w-32 h-32 rounded-full bg-emerald-500/20 animate-ping pointer-events-none" />
            <div className="absolute w-24 h-24 rounded-full bg-emerald-500/30 animate-pulse pointer-events-none" />
          </>
        )}

        {/* Morphing Sphere Visualizer (Ported from MorphingSphere.kt) */}
        <div className="relative z-10 flex items-center justify-center p-1">
          <MorphingSphere
            state={resolvedState}
            audioLevel={audioLevel}
            size={100}
            onClick={handleClick}
          />

          {/* Central Action Icon Overlay inside the sphere */}
          <button
            onClick={handleClick}
            className="absolute inset-0 m-auto w-12 h-12 rounded-full flex items-center justify-center text-white bg-slate-950/40 backdrop-blur-[2px] hover:bg-slate-950/20 transition-all active:scale-90"
            title={getStatusLabel()}
          >
            {resolvedState === AssistantState.LISTENING ? (
              <MicOff className="w-5 h-5 text-emerald-300 animate-pulse" />
            ) : resolvedState === AssistantState.SPEAKING ? (
              <Volume2 className="w-5 h-5 text-sky-300 animate-bounce" />
            ) : resolvedState === AssistantState.THINKING ? (
              <Sparkles className="w-5 h-5 text-amber-300 animate-spin" />
            ) : (
              <Mic className="w-5 h-5 text-white/90" />
            )}
          </button>
        </div>

        {/* State Label Caption */}
        <span
          className={`text-[11px] sm:text-xs font-medium tracking-wide mt-2 px-3 py-1 rounded-full transition-colors ${
            resolvedState === AssistantState.LISTENING
              ? 'text-emerald-400 bg-emerald-950/40 border border-emerald-500/30'
              : resolvedState === AssistantState.SPEAKING
              ? 'text-sky-300 bg-sky-950/40 border border-sky-500/30'
              : resolvedState === AssistantState.THINKING
              ? 'text-amber-300 bg-amber-950/40 border border-amber-500/30'
              : 'text-slate-400 hover:text-slate-300'
          }`}
        >
          {getStatusLabel()}
        </span>
      </div>
    </div>
  );
};
