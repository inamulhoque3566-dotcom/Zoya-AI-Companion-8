import React, { useState, useEffect } from 'react';
import {
  X,
  Activity,
  Download,
  Copy,
  Check,
  Trash2,
  Play,
  Loader2,
  Clock,
  Zap,
  Volume2,
  FileSpreadsheet,
} from 'lucide-react';
import {
  latencyLogger,
  LatencyLogEntry,
  extractFirstCompleteSentence,
  splitVoiceReplyAndVisualCard,
  selectOptimalModelForRequest,
} from '../services/latencyLogger';

interface LatencyLogModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSpeakText?: (text: string) => void;
}

export const LatencyLogModal: React.FC<LatencyLogModalProps> = ({
  isOpen,
  onClose,
  onSpeakText,
}) => {
  const [entries, setEntries] = useState<LatencyLogEntry[]>(() =>
    latencyLogger.getEntries()
  );
  const [copiedJson, setCopiedJson] = useState<boolean>(false);
  const [isRunningProbe, setIsRunningProbe] = useState<boolean>(false);
  const [probePrompt, setProbePrompt] = useState<string>(
    'Explain how Android AccessibilityService and KeyguardManager work together in 3 short sentences.'
  );

  useEffect(() => {
    setEntries(latencyLogger.getEntries());
    const unsub = latencyLogger.subscribe(() => {
      setEntries(latencyLogger.getEntries());
    });
    return unsub;
  }, [isOpen]);

  if (!isOpen) return null;

  const stats = latencyLogger.getSummaryStats();

  const handleExportFile = (format: 'json' | 'csv') => {
    const content =
      format === 'json' ? latencyLogger.exportAsJson() : latencyLogger.exportAsCsv();
    const mime = format === 'json' ? 'application/json' : 'text/csv';
    const ext = format === 'json' ? 'json' : 'csv';
    const fileName = `zoya-phone-latency-log-${Date.now()}.${ext}`;

    const blob = new Blob([content], { type: mime });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleCopyJson = () => {
    const json = latencyLogger.exportAsJson();
    navigator.clipboard.writeText(json);
    setCopiedJson(true);
    setTimeout(() => setCopiedJson(false), 2000);
  };

  const handleRunLivePhoneProbe = async () => {
    if (isRunningProbe || !probePrompt.trim()) return;
    setIsRunningProbe(true);

    const opt = selectOptimalModelForRequest(probePrompt);
    const reqId = latencyLogger.startRequest({
      query: probePrompt,
      source: 'benchmark',
      model: opt.model,
      relevantToolCount: opt.relevantTools.length,
    });

    try {
      const response = await fetch('/api/chat-stream', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: probePrompt,
          personaMode: 'professional',
          language: 'en-IN',
          relevantToolNames: opt.relevantTools.map((t) => t.name),
          fastMode: opt.isSimpleRequest,
        }),
      });

      if (!response.ok || !response.body) {
        throw new Error(`HTTP ${response.status}`);
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';
      let sentenceBuffer = '';
      let fullReply = '';
      let firstTokenRecorded = false;
      let firstSpeechRecorded = false;

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() || '';

        for (const line of lines) {
          const trimmed = line.trim();
          if (!trimmed.startsWith('data:')) continue;
          const dataStr = trimmed.replace(/^data:\s*/, '').trim();
          if (dataStr === '[DONE]') break;

          try {
            const parsed = JSON.parse(dataStr);
            if (parsed.text) {
              if (!firstTokenRecorded) {
                firstTokenRecorded = true;
                latencyLogger.markFirstToken(reqId);
              }
              fullReply += parsed.text;
              sentenceBuffer += parsed.text;

              if (!firstSpeechRecorded) {
                const { firstSentence } = extractFirstCompleteSentence(sentenceBuffer);
                if (firstSentence) {
                  firstSpeechRecorded = true;
                  latencyLogger.markFirstSpeech(reqId, firstSentence);
                  onSpeakText?.(firstSentence);
                }
              }
            }
          } catch {
            // ignore
          }
        }
      }

      const split = splitVoiceReplyAndVisualCard(fullReply);
      if (!firstSpeechRecorded && split.spokenSummary) {
        latencyLogger.markFirstSpeech(reqId, split.spokenSummary);
        onSpeakText?.(split.spokenSummary);
      }

      latencyLogger.markDone(reqId, {
        fullOutput: fullReply,
        spokenText: split.spokenSummary,
        routedToCard: split.routedToCard,
        status: 'completed',
      });
    } catch {
      latencyLogger.markDone(reqId, { status: 'error' });
    } finally {
      setIsRunningProbe(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-950/90 backdrop-blur-md animate-fade-in select-text">
      <div className="relative w-full max-w-4xl bg-[#090d1a] rounded-3xl border border-cyan-500/35 shadow-2xl overflow-hidden flex flex-col h-[90dvh]">
        {/* Header */}
        <div className="flex items-center justify-between px-4 sm:px-6 py-3.5 border-b border-slate-800 bg-slate-950/80 shrink-0">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-cyan-500 to-indigo-600 flex items-center justify-center text-white shadow-lg shrink-0">
              <Activity className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <h3 className="text-sm sm:text-base font-bold text-white truncate">
                On-Device Latency Log &amp; Voice Pipeline Telemetry
              </h3>
              <p className="text-[11px] text-slate-400 truncate">
                Records Message Sent → First Token (TTFT) → First Speech (TTFSS) → Done on your real phone &amp; network
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            <button
              onClick={() => handleExportFile('json')}
              className="px-3 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-sm"
              title="Export Latency Log as JSON"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export JSON</span>
            </button>
            <button
              onClick={() => handleExportFile('csv')}
              className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-sm"
              title="Export Latency Log as CSV"
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              <span>CSV</span>
            </button>
            <button
              onClick={handleCopyJson}
              className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 cursor-pointer"
              title="Copy JSON to Clipboard"
            >
              {copiedJson ? (
                <Check className="w-4 h-4 text-emerald-400" />
              ) : (
                <Copy className="w-4 h-4" />
              )}
            </button>
            <button
              onClick={() => latencyLogger.clearAll()}
              className="p-2 rounded-xl bg-slate-900 hover:bg-rose-950 border border-slate-700 text-slate-400 hover:text-rose-300 cursor-pointer"
              title="Clear Log"
            >
              <Trash2 className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
          {/* Summary Metrics Bar */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            <div className="p-3 rounded-2xl bg-slate-900/90 border border-slate-800">
              <div className="text-[10px] text-slate-400 uppercase font-semibold flex items-center gap-1">
                <Zap className="w-3 h-3 text-cyan-400" />
                <span>First Token (TTFT)</span>
              </div>
              <div className="text-base sm:text-lg font-black text-cyan-300 font-mono mt-0.5">
                {stats.medianTtftMs} ms
              </div>
              <div className="text-[10px] text-slate-500 font-mono">
                Median | p95: {stats.p95TtftMs} ms
              </div>
            </div>

            <div className="p-3 rounded-2xl bg-slate-900/90 border border-slate-800">
              <div className="text-[10px] text-slate-400 uppercase font-semibold flex items-center gap-1">
                <Volume2 className="w-3 h-3 text-pink-400" />
                <span>First Speech (TTFSS)</span>
              </div>
              <div className="text-base sm:text-lg font-black text-pink-300 font-mono mt-0.5">
                {stats.medianTtfssMs} ms
              </div>
              <div className="text-[10px] text-slate-500 font-mono">
                Median | p95: {stats.p95TtfssMs} ms
              </div>
            </div>

            <div className="p-3 rounded-2xl bg-slate-900/90 border border-slate-800">
              <div className="text-[10px] text-slate-400 uppercase font-semibold flex items-center gap-1">
                <Clock className="w-3 h-3 text-emerald-400" />
                <span>Total Stream Done</span>
              </div>
              <div className="text-base sm:text-lg font-black text-emerald-300 font-mono mt-0.5">
                {stats.medianTotalMs} ms
              </div>
              <div className="text-[10px] text-slate-500 font-mono">
                Median | p95: {stats.p95TotalMs} ms
              </div>
            </div>

            <div className="p-3 rounded-2xl bg-slate-900/90 border border-slate-800">
              <div className="text-[10px] text-slate-400 uppercase font-semibold">
                Recorded Requests
              </div>
              <div className="text-base sm:text-lg font-black text-white font-mono mt-0.5">
                {entries.length}
              </div>
              <div className="text-[10px] text-slate-500 font-mono">
                Completed: {stats.count}
              </div>
            </div>
          </div>

          {/* Live On-Phone Probe Runner */}
          <div className="p-4 rounded-2xl bg-slate-900/90 border border-cyan-500/30 space-y-2.5">
            <div className="text-xs font-bold text-white flex items-center justify-between">
              <span>Run Live Pipeline Measurement on This Device</span>
              <span className="text-[10px] font-mono text-cyan-300">
                Selective Schemas + First-Sentence TTS + Card Routing
              </span>
            </div>
            <div className="flex flex-col sm:flex-row gap-2">
              <input
                type="text"
                value={probePrompt}
                onChange={(e) => setProbePrompt(e.target.value)}
                placeholder="Enter test prompt to measure on your phone network..."
                className="flex-1 px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white outline-none focus:border-cyan-500"
              />
              <button
                onClick={handleRunLivePhoneProbe}
                disabled={isRunningProbe}
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-600 to-indigo-600 hover:brightness-110 disabled:opacity-50 text-white text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer shrink-0"
              >
                {isRunningProbe ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    <span>Measuring...</span>
                  </>
                ) : (
                  <>
                    <Play className="w-3.5 h-3.5" />
                    <span>Measure Request Now</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Request Stages Table */}
          <div className="space-y-2">
            <div className="text-xs font-bold text-slate-300">
              Recorded Request Stages (Message Sent → First Token → First Speech → Done)
            </div>

            {entries.length === 0 ? (
              <div className="p-8 rounded-2xl bg-slate-900/60 border border-slate-800 text-center text-xs text-slate-400">
                No requests logged yet. Speak to Zoya, send a chat message, or click &quot;Measure Request Now&quot; above.
              </div>
            ) : (
              <div className="space-y-2">
                {entries.map((entry) => (
                  <div
                    key={entry.id}
                    className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-2 text-xs"
                  >
                    <div className="flex items-center justify-between gap-2 flex-wrap">
                      <div className="flex items-center gap-2 min-w-0">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-mono uppercase font-bold ${
                            entry.source === 'voice'
                              ? 'bg-pink-500/20 text-pink-300 border border-pink-500/40'
                              : entry.source === 'benchmark'
                              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                              : 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/40'
                          }`}
                        >
                          {entry.source}
                        </span>
                        <span className="font-bold text-white truncate max-w-md">
                          &ldquo;{entry.queryPreview}&rdquo;
                        </span>
                      </div>
                      <div className="flex items-center gap-2 text-[10px] font-mono text-slate-400">
                        <span>Model: {entry.model}</span>
                        <span>
                          Schemas: {entry.relevantToolCount}/{entry.totalRegistryTools}
                        </span>
                        <span>{new Date(entry.messageSentMs).toLocaleTimeString()}</span>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 pt-1 font-mono text-[11px]">
                      <div className="p-2 rounded-xl bg-slate-950 border border-slate-800">
                        <span className="text-[9.5px] text-slate-500 block">1. Message Sent</span>
                        <span className="text-slate-200">0 ms (t0)</span>
                      </div>
                      <div className="p-2 rounded-xl bg-slate-950 border border-slate-800">
                        <span className="text-[9.5px] text-slate-500 block">2. First Token (TTFT)</span>
                        <span className="text-cyan-300 font-bold">
                          {entry.ttftMs !== null ? `${entry.ttftMs} ms` : '...'}
                        </span>
                      </div>
                      <div className="p-2 rounded-xl bg-slate-950 border border-slate-800">
                        <span className="text-[9.5px] text-slate-500 block">3. First Speech (TTFSS)</span>
                        <span className="text-pink-300 font-bold">
                          {entry.ttfssMs !== null ? `${entry.ttfssMs} ms` : 'N/A'}
                        </span>
                      </div>
                      <div className="p-2 rounded-xl bg-slate-950 border border-slate-800">
                        <span className="text-[9.5px] text-slate-500 block">4. Stream Done</span>
                        <span className="text-emerald-300 font-bold">
                          {entry.totalDurationMs !== null ? `${entry.totalDurationMs} ms` : '...'}
                        </span>
                      </div>
                      <div className="p-2 rounded-xl bg-slate-950 border border-slate-800">
                        <span className="text-[9.5px] text-slate-500 block">Spoken vs Card</span>
                        <span className="text-amber-200">
                          {entry.spokenChars}c spoken / {entry.totalOutputChars}c total{' '}
                          {entry.routedToCard ? '(Card)' : ''}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
