import React, { useState } from 'react';
import type { ExtractedFile } from '../types/zip';
import { 
  FileText, 
  Image as ImageIcon, 
  Download, 
  Copy, 
  Check, 
  Code, 
  Binary, 
  Search,
  Maximize2,
  FileCode
} from 'lucide-react';

interface FileViewerProps {
  file: ExtractedFile | null;
  onUpdateFileContent?: (filePath: string, newContent: string) => void;
}

export const FileViewer: React.FC<FileViewerProps> = ({ file, onUpdateFileContent }) => {
  const [copied, setCopied] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [isEditing, setIsEditing] = useState(false);
  const [editedText, setEditedText] = useState(file?.textContent || '');

  React.useEffect(() => {
    setEditedText(file?.textContent || '');
    setIsEditing(false);
  }, [file]);

  if (!file) {
    return (
      <div className="h-full min-h-[400px] flex flex-col items-center justify-center p-8 text-center bg-slate-900/40 rounded-xl border border-slate-800 text-slate-400">
        <FileCode className="w-12 h-12 text-slate-600 mb-3" />
        <h3 className="text-base font-semibold text-slate-200">कोई फ़ाइल चयनित नहीं है</h3>
        <p className="text-sm text-slate-400 max-w-sm mt-1">
          बाईं ओर की ट्री या सूची से किसी भी फ़ाइल पर क्लिक करें ताकि उसका पूरा डेटा देखा जा सके।
        </p>
      </div>
    );
  }

  const handleCopy = () => {
    if (file.textContent) {
      navigator.clipboard.writeText(file.textContent);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleDownload = () => {
    if (file.dataUrl && file.isImage) {
      const a = document.createElement('a');
      a.href = file.dataUrl;
      a.download = file.name;
      a.click();
    } else if (file.textContent !== undefined) {
      const blob = new Blob([file.textContent], { type: file.mimeType });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = file.name;
      a.click();
      URL.revokeObjectURL(url);
    } else if (file.rawUint8Array) {
      const blob = new Blob([file.rawUint8Array as unknown as BlobPart], { type: file.mimeType });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = file.name;
      a.click();
      URL.revokeObjectURL(url);
    }
  };

  const handleSaveEdit = () => {
    if (onUpdateFileContent) {
      onUpdateFileContent(file.path, editedText);
      setIsEditing(false);
    }
  };

  const formatBytes = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
  };

  // Prepare text lines for viewing
  const lines = (isEditing ? editedText : file.textContent || '').split('\n');

  return (
    <div className="flex flex-col h-full bg-slate-900 rounded-xl border border-slate-800 overflow-hidden shadow-xl">
      {/* Header bar */}
      <div className="flex items-center justify-between px-4 py-3 bg-slate-950/80 border-b border-slate-800 gap-3">
        <div className="flex items-center gap-2 min-w-0">
          {file.isImage ? (
            <ImageIcon className="w-4 h-4 text-emerald-400 shrink-0" />
          ) : file.isText ? (
            <Code className="w-4 h-4 text-sky-400 shrink-0" />
          ) : (
            <Binary className="w-4 h-4 text-amber-400 shrink-0" />
          )}
          <span className="font-mono text-sm font-medium text-slate-200 truncate" title={file.path}>
            {file.path}
          </span>
          <span className="text-xs text-slate-400 font-mono shrink-0">
            ({formatBytes(file.size)})
          </span>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          {file.isText && (
            <>
              {isEditing ? (
                <>
                  <button
                    onClick={handleSaveEdit}
                    className="px-2.5 py-1 text-xs font-medium text-emerald-300 bg-emerald-950/80 border border-emerald-700/60 rounded hover:bg-emerald-900 transition-colors"
                  >
                    सेव करें (Save)
                  </button>
                  <button
                    onClick={() => {
                      setEditedText(file.textContent || '');
                      setIsEditing(false);
                    }}
                    className="px-2.5 py-1 text-xs font-medium text-slate-300 bg-slate-800 border border-slate-700 rounded hover:bg-slate-700 transition-colors"
                  >
                    रद्द करें (Cancel)
                  </button>
                </>
              ) : (
                <button
                  onClick={() => setIsEditing(true)}
                  className="px-2.5 py-1 text-xs font-medium text-slate-300 bg-slate-800 border border-slate-700 rounded hover:bg-slate-700 transition-colors"
                >
                  संपादित करें (Edit)
                </button>
              )}

              <button
                onClick={handleCopy}
                className="flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium text-slate-300 bg-slate-800/80 border border-slate-700 rounded hover:bg-slate-700 transition-colors"
                title="सामग्री कॉपी करें"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'कॉपी हुआ' : 'Copy'}</span>
              </button>
            </>
          )}

          <button
            onClick={handleDownload}
            className="flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium text-sky-300 bg-sky-950/70 border border-sky-800/60 rounded hover:bg-sky-900 transition-colors"
            title="फ़ाइल डाउनलोड करें"
          >
            <Download className="w-3.5 h-3.5" />
            <span>डाउनलोड</span>
          </button>
        </div>
      </div>

      {/* Main viewer body */}
      <div className="flex-1 overflow-auto p-4 bg-slate-950/40">
        {file.isImage && file.dataUrl ? (
          <div className="flex flex-col items-center justify-center p-6 h-full min-h-[350px]">
            <div className="relative p-2 bg-slate-900/90 rounded-lg border border-slate-800 shadow-2xl max-w-full">
              <img
                src={file.dataUrl}
                alt={file.name}
                className="max-h-[460px] max-w-full object-contain rounded"
              />
            </div>
            <div className="mt-4 flex items-center gap-4 text-xs text-slate-400">
              <span>प्रारूप: {file.extension.toUpperCase()}</span>
              <span>·</span>
              <span>साइज: {formatBytes(file.size)}</span>
              <span>·</span>
              <span>पथ: {file.path}</span>
            </div>
          </div>
        ) : file.isText && file.textContent !== undefined ? (
          isEditing ? (
            <textarea
              value={editedText}
              onChange={(e) => setEditedText(e.target.value)}
              className="w-full h-full min-h-[450px] p-4 font-mono text-xs text-slate-200 bg-slate-950 border border-slate-800 rounded-lg focus:outline-none focus:ring-1 focus:ring-sky-500 resize-none"
              spellCheck={false}
            />
          ) : (
            <div className="font-mono text-xs leading-relaxed text-slate-300 select-text">
              <table className="w-full border-collapse">
                <tbody>
                  {lines.map((line, idx) => {
                    const lineNum = idx + 1;
                    const isMatched = searchTerm && line.toLowerCase().includes(searchTerm.toLowerCase());
                    return (
                      <tr
                        key={idx}
                        className={`hover:bg-slate-800/40 ${isMatched ? 'bg-amber-950/40' : ''}`}
                      >
                        <td className="w-12 pr-4 text-right select-none text-slate-600 align-top py-0.5">
                          {lineNum}
                        </td>
                        <td className="whitespace-pre-wrap break-all py-0.5 text-slate-200">
                          {line || ' '}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )
        ) : (
          <div className="p-6 text-center text-slate-400 font-mono text-xs">
            <Binary className="w-10 h-10 text-slate-600 mx-auto mb-3" />
            <p className="text-slate-300 font-medium mb-1">बाइनरी फ़ाइल (Binary File)</p>
            <p className="text-slate-500 mb-4">
              यह फ़ाइल बाइनरी प्रारूप में है ({file.mimeType}, {formatBytes(file.size)})।
            </p>
            {file.rawUint8Array && (
              <div className="max-w-xl mx-auto p-3 bg-slate-950 border border-slate-800 rounded text-left overflow-x-auto text-[11px] text-slate-400">
                <div className="text-slate-500 mb-1">हेक्स पूर्वावलोकन (प्रथम 64 बाइट्स):</div>
                <div className="font-mono break-all text-sky-400/90">
                  {Array.from(file.rawUint8Array.slice(0, 64))
                    .map((b) => b.toString(16).padStart(2, '0'))
                    .join(' ')}
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Footer stats bar */}
      <div className="flex items-center justify-between px-4 py-2 bg-slate-950 border-t border-slate-800 text-xs text-slate-500 font-mono">
        <div>
          {file.isText && (
            <span>
              {lines.length} पंक्तियाँ (Lines) · {(file.textContent || '').length} अक्षर (Chars)
            </span>
          )}
        </div>
        <div>MIME: {file.mimeType}</div>
      </div>
    </div>
  );
};
