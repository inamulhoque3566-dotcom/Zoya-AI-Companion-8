import React, { useState, useEffect } from 'react';
import {
  Youtube,
  Search,
  Plus,
  Trash2,
  Check,
  ExternalLink,
  Smartphone,
  Globe,
  Radio,
  Play,
  KeyRound,
  RotateCw,
  AlertTriangle,
  CheckCircle2,
  Sparkles,
  Music,
  Users,
  Star,
  Film
} from 'lucide-react';
import {
  youtubeManager,
  PreferredYouTubeApp,
  FavoriteSinger,
  YouTubeApiStatus,
  YouTubeChannel,
  YouTubeVideo,
  SUGGESTED_SINGERS,
  AppDetectionDetails,
} from '../services/youtubeManager';

interface ZoyaYouTubeSettingsProps {
  onBack?: () => void;
  onPlayVideo?: (video: YouTubeVideo) => void;
}

export const ZoyaYouTubeSettings: React.FC<ZoyaYouTubeSettingsProps> = ({ onPlayVideo }) => {
  // App Selection & Detection State
  const [preferredApp, setPreferredApp] = useState<PreferredYouTubeApp>(() => youtubeManager.getPreferredApp());
  const [detection, setDetection] = useState<AppDetectionDetails>(() => youtubeManager.getAppDetectionDetails());
  const [launchFeedback, setLaunchFeedback] = useState<{ message: string; method: string } | null>(null);

  // API Status State
  const [apiStatus, setApiStatus] = useState<YouTubeApiStatus | null>(null);
  const [apiKeyInput, setApiKeyInput] = useState<string>('');
  const [isTestingStatus, setIsTestingStatus] = useState<boolean>(false);
  const [isSavingKey, setIsSavingKey] = useState<boolean>(false);
  const [saveMessage, setSaveMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Search Mode Tab: 'singers' (Channels & Artists) or 'songs' (Songs & Music Videos)
  const [searchTab, setSearchTab] = useState<'singers' | 'songs'>('singers');

  // Favorite Singers State
  const [favoriteSingers, setFavoriteSingers] = useState<FavoriteSinger[]>(() => youtubeManager.getFavoriteSingers());
  const [singerSearchQuery, setSingerSearchQuery] = useState<string>('');
  const [isSearchingSingers, setIsSearchingSingers] = useState<boolean>(false);
  const [singerSearchResults, setSingerSearchResults] = useState<YouTubeChannel[]>([]);
  const [singerSearchError, setSingerSearchError] = useState<string | null>(null);

  // Songs Search State
  const [songSearchQuery, setSongSearchQuery] = useState<string>('');
  const [isSearchingSongs, setIsSearchingSongs] = useState<boolean>(false);
  const [songSearchResults, setSongSearchResults] = useState<YouTubeVideo[]>([]);
  const [songSearchError, setSongSearchError] = useState<string | null>(null);

  // Preview / Playing State
  const [testVideoResult, setTestVideoResult] = useState<{ singer: string; videos: YouTubeVideo[] } | null>(null);
  const [isLoadingTracks, setIsLoadingTracks] = useState<boolean>(false);

  useEffect(() => {
    refreshStatus();
    setDetection(youtubeManager.getAppDetectionDetails());

    const handleSingersUpdated = () => {
      setFavoriteSingers(youtubeManager.getFavoriteSingers());
    };
    const handleAppChanged = () => {
      setPreferredApp(youtubeManager.getPreferredApp());
    };

    window.addEventListener('zoya_singers_updated', handleSingersUpdated);
    window.addEventListener('zoya_youtube_preferred_app_changed', handleAppChanged);
    return () => {
      window.removeEventListener('zoya_singers_updated', handleSingersUpdated);
      window.removeEventListener('zoya_youtube_preferred_app_changed', handleAppChanged);
    };
  }, []);

  const refreshStatus = async () => {
    setIsTestingStatus(true);
    try {
      const s = await youtubeManager.getStatus();
      setApiStatus(s);
    } finally {
      setIsTestingStatus(false);
    }
  };

  const handleSelectPreferredApp = (app: PreferredYouTubeApp) => {
    setPreferredApp(app);
    youtubeManager.setPreferredApp(app);
    setLaunchFeedback(null);
  };

  const handleTestAppLaunch = () => {
    // Test video ID: Arijit Singh's Kesariya (BddP6PYo2gs)
    const res = youtubeManager.openVideo('BddP6PYo2gs');
    setLaunchFeedback({
      message: `Launched test video using ${res.method.replace('_', ' ').toUpperCase()}`,
      method: res.method,
    });
    setTimeout(() => setLaunchFeedback(null), 5000);
  };

  const handleSaveApiKey = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!apiKeyInput.trim()) return;

    setIsSavingKey(true);
    setSaveMessage(null);
    try {
      const res = await youtubeManager.configureKey(apiKeyInput.trim());
      if (res.success) {
        setSaveMessage({ type: 'success', text: res.message || 'Key saved successfully!' });
        setApiKeyInput('');
        refreshStatus();
      } else {
        setSaveMessage({ type: 'error', text: res.message || 'Failed to validate API key.' });
      }
    } catch (err: any) {
      setSaveMessage({ type: 'error', text: err?.message || 'Error configuring key.' });
    } finally {
      setIsSavingKey(false);
    }
  };

  const handleSearchSingers = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const q = singerSearchQuery.trim();
    if (!q) return;

    setIsSearchingSingers(true);
    setSingerSearchError(null);
    setSingerSearchResults([]);

    try {
      const res = await youtubeManager.searchSingers(q);
      if (res.channels.length > 0) {
        setSingerSearchResults(res.channels);
      } else if (res.noKey) {
        setSingerSearchError('YouTube Data API key is not configured. Please add your key below to search all YouTube channels.');
      } else if (res.error) {
        setSingerSearchError(res.error);
      } else {
        setSingerSearchError(`No channels found for "${q}". Try another singer name.`);
      }
    } catch (err: any) {
      setSingerSearchError(err?.message || 'Error searching channels.');
    } finally {
      setIsSearchingSingers(false);
    }
  };

  const handleSearchSongs = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const q = songSearchQuery.trim();
    if (!q) return;

    setIsSearchingSongs(true);
    setSongSearchError(null);
    setSongSearchResults([]);

    try {
      const res = await youtubeManager.searchVideos(q, undefined, 10);
      if (res.videos.length > 0) {
        setSongSearchResults(res.videos);
      } else if (res.noKey) {
        setSongSearchError('YouTube Data API key is not configured. Enter key in the Security section below.');
      } else if (res.error) {
        setSongSearchError(res.error);
      } else {
        setSongSearchError(`No songs found matching "${q}".`);
      }
    } catch (err: any) {
      setSongSearchError(err?.message || 'Error searching songs.');
    } finally {
      setIsSearchingSongs(false);
    }
  };

  const handleAddSinger = (channel: YouTubeChannel | Omit<FavoriteSinger, 'id' | 'addedAt'>) => {
    const name = 'title' in channel ? channel.title : channel.name;
    const thumbnail = channel.thumbnail;
    const channelId = 'channelId' in channel ? channel.channelId : undefined;
    const channelTitle = 'title' in channel ? channel.title : channel.channelTitle;

    // First singer added automatically becomes Primary
    const isFirst = favoriteSingers.length === 0;

    youtubeManager.addFavoriteSinger({
      name,
      thumbnail,
      channelId,
      channelTitle,
      isPrimary: isFirst,
    });
    setFavoriteSingers(youtubeManager.getFavoriteSingers());
  };

  const handleRemoveSinger = (id: string) => {
    youtubeManager.removeFavoriteSinger(id);
    setFavoriteSingers(youtubeManager.getFavoriteSingers());
  };

  const handleSetPrimarySinger = (id: string) => {
    youtubeManager.setPrimaryFavoriteSinger(id);
    setFavoriteSingers(youtubeManager.getFavoriteSingers());
  };

  const handlePlaySingerTracks = async (singer: FavoriteSinger) => {
    setIsLoadingTracks(true);
    setTestVideoResult(null);
    try {
      const res = await youtubeManager.getSingerTopTracks(singer.name, singer.channelId);
      if (res.videos && res.videos.length > 0) {
        setTestVideoResult({ singer: singer.name, videos: res.videos });
      } else {
        const searchRes = await youtubeManager.searchVideos('best hit songs', singer.name, 6);
        if (searchRes.videos && searchRes.videos.length > 0) {
          setTestVideoResult({ singer: singer.name, videos: searchRes.videos });
        } else {
          youtubeManager.openVideo('', `https://www.youtube.com/results?search_query=${encodeURIComponent(singer.name + ' songs')}`);
        }
      }
    } finally {
      setIsLoadingTracks(false);
    }
  };

  const handleOpenVideo = (video: YouTubeVideo) => {
    if (onPlayVideo) {
      onPlayVideo(video);
    } else {
      youtubeManager.openVideo(video.videoId, video.videoUrl);
    }
  };

  return (
    <div className="space-y-5 animate-fade-in w-full text-slate-100">
      
      {/* 1. YOUTUBE APP SELECTION SECTION */}
      <div className="p-4 rounded-[20px] bg-[var(--theme-card-bg)] border border-[var(--theme-border)] shadow-sm space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-red-600/20 border border-red-500/40 flex items-center justify-center text-red-400">
              <Youtube className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-[15px] font-bold text-white flex items-center gap-2">
                YouTube App Selection
              </h3>
              <p className="text-xs text-slate-400">
                Choose preferred playback application for songs & videos.
              </p>
            </div>
          </div>

          {/* Device Detection Badge */}
          <div className={`px-2.5 py-1 rounded-full text-[10.5px] font-mono border flex items-center gap-1.5 ${
            detection.detected
              ? 'bg-emerald-950/60 border-emerald-500/50 text-emerald-300'
              : 'bg-blue-950/60 border-blue-500/50 text-blue-300'
          }`}>
            {detection.detected ? <Smartphone className="w-3 h-3 text-emerald-400" /> : <Globe className="w-3 h-3 text-blue-400" />}
            <span>{detection.detected ? 'YouTube App Supported' : 'Web Browser Ready'}</span>
          </div>
        </div>

        {/* Diagnostic Detection Info */}
        <div className="px-3 py-2 rounded-xl bg-black/30 border border-white/5 text-[11px] text-slate-400 flex items-center justify-between gap-2">
          <span>{detection.reason}</span>
          <button
            type="button"
            onClick={handleTestAppLaunch}
            className="text-[10px] font-bold px-2 py-1 rounded-lg bg-red-600/30 hover:bg-red-600/50 text-red-300 border border-red-500/40 transition-colors cursor-pointer shrink-0"
          >
            Test App Launch
          </button>
        </div>

        {launchFeedback && (
          <div className="p-2.5 rounded-xl bg-red-950/40 border border-red-500/50 text-xs text-red-300 flex items-center justify-between animate-fade-in">
            <span>{launchFeedback.message}</span>
            <span className="font-mono text-[10px] bg-red-900/60 px-2 py-0.5 rounded">Target: {launchFeedback.method}</span>
          </div>
        )}

        {/* 3 Playback Choices */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-1">
          {/* Option A: Official YouTube App */}
          <button
            type="button"
            onClick={() => handleSelectPreferredApp('youtube_app')}
            className={`p-3 rounded-2xl border text-left flex flex-col justify-between gap-2 transition-all cursor-pointer ${
              preferredApp === 'youtube_app'
                ? 'bg-red-950/40 border-red-500 shadow-[0_0_15px_rgba(239,68,68,0.25)]'
                : 'bg-slate-900/60 hover:bg-slate-900 border-slate-800'
            }`}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Smartphone className="w-4 h-4 text-red-400" />
                <span className="text-xs font-bold text-white">Official YouTube App</span>
              </div>
              {preferredApp === 'youtube_app' ? (
                <div className="w-4 h-4 rounded-full bg-red-500 text-white flex items-center justify-center">
                  <Check className="w-2.5 h-2.5 stroke-[3]" />
                </div>
              ) : (
                <div className="w-4 h-4 rounded-full border border-slate-700" />
              )}
            </div>
            <p className="text-[10.5px] text-slate-400 leading-tight">
              Opens links directly in native YouTube app with deep linking and browser fallback.
            </p>
          </button>

          {/* Option B: Web Browser */}
          <button
            type="button"
            onClick={() => handleSelectPreferredApp('browser')}
            className={`p-3 rounded-2xl border text-left flex flex-col justify-between gap-2 transition-all cursor-pointer ${
              preferredApp === 'browser'
                ? 'bg-blue-950/40 border-blue-500 shadow-[0_0_15px_rgba(59,130,246,0.25)]'
                : 'bg-slate-900/60 hover:bg-slate-900 border-slate-800'
            }`}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Globe className="w-4 h-4 text-blue-400" />
                <span className="text-xs font-bold text-white">Web Browser</span>
              </div>
              {preferredApp === 'browser' ? (
                <div className="w-4 h-4 rounded-full bg-blue-500 text-white flex items-center justify-center">
                  <Check className="w-2.5 h-2.5 stroke-[3]" />
                </div>
              ) : (
                <div className="w-4 h-4 rounded-full border border-slate-700" />
              )}
            </div>
            <p className="text-[10.5px] text-slate-400 leading-tight">
              Opens videos in browser tabs without launching external apps.
            </p>
          </button>

          {/* Option C: Auto Detect */}
          <button
            type="button"
            onClick={() => handleSelectPreferredApp('auto')}
            className={`p-3 rounded-2xl border text-left flex flex-col justify-between gap-2 transition-all cursor-pointer ${
              preferredApp === 'auto'
                ? 'bg-purple-950/40 border-purple-500 shadow-[0_0_15px_rgba(168,85,247,0.25)]'
                : 'bg-slate-900/60 hover:bg-slate-900 border-slate-800'
            }`}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-purple-400" />
                <span className="text-xs font-bold text-white">Auto Detect (Recommended)</span>
              </div>
              {preferredApp === 'auto' ? (
                <div className="w-4 h-4 rounded-full bg-purple-500 text-white flex items-center justify-center">
                  <Check className="w-2.5 h-2.5 stroke-[3]" />
                </div>
              ) : (
                <div className="w-4 h-4 rounded-full border border-slate-700" />
              )}
            </div>
            <p className="text-[10.5px] text-slate-400 leading-tight">
              Uses YouTube app on mobile/APK; falls back to browser if unavailable.
            </p>
          </button>
        </div>
      </div>

      {/* 2. YOUTUBE DATA API V3 CONNECTION & SECURITY STATUS */}
      <div className="p-4 rounded-[20px] bg-[var(--theme-card-bg)] border border-[var(--theme-border)] shadow-sm space-y-3">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-300">
              <KeyRound className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-[15px] font-bold text-white flex items-center gap-2">
                YouTube Data API v3 Security
              </h3>
              <p className="text-xs text-slate-400">
                Official Google Cloud API configuration for live music & channel search.
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={refreshStatus}
            disabled={isTestingStatus}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors cursor-pointer shrink-0"
            title="Refresh connection status"
          >
            <RotateCw className={`w-4 h-4 ${isTestingStatus ? 'animate-spin' : ''}`} />
          </button>
        </div>

        {/* Live Status Display */}
        <div className="p-3 rounded-xl bg-black/40 border border-white/5 flex items-center justify-between">
          <div className="flex items-center gap-2">
            {apiStatus?.connected ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            ) : (
              <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
            )}
            <div>
              <div className="text-xs font-semibold text-white flex items-center gap-2">
                {apiStatus?.connected ? 'Connected to YouTube Data API v3' : 'API Key Not Configured / Disconnected'}
                {apiStatus?.maskedKey && (
                  <span className="font-mono text-[10px] text-slate-400 bg-slate-800 px-1.5 py-0.5 rounded">
                    {apiStatus.maskedKey}
                  </span>
                )}
              </div>
              <p className="text-[10.5px] text-slate-400 mt-0.5">
                {apiStatus?.message || 'Checking connection status...'}
              </p>
            </div>
          </div>
        </div>

        {/* Secure Server-Side Key Configuration Form */}
        <form onSubmit={handleSaveApiKey} className="space-y-2 pt-1">
          <label className="block text-xs font-medium text-slate-300">
            Configure / Update YouTube API Key (Validated & stored securely server-side)
          </label>
          <div className="flex gap-2">
            <input
              type="password"
              value={apiKeyInput}
              onChange={(e) => setApiKeyInput(e.target.value)}
              placeholder="Paste your YouTube Data API v3 key (AIzaSy...)..."
              className="flex-1 px-3 py-2 text-xs rounded-xl bg-slate-900 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:border-red-500 font-mono"
            />
            <button
              type="submit"
              disabled={isSavingKey || !apiKeyInput.trim()}
              className="px-4 py-2 rounded-xl bg-red-600 hover:bg-red-500 disabled:opacity-50 text-xs font-bold text-white transition-colors cursor-pointer shrink-0 shadow-sm"
            >
              {isSavingKey ? 'Verifying...' : 'Save & Verify'}
            </button>
          </div>
          {saveMessage && (
            <p className={`text-xs mt-1 font-medium ${saveMessage.type === 'success' ? 'text-emerald-400' : 'text-rose-400'}`}>
              {saveMessage.text}
            </p>
          )}
        </form>
      </div>

      {/* 3. FAVORITE SINGERS & YOUTUBE DATA API SEARCH SECTION */}
      <div className="p-4 rounded-[20px] bg-[var(--theme-card-bg)] border border-[var(--theme-border)] shadow-sm space-y-4">
        
        {/* Section Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-purple-600/20 border border-purple-500/40 flex items-center justify-center text-purple-300">
              <Music className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-[15px] font-bold text-white flex items-center gap-2">
                Favorite Singers & YouTube Data API
                <span className="text-xs font-mono font-normal text-purple-300 bg-purple-950/60 px-2 py-0.5 rounded-full border border-purple-500/40">
                  {favoriteSingers.length} saved
                </span>
              </h3>
              <p className="text-xs text-slate-400">
                Manage favorite singers, search official channels & specific songs via YouTube Data API v3.
              </p>
            </div>
          </div>
        </div>

        {/* Sub-Tabs: Singers & Channels VS Songs & Music Videos */}
        <div className="flex items-center gap-2 p-1 rounded-xl bg-slate-950/60 border border-slate-800">
          <button
            type="button"
            onClick={() => setSearchTab('singers')}
            className={`flex-1 py-1.5 px-3 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
              searchTab === 'singers'
                ? 'bg-purple-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            <span>Search Singers & Channels</span>
          </button>

          <button
            type="button"
            onClick={() => setSearchTab('songs')}
            className={`flex-1 py-1.5 px-3 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
              searchTab === 'songs'
                ? 'bg-purple-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Film className="w-3.5 h-3.5" />
            <span>Search Songs & Music Videos</span>
          </button>
        </div>

        {/* TAB A: SINGER SEARCH FORM */}
        {searchTab === 'singers' && (
          <div className="space-y-3">
            <form onSubmit={handleSearchSingers} className="flex gap-2">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={singerSearchQuery}
                  onChange={(e) => setSingerSearchQuery(e.target.value)}
                  placeholder="Search singer name (e.g. Arijit Singh, Shreya Ghoshal, Diljit Dosanjh)..."
                  className="w-full pl-9 pr-3 py-2 text-xs rounded-xl bg-slate-900 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
                />
              </div>
              <button
                type="submit"
                disabled={isSearchingSingers || !singerSearchQuery.trim()}
                className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 disabled:opacity-50 text-xs font-bold text-white transition-colors cursor-pointer shrink-0 shadow-sm"
              >
                {isSearchingSingers ? 'Searching...' : 'Search'}
              </button>
            </form>

            {singerSearchError && (
              <div className="p-3 rounded-xl bg-amber-950/40 border border-amber-500/40 text-xs text-amber-300 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0 text-amber-400" />
                <span>{singerSearchError}</span>
              </div>
            )}

            {/* Singer Search Results */}
            {singerSearchResults.length > 0 && (
              <div className="space-y-2 pt-1">
                <h4 className="text-xs font-bold uppercase tracking-wider text-purple-300">
                  Matching YouTube Channels ({singerSearchResults.length})
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-64 overflow-y-auto pr-1">
                  {singerSearchResults.map((channel) => {
                    const isSaved = youtubeManager.isFavorite(channel.title);
                    return (
                      <div
                        key={channel.channelId}
                        className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-800 flex items-center justify-between gap-2.5"
                      >
                        <div className="flex items-center gap-2.5 min-w-0">
                          {channel.thumbnail ? (
                            <img
                              src={channel.thumbnail}
                              alt={channel.title}
                              className="w-10 h-10 rounded-full object-cover shrink-0 border border-slate-700"
                            />
                          ) : (
                            <div className="w-10 h-10 rounded-full bg-purple-900/50 flex items-center justify-center shrink-0 text-purple-300">
                              <Users className="w-4 h-4" />
                            </div>
                          )}
                          <div className="min-w-0">
                            <div className="text-xs font-bold text-white truncate flex items-center gap-1.5">
                              {channel.title}
                              {channel.isOfficialArtist && (
                                <span className="text-[9px] px-1 py-0.2 rounded bg-purple-500/20 text-purple-300 border border-purple-500/30">
                                  Official Artist
                                </span>
                              )}
                            </div>
                            <p className="text-[10px] text-slate-400 truncate">
                              {channel.subscriberCount ? `${channel.subscriberCount} subscribers` : 'Official Channel'}
                            </p>
                          </div>
                        </div>

                        <button
                          type="button"
                          disabled={isSaved}
                          onClick={() => handleAddSinger(channel)}
                          className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold shrink-0 transition-colors flex items-center gap-1 ${
                            isSaved
                              ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/40'
                              : 'bg-purple-600 hover:bg-purple-500 text-white cursor-pointer'
                          }`}
                        >
                          {isSaved ? <Check className="w-3 h-3" /> : <Plus className="w-3 h-3" />}
                          <span>{isSaved ? 'Added' : 'Add'}</span>
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        )}

        {/* TAB B: SONGS & MUSIC VIDEOS SEARCH */}
        {searchTab === 'songs' && (
          <div className="space-y-3">
            <form onSubmit={handleSearchSongs} className="flex gap-2">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={songSearchQuery}
                  onChange={(e) => setSongSearchQuery(e.target.value)}
                  placeholder="Search specific song title (e.g. Kesariya, Lover, Chaleya, Tum Hi Ho)..."
                  className="w-full pl-9 pr-3 py-2 text-xs rounded-xl bg-slate-900 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
                />
              </div>
              <button
                type="submit"
                disabled={isSearchingSongs || !songSearchQuery.trim()}
                className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 disabled:opacity-50 text-xs font-bold text-white transition-colors cursor-pointer shrink-0 shadow-sm"
              >
                {isSearchingSongs ? 'Searching...' : 'Search'}
              </button>
            </form>

            {songSearchError && (
              <div className="p-3 rounded-xl bg-amber-950/40 border border-amber-500/40 text-xs text-amber-300 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0 text-amber-400" />
                <span>{songSearchError}</span>
              </div>
            )}

            {/* Song Search Results */}
            {songSearchResults.length > 0 && (
              <div className="space-y-2 pt-1">
                <h4 className="text-xs font-bold uppercase tracking-wider text-purple-300">
                  YouTube Music Results ({songSearchResults.length})
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-72 overflow-y-auto pr-1">
                  {songSearchResults.map((vid) => (
                    <div
                      key={vid.videoId}
                      onClick={() => handleOpenVideo(vid)}
                      className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 hover:border-red-500/60 flex items-center justify-between gap-2.5 cursor-pointer transition-colors group"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <img
                          src={vid.thumbnail}
                          alt={vid.title}
                          className="w-14 h-10 rounded-lg object-cover shrink-0 border border-slate-800"
                        />
                        <div className="min-w-0">
                          <p className="text-xs font-bold text-white line-clamp-1 group-hover:text-red-400">
                            {vid.title}
                          </p>
                          <p className="text-[10px] text-slate-400 truncate mt-0.5">
                            {vid.channelTitle}
                          </p>
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleOpenVideo(vid);
                        }}
                        className="p-2 rounded-lg bg-red-600/20 hover:bg-red-600/40 text-red-300 border border-red-500/40 transition-colors cursor-pointer shrink-0"
                        title="Play Video"
                      >
                        <Play className="w-3.5 h-3.5 fill-current" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Current Saved Favorite Singers List */}
        <div className="pt-3 border-t border-[var(--theme-border)]">
          <div className="flex items-center justify-between mb-2.5">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
              <span>Your Favorite Singers</span>
              <span className="text-[10px] text-slate-400 font-normal">
                (Click star to set Primary for &ldquo;Play my favorite singer&rdquo;)
              </span>
            </h4>
          </div>

          {favoriteSingers.length === 0 ? (
            <div className="p-4 rounded-xl bg-slate-900/40 border border-dashed border-slate-800 text-center space-y-2">
              <p className="text-xs text-slate-400">
                You haven&apos;t added any favorite singers yet. Search above or tap a suggestion to add:
              </p>
              <div className="flex flex-wrap items-center justify-center gap-1.5 pt-1">
                {SUGGESTED_SINGERS.map((sug) => (
                  <button
                    key={sug.name}
                    type="button"
                    onClick={() => handleAddSinger(sug)}
                    className="px-2.5 py-1 rounded-full bg-slate-800 hover:bg-purple-900/40 border border-slate-700 hover:border-purple-500/60 text-xs text-slate-200 transition-colors flex items-center gap-1 cursor-pointer"
                  >
                    <Plus className="w-3 h-3 text-purple-400" />
                    <span>{sug.name}</span>
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {favoriteSingers.map((singer) => {
                const isPrimary = singer.isPrimary || favoriteSingers[0]?.id === singer.id;
                return (
                  <div
                    key={singer.id}
                    className={`p-3 rounded-2xl border transition-colors flex items-center justify-between gap-3 ${
                      isPrimary
                        ? 'bg-purple-950/30 border-purple-500/60 shadow-[0_0_12px_rgba(168,85,247,0.15)]'
                        : 'bg-slate-900/90 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      {singer.thumbnail ? (
                        <img
                          src={singer.thumbnail}
                          alt={singer.name}
                          className="w-10 h-10 rounded-full object-cover shrink-0 border border-slate-700 shadow-sm"
                        />
                      ) : (
                        <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-purple-600 to-indigo-600 flex items-center justify-center text-white shrink-0 font-bold text-xs">
                          {singer.name.charAt(0)}
                        </div>
                      )}
                      <div className="min-w-0">
                        <div className="text-xs font-bold text-white truncate flex items-center gap-1.5">
                          <span>{singer.name}</span>
                          {isPrimary && (
                            <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/30">
                              Primary
                            </span>
                          )}
                        </div>
                        <p className="text-[10px] text-slate-400 truncate">
                          {singer.channelTitle || 'Favorite Artist'}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      {/* Set Primary Button */}
                      <button
                        type="button"
                        onClick={() => handleSetPrimarySinger(singer.id)}
                        className={`p-1.5 rounded-lg border transition-colors cursor-pointer ${
                          isPrimary
                            ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                            : 'bg-slate-800 text-slate-400 hover:text-amber-300 border-slate-700'
                        }`}
                        title={isPrimary ? 'Primary Favorite Singer' : 'Set as Primary Favorite'}
                      >
                        <Star className={`w-3.5 h-3.5 ${isPrimary ? 'fill-amber-400 text-amber-400' : ''}`} />
                      </button>

                      {/* Play Top Songs Button */}
                      <button
                        type="button"
                        onClick={() => handlePlaySingerTracks(singer)}
                        disabled={isLoadingTracks}
                        className="p-1.5 rounded-lg bg-red-600/20 hover:bg-red-600/30 text-red-300 border border-red-500/30 transition-colors cursor-pointer"
                        title={`Play top songs by ${singer.name}`}
                      >
                        <Play className="w-3.5 h-3.5 fill-current" />
                      </button>

                      {/* Remove Button */}
                      <button
                        type="button"
                        onClick={() => handleRemoveSinger(singer.id)}
                        className="p-1.5 rounded-lg bg-slate-800 hover:bg-rose-950 text-slate-400 hover:text-rose-300 border border-slate-700 hover:border-rose-500/40 transition-colors cursor-pointer"
                        title="Remove from favorites"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Top Tracks Result Preview (if user tapped Play on any singer) */}
        {testVideoResult && (
          <div className="p-3.5 rounded-xl bg-slate-950 border border-red-500/40 space-y-2 mt-3 animate-fade-in">
            <div className="flex items-center justify-between">
              <h5 className="text-xs font-bold text-red-400 flex items-center gap-1.5">
                <Youtube className="w-4 h-4" />
                Top Songs for {testVideoResult.singer} ({testVideoResult.videos.length})
              </h5>
              <button
                type="button"
                onClick={() => setTestVideoResult(null)}
                className="text-[10px] text-slate-400 hover:text-white"
              >
                Close
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1 max-h-52 overflow-y-auto">
              {testVideoResult.videos.map((vid) => (
                <div
                  key={vid.videoId}
                  onClick={() => handleOpenVideo(vid)}
                  className="p-2 rounded-lg bg-slate-900 border border-slate-800 hover:border-red-500/60 flex items-center gap-2 cursor-pointer transition-colors group"
                >
                  <img
                    src={vid.thumbnail}
                    alt={vid.title}
                    className="w-14 h-9 rounded object-cover shrink-0"
                  />
                  <div className="min-w-0 flex-1">
                    <p className="text-[11px] font-semibold text-slate-200 group-hover:text-white line-clamp-1">
                      {vid.title}
                    </p>
                    <p className="text-[9.5px] text-slate-400 truncate">
                      {vid.channelTitle}
                    </p>
                  </div>
                  <Play className="w-3.5 h-3.5 text-red-400 shrink-0 group-hover:scale-110 transition-transform" />
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
