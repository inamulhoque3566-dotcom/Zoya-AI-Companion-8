import React, { useState } from 'react';
import {
  Palette,
  Twitter,
  Copy,
  Check,
  Download,
  Sparkles,
  ShieldCheck,
  TrendingUp,
  MessageCircle,
  Bookmark,
  Repeat2,
  Sliders,
  Eye,
  CheckCircle2,
  Code2,
} from 'lucide-react';
import {
  Part7SkillPayload,
  ThemeFactoryPayload,
  TwitterOptimizerPayload,
  ThemeDefinition,
  PRESET_THEMES,
} from '../../services/zoyaSkillsPart7';

interface Part7SkillOutputCardProps {
  payload: Part7SkillPayload;
}

export const Part7SkillOutputCard: React.FC<Part7SkillOutputCardProps> = ({ payload }) => {
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const handleCopy = (text: string, id: string) => {
    try {
      navigator.clipboard.writeText(text);
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 1800);
    } catch {}
  };

  const handleDownload = (filename: string, content: string, mime: string = 'text/plain') => {
    const blob = new Blob([content], { type: `${mime};charset=utf-8` });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // ==========================================================================
  // 1. THEME FACTORY CARD
  // ==========================================================================
  if (payload.kind === 'theme-factory') {
    const [selectedThemeId, setSelectedThemeId] = useState<string>(payload.selectedTheme.id);
    const [categoryFilter, setCategoryFilter] = useState<string>('All');
    const [activeTab, setActiveTab] = useState<'preview' | 'css' | 'tailwind'>('preview');

    const curTheme: ThemeDefinition =
      payload.allThemes.find((t) => t.id === selectedThemeId) || payload.selectedTheme;

    const filteredThemes =
      categoryFilter === 'All'
        ? payload.allThemes
        : payload.allThemes.filter((t) => t.category === categoryFilter);

    const dynamicCss = `:root {
  /* ${curTheme.name} Theme Tokens */
  --color-bg: ${curTheme.colors.bg};
  --color-surface: ${curTheme.colors.surface};
  --color-primary: ${curTheme.colors.primary};
  --color-secondary: ${curTheme.colors.secondary};
  --color-accent: ${curTheme.colors.accent};
  --color-text: ${curTheme.colors.text};
  --color-text-muted: ${curTheme.colors.textMuted};
  --font-heading: '${curTheme.fonts.heading}';
  --font-body: '${curTheme.fonts.body}';
}`;

    const dynamicTailwind = `// tailwind.config.js - ${curTheme.name}
module.exports = {
  theme: {
    extend: {
      colors: {
        themeBg: '${curTheme.colors.bg}',
        themeSurface: '${curTheme.colors.surface}',
        themePrimary: '${curTheme.colors.primary}',
        themeSecondary: '${curTheme.colors.secondary}',
        themeAccent: '${curTheme.colors.accent}',
        themeText: '${curTheme.colors.text}',
        themeMuted: '${curTheme.colors.textMuted}',
      },
      fontFamily: {
        heading: ['${curTheme.fonts.heading.split(',')[0]}'],
        body: ['${curTheme.fonts.body.split(',')[0]}'],
      }
    }
  }
};`;

    return (
      <div className="mt-3 rounded-2xl border border-violet-500/40 bg-[#0e0a1e] overflow-hidden shadow-xl text-slate-200 text-xs">
        {/* Header */}
        <div className="px-3.5 py-2.5 bg-[#171032] border-b border-violet-500/30 flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-lg bg-violet-500/20 text-violet-400 flex items-center justify-center font-bold">
              <Palette className="w-3.5 h-3.5" />
            </div>
            <div>
              <div className="text-[13px] font-semibold text-violet-300">
                Theme Factory Showcase (10 Curated Palettes)
              </div>
              <div className="text-[10px] text-slate-400">
                Active: <span className="font-semibold text-violet-200">{curTheme.name}</span> · {curTheme.contrastRatio}
              </div>
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => handleDownload(`${curTheme.id}-theme.css`, dynamicCss, 'text/css')}
              className="px-2.5 py-1 rounded-lg bg-violet-600/30 hover:bg-violet-600/50 text-violet-200 border border-violet-500/30 text-[11px] font-medium flex items-center gap-1 cursor-pointer transition-colors"
            >
              <Download className="w-3 h-3" />
              CSS
            </button>
            <button
              onClick={() => handleCopy(dynamicCss, 'theme-css')}
              className="px-2.5 py-1 rounded-lg bg-[#251a52] hover:bg-[#32236e] text-violet-200 border border-violet-500/30 text-[11px] font-medium flex items-center gap-1 cursor-pointer"
            >
              {copiedId === 'theme-css' ? (
                <>
                  <Check className="w-3 h-3 text-emerald-400" /> Copied
                </>
              ) : (
                <>
                  <Copy className="w-3 h-3" /> Copy Tokens
                </>
              )}
            </button>
          </div>
        </div>

        {/* Category Filter Chips */}
        <div className="px-3 py-1.5 bg-[#090614] border-b border-violet-950 flex items-center gap-1.5 overflow-x-auto text-[10.5px]">
          {['All', 'Modern', 'Natural', 'Dramatic', 'Minimal', 'Vibrant'].map((cat) => (
            <button
              key={cat}
              onClick={() => setCategoryFilter(cat)}
              className={`px-2.5 py-0.5 rounded-full border cursor-pointer transition-colors ${
                categoryFilter === cat
                  ? 'bg-violet-950 border-violet-400 text-violet-200 font-bold'
                  : 'bg-[#120d26] border-slate-800 text-slate-400'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* 10-Theme Selector Scrollbar */}
        <div className="p-3 bg-[#0c081a] border-b border-violet-950/80">
          <div className="flex gap-2 overflow-x-auto pb-1">
            {filteredThemes.map((thm) => {
              const isSelected = thm.id === selectedThemeId;
              return (
                <button
                  key={thm.id}
                  onClick={() => setSelectedThemeId(thm.id)}
                  className={`p-2 rounded-xl border text-left shrink-0 cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-violet-950/80 border-violet-400 shadow-md ring-1 ring-violet-500/50'
                      : 'bg-[#150f2e] border-slate-800 hover:border-slate-700'
                  }`}
                  style={{ width: '135px' }}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-bold text-[11px] text-white truncate">{thm.name}</span>
                    {isSelected && <CheckCircle2 className="w-3 h-3 text-violet-400 shrink-0" />}
                  </div>
                  {/* Swatch dots */}
                  <div className="flex gap-1 items-center">
                    <span className="w-3.5 h-3.5 rounded-full border border-black/40" style={{ backgroundColor: thm.colors.bg }} />
                    <span className="w-3.5 h-3.5 rounded-full border border-black/40" style={{ backgroundColor: thm.colors.primary }} />
                    <span className="w-3.5 h-3.5 rounded-full border border-black/40" style={{ backgroundColor: thm.colors.accent }} />
                    <span className="w-3.5 h-3.5 rounded-full border border-black/40" style={{ backgroundColor: thm.colors.text }} />
                  </div>
                  <div className="text-[9px] text-slate-400 mt-1 truncate">{thm.category}</div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Live Mockup Artifact Styled with Selected Theme */}
        <div className="p-3.5 space-y-3">
          {/* Tabs */}
          <div className="flex gap-2 border-b border-violet-950 pb-1.5 text-[11px]">
            <button
              onClick={() => setActiveTab('preview')}
              className={`pb-1 font-semibold cursor-pointer ${
                activeTab === 'preview' ? 'text-violet-300 border-b-2 border-violet-400' : 'text-slate-400'
              }`}
            >
              Live Artifact Preview
            </button>
            <button
              onClick={() => setActiveTab('css')}
              className={`pb-1 font-semibold cursor-pointer ${
                activeTab === 'css' ? 'text-violet-300 border-b-2 border-violet-400' : 'text-slate-400'
              }`}
            >
              CSS Variables (:root)
            </button>
            <button
              onClick={() => setActiveTab('tailwind')}
              className={`pb-1 font-semibold cursor-pointer ${
                activeTab === 'tailwind' ? 'text-violet-300 border-b-2 border-violet-400' : 'text-slate-400'
              }`}
            >
              Tailwind Palette
            </button>
          </div>

          {activeTab === 'preview' && (
            <div className="space-y-3">
              {/* Dynamic Styled Card */}
              <div
                className="p-4 rounded-xl border transition-all duration-300 shadow-lg space-y-2.5"
                style={{
                  backgroundColor: curTheme.colors.bg,
                  borderColor: curTheme.colors.primary + '55',
                  color: curTheme.colors.text,
                }}
              >
                <div className="flex items-center justify-between">
                  <div
                    className="text-[14px] font-bold tracking-tight"
                    style={{
                      color: curTheme.colors.primary,
                      fontFamily: curTheme.fonts.heading,
                    }}
                  >
                    {curTheme.name}
                  </div>
                  <span
                    className="px-2 py-0.5 rounded-full text-[9.5px] font-semibold border"
                    style={{
                      backgroundColor: curTheme.colors.surface,
                      borderColor: curTheme.colors.accent,
                      color: curTheme.colors.accent,
                    }}
                  >
                    {curTheme.category}
                  </span>
                </div>

                <p
                  className="text-[11px] leading-relaxed"
                  style={{
                    color: curTheme.colors.textMuted,
                    fontFamily: curTheme.fonts.body,
                  }}
                >
                  {curTheme.tagline}. Optimized with complementary typography pairings: {curTheme.fonts.heading} for titles and {curTheme.fonts.body} for body text.
                </p>

                {/* Hex Swatch Pills */}
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-1.5 pt-1">
                  {[
                    { label: 'Background', val: curTheme.colors.bg },
                    { label: 'Surface', val: curTheme.colors.surface },
                    { label: 'Primary', val: curTheme.colors.primary },
                    { label: 'Secondary', val: curTheme.colors.secondary },
                    { label: 'Accent', val: curTheme.colors.accent },
                  ].map((s) => (
                    <div
                      key={s.label}
                      className="p-1.5 rounded-lg border flex items-center gap-1.5 text-[9.5px]"
                      style={{
                        backgroundColor: curTheme.colors.surface,
                        borderColor: curTheme.colors.primary + '33',
                        color: curTheme.colors.text,
                      }}
                    >
                      <span className="w-3 h-3 rounded-full shrink-0 border border-white/20" style={{ backgroundColor: s.val }} />
                      <div className="truncate">
                        <div className="font-semibold">{s.label}</div>
                        <div className="font-mono opacity-80">{s.val}</div>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="text-[10px] pt-1 border-t flex justify-between items-center opacity-80" style={{ borderColor: curTheme.colors.primary + '22' }}>
                  <span>Best for: {curTheme.bestFor}</span>
                  <span className="font-mono">{curTheme.contrastRatio}</span>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'css' && (
            <pre className="p-3 rounded-xl bg-[#06040d] border border-violet-950 font-mono text-[10.5px] leading-relaxed text-violet-200 overflow-x-auto select-text">
              {dynamicCss}
            </pre>
          )}

          {activeTab === 'tailwind' && (
            <pre className="p-3 rounded-xl bg-[#06040d] border border-violet-950 font-mono text-[10.5px] leading-relaxed text-violet-200 overflow-x-auto select-text">
              {dynamicTailwind}
            </pre>
          )}
        </div>
      </div>
    );
  }

  // ==========================================================================
  // 2. TWITTER ALGORITHM OPTIMIZER CARD
  // ==========================================================================
  if (payload.kind === 'twitter-algorithm-optimizer') {
    const [selectedVariantIdx, setSelectedVariantIdx] = useState<number>(0);
    const activeVariant = payload.variants[selectedVariantIdx] || payload.variants[0];

    return (
      <div className="mt-3 rounded-2xl border border-sky-500/40 bg-[#06111f] overflow-hidden shadow-xl text-slate-200 text-xs">
        {/* Header */}
        <div className="px-3.5 py-2.5 bg-[#0a1c33] border-b border-sky-500/30 flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-lg bg-sky-500/20 text-sky-400 flex items-center justify-center font-bold">
              <Twitter className="w-3.5 h-3.5" />
            </div>
            <div>
              <div className="text-[13px] font-semibold text-sky-300 flex items-center gap-2">
                Twitter Recommendation Optimizer
                <span className="text-[9px] font-mono uppercase px-1.5 py-0.5 rounded bg-sky-950/80 text-sky-300 border border-sky-500/40">
                  Heuristic Estimate
                </span>
              </div>
              <div className="text-[10px] text-slate-400">
                Open Best Practices (Real-graph, SimClusters, TwHIN) · Not Proprietary Algorithm
              </div>
            </div>
          </div>
          <span className="px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-500/30 text-[10px] font-semibold">
            100% Free / Open Source Insights
          </span>
        </div>

        {/* Algorithm Score Gauge */}
        <div className="p-3.5 bg-gradient-to-r from-[#071629] via-[#0b213e] to-[#071629] border-b border-sky-950 space-y-2">
          <div className="flex items-center justify-between">
            <span className="font-semibold text-sky-200 text-[11px] uppercase tracking-wider flex items-center gap-1.5">
              <TrendingUp className="w-4 h-4 text-sky-400" />
              Heuristic Virality Index (Estimated)
            </span>
            <span className="text-lg font-extrabold text-sky-300">
              ~{payload.signals.overallViralityIndex} / 100
            </span>
          </div>

          {/* Progress Bar */}
          <div className="w-full h-2 rounded-full bg-slate-900 overflow-hidden">
            <div
              className="h-full rounded-full bg-gradient-to-r from-sky-500 to-emerald-400 transition-all duration-500"
              style={{ width: `${payload.signals.overallViralityIndex}%` }}
            />
          </div>

          {/* 4 Core Twitter ML Sub-models */}
          <div className="grid grid-cols-4 gap-2 pt-1">
            <div className="p-2 rounded-xl bg-[#091729] border border-sky-900/50 text-center">
              <div className="text-[9.5px] text-slate-400">Real-graph</div>
              <div className="text-[13px] font-bold text-sky-300">{payload.signals.realGraphScore}%</div>
              <div className="text-[8.5px] text-emerald-400">Follower Engagement</div>
            </div>
            <div className="p-2 rounded-xl bg-[#091729] border border-sky-900/50 text-center">
              <div className="text-[9.5px] text-slate-400">SimClusters</div>
              <div className="text-[13px] font-bold text-sky-300">{payload.signals.simClustersScore}%</div>
              <div className="text-[8.5px] text-sky-400">Niche Resonance</div>
            </div>
            <div className="p-2 rounded-xl bg-[#091729] border border-sky-900/50 text-center">
              <div className="text-[9.5px] text-slate-400">TwHIN Fit</div>
              <div className="text-[13px] font-bold text-sky-300">{payload.signals.twHINScore}%</div>
              <div className="text-[8.5px] text-emerald-400">Topic Authority</div>
            </div>
            <div className="p-2 rounded-xl bg-[#091729] border border-sky-900/50 text-center">
              <div className="text-[9.5px] text-slate-400">Tweepcred</div>
              <div className="text-[13px] font-bold text-emerald-400">{payload.signals.tweepcredScore}%</div>
              <div className="text-[8.5px] text-slate-400">Spam-Safe Score</div>
            </div>
          </div>
        </div>

        {/* 3 Optimized Variants */}
        <div className="p-3.5 space-y-3">
          <div className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
            Optimized Rewrites (Algorithmic Advantage):
          </div>

          <div className="flex gap-2">
            {payload.variants.map((v, idx) => (
              <button
                key={v.title}
                onClick={() => setSelectedVariantIdx(idx)}
                className={`px-3 py-1.5 rounded-xl border text-left cursor-pointer transition-all flex-1 ${
                  selectedVariantIdx === idx
                    ? 'bg-sky-950/90 border-sky-400 text-sky-200'
                    : 'bg-[#0a1626] border-slate-800 text-slate-400'
                }`}
              >
                <div className="font-semibold text-[11px] truncate">{v.title.split(':')[0]}</div>
                <div className="text-[9.5px] text-emerald-400 font-mono mt-0.5">{v.projectedBoost}</div>
              </button>
            ))}
          </div>

          {/* Active Variant Card */}
          <div className="p-3 rounded-xl bg-[#091524] border border-sky-900/60 space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-sky-300 text-[11.5px]">
                {activeVariant.title}
              </span>
              <button
                onClick={() => handleCopy(activeVariant.text, `tweet-${selectedVariantIdx}`)}
                className="px-2.5 py-1 rounded-lg bg-sky-600/30 hover:bg-sky-600/50 text-sky-200 border border-sky-500/30 text-[11px] font-medium flex items-center gap-1 cursor-pointer"
              >
                {copiedId === `tweet-${selectedVariantIdx}` ? (
                  <>
                    <Check className="w-3 h-3 text-emerald-400" /> Copied
                  </>
                ) : (
                  <>
                    <Copy className="w-3 h-3" /> Copy Tweet
                  </>
                )}
              </button>
            </div>

            <pre className="p-3 rounded-xl bg-[#050b14] border border-sky-950 font-sans text-[11.5px] leading-relaxed text-slate-100 whitespace-pre-wrap select-text">
              {activeVariant.text}
            </pre>

            <div className="p-2.5 rounded-lg bg-sky-950/40 border border-sky-800/40 space-y-1">
              <div className="text-[10px] font-semibold text-sky-400 uppercase">
                Why Twitter's Algorithm Rewards This:
              </div>
              <p className="text-[11px] text-slate-300 leading-normal">
                {activeVariant.whyItWorks}
              </p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return null;
};
