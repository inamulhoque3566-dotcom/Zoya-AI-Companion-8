import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { VRM, VRMLoaderPlugin, VRMUtils } from '@pixiv/three-vrm';
import { getAvatarAnatomy, AvatarAnatomyConfig } from '../../data/avatarAnatomy';
import { getAllAvatars } from '../../data/anime3DAvatars';
import { audioLevelStore } from '../../services/speech/audioLevelStore';

export interface ZoyaLiving3DAvatarProps {
  avatarId?: string;
  voiceStatus?: 'idle' | 'listening' | 'processing' | 'speaking';
  audioLevel?: number;
  avatarScale?: number;
  avatarOffsetY?: number;
  onTapAvatar?: () => void;
  className?: string;
}

if (typeof window !== 'undefined') {
  (window as any).__zoyaForceBlinkState = (state: 'open' | 'half' | 'closed' | 'auto') => {
    (window as any).__zoyaCurrentForcedBlink = state;
  };
}

export const ZoyaLiving3DAvatar: React.FC<ZoyaLiving3DAvatarProps> = ({
  avatarId = 'classic',
  voiceStatus = 'idle',
  audioLevel = 0,
  avatarScale = 1.0,
  avatarOffsetY = 0,
  onTapAvatar,
  className = '',
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const sceneRef = useRef<THREE.Scene | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const animFrameRef = useRef<number | null>(null);

  // References for live animation loop
  const voiceStatusRef = useRef(voiceStatus);
  voiceStatusRef.current = voiceStatus;
  const audioLevelRef = useRef(audioLevel > 0 ? audioLevel : audioLevelStore.get());
  if (audioLevel > 0) {
    audioLevelRef.current = audioLevel;
  }

  useEffect(() => {
    return audioLevelStore.subscribe((lvl) => {
      audioLevelRef.current = lvl;
    });
  }, []);

  useEffect(() => {
    const container = containerRef.current;
    const canvas = canvasRef.current;
    if (!container || !canvas) return;

    const anatomy: AvatarAnatomyConfig = getAvatarAnatomy(avatarId);
    const registeredAvatar = getAllAvatars().find((a) => a.id === avatarId);

    // Determine asset paths and model type
    const rawPath =
      registeredAvatar?.vrmModelUrl ||
      registeredAvatar?.videoUrl ||
      registeredAvatar?.transparentPng ||
      (avatarId === 'classic'
        ? '/assets/images/zoya_new_avatar_transparent.png'
        : `${anatomy.modularPath}/body_skin.png`);

    const isVrmModel =
      typeof rawPath === 'string' &&
      (rawPath.toLowerCase().endsWith('.vrm') || rawPath.toLowerCase().endsWith('.glb'));

    const isVideoModel =
      typeof rawPath === 'string' &&
      (rawPath.toLowerCase().endsWith('.mp4') || rawPath.toLowerCase().endsWith('.webm'));

    // 1. Transparent Scene & WebGL Renderer Setup
    const scene = new THREE.Scene();
    scene.background = null; // Strictly transparent - no background
    sceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(36, 1, 0.1, 100);
    cameraRef.current = camera;

    const renderer = new THREE.WebGLRenderer({
      canvas,
      alpha: true,
      antialias: true,
      powerPreference: 'high-performance',
      premultipliedAlpha: true,
    });
    renderer.setClearColor(0x000000, 0); // Transparent canvas
    renderer.toneMapping = THREE.NoToneMapping;
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2.0));
    rendererRef.current = renderer;

    // Ambient and directional key lighting for 3D/VRM models (strictly neutral)
    const ambientLight = new THREE.AmbientLight(0xffffff, 1.2);
    scene.add(ambientLight);
    const keyLight = new THREE.DirectionalLight(0xffffff, 1.0);
    keyLight.position.set(1.5, 3.5, 2.5);
    scene.add(keyLight);

    // Character Pivot Root Group (anchored at ground level for zero floating feet)
    const characterRoot = new THREE.Group();
    const scaleFactor = Math.max(0.6, Math.min(1.5, avatarScale));
    characterRoot.scale.set(scaleFactor, scaleFactor, scaleFactor);
    characterRoot.position.set(0, (avatarOffsetY / 100) * 0.4, 0);
    scene.add(characterRoot);

    const characterPivot = new THREE.Group();
    characterRoot.add(characterPivot);

    const feetY = anatomy.landmarks?.feetY ?? -1.45;
    characterPivot.position.set(0, feetY, 0);

    // Track allocated GPU resources for surgical disposal on unmount/switch
    const disposables: {
      geometries: THREE.BufferGeometry[];
      materials: THREE.Material[];
      textures: THREE.Texture[];
    } = { geometries: [], materials: [], textures: [] };

    let currentVRM: VRM | null = null;
    let baseMesh: THREE.Mesh | null = null;
    let eyelidMesh: THREE.Mesh | null = null;
    let eyelidMat: THREE.MeshBasicMaterial | null = null;
    let activeVideoElement: HTMLVideoElement | null = null;
    let halfEyeTex: THREE.Texture | null = null;
    let closedEyeTex: THREE.Texture | null = null;

    // Body dimensions for 2D presentation
    const bodyHeight = anatomy.bodyHeight3D || 3.0;
    const bodyWidth = anatomy.bodyWidth3D || bodyHeight * (anatomy.widthPx / anatomy.heightPx);

    // Biological Blinking State Machine (3 to 6 seconds interval)
    let nextBlinkTime = 2.5 + Math.random() * 2.5;
    let blinkStartTime = 0;
    let isBlinking = false;
    let isDoubleBlink = false;
    let blinkProgress = 0; // 0 = open, 1 = closed

    // Category A: Load VRM / GLB Humanoid Model
    if (isVrmModel) {
      const gltfLoader = new GLTFLoader();
      gltfLoader.register((parser) => new VRMLoaderPlugin(parser));
      gltfLoader.load(
        rawPath,
        (gltf) => {
          const vrm = gltf.userData.vrm as VRM;
          if (vrm) {
            currentVRM = vrm;
            VRMUtils.removeUnnecessaryVertices(gltf.scene);
            VRMUtils.removeUnnecessaryJoints(gltf.scene);
            vrm.scene.rotation.y = Math.PI; // Standard VRM camera facing
            characterPivot.add(vrm.scene);

            // Natural upright posture: slightly lower arms if T-posed
            const leftUpperArm = vrm.humanoid?.getNormalizedBoneNode('leftUpperArm');
            const rightUpperArm = vrm.humanoid?.getNormalizedBoneNode('rightUpperArm');
            if (leftUpperArm && rightUpperArm) {
              leftUpperArm.rotation.z = THREE.MathUtils.degToRad(-68);
              rightUpperArm.rotation.z = THREE.MathUtils.degToRad(68);
            }
            updateCameraFraming();
          }
        },
        undefined,
        (err) => {
          console.warn('[ZoyaLiving3DAvatar] VRM load error, falling back to 2D texture:', err);
        }
      );
    } else if (isVideoModel) {
      // Category C: Video avatar (muted, looping, continuous)
      const video = document.createElement('video');
      video.src = rawPath;
      video.crossOrigin = 'anonymous';
      video.loop = true;
      video.muted = true;
      video.playsInline = true;
      video.autoplay = true;
      video.setAttribute('webkit-playsinline', 'true');
      activeVideoElement = video;

      const videoTex = new THREE.VideoTexture(video);
      videoTex.colorSpace = THREE.SRGBColorSpace;
      videoTex.minFilter = THREE.LinearFilter;
      videoTex.magFilter = THREE.LinearFilter;
      disposables.textures.push(videoTex);

      video.addEventListener('loadeddata', () => {
        updateCameraFraming();
      });

      video.play().catch((err) => {
        console.warn('[ZoyaLiving3DAvatar] Video autoplay error:', err);
      });

      const videoGeo = new THREE.PlaneGeometry(bodyWidth, bodyHeight, 1, 1);
      disposables.geometries.push(videoGeo);

      const videoMat = new THREE.MeshBasicMaterial({
        map: videoTex,
        transparent: true,
        side: THREE.DoubleSide,
      });
      disposables.materials.push(videoMat);

      baseMesh = new THREE.Mesh(videoGeo, videoMat);
      baseMesh.position.set(0, bodyHeight * 0.5, 0);
      characterPivot.add(baseMesh);
    } else {
      // Category B: Living 2D Avatar Rendering (Hair Breeze Sway + Natural Eye Blinking)
      const textureLoader = new THREE.TextureLoader();
      const maxAniso = renderer.capabilities.getMaxAnisotropy() || 8;

      // Base body texture
      const baseTex = textureLoader.load(rawPath, () => {
        updateCameraFraming();
      });
      baseTex.colorSpace = THREE.SRGBColorSpace;
      baseTex.minFilter = THREE.LinearMipmapLinearFilter;
      baseTex.magFilter = THREE.LinearFilter;
      baseTex.generateMipmaps = true;
      baseTex.anisotropy = maxAniso;
      disposables.textures.push(baseTex);

      // Subdivided plane (48x80 segments) for fine-grained hair vertex displacement
      const baseGeo = new THREE.PlaneGeometry(bodyWidth, bodyHeight, 48, 80);
      disposables.geometries.push(baseGeo);

      // Hair mask texture (0 = still scalp/face/body/clothes/feet, 1 = maximum sway at hair ends)
      const hairMaskTex = textureLoader.load(`${anatomy.modularPath}/hair_mask.png`);
      hairMaskTex.colorSpace = THREE.LinearSRGBColorSpace;
      hairMaskTex.minFilter = THREE.LinearFilter;
      hairMaskTex.magFilter = THREE.LinearFilter;
      hairMaskTex.generateMipmaps = false;
      hairMaskTex.wrapS = THREE.ClampToEdgeWrapping;
      hairMaskTex.wrapT = THREE.ClampToEdgeWrapping;
      disposables.textures.push(hairMaskTex);

      // Amplitude: ~0.7% of body width (gentle, realistic soft breeze)
      const hairAmplitude = bodyWidth * 0.007;

      const hairShaderMat = new THREE.ShaderMaterial({
        uniforms: {
          uTime: { value: 0 },
          uTexture: { value: baseTex },
          uHairMask: { value: hairMaskTex },
          uAmplitude: { value: hairAmplitude },
        },
        vertexShader: `
          uniform float uTime;
          uniform sampler2D uHairMask;
          uniform float uAmplitude;
          varying vec2 vUv;

          void main() {
            vUv = uv;
            vec3 pos = position;

            // Sample hair mask (0 = still scalp/body/clothes, 1 = maximum sway at hair ends)
            float mask = texture2D(uHairMask, uv).r;

            if (mask > 0.002) {
              float t = uTime;
              // Dual gentle harmonic wave plus micro-noise
              float wave1 = sin(t * 1.45 + (1.0 - uv.y) * 5.2);
              float wave2 = sin(t * 0.9 + (1.0 - uv.y) * 8.6 + 1.2) * 0.45;
              float microNoise = sin(t * 2.2 + uv.x * 14.0) * 0.12;

              float displacement = (wave1 + wave2 + microNoise) * uAmplitude * mask;
              pos.x += displacement;
              // Subtle 3D depth billow for natural hair strand motion in breeze
              pos.z += sin(t * 1.15 + (1.0 - uv.y) * 5.8) * uAmplitude * 0.35 * mask;
            }

            gl_Position = projectionMatrix * modelViewMatrix * vec4(pos, 1.0);
          }
        `,
        fragmentShader: `
          uniform sampler2D uTexture;
          varying vec2 vUv;

          void main() {
            vec4 color = texture2D(uTexture, vUv);
            if (color.a < 0.01) discard;
            gl_FragColor = color;
            #include <tonemapping_fragment>
            #include <colorspace_fragment>
          }
        `,
        transparent: true,
        depthWrite: true,
        side: THREE.DoubleSide,
      });
      disposables.materials.push(hairShaderMat);

      baseMesh = new THREE.Mesh(baseGeo, hairShaderMat);
      baseMesh.position.set(0, bodyHeight * 0.5, 0);
      characterPivot.add(baseMesh);

      // Multi-frame eyelid overlay (half-closed and closed frames)
      const eyeMarks = anatomy.eyeLandmarks || {
        cropW: 190,
        cropH: 80,
        eyeCenterX: anatomy.widthPx * 0.5,
        eyeCenterY: anatomy.heightPx * 0.15,
      };
      const { cropW, cropH, eyeCenterX, eyeCenterY } = eyeMarks;
      const eyeMeshW = (cropW / anatomy.widthPx) * bodyWidth;
      const eyeMeshH = (cropH / anatomy.heightPx) * bodyHeight;

      const normX = (eyeCenterX - anatomy.widthPx * 0.5) / anatomy.widthPx;
      const normY = (anatomy.heightPx * 0.5 - eyeCenterY) / anatomy.heightPx;
      const eyeLocalX = normX * bodyWidth;
      const eyeLocalY = normY * bodyHeight;

      let eyeGeo = new THREE.PlaneGeometry(eyeMeshW, eyeMeshH, 1, 1);
      disposables.geometries.push(eyeGeo);

      eyelidMat = new THREE.MeshBasicMaterial({
        map: null,
        transparent: true,
        opacity: 1,
        depthWrite: false,
        depthTest: false,
        side: THREE.DoubleSide,
      });
      disposables.materials.push(eyelidMat);

      eyelidMesh = new THREE.Mesh(eyeGeo, eyelidMat);
      eyelidMesh.renderOrder = 10;
      // Positioned directly at face eyes, glued to head (not displaced by hair wave)
      eyelidMesh.position.set(eyeLocalX, bodyHeight * 0.5 + eyeLocalY, 0.004);
      eyelidMesh.visible = false;
      characterPivot.add(eyelidMesh);

      closedEyeTex = textureLoader.load(`${anatomy.modularPath}/eyes_closed.png`, (tex) => {
        tex.needsUpdate = true;
        if (eyelidMat) {
          if (!eyelidMat.map) eyelidMat.map = tex;
          eyelidMat.needsUpdate = true;
        }
        // Preserve exact aspect ratio if image dimensions differ slightly from anatomy config
        if (tex.image && tex.image.width && tex.image.height && eyelidMesh) {
          const realAspect = tex.image.width / tex.image.height;
          const currentAspect = eyeMeshW / eyeMeshH;
          if (Math.abs(realAspect - currentAspect) > 0.04) {
            const adjustedW = eyeMeshH * realAspect;
            const newGeo = new THREE.PlaneGeometry(adjustedW, eyeMeshH, 1, 1);
            disposables.geometries.push(newGeo);
            eyelidMesh.geometry = newGeo;
          }
        }
      });
      closedEyeTex.colorSpace = THREE.SRGBColorSpace;
      closedEyeTex.minFilter = THREE.LinearFilter;
      closedEyeTex.magFilter = THREE.LinearFilter;
      disposables.textures.push(closedEyeTex);

      halfEyeTex = textureLoader.load(`${anatomy.modularPath}/eyes_half.png`, (tex) => {
        tex.needsUpdate = true;
        if (eyelidMat) eyelidMat.needsUpdate = true;
      });
      halfEyeTex.colorSpace = THREE.SRGBColorSpace;
      halfEyeTex.minFilter = THREE.LinearFilter;
      halfEyeTex.magFilter = THREE.LinearFilter;
      disposables.textures.push(halfEyeTex);
    }

    // Camera Framing (Head-to-Toe 100% visible, balanced padding, zero cropping)
    const fitHeight = 3.25;
    const fitWidth = bodyWidth * (fitHeight / bodyHeight);

    const updateCameraFraming = () => {
      if (!container || !camera || !renderer) return;
      const w = container.clientWidth || 380;
      const h = container.clientHeight || 650;
      const aspect = w / h;

      camera.aspect = aspect;
      const vFovRad = (camera.fov * Math.PI) / 180;
      const distForHeight = fitHeight / (2 * Math.tan(vFovRad / 2));
      const distForWidth = fitWidth / (2 * Math.tan(vFovRad / 2) * aspect);
      const targetDistance = Math.max(distForHeight, distForWidth);

      const lookY = feetY + bodyHeight * 0.5;
      camera.position.set(0, lookY, targetDistance);
      camera.lookAt(0, lookY, 0);
      camera.updateProjectionMatrix();

      renderer.setSize(w, h, false);
      renderer.render(scene, camera);
    };

    updateCameraFraming();

    // Resize Observer for dynamic window/screen resizing (debounced via requestAnimationFrame)
    let resizeObserver: ResizeObserver | null = null;
    let resizeRafId: number | null = null;
    let lastObservedW = 0;
    let lastObservedH = 0;

    if (typeof ResizeObserver !== 'undefined') {
      resizeObserver = new ResizeObserver((entries) => {
        if (!entries || !entries.length) return;
        const entry = entries[0];
        const w = Math.round(entry.contentRect.width);
        const h = Math.round(entry.contentRect.height);
        if (w === lastObservedW && h === lastObservedH) return;
        lastObservedW = w;
        lastObservedH = h;

        if (resizeRafId !== null) {
          cancelAnimationFrame(resizeRafId);
        }
        resizeRafId = requestAnimationFrame(() => {
          updateCameraFraming();
        });
      });
      resizeObserver.observe(container);
    } else {
      window.addEventListener('resize', updateCameraFraming);
    }

    // Animation Clock & Loop
    let isRunning = true;
    let isPausedForVisibility = false;
    let lastTime = performance.now();
    let accumulatedTime = 0;

    const handleVisibilityChange = () => {
      if (document.hidden) {
        isPausedForVisibility = true;
      } else {
        isPausedForVisibility = false;
        lastTime = performance.now();
      }
    };
    document.addEventListener('visibilitychange', handleVisibilityChange);

    const isLivingAvatar = !isVrmModel && !isVideoModel;

    const renderLoop = (now: number) => {
      if (!isRunning) return;

      if (!isPausedForVisibility) {
        const deltaSec = Math.min((now - lastTime) / 1000, 0.1);
        lastTime = now;
        accumulatedTime += deltaSec;

        // Feet and body stay perfectly still: NO bobbing, NO breathing scale, NO rotation
        // scaleFactor is already applied on characterRoot; keep characterPivot scale at 1
        characterPivot.scale.set(1, 1, 1);
        characterPivot.rotation.z = 0;
        characterPivot.position.set(0, feetY, 0);

        if (isLivingAvatar) {
          // 1. Update gentle hair breeze displacement shader
          const hairMat = (baseMesh?.material as THREE.ShaderMaterial);
          if (hairMat?.uniforms?.uTime) {
            hairMat.uniforms.uTime.value = accumulatedTime;
          }

          // Test hook support for deterministic test verification
          const forcedBlink = (typeof window !== 'undefined' ? (window as any).__zoyaCurrentForcedBlink : undefined) || 'auto';
          if (forcedBlink === 'open') {
            if (eyelidMesh) eyelidMesh.visible = false;
            isBlinking = false;
          } else if (forcedBlink === 'half') {
            if (eyelidMat && eyelidMesh && halfEyeTex) {
              eyelidMat.map = halfEyeTex;
              eyelidMat.needsUpdate = true;
              eyelidMesh.visible = true;
            }
          } else if (forcedBlink === 'closed') {
            if (eyelidMat && eyelidMesh && closedEyeTex) {
              eyelidMat.map = closedEyeTex;
              eyelidMat.needsUpdate = true;
              eyelidMesh.visible = true;
            }
          } else {
            // 2. Biological Multi-Frame Blinking (3-6s interval, occasional double-blink)
            if (!isBlinking && accumulatedTime >= nextBlinkTime) {
              isBlinking = true;
              blinkStartTime = accumulatedTime;
            }

            if (isBlinking && eyelidMat && eyelidMesh) {
              const blinkElapsed = accumulatedTime - blinkStartTime;
              // Blink timeline (closing in ~120 ms and opening in ~150 ms):
              // 0 - 0.06s (0-60ms): half-closed (closing)
              // 0.06 - 0.17s (60-170ms): fully closed
              // 0.17 - 0.28s (170-280ms): half-closed (opening)
              // > 0.28s: fully open (~150ms opening phase from closed state)
              const targetHalf = halfEyeTex || closedEyeTex;
              const targetClosed = closedEyeTex || halfEyeTex;

              if (blinkElapsed < 0.06) {
                if (eyelidMat.map !== targetHalf && targetHalf) {
                  eyelidMat.map = targetHalf;
                  eyelidMat.needsUpdate = true;
                }
                eyelidMesh.visible = Boolean(targetHalf);
              } else if (blinkElapsed < 0.17) {
                if (eyelidMat.map !== targetClosed && targetClosed) {
                  eyelidMat.map = targetClosed;
                  eyelidMat.needsUpdate = true;
                }
                eyelidMesh.visible = Boolean(targetClosed);
              } else if (blinkElapsed < 0.28) {
                if (eyelidMat.map !== targetHalf && targetHalf) {
                  eyelidMat.map = targetHalf;
                  eyelidMat.needsUpdate = true;
                }
                eyelidMesh.visible = Boolean(targetHalf);
              } else {
                eyelidMesh.visible = false;
                isBlinking = false;
                if (!isDoubleBlink && Math.random() < 0.18) {
                  isDoubleBlink = true;
                  nextBlinkTime = accumulatedTime + 0.14; // Double blink
                } else {
                  isDoubleBlink = false;
                  nextBlinkTime = accumulatedTime + 3.0 + Math.random() * 3.0; // 3 to 6 seconds
                }
              }
            } else if (eyelidMesh) {
              eyelidMesh.visible = false;
            }
          }
        }

        renderer.render(scene, camera);
      } else {
        lastTime = now;
      }

      animFrameRef.current = requestAnimationFrame(renderLoop);
    };

    animFrameRef.current = requestAnimationFrame(renderLoop);

    // Complete cleanup on unmount or avatar change (zero memory leaks, exactly ONE active avatar)
    return () => {
      isRunning = false;
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      if (animFrameRef.current !== null) {
        cancelAnimationFrame(animFrameRef.current);
      }
      if (resizeRafId !== null) {
        cancelAnimationFrame(resizeRafId);
      }
      if (resizeObserver) {
        resizeObserver.disconnect();
      } else {
        window.removeEventListener('resize', updateCameraFraming);
      }

      // Stop and dispose video element if active
      if (activeVideoElement) {
        activeVideoElement.pause();
        activeVideoElement.removeAttribute('src');
        activeVideoElement.load();
        activeVideoElement = null;
      }

      // Dispose VRM instance if active
      if (currentVRM) {
        VRMUtils.deepDispose(currentVRM.scene);
        currentVRM = null;
      }

      // Dispose all geometries, materials, and textures
      disposables.geometries.forEach((g) => g.dispose());
      disposables.materials.forEach((m) => m.dispose());
      disposables.textures.forEach((t) => t.dispose());

      while (scene.children.length > 0) {
        const obj = scene.children[0];
        scene.remove(obj);
      }

      renderer.setClearColor(0x000000, 0);
      renderer.clear(true, true, true);
      renderer.dispose();
      sceneRef.current = null;
      rendererRef.current = null;
      cameraRef.current = null;
    };
  }, [avatarId, avatarScale, avatarOffsetY]);

  return (
    <div
      ref={containerRef}
      onClick={onTapAvatar}
      className={`relative w-full h-full flex items-center justify-center select-none overflow-visible ${className}`}
      style={{ touchAction: 'manipulation' }}
    >
      <canvas
        ref={canvasRef}
        data-testid="zoya-living-avatar-canvas"
        className="w-full h-full block pointer-events-none"
        style={{
          width: '100%',
          height: '100%',
          filter: 'none',
        }}
      />
    </div>
  );
};
