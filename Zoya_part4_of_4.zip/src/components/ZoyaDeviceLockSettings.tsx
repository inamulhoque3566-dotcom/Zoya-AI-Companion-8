import React, { useState, useEffect } from 'react';
import {
  Lock,
  Unlock,
  KeyRound,
  Shield,
  ShieldCheck,
  ShieldAlert,
  Fingerprint,
  ScanFace,
  ExternalLink,
  RotateCw,
  Mic,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  HelpCircle,
  Sparkles,
  Info,
  Terminal,
  Smartphone
} from 'lucide-react';
import {
  deviceSecurity,
  DeviceSecurityStatus,
  SecurityOperationResult
} from '../services/deviceSecurity';
import { androidAccessibility } from '../services/androidAccessibility';

interface ZoyaDeviceLockSettingsProps {
  onBack?: () => void;
}

export const ZoyaDeviceLockSettings: React.FC<ZoyaDeviceLockSettingsProps> = () => {
  const [status, setStatus] = useState<DeviceSecurityStatus | null>(null);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);
  const [latestResult, setLatestResult] = useState<SecurityOperationResult | null>(null);
  const [logs, setLogs] = useState<Array<{ time: string; msg: string; success: boolean }>>([]);

  const addLog = (msg: string, success: boolean) => {
    const time = new Date().toLocaleTimeString();
    setLogs((prev) => [{ time, msg, success }, ...prev.slice(0, 15)]);
  };

  const refreshStatus = async () => {
    setLoading(true);
    try {
      const s = await deviceSecurity.getSecurityStatus();
      setStatus(s);
    } catch (e: any) {
      addLog(`Failed to refresh security status: ${e?.message || 'Error'}`, false);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    refreshStatus();
    const interval = setInterval(refreshStatus, 4000);
    return () => clearInterval(interval);
  }, []);

  const handleOpenEnrollment = async (type: 'pin' | 'password' | 'fingerprint' | 'face') => {
    setActionLoading(true);
    setLatestResult(null);
    try {
      const res = await deviceSecurity.openSecurityEnrollment(type);
      setLatestResult(res);
      addLog(`${type.toUpperCase()} Setup: ${res.message}`, res.success);
      setTimeout(refreshStatus, 1000);
    } catch (err: any) {
      const errRes = {
        success: false,
        message: err?.message || 'Failed to open security enrollment',
        error: 'EXCEPTION'
      };
      setLatestResult(errRes);
      addLog(`${type.toUpperCase()} Setup Failed: ${err?.message}`, false);
    } finally {
      setActionLoading(false);
    }
  };

  const handleLockNow = async () => {
    setActionLoading(true);
    setLatestResult(null);
    try {
      const res = await deviceSecurity.lockDevice();
      setLatestResult(res);
      addLog(`Lock Screen: ${res.message}`, res.success);
      setTimeout(refreshStatus, 500);
    } catch (err: any) {
      const errRes = {
        success: false,
        message: err?.message || 'Failed to lock screen',
        error: 'EXCEPTION'
      };
      setLatestResult(errRes);
      addLog(`Lock Screen Failed: ${err?.message}`, false);
    } finally {
      setActionLoading(false);
    }
  };

  const handleRequestUnlock = async () => {
    setActionLoading(true);
    setLatestResult(null);
    try {
      const res = await deviceSecurity.requestUnlock();
      setLatestResult(res);
      addLog(`Unlock Challenge: ${res.message}`, res.success);
      setTimeout(refreshStatus, 500);
    } catch (err: any) {
      const errRes = {
        success: false,
        message: err?.message || 'Failed to initiate unlock',
        error: 'EXCEPTION'
      };
      setLatestResult(errRes);
      addLog(`Unlock Failed: ${err?.message}`, false);
    } finally {
      setActionLoading(false);
    }
  };

  const isLocked = status?.screenState === 'locked' || status?.isKeyguardLocked;

  return (
    <div className="flex-1 overflow-y-auto px-4 py-3 space-y-4 text-white select-none pb-14">
      {/* 1. LIVE SECURITY STATUS & ACTION HUD */}
      <div className={`p-4 rounded-2xl border transition-all ${
        isLocked
          ? 'bg-[#2b1118] border-rose-500/50 shadow-[0_0_25px_rgba(244,63,94,0.25)]'
          : 'bg-[#0f1f1d] border-emerald-500/40 shadow-[0_0_20px_rgba(16,185,129,0.15)]'
      }`}>
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className={`w-11 h-11 rounded-xl flex items-center justify-center shrink-0 ${
              isLocked
                ? 'bg-rose-950/80 text-rose-400 border border-rose-500/40'
                : 'bg-emerald-950/80 text-emerald-300 border border-emerald-500/40'
            }`}>
              {isLocked ? <Lock className="w-6 h-6" /> : <ShieldCheck className="w-6 h-6" />}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-[16px] font-bold text-white">
                  Device Lock &amp; Keyguard Status
                </h3>
                {isLocked ? (
                  <span className="flex items-center gap-1 text-[10.5px] px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-400/40 font-semibold">
                    <Lock className="w-3 h-3" /> SCREEN LOCKED
                  </span>
                ) : (
                  <span className="flex items-center gap-1 text-[10.5px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/40 font-semibold">
                    <ShieldCheck className="w-3 h-3" /> UNLOCKED &amp; SECURE
                  </span>
                )}
              </div>
              <p className="text-[12px] text-slate-300 mt-0.5 leading-snug">
                Official Android OS Keyguard, BiometricManager, and Screen Lock integration.
              </p>
            </div>
          </div>

          <button
            onClick={refreshStatus}
            disabled={loading}
            className="p-2 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 transition-colors"
            title="Refresh status"
          >
            <RotateCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>

        {/* Status Indicators Grid */}
        <div className="mt-3.5 pt-3.5 border-t border-white/10 grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
          <div className="p-2.5 rounded-xl bg-black/40 border border-white/5">
            <span className="text-[10px] text-slate-400 uppercase tracking-wider block">Keyguard Security</span>
            <span className={`font-semibold flex items-center gap-1 mt-0.5 ${status?.isDeviceSecure ? 'text-emerald-400' : 'text-amber-400'}`}>
              {status?.isDeviceSecure ? <CheckCircle2 className="w-3 h-3" /> : <AlertTriangle className="w-3 h-3" />}
              {status?.isDeviceSecure ? 'PIN / Password Active' : 'No Lock Screen Set'}
            </span>
          </div>

          <div className="p-2.5 rounded-xl bg-black/40 border border-white/5">
            <span className="text-[10px] text-slate-400 uppercase tracking-wider block">Fingerprint Sensor</span>
            <span className={`font-semibold flex items-center gap-1 mt-0.5 ${
              status?.hasFingerprintHardware ? 'text-cyan-300' : 'text-slate-400'
            }`}>
              <Fingerprint className="w-3 h-3" />
              {status?.hasFingerprintHardware 
                ? (status.fingerprintStatus === 'enrolled' ? 'Hardware Enrolled' : 'Sensor Ready')
                : 'No Sensor Detected'}
            </span>
          </div>

          <div className="p-2.5 rounded-xl bg-black/40 border border-white/5">
            <span className="text-[10px] text-slate-400 uppercase tracking-wider block">Face Authentication</span>
            <span className={`font-semibold flex items-center gap-1 mt-0.5 ${
              status?.hasFaceHardware ? 'text-purple-300' : 'text-slate-400'
            }`}>
              <ScanFace className="w-3 h-3" />
              {status?.hasFaceHardware ? 'Biometric Supported' : 'Hardware Not Present'}
            </span>
          </div>

          <div className="p-2.5 rounded-xl bg-black/40 border border-white/5">
            <span className="text-[10px] text-slate-400 uppercase tracking-wider block">Voice Screen Lock</span>
            <span className={`font-semibold flex items-center gap-1 mt-0.5 ${
              status?.isAccessibilityRunning ? 'text-emerald-400' : 'text-amber-400'
            }`}>
              {status?.isAccessibilityRunning ? 'Service Active (API 28+)' : 'Service Disabled'}
            </span>
          </div>
        </div>

        {/* Quick Lock & Unlock Trigger Buttons */}
        <div className="mt-3.5 flex flex-col sm:flex-row gap-2">
          <button
            type="button"
            onClick={handleLockNow}
            disabled={actionLoading}
            className="flex-1 py-2.5 px-4 rounded-xl font-semibold text-[13px] flex items-center justify-center gap-2 bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 text-white border border-rose-400/40 shadow-[0_0_15px_rgba(244,63,94,0.3)] transition-all cursor-pointer disabled:opacity-50"
          >
            <Lock className="w-4 h-4" />
            Lock Device Screen Now
          </button>

          <button
            type="button"
            onClick={handleRequestUnlock}
            disabled={actionLoading}
            className="flex-1 py-2.5 px-4 rounded-xl font-semibold text-[13px] flex items-center justify-center gap-2 bg-[#1b2b3a] hover:bg-[#23384c] text-cyan-200 border border-cyan-500/40 transition-all cursor-pointer disabled:opacity-50"
          >
            <Unlock className="w-4 h-4" />
            Initiate Android Unlock Challenge
          </button>
        </div>
      </div>

      {/* 2. THE FOUR FUNCTIONAL SECURITY OPTIONS */}
      <div className="space-y-3">
        <h4 className="text-[14px] font-bold text-white flex items-center gap-2">
          <Shield className="w-4 h-4 text-cyan-400" />
          Android Device Lock &amp; Security Options
        </h4>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          
          {/* OPTION 1: PIN LOCK */}
          <div className="p-4 rounded-xl bg-[#141b26] border border-cyan-500/20 hover:border-cyan-500/40 transition-all flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-cyan-950/80 text-cyan-400 border border-cyan-500/30 flex items-center justify-center">
                    <KeyRound className="w-4 h-4" />
                  </div>
                  <div>
                    <h5 className="text-[14px] font-bold text-white">1. PIN Lock</h5>
                    <span className="text-[10px] text-cyan-300 font-mono">DevicePolicyManager API</span>
                  </div>
                </div>
                <span className={`text-[10px] px-2 py-0.5 rounded-full font-semibold border ${
                  status?.hasPinOrPassword 
                    ? 'bg-emerald-500/20 text-emerald-300 border-emerald-400/40' 
                    : 'bg-amber-500/20 text-amber-300 border-amber-400/40'
                }`}>
                  {status?.hasPinOrPassword ? 'Configured' : 'Not Set'}
                </span>
              </div>
              <p className="text-[12px] text-slate-300 leading-relaxed mb-3">
                Configure or update your Android lock screen numeric PIN. Zoya opens Android's official setup flow and never collects or stores your actual PIN.
              </p>
            </div>

            <button
              type="button"
              onClick={() => handleOpenEnrollment('pin')}
              disabled={actionLoading}
              className="w-full py-2 px-3 rounded-lg bg-cyan-900/40 hover:bg-cyan-800/60 text-cyan-200 border border-cyan-500/30 font-medium text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              Open Android PIN Setup
            </button>
          </div>

          {/* OPTION 2: PASSWORD LOCK */}
          <div className="p-4 rounded-xl bg-[#141b26] border border-indigo-500/20 hover:border-indigo-500/40 transition-all flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-indigo-950/80 text-indigo-400 border border-indigo-500/30 flex items-center justify-center">
                    <Lock className="w-4 h-4" />
                  </div>
                  <div>
                    <h5 className="text-[14px] font-bold text-white">2. Password Lock</h5>
                    <span className="text-[10px] text-indigo-300 font-mono">KeyguardManager API</span>
                  </div>
                </div>
                <span className={`text-[10px] px-2 py-0.5 rounded-full font-semibold border ${
                  status?.hasPinOrPassword 
                    ? 'bg-emerald-500/20 text-emerald-300 border-emerald-400/40' 
                    : 'bg-amber-500/20 text-amber-300 border-amber-400/40'
                }`}>
                  {status?.hasPinOrPassword ? 'Active' : 'Standby'}
                </span>
              </div>
              <p className="text-[12px] text-slate-300 leading-relaxed mb-3">
                Configure alphanumeric password protection for the device. Dispatches Android's official lock screen configuration intent. Passwords remain isolated in Android Keystore.
              </p>
            </div>

            <button
              type="button"
              onClick={() => handleOpenEnrollment('password')}
              disabled={actionLoading}
              className="w-full py-2 px-3 rounded-lg bg-indigo-900/40 hover:bg-indigo-800/60 text-indigo-200 border border-indigo-500/30 font-medium text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              Open Android Password Setup
            </button>
          </div>

          {/* OPTION 3: FACE UNLOCK */}
          <div className="p-4 rounded-xl bg-[#141b26] border border-purple-500/20 hover:border-purple-500/40 transition-all flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-purple-950/80 text-purple-400 border border-purple-500/30 flex items-center justify-center">
                    <ScanFace className="w-4 h-4" />
                  </div>
                  <div>
                    <h5 className="text-[14px] font-bold text-white">3. Face Unlock</h5>
                    <span className="text-[10px] text-purple-300 font-mono">BiometricManager / Android 10+</span>
                  </div>
                </div>
                <span className={`text-[10px] px-2 py-0.5 rounded-full font-semibold border ${
                  status?.hasFaceHardware 
                    ? 'bg-purple-500/20 text-purple-300 border-purple-400/40' 
                    : 'bg-slate-700/40 text-slate-400 border-slate-600/40'
                }`}>
                  {status?.hasFaceHardware ? 'Supported' : 'No Hardware'}
                </span>
              </div>
              <p className="text-[12px] text-slate-300 leading-relaxed mb-3">
                Verifies genuine Android biometric hardware support. Zoya uses official Android enrollment APIs and never simulates face recognition using the camera.
              </p>
            </div>

            <button
              type="button"
              onClick={() => handleOpenEnrollment('face')}
              disabled={actionLoading}
              className="w-full py-2 px-3 rounded-lg bg-purple-900/40 hover:bg-purple-800/60 text-purple-200 border border-purple-500/30 font-medium text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              {status?.hasFaceHardware ? 'Configure Face Enrollment' : 'Check Face Security Settings'}
            </button>
          </div>

          {/* OPTION 4: FINGERPRINT UNLOCK */}
          <div className="p-4 rounded-xl bg-[#141b26] border border-emerald-500/20 hover:border-emerald-500/40 transition-all flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-emerald-950/80 text-emerald-400 border border-emerald-500/30 flex items-center justify-center">
                    <Fingerprint className="w-4 h-4" />
                  </div>
                  <div>
                    <h5 className="text-[14px] font-bold text-white">4. Fingerprint Unlock</h5>
                    <span className="text-[10px] text-emerald-300 font-mono">BiometricPrompt API</span>
                  </div>
                </div>
                <span className={`text-[10px] px-2 py-0.5 rounded-full font-semibold border ${
                  status?.hasFingerprintHardware
                    ? 'bg-emerald-500/20 text-emerald-300 border-emerald-400/40'
                    : 'bg-slate-700/40 text-slate-400 border-slate-600/40'
                }`}>
                  {status?.hasFingerprintHardware ? 'Hardware Present' : 'No Hardware'}
                </span>
              </div>
              <p className="text-[12px] text-slate-300 leading-relaxed mb-3">
                Hardware fingerprint sensor detection and enrollment. Connects to Android BiometricPrompt for user verification without storing biometric data.
              </p>
            </div>

            <button
              type="button"
              onClick={() => handleOpenEnrollment('fingerprint')}
              disabled={actionLoading}
              className="w-full py-2 px-3 rounded-lg bg-emerald-900/40 hover:bg-emerald-800/60 text-emerald-200 border border-emerald-500/30 font-medium text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              Configure Fingerprint in Android
            </button>
          </div>

        </div>
      </div>

      {/* 3. VOICE-CONTROLLED DEVICE LOCK DIRECTORY */}
      <div className="p-4 rounded-xl bg-[#141824] border border-white/10 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Mic className="w-4 h-4 text-rose-400" />
            <h4 className="text-[13.5px] font-bold text-white">Voice-Controlled Device Lock Commands</h4>
          </div>
          <span className="text-[11px] px-2 py-0.5 rounded-full bg-rose-500/10 text-rose-300 border border-rose-500/30 font-medium">
            English &amp; Hindi Supported
          </span>
        </div>

        <p className="text-[12px] text-slate-300 leading-snug">
          Say any of these commands to Zoya. Screen locking executes natively through Android AccessibilityService <code className="text-rose-300 bg-black/40 px-1 py-0.5 rounded text-[11px]">GLOBAL_ACTION_LOCK_SCREEN</code> (API 28+).
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs font-mono">
          <div className="p-2.5 rounded-lg bg-black/30 border border-white/5 flex items-center justify-between">
            <span className="text-slate-300">"Zoya, lock my phone"</span>
            <span className="text-[10px] text-emerald-400">Lock Screen</span>
          </div>
          <div className="p-2.5 rounded-lg bg-black/30 border border-white/5 flex items-center justify-between">
            <span className="text-slate-300">"Zoya, lock the screen"</span>
            <span className="text-[10px] text-emerald-400">Lock Screen</span>
          </div>
          <div className="p-2.5 rounded-lg bg-black/30 border border-white/5 flex items-center justify-between">
            <span className="text-slate-300">"फोन लॉक करो" (Phone Lock Karo)</span>
            <span className="text-[10px] text-emerald-400">Hindi Lock</span>
          </div>
          <div className="p-2.5 rounded-lg bg-black/30 border border-white/5 flex items-center justify-between">
            <span className="text-slate-300">"स्क्रीन लॉक करो" (Screen Lock Karo)</span>
            <span className="text-[10px] text-emerald-400">Hindi Lock</span>
          </div>
        </div>
      </div>

      {/* 4. SECURITY & UNLOCK INTEGRITY POLICY */}
      <div className="p-4 rounded-xl bg-[#0f141f] border border-cyan-500/20 space-y-2.5">
        <div className="flex items-center gap-2">
          <ShieldAlert className="w-4 h-4 text-cyan-400" />
          <h4 className="text-[13px] font-bold text-white">Android Security &amp; Unlock Integrity Policy</h4>
        </div>
        <div className="text-[11.5px] text-slate-300 space-y-1.5 leading-relaxed">
          <p className="flex items-start gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
            <span><strong>Mandatory OS Verification:</strong> Android requires physical user confirmation (PIN, password, face, or fingerprint) to dismiss keyguard. Zoya triggers official challenge flows and never bypasses authentication.</span>
          </p>
          <p className="flex items-start gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
            <span><strong>Zero Credential Retention:</strong> Zoya never asks for, captures, logs, or stores PINs, passwords, or biometric templates.</span>
          </p>
          <p className="flex items-start gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
            <span><strong>No Root / Device Owner Misuse:</strong> Implemented via standard, documented Android SDK APIs without exploiting undocumented backdoors.</span>
          </p>
        </div>
      </div>

      {/* 5. EXECUTION CONSOLE & LOGS */}
      <div className="p-3.5 rounded-xl bg-black/40 border border-white/10 space-y-2">
        <div className="flex items-center justify-between text-xs">
          <span className="font-semibold text-slate-300 flex items-center gap-1.5">
            <Terminal className="w-3.5 h-3.5 text-emerald-400" />
            Device Security Execution Log
          </span>
          {latestResult && (
            <span className={`text-[10px] px-2 py-0.5 rounded font-mono ${
              latestResult.success ? 'bg-emerald-500/20 text-emerald-300' : 'bg-rose-500/20 text-rose-300'
            }`}>
              {latestResult.success ? 'SUCCESS' : 'FAILED'}
            </span>
          )}
        </div>

        {latestResult && (
          <div className={`p-2 rounded-lg text-xs font-mono ${
            latestResult.success ? 'bg-emerald-950/40 text-emerald-200 border border-emerald-500/30' : 'bg-rose-950/40 text-rose-200 border border-rose-500/30'
          }`}>
            {latestResult.message}
          </div>
        )}

        <div className="max-h-28 overflow-y-auto space-y-1 font-mono text-[11px] text-slate-400 divide-y divide-white/5">
          {logs.length === 0 ? (
            <div className="py-1 text-slate-500 italic">No security actions dispatched yet.</div>
          ) : (
            logs.map((l, i) => (
              <div key={i} className="pt-1 flex items-center justify-between">
                <span className={l.success ? 'text-slate-300' : 'text-rose-300'}>{l.msg}</span>
                <span className="text-[10px] text-slate-500 shrink-0 ml-2">{l.time}</span>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
