import React, { createContext, useCallback, useContext, useMemo, useRef, useState } from 'react';
import { audioLevelStore } from '../services/speech/audioLevelStore';

export type GlobalMicPhase =
  | 'off'
  | 'listening'
  | 'user_speaking'
  | 'processing'
  | 'ai_speaking'
  | 'reconnecting';

export type GlobalVoiceEngine =
  | 'none'
  | 'gemini-live'
  | 'mediarecorder'
  | 'webspeech'
  | 'native';

export interface GlobalMicContextValue {
  isGlobalMicOn: boolean;
  micPhase: GlobalMicPhase;
  activeEngine: GlobalVoiceEngine;
  audioLevel: number;
  isUserSpeaking: boolean;
  micError: string | null;
  setGlobalMicOn: (on: boolean) => void;
  setMicPhase: (phase: GlobalMicPhase) => void;
  setActiveEngine: (engine: GlobalVoiceEngine) => void;
  setAudioLevel: (level: number) => void;
  setIsUserSpeaking: (speaking: boolean) => void;
  setMicError: (error: string | null) => void;
  registerStopHandler: (handler: () => Promise<void> | void) => void;
  requestStopGlobalMic: () => Promise<void>;
  registerToggleHandler: (handler: () => Promise<void> | void) => void;
  requestToggleGlobalMic: () => Promise<void>;
}

const GlobalMicContext = createContext<GlobalMicContextValue | null>(null);

export const GlobalMicProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isGlobalMicOn, setIsGlobalMicOnState] = useState<boolean>(false);
  const [micPhase, setMicPhaseState] = useState<GlobalMicPhase>('off');
  const [activeEngine, setActiveEngineState] = useState<GlobalVoiceEngine>('none');
  const [isUserSpeaking, setIsUserSpeakingState] = useState<boolean>(false);
  const [micError, setMicErrorState] = useState<string | null>(null);

  const stopHandlerRef = useRef<(() => Promise<void> | void) | null>(null);
  const toggleHandlerRef = useRef<(() => Promise<void> | void) | null>(null);

  const setGlobalMicOn = useCallback((on: boolean) => {
    setIsGlobalMicOnState(on);
    if (!on) {
      setMicPhaseState('off');
      setIsUserSpeakingState(false);
      audioLevelStore.set(0);
    }
  }, []);

  const setMicPhase = useCallback((phase: GlobalMicPhase) => {
    setMicPhaseState(phase);
    if (phase === 'user_speaking') {
      setIsUserSpeakingState(true);
    } else if (phase === 'listening' || phase === 'ai_speaking' || phase === 'off') {
      setIsUserSpeakingState(false);
    }
  }, []);

  const setActiveEngine = useCallback((engine: GlobalVoiceEngine) => {
    setActiveEngineState(engine);
  }, []);

  const setAudioLevel = useCallback((level: number) => {
    audioLevelStore.set(level);
  }, []);

  const setIsUserSpeaking = useCallback((speaking: boolean) => {
    setIsUserSpeakingState(speaking);
  }, []);

  const setMicError = useCallback((error: string | null) => {
    setMicErrorState(error);
  }, []);

  const registerStopHandler = useCallback((handler: () => Promise<void> | void) => {
    stopHandlerRef.current = handler;
  }, []);

  const requestStopGlobalMic = useCallback(async () => {
    if (stopHandlerRef.current) {
      await stopHandlerRef.current();
    } else {
      setGlobalMicOn(false);
      setActiveEngine('none');
    }
  }, [setActiveEngine, setGlobalMicOn]);

  const registerToggleHandler = useCallback((handler: () => Promise<void> | void) => {
    toggleHandlerRef.current = handler;
  }, []);

  const requestToggleGlobalMic = useCallback(async () => {
    if (toggleHandlerRef.current) {
      await toggleHandlerRef.current();
    }
  }, []);

  const value = useMemo<GlobalMicContextValue>(
    () => ({
      isGlobalMicOn,
      micPhase,
      activeEngine,
      audioLevel: 0,
      isUserSpeaking,
      micError,
      setGlobalMicOn,
      setMicPhase,
      setActiveEngine,
      setAudioLevel,
      setIsUserSpeaking,
      setMicError,
      registerStopHandler,
      requestStopGlobalMic,
      registerToggleHandler,
      requestToggleGlobalMic,
    }),
    [
      isGlobalMicOn,
      micPhase,
      activeEngine,
      isUserSpeaking,
      micError,
      setGlobalMicOn,
      setMicPhase,
      setActiveEngine,
      setAudioLevel,
      setIsUserSpeaking,
      setMicError,
      registerStopHandler,
      requestStopGlobalMic,
      registerToggleHandler,
      requestToggleGlobalMic,
    ]
  );

  return <GlobalMicContext.Provider value={value}>{children}</GlobalMicContext.Provider>;
};

export function useGlobalMic(): GlobalMicContextValue {
  const ctx = useContext(GlobalMicContext);
  if (!ctx) {
    return {
      isGlobalMicOn: false,
      micPhase: 'off',
      activeEngine: 'none',
      audioLevel: 0,
      isUserSpeaking: false,
      micError: null,
      setGlobalMicOn: () => {},
      setMicPhase: () => {},
      setActiveEngine: () => {},
      setAudioLevel: () => {},
      setIsUserSpeaking: () => {},
      setMicError: () => {},
      registerStopHandler: () => {},
      requestStopGlobalMic: async () => {},
      registerToggleHandler: () => {},
      requestToggleGlobalMic: async () => {},
    };
  }
  return ctx;
}
