/**
 * Configuration for Rigged 3D Avatars (GLB/GLTF Models)
 *
 * Place your .glb files in the /public/models/ folder (e.g. /public/models/avatar_01.glb)
 * or provide any valid local or remote URL.
 */

export interface AvatarGlbItem {
  id: number;
  slug: string;
  name: string;
  path: string; // The GLB/GLTF file path
  category: string;
  description: string;
  colorAccent: string;
}

/**
 * The array of GLB avatar paths.
 * You can edit the 'path' property for each avatar to point to your GLB files.
 */
export const AVATAR_GLB_LIST: AvatarGlbItem[] = [
  {
    id: 1,
    slug: 'avatar_01',
    name: 'Avatar 01 - Parisian Cardigan',
    path: '/models/avatar_01.glb',
    category: 'Casual Chic',
    description: 'Chic knit cardigan and pleated skirt with rigged arms and blendshapes.',
    colorAccent: '#ef4444',
  },
  {
    id: 2,
    slug: 'avatar_02',
    name: 'Avatar 02 - Dusty Mauve Knit',
    path: '/models/avatar_02.glb',
    category: 'Cozy Elegance',
    description: 'Soft crop knit sweater and flowy cream skirt with full skeleton.',
    colorAccent: '#ec4899',
  },
  {
    id: 5,
    slug: 'avatar_05',
    name: 'Avatar 05 - Royal Plum Anarkali',
    path: '/models/avatar_05.glb',
    category: 'Heritage',
    description: 'Zari embroidered Anarkali gown with dual-arm idle gesture rigging.',
    colorAccent: '#8b5cf6',
  },
  {
    id: 6,
    slug: 'avatar_06',
    name: 'Avatar 06 - Ivory & Rose Florals',
    path: '/models/avatar_06.glb',
    category: 'Graceful',
    description: 'Ivory embroidered traditional gown with eyelid blink targets.',
    colorAccent: '#f43f5e',
  },
  {
    id: 10,
    slug: 'avatar_10',
    name: 'Avatar 10 - Signature Sweater & Glasses',
    path: '/models/avatar_10.glb',
    category: 'Signature Look',
    description: 'Ivory sweater, wire-rim glasses and upright posture locked skeleton.',
    colorAccent: '#64748b',
  },
  {
    id: 11,
    slug: 'avatar_11',
    name: 'Avatar 11 - Heritage Silk Saree',
    path: '/models/avatar_11.glb',
    category: 'Heritage Silk',
    description: 'Silk embroidered saree with locked hips and expressive arm gestures.',
    colorAccent: '#d946ef',
  },
  {
    id: 12,
    slug: 'avatar_urban_crop_hoodie',
    name: 'Urban Crop Hoodie & Cargo Joggers',
    path: '/models/avatar_urban_crop_hoodie.glb',
    category: 'Streetwear',
    description: 'White crop hoodie, red braid and baggy white cargo joggers with sneakers.',
    colorAccent: '#f97316',
  },
  {
    id: 13,
    slug: 'avatar_white_ruffle_babydoll',
    name: 'White Satin Ruffle Babydoll',
    path: '/models/avatar_white_ruffle_babydoll.glb',
    category: 'Romantic',
    description: 'Pearl white satin corset babydoll dress with ribbon tie and bow heels.',
    colorAccent: '#e0e7ff',
  },
  {
    id: 14,
    slug: 'avatar_pink_athleisure_track',
    name: 'Pink Athleisure Tracksuit',
    path: '/models/avatar_pink_athleisure_track.glb',
    category: 'Athleisure',
    description: 'Glossy pink track jacket, matching running shorts, tinted glasses and bob.',
    colorAccent: '#f472b6',
  },
  {
    id: 16,
    slug: 'avatar_pastel_blue_knit_shorts',
    name: 'Pastel Blue Knit & Pink Shorts',
    path: '/models/avatar_pastel_blue_knit_shorts.glb',
    category: 'Cozy Pastel',
    description: 'Striped off-shoulder knit sweater, pink dolphin shorts and sky-blue hair.',
    colorAccent: '#38bdf8',
  },
  {
    id: 18,
    slug: 'avatar_slate_blue_regal_kurta',
    name: 'Slate Blue Regal Kurta & Cape',
    path: '/models/avatar_slate_blue_regal_kurta.glb',
    category: 'Ethnic Royalty',
    description: 'Slate blue embroidered long kurta, flowy sheer cape dupatta and palazzo.',
    colorAccent: '#6366f1',
  },
  {
    id: 19,
    slug: 'avatar_midnight_gold_zari_saree',
    name: 'Midnight Black & Gold Zari Saree',
    path: '/models/avatar_midnight_gold_zari_saree.glb',
    category: 'Midnight Saree',
    description: 'Sheer black chiffon saree with gold floral zari border and wire-rim glasses.',
    colorAccent: '#eab308',
  },
  {
    id: 21,
    slug: 'avatar_nautical_denim_shorts',
    name: 'Silk Blouse & Nautical Denim Shorts',
    path: '/models/avatar_nautical_denim_shorts.glb',
    category: 'Chic Nautical',
    description: 'Cream balloon-sleeve silk blouse, high-waist sailor denim shorts and glasses.',
    colorAccent: '#3b82f6',
  },
];
