import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { spawnSync } from 'child_process';
import JSZip from 'jszip';
import { maskSecrets, agentPermissionGuard } from './agentPermissionGuard.ts';

export type SkillStatus = 'quarantined' | 'installed' | 'enabled' | 'disabled';
export type SkillRiskLevel = 'LOW' | 'MEDIUM' | 'HIGH';

export interface SkillSecurityFinding {
  file: string;
  line: number;
  pattern: string;
  risk: SkillRiskLevel;
  message: string;
  snippet: string;
}

export interface SkillDependencyReport {
  python: {
    declared: string[];
    installed: string[];
    missing: string[];
  };
  node: {
    declared: string[];
    installed: string[];
    missing: string[];
  };
  binaries: {
    declared: string[];
    installed: string[];
    missing: string[];
  };
}

export interface SkillMetadata {
  id: string;
  name: string;
  description: string;
  version: string;
  author?: string;
  tags?: string[];
  binaries?: string[];
  status: SkillStatus;
  riskLevel: SkillRiskLevel;
  contentHash: string;
  installedAt?: string;
  updatedAt?: string;
  skillPath: string;
  findings: SkillSecurityFinding[];
  dependencies: SkillDependencyReport;
}

export interface SkillScanResult {
  quarantineId: string;
  name: string;
  description: string;
  version: string;
  tags?: string[];
  binaries?: string[];
  riskLevel: SkillRiskLevel;
  findings: SkillSecurityFinding[];
  dependencies: SkillDependencyReport;
  contentHash: string;
  requiresStrictApproval: boolean;
}

const BASE_DIR = path.join(process.cwd(), 'data', 'agent_skills');
const QUARANTINE_DIR = path.join(BASE_DIR, 'quarantine');
const INSTALLED_DIR = path.join(BASE_DIR, 'installed');
const REGISTRY_FILE = path.join(BASE_DIR, 'skills_registry.json');
const AUDIT_LOG_FILE = path.join(process.cwd(), 'data', 'agent_logs', 'skills_audit.log');

// Ensure base directories exist
for (const dir of [BASE_DIR, QUARANTINE_DIR, INSTALLED_DIR, path.dirname(AUDIT_LOG_FILE)]) {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true, mode: 0o755 });
  }
}

export class SkillsEngine {
  private static instance: SkillsEngine;
  private registry = new Map<string, SkillMetadata>();

  constructor() {
    this.loadRegistry();
  }

  public static getInstance(): SkillsEngine {
    if (!SkillsEngine.instance) {
      SkillsEngine.instance = new SkillsEngine();
    }
    return SkillsEngine.instance;
  }

  private loadRegistry(): void {
    try {
      if (fs.existsSync(REGISTRY_FILE)) {
        const raw = fs.readFileSync(REGISTRY_FILE, 'utf8');
        const list: SkillMetadata[] = JSON.parse(raw);
        this.registry.clear();
        for (const item of list) {
          this.registry.set(item.id, item);
        }
      }
    } catch (e) {
      console.warn('[SKILLS_ENGINE] Could not load skills registry:', e);
    }
  }

  private saveRegistry(): void {
    try {
      const list = Array.from(this.registry.values());
      fs.writeFileSync(REGISTRY_FILE, JSON.stringify(list, null, 2), 'utf8');
    } catch (e) {
      console.error('[SKILLS_ENGINE] Could not save skills registry:', e);
    }
  }

  private logAudit(action: string, skillId: string, details: string, meta?: any): void {
    const entry = {
      timestamp: new Date().toISOString(),
      action,
      skillId,
      details: maskSecrets(details),
      meta: meta ? JSON.parse(maskSecrets(JSON.stringify(meta))) : undefined,
    };
    try {
      fs.appendFileSync(AUDIT_LOG_FILE, JSON.stringify(entry) + '\n', 'utf8');
    } catch {}
  }

  /**
   * Computes a deterministic SHA-256 hash across all files in a directory
   */
  public computeDirectoryHash(dirPath: string): string {
    const hash = crypto.createHash('sha256');
    const walk = (current: string) => {
      const entries = fs.readdirSync(current, { withFileTypes: true }).sort((a, b) => a.name.localeCompare(b.name));
      for (const entry of entries) {
        const full = path.join(current, entry.name);
        const rel = path.relative(dirPath, full);
        if (entry.isDirectory()) {
          walk(full);
        } else if (entry.isFile()) {
          hash.update(rel);
          hash.update(fs.readFileSync(full));
        }
      }
    };
    if (fs.existsSync(dirPath)) {
      walk(dirPath);
    }
    return hash.digest('hex');
  }

  // =========================================================================
  // 1. IMPORT & ZIP SAFETY
  // =========================================================================

  /**
   * Imports a skill from a local folder into quarantine.
   * ABSOLUTE RULE: Never executes any code during import!
   */
  public importFromFolder(folderPath: string): { quarantineId: string; quarantinePath: string } {
    if (!fs.existsSync(folderPath)) {
      throw new Error(`Source folder does not exist: ${folderPath}`);
    }
    const stat = fs.statSync(folderPath);
    if (!stat.isDirectory()) {
      throw new Error(`Source path is not a directory: ${folderPath}`);
    }

    const quarantineId = `quarantine_${Date.now()}_${crypto.randomBytes(4).toString('hex')}`;
    const targetDir = path.join(QUARANTINE_DIR, quarantineId);
    fs.mkdirSync(targetDir, { recursive: true });

    // Copy files recursively without executing anything
    this.copyDirectoryRecursively(folderPath, targetDir);

    this.logAudit('IMPORT_FOLDER', quarantineId, `Imported skill from folder: ${folderPath}`, { source: folderPath });
    return { quarantineId, quarantinePath: targetDir };
  }

  /**
   * Imports a skill from a ZIP archive with strict Zip-Slip, symlink, and zip-bomb protection.
   * ABSOLUTE RULE: Never executes any code during import!
   */
  public async importFromZip(zipBufferOrPath: Buffer | string): Promise<{ quarantineId: string; quarantinePath: string }> {
    let buffer: Buffer;
    if (typeof zipBufferOrPath === 'string') {
      if (!fs.existsSync(zipBufferOrPath)) {
        throw new Error(`Zip file does not exist: ${zipBufferOrPath}`);
      }
      buffer = fs.readFileSync(zipBufferOrPath);
    } else {
      buffer = zipBufferOrPath;
    }

    const zip = await JSZip.loadAsync(buffer);
    const quarantineId = `quarantine_${Date.now()}_${crypto.randomBytes(4).toString('hex')}`;
    const targetDir = path.join(QUARANTINE_DIR, quarantineId);
    fs.mkdirSync(targetDir, { recursive: true });

    // Zip bomb limits: max 500 files, max 25MB uncompressed
    const MAX_FILES = 500;
    const MAX_TOTAL_SIZE = 25 * 1024 * 1024;
    let totalFiles = 0;
    let totalSize = 0;

    const entries = Object.keys(zip.files);
    if (entries.length > MAX_FILES) {
      throw new Error(`ZIP SAFETY VIOLATION: Archive contains ${entries.length} files (Limit: ${MAX_FILES}).`);
    }

    for (const relativePath of entries) {
      const zipEntry = zip.files[relativePath];
      totalFiles++;

      // 1. Zip-Slip protection: normalize and prevent parent directory escape
      const normalized = path.normalize(relativePath);
      if (
        normalized.startsWith('..') ||
        path.isAbsolute(normalized) ||
        normalized.includes('../') ||
        normalized.includes('..\\')
      ) {
        // Clean up partial extraction
        try { fs.rmSync(targetDir, { recursive: true, force: true }); } catch {}
        throw new Error(`ZIP SAFETY VIOLATION (Zip-Slip): Illegal file path detected in archive: '${relativePath}'`);
      }

      const destPath = path.join(targetDir, normalized);
      if (!destPath.startsWith(targetDir)) {
        try { fs.rmSync(targetDir, { recursive: true, force: true }); } catch {}
        throw new Error(`ZIP SAFETY VIOLATION: Path '${normalized}' escapes target quarantine directory.`);
      }

      // Check symlink bits in Unix permissions header
      const unixMode = (zipEntry as any).unixPermissions;
      if (unixMode && (unixMode & 0o170000) === 0o120000) {
        try { fs.rmSync(targetDir, { recursive: true, force: true }); } catch {}
        throw new Error(`ZIP SAFETY VIOLATION: Symbolic links are strictly prohibited in skill archives: '${relativePath}'`);
      }

      if (zipEntry.dir) {
        fs.mkdirSync(destPath, { recursive: true });
      } else {
        const fileData = await zipEntry.async('nodebuffer');
        totalSize += fileData.length;
        if (totalSize > MAX_TOTAL_SIZE) {
          try { fs.rmSync(targetDir, { recursive: true, force: true }); } catch {}
          throw new Error(`ZIP SAFETY VIOLATION (Zip-Bomb): Total uncompressed size exceeds limit (${totalSize} > ${MAX_TOTAL_SIZE}).`);
        }
        const parent = path.dirname(destPath);
        if (!fs.existsSync(parent)) fs.mkdirSync(parent, { recursive: true });
        fs.writeFileSync(destPath, fileData);
      }
    }

    this.logAudit('IMPORT_ZIP', quarantineId, `Imported skill from ZIP (${totalFiles} files, ${totalSize} bytes)`);
    return { quarantineId, quarantinePath: targetDir };
  }

  /**
   * Imports a public skill from a GitHub repository.
   * If network is unavailable or blocked, safely reports the network constraint.
   */
  public async importFromGit(repoUrl: string, subPath?: string): Promise<{ quarantineId: string; quarantinePath: string }> {
    if (!repoUrl || (!repoUrl.startsWith('https://github.com/') && !repoUrl.startsWith('file://') && !repoUrl.startsWith('/'))) {
      throw new Error(`Invalid Git repository URL: '${repoUrl}'. Must start with https://github.com/ or local git repository.`);
    }

    const quarantineId = `quarantine_${Date.now()}_${crypto.randomBytes(4).toString('hex')}`;
    const targetDir = path.join(QUARANTINE_DIR, quarantineId);

    // Attempt shallow clone without running any hooks (appuser context)
    const cloneResult = spawnSync('git', ['clone', '--depth', '1', repoUrl, targetDir], {
      timeout: 25000,
      env: {
        PATH: process.env.PATH,
        GIT_TERMINAL_PROMPT: '0',
      },
    });

    if (cloneResult.status !== 0) {
      const err = (cloneResult.stderr || cloneResult.stdout || '').toString().trim();
      try { fs.rmSync(targetDir, { recursive: true, force: true }); } catch {}
      throw new Error(`Git clone failed or network unavailable (${err || 'Connection refused'}). Use a local fixture or zip archive.`);
    }

    // Clean up .git directory immediately (skills must be plain files)
    try {
      const gitDir = path.join(targetDir, '.git');
      if (fs.existsSync(gitDir)) fs.rmSync(gitDir, { recursive: true, force: true });
    } catch {}

    // If subPath is specified or targetDir lacks SKILL.md, look for SKILL.md in subfolders
    let skillSourceDir = targetDir;
    if (subPath) {
      const candidate = path.resolve(targetDir, subPath);
      if (candidate.startsWith(targetDir) && fs.existsSync(candidate)) {
        skillSourceDir = candidate;
      }
    } else if (!fs.existsSync(path.join(targetDir, 'SKILL.md'))) {
      // Auto-detect if there is a skills/<skill-name> directory with SKILL.md
      const skillsSubDir = path.join(targetDir, 'skills');
      if (fs.existsSync(skillsSubDir)) {
        const subEntries = fs.readdirSync(skillsSubDir, { withFileTypes: true });
        for (const entry of subEntries) {
          if (entry.isDirectory() && fs.existsSync(path.join(skillsSubDir, entry.name, 'SKILL.md'))) {
            skillSourceDir = path.join(skillsSubDir, entry.name);
            break;
          }
        }
      }
    }

    if (skillSourceDir !== targetDir) {
      const tempStaging = path.join(QUARANTINE_DIR, `${quarantineId}_staging`);
      fs.mkdirSync(tempStaging, { recursive: true });
      this.copyDirectoryRecursively(skillSourceDir, tempStaging);
      fs.rmSync(targetDir, { recursive: true, force: true });
      fs.renameSync(tempStaging, targetDir);
    }

    this.logAudit('IMPORT_GIT', quarantineId, `Cloned repository ${repoUrl} into quarantine (subpath: ${subPath || 'root'})`);
    return { quarantineId, quarantinePath: targetDir };
  }

  // =========================================================================
  // 2. PARSER: SKILL.md FRONTMATTER
  // =========================================================================

  /**
   * Parses and validates SKILL.md in a skill directory.
   */
  public parseSkillManifest(skillDir: string): {
    name: string;
    description: string;
    version: string;
    author?: string;
    tags?: string[];
    binaries?: string[];
    body: string;
  } {
    const skillMdPath = path.join(skillDir, 'SKILL.md');
    if (!fs.existsSync(skillMdPath)) {
      throw new Error(`Invalid skill: Missing required 'SKILL.md' manifest file in ${skillDir}`);
    }

    const content = fs.readFileSync(skillMdPath, 'utf8');
    const frontmatterRegex = /^---\r?\n([\s\S]*?)\r?\n---\r?\n([\s\S]*)$/;
    const match = content.match(frontmatterRegex);

    if (!match) {
      throw new Error(`Invalid SKILL.md format: Must begin with YAML frontmatter delimiter (---).`);
    }

    const yamlBlock = match[1];
    const body = match[2];

    const parsed: Record<string, any> = {};
    for (const rawLine of yamlBlock.split('\n')) {
      const line = rawLine.trim();
      if (!line || line.startsWith('#')) continue;
      const colonIdx = line.indexOf(':');
      if (colonIdx > 0) {
        const key = line.slice(0, colonIdx).trim();
        let val = line.slice(colonIdx + 1).trim();
        // Remove quotes if present
        if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) {
          val = val.slice(1, -1);
        }
        // Handle comma-separated lists for tags/binaries
        if (val.startsWith('[') && val.endsWith(']')) {
          parsed[key] = val.slice(1, -1).split(',').map((s) => s.trim().replace(/^['"]|['"]$/g, '')).filter(Boolean);
        } else {
          parsed[key] = val;
        }
      }
    }

    if (!parsed.name || typeof parsed.name !== 'string' || !parsed.name.trim()) {
      throw new Error(`Invalid SKILL.md: Frontmatter is missing required 'name' field.`);
    }

    // Validate name format: lowercase alphanumeric, hyphen, underscore (1-64 chars)
    const cleanName = parsed.name.trim();
    if (!/^[a-zA-Z0-9_\-]{1,64}$/.test(cleanName)) {
      throw new Error(`Invalid skill name '${cleanName}': Must be 1-64 alphanumeric characters, hyphens, or underscores.`);
    }

    if (!parsed.description || typeof parsed.description !== 'string' || !parsed.description.trim()) {
      throw new Error(`Invalid SKILL.md: Frontmatter is missing required 'description' field.`);
    }

    return {
      name: cleanName,
      description: parsed.description.trim(),
      version: parsed.version || '1.0.0',
      author: parsed.author,
      tags: Array.isArray(parsed.tags) ? parsed.tags : undefined,
      binaries: Array.isArray(parsed.binaries) ? parsed.binaries : undefined,
      body,
    };
  }

  // =========================================================================
  // 3. SECURITY SCANNER (PRE-INSTALL RISK ANALYSIS)
  // =========================================================================

  /**
   * Scans all files in a skill directory for dangerous patterns and security hazards.
   */
  public scanSkillDirectory(skillDir: string): {
    findings: SkillSecurityFinding[];
    riskLevel: SkillRiskLevel;
  } {
    const findings: SkillSecurityFinding[] = [];

    const walk = (current: string) => {
      const items = fs.readdirSync(current, { withFileTypes: true });
      for (const item of items) {
        const full = path.join(current, item.name);
        const rel = path.relative(skillDir, full);

        if (item.isDirectory()) {
          walk(full);
        } else if (item.isFile()) {
          // Scan text and code files (skip large binary media)
          const ext = path.extname(item.name).toLowerCase();
          const scanExtensions = ['.md', '.py', '.js', '.ts', '.sh', '.bash', '.json', '.txt', '.yaml', '.yml', '.rb', '.php'];
          if (scanExtensions.includes(ext) || item.name === 'requirements.txt' || item.name === 'package.json') {
            this.scanSingleFile(full, rel, findings);
          }
        }
      }
    };

    walk(skillDir);

    // Compute overall risk level
    let riskLevel: SkillRiskLevel = 'LOW';
    if (findings.some((f) => f.risk === 'HIGH')) {
      riskLevel = 'HIGH';
    } else if (findings.some((f) => f.risk === 'MEDIUM')) {
      riskLevel = 'MEDIUM';
    }

    return { findings, riskLevel };
  }

  private scanSingleFile(filePath: string, relPath: string, findings: SkillSecurityFinding[]): void {
    let content = '';
    try {
      content = fs.readFileSync(filePath, 'utf8');
    } catch {
      return;
    }

    const lines = content.split('\n');

    // Scan patterns
    const securityRules: Array<{
      pattern: RegExp;
      risk: SkillRiskLevel;
      message: string;
      ruleName: string;
    }> = [
      // 1. Shell pipe to sh/bash
      {
        pattern: /\|\s*(sh|bash|zsh)\b/i,
        risk: 'HIGH',
        message: 'Direct piping of command output to shell interpreter (| sh)',
        ruleName: 'SHELL_PIPE',
      },
      // 2. Sensitive system files or root secrets
      {
        pattern: /(?:\/etc\/(?:passwd|shadow|hosts|sudoers)|\/root\/\.zoya|\.env\b|agent_user_secret|agent_auth_token)/i,
        risk: 'HIGH',
        message: 'Access to sensitive system files, root directory, or auth tokens',
        ruleName: 'SECRET_ACCESS',
      },
      // 3. Destructive deletion
      {
        pattern: /\brm\s+-[a-z]*r[a-z]*f\b|\bshutil\.rmtree\b|\bos\.unlink\b/i,
        risk: 'HIGH',
        message: 'Recursive destructive file deletion (rm -rf / rmtree)',
        ruleName: 'DESTRUCTIVE_DELETE',
      },
      // 4. Evasion / Obfuscation
      {
        pattern: /chr\s*\(\s*47\s*\)|base64\s+(-d|--decode)|b64decode/i,
        risk: 'HIGH',
        message: 'Potential code obfuscation or encoded payload (chr() / b64decode)',
        ruleName: 'CODE_OBFUSCATION',
      },
      // 5. Arbitrary Code Evaluation (eval / exec)
      {
        pattern: /\b(eval|exec)\s*\(/i,
        risk: 'MEDIUM',
        message: 'Dynamic code execution (eval / exec)',
        ruleName: 'DYNAMIC_CODE_EXECUTION',
      },
      // 6. Subprocess / Child Process
      {
        pattern: /\b(subprocess\.(?:Popen|run|call)|child_process\.(?:spawn|exec|execSync)|os\.system)\b/i,
        risk: 'MEDIUM',
        message: 'Subprocess or shell process creation',
        ruleName: 'SUBPROCESS_SPAWN',
      },
      // 7. Network Calls
      {
        pattern: /\b(curl|wget|fetch|axios|requests\.(?:get|post)|urllib\.request|http\.client|socket\.)\b/i,
        risk: 'MEDIUM',
        message: 'External network communication call',
        ruleName: 'NETWORK_CALL',
      },
      // 8. Environment Variable Access
      {
        pattern: /\b(?:os\.environ|process\.env)\b/i,
        risk: 'LOW',
        message: 'Environment variable access',
        ruleName: 'ENV_READ',
      },
    ];

    for (let i = 0; i < lines.length; i++) {
      const lineText = lines[i];
      for (const rule of securityRules) {
        if (rule.pattern.test(lineText)) {
          findings.push({
            file: relPath,
            line: i + 1,
            pattern: rule.ruleName,
            risk: rule.risk,
            message: rule.message,
            snippet: lineText.trim().slice(0, 120),
          });
        }
      }
    }
  }

  // =========================================================================
  // 4. DEPENDENCY DETECTION (REPORT ONLY - NEVER AUTO-INSTALL)
  // =========================================================================

  /**
   * Scans a skill folder for declared dependencies (Python requirements.txt, Node package.json, binaries).
   * ONLY reports missing dependencies. Never installs anything automatically.
   */
  public detectDependencies(skillDir: string, declaredBinaries: string[] = []): SkillDependencyReport {
    const report: SkillDependencyReport = {
      python: { declared: [], installed: [], missing: [] },
      node: { declared: [], installed: [], missing: [] },
      binaries: { declared: declaredBinaries, installed: [], missing: [] },
    };

    // 1. Python requirements.txt
    const reqFile = path.join(skillDir, 'requirements.txt');
    if (fs.existsSync(reqFile)) {
      try {
        const rawReqs = fs.readFileSync(reqFile, 'utf8');
        const pkgNames = rawReqs
          .split('\n')
          .map((l) => l.trim().split(/[<>=!~;]/)[0].trim())
          .filter((p) => p && !p.startsWith('#'));
        report.python.declared = pkgNames;

        for (const pkg of pkgNames) {
          // Check if installed in python3 environment
          const check = spawnSync('python3', ['-c', `import importlib.util; exit(0 if importlib.util.find_spec('${pkg}') else 1)`]);
          if (check.status === 0) {
            report.python.installed.push(pkg);
          } else {
            report.python.missing.push(pkg);
          }
        }
      } catch {}
    }

    // 2. Node package.json
    const pkgFile = path.join(skillDir, 'package.json');
    if (fs.existsSync(pkgFile)) {
      try {
        const rawPkg = fs.readFileSync(pkgFile, 'utf8');
        const pkgJson = JSON.parse(rawPkg);
        const deps = Object.keys(pkgJson.dependencies || {});
        report.node.declared = deps;

        for (const dep of deps) {
          const check = spawnSync('node', ['-e', `try { require.resolve('${dep}'); process.exit(0); } catch { process.exit(1); }`]);
          if (check.status === 0) {
            report.node.installed.push(dep);
          } else {
            report.node.missing.push(dep);
          }
        }
      } catch {}
    }

    // 3. Declared System Binaries (which binary)
    for (const bin of declaredBinaries) {
      const whichProc = spawnSync('which', [bin]);
      if (whichProc.status === 0) {
        report.binaries.installed.push(bin);
      } else {
        report.binaries.missing.push(bin);
      }
    }

    return report;
  }

  // =========================================================================
  // 5. SCAN QUARANTINE SKILL
  // =========================================================================

  public scanQuarantineSkill(quarantineId: string): SkillScanResult {
    const qPath = path.join(QUARANTINE_DIR, quarantineId);
    if (!fs.existsSync(qPath)) {
      throw new Error(`Quarantine skill not found: ${quarantineId}`);
    }

    const manifest = this.parseSkillManifest(qPath);
    const { findings, riskLevel } = this.scanSkillDirectory(qPath);
    const dependencies = this.detectDependencies(qPath, manifest.binaries || []);
    const contentHash = this.computeDirectoryHash(qPath);

    return {
      quarantineId,
      name: manifest.name,
      description: manifest.description,
      version: manifest.version,
      tags: manifest.tags,
      binaries: manifest.binaries,
      riskLevel,
      findings,
      dependencies,
      contentHash,
      requiresStrictApproval: riskLevel === 'HIGH',
    };
  }

  // =========================================================================
  // 6. INSTALL & LIFECYCLE
  // =========================================================================

  /**
   * Installs a quarantined skill into the installed registry.
   * If riskLevel is HIGH, userApprovalSecret is required.
   * NEVER executes code during install!
   */
  public installSkill(
    quarantineId: string,
    options?: { userApprovalSecret?: string; forceApproveHighRisk?: boolean }
  ): SkillMetadata {
    const qPath = path.join(QUARANTINE_DIR, quarantineId);
    if (!fs.existsSync(qPath)) {
      throw new Error(`Quarantine skill not found: ${quarantineId}`);
    }

    const scan = this.scanQuarantineSkill(quarantineId);

    // High risk enforcement: require user approval secret
    if (scan.requiresStrictApproval) {
      if (!options?.forceApproveHighRisk) {
        throw new Error(
          `HIGH RISK SKILL BLOCKED: Skill '${scan.name}' contains high-risk patterns. Explicit human approval is required before installation.`
        );
      }
    }

    const skillId = scan.name;
    const destDir = path.join(INSTALLED_DIR, skillId);

    // If already installed, replace cleanly
    if (fs.existsSync(destDir)) {
      fs.rmSync(destDir, { recursive: true, force: true });
    }
    fs.mkdirSync(destDir, { recursive: true, mode: 0o755 });

    // Copy files from quarantine to installed folder (no execution!)
    this.copyDirectoryRecursively(qPath, destDir);

    // Remove quarantine staging folder
    try {
      fs.rmSync(qPath, { recursive: true, force: true });
    } catch {}

    const meta: SkillMetadata = {
      id: skillId,
      name: scan.name,
      description: scan.description,
      version: scan.version,
      tags: scan.tags,
      binaries: scan.binaries,
      status: 'installed',
      riskLevel: scan.riskLevel,
      contentHash: scan.contentHash,
      installedAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      skillPath: destDir,
      findings: scan.findings,
      dependencies: scan.dependencies,
    };

    this.registry.set(skillId, meta);
    this.saveRegistry();

    this.logAudit('INSTALL', skillId, `Installed skill '${scan.name}' with risk level ${scan.riskLevel}`, {
      contentHash: scan.contentHash,
      findingsCount: scan.findings.length,
    });

    return meta;
  }

  public enableSkill(skillId: string): SkillMetadata {
    const skill = this.registry.get(skillId);
    if (!skill) throw new Error(`Skill '${skillId}' not found in registry.`);
    skill.status = 'enabled';
    skill.updatedAt = new Date().toISOString();
    this.saveRegistry();
    this.logAudit('ENABLE', skillId, `Enabled skill '${skillId}'`);
    return skill;
  }

  public disableSkill(skillId: string): SkillMetadata {
    const skill = this.registry.get(skillId);
    if (!skill) throw new Error(`Skill '${skillId}' not found in registry.`);
    skill.status = 'disabled';
    skill.updatedAt = new Date().toISOString();
    this.saveRegistry();
    this.logAudit('DISABLE', skillId, `Disabled skill '${skillId}'`);
    return skill;
  }

  public removeSkill(skillId: string): boolean {
    const skill = this.registry.get(skillId);
    if (!skill) throw new Error(`Skill '${skillId}' not found.`);

    if (fs.existsSync(skill.skillPath)) {
      fs.rmSync(skill.skillPath, { recursive: true, force: true });
    }
    this.registry.delete(skillId);
    this.saveRegistry();
    this.logAudit('REMOVE', skillId, `Removed skill '${skillId}' and deleted all files.`);
    return true;
  }

  /**
   * Updates an existing skill with a new source folder or zip, computing a unified diff
   */
  public updateSkill(
    skillId: string,
    newQuarantineId: string,
    options?: { userApproved?: boolean; forceApproveHighRisk?: boolean }
  ): { meta: SkillMetadata; diff: string; scan: SkillScanResult } {
    const existing = this.registry.get(skillId);
    if (!existing) throw new Error(`Skill '${skillId}' not found for update.`);

    const qPath = path.join(QUARANTINE_DIR, newQuarantineId);
    if (!fs.existsSync(qPath)) {
      throw new Error(`Quarantine folder not found for update: ${newQuarantineId}`);
    }

    // Compute unified diff between existing and new version
    const diff = this.computeDirectoryDiff(existing.skillPath, qPath);

    // Rescan new version
    const scan = this.scanQuarantineSkill(newQuarantineId);

    // Human approval required for all updates
    if (!options?.userApproved) {
      throw new Error(
        `UPDATE APPROVAL REQUIRED: Updating skill '${skillId}' (v${existing.version} -> v${scan.version}, Content Hash: ${scan.contentHash.slice(0, 16)}...) requires explicit user approval.`
      );
    }

    if (scan.requiresStrictApproval && !options?.forceApproveHighRisk) {
      throw new Error(`HIGH RISK UPDATE BLOCKED: Updated skill contains high risk patterns. Requires explicit re-approval.`);
    }

    // Replace files
    fs.rmSync(existing.skillPath, { recursive: true, force: true });
    fs.mkdirSync(existing.skillPath, { recursive: true });
    this.copyDirectoryRecursively(qPath, existing.skillPath);
    try { fs.rmSync(qPath, { recursive: true, force: true }); } catch {}

    existing.version = scan.version;
    existing.description = scan.description;
    existing.tags = scan.tags;
    existing.binaries = scan.binaries;
    existing.riskLevel = scan.riskLevel;
    existing.contentHash = scan.contentHash;
    existing.findings = scan.findings;
    existing.dependencies = scan.dependencies;
    existing.updatedAt = new Date().toISOString();

    this.saveRegistry();
    this.logAudit('UPDATE', skillId, `Updated skill '${skillId}' to hash ${scan.contentHash.slice(0, 12)}...`, {
      diffLines: diff.split('\n').length,
    });

    return { meta: existing, diff, scan };
  }

  public getSkillUpdateDiff(skillId: string, newQuarantineId: string): { diff: string; scan: SkillScanResult } {
    const existing = this.registry.get(skillId);
    if (!existing) throw new Error(`Skill '${skillId}' not found.`);
    const qPath = path.join(QUARANTINE_DIR, newQuarantineId);
    if (!fs.existsSync(qPath)) throw new Error(`Quarantine folder not found: ${newQuarantineId}`);
    const diff = this.computeDirectoryDiff(existing.skillPath, qPath);
    const scan = this.scanQuarantineSkill(newQuarantineId);
    return { diff, scan };
  }

  public listSkills(): SkillMetadata[] {
    return Array.from(this.registry.values());
  }

  public getSkill(skillId: string): SkillMetadata | undefined {
    return this.registry.get(skillId);
  }

  // =========================================================================
  // 7. AUTO-SELECTION FOR AGENT
  // =========================================================================

  /**
   * Matches a user prompt to relevant ENABLED skills.
   * Disabled skills are NEVER selected.
   */
  public selectSkillsForTask(taskPrompt: string): Array<{
    skill: SkillMetadata;
    matchReason: string;
    confidence: number;
  }> {
    if (!taskPrompt || !taskPrompt.trim()) return [];

    const lowerPrompt = taskPrompt.toLowerCase();
    const enabledSkills = Array.from(this.registry.values()).filter((s) => s.status === 'enabled');
    const matches: Array<{ skill: SkillMetadata; matchReason: string; confidence: number }> = [];

    for (const skill of enabledSkills) {
      let score = 0;
      const reasons: string[] = [];

      // Name match
      const skillNameLower = skill.name.toLowerCase().replace(/[-_]/g, ' ');
      if (lowerPrompt.includes(skillNameLower) || lowerPrompt.includes(skill.name.toLowerCase())) {
        score += 5;
        reasons.push(`Prompt mentions skill name '${skill.name}'`);
      }

      // Keyword / tag matching
      if (skill.tags) {
        for (const tag of skill.tags) {
          if (lowerPrompt.includes(tag.toLowerCase())) {
            score += 2;
            reasons.push(`Matched tag '${tag}'`);
          }
        }
      }

      // Description token matching
      const descTokens = skill.description
        .toLowerCase()
        .replace(/[^a-z0-9\s]/g, ' ')
        .split(/\s+/)
        .filter((w) => w.length >= 4);

      let tokenMatches = 0;
      for (const tok of descTokens) {
        if (lowerPrompt.includes(tok)) {
          tokenMatches++;
        }
      }
      if (tokenMatches > 0) {
        score += Math.min(3, tokenMatches * 0.5);
        reasons.push(`Matched ${tokenMatches} descriptive terms in skill documentation`);
      }

      if (score >= 2) {
        matches.push({
          skill,
          matchReason: reasons.join('; '),
          confidence: Math.min(1.0, score / 10),
        });
      }
    }

    return matches.sort((a, b) => b.confidence - a.confidence);
  }

  // =========================================================================
  // 8. ISOLATED EXECUTION
  // =========================================================================

  /**
   * Runs a script inside a skill folder under appuser isolation and permission guard.
   * Enforces cross-skill containment: Skill A cannot read Skill B's folder!
   * State honestly: This is application-level and network namespace isolation (not full chroot/cgroups).
   */
  public executeSkillScript(
    skillId: string,
    scriptRelPath: string,
    args: string[] = [],
    workspaceRoot: string,
    options?: { allowNetwork?: boolean; userApprovedNetwork?: boolean }
  ): {
    exitCode: number;
    stdout: string;
    stderr: string;
  } {
    const skill = this.registry.get(skillId);
    if (!skill) throw new Error(`Skill '${skillId}' not found.`);
    if (skill.status !== 'enabled') {
      throw new Error(`Skill '${skillId}' is currently ${skill.status}. Only enabled skills can execute scripts.`);
    }

    const scriptFullPath = path.resolve(skill.skillPath, scriptRelPath);

    // Cross-skill isolation check: Script must reside inside this skill's folder
    if (!scriptFullPath.startsWith(skill.skillPath)) {
      throw new Error(`SECURITY VIOLATION: Skill script path '${scriptRelPath}' escapes skill folder '${skill.name}'.`);
    }

    if (!fs.existsSync(scriptFullPath)) {
      throw new Error(`Script not found: ${scriptRelPath} in skill ${skillId}`);
    }

    // Inspect script file for evasion before execution
    const inspection = agentPermissionGuard.inspectCommand(`python3 ${scriptFullPath}`, workspaceRoot);
    if (inspection.isBlocked) {
      throw new Error(`BLOCKED BY GUARD: ${inspection.reason}`);
    }

    // Cross-skill isolation check: Script cannot access other installed skills
    const scriptContent = fs.readFileSync(scriptFullPath, 'utf8');
    const otherSkillIds = Array.from(this.registry.keys()).filter((id) => id !== skillId);
    for (const otherId of otherSkillIds) {
      if (
        scriptContent.includes(otherId) &&
        (scriptContent.includes('installed') || scriptContent.includes('..') || scriptContent.includes('data/agent_skills') || scriptContent.includes('/data/'))
      ) {
        throw new Error(
          `CROSS-SKILL ISOLATION VIOLATION: Access to other skill folder ('${otherId}') is strictly prohibited.`
        );
      }
    }

    // Network isolation policy:
    // By default, network is completely blocked via kernel namespace (unshare -n).
    // If a legitimate skill needs internet access, it MUST request allowNetwork: true,
    // which strictly requires explicit user approval.
    if (options?.allowNetwork && !options?.userApprovedNetwork) {
      throw new Error(
        `STRICT APPROVAL REQUIRED: Skill '${skill.name}' requested outbound network access. An explicit human approval switch is required.`
      );
    }

    // Scrubbed environment
    const scrubbedEnv = {
      PATH: process.env.PATH || '/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin',
      HOME: '/home/appuser',
      LANG: 'en_US.UTF-8',
      USER: 'appuser',
      SKILL_DIR: skill.skillPath,
      WORKSPACE_DIR: workspaceRoot,
    };

    // Determine runner binary based on script extension
    const isJs = scriptFullPath.endsWith('.js') || scriptFullPath.endsWith('.mjs') || scriptFullPath.endsWith('.cjs');
    const runnerBin = isJs ? 'node' : 'python3';

    // Execute under unshare and appuser (UID 1000)
    // If allowNetwork is explicitly approved, omit '-n'
    const cmdArgs = options?.allowNetwork && options?.userApprovedNetwork
      ? ['-S', '1000', '-G', '1000', runnerBin, scriptFullPath, ...args]
      : ['-n', '-S', '1000', '-G', '1000', runnerBin, scriptFullPath, ...args];

    const proc = spawnSync('unshare', cmdArgs, {
      cwd: skill.skillPath,
      env: scrubbedEnv,
      timeout: 15000,
    });

    const stdout = maskSecrets((proc.stdout || '').toString('utf8'));
    const stderr = maskSecrets((proc.stderr || '').toString('utf8'));

    this.logAudit('RUN_SCRIPT', skillId, `Executed script ${scriptRelPath}`, {
      exitCode: proc.status,
      stdoutSnippet: stdout.slice(0, 100),
    });

    return {
      exitCode: proc.status ?? 1,
      stdout,
      stderr,
    };
  }

  // =========================================================================
  // HELPER UTILITIES
  // =========================================================================

  private copyDirectoryRecursively(src: string, dest: string): void {
    if (!fs.existsSync(dest)) fs.mkdirSync(dest, { recursive: true });
    const items = fs.readdirSync(src, { withFileTypes: true });
    for (const item of items) {
      const srcPath = path.join(src, item.name);
      const destPath = path.join(dest, item.name);
      if (item.isDirectory()) {
        this.copyDirectoryRecursively(srcPath, destPath);
      } else if (item.isFile()) {
        fs.copyFileSync(srcPath, destPath);
      }
    }
  }

  private computeDirectoryDiff(oldDir: string, newDir: string): string {
    const diffProc = spawnSync('diff', ['-u', '-r', oldDir, newDir]);
    const raw = (diffProc.stdout || '').toString('utf8');
    return raw || '(No differences detected)';
  }
}

export const skillsEngine = SkillsEngine.getInstance();
