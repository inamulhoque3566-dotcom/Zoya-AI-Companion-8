/**
 * Client-safe Secret Masking Engine
 * Redacts API keys, tokens, and credentials from any text without Node.js dependencies.
 */
export function maskSecrets(input: string): string {
  if (!input || typeof input !== 'string') return input;

  let masked = input;

  // 1. Private Key Blocks (RSA, OPENSSH, EC, DSA, PGP, etc.)
  masked = masked.replace(/-----BEGIN[ A-Z0-9_-]*PRIVATE KEY-----[\s\S]*?-----END[ A-Z0-9_-]*PRIVATE KEY-----/g, '[REDACTED_PRIVATE_KEY_BLOCK]');

  // 2. Gemini / Google AI Studio Keys (AQ.Ab8RN6...)
  masked = masked.replace(/\bAQ\.[A-Za-z0-9_-]{20,}\b/g, '[REDACTED_GEMINI_KEY]');

  // 3. Google Cloud / Maps API Keys (AIzaSy...)
  masked = masked.replace(/\bAIza[0-9A-Za-z-_]{30,40}\b/g, '[REDACTED_GOOGLE_API_KEY]');

  // 4. Anthropic Keys (sk-ant-...)
  masked = masked.replace(/\bsk-ant-[A-Za-z0-9_-]{20,}\b/g, '[REDACTED_ANTHROPIC_KEY]');

  // 5. OpenAI / General LLM Keys (sk-...)
  masked = masked.replace(/\bsk-[A-Za-z0-9_-]{24,}\b/g, '[REDACTED_OPENAI_KEY]');

  // 6. GitHub Tokens (ghp_, github_pat_, gho_, ghu_, ghs_, ghr_)
  masked = masked.replace(/\bghp_[A-Za-z0-9]{30,}\b/g, '[REDACTED_GITHUB_TOKEN]');
  masked = masked.replace(/\bgithub_pat_[A-Za-z0-9_]{40,}\b/g, '[REDACTED_GITHUB_TOKEN]');
  masked = masked.replace(/\b(gho|ghu|ghs|ghr)_[A-Za-z0-9]{30,}\b/g, '[REDACTED_GITHUB_TOKEN]');

  // 7. AWS Keys (AKIA, ASIA, AROA, AIDA)
  masked = masked.replace(/\b(AKIA|ASIA|AROA|AIDA)[0-9A-Z]{16}\b/g, '[REDACTED_AWS_KEY]');

  // 8. Bearer Tokens (any occurrences: "Bearer <token>")
  masked = masked.replace(/\bBearer\s+[A-Za-z0-9_\-\.]{10,}\b/gi, 'Bearer [REDACTED_BEARER_TOKEN]');

  // 9a. Zoya Agent Auth Tokens (zoya_agent_sec_...)
  masked = masked.replace(/\bzoya_agent_sec_[A-Za-z0-9_]{16,}\b/g, '[REDACTED_AGENT_AUTH_TOKEN]');

  // 9b. Zoya User Approval Secret (zoya_user_approver_sec_...)
  masked = masked.replace(/\bzoya_user_approver_sec_[A-Za-z0-9_]{16,}\b/g, '[REDACTED_USER_APPROVAL_TOKEN]');

  // 9c. ElevenLabs API Keys (context-based: sk_<hex> or xi-api-key header/field; avoids redacting UUIDs/MD5s)
  masked = masked.replace(/\bsk_[0-9a-fA-F]{32,}\b/g, '[REDACTED_ELEVENLABS_KEY]');
  masked = masked.replace(/(xi-api-key["'\s:=]+)[0-9a-fA-F]{32,}/gi, '$1[REDACTED_ELEVENLABS_KEY]');

  // 9d. Slack Incoming Webhooks
  masked = masked.replace(/https:\/\/hooks\.slack\.com\/services\/T[A-Za-z0-9_]+\/B[A-Za-z0-9_]+\/[A-Za-z0-9_]+/g, '[REDACTED_SLACK_WEBHOOK]');

  // 10. Dynamic masking of environment variables if running in node context
  if (typeof process !== 'undefined' && process.env) {
    try {
      for (const [k, v] of Object.entries(process.env)) {
        if (!v || typeof v !== 'string' || v.length < 5) continue;
        if (/(?:KEY|TOKEN|SECRET|PASSWORD)/i.test(k)) {
          if (v === 'true' || v === 'false' || v === 'null' || v === 'undefined') continue;
          if (masked.includes(v)) {
            masked = masked.split(v).join(`[REDACTED_ENV_${k.toUpperCase()}]`);
          }
        }
      }
    } catch {}
  }

  return masked;
}
