import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import type { Request, Response, NextFunction } from 'express';

const SECURE_DIR = '/root/.zoya';
const FALLBACK_DIR = path.join(process.cwd(), 'data', '.secure');
const SECURE_BASE = fs.existsSync('/root') ? SECURE_DIR : FALLBACK_DIR;
const AUTH_FILE = path.join(SECURE_BASE, 'agent_auth_token.json');
const USER_SECRET_FILE = path.join(SECURE_BASE, 'agent_user_secret.json');

// Clean up any legacy exposed token files in public data directory
try {
  const legacyAuth = path.join(process.cwd(), 'data', 'agent_auth_token.json');
  const legacySec = path.join(process.cwd(), 'data', 'agent_user_secret.json');
  if (fs.existsSync(legacyAuth)) fs.unlinkSync(legacyAuth);
  if (fs.existsSync(legacySec)) fs.unlinkSync(legacySec);
} catch {}

const OWNER_PASSPHRASE_FILE = path.join(SECURE_BASE, 'owner_passphrase.json');
const SETUP_CODE_FILE = path.join(SECURE_BASE, 'owner_setup_code.json');

const h = (s: string) => crypto.createHash('sha256').update(s).digest();
export const safeEqual = (a: string, b: string): boolean => {
  if (!a || !b) return false;
  return crypto.timingSafeEqual(h(a), h(b));
};

export function parseCookies(header?: string): Record<string, string> {
  const res: Record<string, string> = {};
  if (!header) return res;
  for (const part of header.split(';')) {
    const idx = part.indexOf('=');
    if (idx !== -1) {
      const k = part.substring(0, idx).trim();
      const v = part.substring(idx + 1).trim();
      res[k] = decodeURIComponent(v);
    }
  }
  return res;
}

export class AgentAuthManager {
  private static token: string | null = null;
  private static userApprovalSecret: string | null = null;
  private static userApprovalSecretHash: string | null = null;
  private static approvalSessions = new Map<string, { expiresAt: number }>();
  private static pairedSessions = new Map<string, { expiresAt: number }>();
  private static failedAttempts = { count: 0, lockedUntil: 0, windowStart: Date.now() };
  private static resetLimitAttempts = new Map<string, { count: number; lockedUntil: number; windowStart: number }>();
  private static globalResetAttempts = { count: 0, lockedUntil: 0, windowStart: Date.now() };
  private static pairingConsumeRateLimits = new Map<string, { count: number; windowStart: number }>();
  private static pairingIssueRateLimits = new Map<string, { count: number; windowStart: number }>();
  private static globalPairingConsume = { count: 0, windowStart: Date.now() };
  private static globalPairingIssue = { count: 0, windowStart: Date.now() };
  private static inMemorySetupCode: string | null = null;

  // Reset rate limiting (requires verified setup code)
  public static resetRateLimit(): void {
    this.failedAttempts = { count: 0, lockedUntil: 0, windowStart: Date.now() };
  }

  public static clearResetLimitForIp(ip: string): void {
    this.resetLimitAttempts.delete(ip || 'unknown');
  }

  public static clearAllResetLimits(): void {
    this.resetLimitAttempts.clear();
    this.globalResetAttempts = { count: 0, lockedUntil: 0, windowStart: Date.now() };
  }

  public static clearPairingRateLimits(): void {
    this.pairingConsumeRateLimits.clear();
    this.pairingIssueRateLimits.clear();
    this.globalPairingConsume = { count: 0, windowStart: Date.now() };
    this.globalPairingIssue = { count: 0, windowStart: Date.now() };
  }

  public static checkAndTrackResetLimit(
    socketIp: string,
    setupCode?: string
  ): { allowed: boolean; status: number; error?: string; waitSeconds?: number } {
    const key = (socketIp || 'unknown').trim() || 'unknown';
    const now = Date.now();
    const WINDOW_MS = 15 * 60 * 1000;
    const MAX_PER_IP_ATTEMPTS = 5;
    const GLOBAL_MAX_ATTEMPTS = 20;

    // 1. Check global sliding window (prevents distributed brute-force / spoofed multi-IP flooding)
    if (now - this.globalResetAttempts.windowStart > WINDOW_MS) {
      this.globalResetAttempts = { count: 0, lockedUntil: 0, windowStart: now };
    }
    if (
      (this.globalResetAttempts.lockedUntil && now < this.globalResetAttempts.lockedUntil) ||
      this.globalResetAttempts.count >= GLOBAL_MAX_ATTEMPTS
    ) {
      const lockedUntil = this.globalResetAttempts.lockedUntil || this.globalResetAttempts.windowStart + WINDOW_MS;
      const waitSeconds = Math.max(1, Math.ceil((lockedUntil - now) / 1000));
      return {
        allowed: false,
        status: 429,
        error: `Global reset-limit threshold exceeded. Retry in ${waitSeconds}s.`,
        waitSeconds,
      };
    }

    // 2. Check per-socket-IP sliding window (never reads X-Forwarded-For, isolated per peer IP)
    let record = this.resetLimitAttempts.get(key);
    if (!record || now - record.windowStart > WINDOW_MS) {
      record = { count: 0, lockedUntil: 0, windowStart: now };
      this.resetLimitAttempts.set(key, record);
    }

    if (record.lockedUntil && now < record.lockedUntil) {
      const waitSeconds = Math.max(1, Math.ceil((record.lockedUntil - now) / 1000));
      return {
        allowed: false,
        status: 429,
        error: `Too many reset attempts from this IP. Retry in ${waitSeconds}s.`,
        waitSeconds,
      };
    }

    if (record.count >= MAX_PER_IP_ATTEMPTS) {
      record.lockedUntil = now + WINDOW_MS;
      const waitSeconds = Math.ceil(WINDOW_MS / 1000);
      return {
        allowed: false,
        status: 429,
        error: `Maximum reset attempts (${MAX_PER_IP_ATTEMPTS}) exceeded for 15 minutes.`,
        waitSeconds,
      };
    }

    if (this.verifySetupCodeForReset(setupCode)) {
      this.resetLimitAttempts.delete(key);
      this.resetRateLimit();
      return { allowed: true, status: 200 };
    }

    // Failed setup code verification: increment both per-IP and global counters
    record.count += 1;
    this.globalResetAttempts.count += 1;
    if (this.globalResetAttempts.count >= GLOBAL_MAX_ATTEMPTS) {
      this.globalResetAttempts.lockedUntil = now + WINDOW_MS;
    }

    const backoffMs = Math.min(WINDOW_MS, 2000 * Math.pow(2, record.count - 1));
    record.lockedUntil = record.count >= MAX_PER_IP_ATTEMPTS ? now + WINDOW_MS : now + backoffMs;
    const waitSeconds = Math.ceil((record.lockedUntil - now) / 1000);

    return {
      allowed: false,
      status: record.count >= MAX_PER_IP_ATTEMPTS || this.globalResetAttempts.count >= GLOBAL_MAX_ATTEMPTS ? 429 : 401,
      error:
        record.count >= MAX_PER_IP_ATTEMPTS
          ? `Too many failed setup code attempts. Locked out for ${waitSeconds}s.`
          : `Invalid setup code. Backoff active for ${waitSeconds}s (attempt ${record.count}/${MAX_PER_IP_ATTEMPTS}).`,
      waitSeconds,
    };
  }

  public static checkPairingEndpointRateLimit(
    socketIp: string,
    bucket: 'pair_consume' | 'pair_issue'
  ): { allowed: boolean; waitSeconds?: number; error?: string } {
    const key = (socketIp || 'unknown').trim() || 'unknown';
    const now = Date.now();
    const WINDOW_MS = 15 * 60 * 1000;
    const MAX_PER_IP = 10;
    const MAX_GLOBAL = 40;

    const ipMap = bucket === 'pair_consume' ? this.pairingConsumeRateLimits : this.pairingIssueRateLimits;
    let globalCounter = bucket === 'pair_consume' ? this.globalPairingConsume : this.globalPairingIssue;

    if (now - globalCounter.windowStart > WINDOW_MS) {
      globalCounter = { count: 0, windowStart: now };
      if (bucket === 'pair_consume') {
        this.globalPairingConsume = globalCounter;
      } else {
        this.globalPairingIssue = globalCounter;
      }
    }

    if (globalCounter.count >= MAX_GLOBAL) {
      const waitSeconds = Math.max(1, Math.ceil((globalCounter.windowStart + WINDOW_MS - now) / 1000));
      return {
        allowed: false,
        waitSeconds,
        error: `Too many global pairing requests. Retry in ${waitSeconds}s.`,
      };
    }

    let ipRec = ipMap.get(key);
    if (!ipRec || now - ipRec.windowStart > WINDOW_MS) {
      ipRec = { count: 0, windowStart: now };
      ipMap.set(key, ipRec);
    }

    if (ipRec.count >= MAX_PER_IP) {
      const waitSeconds = Math.max(1, Math.ceil((ipRec.windowStart + WINDOW_MS - now) / 1000));
      return {
        allowed: false,
        waitSeconds,
        error: `Too many pairing requests from this IP. Retry in ${waitSeconds}s.`,
      };
    }

    ipRec.count += 1;
    globalCounter.count += 1;
    return { allowed: true };
  }

  public static isOwnerPassphraseConfigured(): boolean {
    return fs.existsSync(OWNER_PASSPHRASE_FILE);
  }

  /**
   * One-time setup code printed ONLY in server console/logs.
   * Required to configure owner passphrase for the first time, preventing
   * any caller over the public URL from claiming initial ownership.
   */
  public static getOrCreateSetupCode(): string {
    if (this.inMemorySetupCode) return this.inMemorySetupCode;

    if (process.env.ZOYA_SETUP_CODE && process.env.ZOYA_SETUP_CODE.trim()) {
      this.inMemorySetupCode = process.env.ZOYA_SETUP_CODE.trim();
      return this.inMemorySetupCode;
    }

    try {
      if (fs.existsSync(SETUP_CODE_FILE)) {
        const raw = fs.readFileSync(SETUP_CODE_FILE, 'utf8');
        const parsed = JSON.parse(raw);
        if (parsed.setupCode && typeof parsed.setupCode === 'string') {
          this.inMemorySetupCode = parsed.setupCode;
          return parsed.setupCode;
        }
      }
    } catch {}

    const generated = `zoya_setup_${crypto.randomBytes(16).toString('hex')}`;
    this.inMemorySetupCode = generated;

    try {
      const dir = path.dirname(SETUP_CODE_FILE);
      if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
      fs.writeFileSync(
        SETUP_CODE_FILE,
        JSON.stringify(
          {
            setupCode: generated,
            createdAt: new Date().toISOString(),
            description: 'One-time server setup code required to configure initial owner passphrase',
          },
          null,
          2
        ),
        { encoding: 'utf8', mode: 0o600 }
      );
      try { fs.chmodSync(SETUP_CODE_FILE, 0o600); } catch {}
    } catch {}

    console.log('\n========================================================================');
    console.log('🔑 [ZOYA_SECURITY] ONE-TIME OWNER SETUP CODE:');
    console.log(`   ${generated}`);
    console.log('   Required to set initial owner passphrase. Attackers over public URL cannot claim ownership.');
    console.log('========================================================================\n');

    return generated;
  }

  public static setOwnerPassphrase(passphrase: string): { success: boolean; error?: string } {
    return this.setOwnerPassphraseWithSetupCode(passphrase);
  }

  public static setOwnerPassphraseWithSetupCode(
    passphrase: string,
    setupCode?: string,
    currentPassphrase?: string
  ): { success: boolean; error?: string } {
    if (!passphrase || typeof passphrase !== 'string' || passphrase.length < 8) {
      return { success: false, error: 'Passphrase must be at least 8 characters long.' };
    }

    const alreadyConfigured = this.isOwnerPassphraseConfigured();

    if (!alreadyConfigured) {
      // FIRST-TIME CONFIGURATION: Strictly requires valid one-time setup code
      const activeSetupCode = this.getOrCreateSetupCode();
      if (!setupCode || typeof setupCode !== 'string') {
        return {
          success: false,
          error: 'Setup code required. Check server console logs or ZOYA_SETUP_CODE env variable to claim ownership.',
        };
      }

      // Constant-time comparison via SHA-256 digest (prevents length leakage)
      const cleanSetup = setupCode.trim();
      if (!safeEqual(cleanSetup, activeSetupCode)) {
        return {
          success: false,
          error: 'Invalid setup code. Passphrase rejected.',
        };
      }

      // Valid: Consume setup code
      try {
        if (fs.existsSync(SETUP_CODE_FILE)) fs.unlinkSync(SETUP_CODE_FILE);
      } catch {}
      this.inMemorySetupCode = null;
      console.log('[ZOYA_SECURITY] Initial owner passphrase successfully configured and setup code consumed.');
    } else {
      // RECONFIGURATION: Requires existing owner passphrase
      if (!currentPassphrase) {
        return { success: false, error: 'Current owner passphrase required to change passphrase.' };
      }
      const verified = this.verifyOwnerPassphrase(currentPassphrase);
      if (!verified.success) {
        return { success: false, error: verified.error || 'Invalid current owner passphrase.' };
      }
    }

    const salt = crypto.randomBytes(32).toString('hex');
    const hash = crypto.scryptSync(passphrase, salt, 64).toString('hex');
    const dir = path.dirname(OWNER_PASSPHRASE_FILE);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
    fs.writeFileSync(
      OWNER_PASSPHRASE_FILE,
      JSON.stringify({ salt, hash, createdAt: new Date().toISOString() }, null, 2),
      { encoding: 'utf8', mode: 0o600 }
    );
    try { fs.chmodSync(OWNER_PASSPHRASE_FILE, 0o600); } catch {}
    this.failedAttempts = { count: 0, lockedUntil: 0, windowStart: Date.now() };
    return { success: true };
  }

  public static verifyOwnerPassphrase(passphrase: string): {
    success: boolean;
    error?: string;
    rateLimited?: boolean;
    waitSeconds?: number;
  } {
    const now = Date.now();
    // Rate limit check
    if (this.failedAttempts.lockedUntil && now < this.failedAttempts.lockedUntil) {
      const waitSeconds = Math.ceil((this.failedAttempts.lockedUntil - now) / 1000);
      return {
        success: false,
        error: `Too many failed passphrase attempts. Locked out for ${waitSeconds} seconds.`,
        rateLimited: true,
        waitSeconds,
      };
    }
    if (now - this.failedAttempts.windowStart > 15 * 60 * 1000) {
      this.failedAttempts.count = 0;
      this.failedAttempts.windowStart = now;
      this.failedAttempts.lockedUntil = 0;
    }

    if (!fs.existsSync(OWNER_PASSPHRASE_FILE)) {
      // If env var explicitly provided, initialize automatically
      if (process.env.ZOYA_OWNER_PASSPHRASE && process.env.ZOYA_OWNER_PASSPHRASE.trim()) {
        const envPass = process.env.ZOYA_OWNER_PASSPHRASE.trim();
        const setup = this.getOrCreateSetupCode();
        this.setOwnerPassphraseWithSetupCode(envPass, setup);
      } else {
        return { success: false, error: 'Owner passphrase not configured yet. Run setup with console setup code.' };
      }
    }

    try {
      const raw = fs.readFileSync(OWNER_PASSPHRASE_FILE, 'utf8');
      const data = JSON.parse(raw);
      if (!data.salt || !data.hash) {
        return { success: false, error: 'Corrupt owner passphrase store.' };
      }
      const derived = crypto.scryptSync(passphrase || '', data.salt, 64).toString('hex');
      const bufA = Buffer.from(derived, 'hex');
      const bufB = Buffer.from(data.hash, 'hex');
      if (bufA.length === bufB.length && crypto.timingSafeEqual(bufA, bufB)) {
        // Success: clear rate limiter
        this.failedAttempts.count = 0;
        this.failedAttempts.lockedUntil = 0;
        return { success: true };
      }
    } catch (e: any) {
      return { success: false, error: `Authentication error: ${e.message}` };
    }

    // Failed attempt
    this.failedAttempts.count++;
    if (this.failedAttempts.count >= 5) {
      this.failedAttempts.lockedUntil = Date.now() + 15 * 60 * 1000;
      return {
        success: false,
        error: 'Too many failed passphrase attempts. Locked out for 15 minutes.',
        rateLimited: true,
        waitSeconds: 15 * 60,
      };
    }

    return {
      success: false,
      error: `Invalid owner passphrase. (Attempt ${this.failedAttempts.count}/5 before lockout)`,
    };
  }

  public static createApprovalSession(): string {
    const sessionToken = `zoya_sess_${crypto.randomBytes(32).toString('hex')}`;
    this.approvalSessions.set(sessionToken, { expiresAt: Date.now() + 3600 * 1000 });
    return sessionToken;
  }

  public static validateApprovalSession(token: string | undefined): boolean {
    if (!token) return false;
    const sess = this.approvalSessions.get(token);
    if (!sess) return false;
    if (Date.now() > sess.expiresAt) {
      this.approvalSessions.delete(token);
      return false;
    }
    return true;
  }

  public static createPairedSession(ttlMs: number = 3600 * 1000): string {
    const sessionToken = `zoya_paired_${crypto.randomBytes(32).toString('hex')}`;
    this.pairedSessions.set(sessionToken, { expiresAt: Date.now() + ttlMs });
    return sessionToken;
  }

  public static validatePairedSession(token: string | undefined): boolean {
    if (!token) return false;
    const sess = this.pairedSessions.get(token);
    if (!sess) return false;
    if (Date.now() > sess.expiresAt) {
      this.pairedSessions.delete(token);
      return false;
    }
    return true;
  }

  public static validateOwnerSessionFromRequest(req: Request): boolean {
    const cookies = parseCookies(req.headers['cookie']);
    const approvalTok =
      cookies['zoya_approval_session'] ||
      (typeof req.headers['x-approval-session'] === 'string' ? req.headers['x-approval-session'].trim() : undefined);
    if (approvalTok && this.validateApprovalSession(approvalTok)) {
      return true;
    }
    const pairedTok =
      cookies['zoya_agent_paired_session'] ||
      (typeof req.headers['x-agent-paired-session'] === 'string' ? req.headers['x-agent-paired-session'].trim() : undefined);
    if (pairedTok && this.validatePairedSession(pairedTok)) {
      return true;
    }
    return false;
  }

  public static getOrCreateToken(): string {
    if (this.token) return this.token;

    // 1. Environment variable priority
    if (process.env.AGENT_AUTH_TOKEN && process.env.AGENT_AUTH_TOKEN.trim()) {
      const envTok = process.env.AGENT_AUTH_TOKEN.trim();
      this.token = envTok;
      return envTok;
    }

    // 2. Read from secure persistent file and enforce strict 0o700/0o600 permissions
    try {
      const dir = path.dirname(AUTH_FILE);
      if (fs.existsSync(dir)) {
        try { fs.chmodSync(dir, 0o700); } catch {}
      }
      if (fs.existsSync(AUTH_FILE)) {
        try { fs.chmodSync(AUTH_FILE, 0o600); } catch {}
        const raw = fs.readFileSync(AUTH_FILE, 'utf8');
        const parsed = JSON.parse(raw);
        if (parsed.token && typeof parsed.token === 'string' && parsed.token.length >= 16) {
          const fileTok: string = parsed.token;
          this.token = fileTok;
          return fileTok;
        }
      }
    } catch {
      // file read error, regenerate below
    }

    // 3. Generate secure random 256-bit token
    const generated = `zoya_agent_sec_${crypto.randomBytes(24).toString('hex')}`;
    this.token = generated;

    try {
      const dir = path.dirname(AUTH_FILE);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
      }
      try { fs.chmodSync(dir, 0o700); } catch {}
      fs.writeFileSync(
        AUTH_FILE,
        JSON.stringify(
          {
            token: generated,
            createdAt: new Date().toISOString(),
            description: 'Authentication token for Zoya Coding Agent API endpoints',
          },
          null,
          2
        ),
        { encoding: 'utf8', mode: 0o600 }
      );
      try { fs.chmodSync(AUTH_FILE, 0o600); } catch {}
      console.log('[AGENT_AUTH] Initialized new persistent Agent Auth Token in secure storage.');
    } catch (e) {
      console.warn('[AGENT_AUTH] Warning: Could not persist auth token file:', e);
    }

    return generated;
  }

  public static rotateToken(): string {
    const generated = `zoya_agent_sec_${crypto.randomBytes(24).toString('hex')}`;
    this.token = generated;

    try {
      const dir = path.dirname(AUTH_FILE);
      if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
      fs.writeFileSync(
        AUTH_FILE,
        JSON.stringify(
          {
            token: generated,
            rotatedAt: new Date().toISOString(),
            description: 'Authentication token for Zoya Coding Agent API endpoints',
          },
          null,
          2
        ),
        { encoding: 'utf8', mode: 0o600 }
      );
      try { fs.chmodSync(AUTH_FILE, 0o600); } catch {}
      console.log('[AGENT_AUTH] Rotated persistent Agent Auth Token.');
    } catch (e) {
      console.warn('[AGENT_AUTH] Warning: Could not persist rotated auth token file:', e);
    }

    return generated;
  }

  public static getCachedAgentToken(): string | null {
    if (this.token) return this.token;
    return this.getOrCreateToken();
  }

  public static verifySetupCodeForReset(setupCode: string | undefined): boolean {
    if (!setupCode || typeof setupCode !== 'string') return false;
    const active = this.getOrCreateSetupCode();
    return safeEqual(setupCode.trim(), active);
  }

  /**
   * Dedicated separate credential for human user approvals.
   * Agent loop and subprocesses NEVER have access to this token.
   * Stored in mode 0600 file outside agent workspace and validated via SHA-256 hash.
   */
  public static getUserApprovalSecret(): string {
    if (this.userApprovalSecret) return this.userApprovalSecret;

    if (process.env.ZOYA_USER_APPROVAL_SECRET && process.env.ZOYA_USER_APPROVAL_SECRET.trim()) {
      const envSec = process.env.ZOYA_USER_APPROVAL_SECRET.trim();
      this.userApprovalSecret = envSec;
      this.userApprovalSecretHash = crypto.createHash('sha256').update(envSec).digest('hex');
      return envSec;
    }

    try {
      if (fs.existsSync(USER_SECRET_FILE)) {
        const raw = fs.readFileSync(USER_SECRET_FILE, 'utf8');
        const parsed = JSON.parse(raw);
        if (parsed.secret && typeof parsed.secret === 'string' && parsed.secret.length >= 16) {
          this.userApprovalSecret = parsed.secret;
          this.userApprovalSecretHash = crypto.createHash('sha256').update(parsed.secret).digest('hex');
          return parsed.secret;
        }
      }
    } catch {}

    const generated = `zoya_user_approver_sec_${crypto.randomBytes(24).toString('hex')}`;
    this.userApprovalSecret = generated;
    this.userApprovalSecretHash = crypto.createHash('sha256').update(generated).digest('hex');

    try {
      const dir = path.dirname(USER_SECRET_FILE);
      if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
      fs.writeFileSync(
        USER_SECRET_FILE,
        JSON.stringify(
          {
            secret: generated,
            createdAt: new Date().toISOString(),
            description: 'User-only authorization secret for approving/denying privileged agent actions',
          },
          null,
          2
        ),
        { encoding: 'utf8', mode: 0o600 }
      );
      try { fs.chmodSync(USER_SECRET_FILE, 0o600); } catch {}
      console.log('[AGENT_AUTH] Initialized new persistent User Approval Secret in secure storage.');
    } catch (e) {
      console.warn('[AGENT_AUTH] Warning: Could not persist user approval secret:', e);
    }

    return generated;
  }

  public static validateToken(provided: string | undefined): boolean {
    if (!provided) return false;
    const cleanProvided = provided.replace(/^Bearer\s+/i, '').trim();
    if (!cleanProvided) return false;

    let active = this.getOrCreateToken();
    if (cleanProvided !== active && fs.existsSync(AUTH_FILE)) {
      try {
        const raw = fs.readFileSync(AUTH_FILE, 'utf8');
        const parsed = JSON.parse(raw);
        if (parsed.token) {
          this.token = parsed.token;
          active = parsed.token;
        }
      } catch {}
    }

    if (!active) return false;

    // Constant-time comparison via SHA-256 digest (prevents length leakage)
    try {
      return safeEqual(cleanProvided, active);
    } catch {
      return false;
    }
  }

  public static validateUserApprovalSecret(provided: string | undefined): boolean {
    if (!provided) return false;
    const cleanProvided = provided.replace(/^Bearer\s+/i, '').trim();
    if (!cleanProvided) return false;

    // Ensure secret hash is loaded
    if (!this.userApprovalSecretHash) {
      this.getUserApprovalSecret();
    }
    if (!this.userApprovalSecretHash) return false;

    // Reject if caller passed the agent token (prevent self-approval!)
    if (this.validateToken(provided)) {
      return false;
    }

    // Verify using cryptographic SHA-256 hash in constant-time (fixed 32-byte digest)
    try {
      const providedDigest = crypto.createHash('sha256').update(cleanProvided).digest();
      const expectedDigest = Buffer.from(this.userApprovalSecretHash, 'hex');
      if (providedDigest.length !== expectedDigest.length) return false;
      return crypto.timingSafeEqual(providedDigest, expectedDigest);
    } catch {
      return false;
    }
  }

  /**
   * One-time pairing codes for remote UI bootstrap when behind a Cloud reverse proxy.
   * STRICT SECURITY: Requires owner passphrase. Spoofing User-Agent or requesting without passphrase is prohibited.
   */
  private static pairingCodes = new Map<string, { expiresAt: number }>();

  public static generatePairingCodeWithPassphrase(passphrase: string): {
    success: boolean;
    pairingCode?: string;
    error?: string;
    rateLimited?: boolean;
    waitSeconds?: number;
  } {
    const verified = this.verifyOwnerPassphrase(passphrase);
    if (!verified.success) {
      return {
        success: false,
        error: verified.error || 'Invalid owner passphrase',
        rateLimited: verified.rateLimited,
        waitSeconds: verified.waitSeconds,
      };
    }
    const code = this.generatePairingCode();
    return { success: true, pairingCode: code };
  }

  public static generatePairingCode(ttlMs: number = 5 * 60 * 1000): string {
    const code = crypto.randomBytes(16).toString('hex');
    this.pairingCodes.set(code, { expiresAt: Date.now() + ttlMs });
    return code;
  }

  public static hasActivePairingCodes(): boolean {
    const now = Date.now();
    for (const [k, v] of this.pairingCodes.entries()) {
      if (now > v.expiresAt) {
        this.pairingCodes.delete(k);
      }
    }
    return this.pairingCodes.size > 0;
  }

  public static consumePairingCode(code: string): boolean {
    if (!code) return false;
    const now = Date.now();
    let matchedKey: string | null = null;
    for (const [candidate, meta] of this.pairingCodes.entries()) {
      if (now > meta.expiresAt) {
        this.pairingCodes.delete(candidate);
        continue;
      }
      if (safeEqual(code, candidate)) {
        matchedKey = candidate;
      }
    }
    if (!matchedKey) return false;
    const entry = this.pairingCodes.get(matchedKey);
    this.pairingCodes.delete(matchedKey); // Single-use: always delete after use
    return !!entry && now <= entry.expiresAt;
  }

  /**
   * Origin & Socket validation for token bootstrap endpoint (/api/agent/auth/token).
   * Strictly requires a valid single-use pairing code via x-agent-pairing-code header.
   */
  public static isLocalOrTrustedOrigin(req: Request): boolean {
    const pairingHeader = (req.headers['x-agent-pairing-code'] as string | undefined)?.trim();
    if (!pairingHeader) {
      return false;
    }
    return this.consumePairingCode(pairingHeader);
  }

  /**
   * Enforces dedicated user approval credential on /api/agent/approvals/:id/respond.
   * Explicitly detects and blocks agent self-approval attempts.
   * Includes CSRF protection (rejects cross-site/cross-origin approval attempts).
   * Requires either:
   * 1. Short-lived HttpOnly session cookie (zoya_approval_session)
   * 2. Direct dedicated user approval secret token (x-user-approval-token) for headless automation
   */
  public static requireUserApprovalMiddleware(req: Request, res: Response, next: NextFunction): void {
    // 0. CSRF Protection for approval responses
    const origin = req.headers['origin'] as string | undefined;
    const secFetchSite = req.headers['sec-fetch-site'] as string | undefined;
    const host = req.headers['host'] as string | undefined;

    if (secFetchSite === 'cross-site') {
      res.status(403).json({
        success: false,
        error: 'CSRF VIOLATION: Cross-site approval requests are forbidden.',
        code: 'CSRF_VIOLATION',
      });
      return;
    }

    if (origin) {
      try {
        const originUrl = new URL(origin);
        const expectedHost = host?.split(':')[0].toLowerCase();
        const originHost = originUrl.hostname.toLowerCase();
        const isMatch =
          originHost === expectedHost ||
          (expectedHost === 'localhost' && originHost === '127.0.0.1') ||
          (expectedHost === '127.0.0.1' && originHost === 'localhost') ||
          (process.env.APP_URL && new URL(process.env.APP_URL).hostname.toLowerCase() === originHost);

        if (!isMatch) {
          res.status(403).json({
            success: false,
            error: `CSRF VIOLATION: Cross-origin approval attempt from origin '${origin}' is rejected.`,
            code: 'CSRF_VIOLATION',
          });
          return;
        }
      } catch {
        res.status(403).json({
          success: false,
          error: 'CSRF VIOLATION: Invalid Origin header.',
          code: 'CSRF_VIOLATION',
        });
        return;
      }
    }

    const authHeader = req.headers['authorization'];
    const customHeader = req.headers['x-user-approval-token'];
    const customAgentHeader = req.headers['x-agent-auth-token'];
    const providedToken = (typeof customAgentHeader === 'string' ? customAgentHeader : authHeader) || '';

    // Check if agent is attempting to self-approve with its own token
    if (providedToken && AgentAuthManager.validateToken(providedToken)) {
      res.status(403).json({
        success: false,
        error: 'SECURITY VIOLATION: Agent credentials cannot self-approve actions. Dedicated user approval credential required.',
        code: 'AGENT_SELF_APPROVAL_FORBIDDEN',
      });
      return;
    }

    // 1. Check for authenticated HttpOnly approval session cookie or header
    const cookies = parseCookies(req.headers['cookie']);
    const sessionToken =
      cookies['zoya_approval_session'] || (req.headers['x-approval-session'] as string | undefined);
    if (sessionToken && AgentAuthManager.validateApprovalSession(sessionToken)) {
      return next();
    }

    // 2. Check for explicit user approval token header (for headless test suites)
    const providedUserSecret = (typeof customHeader === 'string' ? customHeader : authHeader) || '';
    if (providedUserSecret && AgentAuthManager.validateUserApprovalSecret(providedUserSecret)) {
      return next();
    }

    res.status(401).json({
      success: false,
      error: 'Unauthorized: Valid owner approval session cookie (zoya_approval_session) or user approval secret required.',
      code: 'USER_APPROVAL_UNAUTHORIZED',
      hint: 'Authenticate with owner passphrase at /api/agent/auth/owner/login to establish HttpOnly approval session.',
    });
  }
}

export function agentAuth(req: Request, res: Response, next: NextFunction) {
  const expectedToken = AgentAuthManager.getCachedAgentToken();
  if (!expectedToken) {
    return res.status(503).json({ success: false, error: 'Agent auth not initialised', code: 'AGENT_AUTH_NOT_INITIALISED' });
  }

  const rawAuth = typeof req.headers['x-agent-auth-token'] === 'string'
    ? req.headers['x-agent-auth-token']
    : typeof req.headers.authorization === 'string'
    ? req.headers.authorization
    : '';
  const provided = rawAuth.replace(/^Bearer\s+/i, '').trim();

  if (!provided || !safeEqual(provided, expectedToken)) {
    return res.status(401).json({
      success: false,
      error: 'Unauthorized: Missing or invalid agent authentication token.',
      code: 'AGENT_AUTH_UNAUTHORIZED',
    });
  }

  const remote = req.socket?.remoteAddress || '';
  const hasForwardedFor = req.headers['x-forwarded-for'] !== undefined;
  const isLoopback = !hasForwardedFor && ['127.0.0.1', '::1', '::ffff:127.0.0.1'].includes(remote);

  if (!isLoopback) {
    const hasPairingHeader = req.headers['x-agent-pairing-code'] !== undefined;
    if (hasPairingHeader) {
      const code = String(req.headers['x-agent-pairing-code'] || '').trim();
      if (!code || !AgentAuthManager.consumePairingCode(code)) {
        return res.status(403).json({
          success: false,
          error: 'Pairing code required',
          code: 'PAIRING_CODE_REQUIRED',
        });
      }
      return next();
    }

    // Allow paired browser owner sessions minted by /api/agent/auth/token or /api/agent/auth/owner/login
    if (AgentAuthManager.validateOwnerSessionFromRequest(req)) {
      return next();
    }

    return res.status(403).json({
      success: false,
      error: 'Pairing code required',
      code: 'PAIRING_CODE_REQUIRED',
    });
  }
  return next();
}

/**
 * Protects TTS & ElevenLabs proxy routes with either an active Owner Session
 * (passphrase login / paired browser session) or full agentAuth middleware.
 * Never permits unauthenticated requests (returns 401).
 */
export function requireOwnerOrAgentAuth(req: Request, res: Response, next: NextFunction) {
  if (AgentAuthManager.validateOwnerSessionFromRequest(req)) {
    return next();
  }
  return agentAuth(req, res, next);
}

/**
 * Fixed-window per-socket-IP rate limiter (keyed strictly on req.socket.remoteAddress,
 * never X-Forwarded-For, plus a global safety ceiling).
 */
export function createEndpointRateLimiter(options: {
  name: string;
  maxRequestsPerIp: number;
  windowMs: number;
  maxGlobalRequests?: number;
}) {
  const { name, maxRequestsPerIp, windowMs, maxGlobalRequests = maxRequestsPerIp * 10 } = options;
  const perIp = new Map<string, { count: number; resetAt: number }>();
  let globalWindow = { count: 0, resetAt: Date.now() + windowMs };

  const middleware = (req: Request, res: Response, next: NextFunction) => {
    const now = Date.now();
    const socketIp = (req.socket?.remoteAddress || 'unknown').trim() || 'unknown';

    if (now >= globalWindow.resetAt) {
      globalWindow = { count: 0, resetAt: now + windowMs };
    }
    if (globalWindow.count >= maxGlobalRequests) {
      const retryAfterSec = Math.max(1, Math.ceil((globalWindow.resetAt - now) / 1000));
      res.setHeader('Retry-After', String(retryAfterSec));
      return res.status(429).json({
        success: false,
        error: `Global rate limit exceeded for ${name}. Retry in ${retryAfterSec}s.`,
        retryAfter: retryAfterSec,
      });
    }

    let entry = perIp.get(socketIp);
    if (!entry || now >= entry.resetAt) {
      entry = { count: 0, resetAt: now + windowMs };
      perIp.set(socketIp, entry);
    }

    if (entry.count >= maxRequestsPerIp) {
      const retryAfterSec = Math.max(1, Math.ceil((entry.resetAt - now) / 1000));
      res.setHeader('Retry-After', String(retryAfterSec));
      return res.status(429).json({
        success: false,
        error: `Rate limit exceeded (${maxRequestsPerIp} req/${Math.round(windowMs / 1000)}s). Retry in ${retryAfterSec}s.`,
        retryAfter: retryAfterSec,
      });
    }

    entry.count += 1;
    globalWindow.count += 1;
    return next();
  };

  middleware.resetForTest = () => {
    perIp.clear();
    globalWindow = { count: 0, resetAt: Date.now() + windowMs };
  };

  return middleware;
}

export const AGENT_COOKIE_CONFIG = {
  sameSite: (process.env.ZOYA_COOKIE_SAMESITE as 'Strict' | 'Lax' | 'None') || 'Strict',
  secure: true,
  httpOnly: true,
  maxAge: 3600,
  path: '/',
};


