import fs from 'fs';
import path from 'path';
import { spawn } from 'child_process';
import { EventEmitter } from 'events';
import { resolveWorkspacePath, truncateOutput } from './agentTools.ts';
import { agentPermissionGuard, maskSecrets, type PermissionLevel } from './agentPermissionGuard.ts';

export interface TerminalExecutionResult {
  id: string;
  command: string;
  cwd: string;
  exitCode: number;
  stdout: string;
  stderr: string;
  durationMs: number;
  timestamp: string;
}

export interface TerminalHistoryItem {
  id: string;
  command: string;
  cwd: string;
  exitCode: number;
  durationMs: number;
  timestamp: string;
  stdoutSnippet: string;
  stderrSnippet: string;
}

export interface TerminalManagerOptions {
  workspaceRoot?: string;
  maxHistory?: number;
  commandTimeoutMs?: number;
  maxOutputChars?: number;
  historyFilePath?: string;
}

export class TerminalManager extends EventEmitter {
  private workspaceRoot: string;
  private currentCwd: string; // Absolute path, always inside workspaceRoot
  private maxHistory: number;
  private commandTimeoutMs: number;
  private maxOutputChars: number;
  private historyFilePath: string;
  private history: TerminalHistoryItem[] = [];

  constructor(options?: TerminalManagerOptions) {
    super();
    this.workspaceRoot = path.resolve(options?.workspaceRoot || path.resolve(process.cwd(), 'workspace'));
    if (!fs.existsSync(this.workspaceRoot)) {
      fs.mkdirSync(this.workspaceRoot, { recursive: true });
    }
    // Ensure workspace is owned by appuser (UID 1000) so non-root subprocesses have full access
    try {
      if (typeof process.getuid === 'function' && process.getuid() === 0) {
        const { execSync } = require('child_process');
        execSync(`chown -R 1000:1000 "${this.workspaceRoot}"`, { stdio: 'ignore' });
      }
    } catch {}
    this.currentCwd = this.workspaceRoot;
    this.maxHistory = options?.maxHistory || 200;
    this.commandTimeoutMs = options?.commandTimeoutMs || 30000;
    this.maxOutputChars = options?.maxOutputChars || 65536;
    this.historyFilePath =
      options?.historyFilePath || path.resolve(process.cwd(), 'data', 'agent_logs', 'terminal_history.json');

    this.loadHistory();
  }

  public getWorkspaceRoot(): string {
    return this.workspaceRoot;
  }

  public getCwd(): string {
    return this.currentCwd;
  }

  public getRelativeCwd(): string {
    const rel = path.relative(this.workspaceRoot, this.currentCwd);
    return rel === '' ? '.' : rel;
  }

  /**
   * Sets current working directory, strictly confined to workspaceRoot.
   */
  public setCwd(targetPath: string): string {
    let resolved: string;
    if (path.isAbsolute(targetPath)) {
      // If absolute, make sure it is inside workspaceRoot
      resolved = path.resolve(targetPath);
    } else {
      resolved = path.resolve(this.currentCwd, targetPath);
    }

    if (!resolved.startsWith(this.workspaceRoot)) {
      throw new Error(
        `Navigation denied: Target directory '${targetPath}' is outside the workspace root (${this.workspaceRoot}).`
      );
    }

    if (!fs.existsSync(resolved)) {
      throw new Error(`Directory does not exist: '${targetPath}'`);
    }

    const stat = fs.statSync(resolved);
    if (!stat.isDirectory()) {
      throw new Error(`Path is not a directory: '${targetPath}'`);
    }

    this.currentCwd = resolved;
    this.emit('cwdChanged', this.getRelativeCwd());
    return this.getRelativeCwd();
  }

  /**
   * Executes a terminal command in the persistent CWD with permission evaluation,
   * output truncation, timeout protection, and history tracking.
   */
  public async executeCommand(
    command: string,
    options?: {
      bypassPermissionCheck?: boolean;
      timeoutMs?: number;
      taskId?: string;
      customCwd?: string;
    }
  ): Promise<TerminalExecutionResult> {
    const trimmed = command.trim();
    const id = `term_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
    const startTime = Date.now();
    const execCwd = options?.customCwd
      ? path.resolve(this.workspaceRoot, options.customCwd)
      : this.currentCwd;

    // Safety check on cwd
    if (!execCwd.startsWith(this.workspaceRoot)) {
      throw new Error(`Execution denied: CWD '${execCwd}' is outside workspace root.`);
    }

    // Security Gate check
    if (!options?.bypassPermissionCheck) {
      const auth = agentPermissionGuard.checkToolCall('run_command', { command: trimmed, cwd: execCwd }, this.workspaceRoot);
      if (auth.isBlocked) {
        const errorResult: TerminalExecutionResult = {
          id,
          command: trimmed,
          cwd: this.getRelativeCwd(),
          exitCode: 126,
          stdout: '',
          stderr: `SECURITY BLOCK: ${auth.reason}`,
          durationMs: Date.now() - startTime,
          timestamp: new Date().toISOString()
        };
        this.recordHistory(errorResult);
        return errorResult;
      }
      if (auth.needsApproval) {
        const { promise } = agentPermissionGuard.requestApproval(
          options?.taskId || 'terminal',
          'run_command',
          { command: trimmed, cwd: execCwd },
          auth.level as any,
          auth.reason,
          auth.warning
        );
        const approved = await promise;
        if (!approved) {
          const errorResult: TerminalExecutionResult = {
            id,
            command: trimmed,
            cwd: this.getRelativeCwd(),
            exitCode: 126,
            stdout: '',
            stderr: 'Action denied by user or security policy.',
            durationMs: Date.now() - startTime,
            timestamp: new Date().toISOString()
          };
          this.recordHistory(errorResult);
          return errorResult;
        }
      }
    }

    // Built-in navigation: 'cd'
    if (trimmed.startsWith('cd ') || trimmed === 'cd') {
      const targetDir = trimmed === 'cd' ? '.' : trimmed.slice(3).trim();
      try {
        const newRel = this.setCwd(targetDir);
        const result: TerminalExecutionResult = {
          id,
          command: trimmed,
          cwd: newRel,
          exitCode: 0,
          stdout: `Directory changed to: ${newRel}`,
          stderr: '',
          durationMs: Date.now() - startTime,
          timestamp: new Date().toISOString()
        };
        this.recordHistory(result);
        return result;
      } catch (err: any) {
        const result: TerminalExecutionResult = {
          id,
          command: trimmed,
          cwd: this.getRelativeCwd(),
          exitCode: 1,
          stdout: '',
          stderr: err.message || String(err),
          durationMs: Date.now() - startTime,
          timestamp: new Date().toISOString()
        };
        this.recordHistory(result);
        return result;
      }
    }

    // Built-in 'pwd'
    if (trimmed === 'pwd') {
      const result: TerminalExecutionResult = {
        id,
        command: trimmed,
        cwd: this.getRelativeCwd(),
        exitCode: 0,
        stdout: this.currentCwd,
        stderr: '',
        durationMs: Date.now() - startTime,
        timestamp: new Date().toISOString()
      };
      this.recordHistory(result);
      return result;
    }

    // Spawn child process in persistent bash shell
    const timeoutMs = options?.timeoutMs || this.commandTimeoutMs;

    return new Promise<TerminalExecutionResult>((resolve) => {
      let stdoutAcc = '';
      let stderrAcc = '';
      let timedOut = false;

      // Scrubbed environment: only PATH, HOME, LANG, USER, TERM (strictly no *KEY*, *TOKEN*, *SECRET*)
      const env = {
        PATH: process.env.PATH || '/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin',
        HOME: '/home/appuser',
        LANG: process.env.LANG || 'en_US.UTF-8',
        USER: 'appuser',
        PWD: execCwd,
        TERM: 'xterm-256color',
        PAGER: 'cat'
      };

      // Detect if this command is an approved package installer that requires network egress
      const isApprovedNetCommand = /\b(npm\s+(i|install|add)|pip\s+install|pip3\s+install|git\s+clone)\b/i.test(trimmed);

      let spawnBin = 'bash';
      let spawnArgs = ['--norc', '-c', trimmed];
      let spawnOpts: any = {
        cwd: execCwd,
        uid: 1000,
        gid: 1000,
        env,
        timeout: timeoutMs,
      };

      if (process.getuid && process.getuid() === 0 && !isApprovedNetCommand) {
        spawnBin = 'unshare';
        spawnArgs = ['-n', '-S', '1000', '-G', '1000', 'bash', '--norc', '-c', trimmed];
        spawnOpts = {
          cwd: execCwd,
          env,
          timeout: timeoutMs,
        };
      }

      const child = spawn(spawnBin, spawnArgs, spawnOpts);

      const timer = setTimeout(() => {
        timedOut = true;
        child.kill('SIGKILL');
      }, timeoutMs);

      child.stdout.on('data', (chunk: Buffer) => {
        const text = chunk.toString('utf-8');
        stdoutAcc += text;
        this.emit('stdout', { id, text });
      });

      child.stderr.on('data', (chunk: Buffer) => {
        const text = chunk.toString('utf-8');
        stderrAcc += text;
        this.emit('stderr', { id, text });
      });

      child.on('error', (err: Error) => {
        clearTimeout(timer);
        const duration = Date.now() - startTime;
        const res: TerminalExecutionResult = {
          id,
          command: trimmed,
          cwd: this.getRelativeCwd(),
          exitCode: 1,
          stdout: maskSecrets(truncateOutput(stdoutAcc, this.maxOutputChars)),
          stderr: maskSecrets(`Process error: ${err.message}`),
          durationMs: duration,
          timestamp: new Date().toISOString()
        };
        this.recordHistory(res);
        resolve(res);
      });

      child.on('close', (code: number | null, signal: string | null) => {
        clearTimeout(timer);
        const duration = Date.now() - startTime;
        let finalExit = code !== null ? code : signal ? 128 : 0;
        let finalErr = stderrAcc;

        if (timedOut) {
          finalExit = 124;
          finalErr += `\n[COMMAND TIMEOUT: Exceeded ${timeoutMs}ms limit]`;
        }

        const res: TerminalExecutionResult = {
          id,
          command: trimmed,
          cwd: this.getRelativeCwd(),
          exitCode: finalExit,
          stdout: maskSecrets(truncateOutput(stdoutAcc, this.maxOutputChars)),
          stderr: maskSecrets(truncateOutput(finalErr, this.maxOutputChars)),
          durationMs: duration,
          timestamp: new Date().toISOString()
        };

        this.recordHistory(res);
        resolve(res);
      });
    });
  }

  public getHistory(limit: number = 50): TerminalHistoryItem[] {
    return this.history.slice(-limit).reverse();
  }

  public clearHistory(): void {
    this.history = [];
    try {
      if (fs.existsSync(this.historyFilePath)) {
        fs.unlinkSync(this.historyFilePath);
      }
    } catch {}
    this.emit('historyCleared');
  }

  private recordHistory(res: TerminalExecutionResult) {
    const item: TerminalHistoryItem = {
      id: res.id,
      command: res.command,
      cwd: res.cwd,
      exitCode: res.exitCode,
      durationMs: res.durationMs,
      timestamp: res.timestamp,
      stdoutSnippet: res.stdout.slice(0, 250),
      stderrSnippet: res.stderr.slice(0, 250)
    };

    this.history.push(item);
    if (this.history.length > this.maxHistory) {
      this.history.shift();
    }
    this.saveHistory();
  }

  private saveHistory() {
    try {
      const dir = path.dirname(this.historyFilePath);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      fs.writeFileSync(this.historyFilePath, JSON.stringify(this.history, null, 2), 'utf-8');
    } catch (err) {
      // Ignore disk sync issues on shutdown
    }
  }

  private loadHistory() {
    try {
      if (fs.existsSync(this.historyFilePath)) {
        const raw = fs.readFileSync(this.historyFilePath, 'utf-8');
        this.history = JSON.parse(raw);
      }
    } catch {
      this.history = [];
    }
  }
}

export const terminalManager = new TerminalManager();
