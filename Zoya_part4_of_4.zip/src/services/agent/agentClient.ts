import type {
  AgentTaskState,
  AgentLogEntry,
  ModelProviderConfig,
  ToolResult,
  PendingApprovalRequest,
  SecurityAuditLogItem,
} from './agentTypes';

export interface AgentRunOptions {
  prompt: string;
  workspaceRoot?: string;
  maxRetries?: number;
  modelConfig?: ModelProviderConfig;
}

export class AgentClient {
  private static instance: AgentClient;
  private authToken: string | null = null;
  private pairedSessionToken: string | null = null;
  private approvalSessionToken: string | null = null;

  public static getInstance(): AgentClient {
    if (!AgentClient.instance) {
      AgentClient.instance = new AgentClient();
    }
    return AgentClient.instance;
  }

  public setAuthToken(token: string) {
    this.authToken = token;
    try {
      if (typeof sessionStorage !== 'undefined') {
        sessionStorage.setItem('zoya_agent_session_token', token);
      }
    } catch {}
  }

  public getAuthToken(): string | null {
    if (!this.authToken && typeof sessionStorage !== 'undefined') {
      try {
        this.authToken = sessionStorage.getItem('zoya_agent_session_token');
      } catch {}
    }
    return this.authToken;
  }

  public setPairedSessionToken(session: string) {
    this.pairedSessionToken = session;
    try {
      if (typeof sessionStorage !== 'undefined') {
        sessionStorage.setItem('zoya_agent_paired_session', session);
      }
    } catch {}
  }

  public getPairedSessionToken(): string | null {
    if (!this.pairedSessionToken && typeof sessionStorage !== 'undefined') {
      try {
        this.pairedSessionToken = sessionStorage.getItem('zoya_agent_paired_session');
      } catch {}
    }
    return this.pairedSessionToken;
  }

  public setApprovalSessionToken(session: string) {
    this.approvalSessionToken = session;
    try {
      if (typeof sessionStorage !== 'undefined') {
        sessionStorage.setItem('zoya_agent_approval_session', session);
      }
    } catch {}
  }

  public getApprovalSessionToken(): string | null {
    if (!this.approvalSessionToken && typeof sessionStorage !== 'undefined') {
      try {
        this.approvalSessionToken = sessionStorage.getItem('zoya_agent_approval_session');
      } catch {}
    }
    return this.approvalSessionToken;
  }

  public hasOwnerOrAgentAuth(): boolean {
    return Boolean(this.getAuthToken() || this.getPairedSessionToken() || this.getApprovalSessionToken());
  }

  public getOwnerFetchHeaders(extra: Record<string, string> = {}): Record<string, string> {
    const headers: Record<string, string> = { ...extra };
    const token = this.getAuthToken();
    const pairedSession = this.getPairedSessionToken();
    const approvalSession = this.getApprovalSessionToken();
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }
    if (pairedSession) {
      headers['x-agent-paired-session'] = pairedSession;
    }
    if (approvalSession) {
      headers['x-approval-session'] = approvalSession;
    }
    return headers;
  }

  public async loginOwnerPassphrase(passphrase: string): Promise<{
    success: boolean;
    message?: string;
    error?: string;
    rateLimited?: boolean;
    waitSeconds?: number;
    approvalSession?: string;
  }> {
    try {
      const res = await fetch('/api/agent/auth/owner/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ passphrase }),
      });
      const data = await res.json();
      if (data.success && data.approvalSession) {
        this.setApprovalSessionToken(data.approvalSession);
      }
      return data;
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  }

  public async setupOwnerPassphrase(
    passphrase: string,
    setupCode?: string,
    currentPassphrase?: string
  ): Promise<{ success: boolean; message?: string; error?: string }> {
    try {
      const res = await fetch('/api/agent/auth/owner/setup', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(setupCode ? { 'x-setup-code': setupCode } : {}),
        },
        credentials: 'include',
        body: JSON.stringify({ passphrase, setupCode, currentPassphrase }),
      });
      return await res.json();
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  }

  public async fetchPairingCode(passphrase: string): Promise<{
    success: boolean;
    pairingCode?: string;
    error?: string;
    rateLimited?: boolean;
    waitSeconds?: number;
  }> {
    try {
      const res = await fetch('/api/agent/auth/pairing-code', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ passphrase }),
      });
      return await res.json();
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  }

  public async pairWithCode(
    code: string
  ): Promise<{ success: boolean; token?: string; pairedSession?: string; error?: string }> {
    try {
      const res = await fetch('/api/agent/auth/token', {
        method: 'GET',
        headers: {
          'x-agent-pairing-code': code,
        },
        credentials: 'include',
      });
      const data = await res.json();
      if (data.success && data.token) {
        this.setAuthToken(data.token);
      }
      if (data.success && data.pairedSession) {
        this.setPairedSessionToken(data.pairedSession);
      }
      return data;
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  }

  public async rotateToken(): Promise<{ success: boolean; token?: string; error?: string }> {
    const headers = await this.getAuthHeaders();
    try {
      const res = await fetch('/api/agent/auth/rotate', {
        method: 'POST',
        headers,
        credentials: 'include',
      });
      const data = await res.json();
      if (data.success && data.token) {
        this.setAuthToken(data.token);
      }
      return data;
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  }

  public async ensureAuthToken(): Promise<string> {
    const existing = this.getAuthToken();
    if (existing) return existing;
    return '';
  }

  private async getAuthHeaders(): Promise<Record<string, string>> {
    await this.ensureAuthToken();
    return this.getOwnerFetchHeaders({ 'Content-Type': 'application/json' });
  }

  /**
   * Run an autonomous agent task
   */
  async runTask(options: AgentRunOptions): Promise<{ success: boolean; task?: AgentTaskState; error?: string }> {
    const headers = await this.getAuthHeaders();
    const res = await fetch('/api/agent/run', {
      method: 'POST',
      headers,
      credentials: 'include',
      body: JSON.stringify(options),
    });

    return await res.json();
  }

  /**
   * Stop/abort the currently running task
   */
  async stopTask(): Promise<{ success: boolean; message: string }> {
    const headers = await this.getAuthHeaders();
    const res = await fetch('/api/agent/stop', {
      method: 'POST',
      headers,
      credentials: 'include',
    });
    return await res.json();
  }

  /**
   * Get active task state
   */
  async getStatus(): Promise<{ success: boolean; task: AgentTaskState | null }> {
    const headers = await this.getAuthHeaders();
    const res = await fetch('/api/agent/status', {
      headers: { ...headers, 'Cache-Control': 'no-store' },
      credentials: 'include',
    });
    return await res.json();
  }

  /**
   * Get historical task logs
   */
  async getLogs(): Promise<{ success: boolean; logs: AgentTaskState[] }> {
    const headers = await this.getAuthHeaders();
    const res = await fetch('/api/agent/logs', {
      headers: { ...headers, 'Cache-Control': 'no-store' },
      credentials: 'include',
    });
    return await res.json();
  }

  /**
   * Update agent configuration
   */
  async updateConfig(config: { workspaceRoot?: string; modelConfig?: ModelProviderConfig }): Promise<any> {
    const headers = await this.getAuthHeaders();
    const res = await fetch('/api/agent/config', {
      method: 'POST',
      headers,
      credentials: 'include',
      body: JSON.stringify(config),
    });
    return await res.json();
  }

  /**
   * Execute a single tool manually or for tests
   */
  async executeTool(toolName: string, args: Record<string, any> = {}): Promise<{ success: boolean; result: ToolResult }> {
    const headers = await this.getAuthHeaders();
    const res = await fetch('/api/agent/tools/execute', {
      method: 'POST',
      headers,
      credentials: 'include',
      body: JSON.stringify({ toolName, args }),
    });
    return await res.json();
  }

  /**
   * Get pending approval requests
   */
  async getPendingApprovals(): Promise<{ success: boolean; pending: PendingApprovalRequest[] }> {
    const headers = await this.getAuthHeaders();
    const res = await fetch('/api/agent/approvals', {
      headers: { ...headers, 'Cache-Control': 'no-store' },
      credentials: 'include',
    });
    return await res.json();
  }

  /**
   * Respond to a pending approval request (Authenticated via short-lived HttpOnly session cookie)
   */
  async respondToApproval(id: string, approve: boolean): Promise<{ success: boolean; message: string }> {
    const res = await fetch(`/api/agent/approvals/${encodeURIComponent(id)}/respond`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      credentials: 'include',
      body: JSON.stringify({ approve }),
    });
    return await res.json();
  }

  /**
   * Get security audit logs
   */
  async getSecurityLogs(): Promise<{ success: boolean; logs: SecurityAuditLogItem[] }> {
    const headers = await this.getAuthHeaders();
    const res = await fetch('/api/agent/security/logs', {
      headers: { ...headers, 'Cache-Control': 'no-store' },
      credentials: 'include',
    });
    return await res.json();
  }

  // ==========================================
  // PHASE 3: TERMINAL CLIENT METHODS
  // ==========================================

  /**
   * Execute command in real persistent terminal shell
   */
  async executeTerminalCommand(
    command: string,
    customCwd?: string
  ): Promise<{ success: boolean; result: any; error?: string }> {
    const headers = await this.getAuthHeaders();
    const res = await fetch('/api/agent/terminal/execute', {
      method: 'POST',
      headers,
      credentials: 'include',
      body: JSON.stringify({ command, customCwd }),
    });
    return await res.json();
  }

  /**
   * Get command history
   */
  async getTerminalHistory(limit: number = 50): Promise<{ success: boolean; history: any[] }> {
    const headers = await this.getAuthHeaders();
    const res = await fetch(`/api/agent/terminal/history?limit=${limit}`, {
      headers: { ...headers, 'Cache-Control': 'no-store' },
      credentials: 'include',
    });
    return await res.json();
  }

  /**
   * Clear command history
   */
  async clearTerminalHistory(): Promise<{ success: boolean; message: string }> {
    const headers = await this.getAuthHeaders();
    const res = await fetch('/api/agent/terminal/clear', {
      method: 'POST',
      headers,
      credentials: 'include',
    });
    return await res.json();
  }

  /**
   * Get current persistent CWD
   */
  async getTerminalCwd(): Promise<{ success: boolean; cwd: string; relativeCwd: string; workspaceRoot: string }> {
    const headers = await this.getAuthHeaders();
    const res = await fetch('/api/agent/terminal/cwd', {
      headers: { ...headers, 'Cache-Control': 'no-store' },
      credentials: 'include',
    });
    return await res.json();
  }

  // ==========================================
  // PHASE 3: FILE MANAGER CLIENT METHODS
  // ==========================================

  /**
   * Get recursive workspace file tree
   */
  async getFileTree(subDir: string = '', depth: number = 6): Promise<{ success: boolean; tree: any; error?: string }> {
    const headers = await this.getAuthHeaders();
    const res = await fetch(`/api/agent/files/tree?subDir=${encodeURIComponent(subDir)}&depth=${depth}`, {
      headers: { ...headers, 'Cache-Control': 'no-store' },
      credentials: 'include',
    });
    return await res.json();
  }

  /**
   * Read file content from workspace
   */
  async readFile(filePath: string): Promise<{ success: boolean; file?: any; error?: string }> {
    const headers = await this.getAuthHeaders();
    const res = await fetch(`/api/agent/files/read?path=${encodeURIComponent(filePath)}`, {
      headers: { ...headers, 'Cache-Control': 'no-store' },
      credentials: 'include',
    });
    return await res.json();
  }

  /**
   * Write file to workspace with unified diff tracking
   */
  async writeFile(filePath: string, content: string): Promise<{ success: boolean; result?: any; error?: string }> {
    const headers = await this.getAuthHeaders();
    const res = await fetch('/api/agent/files/write', {
      method: 'POST',
      headers,
      credentials: 'include',
      body: JSON.stringify({ path: filePath, content }),
    });
    return await res.json();
  }

  /**
   * Delete file or directory inside workspace
   */
  async deletePath(filePath: string, recursive: boolean = false): Promise<{ success: boolean; result?: any; error?: string }> {
    const headers = await this.getAuthHeaders();
    const res = await fetch('/api/agent/files/delete', {
      method: 'DELETE',
      headers,
      credentials: 'include',
      body: JSON.stringify({ path: filePath, recursive }),
    });
    return await res.json();
  }

  /**
   * Get unified diff for a file against baseline
   */
  async getFileDiff(filePath: string): Promise<{ success: boolean; diff: string; path: string; error?: string }> {
    const headers = await this.getAuthHeaders();
    const res = await fetch(`/api/agent/files/diff?path=${encodeURIComponent(filePath)}`, {
      headers: { ...headers, 'Cache-Control': 'no-store' },
      credentials: 'include',
    });
    return await res.json();
  }

  /**
   * Get tracked modified/created files and history
   */
  async getFileChanges(): Promise<{ success: boolean; changes: any[]; history: any[] }> {
    const headers = await this.getAuthHeaders();
    const res = await fetch('/api/agent/files/changes', {
      headers: { ...headers, 'Cache-Control': 'no-store' },
      credentials: 'include',
    });
    return await res.json();
  }

  /**
   * Revert file to previous change snapshot
   */
  async revertFile(filePath: string): Promise<{ success: boolean; message: string; error?: string }> {
    const headers = await this.getAuthHeaders();
    const res = await fetch('/api/agent/files/revert', {
      method: 'POST',
      headers,
      credentials: 'include',
      body: JSON.stringify({ path: filePath }),
    });
    return await res.json();
  }

  // ==========================================
  // PHASE 4: SKILLS LIBRARY CLIENT METHODS
  // ==========================================

  async getSkills(): Promise<{ success: boolean; installed: any[]; quarantined: any[]; error?: string }> {
    const headers = await this.getAuthHeaders();
    const res = await fetch('/api/agent/skills', { headers, cache: 'no-store', credentials: 'include' });
    return await res.json();
  }

  async importSkillFolder(folderPath: string): Promise<{ success: boolean; quarantineId?: string; error?: string }> {
    const headers = await this.getAuthHeaders();
    const res = await fetch('/api/agent/skills/import/folder', {
      method: 'POST',
      headers,
      credentials: 'include',
      body: JSON.stringify({ folderPath }),
    });
    return await res.json();
  }

  async importSkillGit(repoUrl: string, subpath?: string): Promise<{ success: boolean; quarantineId?: string; error?: string }> {
    const headers = await this.getAuthHeaders();
    const res = await fetch('/api/agent/skills/import/git', {
      method: 'POST',
      headers,
      credentials: 'include',
      body: JSON.stringify({ repoUrl, subpath }),
    });
    return await res.json();
  }

  async importSkillZip(payload: { zipBase64?: string; zipPath?: string }): Promise<{ success: boolean; quarantineId?: string; error?: string }> {
    const headers = await this.getAuthHeaders();
    const res = await fetch('/api/agent/skills/import/zip', {
      method: 'POST',
      headers,
      credentials: 'include',
      body: JSON.stringify(payload),
    });
    return await res.json();
  }

  async scanSkill(quarantineId: string): Promise<{ success: boolean; report?: any; error?: string }> {
    const headers = await this.getAuthHeaders();
    const res = await fetch(`/api/agent/skills/scan/${encodeURIComponent(quarantineId)}`, {
      headers,
      cache: 'no-store',
      credentials: 'include',
    });
    return await res.json();
  }

  async getSkillUpdateDiff(id: string, quarantineId: string): Promise<{ success: boolean; diff?: string; scan?: any; error?: string }> {
    const headers = await this.getAuthHeaders();
    const res = await fetch(`/api/agent/skills/${encodeURIComponent(id)}/diff/${encodeURIComponent(quarantineId)}`, {
      headers,
      cache: 'no-store',
      credentials: 'include',
    });
    return await res.json();
  }

  async installSkill(quarantineId: string, approved: boolean = false): Promise<{ success: boolean; skill?: any; error?: string }> {
    const headers = await this.getAuthHeaders();
    const res = await fetch(`/api/agent/skills/install/${encodeURIComponent(quarantineId)}`, {
      method: 'POST',
      headers,
      credentials: 'include',
      body: JSON.stringify({ approved }),
    });
    return await res.json();
  }

  async enableSkill(id: string): Promise<{ success: boolean; skill?: any; error?: string }> {
    const headers = await this.getAuthHeaders();
    const res = await fetch(`/api/agent/skills/${encodeURIComponent(id)}/enable`, {
      method: 'POST',
      headers,
      credentials: 'include',
    });
    return await res.json();
  }

  async disableSkill(id: string): Promise<{ success: boolean; skill?: any; error?: string }> {
    const headers = await this.getAuthHeaders();
    const res = await fetch(`/api/agent/skills/${encodeURIComponent(id)}/disable`, {
      method: 'POST',
      headers,
      credentials: 'include',
    });
    return await res.json();
  }

  async deleteSkill(id: string): Promise<{ success: boolean; message?: string; error?: string }> {
    const headers = await this.getAuthHeaders();
    const res = await fetch(`/api/agent/skills/${encodeURIComponent(id)}`, {
      method: 'DELETE',
      headers,
      credentials: 'include',
    });
    return await res.json();
  }

  async updateSkill(id: string, newQuarantineId: string, approved: boolean = false): Promise<{ success: boolean; skill?: any; diff?: string; error?: string }> {
    const headers = await this.getAuthHeaders();
    const res = await fetch(`/api/agent/skills/${encodeURIComponent(id)}/update`, {
      method: 'POST',
      headers,
      credentials: 'include',
      body: JSON.stringify({ newQuarantineId, approved }),
    });
    return await res.json();
  }

  // ==========================================
  // PHASE 5: MCP CLIENT METHODS
  // ==========================================

  async getMcpServers(): Promise<{ success: boolean; servers: any[]; error?: string }> {
    const headers = await this.getAuthHeaders();
    const res = await fetch('/api/agent/mcp/servers', { headers, cache: 'no-store', credentials: 'include' });
    return await res.json();
  }

  async addMcpServer(config: any, approved: boolean = true): Promise<{ success: boolean; server?: any; error?: string }> {
    const headers = await this.getAuthHeaders();
    const res = await fetch('/api/agent/mcp/servers', {
      method: 'POST',
      headers,
      credentials: 'include',
      body: JSON.stringify({ ...config, approved }),
    });
    return await res.json();
  }

  async editMcpServer(id: string, patch: any, approved: boolean = true): Promise<{ success: boolean; server?: any; error?: string }> {
    const headers = await this.getAuthHeaders();
    const res = await fetch(`/api/agent/mcp/servers/${encodeURIComponent(id)}`, {
      method: 'PUT',
      headers,
      credentials: 'include',
      body: JSON.stringify({ ...patch, approved }),
    });
    return await res.json();
  }

  async removeMcpServer(id: string): Promise<{ success: boolean; message?: string; error?: string }> {
    const headers = await this.getAuthHeaders();
    const res = await fetch(`/api/agent/mcp/servers/${encodeURIComponent(id)}`, {
      method: 'DELETE',
      headers,
      credentials: 'include',
    });
    return await res.json();
  }

  async connectMcpServer(id: string, approved: boolean = true): Promise<{ success: boolean; tools?: any[]; error?: string }> {
    const headers = await this.getAuthHeaders();
    const res = await fetch(`/api/agent/mcp/servers/${encodeURIComponent(id)}/connect`, {
      method: 'POST',
      headers,
      credentials: 'include',
      body: JSON.stringify({ approved }),
    });
    return await res.json();
  }

  async disconnectMcpServer(id: string): Promise<{ success: boolean; message?: string; error?: string }> {
    const headers = await this.getAuthHeaders();
    const res = await fetch(`/api/agent/mcp/servers/${encodeURIComponent(id)}/disconnect`, {
      method: 'POST',
      headers,
      credentials: 'include',
    });
    return await res.json();
  }

  async getMcpTools(serverId?: string): Promise<{ success: boolean; tools: any[]; error?: string }> {
    const headers = await this.getAuthHeaders();
    const url = serverId ? `/api/agent/mcp/servers/${encodeURIComponent(serverId)}/tools` : '/api/agent/mcp/tools';
    const res = await fetch(url, { headers, cache: 'no-store', credentials: 'include' });
    return await res.json();
  }

  async callMcpTool(serverId: string, toolName: string, args: any, approved: boolean = true): Promise<{ success: boolean; result?: any; error?: string }> {
    const headers = await this.getAuthHeaders();
    const res = await fetch('/api/agent/mcp/tools/call', {
      method: 'POST',
      headers,
      credentials: 'include',
      body: JSON.stringify({ serverId, toolName, arguments: args, approved }),
    });
    return await res.json();
  }

  async getMcpLogs(limit: number = 100): Promise<{ success: boolean; logs: any[]; error?: string }> {
    const headers = await this.getAuthHeaders();
    const res = await fetch(`/api/agent/mcp/logs?limit=${limit}`, { headers, cache: 'no-store', credentials: 'include' });
    return await res.json();
  }
}

export const agentClient = AgentClient.getInstance();
