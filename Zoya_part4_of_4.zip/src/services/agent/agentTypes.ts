/**
 * Pure client-safe interfaces and types for the Zoya Agent System.
 * Zero Node.js imports (no path, no fs, no crypto).
 */

export type AgentStepPhase = 'plan' | 'tool_call' | 'read_result' | 'fix' | 'verify' | 'report';

export interface ToolResult {
  success: boolean;
  output: string;
  error?: string;
  metadata?: Record<string, any>;
}

export interface AgentLogEntry {
  id: string;
  timestamp: string;
  phase: AgentStepPhase;
  stepNumber: number;
  description: string;
  toolName?: string;
  toolArgs?: any;
  toolResult?: ToolResult;
  modelThinking?: string;
  durationMs?: number;
  status: 'running' | 'success' | 'failure' | 'retrying';
}

export interface AgentTaskState {
  taskId: string;
  userPrompt: string;
  status: 'idle' | 'running' | 'completed' | 'failed' | 'aborted';
  plan: string[];
  currentStep: number;
  totalSteps: number;
  retryCount: number;
  maxRetries: number;
  startTime: string;
  endTime?: string;
  logs: AgentLogEntry[];
  finalReport?: string;
  error?: string;
}

export type PermissionLevel = 'AUTO_ALLOW' | 'ASK_APPROVAL' | 'STRICT_APPROVAL_WITH_WARNING' | 'BLOCKED';

export interface PendingApprovalRequest {
  id: string;
  taskId: string;
  toolName: string;
  args: Record<string, any>;
  bindingHash: string;
  level: 'ASK_APPROVAL' | 'STRICT_APPROVAL_WITH_WARNING';
  reason: string;
  warning?: string;
  createdAt: string;
  expiresAt: number;
  status: 'pending' | 'approved' | 'denied';
  resolvedAt?: string;
  resolvedBy?: string;
  consumed: boolean;
  consumedAt?: string;
}

export interface SecurityAuditLogItem {
  id: string;
  timestamp: string;
  taskId?: string;
  action: 'AUTO_ALLOWED' | 'APPROVAL_REQUESTED' | 'APPROVED' | 'DENIED' | 'BLOCKED_VIOLATION';
  toolName: string;
  details: string;
  level: PermissionLevel;
  userOverride?: boolean;
}

export interface ModelProviderConfig {
  provider?: 'gemini' | 'anthropic' | 'openai' | 'local';
  modelName?: string;
  apiKey?: string;
  endpointUrl?: string;
  temperature?: number;
}
