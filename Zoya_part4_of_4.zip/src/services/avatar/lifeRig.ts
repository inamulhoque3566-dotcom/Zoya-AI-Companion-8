import * as THREE from 'three';

const D = Math.PI / 180;
const V3 = THREE.Vector3;
const Qt = THREE.Quaternion;
const cl = (x: number, a: number, b: number) => Math.max(a, Math.min(b, x));
const nz = (t: number, f: number, p: number) =>
  (Math.sin(t * f + p) + 0.5 * Math.sin(t * f * 2.31 + p * 1.7)) / 1.5;

function rng(s: number) {
  s >>>= 0;
  return () => {
    s = (s + 0x6d2b79f5) >>> 0;
    let t = s;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function hash(str: string) {
  let h = 2166136261;
  for (const c of str) {
    h ^= c.charCodeAt(0);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

export class Spr {
  x: number;
  v: number;
  constructor(x = 0) {
    this.x = x;
    this.v = 0;
  }
  step(tg: number, sm: number, dt: number) {
    const o = 2 / sm;
    const x = o * dt;
    const e = 1 / (1 + x + 0.48 * x * x + 0.235 * x * x * x);
    const c = this.x - tg;
    const t = (this.v + o * c) * dt;
    this.v = (this.v - o * t) * e;
    this.x = tg + (c + t) * e;
    return this.x;
  }
}

export const NAMES: Record<string, RegExp> = {
  hips: /^(hips|pelvis)$/,
  spine: /^spine$/,
  spine1: /^(spine1|chest)$/,
  spine2: /^(spine2|upperchest)$/,
  neck: /^neck$/,
  head: /^head$/,
};

for (const [S, w] of [
  ['L', 'left'],
  ['R', 'right'],
]) {
  NAMES['clav' + S] = new RegExp('^' + w + '(shoulder|clavicle)$');
  NAMES['arm' + S] = new RegExp('^' + w + '(arm|upperarm)$');
  NAMES['fore' + S] = new RegExp('^' + w + '(forearm|lowerarm)$');
  NAMES['hand' + S] = new RegExp('^' + w + 'hand$');
  NAMES['thigh' + S] = new RegExp('^' + w + '(upleg|upperleg|thigh)$');
  NAMES['shin' + S] = new RegExp('^' + w + '(leg|lowerleg|calf|shin)$');
  NAMES['foot' + S] = new RegExp('^' + w + 'foot$');
  NAMES['eye' + S] = new RegExp('^' + w + 'eye$');
}

const E = new THREE.Euler();
const Q = new Qt();
const Wi = new Qt();
const C = new Qt();

export interface LifeRigBoneRecord {
  o: THREE.Bone | THREE.Object3D;
  q: THREE.Quaternion;
  W: THREE.Quaternion;
  wp: THREE.Vector3;
}

export class LifeRig {
  R: () => number;
  name: string;
  ref: THREE.Object3D;
  P: {
    sway: number;
    blink: number;
    cur: number;
    expr: number;
    br: number;
  };
  H: number;
  sc: number;
  B: Record<string, LifeRigBoneRecord>;
  mm: THREE.Mesh[];
  blinkN: string[];
  hasEyeBone: boolean;
  hasLook: boolean;
  currentBlink: number;
  t: number;
  s: any;
  ph: number;

  constructor(ref: THREE.Object3D, name: string, idx = 0) {
    const R = (this.R = rng(hash(name) + idx * 7919));
    this.name = name;
    this.ref = ref;
    this.P = {
      sway: 0,
      blink: 1.0,
      cur: 0,
      expr: 0,
      br: 0,
    };
    ref.updateMatrixWorld(true);
    const rq = ref.getWorldQuaternion(new Qt());
    const rqi = rq.clone().invert();
    this.H = new THREE.Box3().setFromObject(ref).getSize(new V3()).y || 1.7;
    this.sc = ref.getWorldScale(new V3()).y || 1;
    const found: Record<string, any> = {};
    ref.traverse((o: any) => {
      if (!o.isBone) return;
      const k = o.name
        .toLowerCase()
        .replace(/mixamorig/, '')
        .replace(/[^a-z0-9]/g, '');
      for (const n in NAMES) {
        if (!found[n] && NAMES[n].test(k)) found[n] = o;
      }
    });
    ref.updateMatrixWorld(true);
    this.B = {};
    for (const n in found) {
      const o = found[n];
      this.B[n] = {
        o,
        q: o.quaternion.clone(),
        W: rqi.clone().multiply(o.getWorldQuaternion(new Qt())),
        wp: ref.worldToLocal(o.getWorldPosition(new V3())),
      };
    }
    this.mm = [];
    const names = new Set<string>();
    ref.traverse((o: any) => {
      if (o.morphTargetDictionary) {
        this.mm.push(o);
        for (const k in o.morphTargetDictionary) names.add(k);
      }
    });
    this.blinkN = [...names].filter((k) => /blink|eyesclosed|eyes_closed/i.test(k));
    if (!this.blinkN.length) console.warn(name + ': blink morph target नहीं मिला');
    this.hasEyeBone = !!(this.B.eyeL || this.B.eyeR);
    this.hasLook = names.has('eyeLookOutLeft');
    this.currentBlink = 0;
    const t = (this.t = R() * 100);
    const s: any = (this.s = {});
    s.w = new Spr();
    s.wS = new Spr();
    s.wH = new Spr();
    s.wT = 0;
    s.nShift = t + 999999;
    s.hy = new Spr();
    s.hp = new Spr();
    s.ey = new Spr();
    s.ep = new Spr();
    s.yT = 0;
    s.pT = 0;
    s.yPrev = 0;
    s.nLook = t + 999999;
    s.nBlink = t + 1.2 + R() * 2.5;
    s.bt = -1;
    s.bd = false;
    s.bi = 1;
    s.g = null;
    s.nG = t + 999999;
    s.gL = new Spr();
    s.gR = new Spr();
    s.ph = 0;
    this.ph = 0;
  }

  setM(n: string, v: number) {
    for (const m of this.mm) {
      const i = m.morphTargetDictionary ? m.morphTargetDictionary[n] : undefined;
      if (i !== undefined && m.morphTargetInfluences) {
        m.morphTargetInfluences[i] = v;
      }
    }
  }

  move(n: string, x: number, y: number, z: number) {
    const b = this.B[n];
    if (!b || !b.o.parent) return;
    b.o.position.copy(
      b.o.parent.worldToLocal(this.ref.localToWorld(b.wp.clone().add(new V3(x, y, z))))
    );
  }

  update(dt: number, _K = 1) {
    dt = Math.min(dt, 0.05);
    const R = this.R;
    const s = this.s;
    const t = (this.t += dt);

    // 1) STRAIGHT STANDING POSITION: Keep all bones locked in their straight aligned rest orientations
    for (const n in this.B) {
      const b = this.B[n];
      if (!b) continue;
      b.o.quaternion.copy(b.q);
    }
    this.move('hips', 0, 0, 0);

    // 2) NATURAL BIOLOGICAL EYE BLINKING (Strictly 2 to 5 seconds, double blinks, 100% natural reopening)
    if (t > s.nBlink && s.bt < 0) {
      s.bt = 0;
      s.bd = R() < 0.18; // ~18% double blink chance
      s.bi = 1.0;
      s.nBlink = t + 2.0 + R() * 3.0; // Strictly 2 to 5 seconds
    }
    let bv = 0;
    if (s.bt >= 0) {
      s.bt += dt;
      const k = s.bt;
      // Rapid 65ms descent, 25ms synchronous hold, 115ms smooth natural reopening
      bv = (k < 0.065 ? k / 0.065 : k < 0.09 ? 1.0 : 1.0 - (k - 0.09) / 0.115) * s.bi;
      if (k >= 0.205) {
        s.bt = -1;
        bv = 0;
        if (s.bd) {
          s.bd = false;
          s.nBlink = t + 0.11 + R() * 0.05; // Immediate double blink within 110-160ms
        }
      }
    }
    this.currentBlink = cl(bv, 0, 1);
    for (const n of this.blinkN) this.setM(n, this.currentBlink);
  }

}

/**
 * Global rigs store keeping all active LifeRig instances
 */
export const rigs: LifeRig[] = [];

/**
 * Creates standard Mixamo / Humanoid skeletal hierarchy for seamless LifeRig attachment.
 * All bone names strictly follow humanoid conventions (mixamorigHips, mixamorigSpine, etc.).
 */
export function createHumanoidSkeleton(anatomy?: {
  landmarks?: {
    feetY?: number;
    hipY?: number;
    waistY?: number;
    chestY?: number;
    shoulderY?: number;
    shoulderWidth?: number;
  };
}) {
  const lm = anatomy?.landmarks || {
    feetY: -1.45,
    hipY: -0.15,
    waistY: 0.18,
    chestY: 0.54,
    shoulderY: 0.82,
    shoulderWidth: 0.7,
  };
  const feetY = lm.feetY ?? -1.45;
  const hipY = lm.hipY ?? -0.15;
  const waistY = lm.waistY ?? 0.18;
  const chestY = lm.chestY ?? 0.54;
  const shoulderY = lm.shoulderY ?? 0.82;
  const shoulderW = lm.shoulderWidth ?? 0.7;
  const kneeY = (feetY + hipY) * 0.5;

  const hips = new THREE.Bone();
  hips.name = 'mixamorigHips';
  hips.position.set(0, hipY, 0);

  const spine = new THREE.Bone();
  spine.name = 'mixamorigSpine';
  spine.position.set(0, waistY - hipY, 0);
  hips.add(spine);

  const spine1 = new THREE.Bone();
  spine1.name = 'mixamorigSpine1';
  spine1.position.set(0, (chestY - waistY) * 0.5, 0);
  spine.add(spine1);

  const spine2 = new THREE.Bone();
  spine2.name = 'mixamorigSpine2';
  spine2.position.set(0, (chestY - waistY) * 0.5, 0);
  spine1.add(spine2);

  const neck = new THREE.Bone();
  neck.name = 'mixamorigNeck';
  neck.position.set(0, shoulderY - chestY, 0);
  spine2.add(neck);

  const head = new THREE.Bone();
  head.name = 'mixamorigHead';
  head.position.set(0, 1.15 - shoulderY, 0);
  neck.add(head);

  const eyeL = new THREE.Bone();
  eyeL.name = 'mixamorigLeftEye';
  eyeL.position.set(-0.05, 0.03, 0.09);
  head.add(eyeL);

  const eyeR = new THREE.Bone();
  eyeR.name = 'mixamorigRightEye';
  eyeR.position.set(0.05, 0.03, 0.09);
  head.add(eyeR);

  // Left arm
  const clavL = new THREE.Bone();
  clavL.name = 'mixamorigLeftShoulder';
  clavL.position.set(-shoulderW * 0.35, 0, 0);
  spine2.add(clavL);

  const armL = new THREE.Bone();
  armL.name = 'mixamorigLeftArm';
  armL.position.set(-shoulderW * 0.18, -0.05, 0);
  clavL.add(armL);

  const foreL = new THREE.Bone();
  foreL.name = 'mixamorigLeftForeArm';
  foreL.position.set(0, -0.42, 0);
  armL.add(foreL);

  const handL = new THREE.Bone();
  handL.name = 'mixamorigLeftHand';
  handL.position.set(0, -0.35, 0);
  foreL.add(handL);

  // Right arm
  const clavR = new THREE.Bone();
  clavR.name = 'mixamorigRightShoulder';
  clavR.position.set(shoulderW * 0.35, 0, 0);
  spine2.add(clavR);

  const armR = new THREE.Bone();
  armR.name = 'mixamorigRightArm';
  armR.position.set(shoulderW * 0.18, -0.05, 0);
  clavR.add(armR);

  const foreR = new THREE.Bone();
  foreR.name = 'mixamorigRightForeArm';
  foreR.position.set(0, -0.42, 0);
  armR.add(foreR);

  const handR = new THREE.Bone();
  handR.name = 'mixamorigRightHand';
  handR.position.set(0, -0.35, 0);
  foreR.add(handR);

  // Left leg
  const thighL = new THREE.Bone();
  thighL.name = 'mixamorigLeftUpLeg';
  thighL.position.set(-0.16, 0, 0);
  hips.add(thighL);

  const shinL = new THREE.Bone();
  shinL.name = 'mixamorigLeftLeg';
  shinL.position.set(0, kneeY - hipY, 0);
  thighL.add(shinL);

  const footL = new THREE.Bone();
  footL.name = 'mixamorigLeftFoot';
  footL.position.set(0, feetY - kneeY, 0);
  shinL.add(footL);

  // Right leg
  const thighR = new THREE.Bone();
  thighR.name = 'mixamorigRightUpLeg';
  thighR.position.set(0.16, 0, 0);
  hips.add(thighR);

  const shinR = new THREE.Bone();
  shinR.name = 'mixamorigRightLeg';
  shinR.position.set(0, kneeY - hipY, 0);
  thighR.add(shinR);

  const footR = new THREE.Bone();
  footR.name = 'mixamorigRightFoot';
  footR.position.set(0, feetY - kneeY, 0);
  shinR.add(footR);

  return hips;
}
