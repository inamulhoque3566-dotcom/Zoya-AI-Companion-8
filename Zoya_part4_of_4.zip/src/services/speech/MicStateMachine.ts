/**
 * Zoya Central Microphone State Machine
 * Single Source of Truth for Microphone Hardware & Wake-Word Coordination
 * 
 * States:
 * - OFF: Listening disabled by user. Both speech recognizer and wake word are halted.
 * - STANDBY: Low-power standby. Only native ZoyaService wake-word engine listens.
 *            NO speech recognition runs. Small steady green dot displayed in top corner.
 * - ACTIVATING: Wake-word detected or mic button tapped. ZoyaService paused,
 *               activation tone played, speech recognizer starting (<300ms target).
 * - CAPTURING: Active speech recognizer listening to user voice ("Hearing you").
 * - PROCESSING: User speech ended/finalized, assistant querying backend / LLM ("Thinking").
 * - SPEAKING: Assistant TTS audio playback active ("Speaking"). Speech recognizer & wake word
 *             are strictly muted/halted to prevent audio feedback & self-echo.
 * - PAUSED_BY_CALL: Microphone yielded for external PhoneCallModal or FullVoiceCallModal.
 * - ERROR: Hardware, permission, or initialization failure with descriptive reason.
 */

export type MicState =
  | 'OFF'
  | 'STANDBY'
  | 'ACTIVATING'
  | 'CAPTURING'
  | 'PROCESSING'
  | 'SPEAKING'
  | 'PAUSED_BY_CALL'
  | 'ERROR';

export interface MicStateSnapshot {
  state: MicState;
  previousState: MicState;
  reason?: string;
  isWakeWordActive: boolean;
  isSpeechRecActive: boolean;
  isTtsActive: boolean;
  wakeWordAvailable: boolean;
  wakeWordUnavailableReason?: string;
  hasMicPermission: boolean;
  permissionState: 'granted' | 'denied' | 'prompt' | 'unknown';
  audioLevel: number;
  isUserSpeaking: boolean;
  lastUpdated: number;
  activeTtsSource?: string;
  activeCallType?: 'phone' | 'voice_call' | null;
  handsFreeContinuous: boolean;
  voiceEngine: 'gemini-live' | 'webspeech' | 'mediarecorder' | 'native' | 'none';
}

export type MicStateListener = (snapshot: MicStateSnapshot) => void;

class MicStateMachine {
  private currentState: MicState = 'STANDBY';
  private previousState: MicState = 'OFF';
  private lastStateChangeTime: number = Date.now();
  private lastUserRequestTime: number = 0;
  private reason: string = '';
  private activeTtsSource?: string;
  private activeCallType?: 'phone' | 'voice_call' | null = null;
  private audioLevel: number = 0;
  private userSpeaking: boolean = false;
  private lastAudioNotifyTime: number = 0;

  // Watchdog & Silence Timers
  private silenceTimer: any = null;
  private ttsWatchdogTimer: any = null;
  private postTtsResumeTimer: any = null;
  private activationTimeoutTimer: any = null;

  // Listeners & Hardware Adapters
  private listeners: Set<MicStateListener> = new Set();
  private speechRecognizerAdapter: {
    start: () => Promise<boolean>;
    stop: () => Promise<void>;
    isActive: () => boolean;
  } | null = null;

  // Native ZoyaService Wake Word Idempotent Controller
  private isNativeWakeWordPaused = false;
  private isNativeWakeWordStarted = false;

  // Hands-free continuous mode (Love Mode: stays listening continuously even in silence & auto-resumes after TTS)
  private handsFreeContinuous = false;
  private voiceEngine: 'gemini-live' | 'webspeech' | 'mediarecorder' | 'native' | 'none' = 'none';
  private micPermissionState: 'granted' | 'denied' | 'prompt' | 'unknown' = 'unknown';
  private micPermissionGranted: boolean = false;

  // Storage key
  private STORAGE_KEY = 'zoya_mic_listening_enabled';

  constructor() {
    // Check initial user preference: default ON (STANDBY)
    try {
      const saved = localStorage.getItem(this.STORAGE_KEY);
      if (saved === 'false') {
        this.currentState = 'OFF';
      } else {
        this.currentState = 'STANDBY';
      }
    } catch {
      this.currentState = 'STANDBY';
    }

    // Bind window event for Android native bridge wake word detection
    if (typeof window !== 'undefined') {
      window.addEventListener('wake-word-detected', () => {
        console.log('[MIC_SM] Native wake-word event received from AndroidBridge');
        this.requestActivate('wake_word');
      });

      window.addEventListener('wake-word-model-missing', (e: any) => {
        console.warn('[MIC_SM] Native wake-word model missing:', e?.detail);
        this.notifyChange('Hey Zoya model missing');
      });

      window.addEventListener('wake-word-key-missing', () => {
        console.log('[MIC_SM] Native wake-word standby active');
      });

      void this.refreshMicPermission();
    }
  }

  public registerSpeechRecognizerAdapter(adapter: {
    start: () => Promise<boolean>;
    stop: () => Promise<void>;
    isActive: () => boolean;
  }) {
    this.speechRecognizerAdapter = adapter;
  }

  public subscribe(listener: MicStateListener): () => void {
    this.listeners.add(listener);
    listener(this.getSnapshot());
    return () => {
      this.listeners.delete(listener);
    };
  }

  public getSnapshot(): MicStateSnapshot {
    const wakeStatus = this.checkWakeWordAvailability();
    return {
      state: this.currentState,
      previousState: this.previousState,
      reason: this.reason,
      isWakeWordActive: this.currentState === 'STANDBY' && wakeStatus.available,
      isSpeechRecActive: this.currentState === 'ACTIVATING' || this.currentState === 'CAPTURING',
      isTtsActive: this.currentState === 'SPEAKING',
      wakeWordAvailable: wakeStatus.available,
      wakeWordUnavailableReason: wakeStatus.reason,
      hasMicPermission: this.micPermissionGranted,
      permissionState: this.micPermissionState,
      audioLevel: this.audioLevel,
      isUserSpeaking: this.userSpeaking,
      lastUpdated: this.lastStateChangeTime,
      activeTtsSource: this.activeTtsSource,
      activeCallType: this.activeCallType,
      handsFreeContinuous: this.handsFreeContinuous,
      voiceEngine: this.voiceEngine,
    };
  }

  public async refreshMicPermission(): Promise<'granted' | 'denied' | 'prompt' | 'unknown'> {
    if (typeof navigator === 'undefined' || !navigator.permissions?.query) {
      return this.micPermissionState;
    }
    try {
      const permStatus = await navigator.permissions.query({ name: 'microphone' as PermissionName });
      const applyState = (state: PermissionState) => {
        this.micPermissionState = state === 'granted' || state === 'denied' || state === 'prompt' ? state : 'unknown';
        this.micPermissionGranted = state === 'granted';
        this.notifyChange();
      };
      applyState(permStatus.state);
      permStatus.onchange = () => {
        applyState(permStatus.state);
      };
      return this.micPermissionState;
    } catch {
      return this.micPermissionState;
    }
  }

  public reportMicPermission(granted: boolean): void {
    const nextState: 'granted' | 'denied' = granted ? 'granted' : 'denied';
    if (this.micPermissionGranted === granted && this.micPermissionState === nextState) return;
    this.micPermissionGranted = granted;
    this.micPermissionState = nextState;
    this.notifyChange(granted ? 'Microphone permission granted' : 'Microphone permission denied');
  }

  public setHandsFreeContinuous(
    enabled: boolean,
    engine: 'gemini-live' | 'webspeech' | 'mediarecorder' | 'native' | 'none' = enabled ? this.voiceEngine : 'none'
  ): void {
    this.handsFreeContinuous = enabled;
    this.voiceEngine = engine;
    if (enabled) {
      this.clearSilenceWatchdog();
    } else {
      this.userSpeaking = false;
      this.audioLevel = 0;
    }
    this.notifyChange(enabled ? `Hands-free active (${engine})` : 'Hands-free stopped');
  }

  public isHandsFreeContinuous(): boolean {
    return this.handsFreeContinuous;
  }

  public setVoiceEngine(engine: 'gemini-live' | 'webspeech' | 'mediarecorder' | 'native' | 'none'): void {
    this.voiceEngine = engine;
    this.notifyChange();
  }

  public reportExternalLiveState(nextState: MicState, reason?: string): void {
    this.lastStateChangeTime = Date.now();
    this.transition(nextState, reason || `Live state: ${nextState}`);
  }

  public getState(): MicState {
    return this.currentState;
  }

  public isListening(): boolean {
    return this.currentState === 'STANDBY' || this.currentState === 'ACTIVATING' || this.currentState === 'CAPTURING';
  }

  public isCapturing(): boolean {
    return this.currentState === 'CAPTURING';
  }

  public isSpeaking(): boolean {
    return this.currentState === 'SPEAKING';
  }

  public checkWakeWordAvailability(): { available: boolean; reason?: string } {
    if (typeof window === 'undefined') {
      return { available: false, reason: 'Server environment' };
    }

    const bridge = (window as any).AndroidBridge || (window as any).__openclaw;
    if (!bridge) {
      return { available: false, reason: 'Wake word unavailable in web browser (Tap to talk)' };
    }

    if (typeof bridge.getWakeWordStatusJson === 'function') {
      try {
        const raw = bridge.getWakeWordStatusJson();
        const parsed = typeof raw === 'string' ? JSON.parse(raw) : raw;
        return {
          available: Boolean(parsed.hasMicPermission),
          reason: parsed.hasMicPermission ? undefined : 'Microphone permission required',
        };
      } catch {
        return { available: false, reason: 'Wake word status unknown' };
      }
    }

    return { available: true };
  }

  // =========================================================================
  // IDEMPOTENT NATIVE WAKE WORD CALLS (Requirement 4)
  // Exactly ONE recorder at a time across wake-word, hologram mic, calls
  // =========================================================================
  private nativePauseWakeWord(): void {
    if (this.isNativeWakeWordPaused) return; // Idempotent!
    this.isNativeWakeWordPaused = true;

    try {
      if (typeof window !== 'undefined') {
        const bridge = (window as any).AndroidBridge || (window as any).__openclaw;
        if (bridge && typeof bridge.pauseWakeWordListening === 'function') {
          console.log('[MIC_SM] Pausing native ZoyaService wake-word (releasing mic)');
          bridge.pauseWakeWordListening();
        }
      }
    } catch (e) {
      console.warn('[MIC_SM] Failed to pause native wake word:', e);
    }
  }

  private nativeResumeWakeWord(): void {
    if (!this.isNativeWakeWordPaused && this.isNativeWakeWordStarted) return; // Idempotent!
    this.isNativeWakeWordPaused = false;
    this.isNativeWakeWordStarted = true;

    try {
      if (typeof window !== 'undefined') {
        const bridge = (window as any).AndroidBridge || (window as any).__openclaw;
        if (bridge && typeof bridge.resumeWakeWordListening === 'function') {
          console.log('[MIC_SM] Resuming native ZoyaService wake-word (entering standby)');
          bridge.resumeWakeWordListening();
        }
      }
    } catch (e) {
      console.warn('[MIC_SM] Failed to resume native wake word:', e);
    }
  }

  private nativeStopWakeWord(): void {
    this.isNativeWakeWordPaused = true;
    this.isNativeWakeWordStarted = false;
    try {
      if (typeof window !== 'undefined') {
        const bridge = (window as any).AndroidBridge || (window as any).__openclaw;
        if (bridge && typeof bridge.stopWakeWordService === 'function') {
          bridge.stopWakeWordService();
        }
      }
    } catch {}
  }

  // =========================================================================
  // CORE TRANSITIONS & DEBOUNCE (Requirements 1, 2, 3)
  // =========================================================================

  private transition(nextState: MicState, reason?: string) {
    if (this.currentState === nextState && nextState !== 'ERROR') {
      return; // No-op for identical state
    }

    console.log(`[MIC_SM] Transition: ${this.currentState} -> ${nextState} (${reason || 'default'})`);
    this.previousState = this.currentState;
    this.currentState = nextState;
    this.reason = reason || '';
    this.lastStateChangeTime = Date.now();

    // Clear timers on transition unless relevant to state
    if (nextState !== 'ACTIVATING' && nextState !== 'CAPTURING') {
      this.clearSilenceWatchdog();
    }
    if (nextState !== 'SPEAKING') {
      this.clearTtsWatchdog();
    }
    if (nextState !== 'STANDBY') {
      if (this.postTtsResumeTimer) {
        clearTimeout(this.postTtsResumeTimer);
        this.postTtsResumeTimer = null;
      }
    }

    this.notifyChange(reason);
  }

  private notifyChange(reason?: string) {
    if (reason) this.reason = reason;
    const snap = this.getSnapshot();
    this.listeners.forEach((fn) => {
      try {
        fn(snap);
      } catch (e) {
        console.error('[MIC_SM] Listener callback error:', e);
      }
    });
  }

  // =========================================================================
  // PUBLIC ACTIONS (Components request changes through these)
  // =========================================================================

  /**
   * Request Active Listening (hologram mic button tap or wake-word detected)
   * Debounced: ignores requests within 400ms of each other.
   * Target activation time: < 300 ms.
   */
  public async requestActivate(source: 'button_tap' | 'wake_word' | 'ui' = 'button_tap'): Promise<boolean> {
    const now = Date.now();
    if (now - this.lastUserRequestTime < 400) {
      console.log('[MIC_SM] Debounced requestActivate within 400ms. Ignored.');
      return false;
    }
    this.lastUserRequestTime = now;

    // If currently SPEAKING, barge in: stop TTS and activate
    if (this.currentState === 'SPEAKING') {
      console.log('[MIC_SM] Barge-in during SPEAKING: canceling TTS and activating mic');
      this.reportSpeakInterrupted('barge_in');
    }

    // If already ACTIVATING or CAPTURING, tapping mic button means toggle OFF to STANDBY
    if (this.currentState === 'ACTIVATING' || this.currentState === 'CAPTURING') {
      if (source === 'button_tap') {
        console.log('[MIC_SM] Mic button tapped while active: returning to STANDBY');
        return this.requestStandby('User tap to cancel');
      }
      return true; // No-op if already active and from another source
    }

    // If PAUSED_BY_CALL, do not activate
    if (this.currentState === 'PAUSED_BY_CALL') {
      console.warn('[MIC_SM] Cannot activate mic while phone call is active');
      return false;
    }

    // Step 1: Immediately pause native wake word so mic hardware is free
    this.nativePauseWakeWord();

    // Step 2: Transition to ACTIVATING
    this.transition('ACTIVATING', `Activated via ${source}`);

    // Step 3: Start 8-second silence watchdog only when NOT in hands-free continuous mode
    if (!this.handsFreeContinuous) {
      this.startSilenceWatchdog(8000);
    }

    // Step 4: Launch speech recognizer adapter immediately
    if (this.speechRecognizerAdapter) {
      try {
        const started = await this.speechRecognizerAdapter.start();
        if (started) {
          // Transition to CAPTURING once recording is established
          if ((this.currentState as MicState) === 'ACTIVATING') {
            this.transition('CAPTURING', 'Speech recognizer ready');
          }
          return true;
        } else {
          console.warn('[MIC_SM] Speech recognizer failed to start, returning to STANDBY');
          this.requestStandby('Recognizer start failed');
          return false;
        }
      } catch (err: any) {
        console.error('[MIC_SM] Error starting speech recognizer:', err);
        this.reportError(`Mic error: ${err?.message || err}`);
        return false;
      }
    } else {
      // No custom adapter registered yet; keep state alive for direct handlers
      this.transition('CAPTURING', 'Direct capturing active');
      return true;
    }
  }

  /**
   * Request STANDBY mode (user silent, reply ended, or silence timeout)
   * Ensures speech recognition is stopped and ZoyaService wake word is resumed.
   */
  public async requestStandby(reason: string = 'Normal standby'): Promise<boolean> {
    if (this.currentState === 'STANDBY') {
      return true; // Already standby
    }

    if (this.currentState === 'OFF') {
      return false; // User explicitly turned mic off
    }

    // Stop active speech recognition if running
    if (this.speechRecognizerAdapter) {
      try {
        await this.speechRecognizerAdapter.stop();
      } catch (e) {
        console.warn('[MIC_SM] Error stopping speech recognizer on standby:', e);
      }
    }

    this.clearSilenceWatchdog();
    this.clearTtsWatchdog();

    // Idempotently resume native ZoyaService wake word in background
    this.nativeResumeWakeWord();

    this.transition('STANDBY', reason);
    return true;
  }

  /**
   * Request full OFF state (user explicitly turned mic listening off in app/settings)
   */
  public async requestTurnOff(): Promise<void> {
    this.lastUserRequestTime = Date.now();
    try {
      localStorage.setItem(this.STORAGE_KEY, 'false');
    } catch {}

    // Halt speech recognizer
    if (this.speechRecognizerAdapter) {
      try {
        await this.speechRecognizerAdapter.stop();
      } catch {}
    }

    // Halt native wake word
    this.nativeStopWakeWord();

    this.clearSilenceWatchdog();
    this.clearTtsWatchdog();

    this.transition('OFF', 'User disabled listening');
  }

  /**
   * Request turning listening ON from OFF
   */
  public async requestTurnOn(): Promise<void> {
    this.lastUserRequestTime = Date.now();
    try {
      localStorage.setItem(this.STORAGE_KEY, 'true');
    } catch {}

    await this.requestStandby('User enabled listening');
  }

  /**
   * Toggle between OFF and ON (STANDBY)
   */
  public async toggleListening(): Promise<void> {
    if (this.currentState === 'OFF') {
      await this.requestTurnOn();
    } else {
      await this.requestTurnOff();
    }
  }

  // =========================================================================
  // SPEECH RECOGNITION REPORTING (From speech engine to state machine)
  // =========================================================================

  public reportUserSpeechStarted(): void {
    if (this.currentState === 'SPEAKING' || this.currentState === 'PAUSED_BY_CALL') {
      return;
    }
    // When user starts speaking, reset silence timer to allow ongoing utterance
    this.clearSilenceWatchdog();
    if (!this.userSpeaking) {
      this.userSpeaking = true;
      if (this.currentState === 'CAPTURING') {
        this.notifyChange();
      }
    }
    if (this.currentState !== 'CAPTURING') {
      this.transition('CAPTURING', 'User voice detected');
    }
  }

  public reportAudioLevel(level: number): void {
    this.audioLevel = level;
    const isSpeakingNow = level > 0.035 && this.currentState !== 'SPEAKING' && this.currentState !== 'OFF';
    const speakingChanged = isSpeakingNow !== this.userSpeaking;
    this.userSpeaking = isSpeakingNow;
    if (isSpeakingNow && this.currentState === 'ACTIVATING') {
      this.reportUserSpeechStarted();
      return;
    }
    const now = Date.now();
    if (speakingChanged || (this.handsFreeContinuous && now - this.lastAudioNotifyTime > 120)) {
      this.lastAudioNotifyTime = now;
      this.notifyChange();
    }
  }

  public reportUserSpeechFinalized(text: string): void {
    if (this.currentState === 'SPEAKING' || this.currentState === 'PAUSED_BY_CALL') {
      return;
    }
    this.clearSilenceWatchdog();
    // Transition to PROCESSING ("Thinking")
    this.transition('PROCESSING', `Utterance finalized: "${text.slice(0, 30)}..."`);
  }

  // =========================================================================
  // TTS COORDINATION (Requirement 1, 3, 6)
  // Two TTS never speak at once. Speech recording strictly halted during playback.
  // After reply ends, wait ~500ms before returning to STANDBY.
  // =========================================================================

  public reportSpeakStart(ttsSource: string = 'gemini_tts'): void {
    console.log(`[MIC_SM] TTS speakStart reported by source: ${ttsSource}`);
    this.activeTtsSource = ttsSource;

    // Immediately stop speech recognition so Zoya does not hear herself
    if (this.speechRecognizerAdapter) {
      this.speechRecognizerAdapter.stop().catch(() => {});
    }

    // Ensure native wake word is paused
    this.nativePauseWakeWord();

    this.transition('SPEAKING', `TTS playing: ${ttsSource}`);

    // Set 25-second watchdog so mic is NEVER stuck in SPEAKING if audio fails to emit onended
    this.startTtsWatchdog(25000);
  }

  public reportSpeakEnd(ttsSource?: string): void {
    console.log(`[MIC_SM] TTS speakEnd reported by source: ${ttsSource || this.activeTtsSource} (state=${this.currentState}, handsFree=${this.handsFreeContinuous})`);
    this.activeTtsSource = undefined;
    this.clearTtsWatchdog();

    const shouldResumeHandsFree =
      this.handsFreeContinuous &&
      this.currentState !== 'OFF' &&
      this.currentState !== 'PAUSED_BY_CALL' &&
      this.currentState !== 'ERROR';

    if (this.currentState !== 'SPEAKING' && !shouldResumeHandsFree) {
      return;
    }

    // Wait ~450ms after TTS ends to let room reverb decay, then resume listening or standby
    if (this.postTtsResumeTimer) {
      clearTimeout(this.postTtsResumeTimer);
    }

    this.postTtsResumeTimer = setTimeout(async () => {
      this.postTtsResumeTimer = null;
      if (this.currentState === 'OFF' || this.currentState === 'PAUSED_BY_CALL' || this.currentState === 'ERROR') {
        return;
      }

      if (this.handsFreeContinuous) {
        if (this.voiceEngine === 'gemini-live') {
          console.log('[MIC_SM] Hands-free Gemini Live reply finished. Resuming CAPTURING.');
          this.transition('CAPTURING', 'Hands-free listening active');
          return;
        }
        console.log(`[MIC_SM] Hands-free reply finished (${this.voiceEngine}). Auto-resuming CAPTURING.`);
        this.transition('ACTIVATING', 'Auto-resuming hands-free listening');
        if (this.speechRecognizerAdapter) {
          try {
            const ok = await this.speechRecognizerAdapter.start();
            if (ok) {
              if ((this.currentState as MicState) === 'ACTIVATING') {
                this.transition('CAPTURING', 'Hands-free listening resumed');
              }
              return;
            }
            // Retry once after brief hardware release delay
            await new Promise((r) => setTimeout(r, 350));
            const postDelayState = this.currentState as MicState;
            if (this.handsFreeContinuous && postDelayState !== 'OFF' && postDelayState !== 'SPEAKING') {
              const retryOk = await this.speechRecognizerAdapter.start();
              if (retryOk) {
                if ((this.currentState as MicState) === 'ACTIVATING') {
                  this.transition('CAPTURING', 'Hands-free listening resumed on retry');
                }
                return;
              }
            }
            console.error('[MIC_SM] Hands-free mic failed to auto-resume after TTS.');
            this.reportError('माइक दोबारा शुरू नहीं हो सका');
            return;
          } catch (resumeErr: any) {
            console.error('[MIC_SM] Hands-free auto-resume error:', resumeErr);
            this.reportError(`माइक त्रुटि: ${resumeErr?.message || resumeErr}`);
            return;
          }
        }
        if ((this.currentState as MicState) === 'ACTIVATING') {
          this.transition('CAPTURING', 'Hands-free listening resumed');
        }
        return;
      }

      if (this.currentState !== 'SPEAKING') return;
      console.log('[MIC_SM] Post-TTS 500ms delay elapsed. Resuming STANDBY mode.');
      this.requestStandby('TTS completed cleanly');
    }, 450);
  }

  public reportSpeakError(ttsSource?: string, error?: string): void {
    console.warn(`[MIC_SM] TTS speakError reported by source: ${ttsSource}:`, error);
    this.activeTtsSource = undefined;
    this.clearTtsWatchdog();

    setTimeout(async () => {
      if (this.handsFreeContinuous && this.currentState !== 'OFF' && this.currentState !== 'PAUSED_BY_CALL') {
        if ((this.voiceEngine === 'webspeech' || this.voiceEngine === 'mediarecorder') && this.speechRecognizerAdapter) {
          this.transition('ACTIVATING', `Hands-free recovery after TTS error`);
          const ok = await this.speechRecognizerAdapter.start().catch(() => false);
          if (!ok) {
            console.error('[MIC_SM] Hands-free recovery after TTS error failed.');
            this.reportError('माइक दोबारा शुरू नहीं हो सका');
            return;
          }
        }
        const postErrState = this.currentState as MicState;
        if (postErrState !== 'OFF' && postErrState !== 'SPEAKING') {
          this.transition('CAPTURING', 'Hands-free listening recovered');
        }
        return;
      }
      if (this.currentState === 'SPEAKING') {
        this.requestStandby(`TTS error recovery (${error || 'playback error'})`);
      }
    }, 300);
  }

  public reportSpeakInterrupted(ttsSource?: string): void {
    console.log(`[MIC_SM] TTS speakInterrupted reported by source: ${ttsSource || 'user'}`);
    this.activeTtsSource = undefined;
    this.clearTtsWatchdog();
    if (this.postTtsResumeTimer) {
      clearTimeout(this.postTtsResumeTimer);
      this.postTtsResumeTimer = null;
    }
  }

  // =========================================================================
  // CALL MODAL COORDINATION (PhoneCallModal, FullVoiceCallModal)
  // Exactly ONE recorder at a time
  // =========================================================================

  public requestPauseForCall(callType: 'phone' | 'voice_call'): void {
    console.log(`[MIC_SM] requestPauseForCall for ${callType}`);
    this.activeCallType = callType;

    // Pause native wake word
    this.nativePauseWakeWord();

    // Stop central recognizer if running
    if (this.speechRecognizerAdapter) {
      this.speechRecognizerAdapter.stop().catch(() => {});
    }

    this.transition('PAUSED_BY_CALL', `Yielded to ${callType}`);
  }

  public requestResumeAfterCall(callType: 'phone' | 'voice_call'): void {
    console.log(`[MIC_SM] requestResumeAfterCall for ${callType}`);
    this.activeCallType = null;
    if (this.currentState === 'PAUSED_BY_CALL') {
      if (this.handsFreeContinuous) {
        this.transition('CAPTURING', `Hands-free resumed after ${callType}`);
      } else {
        this.requestStandby(`Resumed after ${callType}`);
      }
    }
  }

  public reportError(errorMsg: string): void {
    this.clearSilenceWatchdog();
    this.clearTtsWatchdog();
    this.transition('ERROR', errorMsg);
  }

  // =========================================================================
  // TIMERS & WATCHDOGS
  // =========================================================================

  private startSilenceWatchdog(ms: number = 8000): void {
    this.clearSilenceWatchdog();
    if (this.handsFreeContinuous) {
      return; // Keep listening continuously even while user is silent
    }
    this.silenceTimer = setTimeout(() => {
      if (this.handsFreeContinuous) return;
      if (this.currentState === 'ACTIVATING' || this.currentState === 'CAPTURING') {
        console.log(`[MIC_SM] 8-second silence timeout reached with no user speech. Returning to STANDBY.`);
        this.requestStandby('Silence timeout (8s)');
      }
    }, ms);
  }

  private clearSilenceWatchdog(): void {
    if (this.silenceTimer) {
      clearTimeout(this.silenceTimer);
      this.silenceTimer = null;
    }
  }

  private startTtsWatchdog(ms: number = 25000): void {
    this.clearTtsWatchdog();
    this.ttsWatchdogTimer = setTimeout(() => {
      if (this.currentState === 'SPEAKING') {
        console.warn(`[MIC_SM] TTS watchdog timeout (${ms}ms) reached without speakEnd!`);
        if (this.handsFreeContinuous) {
          this.reportSpeakEnd('tts_watchdog');
        } else {
          this.requestStandby('TTS watchdog timeout');
        }
      }
    }, ms);
  }

  private clearTtsWatchdog(): void {
    if (this.ttsWatchdogTimer) {
      clearTimeout(this.ttsWatchdogTimer);
      this.ttsWatchdogTimer = null;
    }
  }

  /**
   * For unit test execution only
   */
  public async triggerSilenceTimeoutForTesting(): Promise<boolean> {
    if (this.currentState === 'ACTIVATING' || this.currentState === 'CAPTURING') {
      console.log(`[MIC_SM] 8-second silence timeout reached with no user speech. Returning to STANDBY.`);
      return await this.requestStandby('Silence timeout (8s)');
    }
    return false;
  }
}

export const micStateMachine = new MicStateMachine();
