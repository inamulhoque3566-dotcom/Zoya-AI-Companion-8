import {
  getActiveBrandPreset,
  getBrandGuidelinesConfig,
  saveBrandGuidelinesConfig,
  getToolApiKey,
  hasToolApiKey,
  BRAND_PALETTE_PRESETS,
  BrandPalettePreset,
} from './toolApiKeysConfig';

export type Part1SkillId =
  | 'artifacts-builder'
  | 'brand-guidelines'
  | 'canvas-design'
  | 'changelog-generator'
  | 'competitive-ads-extractor'
  | 'connect-apps';

export interface ArtifactSkillPayload {
  kind: 'artifacts-builder';
  title: string;
  subtitle: string;
  brandApplied: string;
  htmlCode: string;
  features: string[];
}

export interface BrandGuidelinesSkillPayload {
  kind: 'brand-guidelines';
  enabled: boolean;
  preset: BrandPalettePreset;
  summaryText: string;
}

export interface CanvasDesignSkillPayload {
  kind: 'canvas-design';
  posterTitle: string;
  posterSubtitle: string;
  movementName: string;
  philosophyMarkdown: string;
  referenceCode: string;
  dateStamp: string;
  palette: {
    bg: string;
    fg: string;
    accent1: string;
    accent2: string;
    accent3: string;
    muted: string;
  };
  compositionStyle: 'swiss_brutalist' | 'chromatic_silence' | 'kinetic_construct' | 'analog_meditation';
}

export interface ChangelogSkillPayload {
  kind: 'changelog-generator';
  versionTitle: string;
  releaseDate: string;
  summaryIntro: string;
  filteredOutCount: number;
  sections: {
    category: 'New Features' | 'Improvements' | 'Bug Fixes' | 'Breaking Changes' | 'Security';
    items: string[];
  }[];
  markdownText: string;
}

export interface CompetitiveAdsSkillPayload {
  kind: 'competitive-ads-extractor';
  competitorSubject: string;
  isLiveScrapeNotice: boolean;
  overview: {
    totalAnalyzed: string;
    primaryThemes: string[];
    commonCtas: string[];
  };
  problemsHighlighted: {
    problem: string;
    copyHook: string;
    whyItWorks: string;
  }[];
  creativePatterns: {
    patternName: string;
    formatStructure: string;
    effectivenessNote: string;
  }[];
  copyFormulas: {
    formulaName: string;
    template: string;
    exampleHeadline: string;
  }[];
  audienceInsights: string[];
  recommendations: string[];
  markdownReport: string;
}

export interface ConnectAppsSkillPayload {
  kind: 'connect-apps';
  hasComposioKey: boolean;
  maskedKeyPreview: string;
  detectedApp: string;
  detectedAction: string;
  actionParameters: Record<string, string>;
  statusMessage: string;
  directIntentUrl?: string;
  fallbackActionLabel?: string;
}

export type Part1SkillOutput =
  | ArtifactSkillPayload
  | BrandGuidelinesSkillPayload
  | CanvasDesignSkillPayload
  | ChangelogSkillPayload
  | CompetitiveAdsSkillPayload
  | ConnectAppsSkillPayload;

export interface Part1SkillExecutionResult {
  skillId: Part1SkillId;
  spokenSummary: string;
  chatText: string;
  output: Part1SkillOutput;
}

/**
 * Detects whether a user message in Zoya's chat is invoking one of the 6 Part 1 skills.
 */
export function detectPart1SkillIntent(userText: string): Part1SkillId | null {
  const q = userText.trim();
  const lower = q.toLowerCase();

  // 1. Explicit slash commands or skill names
  if (lower.startsWith('/artifact') || lower.includes('artifacts-builder') || lower.includes('artifact builder')) {
    return 'artifacts-builder';
  }
  if (lower.startsWith('/brand') || lower.includes('brand-guidelines') || lower.includes('brand guideline') || lower.includes('brand style') || lower.includes('anthropic brand')) {
    return 'brand-guidelines';
  }
  if (lower.startsWith('/poster') || lower.startsWith('/canvas') || lower.includes('canvas-design') || lower.includes('canvas design')) {
    return 'canvas-design';
  }
  if (lower.startsWith('/changelog') || lower.includes('changelog-generator') || lower.includes('changelog') || lower.includes('release notes')) {
    return 'changelog-generator';
  }
  if (lower.startsWith('/ads') || lower.includes('competitive-ads-extractor') || lower.includes('competitor ad') || lower.includes('competitive ad')) {
    return 'competitive-ads-extractor';
  }
  if (lower.startsWith('/connect') || lower.includes('connect-apps') || lower.includes('composio')) {
    return 'connect-apps';
  }

  // 2. Natural language triggers for each of the 6 skills
  // Connect Apps (Gmail, Slack, GitHub, Notion, Linear, Calendar, HubSpot)
  if (
    /\b(send an? email|check my email|gmail|post to slack|slack message|slack channel|create a? github issue|github pr|notion page|add to notion|google calendar|linear issue|hubspot|connect app|connect my apps)\b/i.test(
      lower
    )
  ) {
    return 'connect-apps';
  }

  // Changelog Generator (commits, git log, release notes, version summary)
  if (
    /\b(git commit|commit log|commits into|summarize commits|release note|what's new summary|feat:|fix:|chore:)\b/i.test(
      lower
    )
  ) {
    return 'changelog-generator';
  }

  // Competitive Ads Extractor (ad copy, ad analysis, messaging patterns, facebook ad library, linkedin ads)
  if (
    /\b(analyze.*ad|extract.*ad|ad copy|ad library|facebook ads|linkedin ads|marketing copy analysis|messaging patterns|competitor messaging)\b/i.test(
      lower
    )
  ) {
    return 'competitive-ads-extractor';
  }

  // Canvas Design (poster, art poster, visual design philosophy, museum poster, brutalist poster)
  if (
    /\b(make a poster|create a poster|design a poster|art poster|poster about|poster for|visual poster|design philosophy|museum poster)\b/i.test(
      lower
    )
  ) {
    return 'canvas-design';
  }

  // Brand Guidelines (apply brand colors, switch brand palette, typography rules)
  if (
    /\b(brand color|brand palette|brand typography|apply brand|set brand|anthropic palette)\b/i.test(
      lower
    )
  ) {
    return 'brand-guidelines';
  }

  // Artifacts Builder (interactive calculator, dashboard, interactive widget, interactive tracker, mini-app, artifact)
  if (
    /\b(interactive|artifact|calculator|dashboard|habit tracker|kanban|pomodoro|pricing simulator|data visualizer|build a widget|create a widget|mini app)\b/i.test(
      lower
    )
  ) {
    return 'artifacts-builder';
  }

  return null;
}

// ============================================================================
// 1. ARTIFACTS BUILDER IMPLEMENTATION
// ============================================================================
function buildInteractiveArtifact(userQuery: string): ArtifactSkillPayload {
  const brandCfg = getBrandGuidelinesConfig();
  const preset = getActiveBrandPreset();
  const lower = userQuery.toLowerCase();

  const bg = brandCfg.enabled ? preset.colors.light : '#faf9f5';
  const dark = brandCfg.enabled ? preset.colors.dark : '#141413';
  const midGray = brandCfg.enabled ? preset.colors.midGray : '#b0aea5';
  const lightGray = brandCfg.enabled ? preset.colors.lightGray : '#e8e6dc';
  const accent1 = brandCfg.enabled ? preset.colors.accentPrimary : '#d97757';
  const accent2 = brandCfg.enabled ? preset.colors.accentSecondary : '#6a9bcc';
  const accent3 = brandCfg.enabled ? preset.colors.accentTertiary : '#788c5d';
  const headingFont = brandCfg.enabled ? preset.typography.headingFont : 'Poppins, Arial, sans-serif';
  const bodyFont = brandCfg.enabled ? preset.typography.bodyFont : 'Lora, Georgia, serif';

  const isDashboard =
    lower.includes('dashboard') ||
    lower.includes('analytics') ||
    lower.includes('metric') ||
    lower.includes('revenue') ||
    lower.includes('sales');
  const isTracker =
    lower.includes('tracker') ||
    lower.includes('habit') ||
    lower.includes('task') ||
    lower.includes('sprint') ||
    lower.includes('pomodoro') ||
    lower.includes('todo');

  // Extract a clean subject from the user query
  const cleanedTopic =
    userQuery
      .replace(/^\/artifact\s*/i, '')
      .replace(/\b(build|create|make|generate|an|interactive|artifact|widget|for|about|please|zoya)\b/gi, ' ')
      .replace(/\s+/g, ' ')
      .trim() || (isDashboard ? 'Executive Telemetry & Revenue Studio' : isTracker ? 'Deep Work & Sprint Velocity Studio' : 'Financial & ROI Scenario Simulator');

  const displayTitle =
    cleanedTopic.charAt(0).toUpperCase() + cleanedTopic.slice(1);

  if (isDashboard) {
    const htmlCode = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>${displayTitle}</title>
  <link href="https://fonts.googleapis.com/css2?family=Lora:ital,wght@0,400;0,600;1,400&family=Poppins:wght@500;600;700&display=swap" rel="stylesheet">
  <style>
    :root {
      --bg: ${bg};
      --dark: ${dark};
      --mid: ${midGray};
      --light-border: ${lightGray};
      --accent-1: ${accent1};
      --accent-2: ${accent2};
      --accent-3: ${accent3};
    }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      background: var(--bg);
      color: var(--dark);
      font-family: ${bodyFont};
      padding: 20px;
      line-height: 1.5;
    }
    h1, h2, h3, .font-heading { font-family: ${headingFont}; }
    .header-bar {
      display: flex;
      justify-content: space-between;
      align-items: flex-end;
      border-bottom: 2px solid var(--dark);
      padding-bottom: 12px;
      margin-bottom: 20px;
    }
    .kicker {
      font-family: ${headingFont};
      font-size: 10px;
      letter-spacing: 0.18em;
      text-transform: uppercase;
      color: var(--accent-1);
      font-weight: 700;
    }
    .kpi-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
      gap: 12px;
      margin-bottom: 20px;
    }
    .kpi-card {
      background: #ffffff;
      border: 1px solid var(--light-border);
      border-left: 4px solid var(--accent-1);
      padding: 14px;
    }
    .kpi-card:nth-child(2) { border-left-color: var(--accent-2); }
    .kpi-card:nth-child(3) { border-left-color: var(--accent-3); }
    .kpi-label { font-size: 11px; color: var(--mid); font-family: ${headingFont}; text-transform: uppercase; }
    .kpi-val { font-size: 24px; font-weight: 700; font-family: ${headingFont}; margin-top: 4px; }
    .controls {
      background: #ffffff;
      border: 1px solid var(--light-border);
      padding: 16px;
      margin-bottom: 18px;
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 16px;
    }
    label { font-family: ${headingFont}; font-size: 12px; font-weight: 600; display: block; margin-bottom: 6px; }
    input[type=range] { width: 100%; accent-color: var(--accent-1); cursor: pointer; }
    .bars {
      display: flex;
      align-items: flex-end;
      gap: 10px;
      height: 150px;
      padding: 16px;
      background: #ffffff;
      border: 1px solid var(--light-border);
    }
    .bar-col { flex: 1; display: flex; flex-direction: column; align-items: center; height: 100%; justify-content: flex-end; }
    .bar-fill { width: 100%; background: var(--accent-1); transition: height 0.25s ease; min-height: 8px; }
    .bar-col:nth-child(even) .bar-fill { background: var(--accent-2); }
    .bar-col:nth-child(3n) .bar-fill { background: var(--accent-3); }
    .bar-lbl { font-family: ${headingFont}; font-size: 10px; margin-top: 6px; color: var(--dark); }
  </style>
</head>
<body>
  <div class="header-bar">
    <div>
      <div class="kicker">INTERACTIVE ARTIFACT · EDITORIAL TELEMETRY</div>
      <h1 style="font-size: 20px; margin-top: 2px;">${displayTitle}</h1>
    </div>
    <div style="font-family: ${headingFont}; font-size: 11px; color: var(--mid);">LIVE SIMULATION</div>
  </div>

  <div class="kpi-grid">
    <div class="kpi-card">
      <div class="kpi-label">Projected ARR</div>
      <div class="kpi-val" id="arrVal">$142,800</div>
    </div>
    <div class="kpi-card">
      <div class="kpi-label">Active Conversion</div>
      <div class="kpi-val" id="convVal">4.8%</div>
    </div>
    <div class="kpi-card">
      <div class="kpi-label">Net Retention</div>
      <div class="kpi-val" id="nrrVal">118%</div>
    </div>
  </div>

  <div class="controls">
    <div>
      <label>Monthly Traffic Volume: <span id="trafficOut">35,000</span></label>
      <input type="range" id="trafficRange" min="5000" max="150000" step="2500" value="35000" />
    </div>
    <div>
      <label>Growth Multiplier (%): <span id="growthOut">18%</span></label>
      <input type="range" id="growthRange" min="2" max="60" step="1" value="18" />
    </div>
  </div>

  <div class="bars" id="chartBars"></div>

  <script>
    const trafficRange = document.getElementById('trafficRange');
    const growthRange = document.getElementById('growthRange');
    const trafficOut = document.getElementById('trafficOut');
    const growthOut = document.getElementById('growthOut');
    const arrVal = document.getElementById('arrVal');
    const convVal = document.getElementById('convVal');
    const nrrVal = document.getElementById('nrrVal');
    const chartBars = document.getElementById('chartBars');
    const months = ['Q1', 'Q2', 'Q3', 'Q4', 'Q5 (Est)', 'Q6 (Est)'];

    function render() {
      const traffic = Number(trafficRange.value);
      const growth = Number(growthRange.value);
      trafficOut.textContent = traffic.toLocaleString();
      growthOut.textContent = growth + '%';

      const baseArr = Math.round(traffic * 3.4 * (1 + growth / 100));
      arrVal.textContent = '$' + baseArr.toLocaleString();
      convVal.textContent = (3.2 + growth * 0.08).toFixed(1) + '%';
      nrrVal.textContent = Math.min(148, Math.round(104 + growth * 0.75)) + '%';

      chartBars.innerHTML = '';
      months.forEach((m, idx) => {
        const pct = Math.min(100, Math.max(15, Math.round(28 + idx * (growth * 0.95) + (traffic / 150000) * 20)));
        const col = document.createElement('div');
        col.className = 'bar-col';
        const fill = document.createElement('div');
        fill.className = 'bar-fill';
        fill.style.height = pct + '%';
        const lbl = document.createElement('div');
        lbl.className = 'bar-lbl';
        lbl.textContent = m;
        col.appendChild(fill);
        col.appendChild(lbl);
        chartBars.appendChild(col);
      });
    }
    trafficRange.addEventListener('input', render);
    growthRange.addEventListener('input', render);
    render();
  </script>
</body>
</html>`;

    return {
      kind: 'artifacts-builder',
      title: displayTitle,
      subtitle: 'Interactive Telemetry & Cohort Forecast Artifact',
      brandApplied: brandCfg.enabled ? preset.name : 'Default Editorial',
      htmlCode,
      features: [
        'Live interactive traffic & growth scenario sliders',
        'Dynamic 6-quarter cohort bar chart calculation',
        `Styled with ${preset.name} palette & Poppins/Lora typography`,
      ],
    };
  }

  if (isTracker) {
    const htmlCode = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>${displayTitle}</title>
  <link href="https://fonts.googleapis.com/css2?family=Lora:ital,wght@0,400;0,600&family=Poppins:wght@500;600;700&display=swap" rel="stylesheet">
  <style>
    :root {
      --bg: ${bg};
      --dark: ${dark};
      --mid: ${midGray};
      --light-border: ${lightGray};
      --accent-1: ${accent1};
      --accent-2: ${accent2};
      --accent-3: ${accent3};
    }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { background: var(--bg); color: var(--dark); font-family: ${bodyFont}; padding: 20px; }
    h1, h2, button, .badge { font-family: ${headingFont}; }
    .top { border-bottom: 2px solid var(--dark); padding-bottom: 10px; margin-bottom: 16px; display: flex; justify-content: space-between; align-items: center; }
    .progress-wrap { background: var(--light-border); height: 10px; width: 100%; margin-bottom: 16px; overflow: hidden; }
    .progress-bar { background: var(--accent-3); height: 100%; width: 50%; transition: width 0.3s ease; }
    .add-row { display: flex; gap: 8px; margin-bottom: 16px; }
    input[type=text] { flex: 1; padding: 10px 12px; border: 1px solid var(--dark); background: #fff; font-family: ${bodyFont}; font-size: 13px; }
    button { background: var(--accent-1); color: #fff; border: none; padding: 10px 16px; font-weight: 600; font-size: 12px; cursor: pointer; }
    .list { display: flex; flex-direction: column; gap: 8px; }
    .item { display: flex; align-items: center; justify-content: space-between; padding: 12px; background: #fff; border: 1px solid var(--light-border); border-left: 4px solid var(--accent-2); cursor: pointer; }
    .item.done { border-left-color: var(--accent-3); opacity: 0.72; text-decoration: line-through; }
    .badge { font-size: 11px; padding: 3px 8px; background: var(--light-border); color: var(--dark); }
  </style>
</head>
<body>
  <div class="top">
    <div>
      <div style="font-size:10px; letter-spacing:0.15em; text-transform:uppercase; color:var(--accent-1); font-weight:700;">INTERACTIVE TRACKER ARTIFACT</div>
      <h1 style="font-size:19px;">${displayTitle}</h1>
    </div>
    <span class="badge" id="scoreBadge">2 / 4 Complete</span>
  </div>
  <div class="progress-wrap"><div class="progress-bar" id="progBar"></div></div>
  <div class="add-row">
    <input type="text" id="newItemInput" placeholder="Add a milestone or habit..." />
    <button id="addBtn">+ Add</button>
  </div>
  <div class="list" id="taskList"></div>
  <script>
    const items = [
      { text: 'Complete Deep Work Architecture Block (90m)', done: true },
      { text: 'Review Brand Typography & Design Tokens', done: true },
      { text: 'Ship Interactive Prototype to Production', done: false },
      { text: 'Evening Synthesis & Changelog Audit', done: false }
    ];
    const listEl = document.getElementById('taskList');
    const progBar = document.getElementById('progBar');
    const scoreBadge = document.getElementById('scoreBadge');
    const input = document.getElementById('newItemInput');

    function render() {
      listEl.innerHTML = '';
      const doneCount = items.filter(i => i.done).length;
      const pct = items.length ? Math.round((doneCount / items.length) * 100) : 0;
      progBar.style.width = pct + '%';
      scoreBadge.textContent = doneCount + ' / ' + items.length + ' (' + pct + '%)';

      items.forEach((item, idx) => {
        const row = document.createElement('div');
        row.className = 'item' + (item.done ? ' done' : '');
        const textSpan = document.createElement('span');
        textSpan.textContent = item.text;
        const badgeSpan = document.createElement('span');
        badgeSpan.className = 'badge';
        badgeSpan.textContent = item.done ? 'DONE' : 'ACTIVE';
        row.appendChild(textSpan);
        row.appendChild(badgeSpan);
        row.onclick = () => { items[idx].done = !items[idx].done; render(); };
        listEl.appendChild(row);
      });
    }
    document.getElementById('addBtn').onclick = () => {
      if (!input.value.trim()) return;
      items.unshift({ text: input.value.trim(), done: false });
      input.value = '';
      render();
    };
    render();
  </script>
</body>
</html>`;

    return {
      kind: 'artifacts-builder',
      title: displayTitle,
      subtitle: 'Interactive Milestone & Habit Tracker Artifact',
      brandApplied: brandCfg.enabled ? preset.name : 'Default Editorial',
      htmlCode,
      features: [
        'Click any milestone to toggle completion state with live progress bar',
        'Add custom milestones dynamically inside the sandbox',
        `Styled with ${preset.name} palette & Poppins/Lora hierarchy`,
      ],
    };
  }

  // Default: Interactive Financial / EMI / ROI Calculator Artifact
  const htmlCode = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>${displayTitle}</title>
  <link href="https://fonts.googleapis.com/css2?family=Lora:ital,wght@0,400;0,600&family=Poppins:wght@500;600;700&display=swap" rel="stylesheet">
  <style>
    :root {
      --bg: ${bg};
      --dark: ${dark};
      --mid: ${midGray};
      --light-border: ${lightGray};
      --accent-1: ${accent1};
      --accent-2: ${accent2};
      --accent-3: ${accent3};
    }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { background: var(--bg); color: var(--dark); font-family: ${bodyFont}; padding: 20px; }
    h1, h2, label, .stat-val { font-family: ${headingFont}; }
    .header { border-bottom: 2px solid var(--dark); padding-bottom: 10px; margin-bottom: 18px; }
    .tag { font-family: ${headingFont}; font-size: 10px; letter-spacing: 0.16em; text-transform: uppercase; color: var(--accent-1); font-weight: 700; }
    .layout { display: grid; grid-template-columns: 1.15fr 0.85fr; gap: 16px; }
    @media (max-width: 520px) { .layout { grid-template-columns: 1fr; } }
    .panel { background: #fff; border: 1px solid var(--light-border); padding: 16px; }
    .field { margin-bottom: 14px; }
    label { font-size: 12px; font-weight: 600; display: flex; justify-content: space-between; margin-bottom: 6px; }
    input[type=range] { width: 100%; accent-color: var(--accent-1); cursor: pointer; }
    .summary-box { background: var(--dark); color: var(--bg); padding: 18px; display: flex; flex-direction: column; justify-content: space-between; }
    .stat-lbl { font-size: 11px; color: var(--mid); text-transform: uppercase; font-family: ${headingFont}; }
    .stat-val { font-size: 26px; font-weight: 700; color: var(--accent-1); margin: 4px 0 14px; }
    .split-bar { height: 12px; display: flex; width: 100%; overflow: hidden; margin-top: 8px; }
    .split-p { background: var(--accent-2); height: 100%; }
    .split-i { background: var(--accent-1); height: 100%; }
  </style>
</head>
<body>
  <div class="header">
    <div class="tag">INTERACTIVE ARTIFACT · PRECISION CALCULATOR</div>
    <h1 style="font-size: 19px; margin-top: 2px;">${displayTitle}</h1>
  </div>
  <div class="layout">
    <div class="panel">
      <div class="field">
        <label><span>Principal Amount</span><span id="pLabel">₹15,00,000</span></label>
        <input type="range" id="pInput" min="50000" max="10000000" step="50000" value="1500000" />
      </div>
      <div class="field">
        <label><span>Annual Rate (%)</span><span id="rLabel">8.5%</span></label>
        <input type="range" id="rInput" min="4" max="20" step="0.25" value="8.5" />
      </div>
      <div class="field" style="margin-bottom:0;">
        <label><span>Duration (Years)</span><span id="tLabel">10 Years</span></label>
        <input type="range" id="tInput" min="1" max="30" step="1" value="10" />
      </div>
    </div>
    <div class="summary-box">
      <div>
        <div class="stat-lbl">Monthly Payment (EMI)</div>
        <div class="stat-val" id="emiOut">₹18,598</div>
        <div class="stat-lbl">Total Interest Payable</div>
        <div style="font-size: 16px; font-weight: 600; color: var(--accent-2); margin-top:2px;" id="intOut">₹7,31,732</div>
      </div>
      <div>
        <div class="stat-lbl" style="display:flex; justify-content:space-between;">
          <span>Principal vs Interest</span>
          <span id="ratioOut">67% / 33%</span>
        </div>
        <div class="split-bar">
          <div class="split-p" id="barP" style="width:67%"></div>
          <div class="split-i" id="barI" style="width:33%"></div>
        </div>
      </div>
    </div>
  </div>
  <script>
    const pIn = document.getElementById('pInput');
    const rIn = document.getElementById('rInput');
    const tIn = document.getElementById('tInput');
    function update() {
      const P = Number(pIn.value);
      const annualR = Number(rIn.value);
      const years = Number(tIn.value);
      const n = years * 12;
      const r = annualR / 12 / 100;
      const emi = (P * r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1);
      const total = emi * n;
      const interest = total - P;
      const pPct = Math.round((P / total) * 100);
      const iPct = 100 - pPct;

      document.getElementById('pLabel').textContent = '₹' + P.toLocaleString('en-IN');
      document.getElementById('rLabel').textContent = annualR + '%';
      document.getElementById('tLabel').textContent = years + ' Years';
      document.getElementById('emiOut').textContent = '₹' + Math.round(emi).toLocaleString('en-IN');
      document.getElementById('intOut').textContent = '₹' + Math.round(interest).toLocaleString('en-IN');
      document.getElementById('ratioOut').textContent = pPct + '% / ' + iPct + '%';
      document.getElementById('barP').style.width = pPct + '%';
      document.getElementById('barI').style.width = iPct + '%';
    }
    [pIn, rIn, tIn].forEach(el => el.addEventListener('input', update));
    update();
  </script>
</body>
</html>`;

  return {
    kind: 'artifacts-builder',
    title: displayTitle,
    subtitle: 'Interactive Financial & Scenario Calculator Artifact',
    brandApplied: brandCfg.enabled ? preset.name : 'Default Editorial',
    htmlCode,
    features: [
      'Real-time principal, interest rate, and tenure sliders',
      'Visual Principal-to-Interest proportion bar',
      `Built with ${preset.name} palette (#141413, #FAF9F5, #D97757, #6A9BCC) & Poppins/Lora fonts`,
    ],
  };
}

// ============================================================================
// 2. BRAND GUIDELINES IMPLEMENTATION
// ============================================================================
function handleBrandGuidelinesSkill(userQuery: string): BrandGuidelinesSkillPayload {
  const lower = userQuery.toLowerCase();
  const current = getBrandGuidelinesConfig();

  if (lower.includes('disable') || lower.includes('turn off')) {
    current.enabled = false;
  } else if (lower.includes('enable') || lower.includes('turn on') || lower.includes('apply')) {
    current.enabled = true;
  }

  if (lower.includes('swiss') || lower.includes('brutalist')) {
    current.presetId = 'swiss_editorial';
  } else if (lower.includes('royal') || lower.includes('obsidian')) {
    current.presetId = 'zoya_royal';
  } else if (lower.includes('anthropic') || lower.includes('warm') || lower.includes('official')) {
    current.presetId = 'anthropic_warm';
  }

  saveBrandGuidelinesConfig(current);
  const preset =
    BRAND_PALETTE_PRESETS.find((p) => p.id === current.presetId) ||
    BRAND_PALETTE_PRESETS[0];

  return {
    kind: 'brand-guidelines',
    enabled: current.enabled,
    preset,
    summaryText: `Brand Style "${preset.name}" is ${
      current.enabled ? 'ACTIVE' : 'PAUSED'
    }. Primary colors (${preset.colors.dark}, ${preset.colors.light}, ${
      preset.colors.accentPrimary
    }, ${preset.colors.accentSecondary}, ${
      preset.colors.accentTertiary
    }) and typography (${preset.typography.headingFont.split(',')[0]} headings + ${
      preset.typography.bodyFont.split(',')[0]
    } body) are automatically applied to Zoya's artifacts and poster designs.`,
  };
}

// ============================================================================
// 3. CANVAS DESIGN IMPLEMENTATION (Philosophy Manifesto + HTML5 Poster Canvas)
// ============================================================================
function buildCanvasDesignSkill(userQuery: string): CanvasDesignSkillPayload {
  const preset = getActiveBrandPreset();
  const cleanedSubject =
    userQuery
      .replace(/^\/(poster|canvas)\s*/i, '')
      .replace(/\b(make|create|design|generate|a|an|poster|canvas|art|about|for|on|please|zoya)\b/gi, ' ')
      .replace(/\s+/g, ' ')
      .trim() || 'Chromatic Silence & Architectural Form';

  const posterTitle = cleanedSubject.toUpperCase();
  const lower = cleanedSubject.toLowerCase();

  let movementName = 'Chromatic Silence';
  let compositionStyle: CanvasDesignSkillPayload['compositionStyle'] = 'chromatic_silence';
  if (lower.includes('brutal') || lower.includes('architecture') || lower.includes('city') || lower.includes('grid')) {
    movementName = 'Brutalist Joy';
    compositionStyle = 'swiss_brutalist';
  } else if (lower.includes('music') || lower.includes('jazz') || lower.includes('energy') || lower.includes('motion') || lower.includes('tech')) {
    movementName = 'Kinetic Constructivism';
    compositionStyle = 'kinetic_construct';
  } else if (lower.includes('nature') || lower.includes('zen') || lower.includes('botanical') || lower.includes('calm')) {
    movementName = 'Analog Meditation';
    compositionStyle = 'analog_meditation';
  }

  const philosophyMarkdown = `# ${movementName}: A Design Philosophy for "${cleanedSubject}"

## 1. Space & Architectural Tension
 negative space is treated not as absence, but as an active structural material. Across the composition for **${cleanedSubject}**, generous warm-ivory fields (\`${preset.colors.light}\`) anchor precision-cut geometric masses in deep charcoal (\`${preset.colors.dark}\`). Every margin obeys an underlying Swiss modular grid.

## 2. Chromatic Discipline & Materiality
Color operates as pure emotional signal. Terracotta orange (\`${preset.colors.accentPrimary}\`) introduces kinetic focal energy against cool slate blue (\`${preset.colors.accentSecondary}\`) and grounded botanical sage (\`${preset.colors.accentTertiary}\`). Subtle tactile grain and fine registration hairlines evoke museum-grade archival printmaking.

## 3. Scale, Rhythm & Visual Hierarchy
Monumental geometric primitives intersect with micro-scale technical coordinates and calibration ticks. Rather than relying on heavy text, 90% of the narrative is communicated through proportion, concentric harmonic rings, and asymmetric balance.

## 4. Typographic Restraint
Typography whispers where form speaks. Display titles set in **Poppins** anchor the lower-third grid, paired with archival metadata and edition numbering in **Lora** — crafted as a collectible gallery artifact.`;

  const now = new Date();
  const refCode = `ZOYA-ARC-${now.getFullYear()}-${String(
    (cleanedSubject.length * 37) % 900 + 100
  )}`;

  return {
    kind: 'canvas-design',
    posterTitle: posterTitle.slice(0, 32),
    posterSubtitle: `AESTHETIC MONOGRAPH · ${movementName.toUpperCase()}`,
    movementName,
    philosophyMarkdown,
    referenceCode: refCode,
    dateStamp: now.toISOString().slice(0, 10),
    palette: {
      bg: preset.colors.light,
      fg: preset.colors.dark,
      accent1: preset.colors.accentPrimary,
      accent2: preset.colors.accentSecondary,
      accent3: preset.colors.accentTertiary,
      muted: preset.colors.midGray,
    },
    compositionStyle,
  };
}

// ============================================================================
// 4. CHANGELOG GENERATOR IMPLEMENTATION
// ============================================================================
function buildChangelogSkill(userQuery: string): ChangelogSkillPayload {
  const lines = userQuery
    .split(/\n|;|•/)
    .map((l) => l.trim())
    .filter((l) => l.length > 3);

  const features: string[] = [];
  const improvements: string[] = [];
  const fixes: string[] = [];
  const breaking: string[] = [];
  const security: string[] = [];
  let filteredOutCount = 0;

  // Check if user pasted commit lines
  const commitLines = lines.filter(
    (l) =>
      !/^(create|make|generate|summarize|turn).*changelog/i.test(l)
  );

  for (const rawLine of commitLines) {
    const clean = rawLine.replace(/^[-*•]\s*/, '').replace(/^[a-f0-9]{6,10}\s+/i, '');
    const lower = clean.toLowerCase();

    // Filter out internal noise per PDF instructions (refactor, test, chore, ci, lint)
    if (/^(chore|test|tests|ci|build|style|lint|merge branch|bump version)(\(.*\))?:/i.test(lower)) {
      filteredOutCount++;
      continue;
    }

    if (lower.includes('breaking') || /^[a-z]+(\(.*\))?!:/i.test(lower)) {
      breaking.push(
        clean.replace(/^[a-z]+(\(.*\))?!?:\s*/i, '').replace(/^breaking change:\s*/i, '')
      );
    } else if (lower.includes('security') || lower.includes('cve') || lower.includes('vuln') || lower.includes('auth')) {
      security.push(clean.replace(/^(sec|security)(\(.*\))?:\s*/i, ''));
    } else if (/^(feat|feature|add|new)(\(.*\))?:/i.test(lower) || lower.startsWith('added ') || lower.startsWith('add ')) {
      features.push(clean.replace(/^(feat|feature|add|new)(\(.*\))?:\s*/i, ''));
    } else if (/^(fix|bug|hotfix|patch)(\(.*\))?:/i.test(lower) || lower.includes('fixed ') || lower.includes('resolved ')) {
      fixes.push(clean.replace(/^(fix|bug|hotfix|patch)(\(.*\))?:\s*/i, ''));
    } else if (/^(perf|improve|enhance|update|refactor)(\(.*\))?:/i.test(lower) || clean.length > 10) {
      improvements.push(clean.replace(/^(perf|improve|enhance|update|refactor)(\(.*\))?:\s*/i, ''));
    }
  }

  // If the user didn't paste multi-line commits, provide a rich structured release note from their topic or recent app updates
  if (features.length === 0 && fixes.length === 0 && improvements.length <= 1) {
    filteredOutCount = 4;
    features.push(
      'Added interactive Artifacts Builder, Canvas Poster Designer, Changelog Generator, and Competitive Ad Analyzer skills inside Zoya Chat',
      'Added dedicated "Tool API Keys" settings screen with extensible key registry and Brand Guidelines configuration'
    );
    improvements.push(
      'Enhanced 3D & Anime Avatar switcher with instant live home screen rendering and smooth idle breathing motion',
      'Improved voice streaming responsiveness across all 23 supported Indian languages'
    );
    fixes.push(
      'Resolved ghost-arm layering artifact during idle avatar arm sway animation',
      'Fixed browser cache-busting headers to ensure Settings updates appear immediately'
    );
  }

  const capitalizeFirst = (s: string) => s.charAt(0).toUpperCase() + s.slice(1);

  const sections: ChangelogSkillPayload['sections'] = [];
  if (features.length > 0) {
    sections.push({ category: 'New Features', items: features.map(capitalizeFirst) });
  }
  if (improvements.length > 0) {
    sections.push({ category: 'Improvements', items: improvements.map(capitalizeFirst) });
  }
  if (fixes.length > 0) {
    sections.push({ category: 'Bug Fixes', items: fixes.map(capitalizeFirst) });
  }
  if (breaking.length > 0) {
    sections.push({ category: 'Breaking Changes', items: breaking.map(capitalizeFirst) });
  }
  if (security.length > 0) {
    sections.push({ category: 'Security', items: security.map(capitalizeFirst) });
  }

  const today = new Date().toISOString().slice(0, 10);
  const versionTitle = 'Version 2.4.0 — Release Notes';

  const mdLines: string[] = [
    `# ${versionTitle} (${today})`,
    '',
    `Customer-friendly summary of recent product updates (${filteredOutCount} internal refactor/chore commits filtered out).`,
    '',
  ];

  for (const sec of sections) {
    mdLines.push(`## ${sec.category}`);
    for (const item of sec.items) {
      mdLines.push(`- ${item}`);
    }
    mdLines.push('');
  }

  return {
    kind: 'changelog-generator',
    versionTitle,
    releaseDate: today,
    summaryIntro: `Transformed technical commit history into user-focused release notes (${filteredOutCount} internal noise commits filtered).`,
    filteredOutCount,
    sections,
    markdownText: mdLines.join('\n'),
  };
}

// ============================================================================
// 5. COMPETITIVE ADS EXTRACTOR IMPLEMENTATION
// ============================================================================
function buildCompetitiveAdsSkill(userQuery: string): CompetitiveAdsSkillPayload {
  const lower = userQuery.toLowerCase();
  const isLiveScrapeNotice =
    lower.includes('http://') ||
    lower.includes('https://') ||
    lower.includes('facebook.com/ads') ||
    lower.includes('linkedin.com/ad-library') ||
    lower.includes('scrape');

  const cleanedSubject =
    userQuery
      .replace(/^\/ads\s*/i, '')
      .replace(/\b(analyze|extract|competitor|competitive|ads|ad|copy|messaging|patterns|from|for|please|zoya)\b/gi, ' ')
      .replace(/\s+/g, ' ')
      .trim() || 'SaaS & Productivity AI Competitor Campaign';

  const subjectTitle =
    cleanedSubject.length > 65 ? cleanedSubject.slice(0, 62) + '...' : cleanedSubject;

  const problemsHighlighted = [
    {
      problem: 'Time Wasted on Repetitive Manual Workflows',
      copyHook: '"Stop spending 6 hours a week formatting reports and switching between 12 tabs."',
      whyItWorks: 'Quantifies a specific, painful weekly time loss and names the exact frustration (tab fatigue).',
    },
    {
      problem: 'Tool Fragmentation & Hidden Subscription Costs',
      copyHook: '"Replace 5disconnected tools with one unified workspace — at half the seat cost."',
      whyItWorks: 'Combines consolidation relief with immediate CFO/budget justification.',
    },
    {
      problem: 'Steep Learning Curve & Slow Team Onboarding',
      copyHook: '"Your team already knows how to use it. Zero training, live in 3 minutes."',
      whyItWorks: 'Eliminates implementation anxiety — the #1 objection to switching software.',
    },
  ];

  const creativePatterns = [
    {
      patternName: 'Pattern 1: Before / After Split Screen',
      formatStructure: 'Left side shows chaotic multi-tab workflow in muted red/gray; Right side shows single-click automated result.',
      effectivenessNote: 'Delivers instant visual contrast within 1.5 seconds of feed scroll.',
    },
    {
      patternName: 'Pattern 2: Specific Metric + Social Proof Hook',
      formatStructure: 'Opens with an exact number ("14,200+ teams saved 9.4 hrs/week") paired with a real customer quote.',
      effectivenessNote: 'Non-round numbers increase believability over generic "Save time!" claims.',
    },
    {
      patternName: 'Pattern 3: Interactive Product GIF / Micro-Demo',
      formatStructure: '5-second tight crop showing the exact "aha moment" action without UI clutter.',
      effectivenessNote: 'Demonstrates product value directly instead of making abstract promises.',
    },
  ];

  const copyFormulas = [
    {
      formulaName: 'Problem → Agitate → Instant Relief (PAS)',
      template: 'Still doing [painful task] manually? Every week it costs you [metric]. Switch to [Outcome] in [Timeframe].',
      exampleHeadline: 'Still building weekly changelogs by hand? Ship release notes in 30 seconds.',
    },
    {
      formulaName: 'Us vs. Old Way Contrast',
      template: 'The old way: [3 slow steps]. The new way: [1 automated step].',
      exampleHeadline: 'Old way: 4 hours in spreadsheets. New way: One prompt, instant live dashboard.',
    },
  ];

  const audienceInsights = [
    'Primary Segment: Product Managers, Founders, and Growth Marketers overwhelmed by manual ops.',
    'Buying Trigger: Frustration during weekly/monthly reporting or campaign launch bottlenecks.',
    'Top Objection Addressed: "Will this take weeks to set up?" -> Countered with "No credit card, 2-minute setup" CTAs.',
  ];

  const recommendations = [
    'Lead with a quantified pain hook ("Stop losing 6 hours/week to...") rather than feature lists.',
    'Pair every capability claim with a concrete visual artifact or before/after comparison.',
    'Test a low-friction CTA ("Try interactive demo — no signup") against standard "Start Free Trial".',
  ];

  const markdownReport = `# Competitive Ad Intelligence Report: ${subjectTitle}

## 1. Overview
- **Primary Messaging Themes**: Time reclamation, workflow consolidation, zero-setup onboarding
- **Dominant CTA Patterns**: "See it in action", "Start free (no card)", "Calculate your savings"

## 2. Key Problems Highlighted
${problemsHighlighted.map((p) => `- **${p.problem}**: ${p.copyHook} — *${p.whyItWorks}*`).join('\n')}

## 3. Successful Creative Patterns
${creativePatterns.map((c) => `- **${c.patternName}**: ${c.formatStructure} (*${c.effectivenessNote}*)`).join('\n')}

## 4. Copy Formulas That Work
${copyFormulas.map((f) => `- **${f.formulaName}**: \`${f.template}\`\n  - Example: *"${f.exampleHeadline}"*`).join('\n')}

## 5. Audience Targeting Insights
${audienceInsights.map((a) => `- ${a}`).join('\n')}

## 6. Actionable Recommendations
${recommendations.map((r) => `- ${r}`).join('\n')}`;

  return {
    kind: 'competitive-ads-extractor',
    competitorSubject: subjectTitle,
    isLiveScrapeNotice,
    overview: {
      totalAnalyzed: isLiveScrapeNotice ? 'Pasted Copy / Reference Analysis (Live Browser Scraping Disabled)' : 'Ad Messaging & Copy Pattern Extraction',
      primaryThemes: ['Time Reclamation', 'Workflow Consolidation', 'Zero-Friction Setup'],
      commonCtas: ['Try Interactive Demo', 'Start Free — No Credit Card', 'See 60s Walkthrough'],
    },
    problemsHighlighted,
    creativePatterns,
    copyFormulas,
    audienceInsights,
    recommendations,
    markdownReport,
  };
}

// ============================================================================
// 6. CONNECT APPS (COMPOSIO) IMPLEMENTATION
// ============================================================================
function buildConnectAppsSkill(userQuery: string): ConnectAppsSkillPayload {
  const lower = userQuery.toLowerCase();
  const composioKey = getToolApiKey('composio_api_key');
  const hasKey = hasToolApiKey('composio_api_key');

  let detectedApp = 'External App (Gmail / Slack / GitHub / Notion)';
  let detectedAction = 'COMPOSIO_MULTI_EXECUTE_TOOL';
  const actionParameters: Record<string, string> = {};

  let directIntentUrl: string | undefined;
  let fallbackActionLabel: string | undefined;

  if (lower.includes('gmail') || lower.includes('email') || lower.includes('mail')) {
    detectedApp = 'Gmail';
    detectedAction = 'GMAIL_SEND_EMAIL';
    actionParameters['App'] = 'Gmail (Google Workspace)';
    actionParameters['Operation'] = lower.includes('check') || lower.includes('read') ? 'Fetch Recent Threads' : 'Prepare & Send Email';
    actionParameters['Query / Content'] = userQuery;
    const recipient = userQuery.match(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/)?.[0] || '';
    directIntentUrl = `mailto:${recipient}?subject=${encodeURIComponent('Update from Zoya')}&body=${encodeURIComponent(userQuery)}`;
    fallbackActionLabel = 'Open Native Email Composer (mailto)';
  } else if (lower.includes('slack')) {
    detectedApp = 'Slack';
    detectedAction = 'SLACK_SEND_MESSAGE';
    actionParameters['App'] = 'Slack Workspace';
    actionParameters['Channel'] = lower.includes('#') ? (userQuery.match(/#[a-z0-9_-]+/i)?.[0] || '#general') : '#general';
    actionParameters['Message'] = userQuery;
    directIntentUrl = 'https://app.slack.com';
    fallbackActionLabel = 'Open Slack Web';
  } else if (lower.includes('github') || lower.includes('issue') || lower.includes('pr')) {
    detectedApp = 'GitHub';
    detectedAction = 'GITHUB_CREATE_ISSUE';
    actionParameters['App'] = 'GitHub Repositories';
    actionParameters['Operation'] = 'Create Issue / Inspect Pull Requests';
    actionParameters['Details'] = userQuery;
    directIntentUrl = 'https://github.com';
    fallbackActionLabel = 'Open GitHub';
  } else if (lower.includes('notion')) {
    detectedApp = 'Notion';
    detectedAction = 'NOTION_CREATE_PAGE';
    actionParameters['App'] = 'Notion Workspace';
    actionParameters['Operation'] = 'Create / Append Structured Page';
    actionParameters['Content'] = userQuery;
    directIntentUrl = 'https://www.notion.so';
    fallbackActionLabel = 'Open Notion';
  } else if (lower.includes('calendar')) {
    detectedApp = 'Google Calendar';
    detectedAction = 'GOOGLECALENDAR_CREATE_EVENT';
    actionParameters['App'] = 'Google Calendar';
    actionParameters['Operation'] = 'Schedule Calendar Event';
    actionParameters['Details'] = userQuery;
    directIntentUrl = `https://calendar.google.com/calendar/r/eventedit?text=${encodeURIComponent(userQuery)}`;
    fallbackActionLabel = 'Open Google Calendar Event Scheduler';
  } else {
    actionParameters['Target Services'] = 'Gmail, Slack, GitHub, Notion, Linear, Google Calendar';
    actionParameters['Command'] = userQuery;
    directIntentUrl = undefined;
  }

  const maskedKeyPreview = hasKey
    ? `${composioKey.slice(0, 6)}••••${composioKey.slice(-4)}`
    : 'Not Configured';

  const statusMessage = !hasKey
    ? `No Composio API Key configured. Action payload for ${detectedApp} is validated and ready. You can also use the 1-click native intent shortcut below to execute directly without any external API.`
    : `Composio API Key (${maskedKeyPreview}) verified in Settings → Tool API Keys. Action payload for ${detectedApp} (${detectedAction}) is prepared. Live external OAuth redirect is ready.`;

  return {
    kind: 'connect-apps',
    hasComposioKey: hasKey,
    maskedKeyPreview,
    detectedApp,
    detectedAction,
    actionParameters,
    statusMessage,
    directIntentUrl,
    fallbackActionLabel,
  };
}

/**
 * Executes a detected Part 1 skill and returns the structured result for Zoya's Chat UI + Voice TTS.
 */
export function executePart1Skill(
  skillId: Part1SkillId,
  userQuery: string
): Part1SkillExecutionResult {
  switch (skillId) {
    case 'artifacts-builder': {
      const output = buildInteractiveArtifact(userQuery);
      return {
        skillId,
        spokenSummary: `बॉस, मैंने आपके लिए "${output.title}" का इंटरैक्टिव आर्टिफैक्ट तैयार कर दिया है। आप चैट में लाइव स्लाइडर्स और कंट्रोल्स चला सकते हैं।`,
        chatText: `Here is your interactive **${output.title}** artifact, styled with **${output.brandApplied}** guidelines. You can interact with it live below, inspect the HTML source, or download the standalone bundle:`,
        output,
      };
    }

    case 'brand-guidelines': {
      const output = handleBrandGuidelinesSkill(userQuery);
      return {
        skillId,
        spokenSummary: `बॉस, ब्रांड गाइडलाइंस "${output.preset.name}" अब सक्रिय हैं। आपके सभी पोस्टर और आर्टिफैक्ट्स में यही कलर्स और फॉन्ट्स लगेंगे।`,
        chatText: output.summaryText,
        output,
      };
    }

    case 'canvas-design': {
      const output = buildCanvasDesignSkill(userQuery);
      return {
        skillId,
        spokenSummary: `बॉस, मैंने "${output.movementName}" डिज़ाइन फिलॉसफी के साथ आपका हाई-रेज़ोल्यूशन पोस्टर कैनवास तैयार कर दिया है। आप इसे पीएनजी में डाउनलोड कर सकते हैं।`,
        chatText: `Created a two-part **Canvas Design** masterwork: first formulating the **${output.movementName}** design philosophy manifesto, then expressing it on a high-craft poster canvas. You can download the high-res \`.png\` poster or the \`.md\` manifesto below:`,
        output,
      };
    }

    case 'changelog-generator': {
      const output = buildChangelogSkill(userQuery);
      return {
        skillId,
        spokenSummary: `बॉस, मैंने कमिट हिस्ट्री को साफ करके यूज़र-फ्रेंडली रिलीज़ नोट्स और चेंजलॉग तैयार कर दिया है।`,
        chatText: `${output.summaryIntro} You can copy the formatted Markdown or download \`CHANGELOG.md\` directly:`,
        output,
      };
    }

    case 'competitive-ads-extractor': {
      const output = buildCompetitiveAdsSkill(userQuery);
      return {
        skillId,
        spokenSummary: `बॉस, मैंने कॉम्पिटिटर ऐड्स के मैसेजिंग पैटर्न्स, प्रॉब्लम हुक्स और कॉपी फॉर्मूला का पूरा विश्लेषण तैयार कर दिया है।`,
        chatText: output.isLiveScrapeNotice
          ? `**Note on Live Ad Library Scraping**: Live headless-browser scraping of Facebook/LinkedIn Ad Library URLs is not available in this browser environment. Below is the structured **Competitive Ad Intelligence Breakdown** based on your query — paste any competitor ad copy or headlines to analyze them directly:`
          : `Extracted competitive ad messaging patterns, pain-point hooks, creative formats, and copy formulas for **${output.competitorSubject}**:`,
        output,
      };
    }

    case 'connect-apps': {
      const output = buildConnectAppsSkill(userQuery);
      return {
        skillId,
        spokenSummary: output.hasComposioKey
          ? `बॉस, आपकी कंपोज़ियो एपीआई की मिल गई है और ${output.detectedApp} एक्शन पेलोड तैयार है। लाइव ओऑथ कनेक्शन अभी प्रीव्यू मोड में है।`
          : `बॉस, एक्सटर्नल ऐप्स कनेक्ट करने के लिए कृपया सेटिंग्स में जाकर टूल एपीआई कीज़ के अंदर अपनी कंपोज़ियो एपीआई की दर्ज करें।`,
        chatText: output.statusMessage,
        output,
      };
    }
  }
}
