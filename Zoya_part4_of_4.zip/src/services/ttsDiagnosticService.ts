/**
 * Zoya AI – Complete TTS System Diagnostic Service
 * Strict 3-Engine Architecture:
 * 1. PRIMARY: ElevenLabs TTS (eleven_turbo_v2_5)
 * 2. BACKUP: Google Gemini Flash TTS (gemini-3.8-flash-lite-tts)
 * 3. FALLBACK: Google Gemini Live API (gemini-3.8-live)
 */

import { agentClient } from './agent/agentClient';

export interface TtsEngineInventoryItem {
  id: 'elevenlabs' | 'gemini-flash' | 'gemini-live';
  name: string;
  provider: 'ElevenLabs' | 'Google Gemini';
  model: string;
  role: 'PRIMARY' | 'BACKUP' | 'FALLBACK';
  engineType: 'Cloud Neural API' | 'Cloud Real-Time WebSocket';
  configured: boolean;
  active: boolean;
  endpoint: string;
  voiceName: string;
  voiceId?: string;
  apiKeyStatus: 'Configured (Server Env)' | 'Configured (Client)' | 'Missing';
  apiKeyMasked: string;
  enabled: boolean;
  description: string;
  testResult?: {
    testedAt?: string;
    success: boolean;
    audioGenerated: boolean;
    playbackSucceeded: boolean;
    latencyMs: number;
    statusCode?: number;
    errorMessage?: string;
    engineUsed?: string;
    mimeType?: string;
    details?: string;
  };
}

export interface TtsServerAuditData {
  status: string;
  timestamp: string;
  totalMainEngines: number;
  engines?: Array<{
    id: string;
    name: string;
    model: string;
    provider: string;
    role: string;
    configured: boolean;
    voiceId?: string;
    voiceName?: string;
  }>;
  env: {
    hasElevenLabsKey: boolean;
    hasGeminiKey: boolean;
    elevenLabsVoiceId: string;
    geminiDefaultVoice: string;
  };
  quota: {
    geminiCooldownActive: boolean;
    geminiCooldownRemainingSec: number;
  };
  cache: {
    inMemoryCount: number;
    inFlightDeduplications: number;
  };
  policy: {
    roboticSpeechSynthesisBlocked: boolean;
    androidSystemTtsBlockedInChat: boolean;
    offlineEmergencyTtsEnabled: boolean;
  };
}

export interface ElevenLabsConnectionTestResult {
  success: boolean;
  status: string;
  subscriptionTier?: string;
  characterCount?: number;
  characterLimit?: number;
  voiceId?: string;
  voiceName?: string;
  error?: string;
  latencyMs: number;
}

export interface FallbackChainVerificationResult {
  step1Primary: { engine: string; status: 'pass' | 'fail' | 'skipped'; latencyMs: number; message: string };
  step2Backup: { engine: string; status: 'pass' | 'fail' | 'skipped'; latencyMs: number; message: string };
  step3Fallback: { engine: string; status: 'pass' | 'fail' | 'skipped'; latencyMs: number; message: string };
  automaticFallbackWorking: boolean;
  misconfiguredFallback: boolean;
  simultaneousSpeakingRisk: boolean;
  roboticLeakagePrevented: boolean;
  summary: string;
}

export interface TtsFullDiagnosticReport {
  generatedAt: string;
  totalEnginesFound: number;
  actualPrimaryTts: string;
  actualBackupTts: string;
  actualFallbackTts: string;
  currentlyActiveTts: string;
  workingCount: number;
  failedCount: number;
  untestedCount: number;
  systemHealthScore: number;
  engines: TtsEngineInventoryItem[];
  fallbackChainAudit?: FallbackChainVerificationResult;
  serverAudit?: TtsServerAuditData;
}

/**
 * Fetch server-side TTS telemetry safely without revealing secrets
 */
export async function fetchServerTtsAudit(): Promise<TtsServerAuditData | null> {
  try {
    const res = await fetch('/api/tts/diagnostics', {
      method: 'GET',
      headers: agentClient.getOwnerFetchHeaders({ Accept: 'application/json' }),
      credentials: 'include',
    });
    if (res.ok) {
      return await res.json();
    }
  } catch (err) {
    console.warn('[TTS_DIAGNOSTIC] Failed to fetch server audit telemetry:', err);
  }
  return null;
}

/**
 * Audit and build the live TTS engine inventory for exactly 3 main engines
 */
export function buildTtsInventory(serverAudit: TtsServerAuditData | null): TtsEngineInventoryItem[] {
  let clientElevenVoiceId = '';
  let clientSelectedVoiceId = 'gemini-kore';

  if (typeof window !== 'undefined' && window.localStorage) {
    try {
      clientElevenVoiceId = (localStorage.getItem('zoya_elevenlabs_voice_id') || '').trim();
      clientSelectedVoiceId = localStorage.getItem('zoya_selected_voice_id') || 'gemini-kore';
    } catch {}
  }

  const hasElevenLabs = Boolean(serverAudit?.env?.hasElevenLabsKey);
  const hasGemini = Boolean(serverAudit?.env?.hasGeminiKey || true);

  const effectiveElevenVoiceId =
    clientElevenVoiceId || serverAudit?.env?.elevenLabsVoiceId || '21m00Tcm4TlvDq8ikWAM';
  const geminiVoice = clientSelectedVoiceId.startsWith('gemini-')
    ? clientSelectedVoiceId.replace('gemini-', '').toUpperCase()
    : 'KORE';

  const inventory: TtsEngineInventoryItem[] = [
    {
      id: 'elevenlabs',
      name: 'ElevenLabs TTS',
      provider: 'ElevenLabs',
      model: 'eleven_turbo_v2_5',
      role: 'PRIMARY',
      engineType: 'Cloud Neural API',
      configured: hasElevenLabs,
      active: hasElevenLabs,
      endpoint: 'POST /api/tts (Server Proxy)',
      voiceName: `Voice ID: ${effectiveElevenVoiceId.slice(0, 10)}... (Rachel/Custom)`,
      voiceId: effectiveElevenVoiceId,
      apiKeyStatus: hasElevenLabs ? 'Configured (Server Env)' : 'Missing',
      apiKeyMasked: hasElevenLabs ? 'Configured: Yes (Server)' : 'Configured: No',
      enabled: hasElevenLabs,
      description:
        'Primary voice synthesis engine. Ultra-fast natural neural audio streaming via server-side ElevenLabs Turbo proxy.',
    },
    {
      id: 'gemini-flash',
      name: 'Google Gemini Flash TTS',
      provider: 'Google Gemini',
      model: 'gemini-3.8-flash-lite-tts',
      role: 'BACKUP',
      engineType: 'Cloud Neural API',
      configured: hasGemini,
      active: !hasElevenLabs, // Active backup taking over when ElevenLabs is not set or fails
      endpoint: 'POST /api/tts (Backup Failover)',
      voiceName: `${geminiVoice} (24kHz HD WAV)`,
      apiKeyStatus: serverAudit?.env?.hasGeminiKey ? 'Configured (Server Env)' : 'Missing',
      apiKeyMasked: serverAudit?.env?.hasGeminiKey ? 'Configured: Yes (Server)' : 'Configured: No',
      enabled: true,
      description:
        'Backup voice engine. Activates automatically if ElevenLabs fails, times out, or has no key configured. Produces studio-grade 24kHz HD audio.',
    },
    {
      id: 'gemini-live',
      name: 'Google Gemini Live API',
      provider: 'Google Gemini',
      model: 'gemini-3.8-live',
      role: 'FALLBACK',
      engineType: 'Cloud Real-Time WebSocket',
      configured: hasGemini,
      active: false,
      endpoint: 'POST /api/tts (WebSocket Fallback)',
      voiceName: `${geminiVoice} (Bidirectional Audio)`,
      apiKeyStatus: serverAudit?.env?.hasGeminiKey ? 'Configured (Server Env)' : 'Missing',
      apiKeyMasked: serverAudit?.env?.hasGeminiKey ? 'Configured: Yes (Server)' : 'Configured: No',
      enabled: true,
      description:
        'Final fallback voice engine. Activates only when both ElevenLabs and Gemini Flash fail (e.g. RPM quota cooldown). Connects via real-time WebSocket.',
    },
  ];

  return inventory;
}

/**
 * Test ElevenLabs connection and voice ID against ElevenLabs API
 */
export async function testElevenLabsConnection(
  voiceId?: string
): Promise<ElevenLabsConnectionTestResult> {
  const t0 = performance.now();
  let voiceToUse = voiceId?.trim() || '';

  if (!voiceToUse && typeof window !== 'undefined') {
    try {
      voiceToUse = (localStorage.getItem('zoya_elevenlabs_voice_id') || '').trim();
    } catch {}
  }

  try {
    const res = await fetch('/api/elevenlabs/test-connection', {
      method: 'POST',
      headers: agentClient.getOwnerFetchHeaders({ 'Content-Type': 'application/json' }),
      credentials: 'include',
      body: JSON.stringify({
        voiceId: voiceToUse || undefined,
      }),
    });

    const latency = Math.round(performance.now() - t0);
    const data = await res.json().catch(() => ({}));

    if (res.ok && data?.success) {
      return {
        success: true,
        status: 'Connected & Verified',
        subscriptionTier: data.subscriptionTier || 'active',
        characterCount: data.characterCount,
        characterLimit: data.characterLimit,
        voiceId: data.voiceId,
        voiceName: data.voiceName,
        latencyMs: latency,
      };
    } else {
      return {
        success: false,
        status: 'Connection Failed',
        error: data?.error || `HTTP ${res.status}: Verification failed`,
        latencyMs: latency,
      };
    }
  } catch (err: any) {
    return {
      success: false,
      status: 'Network Error',
      error: err?.message || String(err),
      latencyMs: Math.round(performance.now() - t0),
    };
  }
}

/**
 * Execute an independent test of any single detected TTS engine
 */
export async function testIndividualTtsEngine(
  engineId: TtsEngineInventoryItem['id'],
  testPhrase: string = 'नमस्ते! मैं ज़ोया हूँ, आपकी एआई साथी।'
): Promise<NonNullable<TtsEngineInventoryItem['testResult']>> {
  const t0 = performance.now();

  let clientElevenVoiceId = '';
  if (typeof window !== 'undefined') {
    try {
      clientElevenVoiceId = (localStorage.getItem('zoya_elevenlabs_voice_id') || '').trim();
    } catch {}
  }

  try {
    const res = await fetch('/api/tts', {
      method: 'POST',
      headers: agentClient.getOwnerFetchHeaders({ 'Content-Type': 'application/json' }),
      credentials: 'include',
      body: JSON.stringify({
        text: testPhrase,
        language: 'hi-IN',
        forceEngine: engineId,
        elevenLabsVoiceId: clientElevenVoiceId || undefined,
      }),
    });

    const latency = Math.round(performance.now() - t0);
    const contentType = res.headers.get('content-type') || '';
    let data: any = null;

    if (contentType.includes('application/json')) {
      data = await res.json().catch(() => ({}));
    } else {
      const txt = await res.text().catch(() => '');
      return {
        testedAt: new Date().toLocaleTimeString(),
        success: false,
        audioGenerated: false,
        playbackSucceeded: false,
        latencyMs: latency,
        statusCode: res.status,
        errorMessage: `Server returned non-JSON response: ${txt.slice(0, 100)}`,
      };
    }

    if (data?.audioData) {
      let playbackOk = false;
      let playbackErrMsg: string | undefined;
      try {
        const mime = data.mimeType || 'audio/wav';
        const audio = new Audio(`data:${mime};base64,${data.audioData}`);
        audio.volume = 0.5;
        const playPromise = audio.play();
        if (playPromise !== undefined) {
          await playPromise;
          playbackOk = true;
          setTimeout(() => {
            try {
              audio.pause();
              audio.src = '';
            } catch {}
          }, 2500);
        } else {
          playbackOk = true;
        }
      } catch (playErr: any) {
        console.warn('[TTS_TEST] Audio playback failed:', playErr);
        playbackOk = false;
        playbackErrMsg = playErr?.message || String(playErr || 'Audio playback failed');
      }

      return {
        testedAt: new Date().toLocaleTimeString(),
        success: playbackOk,
        audioGenerated: true,
        playbackSucceeded: playbackOk,
        latencyMs: latency,
        statusCode: res.status,
        engineUsed: data.engineUsed || data.engine || engineId,
        mimeType: data.mimeType || 'audio/wav',
        errorMessage: playbackOk ? undefined : `Audio generated (${data.model || engineId}) but speaker playback failed: ${playbackErrMsg || 'blocked'}`,
        details: playbackOk
          ? `Audio successfully generated (${data.model || engineId}) and speaker playback started cleanly.`
          : `Audio generated (${data.model || engineId}) but speaker playback threw an error.`,
      };
    }

    const errorReason =
      data?.error ||
      (data?.diagnostics &&
        Object.values(data.diagnostics)
          .filter(Boolean)
          .join(' | ')) ||
      'No audio payload generated';

    return {
      testedAt: new Date().toLocaleTimeString(),
      success: false,
      audioGenerated: false,
      playbackSucceeded: false,
      latencyMs: latency,
      statusCode: res.status,
      errorMessage: errorReason,
      details: data?.quotaExhausted
        ? `Quota cooldown active (${data.retryAfter || 45}s remaining).`
        : undefined,
    };
  } catch (err: any) {
    return {
      testedAt: new Date().toLocaleTimeString(),
      success: false,
      audioGenerated: false,
      playbackSucceeded: false,
      latencyMs: Math.round(performance.now() - t0),
      errorMessage: err?.message || String(err),
    };
  }
}

/**
 * Perform full Primary -> Backup -> Fallback Chain Verification:
 * Step 1: ElevenLabs TTS
 * Step 2: Google Gemini Flash TTS
 * Step 3: Google Gemini Live API
 */
export async function runFallbackChainAudit(): Promise<FallbackChainVerificationResult> {
  const result: FallbackChainVerificationResult = {
    step1Primary: { engine: 'ElevenLabs TTS (Primary)', status: 'skipped', latencyMs: 0, message: '' },
    step2Backup: { engine: 'Google Gemini Flash TTS (Backup)', status: 'skipped', latencyMs: 0, message: '' },
    step3Fallback: { engine: 'Google Gemini Live API (Fallback)', status: 'skipped', latencyMs: 0, message: '' },
    automaticFallbackWorking: false,
    misconfiguredFallback: false,
    simultaneousSpeakingRisk: false,
    roboticLeakagePrevented: false,
    summary: '',
  };

  let clientElevenVoiceId = '';
  if (typeof window !== 'undefined') {
    try {
      clientElevenVoiceId = (localStorage.getItem('zoya_elevenlabs_voice_id') || '').trim();
    } catch {}
  }

  let serverBlockedRobotic = false;

  // Step 1: Test Primary Engine (ElevenLabs)
  const t0 = performance.now();
  try {
    const res = await fetch('/api/tts', {
      method: 'POST',
      headers: agentClient.getOwnerFetchHeaders({ 'Content-Type': 'application/json' }),
      credentials: 'include',
      body: JSON.stringify({
        text: 'नमस्ते, प्राथमिक टेस्ट।',
        language: 'hi-IN',
        forceEngine: 'elevenlabs',
        elevenLabsVoiceId: clientElevenVoiceId || undefined,
      }),
    });
    const dt = Math.round(performance.now() - t0);
    const data = await res.json().catch(() => ({}));

    if (data?.audioData) {
      result.step1Primary = {
        engine: 'ElevenLabs TTS (Primary)',
        status: 'pass',
        latencyMs: dt,
        message: `Primary ElevenLabs engine generated audio in ${dt}ms (${data.model || 'turbo'}).`,
      };
    } else {
      result.step1Primary = {
        engine: 'ElevenLabs TTS (Primary)',
        status: 'fail',
        latencyMs: dt,
        message: data.error || 'ElevenLabs API Key not configured on server (Failover trigger active)',
      };
    }

    if (data?.roboticFallbackBlocked === true) {
      serverBlockedRobotic = true;
    }
  } catch (err: any) {
    result.step1Primary = {
      engine: 'ElevenLabs TTS (Primary)',
      status: 'fail',
      latencyMs: Math.round(performance.now() - t0),
      message: err?.message || 'Connection error',
    };
  }

  // Step 2: Test Backup Engine (Google Gemini Flash TTS)
  const t1 = performance.now();
  try {
    const resBackup = await fetch('/api/tts', {
      method: 'POST',
      headers: agentClient.getOwnerFetchHeaders({ 'Content-Type': 'application/json' }),
      credentials: 'include',
      body: JSON.stringify({
        text: 'नमस्ते, बैकअप जेमिनी फ्लैश टेस्ट।',
        language: 'hi-IN',
        forceEngine: 'gemini-flash',
      }),
    });
    const dtBackup = Math.round(performance.now() - t1);
    const dataBackup = await resBackup.json().catch(() => ({}));

    if (dataBackup?.roboticFallbackBlocked === true) {
      serverBlockedRobotic = true;
    }

    if (dataBackup?.audioData) {
      result.step2Backup = {
        engine: 'Google Gemini Flash TTS (Backup)',
        status: 'pass',
        latencyMs: dtBackup,
        message: `Backup Gemini Flash engine generated 24kHz HD WAV in ${dtBackup}ms.`,
      };
    } else if (dataBackup?.quotaExhausted) {
      result.step2Backup = {
        engine: 'Google Gemini Flash TTS (Backup)',
        status: 'fail',
        latencyMs: dtBackup,
        message: `Gemini Flash TTS quota exhausted (${dataBackup.retryAfter || 45}s cooldown) — no audio returned.`,
      };
      result.misconfiguredFallback = true;
    } else {
      result.step2Backup = {
        engine: 'Google Gemini Flash TTS (Backup)',
        status: 'fail',
        latencyMs: dtBackup,
        message: dataBackup?.error || 'Gemini Flash synthesis failed (no audio payload).',
      };
      result.misconfiguredFallback = true;
    }
  } catch (err: any) {
    result.step2Backup = {
      engine: 'Google Gemini Flash TTS (Backup)',
      status: 'fail',
      latencyMs: Math.round(performance.now() - t1),
      message: err?.message || 'Network error',
    };
    result.misconfiguredFallback = true;
  }

  // Step 3: Test Fallback Engine (Google Gemini Live API)
  const t2 = performance.now();
  try {
    const resFallback = await fetch('/api/tts', {
      method: 'POST',
      headers: agentClient.getOwnerFetchHeaders({ 'Content-Type': 'application/json' }),
      credentials: 'include',
      body: JSON.stringify({
        text: 'नमस्ते, फॉलबैक जेमिनी लाइव टेस्ट।',
        language: 'hi-IN',
        forceEngine: 'gemini-live',
      }),
    });
    const dtFallback = Math.round(performance.now() - t2);
    const dataFallback = await resFallback.json().catch(() => ({}));

    if (dataFallback?.roboticFallbackBlocked === true) {
      serverBlockedRobotic = true;
    }

    if (dataFallback?.audioData) {
      result.step3Fallback = {
        engine: 'Google Gemini Live API (Fallback)',
        status: 'pass',
        latencyMs: dtFallback,
        message: `Fallback Live API real-time audio generated in ${dtFallback}ms.`,
      };
    } else if (dataFallback?.quotaExhausted) {
      result.step3Fallback = {
        engine: 'Google Gemini Live API (Fallback)',
        status: 'fail',
        latencyMs: dtFallback,
        message: `Gemini Live API quota exhausted (${dataFallback.retryAfter || 45}s cooldown) — no audio returned.`,
      };
    } else {
      result.step3Fallback = {
        engine: 'Google Gemini Live API (Fallback)',
        status: 'fail',
        latencyMs: dtFallback,
        message: dataFallback?.error || 'Gemini Live API returned no audio payload.',
      };
    }
  } catch (err: any) {
    result.step3Fallback = {
      engine: 'Google Gemini Live API (Fallback)',
      status: 'fail',
      latencyMs: Math.round(performance.now() - t2),
      message: err?.message || 'Gemini Live API connection failed',
    };
  }

  result.roboticLeakagePrevented = serverBlockedRobotic;
  result.automaticFallbackWorking =
    result.step2Backup.status === 'pass' || result.step3Fallback.status === 'pass';

  result.summary =
    result.step2Backup.status === 'pass' && result.step3Fallback.status === 'pass'
      ? 'Automatic failover chain (ElevenLabs → Gemini Flash → Gemini Live) verified with real audio.'
      : result.automaticFallbackWorking
      ? 'Partial failover verified: one backup engine returned audio while another failed.'
      : 'Failover chain FAILED: backup and fallback engines did not return audio.';

  return result;
}
