import dns from 'node:dns';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import type { Express, NextFunction, Request, Response } from 'express';
import { GoogleGenAI, ThinkingLevel } from '@google/genai';

const DATA_DIR = path.resolve(process.cwd(), 'data');
const PUBLISHED_SITES_DIR = path.join(DATA_DIR, 'published_sites');
const PUBLISHED_REGISTRY_FILE = path.join(DATA_DIR, 'published_sites_registry.json');

export interface PublishedSiteRecord {
  slug: string;
  title: string;
  publishedAt: string;
  updatedAt: string;
  customDomain: string | null;
  verificationToken: string | null;
  domainVerified: boolean;
  httpsStatus: 'active' | 'pending_dns' | 'unconfigured';
  fileCount: number;
}

function ensureStorageDirs(): void {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  if (!fs.existsSync(PUBLISHED_SITES_DIR)) {
    fs.mkdirSync(PUBLISHED_SITES_DIR, { recursive: true });
  }
}

function readRegistry(): Record<string, PublishedSiteRecord> {
  ensureStorageDirs();
  try {
    if (!fs.existsSync(PUBLISHED_REGISTRY_FILE)) return {};
    const raw = fs.readFileSync(PUBLISHED_REGISTRY_FILE, 'utf8');
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === 'object' ? parsed : {};
  } catch {
    return {};
  }
}

function writeRegistry(registry: Record<string, PublishedSiteRecord>): void {
  ensureStorageDirs();
  fs.writeFileSync(PUBLISHED_REGISTRY_FILE, JSON.stringify(registry, null, 2), 'utf8');
}

function sanitizeSlug(input: string): string {
  const base = (input || 'site')
    .toLowerCase()
    .replace(/[^a-z0-9-]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 48);
  return base || `site-${crypto.randomBytes(3).toString('hex')}`;
}

function sanitizeDomain(input: string): string {
  return (input || '')
    .trim()
    .toLowerCase()
    .replace(/^https?:\/\//, '')
    .replace(/\/.*$/, '')
    .replace(/:\d+$/, '')
    .trim();
}

function isValidDomainName(domain: string): boolean {
  if (!domain || domain.length > 253) return false;
  return /^(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/.test(domain);
}

function createGeminiClient(apiKeyOverride?: string): GoogleGenAI | null {
  const key = (apiKeyOverride && apiKeyOverride.trim()) || process.env.GEMINI_API_KEY;
  if (!key) return null;
  return new GoogleGenAI({
    apiKey: key,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

const MIME_BY_EXT: Record<string, string> = {
  '.html': 'text/html; charset=utf-8',
  '.htm': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.gif': 'image/gif',
  '.ico': 'image/x-icon',
  '.txt': 'text/plain; charset=utf-8',
};

function serveSiteFile(res: Response, siteSlug: string, relFilePath: string): boolean {
  const siteDir = path.resolve(PUBLISHED_SITES_DIR, sanitizeSlug(siteSlug));
  if (!fs.existsSync(siteDir)) return false;

  const cleanRel = (relFilePath || 'index.html').replace(/^\/+/, '') || 'index.html';
  const targetPath = path.resolve(siteDir, cleanRel);
  if (!targetPath.startsWith(siteDir + path.sep) && targetPath !== path.join(siteDir, 'index.html')) {
    return false;
  }

  let finalPath = targetPath;
  if (!fs.existsSync(finalPath) || fs.statSync(finalPath).isDirectory()) {
    const indexFallback = path.join(siteDir, 'index.html');
    if (cleanRel === 'index.html' || !cleanRel.includes('.')) {
      finalPath = indexFallback;
    } else {
      return false;
    }
  }

  if (!fs.existsSync(finalPath)) return false;
  const ext = path.extname(finalPath).toLowerCase();
  const contentType = MIME_BY_EXT[ext] || 'application/octet-stream';
  res.setHeader('Content-Type', contentType);
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate');
  fs.createReadStream(finalPath).pipe(res);
  return true;
}

/**
 * Middleware mounted BEFORE Vite / static SPA catch-all in server.ts.
 * Serves published websites both via `/sites/:slug/...` AND via connected Custom Domain `Host` headers.
 */
export function createPublishedSiteMiddleware() {
  return (req: Request, res: Response, next: NextFunction) => {
    try {
      // 1. Check Custom Domain Host header mapping first (ignoring /api/* routes)
      const rawHost = String(req.headers['x-forwarded-host'] || req.headers.host || '')
        .split(',')[0]
        .split(':')[0]
        .trim()
        .toLowerCase();

      if (
        rawHost &&
        rawHost !== 'localhost' &&
        rawHost !== '127.0.0.1' &&
        !rawHost.endsWith('.run.app') &&
        !req.path.startsWith('/api/')
      ) {
        const registry = readRegistry();
        const matched = Object.values(registry).find(
          (site) => site.customDomain && site.customDomain.toLowerCase() === rawHost
        );
        if (matched) {
          const served = serveSiteFile(res, matched.slug, req.path === '/' ? 'index.html' : req.path);
          if (served) return;
        }
      }

      // 2. Serve /sites/:slug and /sites/:slug/*
      if (req.path.startsWith('/sites/')) {
        const rest = req.path.slice('/sites/'.length);
        const slashIdx = rest.indexOf('/');
        if (slashIdx === -1) {
          // Ensure trailing slash so relative ./styles.css, ./app.js, ./assets/... resolve under /sites/:slug/
          if (!req.originalUrl.split('?')[0].endsWith('/')) {
            return res.redirect(302, `/sites/${encodeURIComponent(rest)}/`);
          }
          const served = serveSiteFile(res, rest, 'index.html');
          if (served) return;
          return res.status(404).send('Published site not found.');
        }

        const slug = decodeURIComponent(rest.slice(0, slashIdx));
        const subPath = decodeURIComponent(rest.slice(slashIdx + 1)) || 'index.html';
        const served = serveSiteFile(res, slug, subPath);
        if (served) return;
        return res.status(404).send('File not found in published site.');
      }
    } catch (err) {
      console.warn('[PUBLISHED_SITES] Middleware error:', err);
    }
    return next();
  };
}

function buildSystemInstruction(mode: 'create' | 'edit', languageHint?: string): string {
  const modeGuidance =
    mode === 'edit'
      ? `MODE: ITERATIVE EDIT OF AN EXISTING WEBSITE.
The user wants to modify the existing website files provided in their message.
Preserve sections, copy, uploaded image paths (like ./assets/...), and scripts that the user did not ask to remove or change, while cleanly applying every requested change across styles.css, index.html, and app.js.`
      : `MODE: CREATE FROM BLANK CANVAS.
Build a completely original, bespoke website from scratch tailored 100% to the user's description.
Do NOT reuse any fixed template or boilerplate copy. Design the sections, copy, layout, color palette, typography, and interactive JavaScript features purely around what the user asked for. If the user gave a short request (like "build a website"), craft a refined, original website concept (for example an authentic personal studio, boutique brand, or service showcase in the user's language) with full domain-specific copy and real interactive controls.`;

  return `You are an expert senior frontend web engineer and designer.
${modeGuidance}

STRICT OUTPUT PROTOCOL — YOU MUST OUTPUT EXACTLY THESE THREE DELIMITED FILE BLOCKS IN THIS EXACT ORDER, WITH NO MARKDOWN FENCES (\`\`\`), NO EXPLANATIONS, AND NO EXTRA PROSE BEFORE OR AFTER:

<<<FILE:styles.css>>>
/* complete responsive CSS including :root custom color properties */
<<<FILE:index.html>>>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>...</title>
  <link rel="stylesheet" href="./styles.css">
</head>
<body>
  <!-- Semantic <header>, multiple real <section> blocks, and <footer> -->
  <script src="./app.js" defer></script>
</body>
</html>
<<<FILE:app.js>>>
/* real interactive vanilla JavaScript for navigation, forms, tabs, filters, modals, calculators, etc. */
<<<END>>>

DESIGN & ENGINEERING RULES:
1. Language Match: Write all visible copy, headings, buttons, navigation links, labels, and footer text in the exact language requested or used by the user (for example, if the prompt is in Hinglish/Hindi like "ek cafe ki website banao", write natural, authentic Hindi/Hinglish copy or Devanagari/Roman Hindi matching the user's request; if in English, write natural English)${languageHint ? ` (fallback UI language hint: ${languageHint}, only if user prompt is ambiguous)` : ''}.
2. Complete Structure & Semantics: Include a clean <header>, 4–6 rich, domain-authentic <section> blocks (each <section> having a unique id), and a <footer>. Never emit placeholder "Lorem ipsum" text.
3. Palette & CSS Variables: Define clear color variables inside :root in styles.css (for example --bg-color, --surface-color, --text-color, --muted-color, --primary-color, --accent-color) and use them consistently so custom color edits work seamlessly. Pick an aesthetic, domain-authentic color palette that matches the user's requested mood/colors. Use system font stacks alongside optional clean styling so the downloaded site looks sharp offline without network access.
4. Zero Broken External Image URLs: NEVER use unsplash.com, picsum.photos, placeholder.com, via.placeholder.com, or unverified external image URLs. For illustrations, logos, product visuals, or hero graphics, embed crisp custom inline <svg> illustrations OR <img src="data:image/svg+xml;utf8,..." alt="..."> with rich bespoke SVG graphics (URL-encoded cleanly) so the site works 100% offline with zero broken images! If editing an existing site that already has ./assets/... or user image URLs, keep them intact unless asked to replace them.
5. Real Interactivity in app.js: Wire mobile menu toggles, smooth scroll, interactive calculators/filters/cart/forms/tabs/booking modals as relevant to the website, and clean inline status messages (never window.alert).
6. Output cleanliness: NEVER wrap the output in markdown code blocks (\`\`\`html or \`\`\`css). Start immediately with <<<FILE:styles.css>>> and end immediately after <<<END>>>.`;
}

export function registerWebsiteBuilderRoutes(app: Express): void {
  // 1. Live Streaming Website Generation & Iterative Editing (SSE)
  app.post('/api/website-builder/stream', async (req: Request, res: Response) => {
    const prompt = typeof req.body?.prompt === 'string' ? req.body.prompt.trim() : '';
    const mode: 'create' | 'edit' = req.body?.mode === 'edit' ? 'edit' : 'create';
    const language = typeof req.body?.language === 'string' ? req.body.language.trim() : '';
    const currentFiles = req.body?.currentFiles as
      | { html?: string; css?: string; js?: string }
      | undefined;
    const geminiApiKey = typeof req.body?.geminiApiKey === 'string' ? req.body.geminiApiKey : undefined;

    if (!prompt) {
      return res.status(400).json({ error: 'Please describe the website you want to build or change.' });
    }

    const ai = createGeminiClient(geminiApiKey);
    if (!ai) {
      return res.status(503).json({
        error: 'Gemini API key is not configured on the server. Set GEMINI_API_KEY in environment secrets.',
      });
    }

    res.setHeader('Content-Type', 'text/event-stream; charset=utf-8');
    res.setHeader('Cache-Control', 'no-cache, no-transform');
    res.setHeader('Connection', 'keep-alive');
    res.flushHeaders?.();

    const writeEvent = (payload: Record<string, unknown>) => {
      if (!res.writableEnded) {
        res.write(`data: ${JSON.stringify(payload)}\n\n`);
      }
    };

    let clientClosed = false;
    res.on('close', () => {
      if (!res.writableFinished) {
        clientClosed = true;
      }
    });

    const userContent =
      mode === 'edit' && currentFiles
        ? `EXISTING WEBSITE FILES:\n\n<<<FILE:styles.css>>>\n${currentFiles.css || ''}\n\n<<<FILE:index.html>>>\n${currentFiles.html || ''}\n\n<<<FILE:app.js>>>\n${currentFiles.js || ''}\n\nREQUESTED CHANGES:\n${prompt}`
        : `BUILD THIS WEBSITE FROM A BLANK CANVAS:\n${prompt}`;

    const systemInstruction = buildSystemInstruction(mode, language);
    const modelsToTry = [
      { name: 'gemini-4-hydrogen', config: { systemInstruction } },
      {
        name: 'gemini-3.1-flash-lite',
        config: { systemInstruction, thinkingConfig: { thinkingLevel: ThinkingLevel.LOW } },
      },
    ];

    try {
      writeEvent({
        type: 'status',
        phase: 'connecting',
        message: mode === 'edit' ? 'Applying changes live...' : 'Starting live website build...',
      });

      let emittedChars = 0;
      let lastErrorMsg = '';
      const OPEN_TIMEOUT_MS = 10000;
      const CHUNK_TIMEOUT_MS = 18000;

      for (const modelEntry of modelsToTry) {
        if (clientClosed || res.writableEnded || emittedChars > 0) break;
        try {
          console.log(`[WEBSITE_BUILDER_STREAM] Starting stream with ${modelEntry.name} (mode=${mode})`);
          let openTimer: ReturnType<typeof setTimeout> | null = null;
          const stream = await Promise.race([
            ai.models.generateContentStream({
              model: modelEntry.name,
              contents: userContent,
              config: modelEntry.config,
            }),
            new Promise<null>((resolve) => {
              openTimer = setTimeout(() => resolve(null), OPEN_TIMEOUT_MS);
            }),
          ]);
          if (openTimer) clearTimeout(openTimer);

          if (!stream) {
            lastErrorMsg = `Model ${modelEntry.name} timed out before opening stream.`;
            console.warn(`[WEBSITE_BUILDER_STREAM] ${lastErrorMsg}`);
            continue;
          }

          const iterator = stream[Symbol.asyncIterator]();
          let stalledMidStream = false;

          while (!clientClosed && !res.writableEnded) {
            let chunkTimer: ReturnType<typeof setTimeout> | null = null;
            const step = await Promise.race([
              iterator.next().then((r) => ({ timedOut: false as const, r })),
              new Promise<{ timedOut: true }>((resolve) => {
                chunkTimer = setTimeout(() => resolve({ timedOut: true }), CHUNK_TIMEOUT_MS);
              }),
            ]);
            if (chunkTimer) clearTimeout(chunkTimer);

            if (step.timedOut) {
              if (typeof iterator.return === 'function') {
                Promise.resolve(iterator.return(undefined)).catch(() => {});
              }
              stalledMidStream = true;
              lastErrorMsg =
                emittedChars === 0
                  ? `Model ${modelEntry.name} timed out before emitting code.`
                  : 'Live code stream stalled mid-generation. Please retry.';
              console.warn(`[WEBSITE_BUILDER_STREAM] ${lastErrorMsg}`);
              break;
            }

            if (step.r.done) {
              break;
            }

            const chunkText = step.r.value?.text || '';
            if (chunkText) {
              emittedChars += chunkText.length;
              writeEvent({ type: 'chunk', text: chunkText });
            }
          }

          if (stalledMidStream && emittedChars > 0) {
            writeEvent({ type: 'error', message: lastErrorMsg });
            break;
          }
          if (emittedChars > 0) {
            writeEvent({ type: 'done' });
            break;
          }
        } catch (modelErr: any) {
          lastErrorMsg = modelErr?.message || `Model ${modelEntry.name} failed.`;
          console.error(`[WEBSITE_BUILDER_STREAM] ${modelEntry.name} error:`, modelErr);
        }
      }

      if (emittedChars === 0 && !clientClosed && !res.writableEnded) {
        writeEvent({
          type: 'error',
          message: lastErrorMsg || 'Model returned an empty response. Please try describing your site again.',
        });
      }
    } catch (err: any) {
      console.error('[WEBSITE_BUILDER_STREAM] Gemini generation error:', err);
      writeEvent({
        type: 'error',
        message: err?.message || 'Failed to stream website code from Gemini.',
      });
    } finally {
      if (!res.writableEnded) {
        res.write('data: [DONE]\n\n');
        res.end();
      }
    }
  });

  // 2. List Published Sites
  app.get('/api/published-sites', (_req: Request, res: Response) => {
    const registry = readRegistry();
    const sites = Object.values(registry).sort(
      (a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()
    );
    return res.json({ success: true, sites });
  });

  // 3. Publish or Update a Website at /sites/:slug/
  app.post('/api/published-sites', (req: Request, res: Response) => {
    try {
      ensureStorageDirs();
      const rawTitle = typeof req.body?.title === 'string' ? req.body.title.trim() : 'Custom Website';
      const requestedSlug = typeof req.body?.slug === 'string' ? req.body.slug.trim() : '';
      const existingSlug = typeof req.body?.existingSlug === 'string' ? req.body.existingSlug.trim() : '';
      const files = req.body?.files as {
        html?: string;
        css?: string;
        js?: string;
        assets?: Array<{ path: string; dataUrl: string }>;
      };

      if (!files || typeof files.html !== 'string' || !files.html.trim()) {
        return res.status(400).json({ success: false, error: 'Website HTML is required before publishing.' });
      }

      const registry = readRegistry();
      let slug = existingSlug ? sanitizeSlug(existingSlug) : sanitizeSlug(requestedSlug || rawTitle);

      if (!existingSlug && registry[slug]) {
        slug = `${slug}-${crypto.randomBytes(2).toString('hex')}`;
      }

      const siteDir = path.join(PUBLISHED_SITES_DIR, slug);
      const assetsDir = path.join(siteDir, 'assets');
      if (fs.existsSync(siteDir)) {
        fs.rmSync(siteDir, { recursive: true, force: true });
      }
      fs.mkdirSync(assetsDir, { recursive: true });

      fs.writeFileSync(path.join(siteDir, 'index.html'), files.html, 'utf8');
      fs.writeFileSync(path.join(siteDir, 'styles.css'), files.css || '', 'utf8');
      fs.writeFileSync(path.join(siteDir, 'app.js'), files.js || '', 'utf8');

      let writtenAssets = 0;
      if (Array.isArray(files.assets)) {
        for (const asset of files.assets) {
          if (!asset?.path || !asset?.dataUrl) continue;
          const fileName = path.basename(asset.path).replace(/[^a-zA-Z0-9._-]/g, '_');
          const match = asset.dataUrl.match(/^data:([^;]+);base64,(.+)$/);
          if (match && fileName) {
            const buf = Buffer.from(match[2], 'base64');
            fs.writeFileSync(path.join(assetsDir, fileName), buf);
            writtenAssets++;
          }
        }
      }

      const now = new Date().toISOString();
      const prev = registry[slug];
      const record: PublishedSiteRecord = {
        slug,
        title: rawTitle || slug,
        publishedAt: prev?.publishedAt || now,
        updatedAt: now,
        customDomain: prev?.customDomain || null,
        verificationToken: prev?.verificationToken || null,
        domainVerified: prev?.domainVerified || false,
        httpsStatus: prev?.httpsStatus || 'unconfigured',
        fileCount: 3 + writtenAssets,
      };
      registry[slug] = record;
      writeRegistry(registry);

      const proto = String(req.headers['x-forwarded-proto'] || req.protocol || 'https').split(',')[0].trim();
      const host = String(req.headers['x-forwarded-host'] || req.headers.host || 'localhost:3000')
        .split(',')[0]
        .trim();
      const publicPath = `/sites/${slug}/`;
      const publicUrl = `${proto}://${host}${publicPath}`;

      return res.status(201).json({
        success: true,
        site: record,
        publicPath,
        publicUrl,
      });
    } catch (err: any) {
      console.error('[PUBLISHED_SITES] Publish error:', err);
      return res.status(500).json({
        success: false,
        error: err?.message || 'Failed to publish website.',
      });
    }
  });

  // 4. Connect a Custom Domain + Generate DNS Instructions
  app.post('/api/published-sites/:slug/domain', (req: Request, res: Response) => {
    try {
      const slug = sanitizeSlug(req.params.slug);
      const domain = sanitizeDomain(String(req.body?.domain || ''));
      if (!isValidDomainName(domain)) {
        return res.status(400).json({
          success: false,
          error: 'Please enter a valid domain name (for example: example.com or www.example.com).',
        });
      }

      const registry = readRegistry();
      const site = registry[slug];
      if (!site) {
        return res.status(404).json({
          success: false,
          error: 'Publish your website first before connecting a custom domain.',
        });
      }

      // Prevent stealing a domain already bound to another slug
      const conflict = Object.values(registry).find(
        (other) => other.slug !== slug && other.customDomain?.toLowerCase() === domain
      );
      if (conflict) {
        return res.status(409).json({
          success: false,
          error: `${domain} is already connected to another published site (${conflict.slug}).`,
        });
      }

      const verificationToken =
        site.customDomain === domain && site.verificationToken
          ? site.verificationToken
          : `zoya-verify=${crypto.randomBytes(8).toString('hex')}`;

      site.customDomain = domain;
      site.verificationToken = verificationToken;
      site.domainVerified = false;
      site.httpsStatus = 'pending_dns';
      site.updatedAt = new Date().toISOString();
      registry[slug] = site;
      writeRegistry(registry);

      const platformHost = String(req.headers['x-forwarded-host'] || req.headers.host || 'localhost')
        .split(',')[0]
        .split(':')[0]
        .trim();
      const parts = domain.split('.');
      const isApex = parts.length === 2;

      return res.json({
        success: true,
        site,
        dnsGuide: {
          domain,
          isApex,
          targetHost: platformHost,
          records: [
            isApex
              ? {
                  type: 'ALIAS / A',
                  host: '@',
                  value: platformHost,
                  note: 'Point your root domain (@) to this host via ALIAS/ANAME (or A record IP if your DNS provider requires an IPv4 address).',
                }
              : {
                  type: 'CNAME',
                  host: parts[0],
                  value: platformHost,
                  note: `Point subdomain "${parts[0]}" to ${platformHost}.`,
                },
            {
              type: 'TXT',
              host: `_zoya-verify.${domain}`,
              value: verificationToken,
              note: 'Required to prove domain ownership and activate automatic HTTPS.',
            },
          ],
          httpsSteps: [
            'Once your CNAME/ALIAS and TXT records propagate (usually 2–15 minutes), click "Verify DNS".',
            'Automatic TLS/SSL certificate provisioning activates HTTPS on your domain automatically over port 443.',
          ],
        },
      });
    } catch (err: any) {
      return res.status(500).json({
        success: false,
        error: err?.message || 'Failed to save custom domain.',
      });
    }
  });

  // 5. Real DNS Lookup Verification for Custom Domain
  app.post('/api/published-sites/:slug/verify-domain', async (req: Request, res: Response) => {
    const slug = sanitizeSlug(req.params.slug);
    const registry = readRegistry();
    const site = registry[slug];
    if (!site || !site.customDomain) {
      return res.status(404).json({
        success: false,
        error: 'No custom domain connected to this published site yet.',
      });
    }

    const domain = site.customDomain;
    const expectedHost = String(req.headers['x-forwarded-host'] || req.headers.host || '')
      .split(',')[0]
      .split(':')[0]
      .trim()
      .toLowerCase();

    const diagnostics: {
      txtMatched: boolean;
      cnameMatched: boolean;
      aRecords: string[];
      cnameRecords: string[];
      txtRecords: string[];
    } = {
      txtMatched: false,
      cnameMatched: false,
      aRecords: [],
      cnameRecords: [],
      txtRecords: [],
    };

    try {
      const txtRows = await dns.promises.resolveTxt(`_zoya-verify.${domain}`).catch(() => [] as string[][]);
      diagnostics.txtRecords = txtRows.map((row) => row.join('')).filter(Boolean);
      if (site.verificationToken && diagnostics.txtRecords.some((v) => v.includes(site.verificationToken!))) {
        diagnostics.txtMatched = true;
      }
    } catch {}

    try {
      const cnames = await dns.promises.resolveCname(domain).catch(() => [] as string[]);
      diagnostics.cnameRecords = cnames;
      if (expectedHost && cnames.some((c) => c.toLowerCase().replace(/\.$/, '') === expectedHost)) {
        diagnostics.cnameMatched = true;
      }
    } catch {}

    try {
      diagnostics.aRecords = await dns.promises.resolve4(domain).catch(() => [] as string[]);
    } catch {}

    const verified = diagnostics.txtMatched || diagnostics.cnameMatched;
    site.domainVerified = verified;
    site.httpsStatus = verified ? 'active' : 'pending_dns';
    site.updatedAt = new Date().toISOString();
    registry[slug] = site;
    writeRegistry(registry);

    return res.json({
      success: true,
      verified,
      site,
      diagnostics,
      message: verified
        ? `DNS verified for ${domain}. Custom domain routing and automatic HTTPS are active.`
        : `DNS records for ${domain} have not propagated yet. Ensure the TXT (${site.verificationToken}) and CNAME/ALIAS records are saved at your DNS registrar, then re-verify.`,
    });
  });

  // 6. Disconnect Custom Domain
  app.delete('/api/published-sites/:slug/domain', (req: Request, res: Response) => {
    const slug = sanitizeSlug(req.params.slug);
    const registry = readRegistry();
    const site = registry[slug];
    if (!site) {
      return res.status(404).json({ success: false, error: 'Published site not found.' });
    }
    site.customDomain = null;
    site.verificationToken = null;
    site.domainVerified = false;
    site.httpsStatus = 'unconfigured';
    site.updatedAt = new Date().toISOString();
    registry[slug] = site;
    writeRegistry(registry);
    return res.json({ success: true, site });
  });
}
