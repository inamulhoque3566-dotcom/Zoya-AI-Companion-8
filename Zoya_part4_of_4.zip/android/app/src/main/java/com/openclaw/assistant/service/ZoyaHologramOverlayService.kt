package com.openclaw.assistant.service

import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.Typeface
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.util.DisplayMetrics
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import androidx.core.app.NotificationCompat
import com.openclaw.assistant.MainActivity
import com.openclaw.assistant.R
import org.json.JSONObject
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * ZOYA 3D Floating Holographic AI Companion Android Foreground Service
 *
 * Implements all 22 reference styles (matching holo_ref_01.png to holo_ref_22.png):
 * - 100% Circular boundary with fully transparent background
 * - Central "ZOYA" wordmark on every style (no microphone icon in center)
 * - Concentric independent rotating rings, additive neon glow, particles, 3D tilt
 * - Real audio reactivity driven by RMS amplitude & utterance callbacks
 * - Dynamic smooth scaling (1.0x -> 1.35x-1.5x) while SPEAKING with 250-400ms ease
 * - WindowManager TYPE_APPLICATION_OVERLAY with bounds clamping and persistent coordinates
 * - Interactive controls: Tap opens Zoya, Draggable, Minimize/Restore, Stop Listening, Close Overlay
 * - Lifecycle resilient: Screen-off animation pause, no per-frame GC allocations
 */
class ZoyaHologramOverlayService : Service() {

    companion object {
        private const val TAG = "ZoyaHologramService"
        private const val NOTIFICATION_ID = 2001
        private const val CHANNEL_ID = "zoya_hologram_channel"
        private const val PREFS_NAME = "zoya_hologram_prefs"
        private const val PREF_KEY_X = "pos_x"
        private const val PREF_KEY_Y = "pos_y"
        private const val PREF_KEY_STYLE = "selected_style"

        const val ACTION_START = "com.openclaw.assistant.action.START_HOLOGRAM"
        const val ACTION_STOP = "com.openclaw.assistant.action.STOP_HOLOGRAM"
        const val ACTION_UPDATE_STATE = "com.openclaw.assistant.action.UPDATE_STATE"
        const val ACTION_UPDATE_CONFIG = "com.openclaw.assistant.action.UPDATE_CONFIG"
        const val ACTION_STOP_LISTENING = "com.openclaw.assistant.action.STOP_LISTENING"
        const val ACTION_TOGGLE_MINIMIZE = "com.openclaw.assistant.action.TOGGLE_MINIMIZE"

        const val EXTRA_STATE = "extra_state"
        const val EXTRA_CONFIG = "extra_config"

        @Volatile
        var isOverlayRunning = false
            private set

        fun start(context: Context, stateJson: String? = null, configJson: String? = null) {
            if (!canDrawOverlays(context)) {
                Log.w(TAG, "Cannot start Zoya Hologram Overlay: SYSTEM_ALERT_WINDOW permission missing")
                return
            }
            val intent = Intent(context, ZoyaHologramOverlayService::class.java).apply {
                action = ACTION_START
                stateJson?.let { putExtra(EXTRA_STATE, it) }
                configJson?.let { putExtra(EXTRA_CONFIG, it) }
            }
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(intent)
                } else {
                    context.startService(intent)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error starting ZoyaHologramOverlayService: ${e.message}", e)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, ZoyaHologramOverlayService::class.java).apply {
                action = ACTION_STOP
            }
            context.stopService(intent)
        }

        fun updateState(context: Context, stateJson: String) {
            val intent = Intent(context, ZoyaHologramOverlayService::class.java).apply {
                action = ACTION_UPDATE_STATE
                putExtra(EXTRA_STATE, stateJson)
            }
            context.startService(intent)
        }

        fun updateConfig(context: Context, configJson: String) {
            val intent = Intent(context, ZoyaHologramOverlayService::class.java).apply {
                action = ACTION_UPDATE_CONFIG
                putExtra(EXTRA_CONFIG, configJson)
            }
            context.startService(intent)
        }

        fun canDrawOverlays(context: Context): Boolean {
            return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                Settings.canDrawOverlays(context)
            } else {
                true
            }
        }
    }

    private var windowManager: WindowManager? = null
    private var overlayContainer: HologramContainerView? = null
    private var layoutParams: WindowManager.LayoutParams? = null
    private lateinit var prefs: SharedPreferences

    // Configuration
    private var selectedStyleIndex = 1 // 1 to 22 (matching holo_ref_01 to holo_ref_22)
    private var baseSizePx = 360
    private var speakingEnlargeRatio = 1.35f
    private var glowIntensity = 1.0f
    private var animationSpeed = 1.0f
    private var isMinimized = false

    // State tracking
    private var currentVoiceStatus = "idle" // idle, listening, processing, speaking, error, disconnected
    private var currentAudioLevel = 0f

    // Size animation easing
    private var sizeAnimator: ValueAnimator? = null
    private var currentSizePx = 360

    // Screen power receiver to conserve GPU/CPU when screen is off
    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                Intent.ACTION_SCREEN_OFF -> {
                    Log.d(TAG, "Screen off: pausing hologram rendering")
                    overlayContainer?.hologramView?.pauseAnimation()
                }
                Intent.ACTION_SCREEN_ON -> {
                    Log.d(TAG, "Screen on: resuming hologram rendering")
                    overlayContainer?.hologramView?.resumeAnimation()
                }
            }
        }
    }

    private val zoyaStateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != ZoyaService.BROADCAST_STATE) return
            val state = intent.getStringExtra(ZoyaService.EXTRA_STATE) ?: return
            mainHandler.post {
                when (state) {
                    "IDLE_LISTENING" -> {
                        currentVoiceStatus = "idle"
                        overlayContainer?.hologramView?.updateVoiceState("idle", 0f)
                        animateWindowSizeForState()
                    }
                    "WAKE_DETECTED" -> {
                        currentVoiceStatus = "listening"
                        overlayContainer?.hologramView?.updateVoiceState("listening", 0.55f)
                        animateWindowSizeForState()
                    }
                    "LISTENING_COMMAND" -> {
                        currentVoiceStatus = "listening"
                        overlayContainer?.hologramView?.updateVoiceState("listening", 0.85f)
                        animateWindowSizeForState()
                    }
                    "PROCESSING" -> {
                        currentVoiceStatus = "thinking"
                        overlayContainer?.hologramView?.updateVoiceState("thinking", 0.45f)
                        animateWindowSizeForState()
                    }
                    "SPEAKING" -> {
                        currentVoiceStatus = "speaking"
                        overlayContainer?.hologramView?.updateVoiceState("speaking", 0.9f)
                        animateWindowSizeForState()
                    }
                }
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        Log.d(TAG, "ZoyaHologramOverlayService onCreate")
        prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        selectedStyleIndex = prefs.getInt(PREF_KEY_STYLE, 1)

        startForeground(NOTIFICATION_ID, createNotification("Zoya AI Companion Ready", "Active - Tap overlay to interact"))
        initOverlayView()
        isOverlayRunning = true

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
        }
        registerReceiver(screenReceiver, filter)

        val stateFilter = IntentFilter(ZoyaService.BROADCAST_STATE)
        androidx.core.content.ContextCompat.registerReceiver(
            this,
            zoyaStateReceiver,
            stateFilter,
            androidx.core.content.ContextCompat.RECEIVER_NOT_EXPORTED
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_STOP_LISTENING -> {
                handleStopListeningAction()
                return START_STICKY
            }
            ACTION_TOGGLE_MINIMIZE -> {
                toggleMinimize()
                return START_STICKY
            }
            ACTION_UPDATE_STATE -> {
                intent.getStringExtra(EXTRA_STATE)?.let { handleStateUpdate(it) }
            }
            ACTION_UPDATE_CONFIG -> {
                intent.getStringExtra(EXTRA_CONFIG)?.let { handleConfigUpdate(it) }
            }
            ACTION_START -> {
                intent.getStringExtra(EXTRA_STATE)?.let { handleStateUpdate(it) }
                intent.getStringExtra(EXTRA_CONFIG)?.let { handleConfigUpdate(it) }
            }
        }
        return START_STICKY
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        layoutParams?.let { params ->
            clampToScreen(params)
            try {
                windowManager?.updateViewLayout(overlayContainer, params)
            } catch (e: Exception) {
                Log.w(TAG, "Config change reposition error: ${e.message}")
            }
        }
    }

    private fun handleStateUpdate(jsonStr: String) {
        try {
            val json = JSONObject(jsonStr)
            var changed = false
            if (json.has("status")) {
                val s = json.getString("status").lowercase()
                if (s != currentVoiceStatus) {
                    currentVoiceStatus = s
                    changed = true
                }
            } else if (json.has("state")) {
                val s = json.getString("state").lowercase()
                if (s != currentVoiceStatus) {
                    currentVoiceStatus = s
                    changed = true
                }
            }
            if (json.has("audioLevel")) {
                currentAudioLevel = json.getDouble("audioLevel").toFloat()
            }

            if (changed) {
                animateWindowSizeForState()
                updateNotificationForState()
            }

            overlayContainer?.hologramView?.updateVoiceState(currentVoiceStatus, currentAudioLevel)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to parse state update JSON: ${e.message}")
        }
    }

    private fun handleConfigUpdate(jsonStr: String) {
        try {
            val json = JSONObject(jsonStr)
            if (json.has("styleIndex")) {
                selectedStyleIndex = json.getInt("styleIndex").coerceIn(1, 22)
                prefs.edit().putInt(PREF_KEY_STYLE, selectedStyleIndex).apply()
            } else if (json.has("activeStyleId")) {
                val idStr = json.getString("activeStyleId")
                val match = Regex("\\d+").find(idStr)
                if (match != null) {
                    selectedStyleIndex = match.value.toInt().coerceIn(1, 22)
                    prefs.edit().putInt(PREF_KEY_STYLE, selectedStyleIndex).apply()
                }
            }
            if (json.has("sizePx")) {
                baseSizePx = json.getInt("sizePx")
            } else if (json.has("baseSizePx")) {
                baseSizePx = json.getInt("baseSizePx")
            }
            if (json.has("speakingEnlargeRatio")) {
                speakingEnlargeRatio = json.getDouble("speakingEnlargeRatio").toFloat()
            }
            if (json.has("glowIntensity")) {
                glowIntensity = json.getDouble("glowIntensity").toFloat()
            }
            if (json.has("animationSpeed")) {
                animationSpeed = json.getDouble("animationSpeed").toFloat()
            }
            if (json.has("isMinimized")) {
                val min = json.getBoolean("isMinimized")
                if (min != isMinimized) {
                    isMinimized = min
                }
            }

            animateWindowSizeForState()
            overlayContainer?.hologramView?.updateConfig(
                selectedStyleIndex,
                glowIntensity,
                animationSpeed
            )
        } catch (e: Exception) {
            Log.e(TAG, "Failed to parse config update JSON: ${e.message}")
        }
    }

    private fun toggleMinimize() {
        isMinimized = !isMinimized
        animateWindowSizeForState()
    }

    private fun handleStopListeningAction() {
        Log.d(TAG, "Stop Listening triggered from Hologram or Notification")
        try {
            startService(Intent(this, ZoyaService::class.java).setAction(ZoyaService.ACTION_STOP))
        } catch (e: Exception) {
            Log.w(TAG, "Could not stop ZoyaService: ${e.message}")
        }
        currentVoiceStatus = "idle"
        overlayContainer?.hologramView?.updateVoiceState("idle", 0f)
        animateWindowSizeForState()
        updateNotificationForState()
    }

    /**
     * Smoothly scales the WindowManager view using a 300ms DecelerateInterpolator ValueAnimator
     * Normal size: baseSizePx
     * Speaking size: baseSizePx * speakingEnlargeRatio
     * Minimized size: 140px (compact 48dp orb)
     */
    private fun animateWindowSizeForState() {
        val targetSize = when {
            isMinimized -> 140
            currentVoiceStatus.equals("speaking", ignoreCase = true) -> (baseSizePx * speakingEnlargeRatio).toInt()
            else -> baseSizePx
        }

        if (targetSize == currentSizePx) return

        sizeAnimator?.cancel()
        val startSize = currentSizePx
        sizeAnimator = ValueAnimator.ofInt(startSize, targetSize).apply {
            duration = 320L
            interpolator = DecelerateInterpolator()
            addUpdateListener { animator ->
                val size = animator.animatedValue as Int
                currentSizePx = size
                layoutParams?.let { params ->
                    val prevW = params.width
                    val prevH = params.height
                    params.width = size
                    params.height = size
                    // Center-align resize
                    params.x -= (size - prevW) / 2
                    params.y -= (size - prevH) / 2
                    clampToScreen(params)
                    try {
                        windowManager?.updateViewLayout(overlayContainer, params)
                    } catch (e: Exception) {
                        Log.w(TAG, "Error updating animated view layout size: ${e.message}")
                    }
                }
            }
            start()
        }
    }

    private fun initOverlayView() {
        if (overlayContainer != null) return

        windowManager = getSystemService(Context.WINDOW_SERVICE) as? WindowManager
        if (windowManager == null) {
            Log.e(TAG, "WindowManager unavailable")
            return
        }

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val dm = resources.displayMetrics
        val savedX = prefs.getInt(PREF_KEY_X, dm.widthPixels - baseSizePx - 40)
        val savedY = prefs.getInt(PREF_KEY_Y, dm.heightPixels / 3)

        currentSizePx = baseSizePx

        layoutParams = WindowManager.LayoutParams(
            currentSizePx,
            currentSizePx,
            savedX,
            savedY,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                    WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
        }

        clampToScreen(layoutParams!!)

        val container = HologramContainerView(this)
        container.hologramView.updateConfig(selectedStyleIndex, glowIntensity, animationSpeed)
        container.hologramView.updateVoiceState(currentVoiceStatus, currentAudioLevel)

        try {
            windowManager?.addView(container, layoutParams)
            overlayContainer = container
        } catch (e: Exception) {
            Log.e(TAG, "Error adding overlayContainer to WindowManager: ${e.message}", e)
        }
    }

    private fun clampToScreen(params: WindowManager.LayoutParams) {
        val dm = resources.displayMetrics
        val minX = 0
        val maxX = (dm.widthPixels - params.width).coerceAtLeast(0)
        val minY = 40
        val maxY = (dm.heightPixels - params.height - 40).coerceAtLeast(0)

        params.x = params.x.coerceIn(minX, maxX)
        params.y = params.y.coerceIn(minY, maxY)
    }

    private fun savePosition(x: Int, y: Int) {
        prefs.edit()
            .putInt(PREF_KEY_X, x)
            .putInt(PREF_KEY_Y, y)
            .apply()
    }

    private fun updateNotificationForState() {
        val (title, text) = when (currentVoiceStatus) {
            "listening" -> Pair("Zoya AI Listening...", "Analyzing voice input in real time")
            "processing" -> Pair("Zoya AI Thinking...", "Synthesizing intelligence response")
            "speaking" -> Pair("Zoya AI Speaking", "Playing audio vocal response")
            "error" -> Pair("Zoya AI State Alert", "Microphone or network exception occurred")
            "disconnected" -> Pair("Zoya AI Offline", "Waiting for network reconnection")
            else -> Pair("Zoya 3D Holographic Companion", "Active background listening ready")
        }
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIFICATION_ID, createNotification(title, text))
    }

    private fun createNotification(title: String, content: String): Notification {
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Zoya 3D Hologram Overlay",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows real-time status of Zoya 3D Hologram Companion"
                setShowBadge(false)
            }
            notificationManager.createNotificationChannel(channel)
        }

        val launchIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("from_hologram_notification", true)
        }
        val pLaunch = PendingIntent.getActivity(
            this, 0, launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopListenIntent = Intent(this, ZoyaHologramOverlayService::class.java).apply {
            action = ACTION_STOP_LISTENING
        }
        val pStopListen = PendingIntent.getService(
            this, 1, stopListenIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopOverlayIntent = Intent(this, ZoyaHologramOverlayService::class.java).apply {
            action = ACTION_STOP
        }
        val pStopOverlay = PendingIntent.getService(
            this, 2, stopOverlayIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(content)
            .setSmallIcon(R.drawable.ic_mic)
            .setContentIntent(pLaunch)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_media_pause, "Stop Listening", pStopListen)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Close Overlay", pStopOverlay)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        isOverlayRunning = false
        try {
            unregisterReceiver(screenReceiver)
        } catch (_: Exception) {}
        try {
            unregisterReceiver(zoyaStateReceiver)
        } catch (_: Exception) {}

        sizeAnimator?.cancel()
        overlayContainer?.hologramView?.destroy()
        if (overlayContainer != null) {
            try {
                windowManager?.removeView(overlayContainer)
            } catch (e: Exception) {
                Log.w(TAG, "Error removing overlayContainer on destroy: ${e.message}")
            }
            overlayContainer = null
        }
        Log.d(TAG, "ZoyaHologramOverlayService destroyed")
    }

    /**
     * Overlay Container View wrapping the HologramCanvasView and controls
     */
    private inner class HologramContainerView(context: Context) : View(context) {
        val hologramView = HologramCanvasView(context)

        // Dragging & gesture detection
        private var initialX = 0
        private var initialY = 0
        private var initialTouchX = 0f
        private var initialTouchY = 0f
        private var isDragging = false
        private val touchSlop = 18f
        private var downTimestamp = 0L

        init {
            // Forward draw calls directly to HologramCanvasView
            isClickable = true
            isFocusable = false
        }

        override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
            super.onSizeChanged(w, h, oldw, oldh)
            hologramView.layout(0, 0, w, h)
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            hologramView.draw(canvas)
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            val params = layoutParams ?: return false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    isDragging = false
                    downTimestamp = System.currentTimeMillis()
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - initialTouchX
                    val dy = event.rawY - initialTouchY
                    if (!isDragging && (dx * dx + dy * dy > touchSlop * touchSlop)) {
                        isDragging = true
                    }
                    if (isDragging) {
                        params.x = (initialX + dx).toInt()
                        params.y = (initialY + dy).toInt()
                        clampToScreen(params)
                        try {
                            windowManager?.updateViewLayout(this, params)
                        } catch (e: Exception) {
                            Log.w(TAG, "Move update error: ${e.message}")
                        }
                    }
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    val clickDuration = System.currentTimeMillis() - downTimestamp
                    if (!isDragging) {
                        if (clickDuration > 800L) {
                            // Long-press: toggle minimize or cycle style
                            toggleMinimize()
                        } else {
                            // Single tap: open main Zoya app
                            onTapOpenApp()
                        }
                    } else {
                        savePosition(params.x, params.y)
                    }
                    isDragging = false
                    return true
                }
            }
            return super.onTouchEvent(event)
        }

        private fun onTapOpenApp() {
            Log.d(TAG, "Overlay tapped. Bringing Zoya MainActivity to front...")
            try {
                val intent = Intent(context, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
                    putExtra("from_hologram_tap", true)
                }
                context.startActivity(intent)
            } catch (e: Exception) {
                Log.e(TAG, "Error launching MainActivity: ${e.message}")
            }
        }
    }

    /**
     * Native Android 3D Hologram Canvas Rendering View
     * Zero-allocation per frame, 60fps capable, 22 full reference style implementations.
     */
    inner class HologramCanvasView(context: Context) : View(context) {

        private var styleIndex = 1
        private var glowIntensity = 1.0f
        private var animSpeed = 1.0f

        private var voiceStatus = "idle"
        private var audioLevel = 0f
        private var animTime = 0f
        private var isRunning = true

        // Preallocated Paints
        private val paintBackdrop = Paint(Paint.ANTI_ALIAS_FLAG)
        private val paintRingThick = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
        private val paintRingThin = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
        private val paintFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        private val paintGlow = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
        private val paintParticle = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        private val paintTextCore = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        }
        private val paintTextGlow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textAlign = Paint.Align.CENTER
            style = Paint.Style.STROKE
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        }

        // Preallocated geometry objects
        private val reusableRect = RectF()
        private val reusablePath = Path()
        private val reusableMatrix = Matrix()

        private val frameRunnable = object : Runnable {
            override fun run() {
                if (isRunning) {
                    animTime += 0.032f * animSpeed
                    overlayContainer?.invalidate()
                    postDelayed(this, 16) // ~60 FPS
                }
            }
        }

        init {
            post(frameRunnable)
        }

        fun updateConfig(style: Int, glow: Float, speed: Float) {
            styleIndex = style
            glowIntensity = glow
            animSpeed = speed
            overlayContainer?.invalidate()
        }

        fun updateVoiceState(status: String, level: Float) {
            voiceStatus = status
            audioLevel = level
            overlayContainer?.invalidate()
        }

        fun pauseAnimation() {
            isRunning = false
            removeCallbacks(frameRunnable)
        }

        fun resumeAnimation() {
            if (!isRunning) {
                isRunning = true
                post(frameRunnable)
            }
        }

        fun destroy() {
            pauseAnimation()
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat()
            val h = height.toFloat()
            if (w <= 0f || h <= 0f) return

            val cx = w / 2f
            val cy = h / 2f
            val baseR = (w.coerceAtMost(h) / 2f) * 0.84f

            // Dynamic pulse factor from voice state
            val statePulse = when (voiceStatus) {
                "speaking" -> 1.0f + (sin(animTime * 6f) * 0.06f)
                "listening" -> 1.0f + (audioLevel * 0.22f) + (sin(animTime * 4f) * 0.03f)
                "processing" -> 1.0f + (sin(animTime * 8f) * 0.04f)
                "error", "disconnected" -> 0.94f
                else -> 1.0f + (sin(animTime * 2f) * 0.015f)
            }
            val radius = baseR * statePulse

            // State-based error/disconnected override
            if (voiceStatus == "error" || voiceStatus == "disconnected") {
                drawErrorState(canvas, cx, cy, radius)
                return
            }

            // Route to specific reference style (1 to 22)
            when (styleIndex) {
                1 -> drawStyle01_FlameVortex(canvas, cx, cy, radius)
                2 -> drawStyle02_ImperialGold(canvas, cx, cy, radius)
                3 -> drawStyle03_PrismaticDiamond(canvas, cx, cy, radius)
                4 -> drawStyle04_WavyLotus(canvas, cx, cy, radius)
                5 -> drawStyle05_CyberHexShield(canvas, cx, cy, radius)
                6 -> drawStyle06_QuantumDial(canvas, cx, cy, radius)
                7 -> drawStyle07_AquaPearl(canvas, cx, cy, radius)
                8 -> drawStyle08_CyberBadge(canvas, cx, cy, radius)
                9 -> drawStyle09_HydroSplash(canvas, cx, cy, radius)
                10 -> drawStyle10_CyberLaurel(canvas, cx, cy, radius)
                11 -> drawStyle11_AuroraWave(canvas, cx, cy, radius)
                12 -> drawStyle12_SilkRibbon(canvas, cx, cy, radius)
                13 -> drawStyle13_AudioSpectrum(canvas, cx, cy, radius)
                14 -> drawStyle14_SegmentedHUD(canvas, cx, cy, radius)
                15 -> drawStyle15_GoldBotanical(canvas, cx, cy, radius)
                16 -> drawStyle16_RainbowHalo(canvas, cx, cy, radius)
                17 -> drawStyle17_PlanetaryNebula(canvas, cx, cy, radius)
                18 -> drawStyle18_EmeraldBotanical(canvas, cx, cy, radius)
                19 -> drawStyle19_RibbonVortex(canvas, cx, cy, radius)
                20 -> drawStyle20_FacetedGem(canvas, cx, cy, radius)
                21 -> drawStyle21_DualGoldHorizon(canvas, cx, cy, radius)
                22 -> drawStyle22_CosmicGalaxy(canvas, cx, cy, radius)
                else -> drawStyle01_FlameVortex(canvas, cx, cy, radius)
            }

            // Always render centered large "ZOYA" wordmark with glow and core
            drawCenterWordmark(canvas, cx, cy, radius)
        }

        // =====================================================================
        // CENTRAL "ZOYA" WORDMARK (Bold, prominent, no microphone icon)
        // =====================================================================
        private fun drawCenterWordmark(canvas: Canvas, cx: Float, cy: Float, radius: Float) {
            val textSize = radius * 0.38f
            paintTextCore.textSize = textSize
            paintTextGlow.textSize = textSize

            val textGlowColor = when (styleIndex) {
                2, 15, 21 -> Color.parseColor("#FFD700") // Gold styles
                18 -> Color.parseColor("#00E676") // Green style
                4, 10, 12, 19, 20 -> Color.parseColor("#D500F9") // Magenta styles
                else -> Color.parseColor("#00E5FF") // Cyan / Electric blue styles
            }

            val yOffset = cy - ((paintTextCore.descent() + paintTextCore.ascent()) / 2f)

            // Outer Bloom Glow
            paintTextGlow.color = textGlowColor
            paintTextGlow.strokeWidth = 7f * glowIntensity
            paintTextGlow.alpha = (180 * glowIntensity).toInt().coerceIn(0, 255)
            canvas.drawText("ZOYA", cx, yOffset, paintTextGlow)

            // Inner Crisp Core
            paintTextCore.color = Color.WHITE
            canvas.drawText("ZOYA", cx, yOffset, paintTextCore)
        }

        // =====================================================================
        // 22 DISTINCT HOLOGRAPHIC STYLE ENGINES (1-to-1 match with holo_ref_*.png)
        // =====================================================================

        // Style 1: Cosmic Flame Vortex (holo_ref_01.png) - Swirling magenta/cyan plasma blades
        private fun drawStyle01_FlameVortex(canvas: Canvas, cx: Float, cy: Float, r: Float) {
            drawRadialAura(canvas, cx, cy, r, Color.parseColor("#FF007F"), Color.parseColor("#00E5FF"))

            val rot = animTime * 60f
            canvas.save()
            canvas.rotate(rot, cx, cy)
            paintRingThick.strokeWidth = 5f
            paintRingThick.shader = SweepGradient(cx, cy, intArrayOf(
                Color.parseColor("#FF007F"), Color.parseColor("#00E5FF"),
                Color.parseColor("#7C4DFF"), Color.parseColor("#FF007F")
            ), null)
            canvas.drawCircle(cx, cy, r * 0.94f, paintRingThick)
            paintRingThick.shader = null
            canvas.restore()

            // Swirling curved blades
            val numBlades = 12
            for (i in 0 until numBlades) {
                val angle = (i * (360f / numBlades) + rot * 1.4f) * (PI.toFloat() / 180f)
                val bx = cx + (r * 0.88f) * cos(angle)
                val by = cy + (r * 0.88f) * sin(angle)
                paintParticle.color = if (i % 2 == 0) Color.parseColor("#00E5FF") else Color.parseColor("#FF007F")
                paintParticle.alpha = 210
                canvas.drawCircle(bx, by, 4.5f, paintParticle)
            }
            drawHorizonPedestal(canvas, cx, cy, r, Color.parseColor("#00E5FF"))
        }

        // Style 2: Imperial Gold Sovereign (holo_ref_02.png) - Radiant gold crown & rings
        private fun drawStyle02_ImperialGold(canvas: Canvas, cx: Float, cy: Float, r: Float) {
            drawRadialAura(canvas, cx, cy, r, Color.parseColor("#FFD700"), Color.parseColor("#FF8F00"))

            paintRingThick.strokeWidth = 6f
            paintRingThick.color = Color.parseColor("#FFD700")
            paintRingThick.alpha = 220
            canvas.drawCircle(cx, cy, r * 0.92f, paintRingThick)

            paintRingThin.strokeWidth = 2f
            paintRingThin.color = Color.parseColor("#FFF8DC")
            canvas.drawCircle(cx, cy, r * 0.82f, paintRingThin)

            // Tilted outer orbital ellipses
            canvas.save()
            canvas.rotate(animTime * 35f, cx, cy)
            canvas.scale(1.0f, 0.45f, cx, cy)
            paintRingThin.color = Color.parseColor("#FFA500")
            canvas.drawCircle(cx, cy, r * 1.05f, paintRingThin)
            canvas.restore()

            // Golden Crown Emblem above "ZOYA"
            val crownY = cy - r * 0.46f
            drawCrownEmblem(canvas, cx, crownY, r * 0.18f, Color.parseColor("#FFD700"))

            // Golden Diamond Emblem below "ZOYA"
            val diamY = cy + r * 0.44f
            drawDiamondEmblem(canvas, cx, diamY, r * 0.09f, Color.parseColor("#FFD700"))

            drawHorizonPedestal(canvas, cx, cy, r, Color.parseColor("#FFD700"))
        }

        // Style 3: Prismatic Dual Diamond (holo_ref_03.png) - 3D dual-pyramid diamond crystal
        private fun drawStyle03_PrismaticDiamond(canvas: Canvas, cx: Float, cy: Float, r: Float) {
            drawRadialAura(canvas, cx, cy, r, Color.parseColor("#2979FF"), Color.parseColor("#00E5FF"))

            // 3D Diamond Crystal Body
            reusablePath.reset()
            reusablePath.moveTo(cx, cy - r * 0.92f) // Top apex
            reusablePath.lineTo(cx + r * 0.72f, cy) // Right vertex
            reusablePath.lineTo(cx, cy + r * 0.92f) // Bottom apex
            reusablePath.lineTo(cx - r * 0.72f, cy) // Left vertex
            reusablePath.close()

            paintFill.color = Color.parseColor("#0091EA")
            paintFill.alpha = 60
            canvas.drawPath(reusablePath, paintFill)

            paintRingThick.strokeWidth = 3f
            paintRingThick.color = Color.parseColor("#00E5FF")
            paintRingThick.alpha = 240
            canvas.drawPath(reusablePath, paintRingThick)

            // Cross facet lines
            paintRingThin.color = Color.parseColor("#80D8FF")
            canvas.drawLine(cx - r * 0.72f, cy, cx + r * 0.72f, cy, paintRingThin)
            canvas.drawLine(cx, cy - r * 0.92f, cx, cy + r * 0.92f, paintRingThin)

            // Orbiting Crystal Shards
            val shardCount = 6
            for (i in 0 until shardCount) {
                val angle = (i * (360f / shardCount) + animTime * 45f) * (PI.toFloat() / 180f)
                val sx = cx + r * 0.95f * cos(angle)
                val sy = cy + r * 0.65f * sin(angle)
                drawDiamondEmblem(canvas, sx, sy, 7f, Color.parseColor("#00E5FF"))
            }
        }

        // Style 4: Scalloped Lotus Petal Wave (holo_ref_04.png) - Undulating wavy neon flower contour
        private fun drawStyle04_WavyLotus(canvas: Canvas, cx: Float, cy: Float, r: Float) {
            drawRadialAura(canvas, cx, cy, r, Color.parseColor("#FF4081"), Color.parseColor("#FFAB00"))

            reusablePath.reset()
            val points = 120
            val lobes = 10
            for (i in 0..points) {
                val theta = (i.toFloat() / points) * 2f * PI.toFloat()
                val wave = sin(theta * lobes + animTime * 2f) * (r * 0.12f)
                val cr = r * 0.84f + wave
                val px = cx + cr * cos(theta)
                val py = cy + cr * sin(theta)
                if (i == 0) reusablePath.moveTo(px, py) else reusablePath.lineTo(px, py)
            }
            reusablePath.close()

            paintRingThick.strokeWidth = 6f
            paintRingThick.color = Color.parseColor("#FF4081")
            paintRingThick.alpha = 210
            canvas.drawPath(reusablePath, paintRingThick)

            paintRingThin.strokeWidth = 2.5f
            paintRingThin.color = Color.parseColor("#FFD54F")
            canvas.drawPath(reusablePath, paintRingThin)

            // 4-point sparkle stars
            drawSparkleStar(canvas, cx, cy - r * 0.55f, 10f, Color.parseColor("#FF4081"))
            drawSparkleStar(canvas, cx, cy + r * 0.55f, 10f, Color.parseColor("#FF4081"))
        }

        // Style 5: Cyber Tactical Hex Shield (holo_ref_05.png) - Futuristic angular brackets & hex
        private fun drawStyle05_CyberHexShield(canvas: Canvas, cx: Float, cy: Float, r: Float) {
            drawRadialAura(canvas, cx, cy, r, Color.parseColor("#00E5FF"), Color.parseColor("#7C4DFF"))

            // Outer Chamfered Hex Path
            reusablePath.reset()
            val sides = 6
            for (i in 0 until sides) {
                val angle = (i * 60f - 30f) * (PI.toFloat() / 180f)
                val px = cx + (r * 0.95f) * cos(angle)
                val py = cy + (r * 0.85f) * sin(angle)
                if (i == 0) reusablePath.moveTo(px, py) else reusablePath.lineTo(px, py)
            }
            reusablePath.close()

            paintRingThick.strokeWidth = 5f
            paintRingThick.color = Color.parseColor("#00E5FF")
            paintRingThick.alpha = 230
            canvas.drawPath(reusablePath, paintRingThick)

            // Inner Tech Brackets
            paintRingThin.strokeWidth = 3f
            paintRingThin.color = Color.parseColor("#7C4DFF")
            val inset = r * 0.72f
            canvas.drawRect(cx - inset, cy - inset * 0.55f, cx + inset, cy + inset * 0.55f, paintRingThin)

            drawHorizonPedestal(canvas, cx, cy, r, Color.parseColor("#00E5FF"))
        }

        // Style 6: Quantum Compass Dial (holo_ref_06.png) - High precision sci-fi telemetry dial
        private fun drawStyle06_QuantumDial(canvas: Canvas, cx: Float, cy: Float, r: Float) {
            drawRadialAura(canvas, cx, cy, r, Color.parseColor("#7C4DFF"), Color.parseColor("#00E5FF"))

            paintRingThick.strokeWidth = 4f
            paintRingThick.color = Color.parseColor("#7C4DFF")
            canvas.drawCircle(cx, cy, r * 0.92f, paintRingThick)

            // Radial Gauge Ticks
            val tickCount = 48
            paintRingThin.color = Color.parseColor("#00E5FF")
            paintRingThin.strokeWidth = 2f
            for (i in 0 until tickCount) {
                val angle = (i * (360f / tickCount) + animTime * 15f) * (PI.toFloat() / 180f)
                val len = if (i % 6 == 0) r * 0.12f else r * 0.05f
                val x1 = cx + (r * 0.88f) * cos(angle)
                val y1 = cy + (r * 0.88f) * sin(angle)
                val x2 = cx + (r * 0.88f - len) * cos(angle)
                val y2 = cy + (r * 0.88f - len) * sin(angle)
                canvas.drawLine(x1, y1, x2, y2, paintRingThin)
            }

            // Cardinal Crosshair Ticks
            canvas.drawLine(cx - r * 1.05f, cy, cx - r * 0.95f, cy, paintRingThick)
            canvas.drawLine(cx + r * 0.95f, cy, cx + r * 1.05f, cy, paintRingThick)
        }

        // Style 7: Aqua Pearl Satellite Orbit (holo_ref_07.png) - Glass torus with pearl spheres
        private fun drawStyle07_AquaPearl(canvas: Canvas, cx: Float, cy: Float, r: Float) {
            drawRadialAura(canvas, cx, cy, r, Color.parseColor("#00E5FF"), Color.parseColor("#00FF88"))

            paintRingThick.strokeWidth = 6f
            paintRingThick.color = Color.parseColor("#00E5FF")
            canvas.drawCircle(cx, cy, r * 0.90f, paintRingThick)

            paintRingThin.strokeWidth = 2f
            paintRingThin.color = Color.parseColor("#80D8FF")
            canvas.drawCircle(cx, cy, r * 0.78f, paintRingThin)

            // Orbiting Pearl Spheres
            val pearls = 5
            for (i in 0 until pearls) {
                val angle = (i * (360f / pearls) + animTime * 45f) * (PI.toFloat() / 180f)
                val px = cx + (r * 0.98f) * cos(angle)
                val py = cy + (r * 0.98f) * sin(angle)
                paintParticle.color = Color.parseColor("#00FF88")
                canvas.drawCircle(px, py, 9f, paintParticle)
                paintParticle.color = Color.WHITE
                canvas.drawCircle(px - 2f, py - 2f, 3.5f, paintParticle)
            }
            drawHorizonPedestal(canvas, cx, cy, r, Color.parseColor("#00E5FF"))
        }

        // Style 8: Cyberpunk Portal Frame (holo_ref_08.png) - Chamfered badge frame with chevron
        private fun drawStyle08_CyberBadge(canvas: Canvas, cx: Float, cy: Float, r: Float) {
            drawRadialAura(canvas, cx, cy, r, Color.parseColor("#FF9100"), Color.parseColor("#E040FB"))

            reusableRect.set(cx - r * 0.88f, cy - r * 0.65f, cx + r * 0.88f, cy + r * 0.65f)
            paintRingThick.strokeWidth = 5f
            paintRingThick.color = Color.parseColor("#FF9100")
            canvas.drawRoundRect(reusableRect, 24f, 24f, paintRingThick)

            paintRingThin.strokeWidth = 2f
            paintRingThin.color = Color.parseColor("#E040FB")
            reusableRect.inset(12f, 12f)
            canvas.drawRoundRect(reusableRect, 18f, 18f, paintRingThin)

            // Inverted triangle / chevron below "ZOYA"
            val chevY = cy + r * 0.38f
            reusablePath.reset()
            reusablePath.moveTo(cx - 14f, chevY)
            reusablePath.lineTo(cx + 14f, chevY)
            reusablePath.lineTo(cx, chevY + 14f)
            reusablePath.close()
            paintFill.color = Color.parseColor("#FF9100")
            canvas.drawPath(reusablePath, paintFill)
        }

        // Style 9: Hydro Splash Vortex (holo_ref_09.png) - Curling dynamic water splash
        private fun drawStyle09_HydroSplash(canvas: Canvas, cx: Float, cy: Float, r: Float) {
            drawRadialAura(canvas, cx, cy, r, Color.parseColor("#00B0FF"), Color.parseColor("#00E5FF"))

            val rot = animTime * 50f
            canvas.save()
            canvas.rotate(rot, cx, cy)
            val splashArcs = 8
            for (i in 0 until splashArcs) {
                val a = (i * (360f / splashArcs)) * (PI.toFloat() / 180f)
                val sx = cx + r * 0.82f * cos(a)
                val sy = cy + r * 0.82f * sin(a)
                paintRingThick.strokeWidth = 4f
                paintRingThick.color = Color.parseColor("#00B0FF")
                canvas.drawCircle(sx, sy, r * 0.16f, paintRingThick)
            }
            canvas.restore()

            paintRingThin.strokeWidth = 3f
            paintRingThin.color = Color.WHITE
            canvas.drawCircle(cx, cy, r * 0.74f, paintRingThin)
        }

        // Style 10: Cyber Laurel Victory (holo_ref_10.png) - Curved violet & sapphire laurel branches
        private fun drawStyle10_CyberLaurel(canvas: Canvas, cx: Float, cy: Float, r: Float) {
            drawRadialAura(canvas, cx, cy, r, Color.parseColor("#7C4DFF"), Color.parseColor("#00E5FF"))

            paintRingThick.strokeWidth = 4f
            paintRingThick.color = Color.parseColor("#00E5FF")
            canvas.drawCircle(cx, cy, r * 0.76f, paintRingThick)

            // Laurel Wreath Leaves (Left and Right arches)
            val leaves = 8
            paintFill.color = Color.parseColor("#7C4DFF")
            for (i in 0 until leaves) {
                val frac = (i.toFloat() / leaves) * PI.toFloat() - (PI.toFloat() / 2f)
                // Left branch
                val lx = cx - r * 0.88f * cos(frac * 0.75f)
                val ly = cy + r * 0.88f * sin(frac * 0.75f)
                canvas.drawOval(lx - 8f, ly - 14f, lx + 8f, ly + 14f, paintFill)

                // Right branch
                val rx = cx + r * 0.88f * cos(frac * 0.75f)
                val ry = cy + r * 0.88f * sin(frac * 0.75f)
                canvas.drawOval(rx - 8f, ry - 14f, rx + 8f, ry + 14f, paintFill)
            }
        }

        // Style 11: Liquid Aurora Wave Ribbon (holo_ref_11.png) - Translucent undulating cloud ribbons
        private fun drawStyle11_AuroraWave(canvas: Canvas, cx: Float, cy: Float, r: Float) {
            drawRadialAura(canvas, cx, cy, r, Color.parseColor("#00E5FF"), Color.parseColor("#AA00FF"))

            reusablePath.reset()
            val pts = 90
            for (i in 0..pts) {
                val th = (i.toFloat() / pts) * 2f * PI.toFloat()
                val wave = sin(th * 4f + animTime * 3f) * (r * 0.14f) + cos(th * 2f) * (r * 0.08f)
                val dist = r * 0.80f + wave
                val px = cx + dist * cos(th)
                val py = cy + dist * sin(th)
                if (i == 0) reusablePath.moveTo(px, py) else reusablePath.lineTo(px, py)
            }
            reusablePath.close()

            paintRingThick.strokeWidth = 5f
            paintRingThick.color = Color.parseColor("#00E5FF")
            canvas.drawPath(reusablePath, paintRingThick)
        }

        // Style 12: Ethereal Silk Ribbon Halo (holo_ref_12.png) - Interlaced translucent ribbon loops
        private fun drawStyle12_SilkRibbon(canvas: Canvas, cx: Float, cy: Float, r: Float) {
            drawRadialAura(canvas, cx, cy, r, Color.parseColor("#D500F9"), Color.parseColor("#2979FF"))

            canvas.save()
            canvas.rotate(animTime * 30f, cx, cy)
            paintRingThick.strokeWidth = 6f
            paintRingThick.color = Color.parseColor("#D500F9")
            canvas.drawOval(cx - r * 0.90f, cy - r * 0.70f, cx + r * 0.90f, cy + r * 0.70f, paintRingThick)

            canvas.rotate(90f, cx, cy)
            paintRingThick.color = Color.parseColor("#2979FF")
            canvas.drawOval(cx - r * 0.90f, cy - r * 0.70f, cx + r * 0.90f, cy + r * 0.70f, paintRingThick)
            canvas.restore()
        }

        // Style 13: Circular Audio Spectrum Pulse (holo_ref_13.png) - 360-degree radial visualizer bars
        private fun drawStyle13_AudioSpectrum(canvas: Canvas, cx: Float, cy: Float, r: Float) {
            drawRadialAura(canvas, cx, cy, r, Color.parseColor("#E040FB"), Color.parseColor("#00E5FF"))

            val barCount = 48
            paintRingThick.strokeWidth = 3f
            for (i in 0 until barCount) {
                val angle = (i * (360f / barCount)) * (PI.toFloat() / 180f)
                val baseH = r * 0.08f
                val dynamicH = if (voiceStatus == "listening") (audioLevel * r * 0.28f * (sin(i * 1.5f + animTime * 8f) + 1f) / 2f)
                else (sin(i * 0.8f + animTime * 4f) * (r * 0.12f) + r * 0.12f)

                val x1 = cx + (r * 0.72f) * cos(angle)
                val y1 = cy + (r * 0.72f) * sin(angle)
                val x2 = cx + (r * 0.72f + baseH + dynamicH) * cos(angle)
                val y2 = cy + (r * 0.72f + baseH + dynamicH) * sin(angle)

                paintRingThick.color = if (i % 2 == 0) Color.parseColor("#E040FB") else Color.parseColor("#00E5FF")
                canvas.drawLine(x1, y1, x2, y2, paintRingThick)
            }
            paintRingThin.color = Color.WHITE
            canvas.drawCircle(cx, cy, r * 0.70f, paintRingThin)
        }

        // Style 14: Segmented Sci-Fi HUD Reticle (holo_ref_14.png) - Concentric telemetry dash arcs
        private fun drawStyle14_SegmentedHUD(canvas: Canvas, cx: Float, cy: Float, r: Float) {
            drawRadialAura(canvas, cx, cy, r, Color.parseColor("#00E5FF"), Color.parseColor("#7C4DFF"))

            val rot = animTime * 40f
            canvas.save()
            canvas.rotate(rot, cx, cy)
            reusableRect.set(cx - r * 0.92f, cy - r * 0.92f, cx + r * 0.92f, cy + r * 0.92f)
            paintRingThick.strokeWidth = 6f
            paintRingThick.color = Color.parseColor("#00E5FF")
            canvas.drawArc(reusableRect, 0f, 70f, false, paintRingThick)
            canvas.drawArc(reusableRect, 90f, 70f, false, paintRingThick)
            canvas.drawArc(reusableRect, 180f, 70f, false, paintRingThick)
            canvas.drawArc(reusableRect, 270f, 70f, false, paintRingThick)
            canvas.restore()

            paintRingThin.strokeWidth = 2f
            paintRingThin.color = Color.parseColor("#7C4DFF")
            canvas.drawCircle(cx, cy, r * 0.80f, paintRingThin)
        }

        // Style 15: Golden Botanical Leaf Wreath (holo_ref_15.png) - Pure gold filigree vines & leaves
        private fun drawStyle15_GoldBotanical(canvas: Canvas, cx: Float, cy: Float, r: Float) {
            drawRadialAura(canvas, cx, cy, r, Color.parseColor("#FFD700"), Color.parseColor("#FFA500"))

            paintRingThick.strokeWidth = 4f
            paintRingThick.color = Color.parseColor("#FFD700")
            canvas.drawCircle(cx, cy, r * 0.85f, paintRingThick)

            val leafCount = 14
            paintFill.color = Color.parseColor("#FFD700")
            for (i in 0 until leafCount) {
                val a = (i * (360f / leafCount) + animTime * 12f) * (PI.toFloat() / 180f)
                val lx = cx + (r * 0.90f) * cos(a)
                val ly = cy + (r * 0.90f) * sin(a)
                canvas.drawOval(lx - 5f, ly - 10f, lx + 5f, ly + 10f, paintFill)
            }
        }

        // Style 16: Full Spectrum Rainbow Halo (holo_ref_16.png) - Continuous rainbow circle & dual spheres
        private fun drawStyle16_RainbowHalo(canvas: Canvas, cx: Float, cy: Float, r: Float) {
            drawRadialAura(canvas, cx, cy, r, Color.parseColor("#FF0000"), Color.parseColor("#00E5FF"))

            canvas.save()
            canvas.rotate(animTime * 45f, cx, cy)
            paintRingThick.strokeWidth = 6f
            paintRingThick.shader = SweepGradient(cx, cy, intArrayOf(
                Color.RED, Color.YELLOW, Color.GREEN, Color.CYAN, Color.BLUE, Color.MAGENTA, Color.RED
            ), null)
            canvas.drawCircle(cx, cy, r * 0.88f, paintRingThick)
            paintRingThick.shader = null
            canvas.restore()

            // Dual Opposing Satellite Spheres
            val a1 = (animTime * 60f) * (PI.toFloat() / 180f)
            val a2 = a1 + PI.toFloat()
            val s1x = cx + r * 0.98f * cos(a1)
            val s1y = cy + r * 0.98f * sin(a1)
            val s2x = cx + r * 0.98f * cos(a2)
            val s2y = cy + r * 0.98f * sin(a2)

            paintParticle.color = Color.parseColor("#00E5FF")
            canvas.drawCircle(s1x, s1y, 10f, paintParticle)
            paintParticle.color = Color.parseColor("#FF4081")
            canvas.drawCircle(s2x, s2y, 10f, paintParticle)
        }

        // Style 17: Planetary Nebula Constellation (holo_ref_17.png) - Interstellar nebula & twin stars
        private fun drawStyle17_PlanetaryNebula(canvas: Canvas, cx: Float, cy: Float, r: Float) {
            drawRadialAura(canvas, cx, cy, r, Color.parseColor("#651FFF"), Color.parseColor("#E040FB"))

            paintRingThick.strokeWidth = 4f
            paintRingThick.color = Color.parseColor("#651FFF")
            canvas.drawCircle(cx, cy, r * 0.88f, paintRingThick)

            // Twin 4-point sparkle stars
            drawSparkleStar(canvas, cx, cy - r * 0.52f, 12f, Color.parseColor("#E040FB"))
            drawSparkleStar(canvas, cx, cy + r * 0.52f, 12f, Color.parseColor("#00E5FF"))

            // Planetary Orbs
            val o1x = cx + r * 0.94f * cos(animTime * 1.2f)
            val o1y = cy + r * 0.94f * sin(animTime * 1.2f)
            paintParticle.color = Color.WHITE
            canvas.drawCircle(o1x, o1y, 7f, paintParticle)
        }

        // Style 18: Emerald Botanical Halo (holo_ref_18.png) - Bioluminescent green and mint leaves
        private fun drawStyle18_EmeraldBotanical(canvas: Canvas, cx: Float, cy: Float, r: Float) {
            drawRadialAura(canvas, cx, cy, r, Color.parseColor("#00E676"), Color.parseColor("#1DE9B6"))

            paintRingThick.strokeWidth = 5f
            paintRingThick.color = Color.parseColor("#00E676")
            canvas.drawCircle(cx, cy, r * 0.86f, paintRingThick)

            val leaves = 12
            paintFill.color = Color.parseColor("#00E676")
            for (i in 0 until leaves) {
                val a = (i * (360f / leaves) + animTime * 10f) * (PI.toFloat() / 180f)
                val lx = cx + (r * 0.92f) * cos(a)
                val ly = cy + (r * 0.92f) * sin(a)
                canvas.drawOval(lx - 6f, ly - 12f, lx + 6f, ly + 12f, paintFill)
            }
        }

        // Style 19: Ribbon Plasma Vortex (holo_ref_19.png) - High-speed concentric swirling ribbons
        private fun drawStyle19_RibbonVortex(canvas: Canvas, cx: Float, cy: Float, r: Float) {
            drawRadialAura(canvas, cx, cy, r, Color.parseColor("#FF007F"), Color.parseColor("#00E5FF"))

            canvas.save()
            canvas.rotate(animTime * 50f, cx, cy)
            paintRingThick.strokeWidth = 5f
            paintRingThick.color = Color.parseColor("#FF007F")
            canvas.drawCircle(cx, cy, r * 0.88f, paintRingThick)

            canvas.rotate(-animTime * 80f, cx, cy)
            paintRingThin.strokeWidth = 3f
            paintRingThin.color = Color.parseColor("#00E5FF")
            canvas.drawCircle(cx, cy, r * 0.76f, paintRingThin)
            canvas.restore()
        }

        // Style 20: Faceted Gemstone Crystal (holo_ref_20.png) - Outer ring of multi-faceted geometric jewels
        private fun drawStyle20_FacetedGem(canvas: Canvas, cx: Float, cy: Float, r: Float) {
            drawRadialAura(canvas, cx, cy, r, Color.parseColor("#7C4DFF"), Color.parseColor("#00E5FF"))

            val facets = 14
            for (i in 0 until facets) {
                val a1 = (i * (360f / facets)) * (PI.toFloat() / 180f)
                val a2 = ((i + 1) * (360f / facets)) * (PI.toFloat() / 180f)

                reusablePath.reset()
                reusablePath.moveTo(cx + r * 0.78f * cos(a1), cy + r * 0.78f * sin(a1))
                reusablePath.lineTo(cx + r * 0.94f * cos(a1), cy + r * 0.94f * sin(a1))
                reusablePath.lineTo(cx + r * 0.94f * cos(a2), cy + r * 0.94f * sin(a2))
                reusablePath.lineTo(cx + r * 0.78f * cos(a2), cy + r * 0.78f * sin(a2))
                reusablePath.close()

                paintFill.color = if (i % 2 == 0) Color.parseColor("#7C4DFF") else Color.parseColor("#00E5FF")
                paintFill.alpha = 180
                canvas.drawPath(reusablePath, paintFill)
            }
        }

        // Style 21: Dual Gold Horizon Ring (holo_ref_21.png) - Twin thin gold rings with horizon starburst
        private fun drawStyle21_DualGoldHorizon(canvas: Canvas, cx: Float, cy: Float, r: Float) {
            drawRadialAura(canvas, cx, cy, r, Color.parseColor("#FFD700"), Color.parseColor("#FFA500"))

            paintRingThick.strokeWidth = 4f
            paintRingThick.color = Color.parseColor("#FFD700")
            canvas.drawCircle(cx, cy, r * 0.90f, paintRingThick)

            paintRingThin.strokeWidth = 2f
            paintRingThin.color = Color.parseColor("#FFA500")
            canvas.drawCircle(cx, cy, r * 0.82f, paintRingThin)

            // Top starburst flare
            drawSparkleStar(canvas, cx, cy - r * 0.90f, 14f, Color.parseColor("#FFD700"))
            drawHorizonPedestal(canvas, cx, cy, r, Color.parseColor("#FFD700"))
        }

        // Style 22: Deep Cosmic Galaxy Bubble (holo_ref_22.png) - Swirling interstellar gas with orbiting moons
        private fun drawStyle22_CosmicGalaxy(canvas: Canvas, cx: Float, cy: Float, r: Float) {
            drawRadialAura(canvas, cx, cy, r, Color.parseColor("#651FFF"), Color.parseColor("#00E5FF"))

            paintRingThick.strokeWidth = 5f
            paintRingThick.color = Color.parseColor("#00E5FF")
            canvas.drawCircle(cx, cy, r * 0.90f, paintRingThick)

            // Orbiting Moons
            val m1x = cx + r * 0.96f * cos(animTime * 1.5f)
            val m1y = cy + r * 0.96f * sin(animTime * 1.5f)
            val m2x = cx + r * 0.96f * cos(animTime * 1.5f + PI.toFloat())
            val m2y = cy + r * 0.96f * sin(animTime * 1.5f + PI.toFloat())

            paintParticle.color = Color.parseColor("#E040FB")
            canvas.drawCircle(m1x, m1y, 11f, paintParticle)
            paintParticle.color = Color.parseColor("#00E5FF")
            canvas.drawCircle(m2x, m2y, 11f, paintParticle)
        }

        // =====================================================================
        // ERROR & DISCONNECTED STATE RENDERING
        // =====================================================================
        private fun drawErrorState(canvas: Canvas, cx: Float, cy: Float, r: Float) {
            val alertColor = if (voiceStatus == "error") Color.parseColor("#FF1744") else Color.parseColor("#FF9100")
            drawRadialAura(canvas, cx, cy, r, alertColor, Color.TRANSPARENT)

            paintRingThick.strokeWidth = 6f
            paintRingThick.color = alertColor
            canvas.drawCircle(cx, cy, r * 0.90f, paintRingThick)

            drawCenterWordmark(canvas, cx, cy, r)
        }

        // =====================================================================
        // REUSABLE PRIMITIVES & EMBLEMS
        // =====================================================================
        private fun drawRadialAura(canvas: Canvas, cx: Float, cy: Float, r: Float, c1: Int, c2: Int) {
            paintBackdrop.shader = RadialGradient(
                cx, cy, r * 1.08f,
                intArrayOf(
                    Color.argb((55 * glowIntensity).toInt().coerceIn(0, 255), Color.red(c1), Color.green(c1), Color.blue(c1)),
                    Color.argb((18 * glowIntensity).toInt().coerceIn(0, 255), Color.red(c2), Color.green(c2), Color.blue(c2)),
                    Color.TRANSPARENT
                ),
                floatArrayOf(0f, 0.72f, 1f),
                Shader.TileMode.CLAMP
            )
            canvas.drawCircle(cx, cy, r * 1.08f, paintBackdrop)
        }

        private fun drawCrownEmblem(canvas: Canvas, cx: Float, cy: Float, size: Float, color: Int) {
            reusablePath.reset()
            val w = size * 1.4f
            val h = size * 0.8f
            reusablePath.moveTo(cx - w / 2f, cy + h / 2f)
            reusablePath.lineTo(cx - w / 2f, cy - h / 3f)
            reusablePath.lineTo(cx - w / 4f, cy + h / 6f)
            reusablePath.lineTo(cx, cy - h / 2f)
            reusablePath.lineTo(cx + w / 4f, cy + h / 6f)
            reusablePath.lineTo(cx + w / 2f, cy - h / 3f)
            reusablePath.lineTo(cx + w / 2f, cy + h / 2f)
            reusablePath.close()

            paintFill.color = color
            canvas.drawPath(reusablePath, paintFill)
        }

        private fun drawDiamondEmblem(canvas: Canvas, cx: Float, cy: Float, size: Float, color: Int) {
            reusablePath.reset()
            reusablePath.moveTo(cx, cy - size)
            reusablePath.lineTo(cx + size, cy)
            reusablePath.lineTo(cx, cy + size)
            reusablePath.lineTo(cx - size, cy)
            reusablePath.close()

            paintFill.color = color
            canvas.drawPath(reusablePath, paintFill)
        }

        private fun drawSparkleStar(canvas: Canvas, cx: Float, cy: Float, size: Float, color: Int) {
            reusablePath.reset()
            reusablePath.moveTo(cx, cy - size)
            reusablePath.quadTo(cx, cy, cx + size, cy)
            reusablePath.quadTo(cx, cy, cx, cy + size)
            reusablePath.quadTo(cx, cy, cx - size, cy)
            reusablePath.quadTo(cx, cy, cx, cy - size)
            reusablePath.close()

            paintFill.color = color
            canvas.drawPath(reusablePath, paintFill)
        }

        private fun drawHorizonPedestal(canvas: Canvas, cx: Float, cy: Float, r: Float, color: Int) {
            val pedY = cy + r * 0.88f
            canvas.save()
            canvas.scale(1.0f, 0.22f, cx, pedY)
            paintRingThin.color = color
            paintRingThin.strokeWidth = 3f
            paintRingThin.alpha = 160
            canvas.drawCircle(cx, pedY, r * 0.72f, paintRingThin)
            canvas.restore()
        }
    }
}
