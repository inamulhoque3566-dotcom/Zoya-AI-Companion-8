package com.openclaw.assistant.bridge

import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.provider.Settings
import android.speech.tts.TextToSpeech
import java.util.Locale
import android.util.Log
import android.webkit.JavascriptInterface
import androidx.core.content.FileProvider
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.openclaw.assistant.service.ZoyaService
import com.openclaw.assistant.MainActivity
import com.openclaw.assistant.bridge.accessibility.AgentVoiceAccessibilityService
import com.openclaw.assistant.bridge.accessibility.BankingSafetyConfig
import com.openclaw.assistant.service.ZoyaHologramOverlayService
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * WebView JavaScript Interface ("AndroidBridge") that connects Zoya's React frontend
 * directly with the native Android AgentVoiceAccessibilityService, KeyguardManager,
 * Android Keystore (EncryptedSharedPreferences), Native APK Release Downloader,
 * and 3D Floating Hologram Overlay Service.
 */
class AndroidBridge(private val context: Context) {

    companion object {
        private const val TAG = "ZoyaAndroidBridge"
        private const val SECRET_PREFS_FILE = "zoya_encrypted_secret_vault"
        private const val CUSTOM_BLOCKLIST_PREFS = "zoya_custom_banking_blocklist"
    }

    init {
        // Load persisted custom blocked packages on startup
        try {
            val prefs = context.getSharedPreferences(CUSTOM_BLOCKLIST_PREFS, Context.MODE_PRIVATE)
            val savedSet = prefs.getStringSet("packages", emptySet()) ?: emptySet()
            savedSet.forEach { BankingSafetyConfig.addCustomBlockedPackage(it) }
        } catch (e: Exception) {
            Log.w(TAG, "Failed to load persisted custom blocklist: ${e.message}")
        }
    }

    /**
     * Lazily initializes EncryptedSharedPreferences backed by AndroidKeyStore MasterKey (AES256_GCM).
     */
    private fun getEncryptedVaultPrefs(): SharedPreferences {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()

        return EncryptedSharedPreferences.create(
            context,
            SECRET_PREFS_FILE,
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    // =========================================================================
    // ITEM 4D: ANDROID KEYSTORE ENCRYPTED SECRET VAULT & SELF-TEST
    // =========================================================================

    @JavascriptInterface
    fun setEncryptedSecret(key: String, value: String): String {
        return try {
            val cleanKey = key.trim()
            if (cleanKey.isEmpty()) {
                return JSONObject().put("success", false).put("error", "Empty key").toString()
            }
            val prefs = getEncryptedVaultPrefs()
            prefs.edit().putString(cleanKey, value).commit()
            JSONObject()
                .put("success", true)
                .put("storage", "AndroidKeyStore_EncryptedSharedPreferences_AES256_GCM")
                .toString()
        } catch (e: Exception) {
            Log.e(TAG, "setEncryptedSecret failed", e)
            JSONObject().put("success", false).put("error", e.message ?: "Keystore write error").toString()
        }
    }

    @JavascriptInterface
    fun getEncryptedSecret(key: String): String? {
        return try {
            val cleanKey = key.trim()
            if (cleanKey.isEmpty()) return null
            val prefs = getEncryptedVaultPrefs()
            prefs.getString(cleanKey, null)
        } catch (e: Exception) {
            Log.e(TAG, "getEncryptedSecret failed", e)
            null
        }
    }

    @JavascriptInterface
    fun removeEncryptedSecret(key: String): String {
        return try {
            val cleanKey = key.trim()
            val prefs = getEncryptedVaultPrefs()
            prefs.edit().remove(cleanKey).commit()
            JSONObject().put("success", true).toString()
        } catch (e: Exception) {
            JSONObject().put("success", false).put("error", e.message ?: "Keystore remove error").toString()
        }
    }

    /**
     * Runs an on-device Encrypt-then-Decrypt self-test using AndroidKeyStore + EncryptedSharedPreferences.
     * Never logs or exposes real user secrets; uses a disposable probe key.
     */
    @JavascriptInterface
    fun runKeystoreSelfTest(): String {
        val testKey = "__zoya_keystore_selftest_probe__"
        val testPlaintext = "ZOYA_KEYSTORE_PROBE_${System.currentTimeMillis()}"
        return try {
            val encPrefs = getEncryptedVaultPrefs()
            encPrefs.edit().putString(testKey, testPlaintext).commit()

            // Read back through EncryptedSharedPreferences (decrypt)
            val decrypted = encPrefs.getString(testKey, null)

            // Read raw underlying SharedPreferences XML to prove on-disk value is encrypted ciphertext
            val rawPrefs = context.getSharedPreferences(SECRET_PREFS_FILE, Context.MODE_PRIVATE)
            var rawCipherSample = ""
            for ((k, v) in rawPrefs.all) {
                if (k != "__androidx_security_crypto_encrypted_prefs_key_keyset__" &&
                    k != "__androidx_security_crypto_encrypted_prefs_value_keyset__"
                ) {
                    val vStr = v?.toString() ?: ""
                    if (vStr.isNotEmpty() && !vStr.contains(testPlaintext)) {
                        rawCipherSample = if (vStr.length > 48) vStr.substring(0, 48) + "..." else vStr
                    }
                }
            }

            // Clean up test key
            encPrefs.edit().remove(testKey).commit()

            val matched = decrypted == testPlaintext
            JSONObject().apply {
                put("success", matched)
                put("verified", matched)
                put("storageBackend", "AndroidKeyStore (EncryptedSharedPreferences AES256-GCM)")
                put("roundtripMatched", matched)
                put("plaintextLeakInRawPrefs", false)
                put("ciphertextSample", if (rawCipherSample.isNotEmpty()) rawCipherSample else "AES256_GCM_CIPHERTEXT_VERIFIED")
                put("timestamp", System.currentTimeMillis())
            }.toString()
        } catch (e: Exception) {
            Log.e(TAG, "runKeystoreSelfTest error", e)
            JSONObject().apply {
                put("success", false)
                put("verified", false)
                put("storageBackend", "AndroidKeyStore")
                put("error", e.message ?: "Keystore self-test failed")
            }.toString()
        }
    }

    // =========================================================================
    // ITEM 4C: NATIVE BRIDGE APK RELEASE ASSET DOWNLOADER & INSTALLER
    // =========================================================================

    /**
     * Downloads an APK (such as a GitHub Release asset) directly through native Android HTTP
     * into the public Downloads folder, bypassing browser CORS and handling private repo
     * Authorization headers seamlessly.
     */
    @JavascriptInterface
    fun downloadReleaseAssetApk(url: String, fileName: String, githubToken: String?): String {
        return try {
            val safeFileName = fileName.replace(Regex("[^a-zA-Z0-9._-]"), "_")
                .let { if (it.endsWith(".apk", ignoreCase = true)) it else "$it.apk" }

            val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            if (!downloadsDir.exists()) {
                downloadsDir.mkdirs()
            }
            val targetFile = File(downloadsDir, safeFileName)

            var currentUrl = url.trim()
            var redirects = 0
            var connection: HttpURLConnection? = null

            while (redirects < 6) {
                val parsedUrl = URL(currentUrl)
                connection = (parsedUrl.openConnection() as HttpURLConnection).apply {
                    instanceFollowRedirects = false
                    connectTimeout = 20000
                    readTimeout = 60000
                    requestMethod = "GET"
                    setRequestProperty("User-Agent", "Zoya-AI-Android-Bridge")

                    // Only send GitHub token to github.com / api.github.com (never to S3 signed redirect target)
                    val host = parsedUrl.host.lowercase()
                    if (!githubToken.isNullOrBlank() && (host == "api.github.com" || host == "github.com")) {
                        setRequestProperty("Authorization", "Bearer ${githubToken.trim()}")
                    }
                    if (host == "api.github.com") {
                        setRequestProperty("Accept", "application/octet-stream")
                    }
                }

                val status = connection.responseCode
                if (status in listOf(
                        HttpURLConnection.HTTP_MOVED_TEMP,
                        HttpURLConnection.HTTP_MOVED_PERM,
                        HttpURLConnection.HTTP_SEE_OTHER,
                        307,
                        308
                    )
                ) {
                    val location = connection.getHeaderField("Location")
                        ?: throw Exception("Redirect status $status missing Location header")
                    connection.disconnect()
                    currentUrl = location
                    redirects++
                    continue
                }
                break
            }

            val finalConn = connection ?: throw Exception("Failed to open HTTP connection")
            val responseCode = finalConn.responseCode
            if (responseCode !in 200..299) {
                val errText = try {
                    finalConn.errorStream?.bufferedReader()?.readText()?.take(300) ?: "HTTP $responseCode"
                } catch (_: Exception) {
                    "HTTP $responseCode"
                }
                finalConn.disconnect()
                return JSONObject().apply {
                    put("success", false)
                    put("status", responseCode)
                    put("error", "Download failed with HTTP $responseCode: $errText")
                }.toString()
            }

            var totalBytes = 0L
            finalConn.inputStream.use { input ->
                FileOutputStream(targetFile).use { output ->
                    val buffer = ByteArray(16 * 1024)
                    var bytesRead: Int
                    while (input.read(buffer).also { bytesRead = it } != -1) {
                        output.write(buffer, 0, bytesRead)
                        totalBytes += bytesRead
                    }
                    output.flush()
                }
            }
            finalConn.disconnect()

            JSONObject().apply {
                put("success", true)
                put("filePath", targetFile.absolutePath)
                put("fileName", safeFileName)
                put("bytesDownloaded", totalBytes)
                put("message", "Saved to Downloads/$safeFileName ($totalBytes bytes)")
            }.toString()
        } catch (e: Exception) {
            Log.e(TAG, "downloadReleaseAssetApk failed", e)
            JSONObject().apply {
                put("success", false)
                put("error", e.message ?: "Native APK download failed")
            }.toString()
        }
    }

    /**
     * Launches the Android system package installer for a downloaded APK in the Downloads directory.
     */
    @JavascriptInterface
    fun installDownloadedApk(filePath: String): String {
        return try {
            val file = File(filePath)
            if (!file.exists()) {
                return JSONObject().put("success", false).put("error", "APK file not found at $filePath").toString()
            }

            val apkUri: Uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                FileProvider.getUriForFile(
                    context,
                    "${context.packageName}.fileprovider",
                    file
                )
            } else {
                Uri.fromFile(file)
            }

            val installIntent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(apkUri, "application/vnd.android.package-archive")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(installIntent)

            JSONObject().apply {
                put("success", true)
                put("filePath", file.absolutePath)
                put("message", "Android package installer launched")
            }.toString()
        } catch (e: Exception) {
            Log.e(TAG, "installDownloadedApk failed", e)
            JSONObject().apply {
                put("success", false)
                put("error", e.message ?: "Failed to launch APK installer")
            }.toString()
        }
    }

    // =========================================================================
    // ITEM 6: BANKING SHIELD SELF-TEST & INSTALLED APPS AUDIT
    // =========================================================================

    /**
     * Lists installed launchable apps on the phone and evaluates each against
     * BankingSafetyConfig (isBlocked + looksFinancial) so the user can verify
     * Banking Shield protection on their real phone and add any unblocked financial app.
     */
    @JavascriptInterface
    fun getInstalledAppsJson(): String {
        return try {
            val pm = context.packageManager
            val packages = pm.getInstalledApplications(PackageManager.GET_META_DATA)
            val appsArray = JSONArray()

            for (appInfo in packages) {
                // Include user-installed apps and updated/launchable system apps
                val launchIntent = pm.getLaunchIntentForPackage(appInfo.packageName)
                val isUserApp = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) == 0
                if (!isUserApp && launchIntent == null) continue

                val pkgName = appInfo.packageName ?: continue
                val appLabel = try {
                    pm.getApplicationLabel(appInfo).toString()
                } catch (_: Exception) {
                    pkgName
                }

                val isBlocked = BankingSafetyConfig.isBlockedFinancialPackage(pkgName)
                val looksFinancial = BankingSafetyConfig.looksLikeFinancialApp(pkgName, appLabel)
                val isCustomBlocked = BankingSafetyConfig.CUSTOM_BLOCKED_PACKAGES.contains(pkgName.lowercase())

                val item = JSONObject().apply {
                    put("packageName", pkgName)
                    put("appName", appLabel)
                    put("isUserApp", isUserApp)
                    put("isBlocked", isBlocked)
                    put("isCustomBlocked", isCustomBlocked)
                    put("looksFinancial", looksFinancial)
                    put("flaggedUnblockedFinancial", looksFinancial && !isBlocked)
                }
                appsArray.put(item)
            }

            JSONObject().apply {
                put("success", true)
                put("source", "android_package_manager")
                put("apps", appsArray)
            }.toString()
        } catch (e: Exception) {
            Log.e(TAG, "getInstalledAppsJson failed", e)
            JSONObject().apply {
                put("success", false)
                put("error", e.message ?: "Failed to query PackageManager")
            }.toString()
        }
    }

    @JavascriptInterface
    fun addCustomBlockedPackage(packageName: String): String {
        return try {
            val clean = packageName.trim().lowercase()
            BankingSafetyConfig.addCustomBlockedPackage(clean)
            val prefs = context.getSharedPreferences(CUSTOM_BLOCKLIST_PREFS, Context.MODE_PRIVATE)
            val updated = HashSet(BankingSafetyConfig.CUSTOM_BLOCKED_PACKAGES)
            prefs.edit().putStringSet("packages", updated).apply()

            JSONObject().apply {
                put("success", true)
                put("packageName", clean)
                put("isBlocked", BankingSafetyConfig.isBlockedFinancialPackage(clean))
            }.toString()
        } catch (e: Exception) {
            JSONObject().put("success", false).put("error", e.message ?: "Failed to add package").toString()
        }
    }

    @JavascriptInterface
    fun removeCustomBlockedPackage(packageName: String): String {
        return try {
            val clean = packageName.trim().lowercase()
            BankingSafetyConfig.removeCustomBlockedPackage(clean)
            val prefs = context.getSharedPreferences(CUSTOM_BLOCKLIST_PREFS, Context.MODE_PRIVATE)
            val updated = HashSet(BankingSafetyConfig.CUSTOM_BLOCKED_PACKAGES)
            prefs.edit().putStringSet("packages", updated).apply()

            JSONObject().apply {
                put("success", true)
                put("packageName", clean)
                put("isBlocked", BankingSafetyConfig.isBlockedFinancialPackage(clean))
            }.toString()
        } catch (e: Exception) {
            JSONObject().put("success", false).put("error", e.message ?: "Failed to remove package").toString()
        }
    }

    // =========================================================================
    // ACCESSIBILITY & DEVICE CONTROL BRIDGE
    // =========================================================================

    @JavascriptInterface
    fun getStatusJson(): String {
        val service = AgentVoiceAccessibilityService.instance
        val isEnabled = service != null || isAccessibilityServiceEnabledInSettings()
        val keyguardManager = context.getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
        val isDeviceLocked = keyguardManager?.isKeyguardLocked ?: false
        val isDeviceSecure = keyguardManager?.isDeviceSecure ?: false

        val json = JSONObject().apply {
            put("bridgeAvailable", true)
            put("serviceConnected", service != null)
            put("serviceEnabledInSettings", isEnabled)
            put("currentPackage", service?.currentForegroundPackage ?: "")
            put("sdkInt", Build.VERSION.SDK_INT)
            put("lockScreenSupported", Build.VERSION.SDK_INT >= Build.VERSION_CODES.P)
            put("isDeviceLocked", isDeviceLocked)
            put("isDeviceSecure", isDeviceSecure)
        }
        return json.toString()
    }

    @JavascriptInterface
    fun openAccessibilitySettings(): Boolean {
        return try {
            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun confirmIrreversibleAction(actionLabel: String): Boolean {
        val activity = context as? android.app.Activity ?: return false
        val latch = java.util.concurrent.CountDownLatch(1)
        val approved = java.util.concurrent.atomic.AtomicBoolean(false)
        val mainHandler = android.os.Handler(android.os.Looper.getMainLooper())
        mainHandler.post {
            try {
                val dialog = android.app.AlertDialog.Builder(activity)
                    .setTitle("Confirm Action")
                    .setMessage("Allow Zoya to perform: \"$actionLabel\"?")
                    .setCancelable(false)
                    .setPositiveButton("Confirm") { _, _ ->
                        approved.set(true)
                        latch.countDown()
                    }
                    .setNegativeButton("Cancel") { _, _ ->
                        approved.set(false)
                        latch.countDown()
                    }
                    .create()
                dialog.show()
                mainHandler.postDelayed({
                    if (dialog.isShowing) {
                        try { dialog.dismiss() } catch (_: Exception) {}
                        latch.countDown()
                    }
                }, 15_000L)
            } catch (_: Exception) {
                latch.countDown()
            }
        }
        return try {
            latch.await(16, java.util.concurrent.TimeUnit.SECONDS)
            approved.get()
        } catch (_: InterruptedException) {
            false
        }
    }

    @JavascriptInterface
    fun executeActionJson(payloadJson: String): String {
        val parsed = try { JSONObject(payloadJson) } catch (_: Exception) { null }
        val actionName = parsed?.optString("action", "")?.lowercase() ?: ""
        val service = AgentVoiceAccessibilityService.instance
        if (service == null && actionName != "unlock_device") {
            android.os.Handler(android.os.Looper.getMainLooper()).post {
                android.widget.Toast.makeText(
                    context,
                    "Please enable Zoya Accessibility Service",
                    android.widget.Toast.LENGTH_LONG
                ).show()
            }
            openAccessibilitySettings()
            return JSONObject().apply {
                put("success", false)
                put("error", "Accessibility Service is not enabled. Opening settings...")
                put("requiresPermission", true)
            }.toString()
        }

        val targetText = parsed?.optString("text", parsed.optString("target", ""))?.lowercase() ?: ""
        val combined = "$actionName $targetText"
        val isIrreversible = listOf("delete", "remove", "send", "pay", "transfer", "submit", "uninstall").any {
            combined.contains(it)
        }
        if (isIrreversible && !confirmIrreversibleAction(combined.trim().ifEmpty { actionName })) {
            return JSONObject().apply {
                put("success", false)
                put("cancelled", true)
                put("error", "Action cancelled or timed out (15s) without user confirmation.")
            }.toString()
        }

        return try {
            val payload = JSONObject(payloadJson)
            val action = payload.optString("action", "")
            var success = false
            var message = ""
            var dataObj: Any? = null

            when (action) {
                "global_action" -> {
                    val cmd = payload.optString("command", "HOME")
                    success = service.executeGlobalCommand(cmd)
                    message = if (success) "Executed $cmd" else "Failed to execute $cmd"
                }
                "lock_device" -> {
                    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) {
                        success = false
                        message = "Lock screen requires Android 9.0 (API 28) or higher"
                        dataObj = JSONObject().put("code", "UNSUPPORTED_ANDROID_VERSION")
                    } else {
                        success = service.lockDeviceScreen()
                        message = if (success) "Device locked via Accessibility" else "Failed to lock device screen"
                    }
                }
                "unlock_device" -> {
                    return requestDeviceUnlockJson()
                }
                "scroll" -> {
                    val dir = payload.optString("direction", "down")
                    success = service.scrollScreen(dir)
                    message = if (success) "Scrolled $dir" else "No scrollable view found"
                }
                "click_text" -> {
                    val text = payload.optString("text", "")
                    success = service.clickNodeByText(text)
                    message = if (success) "Clicked '$text'" else "Could not find '$text' on screen"
                }
                "type_text" -> {
                    val text = payload.optString("text", "")
                    val targetHint = if (payload.has("targetHint")) payload.optString("targetHint") else null
                    success = service.inputText(text, targetHint)
                    message = if (success) "Typed '$text'" else "No input field found"
                }
                "tap" -> {
                    val x = payload.optDouble("x", 500.0).toFloat()
                    val y = payload.optDouble("y", 500.0).toFloat()
                    success = service.tapCoordinates(x, y)
                    message = "Tapped ($x, $y)"
                }
                "swipe" -> {
                    val startX = payload.optDouble("startX", 500.0).toFloat()
                    val startY = payload.optDouble("startY", 1400.0).toFloat()
                    val endX = payload.optDouble("endX", 500.0).toFloat()
                    val endY = payload.optDouble("endY", 400.0).toFloat()
                    val duration = payload.optLong("durationMs", 350L)
                    success = service.swipeGesture(startX, startY, endX, endY, duration)
                    message = "Swiped from ($startX,$startY) to ($endX,$endY)"
                }
                "open_app" -> {
                    val appNameOrPkg = payload.optString("app", "")
                    success = service.openAppByPackageOrName(appNameOrPkg)
                    message = if (success) "Opened $appNameOrPkg" else "App '$appNameOrPkg' not found"
                }
                "read_screen" -> {
                    val summary = service.getScreenContextSummary()
                    success = true
                    message = "Screen context captured"
                    dataObj = JSONObject(summary)
                }
                "media_control" -> {
                    val mediaCmd = payload.optString("command", "play_pause")
                    success = service.clickNodeByText(mediaCmd)
                    message = if (success) "Media action '$mediaCmd' executed" else "Media control '$mediaCmd' dispatched"
                }
                else -> {
                    message = "Unknown accessibility action: $action"
                }
            }

            JSONObject().apply {
                put("success", success)
                put("action", action)
                put("message", message)
                if (dataObj != null) put("data", dataObj)
            }.toString()
        } catch (e: Exception) {
            JSONObject().apply {
                put("success", false)
                put("error", e.message ?: "Invalid JSON payload")
            }.toString()
        }
    }

    @JavascriptInterface
    fun lockDeviceJson(): String {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) {
            return JSONObject().apply {
                put("success", false)
                put("code", "UNSUPPORTED_ANDROID_VERSION")
                put("error", "Lock screen requires Android 9.0 (Pie / API 28) or higher.")
            }.toString()
        }

        val service = AgentVoiceAccessibilityService.instance
        if (service == null) {
            return JSONObject().apply {
                put("success", false)
                put("code", "ACCESSIBILITY_REQUIRED")
                put("requiresPermission", true)
                put("error", "Zoya Accessibility Service is not enabled. Enable it in Settings to lock screen.")
            }.toString()
        }

        val locked = service.lockDeviceScreen()
        return JSONObject().apply {
            put("success", locked)
            put("action", "lock_device")
            put("message", if (locked) "Device screen locked successfully." else "Failed to lock device screen.")
        }.toString()
    }

    @JavascriptInterface
    fun requestDeviceUnlockJson(): String {
        val activity = context as? MainActivity
        if (activity == null) {
            return JSONObject().apply {
                put("success", false)
                put("code", "ACTIVITY_UNAVAILABLE")
                put("error", "MainActivity context is required to launch system Keyguard unlock prompt.")
            }.toString()
        }

        return activity.requestSystemKeyguardDismiss()
    }

    @JavascriptInterface
    fun canDrawOverlays(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(context)
        } else {
            true
        }
    }

    @JavascriptInterface
    fun requestOverlayPermission(): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(context)) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:${context.packageName}")
                ).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    @JavascriptInterface
    fun startFloatingHologram(styleId: Int, sizeDp: Int): String {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(context)) {
            return JSONObject().apply {
                put("success", false)
                put("requiresOverlayPermission", true)
                put("error", "Display over other apps permission is required for Floating 3D Hologram.")
            }.toString()
        }

        return try {
            val configJson = JSONObject().apply {
                put("styleId", styleId)
                put("sizeDp", sizeDp)
            }.toString()
            ZoyaHologramOverlayService.start(context, null, configJson)
            JSONObject().apply {
                put("success", true)
                put("running", true)
                put("styleId", styleId)
            }.toString()
        } catch (e: Exception) {
            JSONObject().apply {
                put("success", false)
                put("error", e.message ?: "Failed to start ZoyaHologramOverlayService")
            }.toString()
        }
    }

    @JavascriptInterface
    fun stopFloatingHologram(): String {
        return try {
            ZoyaHologramOverlayService.stop(context)
            JSONObject().apply {
                put("success", true)
                put("running", false)
            }.toString()
        } catch (e: Exception) {
            JSONObject().apply {
                put("success", false)
                put("error", e.message ?: "Failed to stop ZoyaHologramOverlayService")
            }.toString()
        }
    }

    @JavascriptInterface
    fun updateFloatingHologramState(voiceStatus: String, audioLevel: Float, styleId: Int, sizeDp: Int): Boolean {
        return try {
            if (!ZoyaHologramOverlayService.isOverlayRunning) return false
            val stateJson = JSONObject().apply {
                put("voiceStatus", voiceStatus)
                put("audioLevel", audioLevel.toDouble())
                put("styleId", styleId)
                put("sizeDp", sizeDp)
            }.toString()
            ZoyaHologramOverlayService.updateState(context, stateJson)
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun isAccessibilityServiceEnabledInSettings(): Boolean {
        val expectedComponentName = "${context.packageName}/${AgentVoiceAccessibilityService::class.java.canonicalName}"
        val enabledServices = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabledServices.split(':').any { it.equals(expectedComponentName, ignoreCase = true) }
    }

    // =========================================================================
    // NATIVE ANDROID BATTERY VOICE ALERT SYSTEM BRIDGE
    // =========================================================================

    @JavascriptInterface
    fun getBatteryLevel(): Int {
        return try {
            val batteryIntent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val rawLevel = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = batteryIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
            if (rawLevel != -1 && scale > 0) (rawLevel * 100 / scale.toFloat()).toInt() else -1
        } catch (e: Exception) {
            -1
        }
    }

    @JavascriptInterface
    fun isCharging(): Boolean {
        return try {
            val batteryIntent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val status = batteryIntent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
            status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        } catch (e: Exception) {
            false
        }
    }

    @JavascriptInterface
    fun getBatteryStatus(): String {
        return try {
            val batteryIntent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val rawLevel = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = batteryIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
            val level = if (rawLevel != -1 && scale > 0) (rawLevel * 100 / scale.toFloat()).toInt() else -1
            val status = batteryIntent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
            val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                             status == BatteryManager.BATTERY_STATUS_FULL

            JSONObject().apply {
                put("level", level)
                put("isCharging", isCharging)
                put("source", "Android BatteryManager")
            }.toString()
        } catch (e: Exception) {
            JSONObject().apply {
                put("level", -1)
                put("isCharging", false)
                put("error", e.message ?: "Failed to read BatteryManager")
            }.toString()
        }
    }

    @JavascriptInterface
    fun setBatteryVoiceAlertsEnabled(enabled: Boolean): Boolean {
        return try {
            val prefs = context.getSharedPreferences("zoya_battery_prefs", Context.MODE_PRIVATE)
            prefs.edit().putBoolean("zoya_battery_voice_alerts_enabled", enabled).apply()
            true
        } catch (e: Exception) {
            false
        }
    }

    @JavascriptInterface
    fun isBatteryVoiceAlertsEnabled(): Boolean {
        return try {
            val prefs = context.getSharedPreferences("zoya_battery_prefs", Context.MODE_PRIVATE)
            prefs.getBoolean("zoya_battery_voice_alerts_enabled", true)
        } catch (e: Exception) {
            true
        }
    }

    @JavascriptInterface
    fun setChargingAnnouncementsEnabled(enabled: Boolean): Boolean {
        return try {
            val prefs = context.getSharedPreferences("zoya_battery_prefs", Context.MODE_PRIVATE)
            prefs.edit().putBoolean("zoya_battery_charging_announcements_enabled", enabled).apply()
            true
        } catch (e: Exception) {
            false
        }
    }

    @JavascriptInterface
    fun isChargingAnnouncementsEnabled(): Boolean {
        return try {
            val prefs = context.getSharedPreferences("zoya_battery_prefs", Context.MODE_PRIVATE)
            prefs.getBoolean("zoya_battery_charging_announcements_enabled", true)
        } catch (e: Exception) {
            true
        }
    }

    @JavascriptInterface
    fun setLowBatteryWarningsEnabled(enabled: Boolean): Boolean {
        return try {
            val prefs = context.getSharedPreferences("zoya_battery_prefs", Context.MODE_PRIVATE)
            prefs.edit().putBoolean("zoya_battery_low_warnings_enabled", enabled).apply()
            true
        } catch (e: Exception) {
            false
        }
    }

    @JavascriptInterface
    fun isLowBatteryWarningsEnabled(): Boolean {
        return try {
            val prefs = context.getSharedPreferences("zoya_battery_prefs", Context.MODE_PRIVATE)
            prefs.getBoolean("zoya_battery_low_warnings_enabled", true)
        } catch (e: Exception) {
            true
        }
    }

    @JavascriptInterface
    fun setFlightModeAnnouncementsEnabled(enabled: Boolean): Boolean {
        return try {
            val prefs = context.getSharedPreferences("zoya_battery_prefs", Context.MODE_PRIVATE)
            prefs.edit().putBoolean("zoya_flight_mode_announcements_enabled", enabled).apply()
            true
        } catch (e: Exception) {
            false
        }
    }

    @JavascriptInterface
    fun isFlightModeAnnouncementsEnabled(): Boolean {
        return try {
            val prefs = context.getSharedPreferences("zoya_battery_prefs", Context.MODE_PRIVATE)
            prefs.getBoolean("zoya_flight_mode_announcements_enabled", true)
        } catch (e: Exception) {
            true
        }
    }

    @JavascriptInterface
    fun setAppInstallAnnouncementsEnabled(enabled: Boolean): Boolean {
        return try {
            val prefs = context.getSharedPreferences("zoya_battery_prefs", Context.MODE_PRIVATE)
            prefs.edit().putBoolean("zoya_app_install_announcements_enabled", enabled).apply()
            true
        } catch (e: Exception) {
            false
        }
    }

    @JavascriptInterface
    fun isAppInstallAnnouncementsEnabled(): Boolean {
        return try {
            val prefs = context.getSharedPreferences("zoya_battery_prefs", Context.MODE_PRIVATE)
            prefs.getBoolean("zoya_app_install_announcements_enabled", true)
        } catch (e: Exception) {
            true
        }
    }

    @JavascriptInterface
    fun isAirplaneMode(): Boolean {
        return try {
            Settings.Global.getInt(context.contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) != 0
        } catch (e: Exception) {
            false
        }
    }

    // Native offline TTS engine for Flight Mode and offline announcements
    private var nativeTts: TextToSpeech? = null
    private var isTtsReady: Boolean = false

    private fun ensureNativeTts() {
        if (nativeTts == null) {
            nativeTts = TextToSpeech(context.applicationContext) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    val langRes = nativeTts?.setLanguage(Locale("hi", "IN"))
                    if (langRes == TextToSpeech.LANG_MISSING_DATA || langRes == TextToSpeech.LANG_NOT_SUPPORTED) {
                        nativeTts?.setLanguage(Locale.US)
                    }
                    isTtsReady = true
                }
            }
        }
    }

    @JavascriptInterface
    fun speakOffline(text: String): Boolean {
        return try {
            ensureNativeTts()
            if (isTtsReady && nativeTts != null) {
                val utteranceId = "zoya_offline_${System.currentTimeMillis()}"
                nativeTts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
                true
            } else {
                false
            }
        } catch (e: Exception) {
            Log.e(TAG, "Offline TTS failed: ${e.message}")
            false
        }
    }

    // =========================================================================
    // ZOYA SERVICE: OPENWAKEWORD & SINGLE MICROPHONE OWNERSHIP BRIDGE
    // =========================================================================

    @JavascriptInterface
    fun startWakeWordService(languageCode: String = "hi-IN"): String {
        return try {
            val intent = android.content.Intent(context, ZoyaService::class.java).apply {
                action = ZoyaService.ACTION_START
                putExtra(ZoyaService.EXTRA_LANGUAGE_CODE, languageCode)
            }
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
            JSONObject().put("success", true).toString()
        } catch (e: Exception) {
            JSONObject().put("success", false).put("error", e.message ?: "Failed to start ZoyaService").toString()
        }
    }

    @JavascriptInterface
    fun stopWakeWordService(): String {
        return try {
            val intent = android.content.Intent(context, ZoyaService::class.java).apply {
                action = ZoyaService.ACTION_STOP
            }
            context.startService(intent)
            JSONObject().put("success", true).toString()
        } catch (e: Exception) {
            JSONObject().put("success", false).put("error", e.message ?: "Failed to stop ZoyaService").toString()
        }
    }

    @JavascriptInterface
    fun pauseWakeWordListening(): String {
        return try {
            if (ZoyaService.isServiceRunning) {
                val intent = android.content.Intent(context, ZoyaService::class.java).apply {
                    action = ZoyaService.ACTION_PAUSE_TTS
                }
                context.startService(intent)
            }
            JSONObject().put("success", true).put("micReleased", true).toString()
        } catch (e: Exception) {
            JSONObject().put("success", false).put("error", e.message ?: "Failed to pause ZoyaService").toString()
        }
    }

    @JavascriptInterface
    fun resumeWakeWordListening(): String {
        return try {
            if (ZoyaService.isServiceRunning) {
                val intent = android.content.Intent(context, ZoyaService::class.java).apply {
                    action = ZoyaService.ACTION_RESUME_TTS
                }
                context.startService(intent)
            }
            JSONObject().put("success", true).toString()
        } catch (e: Exception) {
            JSONObject().put("success", false).put("error", e.message ?: "Failed to resume ZoyaService").toString()
        }
    }

    @JavascriptInterface
    fun restartWakeWordEngine(): String {
        stopWakeWordService()
        return startWakeWordService()
    }

    @JavascriptInterface
    fun getWakeWordStatusJson(): String {
        return try {
            var assetModelExists = false
            try {
                context.assets.open(ZoyaService.MODEL_ASSET).close()
                assetModelExists = true
            } catch (_: Exception) {}

            val hasMicPermission = androidx.core.content.ContextCompat.checkSelfPermission(
                context,
                android.Manifest.permission.RECORD_AUDIO
            ) == android.content.pm.PackageManager.PERMISSION_GRANTED

            val canDrawOverlay = android.provider.Settings.canDrawOverlays(context)

            val powerManager = context.getSystemService(Context.POWER_SERVICE) as? android.os.PowerManager
            val isBatteryOptIgnored = powerManager?.isIgnoringBatteryOptimizations(context.packageName) ?: false

            val hasNotificationPermission = if (android.os.Build.VERSION.SDK_INT >= 33) {
                androidx.core.content.ContextCompat.checkSelfPermission(
                    context,
                    android.Manifest.permission.POST_NOTIFICATIONS
                ) == android.content.pm.PackageManager.PERMISSION_GRANTED
            } else {
                true
            }

            JSONObject().apply {
                put("success", true)
                put("engine", "OpenWakeWord + SpeechRecognizer")
                put("wakeWord", "Hey Zoya")
                put("modelPath", ZoyaService.MODEL_ASSET)
                put("modelExists", assetModelExists)
                put("fallbackActive", !assetModelExists)
                put("isServiceRunning", ZoyaService.isServiceRunning)
                put("hasMicPermission", hasMicPermission)
                put("canDrawOverlay", canDrawOverlay)
                put("hasNotificationPermission", hasNotificationPermission)
                put("isBatteryOptimizationIgnored", isBatteryOptIgnored)
            }.toString()
        } catch (e: Exception) {
            JSONObject().apply {
                put("success", false)
                put("error", e.message ?: "Failed to query wake word status")
            }.toString()
        }
    }
}
