# Pytest Automated Testing Suite in Zoya Python Studio
import pytest
import math

def calculate_hologram_enlargement(base_px: int, ratio: float) -> int:
    if ratio < 1.0 or ratio > 2.0:
        raise ValueError("Enlargement ratio must be between 1.0 and 2.0")
    return round(base_px * ratio)

def sanitize_voice_command(cmd: str) -> str:
    cleaned = cmd.lower().strip()
    for prefix in ["zoya", "hey zoya", "hello zoya"]:
        if cleaned.startswith(prefix):
            cleaned = cleaned[len(prefix):].strip(" ,;:-")
    return cleaned

def test_hologram_enlargement_valid():
    assert calculate_hologram_enlargement(360, 1.35) == 486
    assert calculate_hologram_enlargement(100, 1.5) == 150
    assert calculate_hologram_enlargement(200, 1.0) == 200

def test_hologram_enlargement_invalid():
    with pytest.raises(ValueError):
        calculate_hologram_enlargement(360, 0.8)
    with pytest.raises(ValueError):
        calculate_hologram_enlargement(360, 2.5)

def test_voice_sanitization():
    assert sanitize_voice_command("Hey Zoya, open YouTube") == "open youtube"
    assert sanitize_voice_command("Zoya, run this python script") == "run this python script"
    assert sanitize_voice_command("scroll down") == "scroll down"

if __name__ == "__main__":
    print("Running pytest via programmatic invocation...")
    ret = pytest.main(["-v", "test_suite.py"])
    print(f"Pytest exit code: {ret}")
