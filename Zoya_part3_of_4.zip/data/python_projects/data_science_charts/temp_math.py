
import math
print("Computed square root of 256:", math.isqrt(256))
print("Computed factorial of 6:", math.factorial(6))
