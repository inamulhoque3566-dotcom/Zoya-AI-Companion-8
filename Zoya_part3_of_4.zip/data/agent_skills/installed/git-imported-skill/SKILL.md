---
name: git-imported-skill
description: Git-based public repository skill format verification.
version: 1.0.0
tags: [git, public, format]
---
# Git Public Skill
Valid git skill structure.
