import sys
print("ZOYA_SKILL_RESULT: 42 * 42 = " + str(42 * 42))
