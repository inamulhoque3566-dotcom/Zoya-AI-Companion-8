package com.openclaw.assistant.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import com.openclaw.assistant.MainActivity
import com.openclaw.assistant.R
import com.openwakeword.OpenWakeWord

/**
 * "Hey Zoya" persistent background microphone service (migrated from hey-zoya-app.zip).
 *
 *  - Corner me chhota HARA dot  = mic ON, "Hey Zoya" ka intezaar
 *  - "Hey Zoya" bolte hi beep + dot bada = mic active, baat sun raha hai
 *
 * Do tarike (apne aap chunta hai):
 *  1) assets/openwakeword/hey_zoya.onnx maujood ho -> offline wake word model (best, kam battery)
 *  2) model na ho -> phone ki speech recognition se "zoya" shabd pakadta hai (koi file nahi chahiye)
 */
class ZoyaService : Service() {

    companion object {
        const val MODEL_ASSET = "openwakeword/hey_zoya.onnx"
        const val ACTION_START = "com.openclaw.assistant.action.ZOYA_MIC_START"
        const val ACTION_STOP = "com.openclaw.assistant.action.ZOYA_MIC_STOP"
        const val ACTION_PAUSE_TTS = "com.openclaw.assistant.action.ZOYA_MIC_PAUSE_TTS"
        const val ACTION_RESUME_TTS = "com.openclaw.assistant.action.ZOYA_MIC_RESUME_TTS"
        const val BROADCAST_WAKE_DETECTED = "com.openclaw.assistant.ZOYA_WAKE_DETECTED"
        const val BROADCAST_VOICE_COMMAND = "com.openclaw.assistant.ZOYA_VOICE_COMMAND"
        const val BROADCAST_STATE = "com.openclaw.assistant.ZOYA_STATE"
        const val EXTRA_STATE = "state"
        const val EXTRA_LANGUAGE_CODE = "language_code"

        private const val CHANNEL_ID = "zoya_listening"
        private const val NOTIF_ID = 101

        private const val DOT_IDLE_DP = 10
        private const val DOT_ACTIVE_DP = 22
        private const val DOT_MARGIN_RIGHT_DP = 8
        private const val DOT_MARGIN_TOP_DP = 40
        private const val COMMAND_TIMEOUT_MS = 15_000L
        private const val DUPLICATE_COMMAND_DEBOUNCE_MS = 2_000L

        @Volatile
        var isServiceRunning: Boolean = false
            private set

        private val KEYWORDS = listOf(
            "zoya", "zoyaa", "joya", "joyaa", "zoia", "zoiya", "soya",
            "zohra", "zohaya", "zoe", "zoey", "zora", "johaia",
            "hello hello", "hello, hello", "helo helo",
            "hello zoya", "helo zoya", "hey zoya", "hi zoya", "ok zoya", "okay zoya",
            "ज़ोया", "जोया", "झोया", "ज़ोय", "जोयाा", "ज़ोईया", "जोईया", "ज़ोई", "जोई",
            "ज़ोहरा", "जोहरा", "ज़ोहाया", "जोहाया", "ज़ोए",
            "हे ज़ोया", "हे जोया", "हैलो ज़ोया", "हैलो जोया", "हेलो ज़ोया", "हेलो जोया",
            "हैलो हैलो", "हेलो हेलो"
        )
    }

    private val main = Handler(Looper.getMainLooper())
    private var detector: OpenWakeWord? = null     // model mode
    private var recognizer: SpeechRecognizer? = null
    private var dot: View? = null
    private var dotParams: WindowManager.LayoutParams? = null
    private var tone: ToneGenerator? = null
    private var audioManager: AudioManager? = null
    private var audioFocusRequest: android.media.AudioFocusRequest? = null
    private var running = false
    private var pausedForTts = false
    private var languageCode = "hi-IN"
    private var lastCommandText = ""
    private var lastCommandTimeMs = 0L
    private var lastWakeTimeMs = 0L
    private var consecutiveFailures = 0
    private var keywordCycleCount = 0
    private val timeoutRunnable = Runnable { resumeWakeListening() }
    private val ttsSafetyTimeoutRunnable = Runnable {
        if (pausedForTts && running) {
            pausedForTts = false
            resumeWakeListening()
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        intent?.getStringExtra(EXTRA_LANGUAGE_CODE)?.takeIf { it.isNotBlank() }?.let {
            languageCode = it
        }

        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_PAUSE_TTS -> {
                pausedForTts = true
                main.removeCallbacks(timeoutRunnable)
                main.removeCallbacks(ttsSafetyTimeoutRunnable)
                recognizer?.destroy()
                recognizer = null
                detector?.stop()
                setDot(active = false)
                broadcastState("SPEAKING")
                main.postDelayed(ttsSafetyTimeoutRunnable, 15_000L)
                return START_STICKY
            }
            ACTION_RESUME_TTS -> {
                main.removeCallbacks(ttsSafetyTimeoutRunnable)
                if (pausedForTts) {
                    pausedForTts = false
                    main.postDelayed({
                        if (running && !pausedForTts) resumeWakeListening()
                    }, 400L)
                }
                return START_STICKY
            }
        }

        startAsForeground()
        if (!running) {
            running = true
            isServiceRunning = true
            showDot()
            if (modelExists()) {
                detector = OpenWakeWord.Builder(this)
                    .setModelAsset(MODEL_ASSET)
                    .setThreshold(0.5f)
                    .setDebounceMs(1500)
                    .build()
            }
            resumeWakeListening()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        isServiceRunning = false
        pausedForTts = false
        main.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        recognizer = null
        detector?.release()
        detector = null
        abandonCommandAudioFocus()
        removeDot()
        tone?.release()
        tone = null
        super.onDestroy()
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        if (running) {
            try {
                val restartIntent = Intent(applicationContext, ZoyaService::class.java).apply {
                    action = ACTION_START
                }
                val pi = PendingIntent.getService(
                    applicationContext, 1001, restartIntent,
                    PendingIntent.FLAG_ONE_SHOT or PendingIntent.FLAG_IMMUTABLE
                )
                val am = getSystemService(ALARM_SERVICE) as? android.app.AlarmManager
                am?.set(android.app.AlarmManager.ELAPSED_REALTIME, android.os.SystemClock.elapsedRealtime() + 1000L, pi)
            } catch (_: Exception) {}
        }
        super.onTaskRemoved(rootIntent)
    }

    // ---------------- Wake word listening ----------------

    private fun resumeWakeListening() {
        if (!running || pausedForTts) return
        main.removeCallbacks(timeoutRunnable)
        abandonCommandAudioFocus()
        recognizer?.destroy()
        recognizer = null
        setDot(active = false)
        broadcastState("IDLE_LISTENING")
        val d = detector
        if (d != null) {
            android.util.Log.d("ZoyaService", "Wake mode: OpenWakeWord ONNX")
            d.start { onWakeWord() }
        } else {
            android.util.Log.d("ZoyaService", "Wake mode: SpeechRecognizer keyword fallback ($languageCode)")
            startKeywordListening()
        }
    }

    private fun onWakeWord() {
        if (!running || pausedForTts) return
        val now = System.currentTimeMillis()
        if (now - lastWakeTimeMs < DUPLICATE_COMMAND_DEBOUNCE_MS) return
        lastWakeTimeMs = now
        try {
            if (tone == null) tone = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 80)
            tone?.startTone(ToneGenerator.TONE_PROP_BEEP, 120)
        } catch (_: Exception) {}
        setDot(active = true)
        broadcastState("WAKE_DETECTED")

        sendBroadcast(Intent(BROADCAST_WAKE_DETECTED).apply {
            setPackage(packageName)
        })

        val d = detector
        if (d != null) {
            // mic detector se chhodna padta hai taaki SpeechRecognizer use kar sake
            Thread {
                d.stop()
                main.post { startCommandListening() }
            }.start()
        } else {
            recognizer?.destroy()
            recognizer = null
            startCommandListening()
        }
    }

    // ---------------- Fallback: keyword via speech recognition ----------------

    private fun startKeywordListening() {
        if (!running || pausedForTts) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : SimpleListener() {
                override fun onReadyForSpeech(params: Bundle?) {
                    consecutiveFailures = 0
                }
                override fun onPartialResults(partialResults: Bundle?) {
                    consecutiveFailures = 0
                    check(partialResults)
                }
                override fun onResults(results: Bundle?) {
                    consecutiveFailures = 0
                    if (!check(results)) restartKeywordSoon(250L)
                }
                override fun onError(error: Int) {
                    if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                        android.util.Log.e("ZoyaService", "Mic permission missing; stopping fallback loop")
                        stopSelf()
                        return
                    }
                    if (error == SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED && languageCode != "en-IN") {
                        languageCode = "en-IN"
                    }
                    consecutiveFailures++
                    val baseDelay = when (error) {
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY, SpeechRecognizer.ERROR_CLIENT -> 600L
                        else -> 250L
                    }
                    val delayMs = if (consecutiveFailures > 5) {
                        (baseDelay * (1 shl (consecutiveFailures - 5).coerceAtMost(4))).coerceAtMost(5000L)
                    } else {
                        baseDelay
                    }
                    restartKeywordSoon(delayMs)
                }

                private fun check(b: Bundle?): Boolean {
                    val text = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.joinToString(" ")?.lowercase() ?: return false
                    if (KEYWORDS.any { text.contains(it) }) {
                        onWakeWord()
                        return true
                    }
                    return false
                }
            })
        }
        val useEnFallback = (keywordCycleCount % 3 == 1) && languageCode != "en-IN"
        keywordCycleCount++
        recognizer?.startListening(recognizerIntent(partial = true, overrideLang = if (useEnFallback) "en-IN" else null))
    }

    private fun restartKeywordSoon(delayMs: Long = 300L) {
        main.postDelayed({
            if (detector == null && running && !pausedForTts) startKeywordListening()
        }, delayMs)
    }

    // ---------------- Command listening (after "Hey Zoya") ----------------

    private fun startCommandListening() {
        if (!running || pausedForTts) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            resumeWakeListening()
            return
        }
        broadcastState("LISTENING_COMMAND")
        requestCommandAudioFocus()
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : SimpleListener() {
                override fun onResults(results: Bundle?) {
                    val text = results
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()
                    if (!text.isNullOrBlank()) onCommand(text)
                    resumeWakeListening()
                }
                override fun onError(error: Int) = resumeWakeListening()
            })
        }
        recognizer?.startListening(recognizerIntent(partial = false))
        main.postDelayed(timeoutRunnable, COMMAND_TIMEOUT_MS)
    }

    private fun recognizerIntent(partial: Boolean, overrideLang: String? = null) =
        Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            val effectiveLang = overrideLang ?: languageCode
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, effectiveLang)
            putExtra("android.speech.extra.EXTRA_ADDITIONAL_LANGUAGES", arrayOf("en-IN", "hi-IN"))
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, partial)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        }

    /**
     * Dispatches the recognized spoken command into Zoya's existing AI Chat pipeline
     * via MainActivity / AndroidBridge, with duplicate-submission protection.
     */
    private fun onCommand(text: String) {
        val trimmed = text.trim()
        if (trimmed.isEmpty() || pausedForTts) return
        val now = System.currentTimeMillis()
        if (trimmed.equals(lastCommandText, ignoreCase = true) &&
            (now - lastCommandTimeMs) < DUPLICATE_COMMAND_DEBOUNCE_MS
        ) {
            return
        }
        lastCommandText = trimmed
        lastCommandTimeMs = now
        broadcastState("PROCESSING")

        sendBroadcast(Intent(BROADCAST_VOICE_COMMAND).apply {
            setPackage(packageName)
            putExtra("command", trimmed)
        })
    }

    private fun broadcastState(state: String) {
        sendBroadcast(Intent(BROADCAST_STATE).apply {
            setPackage(packageName)
            putExtra(EXTRA_STATE, state)
        })
    }

    private fun requestCommandAudioFocus() {
        try {
            val am = audioManager ?: (getSystemService(AUDIO_SERVICE) as? AudioManager).also { audioManager = it } ?: return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val req = android.media.AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                    .setAudioAttributes(
                        android.media.AudioAttributes.Builder()
                            .setUsage(android.media.AudioAttributes.USAGE_ASSISTANT)
                            .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build()
                    )
                    .build()
                audioFocusRequest = req
                am.requestAudioFocus(req)
            } else {
                @Suppress("DEPRECATION")
                am.requestAudioFocus(null, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
            }
        } catch (_: Exception) {}
    }

    private fun abandonCommandAudioFocus() {
        try {
            val am = audioManager ?: return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                audioFocusRequest?.let { am.abandonAudioFocusRequest(it) }
                audioFocusRequest = null
            } else {
                @Suppress("DEPRECATION")
                am.abandonAudioFocus(null)
            }
        } catch (_: Exception) {}
    }

    private open class SimpleListener : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
        override fun onResults(results: Bundle?) {}
        override fun onError(error: Int) {}
    }

    // ---------------- Green dot overlay ----------------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private var promptedOverlayOnce = false

    private fun showDot() {
        if (!Settings.canDrawOverlays(this)) {
            if (!promptedOverlayOnce) {
                promptedOverlayOnce = true
                main.post {
                    android.widget.Toast.makeText(
                        this,
                        "Please grant 'Display over other apps' for Zoya",
                        android.widget.Toast.LENGTH_LONG
                    ).show()
                }
            }
            return
        }
        try {
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            val view = View(this).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(Color.parseColor("#2ECC40"))
                }
                visibility = if (ZoyaHologramOverlayService.isOverlayRunning) View.GONE else View.VISIBLE
            }
            val params = WindowManager.LayoutParams(
                dp(DOT_IDLE_DP), dp(DOT_IDLE_DP),
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.END
                x = dp(DOT_MARGIN_RIGHT_DP)
                y = dp(DOT_MARGIN_TOP_DP)
            }
            wm.addView(view, params)
            dot = view
            dotParams = params
        } catch (_: Exception) {}
    }

    private fun setDot(active: Boolean) {
        val view = dot ?: return
        val params = dotParams ?: return
        try {
            view.visibility = if (ZoyaHologramOverlayService.isOverlayRunning) View.GONE else View.VISIBLE
            val size = dp(if (active) DOT_ACTIVE_DP else DOT_IDLE_DP)
            params.width = size
            params.height = size
            (getSystemService(WINDOW_SERVICE) as WindowManager).updateViewLayout(view, params)
        } catch (_: Exception) {}
    }

    private fun removeDot() {
        dot?.let {
            try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) } catch (_: Exception) {}
        }
        dot = null
    }

    // ---------------- Foreground notification & model check ----------------

    private fun modelExists(): Boolean =
        try { assets.open(MODEL_ASSET).use { true } } catch (_: Exception) { false }

    private fun startAsForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26 && nm.getNotificationChannel(CHANNEL_ID) == null) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Hey Zoya", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val openIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notif = (if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL_ID)
        else @Suppress("DEPRECATION") Notification.Builder(this))
            .setContentTitle("Zoya sun rahi hai")
            .setContentText("\"Hey Zoya\" bolo...")
            .setSmallIcon(R.drawable.ic_mic)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= 30) {
            startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTIF_ID, notif)
        }
    }
}
