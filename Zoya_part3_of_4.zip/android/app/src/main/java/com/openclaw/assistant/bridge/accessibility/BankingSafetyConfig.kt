package com.openclaw.assistant.bridge.accessibility

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast
import java.util.concurrent.CopyOnWriteArraySet

/**
 * Fail-Closed Banking, UPI & Accessibility Safety Configuration.
 *
 * STRICT FAIL-CLOSED ALLOWLIST POLICY:
 * - Zoya Accessibility Service & Voice Automation ONLY allows automation inside
 *   explicitly allowlisted package names ([ALLOWED_AUTOMATION_PACKAGES]).
 * - Everything else (all unlisted apps, browsers, and all exact banking/UPI/wallet/brokerage
 *   packages) is BLOCKED by default.
 * - Overly broad substring/regex heuristics are removed in favor of exact
 *   package matching + fail-closed allowlist enforcement.
 */
object BankingSafetyConfig {

    const val SAFETY_BLOCKED_MESSAGE =
        "Security Shield: This app is not on the explicit automation allowlist and is blocked for your safety."

    /**
     * Explicit fail-closed allowlist: ONLY these verified non-financial packages may be automated.
     * Any package NOT in this set is automatically blocked.
     */
    val ALLOWED_AUTOMATION_PACKAGES: Set<String> = setOf(
        "com.whatsapp",
        "com.whatsapp.w4b",
        "com.google.android.dialer",
        "com.android.dialer",
        "com.samsung.android.dialer",
        "com.google.android.contacts",
        "com.android.contacts",
        "com.google.android.apps.messaging",
        "com.android.mms",
        "com.google.android.youtube",
        "com.spotify.music",
        "com.google.android.deskclock",
        "com.android.deskclock",
        "com.google.android.calendar",
        "com.google.android.apps.maps",
        "com.android.camera",
        "com.google.android.googlecamera",
        "com.google.android.calculator",
        "com.android.calculator2"
    )

    /**
     * Runtime user-editable custom blocked packages added from the in-app
     * Banking Shield Self-Test screen.
     */
    val CUSTOM_BLOCKED_PACKAGES: MutableSet<String> = CopyOnWriteArraySet()

    fun addCustomBlockedPackage(packageName: String): Boolean {
        val clean = packageName.trim().lowercase()
        if (clean.isEmpty()) return false
        return CUSTOM_BLOCKED_PACKAGES.add(clean)
    }

    fun removeCustomBlockedPackage(packageName: String): Boolean {
        val clean = packageName.trim().lowercase()
        return CUSTOM_BLOCKED_PACKAGES.remove(clean)
    }

    /**
     * Exact Android package names for known banking, UPI, wallet, brokerage, and password manager apps.
     */
    val BLOCKED_FINANCIAL_PACKAGES: Set<String> = setOf(
        // UPI & Payment Apps (India)
        "com.google.android.apps.nbu.paisa.user", // Google Pay (Tez)
        "com.phonepe.app",                        // PhonePe
        "net.one97.paytm",                        // Paytm
        "in.org.npci.upiapp",                     // BHIM UPI
        "in.amazon.mShop.android.shopping",       // Amazon (Amazon Pay)
        "com.dreamplug.androidapp",               // CRED
        "com.cred.android",                       // CRED Android
        "com.mobikwik_new",                       // MobiKwik
        "com.freecharge.android",                 // Freecharge
        "com.bharatpe.app",                       // BharatPe
        "com.slice",                              // slice
        "com.uni.app",                            // Uni Cards
        "money.jupiter",                          // Jupiter Money
        "com.epifi.paisa",                        // Fi Money
        "com.fampay.in",                          // FamPay
        "com.naviapp",                            // Navi UPI & Loans
        "com.myairtelapp",                        // Airtel Thanks (Airtel Payments Bank)
        "com.jio.myjio",                          // MyJio (JioPay / JioFinance)
        "com.jio.bapp",                           // JioFinance

        // Major Indian Banks (Public & Private)
        "com.sbi.lotusintouch",                   // YONO SBI
        "com.sbi.SBIFreedomPlus",                 // YONO Lite SBI
        "com.sbi.upi",                            // BHIM SBI Pay
        "com.snapwork.hdfc",                      // HDFC Bank MobileBanking
        "com.hdfcbank.payzapp",                   // HDFC PayZapp
        "com.csam.icici.bank.imobile",            // iMobile Pay by ICICI Bank
        "com.axis.mobile",                        // Axis Mobile
        "com.msf.kbank.mobile",                   // Kotak — 811 & Mobile Banking
        "com.infrasoft.uboi",                     // Vyom (Union Bank of India)
        "com.baroda.mpassbook",                   // Bank of Baroda
        "com.bankofbaroda.mconnect",              // bob World (Bank of Baroda)
        "com.Version1",                           // PNB ONE (Punjab National Bank)
        "com.canarabank.mobility",                // Canara ai1
        "com.idfcfirstbank.optimus",              // IDFC FIRST Bank
        "com.indusind.indie",                     // INDIE by IndusInd
        "com.fss.indus",                          // IndusMobile
        "com.yesbank",                            // IRIS by YES BANK
        "com.rblbank.mobank",                     // RBL MoBank
        "com.fedmobile",                          // FedMobile (Federal Bank)
        "com.Bandhan.Bandhan",                    // mBandhan
        "com.boi.ua.android",                     // BOI Mobile (Bank of India)
        "com.cbi.bank",                           // Cent Mobile (Central Bank of India)
        "com.indianbank.indpay",                  // IndOASIS (Indian Bank)
        "com.iob.iobmobile",                      // IOB Mobile
        "com.uco.mbs",                            // UCO mBanking Plus
        "com.idbibank.goMobilePlus",              // IDBI Bank GO Mobile+
        "com.dbs.in.digitalbank",                 // digibank by DBS
        "com.scb.breeze.android.in",              // Standard Chartered India
        "com.hsbc.hsbcindia",                     // HSBC India
        "com.citibank.mobile.in",                 // Citi Mobile India
        "com.au.small.finance.bank",              // AU 0101

        // Payments Banks & Post Office
        "com.ippb.app",                           // IPPB Mobile Banking (India Post)
        "com.airtel.paymentsbank",                // Airtel Payments Bank
        "com.paytmpaymentsbank",                  // Paytm Payments Bank
        "com.finopaymentbank.mobile",             // FinoPay

        // Trading, Mutual Funds & Crypto
        "com.zerodha.kite3",                      // Zerodha Kite
        "com.zerodha.coin",                       // Zerodha Coin
        "com.nextbillion.groww",                  // Groww
        "in.upstox.app",                          // Upstox
        "com.msf.angelmobile",                    // Angel One
        "com.icicidirect.markets",                // ICICIdirect
        "com.hdfcsec.investright",                // HDFC Sky / Securities
        "com.kotak.neo",                          // Kotak Neo
        "com.dhan.live",                          // Dhan
        "com.indmoney",                           // INDmoney
        "com.kuvera.android",                     // Kuvera
        "com.etmoney.webapp",                     // ET Money
        "com.coinswitch.kuber",                   // CoinSwitch
        "com.coindcx.btc",                        // CoinDCX
        "com.binance.dev",                        // Binance
        "com.coinbase.android",                   // Coinbase

        // International Payment & Banking Apps
        "com.paypal.android.p2pmobile",           // PayPal
        "com.venmo",                              // Venmo
        "com.squareup.cash",                      // Cash App
        "com.revolut.revolut",                    // Revolut
        "com.transferwise.android",               // Wise
        "com.stripe.android.dashboard",           // Stripe
        "com.google.android.apps.walletnfcrel",   // Google Wallet
        "com.samsung.android.spay",               // Samsung Wallet / Pay
        "com.chase.sig.android",                  // Chase Mobile
        "com.infonow.bofa",                       // Bank of America
        "com.wf.wellsfargomobile",                // Wells Fargo
        "com.citi.citimobile",                    // Citi Mobile

        // Password Managers & 2FA Authenticators
        "com.x8bit.bitwarden",                    // Bitwarden
        "com.agilebits.onepassword",              // 1Password
        "com.lastpass.lpandroid",                 // LastPass
        "com.dashlane",                           // Dashlane
        "com.proton.android.pass",                // Proton Pass
        "com.google.android.apps.authenticator2", // Google Authenticator
        "com.azure.authenticator",                // Microsoft Authenticator
        "com.authy.authy"                         // Authy
    )

    private val EXACT_BLOCKED_LOWERCASE: Set<String> =
        BLOCKED_FINANCIAL_PACKAGES.map { it.lowercase() }.toSet()

    /**
     * Fail-closed package check:
     * Returns true (BLOCKED) for any null/blank package, any exact known banking/UPI package,
     * any custom-blocked package, and ANY package NOT in [ALLOWED_AUTOMATION_PACKAGES].
     */
    fun isBlockedFinancialPackage(packageName: String?): Boolean {
        if (packageName.isNullOrBlank()) return true
        val normalized = packageName.trim().lowercase()
        if (EXACT_BLOCKED_LOWERCASE.contains(normalized)) return true
        if (CUSTOM_BLOCKED_PACKAGES.contains(normalized)) return true
        // Fail-closed: block everything outside explicit allowlist
        return !ALLOWED_AUTOMATION_PACKAGES.contains(normalized)
    }

    fun isPackageBlocked(packageName: String?): Boolean = isBlockedFinancialPackage(packageName)

    fun isSafeToAutomate(packageName: String?): Boolean = !isBlockedFinancialPackage(packageName)

    /**
     * Exact-package self-test lookup (without broad regex false positives).
     */
    fun looksLikeFinancialApp(packageName: String?, appLabel: String?): Boolean {
        val pkg = packageName?.trim()?.lowercase() ?: ""
        if (EXACT_BLOCKED_LOWERCASE.contains(pkg)) return true
        val label = appLabel?.trim()?.lowercase() ?: ""
        return label.contains("bank") ||
               label.contains("paytm") ||
               label.contains("phonepe") ||
               label.contains("gpay") ||
               label.contains("bhim") ||
               label.contains("wallet")
    }

    fun isOtpOrSmsContent(text: String?): Boolean {
        if (text.isNullOrBlank()) return false
        val lower = text.lowercase()
        return lower.contains("otp") ||
               lower.contains("one time password") ||
               lower.contains("verification code") ||
               lower.contains("cvv") ||
               lower.contains("upi pin")
    }

    fun isSensitiveField(node: AccessibilityNodeInfo?): Boolean {
        if (node == null) return false
        if (node.isPassword) return true
        val hint = node.hintText?.toString()?.lowercase() ?: ""
        val desc = node.contentDescription?.toString()?.lowercase() ?: ""
        val combined = "$hint $desc"
        return combined.contains("password") ||
               combined.contains("pin") ||
               combined.contains("otp") ||
               combined.contains("cvv")
    }

    fun redactSensitiveContent(text: String?): String {
        if (text.isNullOrBlank()) return ""
        if (isOtpOrSmsContent(text)) return "[REDACTED_SENSITIVE_CONTENT]"
        return text.replace(Regex("\\b\\d{4}[\\s-]?\\d{4}[\\s-]?\\d{4}(?:[\\s-]?\\d{4})?\\b"), "[REDACTED_CARD_OR_AADHAAR]")
    }

    fun notifySafetyBlocked(context: Context) {
        Handler(Looper.getMainLooper()).post {
            runCatching {
                Toast.makeText(context.applicationContext, SAFETY_BLOCKED_MESSAGE, Toast.LENGTH_SHORT).show()
            }
        }
    }
}
