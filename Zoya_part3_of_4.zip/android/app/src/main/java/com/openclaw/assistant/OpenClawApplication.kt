package com.openclaw.assistant

import android.app.Application
import android.util.Log

class OpenClawApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        Log.i("ZoyaApplication", "Zoya AI Assistant Application initialized")
    }
}
