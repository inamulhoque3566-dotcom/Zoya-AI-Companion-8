# Zoya AI Native Android Build & CI Guide

See [`/README_BUILD_APK.md`](../README_BUILD_APK.md) for the **Phone-Friendly 4-Step Guide** to building and downloading `zoya-ai-debug.apk` directly on your phone using GitHub Actions.

## Architecture Included in `/android`
- `android/settings.gradle.kts` & `android/build.gradle.kts`: Root Gradle configuration (AGP 8.7.2, Kotlin 2.0.21).
- `android/app/build.gradle.kts`: App module configuration with `standard` flavor (`assembleStandardDebug`), `androidx.security:security-crypto`, Compose, and WebKit.
- `android/app/src/main/java/com/openclaw/assistant/MainActivity.kt`: Hosts the fullscreen hardware-accelerated WebView (`file:///android_asset/www/index.html`) and attaches `@JavascriptInterface` `AndroidBridge`.
- `android/app/src/main/java/com/openclaw/assistant/bridge/AndroidBridge.kt`:
  - Hardware-backed `EncryptedSharedPreferences` (`AES256_GCM`) secret vault + `runKeystoreSelfTest()`.
  - Native HTTP Release-Asset APK Downloader (`downloadReleaseAssetApk`) into `Downloads` + `FileProvider` package installer (`installDownloadedApk`).
  - Installed apps enumerator (`getInstalledAppsJson`) + custom blocklist manager for the **Banking Shield Self-Test**.
  - Accessibility action dispatcher (`executeActionJson`, `lockDeviceJson`, `requestDeviceUnlockJson`).
- `android/app/src/main/java/com/openclaw/assistant/bridge/accessibility/AgentVoiceAccessibilityService.kt` & `BankingSafetyConfig.kt`: Real Android `AccessibilityService` with strict Banking/UPI package, keyword, and screen-text interception.
- `android/app/src/main/java/com/openclaw/assistant/service/ZoyaHologramOverlayService.kt`: 22-style floating 3D holographic companion overlay service.
