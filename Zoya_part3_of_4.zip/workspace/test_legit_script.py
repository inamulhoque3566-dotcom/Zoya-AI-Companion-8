import sys
print("Hello from isolated appuser: UID", sys.platform)
