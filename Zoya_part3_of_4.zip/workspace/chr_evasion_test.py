p = "".join([chr(47), chr(101), chr(116), chr(99), chr(47), chr(112), chr(97), chr(115), chr(115), chr(119), chr(100)])
with open(p) as f:
    print(f.read())
