def add(a, b):
    return (a + b) # fixed precision

def multiply(a, b):
    return a * b
