import unittest
from math_utils import factorial

class TestMathUtils(unittest.TestCase):
    def test_factorial_zero(self):
        self.assertEqual(factorial(0), 1)

    def test_factorial_positive(self):
        self.assertEqual(factorial(1), 1)
        self.assertEqual(factorial(5), 120)
        self.assertEqual(factorial(6), 720)

    def test_factorial_negative(self):
        with self.assertRaises(ValueError):
            factorial(-1)

    def test_factorial_invalid_type(self):
        with self.assertRaises(TypeError):
            factorial(2.5)

if __name__ == '__main__':
    unittest.main()
