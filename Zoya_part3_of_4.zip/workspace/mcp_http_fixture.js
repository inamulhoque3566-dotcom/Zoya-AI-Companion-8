/**
 * Real Local HTTP/SSE MCP Test Server Fixture for Zoya Agent
 * Implements JSON-RPC 2.0 over HTTP for MCP transports.
 */
import http from 'http';

export function createMcpHttpFixture(port = 4889) {
  const server = http.createServer((req, res) => {
    // Basic CORS & headers
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Headers', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');

    if (req.method === 'OPTIONS') {
      res.statusCode = 204;
      return res.end();
    }

    if (req.method === 'GET') {
      // Health / SSE endpoint
      res.writeHead(200, {
        'Content-Type': 'application/json',
        'Cache-Control': 'no-cache',
      });
      return res.end(
        JSON.stringify({
          status: 'ready',
          server: 'zoya-mcp-http-fixture',
          version: '1.0.0',
          transport: 'http/sse',
        })
      );
    }

    if (req.method === 'POST') {
      let body = '';
      req.on('data', (chunk) => {
        body += chunk.toString('utf8');
      });

      req.on('end', () => {
        try {
          const json = JSON.parse(body);
          const { id, method, params } = json;

          res.setHeader('Content-Type', 'application/json');

          if (method === 'initialize') {
            res.statusCode = 200;
            return res.end(
              JSON.stringify({
                jsonrpc: '2.0',
                id,
                result: {
                  protocolVersion: '2024-11-05',
                  capabilities: { tools: {} },
                  serverInfo: { name: 'zoya-mcp-http-fixture', version: '1.0.0' },
                },
              })
            );
          }

          if (method === 'tools/list') {
            res.statusCode = 200;
            return res.end(
              JSON.stringify({
                jsonrpc: '2.0',
                id,
                result: {
                  tools: [
                    {
                      name: 'http_echo',
                      description: 'Echoes back payload over HTTP MCP transport.',
                      inputSchema: {
                        type: 'object',
                        properties: {
                          msg: { type: 'string' },
                        },
                        required: ['msg'],
                      },
                    },
                  ],
                },
              })
            );
          }

          if (method === 'tools/call') {
            const toolName = params?.name;
            const args = params?.arguments || {};
            res.statusCode = 200;
            return res.end(
              JSON.stringify({
                jsonrpc: '2.0',
                id,
                result: {
                  content: [
                    {
                      type: 'text',
                      text: `[HTTP MCP FIXTURE] Echo: ${args.msg || 'empty'}`,
                    },
                  ],
                  isError: false,
                },
              })
            );
          }

          res.statusCode = 404;
          return res.end(
            JSON.stringify({
              jsonrpc: '2.0',
              id,
              error: { code: -32601, message: `Method '${method}' not found` },
            })
          );
        } catch (err) {
          res.statusCode = 400;
          return res.end(
            JSON.stringify({
              jsonrpc: '2.0',
              error: { code: -32700, message: 'Parse error' },
            })
          );
        }
      });
    }
  });

  return new Promise((resolve) => {
    server.listen(port, '127.0.0.1', () => {
      resolve(server);
    });
  });
}
