---
name: missing-deps-skill
description: Skill with declared dependencies.
version: 1.0.0
binaries: [git, nonexistent_binary_tool_xyz_99]
---
