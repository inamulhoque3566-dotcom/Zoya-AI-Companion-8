// File 2
export function greet(name: string) { return "Hello " + name; }
