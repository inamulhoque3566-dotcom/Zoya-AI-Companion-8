import JSZip from 'jszip';
import type { ExtractedFile, ZipProcessProgress, ZipProcessResult, ZipTreeNode } from '../types/zip';

// Helper to determine mime type and file nature
export function getFileMimeType(fileName: string): { mimeType: string; isText: boolean; isImage: boolean; extension: string } {
  const ext = fileName.includes('.') ? fileName.split('.').pop()?.toLowerCase() || '' : '';
  
  const textExtensions = new Set([
    'ts', 'tsx', 'js', 'jsx', 'mjs', 'cjs', 'json', 'html', 'htm', 'css', 'scss', 'sass', 'less',
    'md', 'markdown', 'txt', 'csv', 'tsv', 'xml', 'svg', 'yaml', 'yml', 'env', 'example',
    'gitignore', 'npmignore', 'editorconfig', 'dockerfile', 'sh', 'bash', 'zsh', 'bat', 'cmd',
    'ps1', 'sql', 'prisma', 'graphql', 'gql', 'toml', 'ini', 'cfg', 'conf', 'rules', 'lock'
  ]);

  const imageExtensions: Record<string, string> = {
    png: 'image/png',
    jpg: 'image/jpeg',
    jpeg: 'image/jpeg',
    webp: 'image/webp',
    gif: 'image/gif',
    svg: 'image/svg+xml',
    ico: 'image/x-icon',
    bmp: 'image/bmp',
    avif: 'image/avif',
  };

  if (imageExtensions[ext]) {
    return {
      mimeType: imageExtensions[ext],
      isText: ext === 'svg', // SVG is both text and image
      isImage: true,
      extension: ext,
    };
  }

  if (textExtensions.has(ext) || ext === '') {
    const mimeMap: Record<string, string> = {
      ts: 'text/typescript',
      tsx: 'text/typescript-jsx',
      js: 'text/javascript',
      jsx: 'text/javascript-jsx',
      json: 'application/json',
      html: 'text/html',
      css: 'text/css',
      md: 'text/markdown',
      txt: 'text/plain',
      csv: 'text/csv',
      xml: 'application/xml',
      yaml: 'text/yaml',
      yml: 'text/yaml',
      sh: 'text/x-shellscript',
      sql: 'application/sql',
      rules: 'text/plain',
    };
    return {
      mimeType: mimeMap[ext] || 'text/plain',
      isText: true,
      isImage: false,
      extension: ext,
    };
  }

  // Audio / Video / PDF
  const otherMap: Record<string, string> = {
    pdf: 'application/pdf',
    mp3: 'audio/mpeg',
    wav: 'audio/wav',
    ogg: 'audio/ogg',
    mp4: 'video/mp4',
    webm: 'video/webm',
    zip: 'application/zip',
    tar: 'application/x-tar',
    gz: 'application/gzip',
  };

  return {
    mimeType: otherMap[ext] || 'application/octet-stream',
    isText: false,
    isImage: false,
    extension: ext,
  };
}

/**
 * 100% Complete ZIP Extraction and Processing Function
 * Guaranteed zero files missed: reads all files and subdirectories completely.
 */
export async function readAndProcessEntireZip(
  source: File | Blob | ArrayBuffer,
  fileName: string = 'archive.zip',
  onProgress?: (progress: ZipProcessProgress) => void
): Promise<ZipProcessResult> {
  const startTime = performance.now();

  onProgress?.({
    phase: 'reading',
    currentFile: fileName,
    loadedFiles: 0,
    totalFiles: 0,
    percentage: 5,
    bytesProcessed: 0,
  });

  const zip = new JSZip();
  const loadedZip = await zip.loadAsync(source);

  const fileEntries: { path: string; entry: JSZip.JSZipObject }[] = [];
  loadedZip.forEach((relativePath, entry) => {
    fileEntries.push({ path: relativePath, entry });
  });

  const totalEntries = fileEntries.length;
  let processedCount = 0;
  let totalUncompressedSize = 0;
  let folderCount = 0;
  let fileCount = 0;

  const extractedFiles: ExtractedFile[] = [];
  const extensionStats: Record<string, { count: number; totalSize: number }> = {};

  onProgress?.({
    phase: 'extracting',
    currentFile: fileName,
    loadedFiles: 0,
    totalFiles: totalEntries,
    percentage: 15,
    bytesProcessed: 0,
  });

  for (const { path, entry } of fileEntries) {
    const isDir = entry.dir;
    const cleanPath = path.replace(/\\/g, '/');
    const pathParts = cleanPath.split('/').filter(Boolean);
    const name = pathParts.length > 0 ? pathParts[pathParts.length - 1] : cleanPath;
    const directory = pathParts.length > 1 ? pathParts.slice(0, -1).join('/') : '';

    if (isDir) {
      folderCount++;
      const dirFile: ExtractedFile = {
        id: `dir-${cleanPath}`,
        name,
        path: cleanPath.endsWith('/') ? cleanPath : `${cleanPath}/`,
        directory,
        isDirectory: true,
        size: 0,
        compressedSize: 0,
        date: entry.date,
        extension: '',
        mimeType: 'inode/directory',
        isText: false,
        isImage: false,
      };
      extractedFiles.push(dirFile);
    } else {
      fileCount++;
      const { mimeType, isText, isImage, extension } = getFileMimeType(name);

      let textContent: string | undefined;
      let dataUrl: string | undefined;
      let rawUint8Array: Uint8Array | undefined;
      let error: string | undefined;

      try {
        if (isText) {
          textContent = await entry.async('string');
        }

        if (isImage) {
          const base64 = await entry.async('base64');
          dataUrl = `data:${mimeType};base64,${base64}`;
        }

        // Get raw array buffer for size / binary view / hash
        const buffer = await entry.async('uint8array');
        rawUint8Array = buffer;
      } catch (err: unknown) {
        error = err instanceof Error ? err.message : 'Error extracting file';
        console.error(`Failed to fully extract file ${cleanPath}:`, err);
      }

      // Compute actual size
      const uncompressedSize = rawUint8Array ? rawUint8Array.byteLength : (textContent ? new TextEncoder().encode(textContent).length : 0);
      // JSZip internal metadata or fallback
      const compressedSize = (entry as unknown as { _data?: { compressedSize?: number } })._data?.compressedSize || uncompressedSize;

      totalUncompressedSize += uncompressedSize;

      // Update extension statistics
      const extKey = extension ? `.${extension}` : 'no-extension';
      if (!extensionStats[extKey]) {
        extensionStats[extKey] = { count: 0, totalSize: 0 };
      }
      extensionStats[extKey].count += 1;
      extensionStats[extKey].totalSize += uncompressedSize;

      const fileItem: ExtractedFile = {
        id: `file-${cleanPath}`,
        name,
        path: cleanPath,
        directory,
        isDirectory: false,
        size: uncompressedSize,
        compressedSize,
        date: entry.date,
        extension,
        mimeType,
        isText,
        isImage,
        textContent,
        dataUrl,
        rawUint8Array,
        error,
      };

      extractedFiles.push(fileItem);
    }

    processedCount++;
    const percentage = Math.min(95, 15 + Math.floor((processedCount / totalEntries) * 80));

    if (processedCount % 5 === 0 || processedCount === totalEntries) {
      onProgress?.({
        phase: 'extracting',
        currentFile: cleanPath,
        loadedFiles: processedCount,
        totalFiles: totalEntries,
        percentage,
        bytesProcessed: totalUncompressedSize,
      });
    }
  }

  // Build the hierarchical directory tree
  onProgress?.({
    phase: 'processing',
    currentFile: 'Building file hierarchy tree...',
    loadedFiles: totalEntries,
    totalFiles: totalEntries,
    percentage: 96,
    bytesProcessed: totalUncompressedSize,
  });

  const tree = buildZipTree(extractedFiles);

  const endTime = performance.now();
  const processingTimeMs = Math.round(endTime - startTime);

  const allProcessedWithoutErrors = extractedFiles.every((f) => !f.error);

  const result: ZipProcessResult = {
    fileName,
    totalZipSize: (source as Blob).size || (source as ArrayBuffer).byteLength || totalUncompressedSize,
    uncompressedTotalSize: totalUncompressedSize,
    fileCount,
    folderCount,
    files: extractedFiles,
    tree,
    extensionStats,
    allProcessedWithoutErrors,
    processingTimeMs,
  };

  onProgress?.({
    phase: 'completed',
    currentFile: 'Complete',
    loadedFiles: totalEntries,
    totalFiles: totalEntries,
    percentage: 100,
    bytesProcessed: totalUncompressedSize,
  });

  return result;
}

/**
 * Builds a clean nested tree from flat list of extracted files
 */
export function buildZipTree(files: ExtractedFile[]): ZipTreeNode {
  const root: ZipTreeNode = {
    name: 'root',
    path: '',
    isDirectory: true,
    children: {},
    size: 0,
    itemCount: 0,
  };

  for (const file of files) {
    const parts = file.path.split('/').filter(Boolean);
    let current = root;

    for (let i = 0; i < parts.length; i++) {
      const part = parts[i];
      const isLast = i === parts.length - 1;
      const subPath = parts.slice(0, i + 1).join('/') + (isLast && file.isDirectory ? '/' : '');

      if (!current.children[part]) {
        current.children[part] = {
          name: part,
          path: subPath,
          isDirectory: !isLast || file.isDirectory,
          children: {},
          size: 0,
          itemCount: 0,
          file: isLast ? file : undefined,
        };
      }

      current.size += file.size;
      current.itemCount += 1;
      current = current.children[part];
    }
  }

  return root;
}

/**
 * Re-packs extracted files into a new ZIP and triggers download
 */
export async function exportFilesToZip(
  files: ExtractedFile[],
  outputName: string = 'processed_archive.zip',
  onProgress?: (percent: number) => void
): Promise<Blob> {
  const zip = new JSZip();

  for (const file of files) {
    if (file.isDirectory) {
      zip.folder(file.path.replace(/\/$/, ''));
    } else {
      if (file.textContent !== undefined) {
        zip.file(file.path, file.textContent);
      } else if (file.rawUint8Array) {
        zip.file(file.path, file.rawUint8Array);
      }
    }
  }

  const content = await zip.generateAsync(
    {
      type: 'blob',
      compression: 'DEFLATE',
      compressionOptions: { level: 6 },
    },
    (metadata) => {
      onProgress?.(Math.round(metadata.percent));
    }
  );

  return content;
}

/**
 * Global search across all text files
 */
export function searchInFiles(
  files: ExtractedFile[],
  query: string,
  isRegex: boolean = false,
  caseSensitive: boolean = false
): { file: ExtractedFile; lineNumber: number; lineContent: string; matchIndex: number }[] {
  if (!query.trim()) return [];

  const results: { file: ExtractedFile; lineNumber: number; lineContent: string; matchIndex: number }[] = [];

  let matcher: RegExp;
  try {
    const flags = caseSensitive ? 'g' : 'gi';
    matcher = isRegex ? new RegExp(query, flags) : new RegExp(query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), flags);
  } catch {
    return [];
  }

  for (const file of files) {
    if (file.isDirectory || !file.textContent) continue;

    const lines = file.textContent.split('\n');
    for (let lineIdx = 0; lineIdx < lines.length; lineIdx++) {
      const line = lines[lineIdx];
      matcher.lastIndex = 0;
      const match = matcher.exec(line);
      if (match) {
        results.push({
          file,
          lineNumber: lineIdx + 1,
          lineContent: line.trim(),
          matchIndex: match.index,
        });
      }
    }
  }

  return results;
}
