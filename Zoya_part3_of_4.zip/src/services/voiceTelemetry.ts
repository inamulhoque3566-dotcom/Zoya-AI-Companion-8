export type VoicePipelineStageId =
  | 'mic'
  | 'recording'
  | 'stt'
  | 'wakeWord'
  | 'userMessage'
  | 'geminiApi'
  | 'aiResponse'
  | 'tts'
  | 'speaker';

export type StageHealth = 'ok' | 'idle' | 'fail';

export interface VoiceStageTelemetry {
  id: VoicePipelineStageId;
  label: string;
  activeLabel: string;
  inactiveLabel: string;
  isOk: boolean;
  health: StageHealth;
  stateText: string;
  detail: string;
  error?: string;
  updatedAt: number;
}

export type VoiceTelemetrySnapshot = Record<VoicePipelineStageId, VoiceStageTelemetry>;
type TelemetryListener = (snapshot: VoiceTelemetrySnapshot) => void;

const now = () => Date.now();

const INITIAL_STATE: VoiceTelemetrySnapshot = {
  mic: {
    id: 'mic',
    label: '1. Microphone',
    activeLabel: 'ACTIVE',
    inactiveLabel: 'INACTIVE',
    isOk: false,
    health: 'idle',
    stateText: 'INACTIVE',
    detail: 'Not yet initialized',
    updatedAt: now(),
  },
  recording: {
    id: 'recording',
    label: '2. Audio Recording',
    activeLabel: 'RECORDING',
    inactiveLabel: 'NOT RECORDING',
    isOk: false,
    health: 'idle',
    stateText: 'NOT RECORDING',
    detail: 'No active capture stream',
    updatedAt: now(),
  },
  stt: {
    id: 'stt',
    label: '3. Speech Recognition',
    activeLabel: 'WORKING',
    inactiveLabel: 'FAILED',
    isOk: false,
    health: 'idle',
    stateText: 'IDLE',
    detail: 'Awaiting speech input',
    updatedAt: now(),
  },
  wakeWord: {
    id: 'wakeWord',
    label: '4. Wake Word',
    activeLabel: 'DETECTED',
    inactiveLabel: 'NOT DETECTED',
    isOk: false,
    health: 'idle',
    stateText: 'NOT DETECTED',
    detail: 'Waiting for "Hello Zoya" / "Hello Hello"',
    updatedAt: now(),
  },
  userMessage: {
    id: 'userMessage',
    label: '5. User Message',
    activeLabel: 'SUBMITTED',
    inactiveLabel: 'NOT SUBMITTED',
    isOk: false,
    health: 'idle',
    stateText: 'NOT SUBMITTED',
    detail: 'No voice message submitted yet',
    updatedAt: now(),
  },
  geminiApi: {
    id: 'geminiApi',
    label: '6. Gemini API',
    activeLabel: 'CONNECTED',
    inactiveLabel: 'ERROR',
    isOk: false,
    health: 'idle',
    stateText: 'IDLE',
    detail: 'Not probed yet',
    updatedAt: now(),
  },
  aiResponse: {
    id: 'aiResponse',
    label: '7. AI Response',
    activeLabel: 'RECEIVED',
    inactiveLabel: 'NOT RECEIVED',
    isOk: false,
    health: 'idle',
    stateText: 'NOT RECEIVED',
    detail: 'No AI response received yet',
    updatedAt: now(),
  },
  tts: {
    id: 'tts',
    label: '8. TTS Generation',
    activeLabel: 'WORKING',
    inactiveLabel: 'FAILED',
    isOk: false,
    health: 'idle',
    stateText: 'IDLE',
    detail: 'No TTS request made yet',
    updatedAt: now(),
  },
  speaker: {
    id: 'speaker',
    label: '9. Speaker Playback',
    activeLabel: 'PLAYING',
    inactiveLabel: 'NOT PLAYING',
    isOk: false,
    health: 'idle',
    stateText: 'NOT PLAYING',
    detail: 'No audio played yet',
    updatedAt: now(),
  },
};

class VoiceTelemetryStore {
  private snapshot: VoiceTelemetrySnapshot = { ...INITIAL_STATE };
  private listeners = new Set<TelemetryListener>();

  public getSnapshot(): VoiceTelemetrySnapshot {
    return { ...this.snapshot };
  }

  public update(
    id: VoicePipelineStageId,
    patch: {
      isOk: boolean;
      health?: StageHealth;
      stateText?: string;
      detail: string;
      error?: string;
    }
  ): void {
    const prev = this.snapshot[id];
    const health: StageHealth = patch.health ?? (patch.isOk ? 'ok' : patch.error ? 'fail' : 'idle');
    const stateText =
      patch.stateText ?? (patch.isOk ? prev.activeLabel : prev.inactiveLabel);

    this.snapshot = {
      ...this.snapshot,
      [id]: {
        ...prev,
        isOk: patch.isOk,
        health,
        stateText,
        detail: patch.detail,
        error: patch.error,
        updatedAt: Date.now(),
      },
    };
    this.emit();
  }

  public subscribe(fn: TelemetryListener): () => void {
    this.listeners.add(fn);
    fn(this.getSnapshot());
    return () => {
      this.listeners.delete(fn);
    };
  }

  private emit(): void {
    const snap = this.getSnapshot();
    this.listeners.forEach((fn) => {
      try {
        fn(snap);
      } catch {}
    });
  }
}

export const voiceTelemetry = new VoiceTelemetryStore();
