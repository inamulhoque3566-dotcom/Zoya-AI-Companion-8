/**
 * Android Device Lock & Unlock Security Service
 * Integrates Web <-> Android Native Security APIs:
 * - KeyguardManager (Screen lock status, PIN/Password detection, requestDismissKeyguard)
 * - BiometricManager & BiometricPrompt (Fingerprint & Face authentication checks)
 * - AccessibilityService (GLOBAL_ACTION_LOCK_SCREEN for voice & programmatic screen locking)
 * - Android Settings Intents (Official enrollment for PIN, Password, Face, Fingerprint)
 * 
 * STRICT SECURITY CONSTRAINTS:
 * - Never collects, stores, or processes PINs or passwords.
 * - Never bypasses Android lock screen security.
 * - Never claims remote or silent credential bypass.
 * - Relies exclusively on official Android OS security challenges.
 */

export interface DeviceSecurityStatus {
  isDeviceSecure: boolean;
  isKeyguardSecure: boolean;
  isKeyguardLocked: boolean;
  hasPinOrPassword: boolean;
  hasFingerprintHardware: boolean;
  hasFaceHardware: boolean;
  fingerprintStatus: 'enrolled' | 'available' | 'no_hardware' | 'hw_unavailable' | 'unknown';
  faceStatus: 'enrolled' | 'available' | 'no_hardware' | 'hw_unavailable' | 'unknown';
  biometricStatus: string;
  isAccessibilityRunning: boolean;
  canLockScreen: boolean;
  sdkInt: number;
  isNativeApk: boolean;
  screenState: 'unlocked' | 'locked';
}

export interface SecurityOperationResult {
  success: boolean;
  message: string;
  error?: string;
  code?: string;
  data?: any;
}

function getStorage(key: string, defaultValue: string = ''): string {
  try {
    if (typeof localStorage !== 'undefined') {
      return localStorage.getItem(key) ?? defaultValue;
    }
  } catch {}
  return defaultValue;
}

function setStorage(key: string, value: string): void {
  try {
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem(key, value);
    }
  } catch {}
}

class DeviceSecurityService {
  private simulatedState: DeviceSecurityStatus = {
    isDeviceSecure: true,
    isKeyguardSecure: true,
    isKeyguardLocked: false,
    hasPinOrPassword: true,
    hasFingerprintHardware: true,
    hasFaceHardware: false, // Default false unless platform reports
    fingerprintStatus: 'enrolled',
    faceStatus: 'no_hardware',
    biometricStatus: 'available',
    isAccessibilityRunning: true,
    canLockScreen: true,
    sdkInt: 34,
    isNativeApk: false,
    screenState: 'unlocked'
  };

  constructor() {
    this.initBrowserHardwareDetection();
  }

  private async initBrowserHardwareDetection() {
    if (typeof window === 'undefined') return;

    // Check if platform authenticator (fingerprint / Windows Hello / Touch ID) is available in browser
    if (window.PublicKeyCredential && typeof window.PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable === 'function') {
      try {
        const hasPlatformAuth = await window.PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable();
        this.simulatedState.hasFingerprintHardware = hasPlatformAuth;
        this.simulatedState.fingerprintStatus = hasPlatformAuth ? 'enrolled' : 'no_hardware';
      } catch {
        // Fallback default
      }
    }

    const savedLocked = getStorage('zoya_simulated_screen_locked');
    if (savedLocked === 'true') {
      this.simulatedState.screenState = 'locked';
      this.simulatedState.isKeyguardLocked = true;
    }
  }

  public isNativeEnvironment(): boolean {
    return typeof window !== 'undefined' &&
      typeof window.AndroidBridge !== 'undefined' &&
      typeof window.AndroidBridge.getDeviceSecurityStatus === 'function';
  }

  /**
   * Retrieves live Android device security status
   */
  public async getSecurityStatus(): Promise<DeviceSecurityStatus> {
    if (this.isNativeEnvironment() && window.AndroidBridge?.getDeviceSecurityStatus) {
      try {
        const raw = window.AndroidBridge.getDeviceSecurityStatus();
        const parsed = JSON.parse(raw);
        return {
          isDeviceSecure: !!parsed.isDeviceSecure,
          isKeyguardSecure: !!parsed.isKeyguardSecure,
          isKeyguardLocked: !!parsed.isKeyguardLocked,
          hasPinOrPassword: !!parsed.hasPinOrPassword,
          hasFingerprintHardware: !!parsed.hasFingerprintHardware,
          hasFaceHardware: !!parsed.hasFaceHardware,
          fingerprintStatus: parsed.fingerprintStatus || 'unknown',
          faceStatus: parsed.faceStatus || 'unknown',
          biometricStatus: parsed.biometricStatus || 'unknown',
          isAccessibilityRunning: !!parsed.isAccessibilityRunning,
          canLockScreen: !!parsed.canLockScreen,
          sdkInt: parsed.sdkInt || 0,
          isNativeApk: true,
          screenState: parsed.isKeyguardLocked ? 'locked' : 'unlocked'
        };
      } catch (e) {
        console.warn('[DEVICE_SECURITY] Failed to parse native security status:', e);
      }
    }

    // Web simulation state
    const isSimLocked = getStorage('zoya_simulated_screen_locked') === 'true';
    const isSimServiceRunning = getStorage('zoya_simulated_accessibility') === 'true';

    return {
      ...this.simulatedState,
      isKeyguardLocked: isSimLocked,
      screenState: isSimLocked ? 'locked' : 'unlocked',
      isAccessibilityRunning: isSimServiceRunning,
      canLockScreen: isSimServiceRunning,
      isNativeApk: false
    };
  }

  /**
   * Opens Android official setup screen for PIN, Password, Face, or Fingerprint
   */
  public async openSecurityEnrollment(type: 'pin' | 'password' | 'fingerprint' | 'face' | 'security_settings'): Promise<SecurityOperationResult> {
    if (this.isNativeEnvironment() && window.AndroidBridge?.openSecurityEnrollment) {
      try {
        const raw = window.AndroidBridge.openSecurityEnrollment(type);
        const parsed = JSON.parse(raw);
        return {
          success: parsed.success ?? false,
          message: parsed.message || `Dispatched Android enrollment for ${type}`,
          error: parsed.error
        };
      } catch (err: any) {
        return {
          success: false,
          message: `Failed to open ${type} setup screen: ${err?.message || 'Bridge error'}`,
          error: 'BRIDGE_ERROR'
        };
      }
    }

    // Web Simulator
    const labels: Record<string, string> = {
      pin: 'Android PIN Setup (DevicePolicyManager.ACTION_SET_NEW_PASSWORD)',
      password: 'Android Password Setup (DevicePolicyManager.ACTION_SET_NEW_PASSWORD)',
      fingerprint: 'Android Fingerprint Enrollment (Settings.ACTION_FINGERPRINT_ENROLL)',
      face: 'Android Face Authentication Enrollment (Settings.ACTION_BIOMETRIC_ENROLL)',
      security_settings: 'Android Security & Privacy Settings (Settings.ACTION_SECURITY_SETTINGS)'
    };

    return {
      success: true,
      message: `Launched official intent: ${labels[type] || type}. In native APK, Android opens the system enrollment screen.`,
      data: { simulatedType: type }
    };
  }

  /**
   * Locks the Android device screen via AccessibilityService GLOBAL_ACTION_LOCK_SCREEN
   */
  public async lockDevice(): Promise<SecurityOperationResult> {
    if (this.isNativeEnvironment()) {
      if (window.AndroidBridge?.lockDevice) {
        try {
          const raw = window.AndroidBridge.lockDevice();
          const parsed = JSON.parse(raw);
          return {
            success: parsed.success ?? false,
            message: parsed.message || parsed.error || (parsed.success ? 'Device locked successfully.' : 'Failed to lock device.'),
            error: parsed.error,
            code: parsed.code
          };
        } catch (e: any) {
          return {
            success: false,
            message: `Native lock failed: ${e?.message || 'Unknown error'}`,
            error: 'EXCEPTION'
          };
        }
      }

      // Fallback via executeAccessibilityAction
      if (window.AndroidBridge?.executeAccessibilityAction) {
        try {
          const raw = window.AndroidBridge.executeAccessibilityAction(JSON.stringify({ action: 'lock' }));
          const parsed = JSON.parse(raw);
          return {
            success: parsed.success ?? false,
            message: parsed.message || parsed.error || 'Dispatched lock screen action',
            error: parsed.error,
            code: parsed.code
          };
        } catch (e: any) {
          return {
            success: false,
            message: `Lock command failed: ${e?.message || 'Error'}`,
            error: 'BRIDGE_ERROR'
          };
        }
      }
    }

    // Web Simulator
    const isServiceRunning = getStorage('zoya_simulated_accessibility') === 'true';
    if (!isServiceRunning) {
      return {
        success: false,
        message: 'Cannot lock screen: Accessibility Service is currently disabled. Please enable it in Android Accessibility Settings first.',
        code: 'ACCESSIBILITY_REQUIRED'
      };
    }

    setStorage('zoya_simulated_screen_locked', 'true');
    this.simulatedState.isKeyguardLocked = true;
    this.simulatedState.screenState = 'locked';

    return {
      success: true,
      message: 'Device screen locked successfully. (GLOBAL_ACTION_LOCK_SCREEN dispatched to Android system).'
    };
  }

  /**
   * Initiates official Android unlock challenge
   * STRICT: Android OS must verify the user's PIN, password, face, or fingerprint.
   * Zoya never bypasses keyguard or stores credentials.
   */
  public async requestUnlock(): Promise<SecurityOperationResult> {
    if (this.isNativeEnvironment() && window.AndroidBridge?.requestDeviceUnlock) {
      try {
        const raw = window.AndroidBridge.requestDeviceUnlock();
        const parsed = JSON.parse(raw);
        return {
          success: parsed.success ?? false,
          message: parsed.message || (parsed.error || 'Unlock challenge initiated.'),
          data: parsed
        };
      } catch (e: any) {
        return {
          success: false,
          message: `Failed to initiate unlock challenge: ${e?.message || 'Bridge error'}`,
          error: 'BRIDGE_ERROR'
        };
      }
    }

    // Web Simulator
    const isLocked = getStorage('zoya_simulated_screen_locked') === 'true';
    if (!isLocked) {
      return {
        success: true,
        message: 'Device screen is already unlocked.'
      };
    }

    // Dismiss simulation lock state
    setStorage('zoya_simulated_screen_locked', 'false');
    this.simulatedState.isKeyguardLocked = false;
    this.simulatedState.screenState = 'unlocked';

    return {
      success: true,
      message: 'Initiated official Android unlock challenge. Keyguard dismissed upon user verification.'
    };
  }
}

export const deviceSecurity = new DeviceSecurityService();
