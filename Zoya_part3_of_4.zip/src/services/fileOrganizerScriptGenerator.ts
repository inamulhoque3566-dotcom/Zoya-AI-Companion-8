/**
 * Zoya File Organizer Script Generator
 * Generates verified, ready-to-download .sh, .py, and .bat scripts
 * with clear safety warnings and default --dry-run mode.
 */

export interface GeneratedOrganizerScripts {
  safetyWarning: string;
  bashScript: string;
  pythonScript: string;
  batScript: string;
  bashDataUri: string;
  pythonDataUri: string;
  batDataUri: string;
}

export function generateOrganizerScripts(folderTarget = '~/Downloads'): GeneratedOrganizerScripts {
  const safetyWarning =
    '⚠️ SAFETY WARNING: Review all paths and commands before executing. Always run with DRY_RUN=true first to preview actions without moving or deleting any files.';

  const bashScript = `#!/usr/bin/env bash
# ==============================================================================
# Zoya AI Safe File Organizer
# Target Folder: ${folderTarget}
# ${safetyWarning}
# ==============================================================================
set -euo pipefail

TARGET_DIR="\${1:-${folderTarget}}"
# Expand tilde if present
TARGET_DIR="\${TARGET_DIR/#\\~/$HOME}"

# Set DRY_RUN=0 to actually move files
DRY_RUN="\${DRY_RUN:-1}"

echo "========================================================"
echo "📂 Zoya Safe File Organizer"
echo "Target Directory: $TARGET_DIR"
if [ "$DRY_RUN" -eq 1 ]; then
  echo "🔍 MODE: DRY-RUN (PREVIEW ONLY — NO FILES WILL BE MOVED)"
  echo "👉 To apply changes, run: DRY_RUN=0 ./organize_files.sh"
else
  echo "⚡ MODE: LIVE EXECUTION (Moving files)"
fi
echo "========================================================"

if [ ! -d "$TARGET_DIR" ]; then
  echo "❌ Error: Target directory '$TARGET_DIR' does not exist."
  exit 1
fi

# Define destination subfolders
DOCS_DIR="$TARGET_DIR/Documents"
IMAGES_DIR="$TARGET_DIR/Images"
ARCHIVE_DIR="$TARGET_DIR/Archives"
DEV_DIR="$TARGET_DIR/Code_And_Data"

move_file() {
  local src="$1"
  local dest_dir="$2"
  local filename
  filename=$(basename "$src")

  if [ "$DRY_RUN" -eq 1 ]; then
    echo "  [DRY-RUN PREVIEW] Would move: $filename -> $dest_dir/"
  else
    mkdir -p "$dest_dir"
    mv -n "$src" "$dest_dir/"
    echo "  ✓ Moved: $filename -> $dest_dir/"
  fi
}

# Scan and categorize files
find "$TARGET_DIR" -maxdepth 1 -type f | while IFS= read -r file; do
  case "\${file,,}" in
    *.pdf|*.docx|*.doc|*.txt|*.xlsx|*.csv)
      move_file "$file" "$DOCS_DIR"
      ;;
    *.png|*.jpg|*.jpeg|*.webp|*.svg|*.gif)
      move_file "$file" "$IMAGES_DIR"
      ;;
    *.zip|*.tar.gz|*.rar|*.7z)
      move_file "$file" "$ARCHIVE_DIR"
      ;;
    *.json|*.py|*.ts|*.js|*.html|*.sql)
      move_file "$file" "$DEV_DIR"
      ;;
    *)
      # Leave uncategorized files untouched for safety
      ;;
  esac
done

echo ""
echo "✅ Organizer scan completed safely."
`;

  const pythonScript = `#!/usr/bin/env python3
"""
Zoya AI Safe File Organizer (Python 3)
${safetyWarning}
"""
import os
import sys
import shutil
from pathlib import Path

DRY_RUN = os.environ.get("DRY_RUN", "1") == "1"
if "--live" in sys.argv or "--apply" in sys.argv:
    DRY_RUN = False

target_dir = Path(os.path.expanduser("${folderTarget}"))
if len(sys.argv) > 1 and not sys.argv[1].startswith("--"):
    target_dir = Path(os.path.expanduser(sys.argv[1]))

print("=" * 60)
print("📂 Zoya Safe File Organizer (Python 3)")
print(f"Target Directory: {target_dir}")
print(f"MODE: {'🔍 DRY-RUN (Preview Only)' if DRY_RUN else '⚡ LIVE EXECUTION'}")
if DRY_RUN:
    print("👉 To actually move files, run: python3 organize_files.py --apply")
print("=" * 60)

if not target_dir.exists() or not target_dir.is_dir():
    print(f"❌ Target directory '{target_dir}' does not exist.")
    sys.exit(1)

CATEGORIES = {
    "Documents": {".pdf", ".docx", ".doc", ".txt", ".xlsx", ".csv", ".pptx"},
    "Images": {".png", ".jpg", ".jpeg", ".webp", ".svg", ".gif"},
    "Archives": {".zip", ".tar.gz", ".rar", ".7z", ".gz"},
    "Code_And_Data": {".json", ".py", ".ts", ".js", ".html", ".sql", ".sh"},
}

moved_count = 0
for item in target_dir.iterdir():
    if not item.is_file():
        continue
    suffix = item.suffix.lower()
    for category, extensions in CATEGORIES.items():
        if suffix in extensions:
            dest_folder = target_dir / category
            if DRY_RUN:
                print(f"  [DRY-RUN] Would move: {item.name} -> {category}/")
            else:
                dest_folder.mkdir(exist_ok=True)
                dest_path = dest_folder / item.name
                if not dest_path.exists():
                    shutil.move(str(item), str(dest_path))
                    print(f"  ✓ Moved: {item.name} -> {category}/")
            moved_count += 1
            break

print(f"\\n✅ Scan finished. Total categorized: {moved_count} files.")
`;

  const batScript = `@echo off
rem ==============================================================================
rem Zoya AI Safe File Organizer (Windows Batch)
rem ${safetyWarning}
rem ==============================================================================
setlocal enabledelayedexpansion

set TARGET_DIR=%USERPROFILE%\\Downloads
set DRY_RUN=1
if "%1"=="--apply" set DRY_RUN=0

echo ========================================================
echo 📂 Zoya Safe File Organizer (Windows)
echo Target Directory: %TARGET_DIR%
if "%DRY_RUN%"=="1" (
  echo 🔍 MODE: DRY-RUN (PREVIEW ONLY - NO FILES MOVED)
  echo 👉 Run with --apply to actually move files: organize_files.bat --apply
) else (
  echo ⚡ MODE: LIVE EXECUTION
)
echo ========================================================

if not exist "%TARGET_DIR%" (
  echo ❌ Error: Directory not found.
  exit /b 1
)

for %%f in ("%TARGET_DIR%\\*.pdf" "%TARGET_DIR%\\*.docx" "%TARGET_DIR%\\*.xlsx") do (
  if "%DRY_RUN%"=="1" (
    echo   [DRY-RUN] Would move %%~nxf to Documents\\
  ) else (
    if not exist "%TARGET_DIR%\\Documents" mkdir "%TARGET_DIR%\\Documents"
    move "%%f" "%TARGET_DIR%\\Documents\\"
  )
)
echo.
echo ✅ Done.
`;

  return {
    safetyWarning,
    bashScript,
    pythonScript,
    batScript,
    bashDataUri: `data:text/x-sh;base64,${Buffer.from(bashScript).toString('base64')}`,
    pythonDataUri: `data:text/x-python;base64,${Buffer.from(pythonScript).toString('base64')}`,
    batDataUri: `data:application/x-bat;base64,${Buffer.from(batScript).toString('base64')}`,
  };
}
