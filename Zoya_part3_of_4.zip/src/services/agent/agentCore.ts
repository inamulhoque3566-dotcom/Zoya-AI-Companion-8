import fs from 'fs';
import path from 'path';
import {
  createModelProvider,
  type IModelProvider,
  type ModelProviderConfig,
  type AgentMessage,
  type AgentToolCall,
} from './modelProvider.ts';
import {
  AgentToolExecutor,
  AGENT_TOOL_DECLARATIONS,
  type ToolExecutionContext,
  type ToolResult,
} from './agentTools.ts';
import { maskSecrets } from './agentPermissionGuard.ts';
import { skillsEngine } from './skillsEngine.ts';

export type AgentStepPhase = 'plan' | 'tool_call' | 'read_result' | 'fix' | 'verify' | 'report';

export interface AgentLogEntry {
  id: string;
  timestamp: string;
  phase: AgentStepPhase;
  stepNumber: number;
  description: string;
  toolName?: string;
  toolArgs?: any;
  toolResult?: ToolResult;
  modelThinking?: string;
  durationMs?: number;
  status: 'running' | 'success' | 'failure' | 'retrying';
}

export interface AgentTaskState {
  taskId: string;
  userPrompt: string;
  status: 'idle' | 'running' | 'completed' | 'failed' | 'aborted';
  plan: string[];
  currentStep: number;
  totalSteps: number;
  retryCount: number;
  maxRetries: number;
  startTime: string;
  endTime?: string;
  logs: AgentLogEntry[];
  finalReport?: string;
  error?: string;
}

export interface AgentCoreConfig {
  workspaceRoot?: string;
  maxRetries?: number;
  commandTimeoutMs?: number;
  maxOutputChars?: number;
  autoApprove?: boolean;
  onPendingApproval?: (id: string, toolName: string, args: Record<string, any>, warning?: string) => void;
  modelConfig?: ModelProviderConfig;
  onLogUpdate?: (entry: AgentLogEntry) => void;
  onStateUpdate?: (state: AgentTaskState) => void;
}

const DEFAULT_WORKSPACE = path.join(process.cwd(), 'workspace');
const LOGS_DIR = path.join(process.cwd(), 'data', 'agent_logs');

if (!fs.existsSync(LOGS_DIR)) {
  fs.mkdirSync(LOGS_DIR, { recursive: true });
}

export class AgentCore {
  private workspaceRoot: string;
  private maxRetries: number;
  private commandTimeoutMs: number;
  private maxOutputChars: number;
  private provider: IModelProvider;
  private toolExecutor: AgentToolExecutor;
  private activeTask: AgentTaskState | null = null;
  private config?: AgentCoreConfig;
  private isAborted = false;

  constructor(config?: AgentCoreConfig) {
    this.config = config;
    this.workspaceRoot = config?.workspaceRoot || DEFAULT_WORKSPACE;
    this.maxRetries = config?.maxRetries ?? 3;
    this.commandTimeoutMs = config?.commandTimeoutMs ?? 20000;
    this.maxOutputChars = config?.maxOutputChars ?? 60000;

    this.provider = createModelProvider(config?.modelConfig);

    const toolContext: ToolExecutionContext = {
      workspaceRoot: this.workspaceRoot,
      commandTimeoutMs: this.commandTimeoutMs,
      maxOutputChars: this.maxOutputChars,
      logAction: (toolName, args, result, durationMs) => {
        // Automatically recorded inside loop
      },
    };

    this.toolExecutor = new AgentToolExecutor(toolContext);
  }

  public getWorkspaceRoot(): string {
    return this.workspaceRoot;
  }

  public setWorkspaceRoot(newRoot: string) {
    this.workspaceRoot = newRoot;
    this.toolExecutor = new AgentToolExecutor({
      workspaceRoot: this.workspaceRoot,
      commandTimeoutMs: this.commandTimeoutMs,
      maxOutputChars: this.maxOutputChars,
    });
  }

  public updateModelConfig(modelConfig: ModelProviderConfig) {
    this.provider = createModelProvider(modelConfig);
  }

  public getActiveTask(): AgentTaskState | null {
    return this.activeTask;
  }

  public abortTask(): boolean {
    if (this.activeTask && this.activeTask.status === 'running') {
      this.isAborted = true;
      this.activeTask.status = 'aborted';
      this.activeTask.endTime = new Date().toISOString();
      this.appendLog('report', 'Task manually aborted by user.', 'failure');
      this.persistTaskLog();
      return true;
    }
    return false;
  }

  /**
   * Main Autonomous Execution Loop:
   * plan -> tool call -> read result -> fix -> verify -> report
   */
  public async runTask(userPrompt: string): Promise<AgentTaskState> {
    if (!userPrompt || !userPrompt.trim()) {
      throw new Error('User prompt cannot be empty.');
    }

    this.isAborted = false;
    const taskId = `task_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;

    const state: AgentTaskState = {
      taskId,
      userPrompt,
      status: 'running',
      plan: [],
      currentStep: 0,
      totalSteps: 1,
      retryCount: 0,
      maxRetries: this.maxRetries,
      startTime: new Date().toISOString(),
      logs: [],
    };

    this.activeTask = state;
    this.notifyState();

    // Auto-select relevant enabled skills for the task (disabled skills are never selected)
    const selectedSkills = skillsEngine.selectSkillsForTask(userPrompt);
    const skillsSummary = selectedSkills.length > 0
      ? `\nActive Selected Skills (${selectedSkills.length}):\n` +
        selectedSkills.map((s) => `* [SKILL] ${s.skill.name}: ${s.skill.description} (Reason: ${s.matchReason})`).join('\n')
      : '';

    // Ensure Step 1 is ALWAYS [plan]
    const initialPlanSteps = [
      `Inspect workspace and requirements for "${userPrompt.slice(0, 70)}..."`,
      'Implement necessary source and test files',
      'Execute tests/build to verify functionality',
      'Review results and generate final report',
    ];
    state.plan = initialPlanSteps;
    state.totalSteps = initialPlanSteps.length;
    this.appendLog(
      'plan',
      `Formulated execution plan:\n${initialPlanSteps.map((s, i) => `${i + 1}. ${s}`).join('\n')}${skillsSummary ? `\n\n${skillsSummary}` : ''}`,
      'success'
    );

    this.toolExecutor = new AgentToolExecutor({
      workspaceRoot: this.workspaceRoot,
      commandTimeoutMs: this.commandTimeoutMs,
      maxOutputChars: this.maxOutputChars,
      autoApprove: this.config?.autoApprove,
      onPendingApproval: this.config?.onPendingApproval,
      taskId,
    });

    const conversation: AgentMessage[] = [
      {
        role: 'system',
        content: `You are Zoya Coding Agent, a top-tier autonomous software engineering agent running directly on the system.
You operate strictly within the confined workspace folder: "${this.workspaceRoot}".

Your standard cycle:
1. [PLAN]: Break the task down into clear numbered steps.
2. [TOOL_CALL]: Execute the best tool for the current step. Never guess; read or inspect first.
3. [READ_RESULT]: Scrutinize the tool output, exit codes, and diffs.
4. [FIX]: If an error occurs, analyze the stack trace or compiler error and formulate a precise fix immediately. Do not repeat the exact same failing action without changes.
5. [VERIFY]: Run tests or build checks to prove that the code actually compiles and functions as intended.
6. [REPORT]: Provide a concise, factual summary of all actions taken and verification evidence.

STRICT RULES:
- Use tools to inspect and modify files.
- Stay inside the workspace.
- Check compiler/test outputs after changes.
- Emit tool calls using the available tool declarations.`,
      },
      {
        role: 'user',
        content: `Task: ${userPrompt}\n\nConfined Workspace: ${this.workspaceRoot}${skillsSummary ? `\n\n${skillsSummary}` : ''}\nPlease form a plan, execute it, self-heal any failures, verify the build/tests, and report the outcome.`,
      },
    ];

    try {
      let loopIteration = 0;
      const MAX_TOTAL_TURNS = 18;
      const toolCallCounts = new Map<string, number>();

      while (loopIteration < MAX_TOTAL_TURNS && !this.isAborted) {
        loopIteration++;
        const turnStart = Date.now();

        // 1. Ask model for next action (plan, tool call, or final answer)
        const availableTools = this.toolExecutor.getAvailableToolDeclarations();
        const modelResponse = await this.provider.generate(conversation, availableTools);

        if (this.isAborted) break;

        const content = modelResponse.content || '';
        const toolCalls = modelResponse.toolCalls || [];

        // If model produces a detailed numbered plan on turn 1, refine the plan steps
        if (content && loopIteration === 1) {
          const extractedPlan = this.extractPlanSteps(content);
          if (extractedPlan.length > 0) {
            state.plan = extractedPlan;
            state.totalSteps = extractedPlan.length;
          }
        }

        // If no tool calls: check if task is actually done or if it's an initial plan/text turn
        if (toolCalls.length === 0) {
          const hasRunTools = conversation.some((m) => m.role === 'tool');
          if (hasRunTools || loopIteration >= 3) {
            state.status = 'completed';
            state.finalReport = content;
            state.endTime = new Date().toISOString();
            this.appendLog('report', content, 'success', Date.now() - turnStart);
            this.persistTaskLog();
            this.notifyState();
            return state;
          }

          // Initial plan turn: ask model to proceed immediately with step 1
          conversation.push({
            role: 'assistant',
            content,
          });
          conversation.push({
            role: 'user',
            content: 'Plan noted. Please proceed immediately to execute Step 1 by calling the appropriate tool.',
          });
          continue;
        }

        // Add assistant turn to conversation
        conversation.push({
          role: 'assistant',
          content: content || `Executing tools: ${toolCalls.map((t) => t.name).join(', ')}`,
          toolCalls,
        });

        // 2. Execute tool calls sequentially
        for (const call of toolCalls) {
          if (this.isAborted) break;

          const callSignature = `${call.name}:${JSON.stringify(call.args)}`;
          const priorCount = toolCallCounts.get(callSignature) || 0;
          toolCallCounts.set(callSignature, priorCount + 1);

          if (priorCount >= 1 && (call.name === 'list_dir' || call.name === 'search_code' || call.name === 'read_file')) {
            conversation.push({
              role: 'user',
              content: `Notice: You have already inspected this path via "${call.name}". Please proceed directly to write or edit the files required for the task.`,
            });
            continue;
          }

          state.currentStep = Math.min(state.totalSteps, state.currentStep + 1);
          const toolStart = Date.now();

          this.appendLog(
            'tool_call',
            `Executing tool '${call.name}' with args: ${JSON.stringify(call.args)}`,
            'running',
            undefined,
            call.name,
            call.args
          );

          // Real execution inside confined workspace
          const toolResult = await this.toolExecutor.executeTool(call.name, call.args);
          const duration = Date.now() - toolStart;

          // 3. Read Result & Evaluate Success / Failure
          if (toolResult.success) {
            this.appendLog(
              'read_result',
              `Tool '${call.name}' succeeded (${duration}ms):\n${toolResult.output}`,
              'success',
              duration,
              call.name,
              call.args,
              toolResult
            );

            // Feed tool result back to model conversation
            conversation.push({
              role: 'tool',
              name: call.name,
              toolCallId: call.id,
              content: toolResult.output,
            });

            if (call.name === 'list_dir' || call.name === 'search_code') {
              conversation.push({
                role: 'user',
                content: 'Inspection complete. Now proceed immediately to create or edit the code files required for the task.',
              });
            }

            // If it was a verify step (run_tests or run_build)
            if (call.name === 'run_tests' || call.name === 'run_build') {
              this.appendLog(
                'verify',
                `Verification verification passed for ${call.name}:\n${toolResult.output}`,
                'success',
                duration
              );
            }
          } else {
            // Failure occurred: handle retry & auto-fix logic
            state.retryCount++;
            const isOverRetryLimit = state.retryCount > state.maxRetries;

            this.appendLog(
              'fix',
              `Tool '${call.name}' encountered error (Attempt ${state.retryCount}/${state.maxRetries}):\n${toolResult.output}`,
              isOverRetryLimit ? 'failure' : 'retrying',
              duration,
              call.name,
              call.args,
              toolResult
            );

            conversation.push({
              role: 'tool',
              name: call.name,
              toolCallId: call.id,
              content: `[TOOL ERROR] ${toolResult.output}\nPlease analyze the root cause and execute a corrective fix immediately.`,
            });

            if (isOverRetryLimit) {
              state.status = 'failed';
              state.error = `Maximum retry limit (${state.maxRetries}) exceeded on tool '${call.name}'.`;
              state.endTime = new Date().toISOString();
              this.appendLog(
                'report',
                `Task failed: ${state.error}\nLast output: ${toolResult.output}`,
                'failure'
              );
              this.persistTaskLog();
              this.notifyState();
              return state;
            }
          }
        }
      }

      if (state.status === 'running') {
        state.status = 'completed';
        state.endTime = new Date().toISOString();
        state.finalReport = 'Agent completed task execution cycle.';
        this.appendLog('report', state.finalReport, 'success');
      }
    } catch (err: any) {
      state.status = 'failed';
      state.error = err?.message || String(err);
      state.endTime = new Date().toISOString();
      this.appendLog('report', `Agent execution failed with error: ${state.error}`, 'failure');
    }

    this.persistTaskLog();
    this.notifyState();
    return state;
  }

  private extractPlanSteps(text: string): string[] {
    const lines = text.split('\n');
    const steps: string[] = [];
    const stepRegex = /^\s*(?:\d+[\.\)]|step\s+\d+[:\.\)])\s+(.*)/i;

    for (const line of lines) {
      const match = line.match(stepRegex);
      if (match && match[1].trim()) {
        steps.push(match[1].trim());
      }
    }

    return steps.slice(0, 10);
  }

  private appendLog(
    phase: AgentStepPhase,
    description: string,
    status: 'running' | 'success' | 'failure' | 'retrying',
    durationMs?: number,
    toolName?: string,
    toolArgs?: any,
    toolResult?: ToolResult
  ) {
    if (!this.activeTask) return;

    const entry: AgentLogEntry = {
      id: `log_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      timestamp: new Date().toISOString(),
      phase,
      stepNumber: this.activeTask.logs.length + 1,
      description: maskSecrets(description),
      status,
      durationMs,
      toolName,
      toolArgs,
      toolResult,
    };

    this.activeTask.logs.push(entry);

    if (this.config?.onLogUpdate) {
      this.config.onLogUpdate(entry);
    }
    this.notifyState();
  }

  private notifyState() {
    if (this.activeTask && this.config?.onStateUpdate) {
      this.config.onStateUpdate({ ...this.activeTask });
    }
  }

  private persistTaskLog() {
    if (!this.activeTask) return;
    try {
      const filename = path.join(LOGS_DIR, `${this.activeTask.taskId}.json`);
      fs.writeFileSync(filename, JSON.stringify(this.activeTask, null, 2), 'utf8');
    } catch (e) {
      console.warn('[AGENT_CORE] Failed to persist log:', e);
    }
  }

  public getSavedTaskLogs(): AgentTaskState[] {
    try {
      if (!fs.existsSync(LOGS_DIR)) return [];
      const files = fs.readdirSync(LOGS_DIR).filter((f) => f.endsWith('.json'));
      const tasks: AgentTaskState[] = [];
      for (const file of files.sort().reverse().slice(0, 30)) {
        try {
          const raw = fs.readFileSync(path.join(LOGS_DIR, file), 'utf8');
          tasks.push(JSON.parse(raw));
        } catch {
          // ignore corrupted files
        }
      }
      return tasks;
    } catch {
      return [];
    }
  }
}
