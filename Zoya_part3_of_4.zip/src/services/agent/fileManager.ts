import fs from 'fs';
import path from 'path';
import { resolveWorkspacePath, truncateOutput } from './agentTools.ts';
import { agentPermissionGuard, maskSecrets, type PermissionLevel } from './agentPermissionGuard.ts';

export interface FileTreeNode {
  name: string;
  path: string; // Relative to workspace root
  type: 'file' | 'directory';
  size?: number;
  mtime?: string;
  children?: FileTreeNode[];
}

export interface FileChangeRecord {
  id: string;
  timestamp: string;
  path: string; // Relative
  changeType: 'create' | 'modify' | 'delete' | 'rename';
  oldSize?: number;
  newSize?: number;
  unifiedDiff?: string;
  previousContent?: string;
}

export interface FileManagerOptions {
  workspaceRoot?: string;
  changeLogPath?: string;
  maxFileSize?: number;
}

/**
 * Computes a standard unified diff between two text strings.
 */
export function generateUnifiedDiff(filePath: string, oldText: string, newText: string): string {
  const oldLines = oldText === '' ? [] : oldText.split('\n');
  const newLines = newText === '' ? [] : newText.split('\n');

  if (oldText === newText) {
    return `--- a/${filePath}\n+++ b/${filePath}\n(No changes)`;
  }

  // Simple LCS diff for clean hunk generation
  const diffHunks: string[] = [];
  diffHunks.push(`--- a/${filePath}`);
  diffHunks.push(`+++ b/${filePath}`);

  // Compute longest common subsequence table
  const m = oldLines.length;
  const n = newLines.length;

  // For very large files, limit LCS computation to first 1500 lines to avoid high CPU usage
  const MAX_DIFF_LINES = 1500;
  if (m > MAX_DIFF_LINES || n > MAX_DIFF_LINES) {
    return `${diffHunks.join('\n')}\n@@ -1,${m} +1,${n} @@\n[File too large for line-by-line diff - replaced ${m} lines with ${n} lines]`;
  }

  const dp: number[][] = Array(m + 1)
    .fill(0)
    .map(() => Array(n + 1).fill(0));

  for (let i = 0; i < m; i++) {
    for (let j = 0; j < n; j++) {
      if (oldLines[i] === newLines[j]) {
        dp[i + 1][j + 1] = dp[i][j] + 1;
      } else {
        dp[i + 1][j + 1] = Math.max(dp[i + 1][j], dp[i][j + 1]);
      }
    }
  }

  // Backtrack to find edits
  const edits: { type: 'keep' | 'add' | 'delete'; line: string }[] = [];
  let i = m;
  let j = n;

  while (i > 0 || j > 0) {
    if (i > 0 && j > 0 && oldLines[i - 1] === newLines[j - 1]) {
      edits.unshift({ type: 'keep', line: oldLines[i - 1] });
      i--;
      j--;
    } else if (j > 0 && (i === 0 || dp[i][j - 1] >= dp[i - 1][j])) {
      edits.unshift({ type: 'add', line: newLines[j - 1] });
      j--;
    } else if (i > 0) {
      edits.unshift({ type: 'delete', line: oldLines[i - 1] });
      i--;
    }
  }

  // Format into standard diff format with @@ header
  diffHunks.push(`@@ -1,${m} +1,${n} @@`);
  for (const edit of edits) {
    if (edit.type === 'keep') {
      diffHunks.push(` ${edit.line}`);
    } else if (edit.type === 'delete') {
      diffHunks.push(`-${edit.line}`);
    } else if (edit.type === 'add') {
      diffHunks.push(`+${edit.line}`);
    }
  }

  return diffHunks.join('\n');
}

export class FileManager {
  private workspaceRoot: string;
  private changeLogPath: string;
  private maxFileSize: number;
  private changeHistory: FileChangeRecord[] = [];
  private initialFileSnapshots: Map<string, string> = new Map();

  constructor(options?: FileManagerOptions) {
    this.workspaceRoot = path.resolve(options?.workspaceRoot || path.resolve(process.cwd(), 'workspace'));
    if (!fs.existsSync(this.workspaceRoot)) {
      fs.mkdirSync(this.workspaceRoot, { recursive: true });
    }
    this.changeLogPath =
      options?.changeLogPath || path.resolve(process.cwd(), 'data', 'agent_logs', 'file_changes.json');
    this.maxFileSize = options?.maxFileSize || 10 * 1024 * 1024; // 10MB limit

    this.loadChangeHistory();
  }

  public getWorkspaceRoot(): string {
    return this.workspaceRoot;
  }

  /**
   * Explores workspace and returns a recursive file tree structure.
   */
  public getFileTree(subDir: string = '', depth: number = 6): FileTreeNode {
    const targetDir = subDir ? resolveWorkspacePath(subDir, this.workspaceRoot) : this.workspaceRoot;
    return this.buildTree(targetDir, depth, 0);
  }

  private buildTree(currentDir: string, maxDepth: number, currentDepth: number): FileTreeNode {
    const relPath = path.relative(this.workspaceRoot, currentDir) || '.';
    const baseName = path.basename(currentDir) || 'workspace';

    const node: FileTreeNode = {
      name: baseName,
      path: relPath,
      type: 'directory',
      children: []
    };

    if (currentDepth >= maxDepth) return node;

    try {
      const entries = fs.readdirSync(currentDir, { withFileTypes: true });
      // Sort: directories first, then alphabetically
      entries.sort((a, b) => {
        if (a.isDirectory() && !b.isDirectory()) return -1;
        if (!a.isDirectory() && b.isDirectory()) return 1;
        return a.name.localeCompare(b.name);
      });

      for (const entry of entries) {
        // Exclude common bulky or cache directories from deep expansion
        if (['node_modules', '.git', '.cache', 'dist'].includes(entry.name)) {
          node.children?.push({
            name: entry.name,
            path: path.relative(this.workspaceRoot, path.join(currentDir, entry.name)),
            type: entry.isDirectory() ? 'directory' : 'file',
            size: 0
          });
          continue;
        }

        const fullPath = path.join(currentDir, entry.name);
        const childRel = path.relative(this.workspaceRoot, fullPath);

        if (entry.isDirectory()) {
          node.children?.push(this.buildTree(fullPath, maxDepth, currentDepth + 1));
        } else {
          try {
            const stat = fs.statSync(fullPath);
            node.children?.push({
              name: entry.name,
              path: childRel,
              type: 'file',
              size: stat.size,
              mtime: stat.mtime.toISOString()
            });
          } catch {
            node.children?.push({
              name: entry.name,
              path: childRel,
              type: 'file',
              size: 0
            });
          }
        }
      }
    } catch {
      // Permission or unreadable directory
    }

    return node;
  }

  /**
   * Reads a file from workspace.
   */
  public readFile(relPath: string): { content: string; size: number; mtime: string; path: string } {
    const fullPath = resolveWorkspacePath(relPath, this.workspaceRoot);
    if (!fs.existsSync(fullPath)) {
      throw new Error(`File does not exist: '${relPath}'`);
    }
    const stat = fs.statSync(fullPath);
    if (stat.isDirectory()) {
      throw new Error(`Path is a directory, not a file: '${relPath}'`);
    }
    if (stat.size > this.maxFileSize) {
      throw new Error(`File is too large (${stat.size} bytes). Max readable size is ${this.maxFileSize} bytes.`);
    }

    const content = fs.readFileSync(fullPath, 'utf-8');

    // Snapshot initial state if not yet recorded in this session
    if (!this.initialFileSnapshots.has(relPath)) {
      this.initialFileSnapshots.set(relPath, content);
    }

    return {
      content,
      size: stat.size,
      mtime: stat.mtime.toISOString(),
      path: relPath
    };
  }

  /**
   * Writes content to a file, tracking changes and generating unified diff.
   */
  public async writeFile(
    relPath: string,
    content: string,
    options?: { bypassPermission?: boolean; taskId?: string }
  ): Promise<{ path: string; changeType: 'create' | 'modify'; diff: string }> {
    const fullPath = resolveWorkspacePath(relPath, this.workspaceRoot);
    const exists = fs.existsSync(fullPath);
    const parentDir = path.dirname(fullPath);

    if (!fs.existsSync(parentDir)) {
      fs.mkdirSync(parentDir, { recursive: true });
    }

    let previousContent = '';
    let changeType: 'create' | 'modify' = 'create';
    let oldSize = 0;

    if (exists) {
      changeType = 'modify';
      try {
        previousContent = fs.readFileSync(fullPath, 'utf-8');
        oldSize = Buffer.byteLength(previousContent, 'utf-8');
      } catch {}
    }

    // Permission evaluation
    if (!options?.bypassPermission) {
      const auth = agentPermissionGuard.checkToolCall('write_file', { path: relPath, content }, this.workspaceRoot);
      if (auth.isBlocked) {
        throw new Error(`Security Gate Blocked: ${auth.reason}`);
      }
      if (auth.needsApproval) {
        const { promise } = agentPermissionGuard.requestApproval(
          options?.taskId || 'file_manager',
          'write_file',
          { path: relPath, size: content.length },
          auth.level as any,
          auth.reason,
          auth.warning
        );
        const approved = await promise;
        if (!approved) {
          throw new Error('Write operation denied by user or policy.');
        }
      }
    }

    // Snapshot initial state if not yet captured
    if (exists && !this.initialFileSnapshots.has(relPath)) {
      this.initialFileSnapshots.set(relPath, previousContent);
    }

    fs.writeFileSync(fullPath, content, 'utf-8');
    const newSize = Buffer.byteLength(content, 'utf-8');
    const unifiedDiff = generateUnifiedDiff(relPath, previousContent, content);

    const record: FileChangeRecord = {
      id: `change_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
      timestamp: new Date().toISOString(),
      path: relPath,
      changeType,
      oldSize,
      newSize,
      unifiedDiff,
      previousContent
    };

    this.changeHistory.push(record);
    this.saveChangeHistory();

    return {
      path: relPath,
      changeType,
      diff: unifiedDiff
    };
  }

  /**
   * Deletes a file or directory inside workspace with permission guard.
   */
  public async deletePath(
    relPath: string,
    options?: { recursive?: boolean; bypassPermission?: boolean; taskId?: string }
  ): Promise<{ path: string; deleted: boolean }> {
    const fullPath = resolveWorkspacePath(relPath, this.workspaceRoot);
    if (!fs.existsSync(fullPath)) {
      return { path: relPath, deleted: false };
    }

    const stat = fs.statSync(fullPath);
    const isDir = stat.isDirectory();

    // Security check: Deletions are STRICT_APPROVAL_WITH_WARNING
    if (!options?.bypassPermission) {
      const auth = agentPermissionGuard.checkToolCall(
        'delete_file',
        { path: relPath, isDirectory: isDir },
        this.workspaceRoot
      );
      if (auth.isBlocked) {
        throw new Error(`Security Gate Blocked: ${auth.reason}`);
      }
      if (auth.needsApproval) {
        const { promise } = agentPermissionGuard.requestApproval(
          options?.taskId || 'file_manager',
          'delete_file',
          { path: relPath, isDirectory: isDir },
          'STRICT_APPROVAL_WITH_WARNING',
          `Deleting ${isDir ? 'directory' : 'file'} '${relPath}' cannot be undone.`,
          'WARNING: Irreversible deletion'
        );
        const approved = await promise;
        if (!approved) {
          throw new Error('Delete operation denied by user.');
        }
      }
    }

    let previousContent: string | undefined;
    if (!isDir) {
      try {
        previousContent = fs.readFileSync(fullPath, 'utf-8');
      } catch {}
    }

    if (isDir) {
      fs.rmSync(fullPath, { recursive: true, force: true });
    } else {
      fs.unlinkSync(fullPath);
    }

    const record: FileChangeRecord = {
      id: `change_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
      timestamp: new Date().toISOString(),
      path: relPath,
      changeType: 'delete',
      previousContent
    };
    this.changeHistory.push(record);
    this.saveChangeHistory();

    return { path: relPath, deleted: true };
  }

  /**
   * Creates a directory within workspace.
   */
  public createDirectory(relPath: string): { path: string; created: boolean } {
    const fullPath = resolveWorkspacePath(relPath, this.workspaceRoot);
    if (!fs.existsSync(fullPath)) {
      fs.mkdirSync(fullPath, { recursive: true });
      return { path: relPath, created: true };
    }
    return { path: relPath, created: false };
  }

  /**
   * Returns unified diff for a file against its initial baseline or previous change.
   */
  public getFileDiff(relPath: string): string {
    const fullPath = resolveWorkspacePath(relPath, this.workspaceRoot);
    const exists = fs.existsSync(fullPath);
    const currentText = exists ? fs.readFileSync(fullPath, 'utf-8') : '';

    const baseText = this.initialFileSnapshots.get(relPath) || '';
    return generateUnifiedDiff(relPath, baseText, currentText);
  }

  /**
   * Returns the list of changed files and records.
   */
  public getChangeHistory(limit: number = 50): FileChangeRecord[] {
    return this.changeHistory.slice(-limit).reverse();
  }

  /**
   * Returns list of currently modified files relative to session baseline.
   */
  public getChangedFiles(): { path: string; type: 'created' | 'modified' | 'deleted' }[] {
    const results: { path: string; type: 'created' | 'modified' | 'deleted' }[] = [];

    // Check tracked records
    const pathStatus = new Map<string, 'created' | 'modified' | 'deleted'>();
    for (const record of this.changeHistory) {
      if (record.changeType === 'create') pathStatus.set(record.path, 'created');
      else if (record.changeType === 'modify') pathStatus.set(record.path, 'modified');
      else if (record.changeType === 'delete') pathStatus.set(record.path, 'deleted');
    }

    for (const [p, type] of pathStatus.entries()) {
      results.push({ path: p, type });
    }

    return results;
  }

  /**
   * Reverts a file to its previous state from change history.
   */
  public async revertFile(relPath: string): Promise<boolean> {
    const lastChange = [...this.changeHistory]
      .reverse()
      .find((c) => c.path === relPath && c.previousContent !== undefined);

    if (!lastChange || lastChange.previousContent === undefined) {
      throw new Error(`No previous version found for '${relPath}' to revert.`);
    }

    await this.writeFile(relPath, lastChange.previousContent, { bypassPermission: true });
    return true;
  }

  private saveChangeHistory() {
    try {
      const dir = path.dirname(this.changeLogPath);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      fs.writeFileSync(this.changeLogPath, JSON.stringify(this.changeHistory.slice(-200), null, 2), 'utf-8');
    } catch {}
  }

  private loadChangeHistory() {
    try {
      if (fs.existsSync(this.changeLogPath)) {
        const raw = fs.readFileSync(this.changeLogPath, 'utf-8');
        this.changeHistory = JSON.parse(raw);
      }
    } catch {
      this.changeHistory = [];
    }
  }
}

export const fileManager = new FileManager();
