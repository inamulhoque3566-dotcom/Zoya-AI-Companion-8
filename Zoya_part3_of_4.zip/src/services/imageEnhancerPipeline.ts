/**
 * Zoya Real Image Enhancement & Filter Pipeline
 * Provides end-to-end image processing, adjustments, convolution sharpening,
 * and PNG export without placeholders.
 */

export interface ImageEnhancerOptions {
  brightness: number; // 0 to 200 (100 is default)
  contrast: number;   // 0 to 200 (100 is default)
  saturation: number; // 0 to 200 (100 is default)
  sharpen: number;    // 0 to 100 (0 is none, 100 is max unsharp mask)
  grayscale: boolean;
  invert: boolean;
}

export const DEFAULT_ENHANCE_OPTIONS: ImageEnhancerOptions = {
  brightness: 110,
  contrast: 115,
  saturation: 105,
  sharpen: 30,
  grayscale: false,
  invert: false,
};

/**
 * Applies 3x3 convolution kernel to ImageData for unsharp mask sharpening
 */
export function applyConvolutionSharpen(
  imageData: ImageData,
  strength: number // 0.0 to 1.0
): ImageData {
  const width = imageData.width;
  const height = imageData.height;
  const src = imageData.data;
  const output = new ImageData(new Uint8ClampedArray(src), width, height);
  const dst = output.data;

  // Center weight increases with strength: at strength 1.0, weight is 5.0 (subtracting 1.0 from 4 neighbors)
  const centerWeight = 1 + 4 * strength;
  const neighborWeight = -strength;

  for (let y = 1; y < height - 1; y++) {
    for (let x = 1; x < width - 1; x++) {
      const idx = (y * width + x) * 4;

      for (let c = 0; c < 3; c++) {
        const top = src[((y - 1) * width + x) * 4 + c];
        const bottom = src[((y + 1) * width + x) * 4 + c];
        const left = src[(y * width + (x - 1)) * 4 + c];
        const right = src[(y * width + (x + 1)) * 4 + c];
        const center = src[idx + c];

        const val =
          center * centerWeight +
          (top + bottom + left + right) * neighborWeight;

        dst[idx + c] = Math.min(255, Math.max(0, val));
      }
      dst[idx + 3] = src[idx + 3]; // preserve alpha
    }
  }

  return output;
}

/**
 * Browser-side end-to-end canvas enhancement function.
 * Takes an HTMLImageElement or ImageBitmap, applies filters, and returns data URL PNG.
 */
export function processImageOnCanvas(
  img: HTMLImageElement | HTMLCanvasElement,
  options: Partial<ImageEnhancerOptions> = {}
): string {
  const opts = { ...DEFAULT_ENHANCE_OPTIONS, ...options };
  const canvas = document.createElement('canvas');
  canvas.width = (img as any).naturalWidth || img.width;
  canvas.height = (img as any).naturalHeight || img.height;
  const ctx = canvas.getContext('2d');
  if (!ctx) return '';

  // 1. Apply standard color filters
  const filterParts = [
    `brightness(${opts.brightness}%)`,
    `contrast(${opts.contrast}%)`,
    `saturate(${opts.saturation}%)`,
  ];
  if (opts.grayscale) filterParts.push('grayscale(100%)');
  if (opts.invert) filterParts.push('invert(100%)');

  ctx.filter = filterParts.join(' ');
  ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
  ctx.filter = 'none';

  // 2. Apply convolution unsharp mask sharpening if requested
  if (opts.sharpen > 0) {
    try {
      const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const sharpened = applyConvolutionSharpen(imgData, opts.sharpen / 100);
      ctx.putImageData(sharpened, 0, 0);
    } catch {
      // Ignore cross-origin canvas security restriction if un-tainted
    }
  }

  return canvas.toDataURL('image/png');
}
