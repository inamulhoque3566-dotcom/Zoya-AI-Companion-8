/**
 * Speech Recognition Manager
 * TypeScript port of com.openclaw.assistant.speech.SpeechRecognizerManager.kt
 * 
 * Stability & Anti-Flicker Architecture:
 * 1. User Intent as UI State: `isPersistentMode` reflects the user's explicit control.
 * 2. Invisible Silence Restarts: Normal browser silence timeouts (`onend`) restart silently in the background
 *    WITHOUT flipping the UI indicator or emitting rapid state transitions.
 * 3. Rapid Loop Protection: If restarts happen >= 3 times in < 3 seconds (signaling real hardware/OS failure),
 *    the loop halts to save phone battery & CPU, and surfaces a single clean error state.
 * 4. Real Audio Source: Web Audio API analyser attached to getUserMedia stream provides true RMS volume.
 */

import { HardwareCaptureState, HardwareStateInfo, SpeechRecognizerListener, SpeechResult } from './SpeechTypes';
import { getLanguageConfig } from '../languageConfig';
import { micStateMachine } from './MicStateMachine';
import { getDecryptedSecretSync } from '../secretVault';
import { voiceTelemetry } from '../voiceTelemetry';

export type MicPermissionState = 'not_asked' | 'granted' | 'denied_by_user' | 'iframe_blocked' | 'unknown';

/// Wake phrase regex patterns (English, Hinglish, Hindi, phonetic mistranscriptions, and "hello hello")
const WAKE_PHRASE_REGEX = /^(?:(?:hello|helo|hey|hi|ok|okay|namaste|suno)[,\s]+)?(?:zoya|zoyaa|zoia|zoiya|joya|joyaa|soya|zohra|zohaya|zoe|zoey|zora|johaia)\b|^(?:hello|helo)[,\s]+(?:hello|helo)\b/i;
const HINDI_WAKE_REGEX = /^(?:(?:हे|हैलो|हेलो|हलो|हाय|नमस्ते|नमस्कार|सुनो|प्रणाम|ओके)[,\s]+)?(?:जोया|ज़ोया|झोया|जया|जोय|ज़ोहरा|जोहरा|ज़ोहाया|जोहाया|ज़ोई|जोई|जोए)(?:[\s,!?:;।.\-]|$)|^(?:हैलो|हेलो|हलो)[,\s]+(?:हैलो|हेलो|हलो)(?:[\s,!?:;।.\-]|$)/i;
const GENERAL_ZOYA_REGEX = /\b(?:zoya|zoyaa|zoia|zoiya|joya|joyaa|soya|zohra|zohaya|zoe|zoey|zora|johaia)\b|\b(?:hello|helo)[,\s]+(?:hello|helo)\b/i;
const GENERAL_HINDI_ZOYA_REGEX = /(जोया|ज़ोया|झोया|ज़ोहरा|जोहरा|ज़ोहाया|जोहाया|ज़ोई|जोई|हैलो[\s,]+हैलो|हेलो[\s,]+हेलो|জোয়া|জয়া|జోయా|ஜோயா|ઝોયા|زویا|ಜೋಯಾ|ଜୋୟା|സോയ|ജോയ|ਜ਼ੋਇਆ|ᱡᱚᱭᱟ)/;

export class SpeechRecognizerManager {
  private listener: SpeechRecognizerListener | null = null;
  private recognition: any = null;
  private isListeningActive = false;
  private isStarting = false;
  private isStopping = false;
  private isTearingDown = false;
  private silenceTimer: any = null;
  private silenceTimeoutMs = 1700;
  private targetLanguage = 'hi-IN';
  private restartAttemptCount = 0;

  // Pending transcript & single-dispatch deduplication state
  private pendingFinalTranscript = '';
  private pendingInterimTranscript = '';
  private lastDispatchedText = '';
  private lastDispatchedTime = 0;
  private onAdvanceConsumedResults: (() => void) | null = null;

  // Anti-Flicker & Rapid Restart Guard
  private recentRestartTimestamps: number[] = [];
  private isSilentRestartInProgress = false;

  // Real Hardware Audio Stream & Analyser (Single Source of Truth for mic input)
  private hardwareAudioStream: MediaStream | null = null;
  private hardwareAudioCtx: AudioContext | null = null;
  private hardwareAnalyser: AnalyserNode | null = null;
  private hardwareMonitorInterval: any = null;
  private isAudioHardwareStreaming = false;

  // Hardware State Tracking (Source of Truth for persistent indicator)
  private hardwareState: HardwareStateInfo = {
    state: 'idle',
    engine: 'none',
    isHardwareLive: false,
    receivingAudio: false,
    error: undefined,
    details: 'Initial standby',
  };

  // Persistent Always-On Mode State
  public isPersistentMode = false;
  public isWakeActive = false;
  public isPausedForSpeaking = false;
  public get isListening(): boolean {
    return this.isListeningActive;
  }
  private autoRestartTimer: any = null;
  private shouldAutoRestart = false;

  // Web Audio Keep-Alive for Background Tab Resilience
  private keepAliveCtx: AudioContext | null = null;
  private keepAliveOsc: OscillatorNode | null = null;
  private keepAliveGain: GainNode | null = null;

  // MediaRecorder fallback state & VAD
  public preferMediaRecorderFallback = false;
  private mediaRecorder: MediaRecorder | null = null;
  private vadSilenceTimer: any = null;
  private vadMaxTimer: any = null;
  private vadIdleRecycleTimer: any = null;
  private hasSpokenInCurrentChunk = false;
  private isSilentRecycle = false;
  private isDiscardingRecorderStop = false;
  private speechFrameCount = 0;
  private chunkPeakRms = 0;
  private chunkSpeechFrames = 0;
  private ambientNoiseFloor = 0.008;
  private consecutiveSttErrors = 0;
  private audioChunks: Blob[] = [];
  private isMediaRecorderActive = false;

  // Live diagnostics tracking
  private networkErrorCount = 0;
  public lastError: string = 'None';
  public lastLogMessage: string = 'Ready';
  public permissionState: MicPermissionState = 'not_asked';
  public currentEngine: 'native' | 'webspeech' | 'mediarecorder' | 'none' = 'none';
  private standbyWakeLocaleCycle = 0;

  // Voice Barge-In Monitor while AI speaks in Web Speech fallback (echo-gated)
  private bargeInStream: MediaStream | null = null;
  private bargeInAudioCtx: AudioContext | null = null;
  private bargeInInterval: any = null;
  private bargeInStartDelayTimer: any = null;

  constructor() {
    console.log('[SPEECH_INTERNAL] [LIFECYCLE] Initializing SpeechRecognizerManager');
    // Prefer Web Speech API by default for real-time live speech in input box, fall back to MediaRecorder if unsupported/errored
    this.preferMediaRecorderFallback = false;
    this.setupNativeBridgeListener();
    this.checkPermissionSilently();
    this.setupPageVisibilityListener();

    // Register adapter with central MicStateMachine (Single Source of Truth)
    micStateMachine.registerSpeechRecognizerAdapter({
      start: () => this.startListening(this.targetLanguage, this.silenceTimeoutMs),
      stop: () => this.stopListening(),
      isActive: () => this.isListeningActive,
    });
  }

  public getHardwareState(): HardwareStateInfo {
    return { ...this.hardwareState };
  }

  public getTargetLanguage(): string {
    return this.targetLanguage;
  }

  public setPreferMediaRecorder(prefer: boolean): void {
    this.preferMediaRecorderFallback = prefer;
  }

  public async setLanguage(language: string): Promise<void> {
    const config = getLanguageConfig(language);
    this.targetLanguage = config.code;
    console.log(`[SPEECH_INTERNAL] Language updated to ${config.name} (${config.code}), STT supported=${config.sttSupported}, fallback=${config.fallbackVoiceLang}`);
    if ((this.isPersistentMode || this.isListeningActive) && this.currentEngine === 'webspeech') {
      this.isSilentRestartInProgress = true;
      await this.startListening(config.code, this.silenceTimeoutMs);
    }
  }

  private notifyHardwareStateChange(
    state: HardwareCaptureState,
    engine: 'native' | 'webspeech' | 'mediarecorder' | 'none',
    isHardwareLive: boolean,
    receivingAudio: boolean,
    error?: string,
    details?: string
  ): void {
    // If persistent listening mode is enabled by the user, suppress any intermediate
    // 'restarting', 'starting', or 'idle' states from causing the UI indicator to flicker.
    // The UI must remain in a steady 'active' state during background silence restarts.
    if (this.isPersistentMode && (state === 'restarting' || state === 'starting' || state === 'idle')) {
      console.debug(`[SPEECH_INTERNAL] [ANTI_FLICKER] Suppressed UI state transition to '${state}'. UI remains steady active.`);
      return;
    }

    this.hardwareState = {
      state,
      engine,
      isHardwareLive,
      receivingAudio,
      error,
      details: details || `State: ${state} (${engine})`,
    };

    console.log(
      `[SPEECH_INTERNAL] [HARDWARE_STATE] state=${state} engine=${engine} live=${isHardwareLive} receivingAudio=${receivingAudio} error=${error || 'none'} details="${details || ''}"`
    );
    this.listener?.onHardwareStateChange?.(this.hardwareState);
  }

  private setupNativeBridgeListener(): void {
    if (typeof window === 'undefined') return;

    (window as any).__onNativeSpeechEvent = (event: SpeechResult | { type: 'end' }) => {
      console.log('[SPEECH_INTERNAL] [Native Bridge Event]:', event);
      if (!event || !event.type) return;

      switch (event.type) {
        case 'ready':
          this.isListeningActive = true;
          this.currentEngine = 'native';
          this.lastLogMessage = 'Native recognizer ready';
          this.notifyHardwareStateChange('active', 'native', true, false, undefined, 'Native recognizer ready');
          this.listener?.onReady?.();
          break;
        case 'listening':
          this.isListeningActive = true;
          this.currentEngine = 'native';
          this.lastLogMessage = 'Native recognizer listening';
          this.notifyHardwareStateChange('active', 'native', true, false, undefined, 'Native recognizer listening');
          this.listener?.onListening?.();
          break;
        case 'rmsChanged': {
          const rms = typeof event.rmsdB === 'number' ? event.rmsdB : 0;
          this.listener?.onRmsChanged?.(rms);
          if (rms > 0.05) {
            this.notifyHardwareStateChange('receiving_audio', 'native', true, true, undefined, `Native audio RMS: ${rms.toFixed(2)}`);
          } else if (this.hardwareState.receivingAudio) {
            this.notifyHardwareStateChange('active', 'native', true, false);
          }
          break;
        }
        case 'partialResult':
          this.pendingInterimTranscript = (event.text || '').trim();
          this.lastLogMessage = `Spoken: "${event.text}"`;
          this.notifyHardwareStateChange('receiving_audio', 'native', true, true, undefined, `Partial: "${event.text}"`);
          this.listener?.onPartialResult?.(event.text || '');
          break;
        case 'result':
          this.pendingFinalTranscript = '';
          this.pendingInterimTranscript = '';
          clearTimeout(this.silenceTimer);
          this.lastLogMessage = `Result: "${event.text}"`;
          this.notifyHardwareStateChange('active', 'native', true, false, undefined, `Final result: "${event.text}"`);
          this.dispatchFinalizedText(event.text || '', event.confidence, event.alternatives);
          if (this.isPersistentMode) {
            this.returnToStandby();
          } else {
            this.isListeningActive = false;
            this.notifyHardwareStateChange('idle', 'native', false, false);
          }
          break;
        case 'error':
          this.lastError = event.error;
          this.lastLogMessage = `Error: ${event.error}`;
          this.notifyHardwareStateChange('error', 'native', false, false, event.error);
          this.listener?.onError?.(event.error || 'माइक्रोफ़ोन त्रुटि', event.code || 1);
          if (!this.isPersistentMode) {
            this.isListeningActive = false;
          }
          break;
        case 'end':
          this.lastLogMessage = 'Session ended';
          if (!this.isPausedForSpeaking) {
            this.flushPendingTranscript('native_end');
          }
          if (this.isPausedForSpeaking) {
            break;
          }
          if (this.isPersistentMode && this.shouldAutoRestart) {
            console.log('[SPEECH_INTERNAL] Native session ended while persistent mode ON. Silent re-arm...');
            this.scheduleAutoRestart();
          } else {
            this.isListeningActive = false;
            this.notifyHardwareStateChange('idle', 'native', false, false);
            this.listener?.onEnd?.();
          }
          break;
      }
    };
  }

  private setupPageVisibilityListener(): void {
    if (typeof document === 'undefined') return;

    document.addEventListener('visibilitychange', () => {
      if (document.hidden) {
        console.log('[SPEECH_INTERNAL] App minimized / tab backgrounded. Persistent listening remains active.');
        this.ensureKeepAliveRunning();
      } else {
        console.log('[SPEECH_INTERNAL] App returned to foreground. Verifying speech recognizer state...');
        if (this.isPersistentMode && !this.isListeningActive) {
          console.log('[SPEECH_INTERNAL] Re-initiating speech recognizer after returning to foreground...');
          this.startListening(this.targetLanguage, this.silenceTimeoutMs);
        }
      }
    });
  }

  public setListener(listener: SpeechRecognizerListener): void {
    this.listener = listener;
    this.listener?.onHardwareStateChange?.(this.hardwareState);
  }

  public isInsideIframe(): boolean {
    if (typeof window === 'undefined') return false;
    try {
      return window.self !== window.top;
    } catch {
      return true;
    }
  }

  public checkIframePermissionPolicy(): { isAllowed: boolean; reason?: string } {
    if (typeof document === 'undefined') return { isAllowed: true };
    const doc = document as any;

    if (doc.permissionsPolicy && typeof doc.permissionsPolicy.allowsFeature === 'function') {
      const allowed = doc.permissionsPolicy.allowsFeature('microphone');
      if (!allowed) {
        return { isAllowed: false, reason: 'Iframe permissionsPolicy denies microphone access' };
      }
    } else if (doc.featurePolicy && typeof doc.featurePolicy.allowsFeature === 'function') {
      const allowed = doc.featurePolicy.allowsFeature('microphone');
      if (!allowed) {
        return { isAllowed: false, reason: 'Iframe featurePolicy denies microphone access' };
      }
    }

    return { isAllowed: true };
  }

  public async checkPermissionSilently(): Promise<MicPermissionState> {
    if (typeof navigator === 'undefined' || !navigator.permissions?.query) {
      this.permissionState = 'not_asked';
      return 'not_asked';
    }

    try {
      const status = await navigator.permissions.query({ name: 'microphone' as any });

      if (status.state === 'granted') {
        this.permissionState = 'granted';
      } else if (status.state === 'denied') {
        const policyCheck = this.checkIframePermissionPolicy();
        this.permissionState = (!policyCheck.isAllowed && this.isInsideIframe()) ? 'iframe_blocked' : 'denied_by_user';
      } else {
        this.permissionState = 'not_asked';
      }

      status.onchange = () => {
        this.checkPermissionSilently();
      };
      return this.permissionState;
    } catch {
      this.permissionState = 'not_asked';
      return 'not_asked';
    }
  }

  public async requestMicrophonePermission(
    keepStreamForMediaRecorder: boolean = false
  ): Promise<{ granted: boolean; state: MicPermissionState; message: string }> {
    console.log('[SPEECH_INTERNAL] [PERMISSION] requestMicrophonePermission() invoked, keepStream:', keepStreamForMediaRecorder);
    const inIframe = this.isInsideIframe();
    const policyCheck = this.checkIframePermissionPolicy();

    if (!policyCheck.isAllowed && inIframe) {
      const msg = 'माइक की अनुमति नहीं मिली। ब्राउज़र में Allow करो या ऐप को नए टैब में खोलो।';
      console.warn('[SPEECH_INTERNAL] iframe permissions policy blocked microphone');
      this.permissionState = 'iframe_blocked';
      this.lastError = msg;
      this.notifyHardwareStateChange('idle', 'none', false, false, undefined, msg);
      return { granted: false, state: 'iframe_blocked', message: msg };
    }

    if (typeof navigator === 'undefined' || !navigator.mediaDevices?.getUserMedia) {
      const msg = 'माइक की अनुमति नहीं मिली। ब्राउज़र में Allow करो या ऐप को नए टैब में खोलो।';
      console.warn('[SPEECH_INTERNAL] navigator.mediaDevices.getUserMedia unavailable');
      this.permissionState = 'denied_by_user';
      this.lastError = msg;
      this.notifyHardwareStateChange('idle', 'none', false, false, undefined, msg);
      return { granted: false, state: 'denied_by_user', message: msg };
    }

    try {
      console.log('[SPEECH_INTERNAL] Requesting temporary getUserMedia stream to confirm permission...');
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        },
      });
      console.log('[SPEECH_INTERNAL] getUserMedia SUCCESS! Active audio tracks:', stream.getTracks().length);
      
      // CRITICAL FIX: To prevent Android Chrome collision ("Speech Recognition and Synthesis from Google
      // cannot record now as Chrome is recording"), we MUST NOT leave the getUserMedia stream actively recording
      // in Chrome when preparing for Web Speech API. Only keep stream open if explicitly requested by MediaRecorder.
      if (keepStreamForMediaRecorder) {
        this.hardwareAudioStream = stream;
        this.startHardwareAudioMonitoring(stream);
      } else {
        stream.getTracks().forEach((track) => {
          try {
            track.stop();
          } catch {}
        });
        this.hardwareAudioStream = null;
        this.stopHardwareAudioMonitoring();
      }

      this.permissionState = 'granted';
      micStateMachine.reportMicPermission(true);
      this.lastError = 'None';
      this.lastLogMessage = 'माइक अनुमति प्राप्त (Permission Granted)';
      return { granted: true, state: 'granted', message: 'माइक अनुमति सफलतापूर्वक मिल गई है!' };
    } catch (err: any) {
      const errName = String(err?.name || 'Error');
      const errMsg = String(err?.message || err || '');
      console.warn('[SPEECH_INTERNAL] getUserMedia failed:', errName, errMsg);

      const isIframeBlock = inIframe && (
        errMsg.toLowerCase().includes('permissions policy') ||
        errMsg.toLowerCase().includes('disallowed') ||
        errName === 'SecurityError' ||
        !policyCheck.isAllowed
      );
      const detail = 'माइक की अनुमति नहीं मिली। ब्राउज़र में Allow करो या ऐप को नए टैब में खोलो।';
      this.permissionState = isIframeBlock ? 'iframe_blocked' : 'denied_by_user';
      micStateMachine.reportMicPermission(false);
      this.lastError = detail;
      this.notifyHardwareStateChange('idle', 'none', false, false, undefined, detail);
      return { granted: false, state: this.permissionState, message: detail };
    }
  }

  /**
   * Starts real hardware audio monitoring using Web Audio API connected to the real MediaStream.
   * This is the REAL source of truth for audio volume & active streaming (no fake wave simulation).
   */
  private startHardwareAudioMonitoring(stream: MediaStream): void {
    try {
      if (this.hardwareMonitorInterval) {
        clearInterval(this.hardwareMonitorInterval);
        this.hardwareMonitorInterval = null;
      }

      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;

      if (!this.hardwareAudioCtx || this.hardwareAudioCtx.state === 'closed') {
        this.hardwareAudioCtx = new AudioCtx();
      }

      if (this.hardwareAudioCtx.state === 'suspended') {
        this.hardwareAudioCtx.resume().catch(() => {});
      }

      const source = this.hardwareAudioCtx.createMediaStreamSource(stream);
      const analyser = this.hardwareAudioCtx.createAnalyser();
      analyser.fftSize = 512;
      analyser.smoothingTimeConstant = 0.35;
      source.connect(analyser);
      this.hardwareAnalyser = analyser;

      const timeData = new Float32Array(analyser.fftSize);
      this.speechFrameCount = 0;

      console.log('[SPEECH_INTERNAL] [HARDWARE_STREAM] True RMS time-domain VAD attached to hardware mic stream');

      this.hardwareMonitorInterval = setInterval(() => {
        if (!this.hardwareAnalyser || this.isPausedForSpeaking) return;
        this.hardwareAnalyser.getFloatTimeDomainData(timeData);

        let sumSq = 0;
        for (let i = 0; i < timeData.length; i++) {
          sumSq += timeData[i] * timeData[i];
        }
        const rms = Math.sqrt(sumSq / timeData.length);
        const volume = Math.min(1, rms * 5.0);

        // Adaptive noise floor only when below active speech
        if (this.speechFrameCount === 0 && rms < 0.04) {
          this.ambientNoiseFloor = Math.max(
            0.002,
            Math.min(0.025, this.ambientNoiseFloor * 0.95 + rms * 0.05)
          );
        }

        const SPEECH_RMS_THRESHOLD = Math.max(0.014, this.ambientNoiseFloor * 2.3);

        // Notify listener of real hardware RMS volume
        this.listener?.onRmsChanged?.(volume);

        if (rms > this.chunkPeakRms) {
          this.chunkPeakRms = rms;
        }

        if (rms > SPEECH_RMS_THRESHOLD) {
          this.speechFrameCount++;
          this.chunkSpeechFrames++;
          if (this.speechFrameCount >= 2 || rms > 0.04) {
            if (!this.hasSpokenInCurrentChunk) {
              this.hasSpokenInCurrentChunk = true;
              console.log(
                `[LOVE_VOICE_CHAIN] [1. RECORD_SPEECH_START] User speech detected (rms=${rms.toFixed(4)}, threshold=${SPEECH_RMS_THRESHOLD.toFixed(4)})`
              );
              if (this.vadIdleRecycleTimer) {
                clearTimeout(this.vadIdleRecycleTimer);
                this.vadIdleRecycleTimer = null;
              }
              if (this.vadMaxTimer) {
                clearTimeout(this.vadMaxTimer);
              }
              this.vadMaxTimer = setTimeout(() => {
                if (this.mediaRecorder && this.mediaRecorder.state === 'recording' && this.hasSpokenInCurrentChunk) {
                  console.log('[LOVE_VOICE_CHAIN] [1. RECORD_MAX_CAP] 25s utterance limit reached -> finalizing chunk');
                  try {
                    this.mediaRecorder.stop();
                  } catch {}
                }
              }, 25000);
            }
            if (this.vadSilenceTimer) {
              clearTimeout(this.vadSilenceTimer);
              this.vadSilenceTimer = null;
            }
            if (!this.hardwareState.receivingAudio) {
              this.notifyHardwareStateChange(
                'receiving_audio',
                this.currentEngine,
                true,
                true,
                undefined,
                `Receiving audio RMS: ${rms.toFixed(3)}`
              );
            }
          }
        } else {
          this.speechFrameCount = 0;
          if (this.hardwareState.receivingAudio && this.isListeningActive) {
            this.notifyHardwareStateChange('active', this.currentEngine, true, false, undefined, 'सुन रहा है');
          }
          // 1.5–2s Silence Detection: finalize recording after silenceTimeoutMs (default 1700ms)
          if (this.hasSpokenInCurrentChunk && this.isMediaRecorderActive && !this.vadSilenceTimer) {
            const silenceWaitMs = Math.max(1500, Math.min(2000, this.silenceTimeoutMs || 1700));
            this.vadSilenceTimer = setTimeout(() => {
              this.vadSilenceTimer = null;
              if (this.mediaRecorder && this.mediaRecorder.state === 'recording' && this.hasSpokenInCurrentChunk) {
                console.log(
                  `[LOVE_VOICE_CHAIN] [1. RECORD_SILENCE_STOP] ${silenceWaitMs}ms silence detected -> stopping recording for STT`
                );
                try {
                  this.mediaRecorder.stop();
                } catch {}
              }
            }, silenceWaitMs);
          }
        }
      }, 60);
    } catch (e) {
      console.warn('[SPEECH_INTERNAL] Failed to start hardware audio monitor:', e);
    }
  }

  private stopHardwareAudioMonitoring(): void {
    if (this.hardwareMonitorInterval) {
      clearInterval(this.hardwareMonitorInterval);
      this.hardwareMonitorInterval = null;
    }
    if (this.hardwareAudioCtx && this.hardwareAudioCtx.state !== 'closed') {
      try {
        this.hardwareAudioCtx.close().catch(() => {});
      } catch {}
      this.hardwareAudioCtx = null;
    }
    this.hardwareAnalyser = null;
    this.listener?.onRmsChanged?.(0);
  }

  public isAvailable(): boolean {
    if (typeof window === 'undefined') return false;
    if ((window as any).AndroidBridge || (window as any).__openclaw) return true;
    if ((window as any).SpeechRecognition || (window as any).webkitSpeechRecognition) return true;
    return typeof navigator !== 'undefined' && !!navigator.mediaDevices?.getUserMedia;
  }

  private ensureKeepAliveRunning(): void {
    if (typeof window === 'undefined') return;
    try {
      if (!this.keepAliveCtx) {
        const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
        if (!AudioCtx) return;
        this.keepAliveCtx = new AudioCtx();
      }

      if (this.keepAliveCtx.state === 'suspended') {
        this.keepAliveCtx.resume().catch(() => {});
      }

      if (!this.keepAliveOsc) {
        const osc = this.keepAliveCtx.createOscillator();
        const gain = this.keepAliveCtx.createGain();
        gain.gain.value = 0.00001; // Inaudible
        osc.connect(gain);
        gain.connect(this.keepAliveCtx.destination);
        osc.start();
        this.keepAliveOsc = osc;
        this.keepAliveGain = gain;
        console.log('[SPEECH_INTERNAL] Background AudioContext keep-alive established');
      }
    } catch (e) {
      console.warn('[SPEECH_INTERNAL] KeepAlive notice:', e);
    }
  }

  private stopKeepAlive(): void {
    try {
      if (this.keepAliveOsc) {
        this.keepAliveOsc.stop();
        this.keepAliveOsc.disconnect();
        this.keepAliveOsc = null;
      }
      if (this.keepAliveGain) {
        this.keepAliveGain.disconnect();
        this.keepAliveGain = null;
      }
      if (this.keepAliveCtx && this.keepAliveCtx.state !== 'closed') {
        this.keepAliveCtx.close().catch(() => {});
        this.keepAliveCtx = null;
      }
      console.log('[SPEECH_INTERNAL] Keep-alive terminated');
    } catch {}
  }

  public async enablePersistentListening(
    language: string = 'hi-IN',
    silenceTimeoutMs: number = 1700
  ): Promise<boolean> {
    console.log('[SPEECH_INTERNAL] [FLOW 1] enablePersistentListening() called by user. Turning persistent mode ON.', {
      language,
      silenceTimeoutMs,
      preferMediaRecorderFallback: this.preferMediaRecorderFallback,
    });
    this.isPersistentMode = true;
    this.shouldAutoRestart = true;
    this.isPausedForSpeaking = false;
    this.isWakeActive = false;
    this.targetLanguage = language;
    this.silenceTimeoutMs = silenceTimeoutMs;
    this.restartAttemptCount = 0;
    this.recentRestartTimestamps = [];
    this.isSilentRestartInProgress = false;
    this.consecutiveSttErrors = 0;

    this.ensureKeepAliveRunning();

    const nativeBridge = (window as any).AndroidBridge;
    if (nativeBridge && typeof nativeBridge.pauseWakeWordListening === 'function') {
      try {
        console.log('[SPEECH_INTERNAL] Coordinating mic handover: pausing ZoyaService wake-word before web capture');
        nativeBridge.pauseWakeWordListening();
      } catch (e) {
        console.warn('[SPEECH_INTERNAL] Native pauseWakeWordListening notice:', e);
      }
    }

    const started = await this.startListening(language, silenceTimeoutMs);
    if (started) {
      this.notifyHardwareStateChange('active', this.currentEngine, true, false, undefined, 'Always-on listening active');
      this.listener?.onStandbyListening?.();
    } else {
      this.notifyHardwareStateChange('error', this.currentEngine, false, false, this.lastError || 'Failed to start microphone');
    }
    return started;
  }

  public async disablePersistentListening(): Promise<void> {
    console.log('[SPEECH_INTERNAL] [FLOW 1] disablePersistentListening() called by user. Turning persistent mode OFF.');
    this.isPersistentMode = false;
    this.shouldAutoRestart = false;
    this.isWakeActive = false;
    this.isSilentRestartInProgress = false;
    this.recentRestartTimestamps = [];
    clearTimeout(this.autoRestartTimer);

    const nativeBridge = (window as any).AndroidBridge;
    if (nativeBridge && typeof nativeBridge.stopWakeWordService === 'function') {
      try {
        nativeBridge.stopWakeWordService();
      } catch {}
    }

    this.stopKeepAlive();
    await this.stopListening();
    this.notifyHardwareStateChange('idle', 'none', false, false, undefined, 'Always-on listening disabled');
    this.lastLogMessage = 'Always-On listening disabled';
    this.listener?.onEnd?.();
  }

  public returnToStandby(): void {
    console.log('[SPEECH_INTERNAL] returnToStandby(): Delegating to MicStateMachine');
    this.isWakeActive = false;
    this.lastLogMessage = 'Standby (Hey Zoya wake-word active)...';
    this.listener?.onStandbyListening?.();
    micStateMachine.requestStandby('returnToStandby');
  }

  /**
   * Pauses microphone listening while assistant is processing, generating, or speaking.
   * Completely halts auto-restart loops, silence timers, and hardware capture so Zoya's
   * own voice coming out of the speakers cannot be picked up or interrupt playback.
   */
  public pauseForAssistantSpeaking(): void {
    console.log('[SPEECH_INTERNAL] [STATE_TRANSITION] pauseForAssistantSpeaking(): Muting mic during assistant response');
    this.isPausedForSpeaking = true;
    this.shouldAutoRestart = false;
    this.isDiscardingRecorderStop = true;
    this.pendingFinalTranscript = '';
    this.pendingInterimTranscript = '';
    clearTimeout(this.autoRestartTimer);
    clearTimeout(this.silenceTimer);
    clearTimeout(this.vadSilenceTimer);
    clearTimeout(this.vadMaxTimer);
    clearTimeout(this.vadIdleRecycleTimer);
    this.vadSilenceTimer = null;
    this.vadMaxTimer = null;
    this.vadIdleRecycleTimer = null;

    const nativeBridge = typeof window !== 'undefined' ? (window as any).AndroidBridge : null;
    if (nativeBridge && typeof nativeBridge.pauseWakeWordListening === 'function') {
      try {
        nativeBridge.pauseWakeWordListening();
      } catch {}
    }

    if (this.recognition) {
      try {
        this.recognition.abort();
      } catch {}
    }

    if (this.mediaRecorder) {
      try {
        const mr = this.mediaRecorder;
        this.mediaRecorder = null;
        this.isMediaRecorderActive = false;
        mr.onstart = null;
        mr.ondataavailable = null;
        mr.onerror = null;
        mr.onstop = null;
        if (mr.state === 'recording') mr.stop();
      } catch {}
    }

    if (this.hardwareAudioStream) {
      try {
        this.hardwareAudioStream.getTracks().forEach((t) => t.stop());
      } catch {}
      this.hardwareAudioStream = null;
    }
    this.stopHardwareAudioMonitoring();
    this.stopBargeInMonitor();
    this.isListeningActive = false;
    this.lastLogMessage = 'Muted (Speaking)...';
    this.notifyHardwareStateChange('idle', this.currentEngine, false, false, undefined, 'Muted while Zoya speaks');
  }

  /**
   * Starts an echo-gated microphone RMS monitor while AI is speaking in Web Speech fallback mode.
   * Only triggers barge-in when user voice clearly exceeds the AEC-attenuated speaker bleed threshold,
   * preventing AI's own audio from echoing back into SpeechRecognition.
   */
  public startBargeInMonitor(onBargeIn: () => void): void {
    this.stopBargeInMonitor();
    if (typeof navigator === 'undefined' || !navigator.mediaDevices?.getUserMedia) return;

    this.bargeInStartDelayTimer = setTimeout(async () => {
      this.bargeInStartDelayTimer = null;
      if (!this.isPausedForSpeaking) return;
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          audio: {
            echoCancellation: true,
            noiseSuppression: true,
            autoGainControl: true,
            channelCount: 1,
          },
        });
        if (!this.isPausedForSpeaking) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }
        this.bargeInStream = stream;
        const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
        if (!AudioCtx) return;
        const ctx = new AudioCtx();
        this.bargeInAudioCtx = ctx;
        if (ctx.state === 'suspended') {
          await ctx.resume().catch(() => {});
        }
        const src = ctx.createMediaStreamSource(stream);
        const analyser = ctx.createAnalyser();
        analyser.fftSize = 512;
        src.connect(analyser);

        const timeData = new Float32Array(analyser.fftSize);
        let consecutiveFrames = 0;
        const BARGE_IN_RMS_THRESHOLD = 0.14;

        this.bargeInInterval = setInterval(() => {
          if (!this.isPausedForSpeaking) {
            this.stopBargeInMonitor();
            return;
          }
          analyser.getFloatTimeDomainData(timeData);
          let sumSq = 0;
          for (let i = 0; i < timeData.length; i++) {
            sumSq += timeData[i] * timeData[i];
          }
          const rms = Math.min(1, Math.sqrt(sumSq / timeData.length) * 3.2);
          if (rms >= BARGE_IN_RMS_THRESHOLD) {
            consecutiveFrames++;
            if (consecutiveFrames >= 3) {
              console.log('[SPEECH_INTERNAL] [BARGE_IN] User voice interruption detected during fallback TTS (RMS:', rms.toFixed(3), ')');
              this.stopBargeInMonitor();
              onBargeIn();
            }
          } else {
            consecutiveFrames = 0;
          }
        }, 80);
      } catch (err) {
        console.debug('[SPEECH_INTERNAL] Barge-in monitor unavailable (non-fatal):', err);
      }
    }, 380);
  }

  public stopBargeInMonitor(): void {
    if (this.bargeInStartDelayTimer) {
      clearTimeout(this.bargeInStartDelayTimer);
      this.bargeInStartDelayTimer = null;
    }
    if (this.bargeInInterval) {
      clearInterval(this.bargeInInterval);
      this.bargeInInterval = null;
    }
    if (this.bargeInStream) {
      try {
        this.bargeInStream.getTracks().forEach((t) => t.stop());
      } catch {}
      this.bargeInStream = null;
    }
    if (this.bargeInAudioCtx && this.bargeInAudioCtx.state !== 'closed') {
      try {
        this.bargeInAudioCtx.close().catch(() => {});
      } catch {}
      this.bargeInAudioCtx = null;
    }
  }

  /**
   * Resumes microphone listening ONLY after Zoya's TTS response has finished playing completely.
   */
  public resumeAfterAssistantSpeaking(): void {
    console.log('[SPEECH_INTERNAL] [STATE_TRANSITION] resumeAfterAssistantSpeaking(): Response complete.');
    this.stopBargeInMonitor();
    this.isPausedForSpeaking = false;
    this.isWakeActive = false;
    this.pendingFinalTranscript = '';
    this.pendingInterimTranscript = '';
    clearTimeout(this.autoRestartTimer);
    clearTimeout(this.silenceTimer);

    if (micStateMachine.isHandsFreeContinuous()) {
      this.shouldAutoRestart = true;
      return;
    }

    // Return to STANDBY via MicStateMachine
    micStateMachine.requestStandby('TTS finished');
  }

  /**
   * Schedules restart with anti-flicker silent background behavior
   * and progressive backoff (300ms, then 1s, then 3s) WITHOUT changing the visible UI state.
   */
  private scheduleAutoRestart(): void {
    // Only restart speech recognizer if currently ACTIVATING or CAPTURING
    const smState = micStateMachine.getState();
    if (smState !== 'ACTIVATING' && smState !== 'CAPTURING' && !this.isPersistentMode) {
      return;
    }
    if (this.isPausedForSpeaking) return;
    clearTimeout(this.autoRestartTimer);

    const backoffDelays = [300, 1000, 3000];
    const delay = backoffDelays[Math.min(this.restartAttemptCount, backoffDelays.length - 1)];
    this.restartAttemptCount++;
    this.isSilentRestartInProgress = true;

    console.debug(`[SPEECH_INTERNAL] [SILENT_RESTART] Backoff restart #${this.restartAttemptCount} queued in ${delay}ms (silent, UI steady).`);

    this.autoRestartTimer = setTimeout(async () => {
      const currentSmState = micStateMachine.getState();
      if ((currentSmState !== 'ACTIVATING' && currentSmState !== 'CAPTURING' && !this.isPersistentMode) || this.isPausedForSpeaking) {
        return;
      }
      console.debug(`[SPEECH_INTERNAL] [SILENT_RESTART] Executing backoff restart #${this.restartAttemptCount}...`);
      await this.startListening(this.targetLanguage, this.silenceTimeoutMs);
    }, delay);
  }

  public checkWakePhrase(text: string): { matched: boolean; wakePhrase: string; remainingText: string } {
    const trimmed = text.trim();
    const lower = trimmed.toLowerCase();

    const engMatch = lower.match(WAKE_PHRASE_REGEX);
    if (engMatch) {
      const wake = trimmed.substring(engMatch.index!, engMatch.index! + engMatch[0].length).trim();
      const remaining = trimmed
        .substring(engMatch.index! + engMatch[0].length)
        .replace(/^[,:;\-।.!?\s]+/, '')
        .trim();
      return { matched: true, wakePhrase: wake, remainingText: remaining };
    }

    const hindiMatch = trimmed.match(HINDI_WAKE_REGEX);
    if (hindiMatch) {
      const wake = hindiMatch[0].replace(/[,:;\-।.!?\s]+$/, '').trim();
      const remaining = trimmed
        .substring(hindiMatch.index! + hindiMatch[0].length)
        .replace(/^[,:;\-।.!?\s]+/, '')
        .trim();
      return { matched: true, wakePhrase: wake, remainingText: remaining };
    }

    if (GENERAL_ZOYA_REGEX.test(lower)) {
      return { matched: true, wakePhrase: 'Zoya', remainingText: trimmed };
    }
    const nativeMatch = trimmed.match(GENERAL_HINDI_ZOYA_REGEX);
    if (nativeMatch) {
      return { matched: true, wakePhrase: nativeMatch[0].trim(), remainingText: trimmed };
    }

    return { matched: false, wakePhrase: '', remainingText: '' };
  }

  /**
   * Dispatches a finalized utterance to the listener (`onWakeWordDetected` or `onResult`)
   * with strict single-dispatch deduplication so each voice command is submitted exactly once.
   */
  public dispatchFinalizedText(
    rawText: string,
    confidence?: number,
    alternatives?: string[]
  ): boolean {
    if (this.isPausedForSpeaking) {
      console.log('[SPEECH_INTERNAL] dispatchFinalizedText ignored because assistant is speaking');
      return false;
    }

    const text = (rawText || '').trim();
    if (!text) return false;

    const now = Date.now();
    if (
      this.lastDispatchedText.toLowerCase() === text.toLowerCase() &&
      now - this.lastDispatchedTime < 1800
    ) {
      console.log('[SPEECH_INTERNAL] Deduplicating already-dispatched utterance within 1800ms:', text);
      return false;
    }

    this.lastDispatchedText = text;
    this.lastDispatchedTime = now;

    // Check wake phrase first
    const wakeCheck = this.checkWakePhrase(text);
    if (wakeCheck.matched && (this.isPersistentMode || !this.isWakeActive)) {
      this.isWakeActive = true;
      this.lastLogMessage = `Wake: "${wakeCheck.wakePhrase}" detected!`;
      voiceTelemetry.update('wakeWord', {
        isOk: true,
        stateText: 'DETECTED',
        detail: `Matched "${wakeCheck.wakePhrase}" from "${text}"`,
      });
      console.log(
        '[WAKE_WORD_LOG] Dispatching wake phrase:',
        wakeCheck.wakePhrase,
        'trailing:',
        wakeCheck.remainingText
      );
      this.listener?.onWakeWordDetected?.(wakeCheck.wakePhrase, wakeCheck.remainingText);
      return true;
    }

    this.lastLogMessage = `Result: "${text}"`;
    voiceTelemetry.update('stt', {
      isOk: true,
      stateText: 'WORKING',
      detail: `Transcribed: "${text}"`,
    });
    console.log('[SPEECH_INTERNAL] Dispatching finalized voice command to onResult:', text);
    this.listener?.onResult?.(text, confidence, alternatives);
    return true;
  }

  /**
   * Flushes any pending accumulated final/interim transcript before session end, silence timeout, or teardown.
   * Prevents `onend` -> `scheduleAutoRestart()` -> `safeTeardown()` from canceling `silenceTimer` and stranding text in the input box.
   */
  private flushPendingTranscript(reason: string): boolean {
    clearTimeout(this.silenceTimer);
    this.silenceTimer = null;

    const fullText = (this.pendingFinalTranscript + ' ' + this.pendingInterimTranscript).trim();
    this.pendingFinalTranscript = '';
    this.pendingInterimTranscript = '';
    if (this.onAdvanceConsumedResults) {
      this.onAdvanceConsumedResults();
    }

    if (!fullText || this.isPausedForSpeaking) {
      return false;
    }

    console.log(`[SPEECH_INTERNAL] Flushing pending transcript (reason=${reason}): "${fullText}"`);
    return this.dispatchFinalizedText(fullText);
  }

  public async startListening(
    language: string = 'hi-IN',
    silenceTimeoutMs: number = 1700
  ): Promise<boolean> {
    if (this.isPausedForSpeaking) {
      console.warn('[REC_LIFECYCLE] startListening blocked because assistant is speaking/processing');
      return false;
    }
    try {
      const bridge = (window as any).AndroidBridge;
      if (bridge && typeof bridge.getWakeWordStatusJson === 'function') {
        const status = JSON.parse(bridge.getWakeWordStatusJson());
        if (status?.isServiceRunning && typeof bridge.pauseWakeWordListening === 'function') {
          console.log('[REC_LIFECYCLE] Pausing ZoyaService so JS SpeechRecognizerManager can acquire microphone cleanly');
          bridge.pauseWakeWordListening();
        }
      }
    } catch {
      // Ignore bridge parse errors
    }
    console.log('[REC_LIFECYCLE] Step (a): Trigger event: startListening requested at', new Date().toISOString(), {
      language,
      isStarting: this.isStarting,
      isListeningActive: this.isListeningActive,
      isPersistentMode: this.isPersistentMode,
      isSilentRestart: this.isSilentRestartInProgress,
    });

    // Lifecycle Lock Mutex: If starting, wait for any in-flight startup to complete or yield
    if (this.isStarting) {
      console.warn('[REC_LIFECYCLE] startListening already in progress, waiting for mutex lock...');
      for (let i = 0; i < 6; i++) {
        await new Promise((r) => setTimeout(r, 60));
        if (!this.isStarting) break;
      }
      if (this.isStarting) {
        console.warn('[REC_LIFECYCLE] Resetting stuck isStarting lock flag');
        this.isStarting = false;
      }
    }

    this.isStarting = true;
    this.targetLanguage = language;
    this.silenceTimeoutMs = silenceTimeoutMs;
    this.lastLogMessage = 'Starting speech engine...';

    // Only notify 'starting' if this is a fresh user-initiated start, NOT during silent background restart
    if (!this.isSilentRestartInProgress) {
      this.notifyHardwareStateChange('starting', this.currentEngine, false, false, undefined, 'Connecting microphone...');
    }

    try {
      this.stopBargeInMonitor();
      await this.safeTeardown();

      // If MediaRecorder fallback was explicitly flagged, route to MediaRecorder
      if (this.preferMediaRecorderFallback) {
        console.log('[SPEECH_INTERNAL] preferMediaRecorderFallback active. Launching MediaRecorder + VAD pipeline...');
        return await this.startMediaRecorderFallback();
      }

      const SpeechRec = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

      if (SpeechRec) {
        console.log('[SPEECH_INTERNAL] Web Speech API available (webkitSpeechRecognition). Checking mic permission...');

        // CRITICAL FIX: Ensure mic permission is granted.
        // We do NOT keep an active getUserMedia track alive in Chrome because doing so
        // causes Android Chrome to lock the audio HAL and display:
        // "Speech Recognition and Synthesis from Google cannot record now as Chrome is recording".
        if (this.permissionState !== 'granted') {
          const permResult = await this.requestMicrophonePermission(false);
          if (!permResult.granted) {
            console.warn('[SPEECH_INTERNAL] Mic permission denied/blocked:', permResult.state, permResult.message);
            this.lastError = permResult.message;
            this.lastLogMessage = permResult.message;
            this.notifyHardwareStateChange('error', 'webspeech', false, false, permResult.message);
            this.listener?.onError?.(permResult.message, 9);
            this.isStarting = false;
            return false;
          }
        }

        // Release any lingering hardware stream so Chrome is completely released from recording mode
        if (this.hardwareAudioStream) {
          try {
            this.hardwareAudioStream.getTracks().forEach((t) => t.stop());
          } catch {}
          this.hardwareAudioStream = null;
        }
        this.stopHardwareAudioMonitoring();

        await new Promise((resolve) => setTimeout(resolve, 80));

        const langConfig = getLanguageConfig(language);
        let effectiveSttLang = langConfig.sttSupported ? langConfig.code : langConfig.fallbackVoiceLang;
        // For dual-locale wake detection when in persistent standby with hi-IN, alternate with en-IN every 2nd cycle
        if (this.isPersistentMode && !this.isWakeActive && effectiveSttLang === 'hi-IN') {
          if (this.standbyWakeLocaleCycle % 2 === 1) {
            effectiveSttLang = 'en-IN';
          }
          this.standbyWakeLocaleCycle++;
        }
        console.log(`[SPEECH_INTERNAL] Instantiating SpeechRecognition instance with lang=${effectiveSttLang} (selected=${langConfig.code})...`);
        const recognition = new SpeechRec();
        this.recognition = recognition;
        recognition.lang = effectiveSttLang;
        recognition.continuous = true;
        recognition.interimResults = true;
        recognition.maxAlternatives = 3;

        let consumedResultCount = 0;
        let lastSeenResultLength = 0;
        this.pendingFinalTranscript = '';
        this.pendingInterimTranscript = '';
        this.onAdvanceConsumedResults = () => {
          consumedResultCount = lastSeenResultLength;
        };

        // 1. EVENT: onstart - Speech recognition engine started
        recognition.onstart = () => {
          if (this.isPausedForSpeaking) {
            console.log('[SPEECH_INTERNAL] onstart aborted because assistant is currently speaking');
            try { recognition.abort(); } catch {}
            return;
          }
          console.log('[SPEECH_INTERNAL] [EVENT: onstart] Speech recognition engine initialized at', new Date().toISOString());
          this.networkErrorCount = 0;
          this.isListeningActive = true;
          this.currentEngine = 'webspeech';
          this.isSilentRestartInProgress = false;
          this.lastLogMessage = this.isPersistentMode && !this.isWakeActive
            ? 'Standby listening for "Hello Zoya"...'
            : 'Listening active...';
          voiceTelemetry.update('mic', {
            isOk: true,
            stateText: 'ACTIVE',
            detail: `WebSpeech mic active (${effectiveSttLang})`,
          });
          voiceTelemetry.update('recording', {
            isOk: true,
            stateText: 'RECORDING',
            detail: `WebSpeech capture started (${effectiveSttLang})`,
          });
          this.notifyHardwareStateChange('active', 'webspeech', true, false, undefined, 'Speech recognition engine started');
          this.listener?.onReady?.();
          this.listener?.onListening?.();
        };

        // 2. EVENT: onaudiostart - Hardware microphone actively streaming audio packets
        recognition.onaudiostart = () => {
          if (this.isPausedForSpeaking) return;
          console.log('[SPEECH_INTERNAL] [EVENT: onaudiostart] Audio capture hardware streaming audio packets at', new Date().toISOString());
          this.isAudioHardwareStreaming = true;
          this.isSilentRestartInProgress = false;
          this.notifyHardwareStateChange('active', 'webspeech', true, false, undefined, 'Hardware audio stream streaming');
          this.listener?.onRmsChanged?.(0.12);
        };

        // 3. EVENT: onsoundstart - Sound wave energy detected in stream
        recognition.onsoundstart = () => {
          if (this.isPausedForSpeaking) return;
          console.log('[SPEECH_INTERNAL] [EVENT: onsoundstart] Sound detected in audio stream at', new Date().toISOString());
          this.notifyHardwareStateChange('receiving_audio', 'webspeech', true, true, undefined, 'Sound detected in stream');
          this.listener?.onRmsChanged?.(0.38);
        };

        // 4. EVENT: onspeechstart - Recognizer detects human speech format
        recognition.onspeechstart = () => {
          if (this.isPausedForSpeaking) return;
          console.log('[SPEECH_INTERNAL] [EVENT: onspeechstart] Human speech signal detected at', new Date().toISOString());
          this.notifyHardwareStateChange('receiving_audio', 'webspeech', true, true, undefined, 'Speech detected in stream');
          this.listener?.onRmsChanged?.(0.68);
        };

        // 5. EVENT: onspeechend - Human speech format ended
        recognition.onspeechend = () => {
          if (this.isPausedForSpeaking) return;
          console.log('[SPEECH_INTERNAL] [EVENT: onspeechend] Human speech signal ended at', new Date().toISOString());
          this.notifyHardwareStateChange('active', 'webspeech', true, false, undefined, 'Speech ended');
          this.listener?.onRmsChanged?.(0.08);

          // If transcript is waiting in buffer when speech signal ends, finalize promptly after 350ms
          if ((this.pendingFinalTranscript || this.pendingInterimTranscript) && !this.isPausedForSpeaking) {
            clearTimeout(this.silenceTimer);
            this.silenceTimer = setTimeout(() => {
              this.flushPendingTranscript('onspeechend');
            }, 350);
          }
        };

        // 6. EVENT: onsoundend - Sound wave energy stopped
        recognition.onsoundend = () => {
          if (this.isPausedForSpeaking) return;
          console.log('[SPEECH_INTERNAL] [EVENT: onsoundend] Sound wave energy stopped at', new Date().toISOString());
          this.notifyHardwareStateChange('active', 'webspeech', true, false, undefined, 'Sound stopped');
          this.listener?.onRmsChanged?.(0);
        };

        // 7. EVENT: onaudioend - Audio capture hardware stopped on silence cutoff
        recognition.onaudioend = () => {
          console.log('[SPEECH_INTERNAL] [EVENT: onaudioend] Audio hardware capture ended at', new Date().toISOString());
          this.isAudioHardwareStreaming = false;
          this.listener?.onRmsChanged?.(0);
          // Normal silence cutoff: do NOT flip UI dot to offline during persistent mode!
          if (!this.isPersistentMode && !this.isPausedForSpeaking) {
            this.notifyHardwareStateChange('idle', 'webspeech', false, false, undefined, 'Audio capture ended');
          }
        };

        // 8. EVENT: onresult - Interim and final transcripts
        recognition.onresult = (event: any) => {
          if (this.isPausedForSpeaking) {
            console.log('[SPEECH_INTERNAL] onresult dropped because assistant is speaking');
            return;
          }
          this.listener?.onRmsChanged?.(0.55);

          lastSeenResultLength = event.results.length;
          if (consumedResultCount > event.results.length) {
            consumedResultCount = 0;
          }

          let sessionFinal = '';
          let sessionInterim = '';
          for (let i = consumedResultCount; i < event.results.length; ++i) {
            const item = event.results[i];
            const transcript = (item[0]?.transcript || '').trim();
            if (!transcript) continue;
            if (item.isFinal) {
              sessionFinal += (sessionFinal ? ' ' : '') + transcript;
            } else {
              sessionInterim += (sessionInterim ? ' ' : '') + transcript;
            }
          }

          this.pendingFinalTranscript = sessionFinal.trim();
          this.pendingInterimTranscript = sessionInterim.trim();

          const combined = (this.pendingFinalTranscript + ' ' + this.pendingInterimTranscript).trim();
          console.log('[SPEECH_INTERNAL] [EVENT: onresult]:', {
            combined,
            hasFinal: Boolean(this.pendingFinalTranscript),
            hasInterim: Boolean(this.pendingInterimTranscript),
            isPersistentMode: this.isPersistentMode,
            isWakeActive: this.isWakeActive,
            timestamp: new Date().toISOString(),
          });

          if (!combined) return;

          this.notifyHardwareStateChange('receiving_audio', 'webspeech', true, true, undefined, `Heard: "${combined}"`);
          this.lastLogMessage = `Heard: "${combined}"`;
          this.listener?.onPartialResult?.(combined);

          clearTimeout(this.silenceTimer);
          // When browser has marked the phrase isFinal and no interim words remain, settle in 450ms;
          // while interim words are still streaming, wait for silenceTimeoutMs (950ms) so interim text is never cut off mid-sentence.
          const isUtteranceFinalizedByEngine =
            Boolean(this.pendingFinalTranscript) && !this.pendingInterimTranscript;
          const effectiveSilence = isUtteranceFinalizedByEngine
            ? 450
            : this.isWakeActive
            ? Math.max(1000, this.silenceTimeoutMs)
            : this.silenceTimeoutMs;

          this.silenceTimer = setTimeout(() => {
            this.flushPendingTranscript(isUtteranceFinalizedByEngine ? 'final_settled' : 'silence_timer');
          }, effectiveSilence);
        };

        // 9. EVENT: onerror - Error handling
        recognition.onerror = (event: any) => {
          if (this.isPausedForSpeaking) {
            console.log('[SPEECH_INTERNAL] onerror dropped because assistant is speaking');
            return;
          }
          const error = event.error;
          const msg = event.message || '';
          console.info('[SPEECH_INTERNAL] [EVENT: onerror]:', { error, message: msg, timestamp: new Date().toISOString() });

          // Normal silence timeout: no speech detected is standard browser behavior
          if (error === 'no-speech' || error === 'aborted') {
            return;
          }

          // Handle audio-capture: immediate fallback to MediaRecorder
          if (error === 'audio-capture') {
            console.warn(`[SPEECH_INTERNAL] Web Speech 'audio-capture' error intercepted. Switching cleanly to MediaRecorder fallback...`);
            this.preferMediaRecorderFallback = true;
            this.safeTeardown().then(() => {
              this.startMediaRecorderFallback();
            });
            return;
          }

          // Handle network error (Google Speech Services socket disconnect)
          if (error === 'network') {
            this.networkErrorCount = (this.networkErrorCount || 0) + 1;
            console.warn(`[SPEECH_INTERNAL] Web Speech 'network' error intercepted (count: ${this.networkErrorCount}). Timestamp:`, new Date().toISOString());

            if (this.networkErrorCount >= 2) {
              console.warn('[SPEECH_INTERNAL] Repeated Web Speech network error. Switching cleanly to MediaRecorder fallback...');
              this.preferMediaRecorderFallback = true;
              this.safeTeardown().then(() => {
                this.startMediaRecorderFallback();
              });
              return;
            }

            // Single transient network disconnect: quietly tear down and reconnect after 500ms backoff
            this.isListeningActive = false;
            this.safeTeardown().then(() => {
              setTimeout(() => {
                if (!this.isPausedForSpeaking && (this.isPersistentMode || this.shouldAutoRestart)) {
                  console.log('[SPEECH_INTERNAL] Re-establishing Web Speech recognition after network hiccup...');
                  this.startListening(this.targetLanguage, this.silenceTimeoutMs);
                }
              }, 500);
            });
            return;
          }

          if (error === 'not-allowed') {
            const inIframe = this.isInsideIframe();
            const policyCheck = this.checkIframePermissionPolicy();
            const isIframeBlock = inIframe && (!policyCheck.isAllowed || msg.toLowerCase().includes('permissions policy'));

            this.permissionState = isIframeBlock ? 'iframe_blocked' : 'denied_by_user';
            const detail = 'माइक की अनुमति नहीं मिली। ब्राउज़र में Allow करो या ऐप को नए टैब में खोलो।';
            console.warn('[SPEECH_INTERNAL] Web Speech permission error:', error, msg);
            this.lastError = detail;
            this.lastLogMessage = `Error: ${error}`;
            this.notifyHardwareStateChange('error', 'webspeech', false, false, detail);
            this.listener?.onError?.(detail, 9);
            this.isPersistentMode = false;
          } else if (error === 'service-not-allowed') {
            console.warn('[SPEECH_INTERNAL] Web Speech service-not-allowed; pivoting to MediaRecorder fallback:', msg);
            this.preferMediaRecorderFallback = true;
            this.safeTeardown().then(() => {
              this.startMediaRecorderFallback();
            });
          } else {
            const detail = `माइक्रोफ़ोन त्रुटि (${error}): ${msg || 'कृपया पुनः प्रयास करें'}`;
            console.warn('[SPEECH_INTERNAL] Web Speech recognition error:', error, msg);
            this.lastError = detail;
            this.lastLogMessage = `Error: ${error}`;
            this.notifyHardwareStateChange('error', 'webspeech', false, false, detail);
            this.listener?.onError?.(detail, 1);
          }
        };

        // 10. EVENT: onend - Recognition session ended (Normal silence cutoff)
        recognition.onend = () => {
          console.log('[SPEECH_INTERNAL] [EVENT: onend] Recognition stream ended at', new Date().toISOString(), {
            isPersistentMode: this.isPersistentMode,
            isTearingDown: this.isTearingDown,
            shouldAutoRestart: this.shouldAutoRestart,
            isPausedForSpeaking: this.isPausedForSpeaking,
          });
          this.isListeningActive = false;
          this.isAudioHardwareStreaming = false;

          // CRITICAL FIX: Flush any pending recognized speech BEFORE auto-restart or teardown!
          if (!this.isPausedForSpeaking) {
            this.flushPendingTranscript('recognition_onend');
          }

          if (this.isTearingDown || this.isPausedForSpeaking) {
            return;
          }

          if (this.isPersistentMode && this.shouldAutoRestart) {
            // Invisible silent background restart: UI remains steady active!
            this.scheduleAutoRestart();
          } else {
            this.lastLogMessage = 'Idle';
            this.notifyHardwareStateChange('idle', 'webspeech', false, false, undefined, 'Session ended');
            this.listener?.onEnd?.();
          }
        };

        console.log('[REC_LIFECYCLE] Step (d): Speech engine starting: webspeech at', new Date().toISOString());
        try {
          recognition.start();
          this.isStarting = false;
          console.log('[REC_LIFECYCLE] Step (e): Active WebSpeech recording confirmed at', new Date().toISOString());
          return true;
        } catch (startErr: any) {
          const errMsg = String(startErr?.message || startErr);
          console.warn('[REC_LIFECYCLE] recognition.start() threw exception:', errMsg);
          
          // Auto-recovery: If InvalidStateError or already started, back off 220ms, recreate instance and retry
          if (errMsg.includes('already started') || errMsg.includes('InvalidStateError')) {
            console.log('[REC_LIFECYCLE] InvalidStateError race detected. Applying 220ms backoff and retrying fresh session...');
            await new Promise((res) => setTimeout(res, 220));
            try {
              const freshRec = new SpeechRec();
              this.recognition = freshRec;
              freshRec.lang = effectiveSttLang;
              freshRec.continuous = true;
              freshRec.interimResults = true;
              freshRec.maxAlternatives = 3;
              freshRec.onstart = recognition.onstart;
              freshRec.onaudiostart = recognition.onaudiostart;
              freshRec.onsoundstart = recognition.onsoundstart;
              freshRec.onspeechstart = recognition.onspeechstart;
              freshRec.onspeechend = recognition.onspeechend;
              freshRec.onsoundend = recognition.onsoundend;
              freshRec.onaudioend = recognition.onaudioend;
              freshRec.onresult = recognition.onresult;
              freshRec.onerror = recognition.onerror;
              freshRec.onend = recognition.onend;
              freshRec.start();
              this.isStarting = false;
              console.log('[REC_LIFECYCLE] Step (e): Auto-retry succeeded! Active recording confirmed at', new Date().toISOString());
              return true;
            } catch (retryErr: any) {
              console.warn('[REC_LIFECYCLE] Step (f): WebSpeech retry also threw, pivoting to MediaRecorder fallback:', retryErr);
              this.preferMediaRecorderFallback = true;
              return await this.startMediaRecorderFallback();
            }
          }

          console.warn('[REC_LIFECYCLE] Non-state error on WebSpeech, routing to MediaRecorder fallback...');
          this.preferMediaRecorderFallback = true;
          return await this.startMediaRecorderFallback();
        }
      }

      console.log('[REC_LIFECYCLE] Web Speech API missing. Using MediaRecorder fallback...');
      return await this.startMediaRecorderFallback();

    } catch (err: any) {
      console.info('[SPEECH_INTERNAL] Notice in startListening:', err);
      this.isStarting = false;
      const exMsg = `माइक्रोफ़ोन त्रुटि: ${err?.message || err}`;
      this.lastError = exMsg;
      this.notifyHardwareStateChange('idle', 'none', false, false, undefined, exMsg);
      this.listener?.onError?.(exMsg, 1);
      return false;
    }
  }

  private async startMediaRecorderFallback(): Promise<boolean> {
    try {
      console.log('[LOVE_VOICE_CHAIN] [1. RECORD_INIT] Initializing MediaRecorder + 1.7s RMS silence detection...');
      this.isDiscardingRecorderStop = false;
      this.isSilentRecycle = false;
      this.hasSpokenInCurrentChunk = false;
      this.speechFrameCount = 0;
      this.chunkPeakRms = 0;
      this.chunkSpeechFrames = 0;

      if (typeof navigator === 'undefined' || !navigator.mediaDevices?.getUserMedia) {
        const msg = 'माइक की अनुमति नहीं मिली। ब्राउज़र में Allow करो या ऐप को नए टैब में खोलो।';
        console.warn('[GLOBAL_VOICE_CHAIN] [RECORD_ERROR] getUserMedia unavailable');
        this.isStarting = false;
        this.permissionState = 'denied_by_user';
        this.lastError = msg;
        this.notifyHardwareStateChange('error', 'mediarecorder', false, false, msg);
        this.listener?.onError?.(msg, 9);
        return false;
      }

      const inIframe = this.isInsideIframe();
      const policyCheck = this.checkIframePermissionPolicy();
      if (!policyCheck.isAllowed && inIframe) {
        const msg = 'माइक की अनुमति नहीं मिली। ब्राउज़र में Allow करो या ऐप को नए टैब में खोलो।';
        console.warn('[GLOBAL_VOICE_CHAIN] [RECORD_ERROR] iframe permission policy blocked mic');
        this.isStarting = false;
        this.permissionState = 'iframe_blocked';
        this.lastError = msg;
        this.notifyHardwareStateChange('error', 'mediarecorder', false, false, msg);
        this.listener?.onError?.(msg, 9);
        return false;
      }

      let stream = this.hardwareAudioStream;
      if (!stream || !stream.active) {
        console.log('[SPEECH_INTERNAL] [MediaRecorder] Requesting active getUserMedia stream...');
        try {
          stream = await navigator.mediaDevices.getUserMedia({
            audio: {
              echoCancellation: true,
              noiseSuppression: true,
              autoGainControl: true,
              channelCount: 1,
            },
          });
        } catch (permErr: any) {
          const errName = String(permErr?.name || 'Error');
          const errMsg = String(permErr?.message || permErr || '');
          const detail = 'माइक की अनुमति नहीं मिली। ब्राउज़र में Allow करो या ऐप को नए टैब में खोलो।';
          this.permissionState =
            inIframe && (errName === 'SecurityError' || errMsg.toLowerCase().includes('permissions policy') || !policyCheck.isAllowed)
              ? 'iframe_blocked'
              : 'denied_by_user';
          micStateMachine.reportMicPermission(false);
          console.warn('[GLOBAL_VOICE_CHAIN] [RECORD_ERROR] getUserMedia failed:', errName, errMsg);
          this.isStarting = false;
          this.lastError = detail;
          this.notifyHardwareStateChange('error', 'mediarecorder', false, false, detail);
          this.listener?.onError?.(detail, 9);
          return false;
        }
        this.hardwareAudioStream = stream;
      }
      this.permissionState = 'granted';
      micStateMachine.reportMicPermission(true);
      this.currentEngine = 'mediarecorder';

      this.startHardwareAudioMonitoring(stream);

      let mimeType = 'audio/webm';
      if (typeof MediaRecorder !== 'undefined' && typeof MediaRecorder.isTypeSupported === 'function') {
        if (MediaRecorder.isTypeSupported('audio/webm;codecs=opus')) {
          mimeType = 'audio/webm;codecs=opus';
        } else if (MediaRecorder.isTypeSupported('audio/webm')) {
          mimeType = 'audio/webm';
        } else if (MediaRecorder.isTypeSupported('audio/mp4')) {
          mimeType = 'audio/mp4';
        } else if (MediaRecorder.isTypeSupported('audio/ogg')) {
          mimeType = 'audio/ogg';
        }
      }

      const recorder = new MediaRecorder(stream, { mimeType });
      this.mediaRecorder = recorder;
      this.audioChunks = [];
      this.hasSpokenInCurrentChunk = false;

      recorder.ondataavailable = (e) => {
        if (e.data && e.data.size > 0) {
          this.audioChunks.push(e.data);
        }
      };

      recorder.onstart = () => {
        if (this.isPausedForSpeaking) {
          this.isDiscardingRecorderStop = true;
          try { recorder.stop(); } catch {}
          return;
        }
        console.log('[LOVE_VOICE_CHAIN] [1. RECORD_LISTENING] Mic listening continuously (waiting for speech)...');
        this.isListeningActive = true;
        this.isMediaRecorderActive = true;
        this.isSilentRestartInProgress = false;
        this.lastLogMessage = 'सुन रहा है...';
        voiceTelemetry.update('mic', {
          isOk: true,
          stateText: 'ACTIVE',
          detail: 'MediaRecorder mic stream active',
        });
        voiceTelemetry.update('recording', {
          isOk: true,
          stateText: 'RECORDING',
          detail: `Capturing real audio (${mimeType})`,
        });
        this.notifyHardwareStateChange('active', 'mediarecorder', true, false, undefined, 'सुन रहा है');
        this.listener?.onReady?.();
        this.listener?.onListening?.();

        // While completely silent, recycle buffer silently every 10s so zero network STT calls fire during silence
        if (this.vadIdleRecycleTimer) clearTimeout(this.vadIdleRecycleTimer);
        this.vadIdleRecycleTimer = setTimeout(() => {
          if (
            this.mediaRecorder &&
            this.mediaRecorder.state === 'recording' &&
            !this.hasSpokenInCurrentChunk &&
            !this.isPausedForSpeaking
          ) {
            this.isSilentRecycle = true;
            try {
              this.mediaRecorder.stop();
            } catch {}
          }
        }, 10000);
      };

      recorder.onerror = (recErr: any) => {
        const msg = recErr?.error?.message || recErr?.message || 'माइक रिकॉर्डिंग त्रुटि';
        console.error('[LOVE_VOICE_CHAIN] [RECORD_ERROR] MediaRecorder error:', recErr);
        this.notifyHardwareStateChange('error', 'mediarecorder', false, false, msg);
        this.listener?.onError?.(msg, 1);
      };

      recorder.onstop = async () => {
        this.isListeningActive = false;
        this.isMediaRecorderActive = false;
        clearTimeout(this.vadMaxTimer);
        clearTimeout(this.vadSilenceTimer);
        clearTimeout(this.vadIdleRecycleTimer);
        this.vadMaxTimer = null;
        this.vadSilenceTimer = null;
        this.vadIdleRecycleTimer = null;

        const chunks = [...this.audioChunks];
        const hadSpeech = this.hasSpokenInCurrentChunk;
        const peakRms = this.chunkPeakRms;
        const speechFrames = this.chunkSpeechFrames;
        const discarding = this.isDiscardingRecorderStop || this.isPausedForSpeaking || this.isTearingDown;
        const silentRecycle = this.isSilentRecycle;
        this.audioChunks = [];
        this.hasSpokenInCurrentChunk = false;
        this.chunkPeakRms = 0;
        this.chunkSpeechFrames = 0;
        this.isDiscardingRecorderStop = false;
        this.isSilentRecycle = false;

        if (discarding) {
          console.log('[LOVE_VOICE_CHAIN] Discarded paused/teardown recording buffer');
          return;
        }

        // Pure silence recycle -> silently restart recorder without hitting STT API or UI flicker
        if (silentRecycle && !hadSpeech) {
          if (this.isPersistentMode && this.shouldAutoRestart && !this.isPausedForSpeaking) {
            await this.startMediaRecorderFallback();
          }
          return;
        }

        const blob = new Blob(chunks, { type: mimeType });
        const passedRmsGate = peakRms >= 0.015 && speechFrames >= 2;

        if (hadSpeech && blob.size > 500 && passedRmsGate) {
          console.log(
            `[LOVE_VOICE_CHAIN] [2. STT_START] Captured ${blob.size} bytes (${mimeType}, peakRms=${peakRms.toFixed(4)}, frames=${speechFrames}), transcribing via /api/transcribe...`
          );
          this.lastLogMessage = 'Speech-to-Text रूपांतरण हो रहा है...';

          try {
            const sttResult = await this.transcribeRecordedBlob(blob);
            if (sttResult.error) {
              this.consecutiveSttErrors++;
              console.warn('[LOVE_VOICE_CHAIN] [2. STT_NOTICE]', sttResult.error);
              this.lastError = sttResult.error;
              voiceTelemetry.update('stt', {
                isOk: false,
                health: 'fail',
                stateText: 'FAILED',
                detail: sttResult.error,
                error: sttResult.error,
              });
              this.listener?.onSttError?.(sttResult.error);
            } else if (sttResult.transcript) {
              this.consecutiveSttErrors = 0;
              console.log('[LOVE_VOICE_CHAIN] [2. STT_DONE] Transcribed text:', sttResult.transcript);
              this.lastLogMessage = `Heard: "${sttResult.transcript}"`;
              voiceTelemetry.update('stt', {
                isOk: true,
                stateText: 'WORKING',
                detail: `Transcribed "${sttResult.transcript}"`,
              });
              this.listener?.onPartialResult?.(sttResult.transcript);
              this.dispatchFinalizedText(sttResult.transcript);
              return; // handleProcessUserQuery -> AI -> TTS -> handlePlaybackEnd will auto-resume mic after speaking!
            } else {
              console.log('[LOVE_VOICE_CHAIN] [2. STT_EMPTY] No clear spoken words detected in recorded audio; resuming listening...');
            }
          } catch (transcribeErr: any) {
            console.warn('[LOVE_VOICE_CHAIN] [2. STT_EXCEPTION]', transcribeErr);
            const errText = transcribeErr?.message || 'Speech-to-Text त्रुटि';
            voiceTelemetry.update('stt', {
              isOk: false,
              health: 'fail',
              stateText: 'FAILED',
              detail: errText,
              error: errText,
            });
            this.listener?.onSttError?.(errText);
          }
        } else if (hadSpeech) {
          console.log(
            `[LOVE_VOICE_CHAIN] [2. STT_SILENCE_GATED] Skipped /api/transcribe upload (size=${blob.size}, peakRms=${peakRms.toFixed(4)}, frames=${speechFrames})`
          );
        }

        // No speech text dispatched -> auto-resume listening cleanly
        if (this.isPersistentMode && this.shouldAutoRestart && !this.isPausedForSpeaking) {
          this.scheduleAutoRestart();
        } else if (!this.isPersistentMode && !this.isPausedForSpeaking) {
          this.notifyHardwareStateChange('idle', 'mediarecorder', false, false);
          this.listener?.onEnd?.();
        }
      };

      recorder.start(250);
      this.isStarting = false;
      return true;
    } catch (recErr: any) {
      console.error('[LOVE_VOICE_CHAIN] [RECORD_ERROR] startMediaRecorderFallback failed:', recErr);
      this.isStarting = false;
      this.lastError = 'माइक रिकॉर्डिंग प्रारंभ नहीं हो सकी';
      this.notifyHardwareStateChange('error', 'mediarecorder', false, false, this.lastError);
      this.listener?.onError?.('माइक रिकॉर्डिंग प्रारंभ नहीं हो सकी', 1);
      return false;
    }
  }

  private async transcribeRecordedBlob(blob: Blob): Promise<{ transcript: string; error?: string; quotaExceeded?: boolean }> {
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onloadend = async () => {
        try {
          const resultStr = String(reader.result || '');
          const base64Data = resultStr.includes(',') ? resultStr.split(',')[1] : '';
          if (!base64Data) {
            resolve({ transcript: '', error: 'ऑडियो डेटा खाली है (Audio encoding failed)' });
            return;
          }
          let geminiApiKey = '';
          try {
            geminiApiKey = getDecryptedSecretSync('zoya_gemini_api_key') || '';
          } catch {}

          // Client timeout (22s) exceeds server worst-case 3-model cascade (3 * 6s = 18s)
          const sttController = new AbortController();
          const sttTimeout = setTimeout(() => sttController.abort(), 22000);
          let res: Response;
          try {
            res = await fetch('/api/transcribe', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              signal: sttController.signal,
              body: JSON.stringify({
                audioData: base64Data,
                mimeType: blob.type || 'audio/webm',
                language: this.targetLanguage,
                geminiApiKey: geminiApiKey || undefined,
              }),
            });
          } finally {
            clearTimeout(sttTimeout);
          }

          if (!res.ok) {
            const errRaw = await res.text().catch(() => '');
            const msg = `/api/transcribe HTTP ${res.status}: ${errRaw.slice(0, 160)}`;
            resolve({ transcript: '', error: msg });
            return;
          }

          const data = await res.json();
          const text = (data?.transcript || '').trim();
          if (data?.source === 'error' || (!text && data?.error)) {
            resolve({
              transcript: '',
              error: String(data?.error || 'Speech-to-Text सर्वर त्रुटि'),
              quotaExceeded: Boolean(data?.quotaExceeded),
            });
            return;
          }
          resolve({ transcript: text, quotaExceeded: Boolean(data?.quotaExceeded) });
        } catch (err: any) {
          const msg =
            err?.name === 'AbortError'
              ? 'Speech-to-Text अनुरोध टाइमआउट (22s) हो गया'
              : `Speech-to-Text नेटवर्क त्रुटि: ${err?.message || err}`;
          resolve({ transcript: '', error: msg });
        }
      };
      reader.onerror = () => resolve({ transcript: '', error: 'रिकॉर्डेड ऑडियो पढ़ने में त्रुटि हुई' });
      reader.readAsDataURL(blob);
    });
  }

  public async sendAudioForTranscription(blob: Blob): Promise<string> {
    const res = await this.transcribeRecordedBlob(blob);
    if (res.error) {
      console.error('[LOVE_VOICE_CHAIN] [STT_ERROR]', res.error);
    }
    return res.transcript;
  }

  /**
   * Real Hardware 3-Second Audio Capture & STT Pipeline Test (zero mocked transcripts).
   */
  public async runLiveListeningTest3Seconds(
    _unusedPrompt?: string
  ): Promise<{ success: boolean; interimText: string; finalText: string; error?: string; peakRms?: number }> {
    console.log('[SPEECH_INTERNAL] [TEST] STARTING REAL 3-SECOND MICROPHONE + STT CAPTURE TEST');

    if (typeof navigator === 'undefined' || !navigator.mediaDevices?.getUserMedia || typeof MediaRecorder === 'undefined') {
      const msg = 'getUserMedia or MediaRecorder not supported in this browser';
      voiceTelemetry.update('mic', { isOk: false, health: 'fail', stateText: 'INACTIVE', detail: msg, error: msg });
      return { success: false, interimText: '', finalText: '', error: msg };
    }

    let testStream: MediaStream | null = null;
    let testCtx: AudioContext | null = null;
    let rmsInterval: any = null;
    let peakRms = 0;

    try {
      testStream = await navigator.mediaDevices.getUserMedia({
        audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true, channelCount: 1 },
      });
      voiceTelemetry.update('mic', { isOk: true, stateText: 'ACTIVE', detail: '3s test mic stream acquired' });

      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioCtx) {
        testCtx = new AudioCtx();
        if (testCtx.state === 'suspended') {
          await testCtx.resume().catch(() => {});
        }
        const src = testCtx.createMediaStreamSource(testStream);
        const analyser = testCtx.createAnalyser();
        analyser.fftSize = 512;
        src.connect(analyser);
        const data = new Float32Array(analyser.fftSize);
        rmsInterval = setInterval(() => {
          analyser.getFloatTimeDomainData(data);
          let sumSq = 0;
          for (let i = 0; i < data.length; i++) sumSq += data[i] * data[i];
          const rms = Math.sqrt(sumSq / data.length);
          if (rms > peakRms) peakRms = rms;
          this.listener?.onRmsChanged?.(Math.min(1, rms * 5));
        }, 60);
      }

      const mimeType = MediaRecorder.isTypeSupported('audio/webm;codecs=opus')
        ? 'audio/webm;codecs=opus'
        : MediaRecorder.isTypeSupported('audio/webm')
        ? 'audio/webm'
        : '';
      const recorder = mimeType ? new MediaRecorder(testStream, { mimeType }) : new MediaRecorder(testStream);
      const chunks: Blob[] = [];
      recorder.ondataavailable = (ev) => {
        if (ev.data && ev.data.size > 0) chunks.push(ev.data);
      };

      const blobPromise = new Promise<Blob>((resolve) => {
        recorder.onstop = () => {
          resolve(new Blob(chunks, { type: recorder.mimeType || 'audio/webm' }));
        };
      });

      this.notifyHardwareStateChange('active', 'mediarecorder', true, false, undefined, 'Recording 3s real audio sample...');
      voiceTelemetry.update('recording', { isOk: true, stateText: 'RECORDING', detail: '3s diagnostic capture running' });
      recorder.start(250);
      await new Promise((r) => setTimeout(r, 3000));
      if (recorder.state === 'recording') recorder.stop();
      const audioBlob = await blobPromise;

      if (rmsInterval) clearInterval(rmsInterval);
      testStream.getTracks().forEach((t) => {
        try { t.stop(); } catch {}
      });
      if (testCtx && testCtx.state !== 'closed') {
        await testCtx.close().catch(() => {});
      }
      this.listener?.onRmsChanged?.(0);

      if (audioBlob.size < 400 || peakRms < 0.002) {
        const msg = `No audible microphone signal detected (bytes=${audioBlob.size}, peakRms=${peakRms.toFixed(4)})`;
        voiceTelemetry.update('recording', { isOk: false, health: 'fail', stateText: 'NOT RECORDING', detail: msg, error: msg });
        return { success: false, interimText: '', finalText: '', error: msg, peakRms };
      }

      const sttRes = await this.transcribeRecordedBlob(audioBlob);
      if (sttRes.error) {
        voiceTelemetry.update('stt', { isOk: false, health: 'fail', stateText: 'FAILED', detail: sttRes.error, error: sttRes.error });
        return { success: false, interimText: '', finalText: '', error: sttRes.error, peakRms };
      }

      const transcript = (sttRes.transcript || '').trim();
      if (!transcript) {
        const msg = `Captured ${audioBlob.size} bytes (peakRms=${peakRms.toFixed(4)}), but STT detected silence/no words`;
        voiceTelemetry.update('stt', { isOk: false, health: 'fail', stateText: 'FAILED', detail: msg, error: msg });
        return { success: false, interimText: '', finalText: '', error: msg, peakRms };
      }

      voiceTelemetry.update('stt', { isOk: true, stateText: 'WORKING', detail: `3s test transcribed: "${transcript}"` });
      this.notifyHardwareStateChange('active', 'mediarecorder', true, false, undefined, `Verified: "${transcript}"`);
      return {
        success: true,
        interimText: transcript,
        finalText: transcript,
        peakRms,
      };
    } catch (err: any) {
      if (rmsInterval) clearInterval(rmsInterval);
      if (testStream) {
        testStream.getTracks().forEach((t) => { try { t.stop(); } catch {} });
      }
      if (testCtx && testCtx.state !== 'closed') {
        testCtx.close().catch(() => {});
      }
      const errMsg = err?.message || String(err);
      voiceTelemetry.update('mic', { isOk: false, health: 'fail', stateText: 'INACTIVE', detail: errMsg, error: errMsg });
      return { success: false, interimText: '', finalText: '', error: errMsg, peakRms };
    }
  }

  /**
   * Tests the live audio pipeline end-to-end with real hardware mic + /api/transcribe
   */
  public async testLiveAudioPipeline(): Promise<{ success: boolean; transcript: string; error?: string }> {
    const res = await this.runLiveListeningTest3Seconds();
    return {
      success: res.success,
      transcript: res.finalText,
      error: res.error,
    };
  }

  public simulateWakeWord(phrase: string = 'Hello Zoya'): void {
    console.log('[SPEECH_INTERNAL] simulateWakeWord triggered with:', phrase);
    this.isWakeActive = true;
    this.listener?.onWakeWordDetected?.(phrase, '');
  }

  public simulateSpokenPhrase(phrase: string): void {
    console.log('[SPEECH_INTERNAL] simulateSpokenPhrase triggered with:', phrase);
    this.notifyHardwareStateChange('receiving_audio', this.currentEngine, true, true);
    this.listener?.onReady?.();
    this.listener?.onListening?.();
    this.listener?.onPartialResult?.(phrase);
    this.lastLogMessage = `Spoken: "${phrase}"`;
    setTimeout(() => {
      this.listener?.onResult?.(phrase);
      this.notifyHardwareStateChange('active', this.currentEngine, true, false);
    }, 450);
  }

  private async safeTeardown(): Promise<void> {
    if (!this.isPausedForSpeaking) {
      this.flushPendingTranscript('safe_teardown');
    }
    this.isTearingDown = true;
    this.isDiscardingRecorderStop = true;
    clearTimeout(this.silenceTimer);
    clearTimeout(this.vadSilenceTimer);
    clearTimeout(this.vadMaxTimer);
    clearTimeout(this.vadIdleRecycleTimer);
    this.vadSilenceTimer = null;
    this.vadMaxTimer = null;
    this.vadIdleRecycleTimer = null;

    if (this.hardwareAudioStream) {
      try {
        this.hardwareAudioStream.getTracks().forEach((t) => t.stop());
      } catch {}
      this.hardwareAudioStream = null;
    }
    this.stopHardwareAudioMonitoring();

    if (this.recognition) {
      const r = this.recognition;
      this.recognition = null;
      console.debug('[SPEECH_INTERNAL] Tearing down previous SpeechRecognition instance safely...');

      await new Promise<void>((resolve) => {
        let finished = false;
        const cleanup = () => {
          if (!finished) {
            finished = true;
            resolve();
          }
        };

        r.onend = cleanup;
        r.onerror = cleanup;
        try {
          r.abort();
        } catch {
          cleanup();
        }
        setTimeout(cleanup, 180);
      });
    }

    if (this.mediaRecorder) {
      try {
        const mr = this.mediaRecorder;
        this.mediaRecorder = null;
        this.isMediaRecorderActive = false;
        mr.onstart = null;
        mr.ondataavailable = null;
        mr.onerror = null;
        mr.onstop = null;
        if (mr.state === 'recording') mr.stop();
      } catch {}
    }

    await new Promise((res) => setTimeout(res, 80));
    this.isTearingDown = false;
    this.isDiscardingRecorderStop = false;
  }

  public async stopListening(): Promise<void> {
    if (this.isStopping) return;
    this.isStopping = true;
    this.isDiscardingRecorderStop = true;
    console.log('[SPEECH_INTERNAL] stopListening() called at', new Date().toISOString());
    if (!this.isPausedForSpeaking) {
      this.flushPendingTranscript('stop_listening');
    }
    clearTimeout(this.silenceTimer);
    clearTimeout(this.vadSilenceTimer);
    clearTimeout(this.vadMaxTimer);
    clearTimeout(this.vadIdleRecycleTimer);
    this.vadSilenceTimer = null;
    this.vadMaxTimer = null;
    this.vadIdleRecycleTimer = null;

    const nativeBridge = (window as any).AndroidBridge;
    if (nativeBridge && typeof nativeBridge.resumeWakeWordListening === 'function' && !this.isPausedForSpeaking && !this.isPersistentMode) {
      try {
        nativeBridge.resumeWakeWordListening();
      } catch {}
    }

    if (this.recognition) {
      try {
        this.recognition.stop();
      } catch {}
    }

    if (this.mediaRecorder) {
      try {
        const mr = this.mediaRecorder;
        this.mediaRecorder = null;
        this.isMediaRecorderActive = false;
        mr.onstart = null;
        mr.ondataavailable = null;
        mr.onerror = null;
        mr.onstop = null;
        if (mr.state === 'recording') mr.stop();
      } catch {}
    }

    if (this.hardwareAudioStream) {
      try {
        this.hardwareAudioStream.getTracks().forEach((t) => t.stop());
      } catch {}
      this.hardwareAudioStream = null;
    }
    this.stopHardwareAudioMonitoring();

    this.notifyHardwareStateChange('idle', 'none', false, false, undefined, 'Stopped listening');
    this.isStopping = false;
  }

  public async cancel(): Promise<void> {
    console.log('[SPEECH_INTERNAL] cancel() called at', new Date().toISOString());
    this.shouldAutoRestart = false;
    this.isSilentRestartInProgress = false;
    this.isDiscardingRecorderStop = true;
    this.recentRestartTimestamps = [];
    clearTimeout(this.silenceTimer);
    clearTimeout(this.autoRestartTimer);
    clearTimeout(this.vadSilenceTimer);
    clearTimeout(this.vadMaxTimer);
    clearTimeout(this.vadIdleRecycleTimer);
    this.vadSilenceTimer = null;
    this.vadMaxTimer = null;
    this.vadIdleRecycleTimer = null;

    if (this.recognition) {
      try {
        this.recognition.abort();
      } catch {}
    }

    if (this.mediaRecorder) {
      try {
        const mr = this.mediaRecorder;
        this.mediaRecorder = null;
        this.isMediaRecorderActive = false;
        mr.onstart = null;
        mr.ondataavailable = null;
        mr.onerror = null;
        mr.onstop = null;
        if (mr.state === 'recording') mr.stop();
      } catch {}
    }

    this.stopHardwareAudioMonitoring();
    if (this.hardwareAudioStream) {
      this.hardwareAudioStream.getTracks().forEach((t) => t.stop());
      this.hardwareAudioStream = null;
    }

    this.notifyHardwareStateChange('idle', 'none', false, false, undefined, 'Cancelled');
  }

  public destroy(): void {
    this.stopBargeInMonitor();
    this.disablePersistentListening();
    this.stopHardwareAudioMonitoring();
    this.recognition = null;
    this.mediaRecorder = null;
  }
}

export const speechManager = new SpeechRecognizerManager();
