/**
 * Zoya AI — Unified Intent Scoring & Disambiguation Skill Router
 * 
 * Prevents regex collisions and waterfall shadowing between overlapping skills
 * (e.g., 'skill-share' vs 'mcp-builder', 'connect-apps' vs 'skill-share', etc.).
 * 
 * Rules:
 * 1. Explicit skill ID / slash command match gets the highest priority score (+100).
 * 2. Primary action verbs ('share', 'broadcast', 'publish' to Slack) take precedence
 *    over topic mentions (e.g. sharing an 'mcp-builder' skill routes to 'skill-share',
 *    while 'build an mcp server' routes to 'mcp-builder').
 * 3. All 26 skills are scored independently to determine the highest-confidence match.
 */

export type CanonicalSkillId =
  // Part 1 (6)
  | 'artifacts-builder'
  | 'brand-guidelines'
  | 'canvas-design'
  | 'changelog-generator'
  | 'competitive-ads-extractor'
  | 'connect-apps'
  // Part 2 & 4 (9)
  | 'content-research-writer'
  | 'domain-name-brainstormer'
  | 'internal-comms'
  | 'invoice-organizer'
  | 'file-organizer'
  | 'image-enhancer'
  | 'langsmith-fetch'
  | 'developer-growth-analysis'
  | 'document-skills/docx'
  // Part 5 & 6 (8)
  | 'lead-research-assistant'
  | 'mcp-builder'
  | 'meeting-insights-analyzer'
  | 'raffle-winner-picker'
  | 'skill-creator'
  | 'skill-share'
  | 'slack-gif-creator'
  | 'tailored-resume-generator'
  // Part 7 (2)
  | 'theme-factory'
  | 'twitter-algorithm-optimizer'
  // Instagram (1)
  | 'instagram-growth';

export interface SkillRouteScore {
  skillId: CanonicalSkillId;
  score: number;
  matchedRule: string;
}

export function routeSkillIntent(userText: string): CanonicalSkillId | null {
  if (!userText || !userText.trim()) return null;
  const raw = userText.trim();
  const lower = raw.toLowerCase();

  // 1. Direct explicit slash command or skill id prefix (Absolute Priority: +100)
  if (lower.startsWith('/artifact') || lower.startsWith('artifacts-builder')) return 'artifacts-builder';
  if (lower.startsWith('/brand') || lower.startsWith('brand-guidelines')) return 'brand-guidelines';
  if (lower.startsWith('/canvas') || lower.startsWith('/poster') || lower.startsWith('canvas-design')) return 'canvas-design';
  if (lower.startsWith('/changelog') || lower.startsWith('changelog-generator')) return 'changelog-generator';
  if (lower.startsWith('/ads') || lower.startsWith('competitive-ads-extractor')) return 'competitive-ads-extractor';
  if (lower.startsWith('/connect') || lower.startsWith('connect-apps')) return 'connect-apps';

  if (lower.startsWith('content-research-writer')) return 'content-research-writer';
  if (lower.startsWith('domain-name-brainstormer')) return 'domain-name-brainstormer';
  if (lower.startsWith('internal-comms')) return 'internal-comms';
  if (lower.startsWith('invoice-organizer')) return 'invoice-organizer';
  if (lower.startsWith('file-organizer')) return 'file-organizer';
  if (lower.startsWith('image-enhancer')) return 'image-enhancer';
  if (lower.startsWith('langsmith-fetch')) return 'langsmith-fetch';
  if (lower.startsWith('developer-growth-analysis')) return 'developer-growth-analysis';
  if (lower.startsWith('document-skills/docx') || lower.startsWith('/docx')) return 'document-skills/docx';

  if (lower.startsWith('lead-research-assistant')) return 'lead-research-assistant';
  if (lower.startsWith('mcp-builder')) {
    // If the query explicitly says "share the mcp-builder skill", action is skill-share!
    if (/\b(share|broadcast|send|post)\b/i.test(lower) && /\b(slack|channel|team)\b/i.test(lower)) {
      return 'skill-share';
    }
    return 'mcp-builder';
  }
  if (lower.startsWith('meeting-insights-analyzer')) return 'meeting-insights-analyzer';
  if (lower.startsWith('raffle-winner-picker')) return 'raffle-winner-picker';
  if (lower.startsWith('skill-creator')) return 'skill-creator';
  if (lower.startsWith('skill-share')) return 'skill-share';
  if (lower.startsWith('slack-gif-creator')) return 'slack-gif-creator';
  if (lower.startsWith('tailored-resume-generator')) return 'tailored-resume-generator';

  if (lower.startsWith('theme-factory') || lower.startsWith('/theme')) return 'theme-factory';
  if (lower.startsWith('twitter-algorithm-optimizer') || lower.startsWith('/tweet') || lower.startsWith('/twitter')) return 'twitter-algorithm-optimizer';
  if (lower.startsWith('instagram-growth') || lower.startsWith('/instagram') || lower.startsWith('/reels')) return 'instagram-growth';

  // 2. High-Priority Disambiguation: skill-share vs other skills
  // If the query is about SHARING / BROADCASTING a skill (even if it mentions MCP, habit-tracker, etc.)
  const isSharingAction =
    /\b(share (this|a|our|my|the)? ?skill|broadcast (my|our|this)? ?skill|post skill|share .* to slack|share .* on slack|share .* with the team|स्लैक पर शेयर|शेयर स्किल)\b/i.test(lower) ||
    (lower.includes('slack') && (lower.includes('skill') || lower.includes('share')) && !lower.includes('slack-gif') && !lower.includes('gif'));

  if (isSharingAction) {
    return 'skill-share';
  }

  // 3. Score-based matching across all 26 skills
  const scores: Record<CanonicalSkillId, number> = {
    'artifacts-builder': 0,
    'brand-guidelines': 0,
    'canvas-design': 0,
    'changelog-generator': 0,
    'competitive-ads-extractor': 0,
    'connect-apps': 0,
    'content-research-writer': 0,
    'domain-name-brainstormer': 0,
    'internal-comms': 0,
    'invoice-organizer': 0,
    'file-organizer': 0,
    'image-enhancer': 0,
    'langsmith-fetch': 0,
    'developer-growth-analysis': 0,
    'document-skills/docx': 0,
    'lead-research-assistant': 0,
    'mcp-builder': 0,
    'meeting-insights-analyzer': 0,
    'raffle-winner-picker': 0,
    'skill-creator': 0,
    'skill-share': 0,
    'slack-gif-creator': 0,
    'tailored-resume-generator': 0,
    'theme-factory': 0,
    'twitter-algorithm-optimizer': 0,
    'instagram-growth': 0,
  };

  // MCP Builder
  if (/\b(build an? mcp|create an? mcp|mcp server|fastmcp|model context protocol|typescript mcp|mcp tools?|mcp schema)\b/i.test(lower)) {
    scores['mcp-builder'] += 50;
  } else if (/\bmcp\b/i.test(lower)) {
    scores['mcp-builder'] += 20;
  }

  // Skill Creator
  if (/\b(create (a )?skill|build a skill|new skill|skill creator|skill template|generate skill\.md|skil बनाओ|नई स्किल)\b/i.test(lower)) {
    scores['skill-creator'] += 45;
  }

  // Slack GIF Creator
  if (/\b(slack gif|slack emoji|animated gif|emoji gif|celebration badge|128x128|गिफ बनाओ)\b/i.test(lower)) {
    scores['slack-gif-creator'] += 50;
  }

  // Artifacts Builder
  if (/\b(artifact|html artifact|interactive calculator|emi calculator|interactive widget|web artifact|आर्टिफ़ैक्ट)\b/i.test(lower)) {
    scores['artifacts-builder'] += 45;
  }

  // Brand Guidelines
  if (/\b(brand guideline|brand style|brand palette|color palette and typography|anthropic brand|brand rules)\b/i.test(lower)) {
    scores['brand-guidelines'] += 45;
  }

  // Canvas Design
  if (/\b(make a poster|design a poster|brutalist poster|museum poster|swiss poster|canvas design|पोस्टर बनाओ)\b/i.test(lower)) {
    scores['canvas-design'] += 45;
  }

  // Changelog Generator
  if (/\b(changelog|release notes|git commits?|commit log|summarize commits|what's new summary)\b/i.test(lower) || /^(feat|fix|perf|chore|refactor):/m.test(lower)) {
    scores['changelog-generator'] += 45;
  }

  // Competitive Ads Extractor
  if (/\b(competitor ads?|ad copy|facebook ads|linkedin ads|ad library|analyze ads?|extract ads?|copy formula)\b/i.test(lower)) {
    scores['competitive-ads-extractor'] += 45;
  }

  // Connect Apps (Composio / Webhooks)
  if (/\b(connect apps?|composio|send an? email|check my email|gmail|notion page|google calendar|linear issue|hubspot)\b/i.test(lower)) {
    scores['connect-apps'] += 40;
  }

  // Content Research Writer
  if (/\b(write a blog|blog outline|article outline|citation|research draft|research writer|ब्लॉग आउटलाइन)\b/i.test(lower)) {
    scores['content-research-writer'] += 40;
  }

  // Domain Name Brainstormer
  if (/\b(domain name|brainstorm domain|suggest domain|\.com|\.io|\.ai|\.dev|डोमेन नाम)\b/i.test(lower)) {
    scores['domain-name-brainstormer'] += 45;
  }

  // Internal Comms
  if (/\b(3p update|progress plans problems|company newsletter|internal comm|executive memo|3p अपडेट)\b/i.test(lower)) {
    scores['internal-comms'] += 45;
  }

  // Invoice Organizer
  if (/\b(invoice|organize invoice|receipt table|invoice csv|expense table|बिल|इनवॉइस|रसीद)\b/i.test(lower)) {
    scores['invoice-organizer'] += 45;
  }

  // File Organizer
  if (/\b(organize files|clean up downloads|folder structure|duplicate files|cleanup script|फ़ाइल ऑर्गनाइज़)\b/i.test(lower)) {
    scores['file-organizer'] += 45;
  }

  // Image Enhancer
  if (/\b(enhance image|upscale image|sharpen photo|image filter|screenshot quality|इमेज एनहांस)\b/i.test(lower)) {
    scores['image-enhancer'] += 45;
  }

  // LangSmith Fetch
  if (/\b(langsmith|trace json|agent trace|llm trace|langsmith trace|ट्रेस विश्लेषण)\b/i.test(lower)) {
    scores['langsmith-fetch'] += 45;
  }

  // Developer Growth Analysis
  if (/\b(developer growth|coding feedback|engineering feedback|code review rubric|डेवलपर ग्रोथ)\b/i.test(lower)) {
    scores['developer-growth-analysis'] += 45;
  }

  // Document Skills / DOCX
  if (/\b(word document|\.docx|docx file|tracked changes|redline document|वर्ड डॉक्यूमेंट)\b/i.test(lower)) {
    scores['document-skills/docx'] += 45;
  }

  // Lead Research Assistant
  if (/\b(find leads|lead research|b2b leads|target companies|prospects|icp leads|ग्राहक|लीड्स)\b/i.test(lower)) {
    scores['lead-research-assistant'] += 45;
  }

  // Meeting Insights Analyzer
  if (/\b(meeting transcript|conflict avoidance|filler words|speaking ratio|meeting insights|मीटिंग ट्रांसक्रिप्ट)\b/i.test(lower)) {
    scores['meeting-insights-analyzer'] += 45;
  }

  // Raffle Winner Picker
  if (/\b(pick a winner|raffle|giveaway|contest winner|random winner|लकी ड्रॉ|विजेता|रैफ़ल)\b/i.test(lower)) {
    scores['raffle-winner-picker'] += 45;
  }

  // Tailored Resume Generator
  if (/\b(tailor resume|ats resume|resume matcher|star resume|रिज्यूमे|रेज़्युमे)\b/i.test(lower)) {
    scores['tailored-resume-generator'] += 45;
  }

  // Theme Factory
  if (/\b(theme factory|apply theme|color theme|preset theme|ocean depths theme|कलर थीम|थीम चुनो)\b/i.test(lower)) {
    scores['theme-factory'] += 45;
  }

  // Twitter Algorithm Optimizer
  if (/\b(optimize tweet|twitter algorithm|tweepcred|simclusters|tweet draft|x post|ट्वीट)\b/i.test(lower)) {
    scores['twitter-algorithm-optimizer'] += 45;
  }

  // Instagram Growth
  if (/\b(instagram growth|viral reels?|reel hook|explore hashtags|zero rupee growth|इंस्टाग्राम)\b/i.test(lower)) {
    scores['instagram-growth'] += 45;
  }

  // Find maximum score
  let maxScore = 0;
  let bestSkill: CanonicalSkillId | null = null;

  for (const [skillId, score] of Object.entries(scores) as [CanonicalSkillId, number][]) {
    if (score > maxScore) {
      maxScore = score;
      bestSkill = skillId;
    }
  }

  return maxScore >= 20 ? bestSkill : null;
}
