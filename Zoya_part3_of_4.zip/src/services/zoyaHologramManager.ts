/**
 * ZOYA 3D HOLOGRAPHIC COMPANION MANAGER & REGISTRY
 *
 * Implements all 22 reference hologram styles (matching holo_ref_01.png to holo_ref_22.png):
 * - Completely circular silhouette
 * - Bold English "ZOYA" text in center (never a microphone icon)
 * - Concentric 3D rings, orbiting satellite spheres, energy ribbons, and particles
 * - Dynamic enlargement when Zoya speaks (1.35x - 1.5x)
 * - Audio-reactive glow during listening, high-speed spin in processing
 * - Bi-directional synchronization with native AndroidBridge
 */

export interface HologramStyle {
  id: string;
  index: number;
  name: string;
  category: 'cosmic' | 'royal' | 'crystal' | 'organic' | 'cyber' | 'botanical' | 'audio';
  imageAsset: string;
  referenceImage: string;
  description: string;
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
  textColor: string;
  ringStyle: string;
  ringType?: string;
  ringCount: number;
  features: string[];
  hasSatellites: boolean;
  satelliteCount?: number;
  centerEmblem?: 'crown' | 'diamond' | 'star' | 'chevron' | 'none';
}

export interface HologramConfig {
  enabled: boolean;
  backgroundListening: boolean;
  activeStyleId: string;
  selectedStyleIndex: number; // 1 to 22
  sizePx: number;               // Normal size: 100 to 220px (default 135px)
  speakingEnlargeRatio: number; // Ratio when speaking: 1.1x to 1.6x (default 1.35x)
  glowIntensity: number;        // Glow intensity: 0.5 to 1.5 (default 1.0)
  animationSpeed: number;       // Speed factor: 0.5 to 2.0 (default 1.0)
  screenPosition: { x: number; y: number }; // Relative position 0 to 1
  isMinimized: boolean;
  showCenterWordmark?: boolean;
}

export const ALL_22_HOLOGRAM_STYLES: HologramStyle[] = [
  {
    id: 'style_01',
    index: 1,
    name: 'Cosmic Flame Vortex',
    category: 'cosmic',
    imageAsset: '/assets/hologram/holo_ref_01.png',
    referenceImage: '/assets/hologram/holo_ref_01.png',
    description: 'Twisting spiral blades with electric blue, fiery magenta, luminous blue center with bold glowing ZOYA and horizon reflection',
    primaryColor: '#FF007F',
    secondaryColor: '#00E5FF',
    accentColor: '#7C4DFF',
    textColor: '#FFFFFF',
    ringStyle: 'vortex_flame',
    ringCount: 4,
    features: ['Twisting plasma blades', 'Electric blue edge', 'Horizon pedestal reflection'],
    hasSatellites: true,
    satelliteCount: 6,
    centerEmblem: 'none',
  },
  {
    id: 'style_02',
    index: 2,
    name: 'Imperial Gold Sovereign',
    category: 'royal',
    imageAsset: '/assets/hologram/holo_ref_02.png',
    referenceImage: '/assets/hologram/holo_ref_02.png',
    description: 'Radiant golden concentric rings, imperial sovereign crown emblem atop ZOYA, diamond flare below, and golden light stage',
    primaryColor: '#FFD700',
    secondaryColor: '#FFA500',
    accentColor: '#FFF8DC',
    textColor: '#FFF3C4',
    ringStyle: 'imperial_crown',
    ringCount: 3,
    features: ['Sovereign Crown emblem', 'Golden orbital rings', 'Diamond marker'],
    hasSatellites: true,
    satelliteCount: 4,
    centerEmblem: 'crown',
  },
  {
    id: 'style_03',
    index: 3,
    name: 'Prismatic Dual Diamond',
    category: 'crystal',
    imageAsset: '/assets/hologram/holo_ref_03.png',
    referenceImage: '/assets/hologram/holo_ref_03.png',
    description: 'Twin-pointed 3D diamond crystal with horizontal orbital rings and floating polyhedral crystal shards in electric cyan-blue',
    primaryColor: '#2979FF',
    secondaryColor: '#00E5FF',
    accentColor: '#7C4DFF',
    textColor: '#FFFFFF',
    ringStyle: 'prismatic_diamond',
    ringCount: 3,
    features: ['Faceted diamond prism', 'Horizontal orbital ring', 'Floating crystal shards'],
    hasSatellites: true,
    satelliteCount: 6,
    centerEmblem: 'diamond',
  },
  {
    id: 'style_04',
    index: 4,
    name: 'Scalloped Lotus Petal Wave',
    category: 'organic',
    imageAsset: '/assets/hologram/holo_ref_04.png',
    referenceImage: '/assets/hologram/holo_ref_04.png',
    description: 'Undulating wavy flower petal neon contour in orange-pink-cyan with delicate 4-point sparkle stars',
    primaryColor: '#FF4081',
    secondaryColor: '#FFAB00',
    accentColor: '#00E5FF',
    textColor: '#FCE4EC',
    ringStyle: 'scalloped_lotus',
    ringCount: 3,
    features: ['Undulating flower lobes', 'Multi-wave neon gradient', 'Sparkle star accents'],
    hasSatellites: true,
    satelliteCount: 2,
    centerEmblem: 'star',
  },
  {
    id: 'style_05',
    index: 5,
    name: 'Cyber Tactical Hex Shield',
    category: 'cyber',
    imageAsset: '/assets/hologram/holo_ref_05.png',
    referenceImage: '/assets/hologram/holo_ref_05.png',
    description: 'Angular futuristic cyber brackets and hexagonal matrix shield with cyan and violet bevels',
    primaryColor: '#00E5FF',
    secondaryColor: '#7C4DFF',
    accentColor: '#00B0FF',
    textColor: '#80D8FF',
    ringStyle: 'cyber_hex',
    ringCount: 4,
    features: ['Hexagonal telemetry brackets', 'Angular shield corner cuts', 'HUD alignment marks'],
    hasSatellites: false,
    centerEmblem: 'none',
  },
  {
    id: 'style_06',
    index: 6,
    name: 'Quantum Compass Dial',
    category: 'cyber',
    imageAsset: '/assets/hologram/holo_ref_06.png',
    referenceImage: '/assets/hologram/holo_ref_06.png',
    description: 'High-precision circular tech gauge with segmented tick reticle, cardinal notches, and indigo halo',
    primaryColor: '#651FFF',
    secondaryColor: '#00E5FF',
    accentColor: '#1A237E',
    textColor: '#EDE7F6',
    ringStyle: 'quantum_compass',
    ringCount: 4,
    features: ['Radial gauge ticks', 'Cardinal crosshairs', 'Concentric speed arcs'],
    hasSatellites: false,
    centerEmblem: 'none',
  },
  {
    id: 'style_07',
    index: 7,
    name: 'Aqua Pearl Satellite Orbit',
    category: 'cyber',
    imageAsset: '/assets/hologram/holo_ref_07.png',
    referenceImage: '/assets/hologram/holo_ref_07.png',
    description: 'Radiant cyan-green-purple glass torus with floating glossy pearl satellite spheres',
    primaryColor: '#00E5FF',
    secondaryColor: '#00FF88',
    accentColor: '#E040FB',
    textColor: '#E1F5FE',
    ringStyle: 'aqua_pearl',
    ringCount: 3,
    features: ['Glass torus ring', 'Orbiting pearl spheres', 'Liquid specular reflection'],
    hasSatellites: true,
    satelliteCount: 5,
    centerEmblem: 'none',
  },
  {
    id: 'style_08',
    index: 8,
    name: 'Cyberpunk Portal Frame',
    category: 'cyber',
    imageAsset: '/assets/hologram/holo_ref_08.png',
    referenceImage: '/assets/hologram/holo_ref_08.png',
    description: 'Rounded chamfered neon badge with amber-purple edges, bright gold typography, and directional chevron',
    primaryColor: '#FF9100',
    secondaryColor: '#E040FB',
    accentColor: '#FFD700',
    textColor: '#FFF8E1',
    ringStyle: 'cyber_portal',
    ringCount: 2,
    features: ['Chamfered badge outline', 'Downward directional chevron', 'Amber neon bloom'],
    hasSatellites: false,
    centerEmblem: 'chevron',
  },
  {
    id: 'style_09',
    index: 9,
    name: 'Hydro Splash Vortex',
    category: 'organic',
    imageAsset: '/assets/hologram/holo_ref_09.png',
    referenceImage: '/assets/hologram/holo_ref_09.png',
    description: 'Swirling turbulent water splash vortex with foaming droplet spray and rushing azure currents',
    primaryColor: '#00B0FF',
    secondaryColor: '#00E5FF',
    accentColor: '#FFFFFF',
    textColor: '#E0F7FA',
    ringStyle: 'hydro_splash',
    ringCount: 3,
    features: ['Curling water arcs', 'Droplet spray particles', 'Fluid wave rotation'],
    hasSatellites: true,
    satelliteCount: 8,
    centerEmblem: 'none',
  },
  {
    id: 'style_10',
    index: 10,
    name: 'Cyber Laurel Victory',
    category: 'botanical',
    imageAsset: '/assets/hologram/holo_ref_10.png',
    referenceImage: '/assets/hologram/holo_ref_10.png',
    description: 'Curved radiant violet/magenta botanical laurel branches wrapping circular neon halo',
    primaryColor: '#7C4DFF',
    secondaryColor: '#00E5FF',
    accentColor: '#E040FB',
    textColor: '#F3E5F5',
    ringStyle: 'laurel_wreath',
    ringCount: 3,
    features: ['Curved laurel branches', 'Bioluminescent leaves', 'Outer rainbow aura'],
    hasSatellites: false,
    centerEmblem: 'none',
  },
  {
    id: 'style_11',
    index: 11,
    name: 'Liquid Aurora Wave Ribbon',
    category: 'organic',
    imageAsset: '/assets/hologram/holo_ref_11.png',
    referenceImage: '/assets/hologram/holo_ref_11.png',
    description: 'Flowing organic smoky aurora plasma wave ribbons with floating neon droplets and soft lavender glow',
    primaryColor: '#00E5FF',
    secondaryColor: '#AA00FF',
    accentColor: '#1DE9B6',
    textColor: '#E0F7FA',
    ringStyle: 'aurora_wave',
    ringCount: 3,
    features: ['Smoky plasma contours', 'Undulating perimeter wave', 'Floating droplet embers'],
    hasSatellites: true,
    satelliteCount: 4,
    centerEmblem: 'none',
  },
  {
    id: 'style_12',
    index: 12,
    name: 'Ethereal Silk Ribbon Halo',
    category: 'organic',
    imageAsset: '/assets/hologram/holo_ref_12.png',
    referenceImage: '/assets/hologram/holo_ref_12.png',
    description: 'Intertwining translucent neon ribbon loops with floating sapphire satellite spheres',
    primaryColor: '#D500F9',
    secondaryColor: '#2979FF',
    accentColor: '#FF4081',
    textColor: '#F8BBD0',
    ringStyle: 'silk_ribbon',
    ringCount: 3,
    features: ['Flowing ribbon loops', 'Dual orbital ellipses', 'Soft chromatic dispersion'],
    hasSatellites: true,
    satelliteCount: 2,
    centerEmblem: 'none',
  },
  {
    id: 'style_13',
    index: 13,
    name: 'Circular Audio Spectrum Pulse',
    category: 'audio',
    imageAsset: '/assets/hologram/holo_ref_13.png',
    referenceImage: '/assets/hologram/holo_ref_13.png',
    description: '360-degree radial audio equalizer frequency bars pulsating in purple, magenta and cyan',
    primaryColor: '#E040FB',
    secondaryColor: '#00E5FF',
    accentColor: '#7C4DFF',
    textColor: '#F3E5F5',
    ringStyle: 'audio_spectrum',
    ringCount: 2,
    features: ['48 radial equalizer bars', 'Audio amplitude pulse', 'Concentric frequency ring'],
    hasSatellites: false,
    centerEmblem: 'none',
  },
  {
    id: 'style_14',
    index: 14,
    name: 'Segmented Sci-Fi HUD Reticle',
    category: 'cyber',
    imageAsset: '/assets/hologram/holo_ref_14.png',
    referenceImage: '/assets/hologram/holo_ref_14.png',
    description: 'Concentric digital telemetry rings with dashed tick arcs, gauge segments and precision brackets',
    primaryColor: '#00E5FF',
    secondaryColor: '#7C4DFF',
    accentColor: '#00B0FF',
    textColor: '#80D8FF',
    ringStyle: 'segmented_hud',
    ringCount: 4,
    features: ['Segmented arc quadrants', 'Counter-rotating telemetry', 'Digital gauge vernier'],
    hasSatellites: false,
    centerEmblem: 'none',
  },
  {
    id: 'style_15',
    index: 15,
    name: 'Golden Botanical Leaf Wreath',
    category: 'botanical',
    imageAsset: '/assets/hologram/holo_ref_15.png',
    referenceImage: '/assets/hologram/holo_ref_15.png',
    description: 'Burnished gold leaf vine filigree with luminous foliage filaments and serif typography',
    primaryColor: '#FFD700',
    secondaryColor: '#FFA500',
    accentColor: '#FFE082',
    textColor: '#FFF9C4',
    ringStyle: 'gold_botanical',
    ringCount: 3,
    features: ['Gilded leaf filigree', 'Alternating leaf arches', 'Warm sunburst aura'],
    hasSatellites: false,
    centerEmblem: 'none',
  },
  {
    id: 'style_16',
    index: 16,
    name: 'Full Spectrum Rainbow Halo',
    category: 'cosmic',
    imageAsset: '/assets/hologram/holo_ref_16.png',
    referenceImage: '/assets/hologram/holo_ref_16.png',
    description: 'Continuous chromatic rainbow spectrum circular ring with two diametrically opposed orbiting spheres',
    primaryColor: '#FF3D00',
    secondaryColor: '#00E676',
    accentColor: '#00E5FF',
    textColor: '#FFFFFF',
    ringStyle: 'rainbow_halo',
    ringCount: 3,
    features: ['Continuous rainbow sweep', 'Dual opposing satellites', '3D orbital track'],
    hasSatellites: true,
    satelliteCount: 2,
    centerEmblem: 'none',
  },
  {
    id: 'style_17',
    index: 17,
    name: 'Planetary Nebula Constellation',
    category: 'cosmic',
    imageAsset: '/assets/hologram/holo_ref_17.png',
    referenceImage: '/assets/hologram/holo_ref_17.png',
    description: 'Deep interstellar nebula with twin sparkling 4-point stars, orbital elliptical rings, and planetoids',
    primaryColor: '#651FFF',
    secondaryColor: '#E040FB',
    accentColor: '#00E5FF',
    textColor: '#EDE7F6',
    ringStyle: 'nebula_constellation',
    ringCount: 3,
    features: ['Twin sparkle stars', 'Planetary orbiters', 'Deep violet cosmic fog'],
    hasSatellites: true,
    satelliteCount: 3,
    centerEmblem: 'star',
  },
  {
    id: 'style_18',
    index: 18,
    name: 'Emerald Botanical Halo',
    category: 'botanical',
    imageAsset: '/assets/hologram/holo_ref_18.png',
    referenceImage: '/assets/hologram/holo_ref_18.png',
    description: 'Bioluminescent emerald-green leaves and vines wrapping circular aura with mint typography',
    primaryColor: '#00E676',
    secondaryColor: '#1DE9B6',
    accentColor: '#00B0FF',
    textColor: '#E8F5E9',
    ringStyle: 'emerald_botanical',
    ringCount: 3,
    features: ['Bioluminescent leaves', 'Vine wrap contour', 'Mint glowing aura'],
    hasSatellites: false,
    centerEmblem: 'none',
  },
  {
    id: 'style_19',
    index: 19,
    name: 'Ribbon Plasma Vortex',
    category: 'cosmic',
    imageAsset: '/assets/hologram/holo_ref_19.png',
    referenceImage: '/assets/hologram/holo_ref_19.png',
    description: 'Concentric magenta-cyan swirling ribbon loops with soft glowing embers and high-speed energy flow',
    primaryColor: '#FF007F',
    secondaryColor: '#00E5FF',
    accentColor: '#9D00FF',
    textColor: '#FCE4EC',
    ringStyle: 'ribbon_vortex',
    ringCount: 4,
    features: ['High-speed ribbon loop', 'Swirling energy vortex', 'Contrasting magenta/cyan'],
    hasSatellites: true,
    satelliteCount: 4,
    centerEmblem: 'none',
  },
  {
    id: 'style_20',
    index: 20,
    name: 'Faceted Gemstone Crystal',
    category: 'crystal',
    imageAsset: '/assets/hologram/holo_ref_20.png',
    referenceImage: '/assets/hologram/holo_ref_20.png',
    description: 'Outer ring composed of multi-faceted geometric gem shards in amethyst violet and electric cyan',
    primaryColor: '#7C4DFF',
    secondaryColor: '#00E5FF',
    accentColor: '#E040FB',
    textColor: '#FFFFFF',
    ringStyle: 'faceted_gem',
    ringCount: 3,
    features: ['14 geometric crystal facets', 'Alternating amethyst shards', 'Prismatic light refraction'],
    hasSatellites: true,
    satelliteCount: 6,
    centerEmblem: 'none',
  },
  {
    id: 'style_21',
    index: 21,
    name: 'Dual Gold Horizon Ring',
    category: 'royal',
    imageAsset: '/assets/hologram/holo_ref_21.png',
    referenceImage: '/assets/hologram/holo_ref_21.png',
    description: 'Double concentric pure gold neon rings with horizon starburst flares and lower pedestal stage',
    primaryColor: '#FFD700',
    secondaryColor: '#FFA500',
    accentColor: '#FFF8DC',
    textColor: '#FFF9C4',
    ringStyle: 'dual_gold_horizon',
    ringCount: 2,
    features: ['Double gold rings', 'Horizon starburst flares', 'Lower reflection stage'],
    hasSatellites: false,
    centerEmblem: 'none',
  },
  {
    id: 'style_22',
    index: 22,
    name: 'Deep Cosmic Galaxy Bubble',
    category: 'cosmic',
    imageAsset: '/assets/hologram/holo_ref_22.png',
    referenceImage: '/assets/hologram/holo_ref_22.png',
    description: 'Mystical interstellar nebula cloud inside spherical glass boundary with orbiting planetary moons',
    primaryColor: '#651FFF',
    secondaryColor: '#00E5FF',
    accentColor: '#E040FB',
    textColor: '#EDE7F6',
    ringStyle: 'galaxy_bubble',
    ringCount: 3,
    features: ['Spherical nebula gas', 'Orbiting planetoid moons', 'Dense stellar particles'],
    hasSatellites: true,
    satelliteCount: 2,
    centerEmblem: 'none',
  },
];

class ZoyaHologramManager {
  private config: HologramConfig;
  private isAppInForeground: boolean = true;
  private isSimulatingHomeScreen: boolean = false;
  private simulatedExternalApp: string | null = null;

  constructor() {
    this.config = this.loadConfig();
    this.initLifecycleListeners();
  }

  private initLifecycleListeners(): void {
    if (typeof window === 'undefined') return;

    // Browser tab visibility detection
    document.addEventListener('visibilitychange', () => {
      const inForeground = document.visibilityState === 'visible';
      if (!this.isSimulatingHomeScreen) {
        this.setAppInForeground(inForeground);
      }
    });

    // Native Android Activity lifecycle callbacks via AndroidBridge
    (window as any).__onZoyaLifecycleEvent = (event: 'resume' | 'pause' | 'stop') => {
      const inForeground = event === 'resume';
      this.setAppInForeground(inForeground);
    };
  }

  private loadConfig(): HologramConfig {
    const defaults: HologramConfig = {
      enabled: false, // Default OFF until user explicitly enables in Settings
      backgroundListening: true,
      activeStyleId: 'style_01',
      selectedStyleIndex: 1,
      sizePx: 135,
      speakingEnlargeRatio: 1.35,
      glowIntensity: 1.0,
      animationSpeed: 1.0,
      screenPosition: { x: 0.82, y: 0.25 },
      isMinimized: false,
      showCenterWordmark: true,
    };

    if (typeof window === 'undefined') return defaults;

    try {
      const raw = localStorage.getItem('zoya_hologram_config');
      if (raw) {
        const parsed = JSON.parse(raw);
        return { ...defaults, ...parsed };
      }
    } catch {}

    return defaults;
  }

  public getConfig(): ZoyaHologramConfig {
    return {
      ...this.config,
      selectedStyleId: this.config.activeStyleId,
      baseSizePx: this.config.sizePx,
      backgroundListeningEnabled: this.config.backgroundListening,
    };
  }

  public updateConfig(
    partial: Partial<
      HologramConfig & {
        selectedStyleId?: string;
        baseSizePx?: number;
        backgroundListeningEnabled?: boolean;
      }
    >
  ): ZoyaHologramConfig {
    const mapped: Partial<HologramConfig> = { ...partial };
    if (partial.selectedStyleId !== undefined) {
      mapped.activeStyleId = partial.selectedStyleId;
      const match = partial.selectedStyleId.match(/\d+/);
      if (match) {
        mapped.selectedStyleIndex = parseInt(match[0], 10);
      }
    }
    if (partial.baseSizePx !== undefined) {
      mapped.sizePx = partial.baseSizePx;
    }
    if (partial.backgroundListeningEnabled !== undefined) {
      mapped.backgroundListening = partial.backgroundListeningEnabled;
    }
    this.config = { ...this.config, ...mapped };
    this.persist();
    this.syncToNativeBridge();
    return this.getConfig();
  }

  public getActiveStyle(): HologramStyle {
    const found = ALL_22_HOLOGRAM_STYLES.find(
      (s) => s.id === this.config.activeStyleId || s.index === this.config.selectedStyleIndex
    );
    return found || ALL_22_HOLOGRAM_STYLES[0];
  }

  public setActiveStyle(styleIdOrIndex: string | number): HologramStyle {
    let index = 1;
    if (typeof styleIdOrIndex === 'number') {
      index = styleIdOrIndex;
    } else {
      const match = styleIdOrIndex.match(/\d+/);
      if (match) {
        index = parseInt(match[0], 10);
      }
    }
    index = Math.max(1, Math.min(22, index));
    const targetId = `style_${index.toString().padStart(2, '0')}`;
    const found = ALL_22_HOLOGRAM_STYLES.find((s) => s.index === index) || ALL_22_HOLOGRAM_STYLES[0];

    this.updateConfig({
      activeStyleId: targetId,
      selectedStyleIndex: index,
    });
    return found;
  }

  private persist(): void {
    if (typeof window === 'undefined') return;
    try {
      localStorage.setItem('zoya_hologram_config', JSON.stringify(this.config));
      window.dispatchEvent(new CustomEvent('zoya_hologram_config_changed', { detail: this.config }));
    } catch {}
  }

  public syncToNativeBridge(): void {
    if (typeof window === 'undefined') return;
    const bridge = (window as any).AndroidBridge;
    if (bridge && typeof bridge.setHologramConfig === 'function') {
      try {
        bridge.setHologramConfig(
          JSON.stringify({
            styleIndex: this.config.selectedStyleIndex,
            activeStyleId: this.config.activeStyleId,
            sizePx: this.config.sizePx,
            speakingEnlargeRatio: this.config.speakingEnlargeRatio,
            glowIntensity: this.config.glowIntensity,
            animationSpeed: this.config.animationSpeed,
            isMinimized: this.config.isMinimized,
          })
        );
      } catch (err) {
        console.warn('[HOLOGRAM] Failed to sync config with AndroidBridge:', err);
      }
    }
  }

  public notifyVoiceState(
    state: 'IDLE' | 'LISTENING' | 'PROCESSING' | 'SPEAKING' | 'ERROR' | 'idle' | 'listening' | 'processing' | 'speaking' | 'error',
    audioLevel: number = 0,
    transcript: string = ''
  ): void {
    if (typeof window === 'undefined') return;
    const normalizedState = (typeof state === 'string' ? state.toLowerCase() : 'idle');
    const bridge = (window as any).AndroidBridge;
    if (bridge && typeof bridge.updateHologramState === 'function') {
      try {
        bridge.updateHologramState(
          JSON.stringify({
            status: normalizedState,
            state: normalizedState.toUpperCase(),
            audioLevel,
            transcript,
            timestamp: Date.now(),
          })
        );
      } catch (err) {
        console.warn('[HOLOGRAM] Failed to update state via AndroidBridge:', err);
      }
    }
  }

  public requestOverlayPermission(): { success: boolean; message: string } {
    if (typeof window === 'undefined') {
      return { success: false, message: 'Window context unavailable' };
    }
    const bridge = (window as any).AndroidBridge;
    if (bridge && typeof bridge.requestOverlayPermission === 'function') {
      try {
        const resStr = bridge.requestOverlayPermission();
        const parsed = JSON.parse(resStr);
        return { success: parsed.success, message: parsed.message || 'Opened overlay settings' };
      } catch {
        return { success: true, message: 'Opening overlay settings...' };
      }
    }
    return { success: false, message: 'Android overlay bridge unavailable in browser mode.' };
  }

  public isOverlayPermissionGranted(): boolean {
    if (typeof window === 'undefined') return false;
    const bridge = (window as any).AndroidBridge;
    if (bridge && typeof bridge.isOverlayPermissionGranted === 'function') {
      return bridge.isOverlayPermissionGranted();
    }
    return false;
  }

  public isAndroidOverlayRunning(): boolean {
    if (typeof window === 'undefined') return false;
    const bridge = (window as any).AndroidBridge;
    if (bridge && typeof bridge.isHologramOverlayRunning === 'function') {
      return bridge.isHologramOverlayRunning();
    }
    return false;
  }

  public subscribe(callback: (config: ZoyaHologramConfig) => void): () => void {
    const handler = () => callback(this.getConfig());
    if (typeof window !== 'undefined') {
      window.addEventListener('zoya_hologram_config_changed', handler);
      return () => window.removeEventListener('zoya_hologram_config_changed', handler);
    }
    return () => {};
  }

  public setEnabled(enabled: boolean): void {
    this.updateConfig({ enabled });
    const bridge = typeof window !== 'undefined' ? (window as any).AndroidBridge : null;
    if (bridge && typeof bridge.setHologramOverlayEnabled === 'function') {
      bridge.setHologramOverlayEnabled(enabled);
    }
  }

  public setBackgroundListening(backgroundListening: boolean): void {
    this.updateConfig({ backgroundListening });
  }

  public setStyle(styleId: string): void {
    this.setActiveStyle(styleId);
  }

  public setBaseSize(sizePx: number): void {
    this.updateConfig({ sizePx });
  }

  public setSpeakingEnlargeRatio(speakingEnlargeRatio: number): void {
    this.updateConfig({ speakingEnlargeRatio });
  }

  public setGlowIntensity(glowIntensity: number): void {
    this.updateConfig({ glowIntensity });
  }

  public setAnimationSpeed(animationSpeed: number): void {
    this.updateConfig({ animationSpeed });
  }

  public setAppInForeground(inForeground: boolean): void {
    if (this.isAppInForeground === inForeground) return;
    this.isAppInForeground = inForeground;
    if (inForeground) {
      this.isSimulatingHomeScreen = false;
      this.simulatedExternalApp = null;
    }
    if (typeof window !== 'undefined') {
      window.dispatchEvent(
        new CustomEvent('zoya_foreground_state_changed', {
          detail: {
            isAppInForeground: this.isAppInForeground,
            isSimulatingHomeScreen: this.isSimulatingHomeScreen,
            simulatedExternalApp: this.simulatedExternalApp,
          },
        })
      );
      const bridge = (window as any).AndroidBridge;
      if (bridge && typeof bridge.setAppInForeground === 'function') {
        try {
          bridge.setAppInForeground(inForeground);
        } catch {}
      }
    }
  }

  public isAppForeground(): boolean {
    return this.isAppInForeground;
  }

  public setSimulatingHomeScreen(simulating: boolean, externalApp: string | null = null): void {
    this.isSimulatingHomeScreen = simulating;
    this.simulatedExternalApp = externalApp;
    this.setAppInForeground(!simulating);
  }

  public isSimulatingOutsideApp(): boolean {
    return this.isSimulatingHomeScreen;
  }

  public getSimulatedExternalApp(): string | null {
    return this.simulatedExternalApp;
  }

  public subscribeForeground(
    callback: (state: {
      isAppInForeground: boolean;
      isSimulatingHomeScreen: boolean;
      simulatedExternalApp: string | null;
    }) => void
  ): () => void {
    const handler = (e: any) =>
      callback(
        e.detail || {
          isAppInForeground: this.isAppInForeground,
          isSimulatingHomeScreen: this.isSimulatingHomeScreen,
          simulatedExternalApp: this.simulatedExternalApp,
        }
      );
    if (typeof window !== 'undefined') {
      window.addEventListener('zoya_foreground_state_changed', handler);
      return () => window.removeEventListener('zoya_foreground_state_changed', handler);
    }
    return () => {};
  }
}

export const hologramManager = new ZoyaHologramManager();
export const ZOYA_HOLOGRAM_STYLES = ALL_22_HOLOGRAM_STYLES;
export const ALL_23_HOLOGRAM_STYLES = ALL_22_HOLOGRAM_STYLES; // Backwards-compatible alias
export type ZoyaHologramStyleDefinition = HologramStyle;
export type ZoyaHologramConfig = HologramConfig & {
  selectedStyleId: string;
  baseSizePx: number;
  backgroundListeningEnabled: boolean;
};
