/**
 * Smart Battery, Flight Mode & System Announcements Configuration
 * 
 * ALL dialogue texts, warning thresholds, and timing parameters are editable in this single file.
 * Placeholder {PERCENT} is automatically replaced with the current battery percentage.
 * Placeholder {APP_NAME} is automatically replaced with the app name.
 */

export interface SystemAnnouncementsConfig {
  thresholds: {
    twenty: number; // 20%
    ten: number;    // 10%
    three: number;  // 3%
  };
  /**
   * Reset hysteresis offset:
   * Low-battery warning flags reset when charger is connected OR
   * when battery level rises above (threshold + hysteresisOffset).
   * Default: 3% (e.g. >23% for 20%, >13% for 10%, >6% for 3%).
   */
  hysteresisOffset: number;
  /**
   * Minimum duration (ms) between rapid event triggers before ignoring as repeat/bounce.
   * Default: 2000 ms.
   */
  debounceMs: number;
  /**
   * Announcements queued behind active speech or phone calls expire if older than this (ms).
   * Default: 15000 ms (15 seconds).
   */
  queueMaxAgeMs: number;

  dialogues: {
    // 1. When charger is plugged in (< 95%)
    chargerConnectedNormal: string;
    // 1b. When charger is plugged in (>= 95% full)
    chargerConnectedFull: string;
    // 2. When charger is unplugged
    chargerDisconnected: string;
    // 3. Low-battery warnings (discharging only)
    lowBattery20: string;
    lowBattery10: string;
    lowBattery3: string;
    // 4. Flight Mode (Offline TTS)
    flightModeOn: string;
    flightModeOff: string;
    // 11. App Installation
    appInstalled: string;
    // 12. App Uninstallation
    appUninstalled: string;
  };
}

export const BATTERY_ALERT_CONFIG: SystemAnnouncementsConfig = {
  thresholds: {
    twenty: 20,
    ten: 10,
    three: 3,
  },
  hysteresisOffset: 3,
  debounceMs: 2000,
  queueMaxAgeMs: 15000,
  dialogues: {
    chargerConnectedNormal: 'Charging shuru ho gayi, power aa gaya. Abhi battery {PERCENT} percent hai.',
    chargerConnectedFull: 'Charging shuru ho gayi, power aa gaya. Battery already {PERCENT} percent hai, lagbhag full.',
    chargerDisconnected: 'Power off ho gaya, charger nikal diya gaya. Abhi battery {PERCENT} percent hai.',
    lowBattery20: 'Boss, battery sirf {PERCENT} percent bachi hai. Kripya charger laga dijiye, warna jaldi band ho sakta hai.',
    lowBattery10: 'Boss, battery bahut kam hai, sirf {PERCENT} percent! Abhi charger lagaiye, warna phone band ho jayega.',
    lowBattery3: 'Boss, emergency! Battery sirf {PERCENT} percent hai, phone kabhi bhi band ho sakta hai. Turant charger lagaiye!',
    flightModeOn: 'Flight mode on ho gaya. Network aur internet band ho gaye hain.',
    flightModeOff: 'Flight mode off ho gaya. Network wapas aa raha hai.',
    appInstalled: '{APP_NAME} install ho gaya.',
    appUninstalled: '{APP_NAME} uninstall ho gaya.',
  },
};
