export const STANDALONE_TYPESCRIPT_CODE = `import JSZip from 'jszip';

export interface ProcessedZipItem {
  path: string;
  name: string;
  isDirectory: boolean;
  size: number;
  isText: boolean;
  isImage: boolean;
  content?: string;          // UTF-8 text for code/txt/json/md
  binaryData?: Uint8Array;    // Raw binary byte array
  dataUrl?: string;          // Data URL for images
}

export interface ZipBatchResult {
  fileName: string;
  totalFiles: number;
  totalFolders: number;
  totalBytes: number;
  items: ProcessedZipItem[];
}

/**
 * 100% Complete ZIP Extraction and Processing Function
 * Reads every single file inside the ZIP archive without skipping any file.
 *
 * @param source - File, Blob, or ArrayBuffer of the ZIP file
 * @param onProgress - Optional callback reporting progress percentage (0 - 100)
 */
export async function processEntireZip(
  source: File | Blob | ArrayBuffer,
  onProgress?: (percent: number, currentFile: string) => void
): Promise<ZipBatchResult> {
  const zip = new JSZip();
  // 1. Load the ZIP file completely
  const loadedZip = await zip.loadAsync(source);

  // 2. Collect all file keys
  const entries: { path: string; entry: JSZip.JSZipObject }[] = [];
  loadedZip.forEach((relativePath, entry) => {
    entries.push({ path: relativePath, entry });
  });

  const total = entries.length;
  const items: ProcessedZipItem[] = [];
  let totalBytes = 0;
  let totalFiles = 0;
  let totalFolders = 0;

  // 3. Process every single file sequentially or in parallel without skipping
  for (let i = 0; i < total; i++) {
    const { path, entry } = entries[i];
    const isDirectory = entry.dir;
    const name = path.split('/').filter(Boolean).pop() || path;

    onProgress?.(Math.round(((i + 1) / total) * 100), path);

    if (isDirectory) {
      totalFolders++;
      items.push({
        path,
        name,
        isDirectory: true,
        size: 0,
        isText: false,
        isImage: false,
      });
      continue;
    }

    totalFiles++;
    const ext = name.includes('.') ? name.split('.').pop()!.toLowerCase() : '';
    const isImage = ['png', 'jpg', 'jpeg', 'webp', 'gif', 'svg', 'ico'].includes(ext);
    const isText = [
      'ts', 'tsx', 'js', 'jsx', 'json', 'html', 'css', 'md', 'txt', 'csv',
      'xml', 'yaml', 'yml', 'env', 'gitignore', 'sh', 'sql'
    ].includes(ext) || ext === '';

    let content: string | undefined;
    let binaryData: Uint8Array | undefined;
    let dataUrl: string | undefined;

    // Load binary Uint8Array for all files
    binaryData = await entry.async('uint8array');
    totalBytes += binaryData.byteLength;

    // If text file, decode UTF-8 string
    if (isText) {
      content = await entry.async('string');
    }

    // If image, create Base64 Data URL for immediate display
    if (isImage) {
      const base64 = await entry.async('base64');
      dataUrl = \`data:image/\${ext === 'svg' ? 'svg+xml' : ext};base64,\${base64}\`;
    }

    items.push({
      path,
      name,
      isDirectory: false,
      size: binaryData.byteLength,
      isText,
      isImage,
      content,
      binaryData,
      dataUrl,
    });
  }

  return {
    fileName: (source as File).name || 'archive.zip',
    totalFiles,
    totalFolders,
    totalBytes,
    items,
  };
}
`;

export const STANDALONE_JAVASCRIPT_CODE = `// Vanilla JavaScript (Node.js or Browser with jszip CDN / npm)
// npm install jszip
import JSZip from 'jszip';

async function processEntireZip(fileOrBuffer, onProgress) {
  const zip = new JSZip();
  const loadedZip = await zip.loadAsync(fileOrBuffer);

  const fileEntries = [];
  loadedZip.forEach((relativePath, entry) => {
    fileEntries.push({ path: relativePath, entry });
  });

  const total = fileEntries.length;
  const processedFiles = [];
  let totalBytes = 0;

  for (let i = 0; i < total; i++) {
    const { path, entry } = fileEntries[i];
    if (onProgress) onProgress(Math.round(((i + 1) / total) * 100), path);

    if (entry.dir) {
      processedFiles.push({ path, isDirectory: true, size: 0 });
      continue;
    }

    // Read raw binary buffer for 100% complete data fidelity
    const uint8 = await entry.async('uint8array');
    totalBytes += uint8.byteLength;

    // Detect if text to extract string
    const isText = /\\.(txt|json|js|jsx|ts|tsx|html|css|md|csv|env|xml|ya?ml)$/i.test(path);
    let textContent = null;
    if (isText) {
      textContent = await entry.async('string');
    }

    processedFiles.push({
      path,
      isDirectory: false,
      size: uint8.byteLength,
      content: textContent,
      binary: uint8,
    });
  }

  return {
    totalFiles: processedFiles.filter(f => !f.isDirectory).length,
    totalFolders: processedFiles.filter(f => f.isDirectory).length,
    totalBytes,
    files: processedFiles,
  };
}
`;
