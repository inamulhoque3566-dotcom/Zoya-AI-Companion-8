/**
 * Zoya AI Secret Vault (Android Keystore + Browser Memory-Only Vault)
 *
 * SECURITY ARCHITECTURE (Round 5 Item 4D):
 * 1. Installed Android APK (`window.AndroidBridge` present):
 *    All sensitive secrets (GitHub PAT, YouTube API Key, Tool API Keys, Custom LLM Key)
 *    are stored in native Android Keystore (`EncryptedSharedPreferences` with `MasterKey`
 *    AES256-GCM) via `window.AndroidBridge.setEncryptedSecret` / `getEncryptedSecret`.
 * 2. Normal Web Browser (no `window.AndroidBridge`):
 *    Secrets are kept IN MEMORY ONLY (`memoryVault` encrypted with Web Crypto AES-256-GCM
 *    session key) and are NEVER written to `localStorage`. Any legacy plaintext or
 *    encrypted secret entries found in `localStorage` are migrated into memory and
 *    immediately deleted from `localStorage`.
 */

const VAULT_PREFIX = 'ZOYA_ENC_V1:';
const memoryVault = new Map<string, string>();
const syncPlainCache = new Map<string, string>();
let runtimeCryptoKeyPromise: Promise<CryptoKey | null> | null = null;

export const DEPRECATED_PURGED_SECRET_KEYS = [
  'zoya_elevenlabs_api_key',
] as const;

export const PROTECTED_SECRET_KEYS = [
  'zoya_github_pat',
  'zoya_github_pat_token',
  'zoya_youtube_api_key',
  'zoya_tool_api_keys_v1',
  'zoya_api_key',
  'zoya_gemini_api_key',
  'zoya_ai_model_key',
  'zoya_tool_key_composio',
  'zoya_tool_key_github_pat',
  'zoya_tool_key_ad_library',
  'zoya_tool_key_langsmith',
  'zoya_tool_key_slack_webhook',
] as const;

export type VaultStorageMode = 'ANDROID_KEYSTORE' | 'BROWSER_MEMORY_ONLY';

export interface SecretVaultSelfTestResult {
  success: boolean;
  storageMode: VaultStorageMode;
  storageBackendLabel: string;
  dummyInputLength: number;
  ciphertextPreview: string;
  roundtripMatched: boolean;
  localStoragePlaintextLeak: boolean;
  localStorageSecretKeyCount: number;
  timestamp: string;
  details: string;
}

/**
 * Returns true when running inside the installed Zoya Android APK with native Keystore bridge.
 */
export function isRunningInAndroidApk(): boolean {
  if (typeof window === 'undefined') return false;
  const bridge = (window as any).AndroidBridge;
  return Boolean(
    bridge &&
      typeof bridge.setEncryptedSecret === 'function' &&
      typeof bridge.getEncryptedSecret === 'function'
  );
}

export function getVaultStorageMode(): VaultStorageMode {
  return isRunningInAndroidApk() ? 'ANDROID_KEYSTORE' : 'BROWSER_MEMORY_ONLY';
}

function getWebCrypto(): Crypto | null {
  if (typeof globalThis !== 'undefined' && globalThis.crypto && globalThis.crypto.subtle) {
    return globalThis.crypto;
  }
  return null;
}

function bytesToBase64(bytes: Uint8Array): string {
  if (typeof Buffer !== 'undefined') {
    return Buffer.from(bytes).toString('base64');
  }
  let binary = '';
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

function base64ToBytes(b64: string): Uint8Array {
  if (typeof Buffer !== 'undefined') {
    return new Uint8Array(Buffer.from(b64, 'base64'));
  }
  const binary = atob(b64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes;
}

/**
 * Generates an ephemeral in-memory AES-256-GCM CryptoKey for the browser session.
 * Never persisted to localStorage.
 */
async function getSessionWrappingKey(): Promise<CryptoKey | null> {
  const cryptoObj = getWebCrypto();
  if (!cryptoObj) return null;

  if (!runtimeCryptoKeyPromise) {
    runtimeCryptoKeyPromise = (async () => {
      try {
        const rawKey = new Uint8Array(32);
        cryptoObj.getRandomValues(rawKey);
        return await cryptoObj.subtle.importKey(
          'raw',
          rawKey,
          { name: 'AES-GCM', length: 256 },
          false,
          ['encrypt', 'decrypt']
        );
      } catch {
        return null;
      }
    })();
  }
  return runtimeCryptoKeyPromise;
}

export async function encryptSecretValue(plaintext: string): Promise<string> {
  if (!plaintext) return '';
  if (plaintext.startsWith(VAULT_PREFIX)) return plaintext;

  const cryptoObj = getWebCrypto();
  const key = await getSessionWrappingKey();
  if (!cryptoObj || !key) {
    throw new Error('AES-GCM WebCrypto unavailable for secret encryption');
  }

  const iv = new Uint8Array(12);
  cryptoObj.getRandomValues(iv);
  const encoded = new TextEncoder().encode(plaintext);
  const cipherBuf = await cryptoObj.subtle.encrypt(
    { name: 'AES-GCM', iv },
    key,
    encoded
  );

  const ivB64 = bytesToBase64(iv);
  const cipherB64 = bytesToBase64(new Uint8Array(cipherBuf));
  return `${VAULT_PREFIX}${ivB64}:${cipherB64}`;
}

export async function decryptSecretValue(stored: string | null | undefined): Promise<string> {
  if (!stored) return '';
  if (!stored.startsWith(VAULT_PREFIX)) {
    return stored;
  }

  const cryptoObj = getWebCrypto();
  const key = await getSessionWrappingKey();
  if (!cryptoObj || !key) return '';

  try {
    const body = stored.slice(VAULT_PREFIX.length);
    const sepIdx = body.indexOf(':');
    if (sepIdx === -1) return '';
    const iv = base64ToBytes(body.slice(0, sepIdx));
    const cipherBytes = base64ToBytes(body.slice(sepIdx + 1));

    const plainBuf = await cryptoObj.subtle.decrypt(
      { name: 'AES-GCM', iv: iv as any },
      key,
      cipherBytes as any
    );
    return new TextDecoder().decode(plainBuf);
  } catch {
    return '';
  }
}

/**
 * Purges any secret keys from browser localStorage so secrets never live in localStorage.
 */
function purgeSecretFromLocalStorage(storageKey: string): void {
  try {
    if (typeof localStorage !== 'undefined') {
      localStorage.removeItem(storageKey);
      localStorage.removeItem('zoya_vault_master_salt_v1');
    }
  } catch {
    // ignore
  }
}

export function isDeprecatedPurgedKey(storageKey: string): boolean {
  return (DEPRECATED_PURGED_SECRET_KEYS as readonly string[]).includes(storageKey);
}

/**
 * Permanently deletes deprecated client-side secrets (such as zoya_elevenlabs_api_key)
 * from localStorage, sessionStorage, in-memory vault, and native Android Keystore.
 */
export function purgeDeprecatedClientSecrets(): void {
  for (const key of DEPRECATED_PURGED_SECRET_KEYS) {
    memoryVault.delete(key);
    syncPlainCache.delete(key);
    purgeSecretFromLocalStorage(key);
    try {
      if (typeof sessionStorage !== 'undefined') {
        sessionStorage.removeItem(key);
      }
    } catch {
      // ignore
    }
    try {
      const bridge = typeof window !== 'undefined' ? (window as any).AndroidBridge : null;
      if (bridge && typeof bridge.removeEncryptedSecret === 'function') {
        bridge.removeEncryptedSecret(key);
      } else if (bridge && typeof bridge.setEncryptedSecret === 'function') {
        bridge.setEncryptedSecret(key, '');
      }
    } catch {
      // ignore
    }
  }
}

/**
 * Stores a secret securely:
 * - In Android APK: writes to Android Keystore (`EncryptedSharedPreferences`) via `AndroidBridge`.
 * - In Browser: keeps in memory only (`memoryVault` with AES-256-GCM ciphertext) and removes from `localStorage`.
 */
export async function setSecretInVault(storageKey: string, plaintext: string): Promise<void> {
  if (isDeprecatedPurgedKey(storageKey)) {
    purgeDeprecatedClientSecrets();
    return;
  }

  const trimmed = plaintext.trim();
  purgeSecretFromLocalStorage(storageKey);

  if (!trimmed) {
    memoryVault.delete(storageKey);
    syncPlainCache.delete(storageKey);
    try {
      const bridge = typeof window !== 'undefined' ? (window as any).AndroidBridge : null;
      if (bridge && typeof bridge.removeEncryptedSecret === 'function') {
        bridge.removeEncryptedSecret(storageKey);
      } else if (bridge && typeof bridge.setEncryptedSecret === 'function') {
        bridge.setEncryptedSecret(storageKey, '');
      }
    } catch {
      // ignore
    }
    return;
  }

  syncPlainCache.set(storageKey, trimmed);

  // 1. Native Android Keystore path when running inside the installed APK
  try {
    const bridge = typeof window !== 'undefined' ? (window as any).AndroidBridge : null;
    if (bridge && typeof bridge.setEncryptedSecret === 'function') {
      bridge.setEncryptedSecret(storageKey, trimmed);
    }
  } catch {
    // Continue to also cache in memory for fast synchronous reads during session
  }

  // 2. In-memory encrypted cache (used in Browser mode and as fast session cache)
  const encrypted = await encryptSecretValue(trimmed);
  memoryVault.set(storageKey, encrypted);
}

/**
 * Reads and decrypts a secret from Android Keystore (if in APK) or in-memory vault (if in Browser).
 * Also purges any legacy localStorage entry if found.
 */
export async function getSecretFromVault(storageKey: string): Promise<string> {
  if (isDeprecatedPurgedKey(storageKey)) {
    purgeDeprecatedClientSecrets();
    return '';
  }

  // Purge any leftover localStorage entry
  try {
    if (typeof localStorage !== 'undefined') {
      const legacyVal = localStorage.getItem(storageKey);
      if (legacyVal !== null) {
        localStorage.removeItem(storageKey);
        if (!legacyVal.startsWith(VAULT_PREFIX) && legacyVal.trim()) {
          await setSecretInVault(storageKey, legacyVal.trim());
        }
      }
    }
  } catch {
    // ignore
  }

  // 1. Check Native Android Keystore first if running in APK
  try {
    const bridge = typeof window !== 'undefined' ? (window as any).AndroidBridge : null;
    if (bridge && typeof bridge.getEncryptedSecret === 'function') {
      const nativeSecret = bridge.getEncryptedSecret(storageKey);
      if (typeof nativeSecret === 'string' && nativeSecret.length > 0) {
        syncPlainCache.set(storageKey, nativeSecret);
        return nativeSecret;
      }
    }
  } catch {
    // Fallback to memoryVault
  }

  // 2. Read from in-memory vault
  const raw = memoryVault.get(storageKey) ?? null;
  if (!raw) return syncPlainCache.get(storageKey) || '';
  const decrypted = await decryptSecretValue(raw);
  if (decrypted) {
    syncPlainCache.set(storageKey, decrypted);
  }
  return decrypted;
}

/**
 * Synchronous read helper for tool API keys and UI components.
 * Checks AndroidBridge Keystore first, then in-memory session cache.
 */
export function getDecryptedSecretSync(storageKey: string): string {
  if (isDeprecatedPurgedKey(storageKey)) {
    purgeDeprecatedClientSecrets();
    return '';
  }

  purgeSecretFromLocalStorage(storageKey);
  try {
    const bridge = typeof window !== 'undefined' ? (window as any).AndroidBridge : null;
    if (bridge && typeof bridge.getEncryptedSecret === 'function') {
      const nativeSecret = bridge.getEncryptedSecret(storageKey);
      if (typeof nativeSecret === 'string' && nativeSecret.length > 0) {
        syncPlainCache.set(storageKey, nativeSecret);
        return nativeSecret;
      }
    }
  } catch {
    // ignore
  }
  return syncPlainCache.get(storageKey) || '';
}

/**
 * Synchronous write trigger for tool API keys and UI components.
 */
export function storeEncryptedSecret(storageKey: string, plaintext: string): void {
  if (isDeprecatedPurgedKey(storageKey)) {
    purgeDeprecatedClientSecrets();
    return;
  }

  const trimmed = plaintext.trim();
  purgeSecretFromLocalStorage(storageKey);
  if (!trimmed) {
    syncPlainCache.delete(storageKey);
    memoryVault.delete(storageKey);
  } else {
    syncPlainCache.set(storageKey, trimmed);
  }
  void setSecretInVault(storageKey, trimmed);
}

/**
 * Initializes the secret vault for a list of keys, deleting deprecated keys
 * and migrating and removing any legacy localStorage entries.
 */
export function initializeSecretVault(keys: readonly string[] = PROTECTED_SECRET_KEYS): void {
  purgeDeprecatedClientSecrets();
  const allKeys = new Set([...PROTECTED_SECRET_KEYS, ...keys]);
  for (const key of allKeys) {
    if (isDeprecatedPurgedKey(key)) continue;
    try {
      if (typeof localStorage !== 'undefined') {
        const legacy = localStorage.getItem(key);
        if (legacy !== null) {
          localStorage.removeItem(key);
          if (!legacy.startsWith(VAULT_PREFIX) && legacy.trim()) {
            void setSecretInVault(key, legacy.trim());
          }
        }
      }
    } catch {
      // ignore
    }
    void getSecretFromVault(key);
  }
}

/**
 * Inspects the raw stored representation for verification (never returns decrypted secret).
 */
export function getRawStoredVaultEntry(storageKey: string): string | null {
  return memoryVault.get(storageKey) ?? null;
}

/**
 * Purges any legacy/deprecated secrets from localStorage and vault on startup.
 */
export async function migrateAllPlaintextSecretsInStorage(): Promise<void> {
  purgeDeprecatedClientSecrets();
  initializeSecretVault(PROTECTED_SECRET_KEYS);
}

/**
 * Runs a live Encrypt-then-Decrypt self-test on the active secret vault.
 * Uses a disposable dummy string (never logs or touches real user tokens).
 */
export async function runSecretVaultSelfTest(): Promise<SecretVaultSelfTestResult> {
  const probeKey = '__zoya_selftest_dummy_secret__';
  const dummyPlaintext = `ZOYA_DUMMY_ROUNDTRIP_TEST_${Date.now()}_OK`;
  const inApk = isRunningInAndroidApk();

  try {
    // Check if AndroidBridge native Keystore self-test is available
    if (inApk) {
      const bridge = (window as any).AndroidBridge;
      if (typeof bridge.runKeystoreSelfTest === 'function') {
        const rawJson = bridge.runKeystoreSelfTest();
        const parsed = JSON.parse(rawJson);
        return {
          success: Boolean(parsed.verified),
          storageMode: 'ANDROID_KEYSTORE',
          storageBackendLabel:
            parsed.storageBackend || 'AndroidKeyStore (EncryptedSharedPreferences AES256-GCM)',
          dummyInputLength: dummyPlaintext.length,
          ciphertextPreview: parsed.ciphertextSample || 'AES256_GCM_CIPHERTEXT',
          roundtripMatched: Boolean(parsed.roundtripMatched),
          localStoragePlaintextLeak: false,
          localStorageSecretKeyCount: countSecretsInLocalStorage(),
          timestamp: new Date().toISOString(),
          details: parsed.verified
            ? 'Verified: Dummy secret encrypted in Android Keystore (EncryptedSharedPreferences), read back, and matched 100%.'
            : `Failed: ${parsed.error || 'Keystore roundtrip mismatch'}`,
        };
      }
    }

    // Browser Memory-Only + AES-256-GCM self-test
    await setSecretInVault(probeKey, dummyPlaintext);
    const rawCipher = getRawStoredVaultEntry(probeKey) || '';
    const decrypted = await getSecretFromVault(probeKey);
    await setSecretInVault(probeKey, ''); // clean up

    let leakInLocalStorage = false;
    try {
      if (typeof localStorage !== 'undefined') {
        for (let i = 0; i < localStorage.length; i++) {
          const k = localStorage.key(i);
          if (!k) continue;
          const v = localStorage.getItem(k) || '';
          if (v.includes(dummyPlaintext)) {
            leakInLocalStorage = true;
          }
        }
      }
    } catch {
      // ignore
    }

    const matched =
      decrypted === dummyPlaintext &&
      rawCipher.startsWith(VAULT_PREFIX) &&
      !rawCipher.includes(dummyPlaintext) &&
      !leakInLocalStorage;

    return {
      success: matched,
      storageMode: inApk ? 'ANDROID_KEYSTORE' : 'BROWSER_MEMORY_ONLY',
      storageBackendLabel: inApk
        ? 'AndroidKeyStore (EncryptedSharedPreferences)'
        : 'Browser Memory-Only Vault (AES-256-GCM WebCrypto, zero localStorage)',
      dummyInputLength: dummyPlaintext.length,
      ciphertextPreview: rawCipher ? `${rawCipher.slice(0, 44)}...` : 'N/A',
      roundtripMatched: decrypted === dummyPlaintext,
      localStoragePlaintextLeak: leakInLocalStorage,
      localStorageSecretKeyCount: countSecretsInLocalStorage(),
      timestamp: new Date().toISOString(),
      details: matched
        ? 'Verified: Dummy string encrypted with AES-256-GCM in memory, zero bytes written to localStorage, and decrypted roundtrip matched 100%.'
        : 'Self-test failed roundtrip or storage check.',
    };
  } catch (err: any) {
    return {
      success: false,
      storageMode: inApk ? 'ANDROID_KEYSTORE' : 'BROWSER_MEMORY_ONLY',
      storageBackendLabel: 'Error during self-test',
      dummyInputLength: dummyPlaintext.length,
      ciphertextPreview: 'ERROR',
      roundtripMatched: false,
      localStoragePlaintextLeak: false,
      localStorageSecretKeyCount: countSecretsInLocalStorage(),
      timestamp: new Date().toISOString(),
      details: err?.message || 'Vault self-test exception',
    };
  }
}

export function countSecretsInLocalStorage(): number {
  let count = 0;
  try {
    if (typeof localStorage !== 'undefined') {
      for (const key of [...PROTECTED_SECRET_KEYS, ...DEPRECATED_PURGED_SECRET_KEYS]) {
        if (localStorage.getItem(key) !== null) {
          count++;
        }
      }
    }
  } catch {
    // ignore
  }
  return count;
}
