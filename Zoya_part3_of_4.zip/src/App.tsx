import React, { useState, useEffect, useRef } from 'react';
import { ZoyaAvatarDisplay, AvatarStyle } from './components/ZoyaAvatarDisplay';
import {
  ANIME_3D_AVATARS,
  getAllAvatars,
  getSaved3DAvatarId,
  save3DAvatarId,
  getIs3DAvatarEnabled,
  saveIs3DAvatarEnabled,
  get3DAvatarScale,
  save3DAvatarScale,
  get3DAvatarOffsetY,
  save3DAvatarOffsetY,
  type Anime3DAvatar,
} from './data/anime3DAvatars';
import { ZoyaSettingsModal } from './components/ZoyaSettingsModal';
import { ZoyaMenuDrawer } from './components/ZoyaMenuDrawer';
import { ZoyaMemoryModal } from './components/ZoyaMemoryModal';
import { ZoyaHistoryModal, HistoryItem } from './components/ZoyaHistoryModal';
import { DiagnosticDashboard } from './components/DiagnosticDashboard';
import { TtsDiagnosticModal } from './components/TtsDiagnosticModal';

// 7 Action Modals
import { AppLauncherModal } from './components/actions/AppLauncherModal';
import { PhoneCallModal } from './components/actions/PhoneCallModal';
import { MessageComposerModal } from './components/actions/MessageComposerModal';
import {
  WebsiteBuilderModal,
  websiteBuilderController,
  triggerVoiceWebsiteBuild,
  isWaitingForWebsiteRequirements,
  type WebsiteBuilderState,
} from './components/actions/WebsiteBuilderModal';
import {
  isWebsiteIntentPrompt,
  isExplicitWebsiteEditIntent,
} from './services/websiteBuilderUtils';
import { SketchCanvasModal } from './components/actions/SketchCanvasModal';
import { FullVoiceCallModal } from './components/actions/FullVoiceCallModal';
import { TextChatModal } from './components/actions/TextChatModal';
import { YouTubeResultsModal } from './components/actions/YouTubeResultsModal';
import { PythonStudioModal } from './components/actions/PythonStudioModal';
import { CodingAgentModal } from './components/actions/CodingAgentModal';
import { youtubeManager, YouTubeVideo } from './services/youtubeManager';
import { All14LivingAvatarsShowcase } from './components/avatar/All14LivingAvatarsShowcase';

import { 
  Menu, 
  Settings, 
  Mic,
  Play,
  Square,
  Sparkles,
  Send,
  MessageSquare,
  Image as ImageIcon,
  FileText,
  Home,
  Brain,
  History,
  X,
  Volume2,
  ChevronDown,
  ChevronUp,
  RefreshCw,
  ExternalLink,
  AlertTriangle,
  Code,
  Terminal,
  Activity,
  Globe,
} from 'lucide-react';
import { LatencyLogModal } from './components/LatencyLogModal';
import {
  latencyLogger,
  selectOptimalModelForRequest,
  splitVoiceReplyAndVisualCard,
} from './services/latencyLogger';
import type { ExtractedFile } from './types/zip';
import { AssistantState, HardwareStateInfo, SpeechRecognizerListener } from './services/speech/SpeechTypes';
import { speechManager, MicPermissionState } from './services/speech/SpeechRecognizerManager';
import { tonePlayer } from './services/speech/AudioTonePlayer';
import { MorphingSphere } from './components/voice/MorphingSphere';
import { VoiceInteractionOverlay } from './components/voice/VoiceInteractionOverlay';
import {
  getLanguageConfig,
  getLiveSpeechLanguageCode,
  getLocalizedTemplates,
  getLocalizedZoyaReply,
  getSelectedLanguageLabel,
} from './services/languageConfig';
import { detectPart1SkillIntent } from './services/zoyaSkillsPart1';
import { zoyaMemory, PipelineStatus, PipelineTransferEvent } from './services/zoyaMemoryEngine';
import { androidAccessibility } from './services/androidAccessibility';
import { themeManager } from './services/themeManager';
import { FloatingHologramOverlay } from './components/voice/FloatingHologramOverlay';
import { hologramManager } from './services/zoyaHologramManager';
import { batteryAlertSystem } from './services/battery/batteryAlertSystem';
import { micStateMachine, MicStateSnapshot } from './services/speech/MicStateMachine';
import { getDecryptedSecretSync } from './services/secretVault';
import { agentClient } from './services/agent/agentClient';
import { geminiLiveVoiceClient, MIC_PERMISSION_DENIED_HI } from './services/speech/GeminiLiveVoiceClient';
import { ZoyaSmallListeningIndicator } from './components/voice/ZoyaSmallListeningIndicator';
import { zoyaVoiceManager } from './services/zoyaVoiceManager';
import { useGlobalMic } from './contexts/GlobalMicContext';
import { audioLevelStore } from './services/speech/audioLevelStore';
import { MicSoundWaves } from './components/voice/MicSoundWaves';
import { voiceTelemetry } from './services/voiceTelemetry';

// In-memory client audio cache to prevent redundant TTS network requests
const clientTtsAudioCache = new Map<string, { audioData: string; mimeType: string }>();

async function withTimeout<T>(promise: Promise<T>, ms: number, fallback: T, label: string): Promise<T> {
  let timer: ReturnType<typeof setTimeout> | null = null;
  try {
    return await Promise.race([
      promise,
      new Promise<T>((resolve) => {
        timer = setTimeout(() => {
          console.warn(`[TIMEOUT_GUARD] ${label} exceeded ${ms}ms; continuing with fallback`);
          resolve(fallback);
        }, ms);
      }),
    ]);
  } catch (err) {
    console.warn(`[TIMEOUT_GUARD] ${label} rejected:`, err);
    return fallback;
  } finally {
    if (timer) clearTimeout(timer);
  }
}

export default function App() {
  const {
    isGlobalMicOn,
    micPhase,
    setGlobalMicOn,
    setMicPhase,
    setActiveEngine,
    setAudioLevel: setGlobalAudioLevel,
    setIsUserSpeaking: setGlobalUserSpeaking,
    setMicError: setGlobalMicError,
    registerStopHandler,
    registerToggleHandler,
  } = useGlobalMic();
  const isGlobalMicOnRef = useRef<boolean>(isGlobalMicOn);
  isGlobalMicOnRef.current = isGlobalMicOn;

  // Navigation & Modal State
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [settingsInitialSection, setSettingsInitialSection] = useState<'general' | 'instagram_growth' | 'hologram' | 'avatar' | 'language' | 'voice_system' | 'api_key' | 'tool_api_keys' | 'memory' | 'accessibility' | 'device_lock' | 'appearance' | 'youtube' | 'python_studio' | 'mode' | 'battery_alerts'>('general');
  const [chatInitialPrompt, setChatInitialPrompt] = useState('');
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isMemoryOpen, setIsMemoryOpen] = useState(false);
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);
  const [showDiagnosticModal, setShowDiagnosticModal] = useState(false);
  const [showTtsDiagnosticModal, setShowTtsDiagnosticModal] = useState(false);
  const [showLatencyLogModal, setShowLatencyLogModal] = useState(false);
  const [show14LivingShowcase, setShow14LivingShowcase] = useState(false);
  const [appTheme, setAppTheme] = useState(() => themeManager.getTheme());

  // YouTube Results Modal State
  const [showYouTubeModal, setShowYouTubeModal] = useState(false);
  const [youtubeModalTitle, setYoutubeModalTitle] = useState('YouTube Music Search');
  const [youtubeModalSinger, setYoutubeModalSinger] = useState('');
  const [youtubeModalVideos, setYoutubeModalVideos] = useState<YouTubeVideo[]>([]);

  const [wakeWordNotice, setWakeWordNotice] = useState<{ message: string; type: 'info' | 'warning' | 'error' } | null>(null);

  useEffect(() => {
    const handleTheme = () => setAppTheme(themeManager.getTheme());
    const handleOpenTtsDiagnostic = () => setShowTtsDiagnosticModal(true);
    window.addEventListener('zoya-theme-changed', handleTheme);
    window.addEventListener('open-tts-diagnostic', handleOpenTtsDiagnostic);
    return () => {
      window.removeEventListener('zoya-theme-changed', handleTheme);
      window.removeEventListener('open-tts-diagnostic', handleOpenTtsDiagnostic);
    };
  }, []);

  // ZoyaService "Hey Zoya" Wake-Word & Voice Command Native Bridge Event Integration
  useEffect(() => {
    const handleWakeDetected = () => {
      console.log('[WAKE_WORD_EVENT] ZoyaService wake-word detected');
      voiceTelemetry.update('wakeWord', {
        isOk: true,
        stateText: 'DETECTED',
        detail: 'Native ZoyaService wake word detected',
      });
      setWakeWordNotice({ message: '🗣️ "Hey Zoya" wake word detected!', type: 'info' });
      setTimeout(() => setWakeWordNotice(null), 4500);
    };

    const handleVoiceCommand = (e: any) => {
      const command = e?.detail?.command;
      if (typeof command === 'string' && command.trim().length > 0) {
        const cleanCmd = command.trim();
        console.log('[VOICE_COMMAND_EVENT] Received spoken command from ZoyaService:', cleanCmd);
        setLiveTranscript(cleanCmd);
        voiceTelemetry.update('stt', {
          isOk: true,
          stateText: 'WORKING',
          detail: `Bridge voice command: "${cleanCmd}"`,
        });
        // Call handleProcessUserQueryRef directly with command text (fixes stale closure)
        void handleProcessUserQueryRef.current(cleanCmd, 'voice');
      }
    };

    const handleSystemToast = (e: any) => {
      const msg = e?.detail?.message;
      if (msg) {
        setWakeWordNotice({ message: msg, type: 'info' });
        setTimeout(() => setWakeWordNotice(null), 5000);
      }
    };

    window.addEventListener('wake-word-detected', handleWakeDetected);
    window.addEventListener('zoya-voice-command', handleVoiceCommand);
    window.addEventListener('zoya-system-toast', handleSystemToast);

    return () => {
      window.removeEventListener('wake-word-detected', handleWakeDetected);
      window.removeEventListener('zoya-voice-command', handleVoiceCommand);
      window.removeEventListener('zoya-system-toast', handleSystemToast);
    };
  }, []);

  // 7 Action Modals State
  const [showAppLauncher, setShowAppLauncher] = useState(false);
  const [showPhoneCall, setShowPhoneCall] = useState(false);
  const [callContact, setCallContact] = useState('Mummy');
  const [showMessageComposer, setShowMessageComposer] = useState(false);
  const [messageRecipient, setMessageRecipient] = useState('Papa');
  const [showWebsiteBuilder, setShowWebsiteBuilder] = useState(false);
  const [websitePrompt, setWebsitePrompt] = useState('');
  const [websiteBuildState, setWebsiteBuildState] = useState<WebsiteBuilderState>(() =>
    websiteBuilderController.getState()
  );

  useEffect(() => {
    return websiteBuilderController.subscribe((next) => setWebsiteBuildState(next));
  }, []);
  const [showSketchCanvas, setShowSketchCanvas] = useState(false);
  const [selectedSketchFile, setSelectedSketchFile] = useState<File | null>(null);
  const sketchFileInputRef = useRef<HTMLInputElement | null>(null);
  const [showVoiceCall, setShowVoiceCall] = useState(false);
  const [showTextChat, setShowTextChat] = useState(false);
  const [showPythonStudio, setShowPythonStudio] = useState(false);
  const [pythonInitialPrompt, setPythonInitialPrompt] = useState('');
  const [showCodingAgent, setShowCodingAgent] = useState(false);

  // Voice & Input State
  const [inputText, setInputText] = useState('');
  const [assistantState, setAssistantState] = useState<AssistantState>(AssistantState.IDLE);
  const [voiceStatus, setVoiceStatus] = useState<'idle' | 'listening' | 'processing' | 'speaking'>('idle');
  const [liveTranscript, setLiveTranscript] = useState('');
  const [isVoiceOverlayOpen, setIsVoiceOverlayOpen] = useState<boolean>(false);
  const homeMicBtnRef = useRef<HTMLButtonElement | null>(null);

  const recognitionRef = useRef<any>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const animFrameRef = useRef<number | null>(null);

  // Speech Recognition Timers & State Guards
  const silenceTimerRef = useRef<any>(null);
  const maxListenTimerRef = useRef<any>(null);
  const transcriptAccumulatorRef = useRef<string>('');
  const isProcessingRef = useRef<boolean>(false);
  const hasErrorRef = useRef<boolean>(false);
  const lastMicTapRef = useRef<number>(0);
  const isMicTransitioningRef = useRef<boolean>(false);

  // Live Mic Diagnostics & Permission State (User STEP 1 & STEP 3 HUD)
  const [micPermissionState, setMicPermissionState] = useState<MicPermissionState>('not_asked');
  const [micDebugLog, setMicDebugLog] = useState<string>('Ready');
  const [lastMicError, setLastMicError] = useState<string>('None');
  const [showDebugHud, setShowDebugHud] = useState<boolean>(true);
  const [isIframe, setIsIframe] = useState<boolean>(false);
  const [recLanguage, setRecLanguage] = useState<string>(() => {
    try {
      const saved = localStorage.getItem('zoya_language');
      return saved ? getLanguageConfig(saved).code : 'hi-IN';
    } catch {
      return 'hi-IN';
    }
  });
  const recLanguageRef = useRef<string>(recLanguage);
  recLanguageRef.current = recLanguage;
  const [voiceWakeActive, setVoiceWakeActive] = useState<boolean>(false);
  const [isPersistentListening, setIsPersistentListening] = useState<boolean>(false);
  const [isWakeActive, setIsWakeActive] = useState<boolean>(false);
  const [hardwareState, setHardwareState] = useState<HardwareStateInfo>(speechManager.getHardwareState());
  const [micSnapshot, setMicSnapshot] = useState<MicStateSnapshot>(() => micStateMachine.getSnapshot());
  const [isLoveHandsFreeActive, setIsLoveHandsFreeActive] = useState<boolean>(false);
  const [loveVoiceEngine, setLoveVoiceEngine] = useState<'none' | 'gemini-live' | 'webspeech' | 'mediarecorder'>('none');
  const [micErrorNotice, setMicErrorNotice] = useState<string | null>(null);
  const isLoveHandsFreeActiveRef = useRef<boolean>(false);
  isLoveHandsFreeActiveRef.current = isLoveHandsFreeActive;
  const loveVoiceEngineRef = useRef<'none' | 'gemini-live' | 'webspeech' | 'mediarecorder'>('none');
  loveVoiceEngineRef.current = loveVoiceEngine;

  // Subscribe to central micStateMachine for single-source-of-truth status
  useEffect(() => {
    const unsub = micStateMachine.subscribe((snap) => {
      setMicSnapshot(snap);
      if (snap.state === 'CAPTURING' || snap.state === 'ACTIVATING') {
        setIsWakeActive(true);
        setIsButtonSpinning(true);
        if (isGlobalMicOnRef.current) {
          setMicPhase(snap.isUserSpeaking ? 'user_speaking' : 'listening');
        }
      } else if (snap.state === 'PROCESSING') {
        setIsWakeActive(true);
        setIsButtonSpinning(true);
        if (isGlobalMicOnRef.current) {
          setMicPhase('processing');
        }
      } else if (snap.state === 'SPEAKING') {
        setIsButtonSpinning(true);
        if (isGlobalMicOnRef.current) {
          setMicPhase('ai_speaking');
        }
      } else if (snap.state === 'STANDBY' || snap.state === 'OFF') {
        if (!isGlobalMicOnRef.current && !isLoveHandsFreeActiveRef.current) {
          setIsWakeActive(false);
          setIsButtonSpinning(false);
        }
      }
    });
    return unsub;
  }, [setMicPhase]);

  // Global mic active indicator: true whenever global always-on mic is ON
  const isMicActive =
    isGlobalMicOn ||
    isLoveHandsFreeActive ||
    micSnapshot.state === 'ACTIVATING' ||
    micSnapshot.state === 'CAPTURING';
  // Bottom center button continuous fan spin state:
  // Starts on recording start -> stays spinning during thinking gap -> stops when voice reply finishes playing
  const [isButtonSpinning, setIsButtonSpinning] = useState<boolean>(false);
  const pendingUtterancesCountRef = useRef<number>(0);
  const lastProcessedQueryRef = useRef<{ query: string; time: number }>({ query: '', time: 0 });
  const isInputFocusedRef = useRef<boolean>(false);
  const isVoiceInputRef = useRef<boolean>(false);
  const hasManualTextRef = useRef<boolean>(false);
  const lastSpokenReplyRef = useRef<{ text: string; time: number }>({ text: '', time: 0 });
  const browserTtsWatchdogRef = useRef<any>(null);
  const thinkingWatchdogRef = useRef<any>(null);
  const chatStreamAbortRef = useRef<AbortController | null>(null);
  const assistantStateRef = useRef<AssistantState>(assistantState);
  assistantStateRef.current = assistantState;
  const isPersistentListeningRef = useRef<boolean>(isPersistentListening);
  isPersistentListeningRef.current = isPersistentListening;
  const showTextChatRef = useRef<boolean>(showTextChat);
  showTextChatRef.current = showTextChat;

  // Automatic Listening toggle state (default ON, stored in localStorage)
  const [automaticListening, setAutomaticListening] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('zoya_automatic_listening');
      return saved !== null ? saved === 'true' : true;
    } catch {
      return true;
    }
  });
  const automaticListeningRef = useRef<boolean>(automaticListening);
  automaticListeningRef.current = automaticListening;

  const handleToggleAutomaticListening = async (enabled: boolean) => {
    setAutomaticListening(enabled);
    automaticListeningRef.current = enabled;
    try {
      localStorage.setItem('zoya_automatic_listening', String(enabled));
    } catch {}

    if (!enabled) {
      console.log('[GLOBAL_MIC] Automatic listening toggled OFF');
      await stopGlobalMicSession();
    } else {
      console.log('[GLOBAL_MIC] Automatic listening toggled ON');
      await startGlobalMicSession();
    }
  };

  // Check initial permission state and auto-start listening on mount if automaticListening is true
  useEffect(() => {
    // Purge any legacy half avatar storage entries if present in browser
    try {
      Object.keys(localStorage).forEach((key) => {
        if (key.includes('half_avatar')) {
          localStorage.removeItem(key);
        }
      });
    } catch {}

    setIsIframe(speechManager.isInsideIframe());
    let disposed = false;
    let gestureArmed = false;

    const armFirstGestureFallback = () => {
      if (gestureArmed || disposed) return;
      gestureArmed = true;
      const onFirstGesture = () => {
        window.removeEventListener('pointerdown', onFirstGesture, true);
        window.removeEventListener('keydown', onFirstGesture, true);
        window.removeEventListener('click', onFirstGesture, true);
        gestureArmed = false;
        if (!disposed && automaticListeningRef.current && !isGlobalMicOnRef.current) {
          console.log('[GLOBAL_MIC] First user gesture detected -> starting automatic listening');
          void startGlobalMicSessionRef.current();
        }
      };
      window.addEventListener('pointerdown', onFirstGesture, true);
      window.addEventListener('keydown', onFirstGesture, true);
      window.addEventListener('click', onFirstGesture, true);
    };

    speechManager.checkPermissionSilently().then(async (state) => {
      if (disposed) return;
      setMicPermissionState(state);
      if (automaticListeningRef.current && !isGlobalMicOnRef.current) {
        console.log('[GLOBAL_MIC] Auto-starting global listening on mount (permission:', state, ')');
        const started = await startGlobalMicSessionRef.current();
        if (!started && !disposed && automaticListeningRef.current) {
          console.log('[GLOBAL_MIC] Auto-start deferred by browser policy; armed on first user gesture');
          armFirstGestureFallback();
        }
      }
    });

    return () => {
      disposed = true;
    };
  }, []);

  // Avatar & Voice Persona Settings (Persisted across refreshes and Memory System toggles)
  const [avatarStyle, setAvatarStyleState] = useState<AvatarStyle>(() => {
    try {
      const saved = localStorage.getItem('zoya_saved_avatar_style_v1') as AvatarStyle | null;
      if (saved === 'classic') {
        return saved;
      }
      return 'classic';
    } catch {
      return 'classic';
    }
  });

  const setAvatarStyle = (style: AvatarStyle) => {
    setAvatarStyleState(style);
    try {
      localStorage.setItem('zoya_saved_avatar_style_v1', style);
    } catch {}
  };

  const [selected3DAvatarId, setSelected3DAvatarId] = useState<string>(() => getSaved3DAvatarId());
  const [is3DAvatarActive, setIs3DAvatarActive] = useState<boolean>(() => getIs3DAvatarEnabled());
  const [avatarScale, setAvatarScale] = useState<number>(() => get3DAvatarScale());
  const [avatarOffsetY, setAvatarOffsetY] = useState<number>(() => get3DAvatarOffsetY());

  // Listen to cross-component permanent avatar events to ensure instantaneous synchronization
  useEffect(() => {
    const handleAvatarSelectedEvent = (e: Event) => {
      const customEvent = e as CustomEvent<{ avatarId: string }>;
      const nextId = customEvent.detail?.avatarId;
      if (nextId) {
        setSelected3DAvatarId(nextId);
        setIs3DAvatarActive(true);
      }
    };
    const handleAvatarEnabledEvent = (e: Event) => {
      const customEvent = e as CustomEvent<{ enabled: boolean }>;
      if (typeof customEvent.detail?.enabled === 'boolean') {
        setIs3DAvatarActive(customEvent.detail.enabled);
      }
    };
    window.addEventListener('zoya-avatar-selected', handleAvatarSelectedEvent);
    window.addEventListener('zoya-avatar-enabled-changed', handleAvatarEnabledEvent);
    return () => {
      window.removeEventListener('zoya-avatar-selected', handleAvatarSelectedEvent);
      window.removeEventListener('zoya-avatar-enabled-changed', handleAvatarEnabledEvent);
    };
  }, []);

  // Active Avatar Key across gallery 3D anime and classic styles (selected avatar takes priority)
  const currentAvatarKey = is3DAvatarActive ? selected3DAvatarId : avatarStyle;

  const memoryBgIframeRef = useRef<HTMLIFrameElement | null>(null);

  // 3D Memory System Background (Default OFF so the Cosmic Purple Stage, Spotlight, Glowing Rings & Zoya Avatar show on Home Screen)
  const [use3DMemoryBackground, setUse3DMemoryBackground] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('zoya_use_3d_memory_bg_v3');
      return saved === null ? false : saved === 'true';
    } catch {
      return false;
    }
  });

  const handleToggle3DMemoryBackground = (enabled: boolean) => {
    if (enabled) {
      setUse3DMemoryBackground(true);
      try {
        localStorage.setItem('zoya_use_3d_memory_bg_v3', 'true');
      } catch {}
    } else {
      // OFF = Remove 3D Memory System from Home Screen and restore avatar without overwriting selected avatar
      setUse3DMemoryBackground(false);
      try {
        localStorage.setItem('zoya_use_3d_memory_bg_v3', 'false');
      } catch {}
    }
  };

  const handleSelect3DAvatar = (id: string) => {
    if (!id) return;
    setSelected3DAvatarId(id);
    save3DAvatarId(id);
    setIs3DAvatarActive(true);
    saveIs3DAvatarEnabled(true);
    if (id === 'classic') {
      setAvatarStyleState(id as AvatarStyle);
    }
    // If Memory System was ON on Home Screen, activating an avatar restores the avatar to Home Screen without overlap
    if (use3DMemoryBackground) {
      setUse3DMemoryBackground(false);
      try {
        localStorage.setItem('zoya_use_3d_memory_bg_v3', 'false');
      } catch {}
    }
  };

  useEffect(() => {
    (window as any).__zoyaSelectAvatar = (id: string) => {
      handleSelect3DAvatar(id);
    };
  }, []);

  const handleToggle3DAvatar = (id: string) => {
    if (!use3DMemoryBackground && is3DAvatarActive && selected3DAvatarId === id) {
      // User explicitly turned OFF the active avatar
      setIs3DAvatarActive(false);
      saveIs3DAvatarEnabled(false);
    } else {
      // User turned ON or switched to this avatar
      handleSelect3DAvatar(id);
    }
  };

  const handleToggle3DAvatarGlobal = (enabled: boolean) => {
    setIs3DAvatarActive(enabled);
    saveIs3DAvatarEnabled(enabled);
    if (enabled && use3DMemoryBackground) {
      setUse3DMemoryBackground(false);
      try {
        localStorage.setItem('zoya_use_3d_memory_bg_v3', 'false');
      } catch {}
    }
  };

  const handleChangeAvatarScale = (scale: number) => {
    setAvatarScale(scale);
    save3DAvatarScale(scale);
  };

  const handleChangeAvatarOffsetY = (offset: number) => {
    setAvatarOffsetY(offset);
    save3DAvatarOffsetY(offset);
  };

  const handleResetAvatarControls = () => {
    setAvatarScale(1.0);
    save3DAvatarScale(1.0);
    setAvatarOffsetY(0);
    save3DAvatarOffsetY(0);
  };

  const [personaMode, setPersonaMode] = useState<string>(() => {
    try {
      const saved = localStorage.getItem('zoya_persona_mode');
      if (saved) return saved;
      return 'girlfriend';
    } catch {
      return 'girlfriend';
    }
  });

  const personaModeRef = useRef<string>(personaMode);
  personaModeRef.current = personaMode;

  const getSelectedGeminiVoiceName = (): string => {
    try {
      const id = (localStorage.getItem('zoya_selected_voice_id') || 'gemini-kore').toLowerCase();
      if (id.includes('aoede')) return 'Aoede';
      if (id.includes('zephyr')) return 'Zephyr';
      if (id.includes('puck')) return 'Puck';
      if (id.includes('charon')) return 'Charon';
      if (id.includes('fenrir')) return 'Fenrir';
    } catch {}
    return 'Kore';
  };

  const handleSetPersonaMode = (mode: string) => {
    setPersonaMode(mode);
    personaModeRef.current = mode;
    try {
      localStorage.setItem('zoya_persona_mode', mode);
    } catch {}

    // Keep global mic ON when switching modes: silently update background Live session if running
    if (isGlobalMicOnRef.current && geminiLiveVoiceClient.isRunning()) {
      console.log('[GLOBAL_MIC] Mode switched -> keeping mic ON and updating live session:', mode);
      geminiLiveVoiceClient
        .reconnectWithOptions({
          personaMode: mode,
          language: recLanguageRef.current,
          voiceName: getSelectedGeminiVoiceName(),
        })
        .catch(() => {});
    }
  };

  // Live Memory Pipeline status for the 3D Memory System Background
  const [memoryPipelineStatus, setMemoryPipelineStatus] = useState<PipelineStatus>(() =>
    zoyaMemory.getPipelineStatus()
  );
  const [memoryActiveTransfer, setMemoryActiveTransfer] = useState<PipelineTransferEvent | null>(null);

  useEffect(() => {
    const unsub = zoyaMemory.subscribePipeline((evt) => {
      setMemoryPipelineStatus(evt.status);
      setMemoryActiveTransfer(evt);
      if (memoryBgIframeRef.current?.contentWindow) {
        const modeLower = (evt.sourceMode || 'girlfriend').toLowerCase();
        const boxId =
          modeLower === 'professional' || modeLower === 'teacher' || modeLower === 'hungry'
            ? 'tara'
            : modeLower === 'developer' || modeLower === 'custom'
            ? 'soyat'
            : modeLower === 'funny' || modeLower === 'nautanki'
            ? 'inamui'
            : 'zoya';
        memoryBgIframeRef.current.contentWindow.postMessage(
          {
            type: 'ZOYA_MEMORY_TRANSFER_EVENT',
            fromBoxId: boxId,
            fromMode: evt.sourceMode,
            summary: evt.title || evt.details || '⚡ Memory Integrated',
          },
          '*'
        );
      }
    });
    return unsub;
  }, []);
  const [voiceSpeed, setVoiceSpeed] = useState<number>(1.0);
  const [voiceVolume, setVoiceVolume] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('zoya_voice_volume');
      return saved ? parseInt(saved, 10) : 85;
    } catch {
      return 85;
    }
  });

  const handleSetVoiceVolume = (vol: number) => {
    setVoiceVolume(vol);
    try {
      localStorage.setItem('zoya_voice_volume', String(vol));
    } catch {}
  };

  const handleSetLanguage = async (langCode: string) => {
    const config = getLanguageConfig(langCode);
    const speechLanguageCode = getLiveSpeechLanguageCode(config.code);
    const selectedLanguage = getSelectedLanguageLabel(config.code);

    console.log('[LANGUAGE_SETTING] Settings language selected:', {
      selectedLanguage,
      settingsCode: config.code,
      speechConfigLanguageCode: speechLanguageCode,
      globalMicOn: isGlobalMicOnRef.current,
    });

    setRecLanguage(config.code);
    recLanguageRef.current = config.code;
    try {
      localStorage.setItem('zoya_language', config.code);
    } catch {}

    setMicDebugLog(`भाषा: ${config.nativeName} (${speechLanguageCode})`);

    // Keep global mic ON when changing language: silently swap Live WS session or update STT/TTS target language
    if (isGlobalMicOnRef.current && geminiLiveVoiceClient.isRunning()) {
      console.log(
        `[GLOBAL_MIC] Silently reconnecting Live session for new language selectedLanguage="${selectedLanguage}", languageCode=${speechLanguageCode}`
      );
      stopAllAudioPlayback();
      isProcessingRef.current = false;
      setMicPhase('listening');
      await geminiLiveVoiceClient
        .reconnectWithOptions({
          personaMode: personaModeRef.current,
          language: config.code,
          voiceName: getSelectedGeminiVoiceName(),
        })
        .catch(() => {});
      return;
    }

    if (isGlobalMicOnRef.current || isLoveHandsFreeActiveRef.current) {
      console.log(
        `[GLOBAL_MIC] Updating continuous voice session language (mic stays ON) -> selectedLanguage="${selectedLanguage}", languageCode=${speechLanguageCode}`
      );
      stopAllAudioPlayback();
      isProcessingRef.current = false;
      setMicPhase('listening');
      await speechManager.setLanguage(config.code);
      speechManager.resumeAfterAssistantSpeaking();
      micStateMachine.reportExternalLiveState('CAPTURING', 'सुन रहा है');
      return;
    }

    // Update STT recognition engine language immediately
    speechManager.setLanguage(config.code);
  };

  const [archiveFiles] = useState<ExtractedFile[]>([]);

  // Subscribe home mic button scale directly to external audioLevelStore (zero root App re-renders)
  useEffect(() => {
    const unsub = audioLevelStore.subscribe((lvl) => {
      if (homeMicBtnRef.current) {
        homeMicBtnRef.current.style.transform = `scale(${1 + lvl * 0.12})`;
      }
    });
    return unsub;
  }, []);

  // Clean up audio and speech manager on unmount
  useEffect(() => {
    return () => {
      if (thinkingWatchdogRef.current) {
        clearTimeout(thinkingWatchdogRef.current);
        thinkingWatchdogRef.current = null;
      }
      if (chatStreamAbortRef.current) {
        try {
          chatStreamAbortRef.current.abort();
        } catch {}
        chatStreamAbortRef.current = null;
      }
      geminiLiveVoiceClient.stop().catch(() => {});
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        try {
          window.speechSynthesis.cancel();
        } catch {}
      }
      speechManager.destroy();
      stopAudioAnalysis();
      clearTimeout(silenceTimerRef.current);
      clearTimeout(maxListenTimerRef.current);
      if (recognitionRef.current) {
        try {
          recognitionRef.current.abort();
        } catch (err) {
          console.error('Error aborting speech recognition on cleanup:', err);
        }
      }
    };
  }, []);

  const stopAudioAnalysis = () => {
    if (animFrameRef.current) {
      cancelAnimationFrame(animFrameRef.current);
      animFrameRef.current = null;
    }
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach((t) => t.stop());
      mediaStreamRef.current = null;
    }
    if (audioContextRef.current) {
      const ctx = audioContextRef.current;
      audioContextRef.current = null;
      if (ctx.state !== 'closed') {
        try {
          Promise.resolve(ctx.close()).catch(() => {});
        } catch {}
      }
    }
    audioLevelStore.set(0);
  };

  // Add interaction to history
  const logToHistory = (type: HistoryItem['type'], title: string, detail: string) => {
    try {
      const saved = localStorage.getItem('zoya_action_history');
      const list: HistoryItem[] = saved ? JSON.parse(saved) : [];
      const now = new Date();
      const timeStr = `आज, ${now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
      const newItem: HistoryItem = {
        id: `hist-${Date.now()}`,
        type,
        title,
        detail,
        timestamp: timeStr,
      };
      localStorage.setItem('zoya_action_history', JSON.stringify([newItem, ...list.slice(0, 30)]));
    } catch (err) {
      console.error('Failed to log action to history in localStorage:', err);
    }
  };

  // Reference to active server TTS audio playback context, source, and HTML5 Audio element
  const ttsEpochRef = useRef<number>(0);
  const currentTtsCtxRef = useRef<AudioContext | null>(null);
  const currentTtsSourceRef = useRef<AudioBufferSourceNode | null>(null);
  const currentHtmlAudioRef = useRef<HTMLAudioElement | null>(null);

  // Streaming speech queue for instant sentence-by-sentence TTS playback (preserving per-chunk onDone)
  const speechQueueRef = useRef<Array<{ text: string; onDone?: () => void }>>([]);
  const isPlayingQueueRef = useRef<boolean>(false);

  const clearThinkingWatchdog = () => {
    if (thinkingWatchdogRef.current) {
      clearTimeout(thinkingWatchdogRef.current);
      thinkingWatchdogRef.current = null;
    }
  };

  const startThinkingWatchdog = () => {
    clearThinkingWatchdog();
    thinkingWatchdogRef.current = setTimeout(() => {
      thinkingWatchdogRef.current = null;
      console.warn('[GLOBAL_VOICE_CHAIN] [THINKING_WATCHDOG] Processing exceeded 20000ms; recovering cleanly');
      if (chatStreamAbortRef.current) {
        try {
          chatStreamAbortRef.current.abort();
        } catch {}
        chatStreamAbortRef.current = null;
      }
      isProcessingRef.current = false;
      if (!isPlayingQueueRef.current && speechQueueRef.current.length === 0) {
        speechManager.resumeAfterAssistantSpeaking();
        micStateMachine.reportSpeakEnd('thinking_watchdog');
        if (isGlobalMicOnRef.current || isLoveHandsFreeActiveRef.current) {
          setAssistantState(AssistantState.LISTENING);
          setVoiceStatus('listening');
          setMicPhase('listening');
          setIsButtonSpinning(true);
        } else {
          setIsButtonSpinning(false);
          setAssistantState(AssistantState.IDLE);
          setVoiceStatus('idle');
          setMicPhase('off');
          setIsWakeActive(false);
        }
      }
    }, 20000);
  };

  // Stop any active TTS audio (Server AudioContext, HTML5 Audio, Web SpeechSynthesis, and Gemini Live playback)
  const stopAllAudioPlayback = () => {
    speechQueueRef.current = [];
    isPlayingQueueRef.current = false;
    ttsEpochRef.current++; // Invalidate any pending network response or decode
    speechManager.stopBargeInMonitor();
    geminiLiveVoiceClient.interruptPlayback();
    if (browserTtsWatchdogRef.current) {
      clearTimeout(browserTtsWatchdogRef.current);
      browserTtsWatchdogRef.current = null;
    }
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      try {
        window.speechSynthesis.cancel();
      } catch {}
    }
    if (currentHtmlAudioRef.current) {
      try {
        currentHtmlAudioRef.current.pause();
        currentHtmlAudioRef.current.src = '';
      } catch {}
      currentHtmlAudioRef.current = null;
    }
    if (currentTtsSourceRef.current) {
      try {
        currentTtsSourceRef.current.stop();
        currentTtsSourceRef.current.disconnect();
      } catch {}
      currentTtsSourceRef.current = null;
    }
    if (currentTtsCtxRef.current) {
      const ctx = currentTtsCtxRef.current;
      currentTtsCtxRef.current = null;
      if (ctx.state !== 'closed') {
        try {
          Promise.resolve(ctx.close()).catch(() => {});
        } catch {}
      }
    }
  };

  const handlePlaybackEnd = (onDone?: () => void) => {
    clearThinkingWatchdog();
    if (browserTtsWatchdogRef.current) {
      clearTimeout(browserTtsWatchdogRef.current);
      browserTtsWatchdogRef.current = null;
    }
    if (speechQueueRef.current.length > 0) {
      if (onDone) {
        try {
          onDone();
        } catch (cbErr) {
          console.warn('[TTS_PIPELINE] Chunk onDone callback error:', cbErr);
        }
      }
      playNextSpeechQueueChunk();
      return;
    }
    console.log('[GLOBAL_VOICE_CHAIN] [4. TTS_END] Voice playback ended completely.');
    speechManager.stopBargeInMonitor();
    geminiLiveVoiceClient.pauseCaptureForExternalTts(false);
    isPlayingQueueRef.current = false;
    isProcessingRef.current = false;
    voiceTelemetry.update('speaker', {
      isOk: true,
      stateText: 'IDLE',
      detail: 'Speaker playback finished cleanly',
    });

    if (isGlobalMicOnRef.current || isLoveHandsFreeActiveRef.current) {
      // Keep global always-on mic listening right after reply ends across ALL modes
      lastSpokenReplyRef.current = { text: lastSpokenReplyRef.current.text, time: Date.now() };
      setAssistantState(AssistantState.LISTENING);
      setVoiceStatus('listening');
      setMicPhase('listening');
      setIsButtonSpinning(true);
      speechManager.resumeAfterAssistantSpeaking();
      micStateMachine.reportSpeakEnd('server_tts');
      if (onDone) {
        try {
          onDone();
        } catch (cbErr) {
          console.warn('[TTS_PIPELINE] Chunk onDone callback error:', cbErr);
        }
      }
      return;
    }

    lastSpokenReplyRef.current = { text: lastSpokenReplyRef.current.text, time: Date.now() };
    setIsButtonSpinning(false);
    setAssistantState(AssistantState.IDLE);
    setVoiceStatus('idle');
    setMicPhase('off');

    // Notify central micStateMachine of TTS finish.
    // The state machine enforces a 500ms post-TTS room reverb decay before resuming standby/ZoyaService.
    micStateMachine.reportSpeakEnd('server_tts');
    speechManager.resumeAfterAssistantSpeaking();
    setIsWakeActive(false);

    if (onDone) {
      try {
        onDone();
      } catch (cbErr) {
        console.warn('[TTS_PIPELINE] Chunk onDone callback error:', cbErr);
      }
    }
  };

  // Play a single TTS sentence chunk cleanly across neural engines only (ElevenLabs -> Gemini Flash -> Gemini Live; no robotic speechSynthesis)
  const playServerTtsChunk = async (text: string, onDone?: () => void) => {
    clearThinkingWatchdog();
    const epoch = ttsEpochRef.current;
    // Keep microphone echo-muted while Zoya is speaking, and pause Live capture during external TTS
    speechManager.pauseForAssistantSpeaking();
    geminiLiveVoiceClient.pauseCaptureForExternalTts(true);
    micStateMachine.reportSpeakStart('server_tts');
    setAssistantState(AssistantState.SPEAKING);
    setVoiceStatus('speaking');
    if (isGlobalMicOnRef.current) {
      setMicPhase('ai_speaking');
    }
    setIsButtonSpinning(true);
    if (isGlobalMicOnRef.current && !geminiLiveVoiceClient.isRunning()) {
      speechManager.startBargeInMonitor(() => {
        console.log('[GLOBAL_VOICE_CHAIN] User voice barge-in during TTS fallback -> interrupting AI & resuming mic');
        stopAllAudioPlayback();
        geminiLiveVoiceClient.pauseCaptureForExternalTts(false);
        isProcessingRef.current = false;
        setAssistantState(AssistantState.LISTENING);
        setVoiceStatus('listening');
        setMicPhase('listening');
        setIsButtonSpinning(true);
        speechManager.resumeAfterAssistantSpeaking();
        micStateMachine.reportSpeakInterrupted('user_barge_in');
        micStateMachine.reportSpeakEnd('user_barge_in');
      });
    }
    console.log('[GLOBAL_VOICE_CHAIN] [4. TTS_START] Speaking reply chunk:', text.slice(0, 80), '| lang:', recLanguageRef.current);

    let geminiApiKey = '';
    let elevenLabsVoiceId = '';
    let selectedVoiceId = '';
    try {
      geminiApiKey = getDecryptedSecretSync('zoya_gemini_api_key') || '';
      elevenLabsVoiceId = localStorage.getItem('zoya_elevenlabs_voice_id') || '';
      selectedVoiceId = localStorage.getItem('zoya_selected_voice_id') || 'gemini-kore';
    } catch {}

    const activeLang = recLanguageRef.current;
    const clientCacheKey = `${text.trim().toLowerCase()}::${selectedVoiceId}::${activeLang}`;
    let audioPayload: { audioData: string; mimeType: string; engine?: string } | null = null;
    let lastTtsError = '';

    const requestNeuralTts = async (forceEngine?: string) => {
      const ttsController = new AbortController();
      const ttsTimeout = setTimeout(() => ttsController.abort(), 11500);
      try {
        const res = await fetch('/api/tts', {
          method: 'POST',
          headers: agentClient.getOwnerFetchHeaders({ 'Content-Type': 'application/json' }),
          credentials: 'include',
          signal: ttsController.signal,
          body: JSON.stringify({
            text,
            personaMode,
            language: activeLang,
            selectedVoiceId,
            forceEngine,
            geminiApiKey: geminiApiKey || undefined,
            elevenLabsVoiceId: elevenLabsVoiceId || undefined,
          }),
        });
        const contentType = res.headers.get('content-type') || '';
        let data: any = null;
        if (contentType.includes('application/json')) {
          data = await res.json().catch(() => null);
        }
        if (!res.ok) {
          lastTtsError = data?.error || `HTTP ${res.status}`;
          return null;
        }
        if (data?.audioData) {
          return {
            audioData: data.audioData as string,
            mimeType: (data.mimeType as string) || 'audio/wav',
            engine: (data.engineUsed || data.engine || forceEngine || 'neural') as string,
          };
        }
        lastTtsError = data?.error || 'No neural audio returned';
        return null;
      } catch (reqErr: any) {
        lastTtsError = reqErr?.name === 'AbortError' ? 'TTS request timed out' : (reqErr?.message || String(reqErr));
        return null;
      } finally {
        clearTimeout(ttsTimeout);
      }
    };

    try {
      // 1. Check client memory cache
      if (clientTtsAudioCache.has(clientCacheKey)) {
        audioPayload = clientTtsAudioCache.get(clientCacheKey)!;
      } else {
        // 2. Primary automatic cascade on server (ElevenLabs -> Gemini Flash -> Gemini Live)
        audioPayload = await requestNeuralTts(undefined);
        if (epoch !== ttsEpochRef.current) return;

        // 3. Explicit retry on backup neural engines if auto call returned no audio (never fall back to robotic speechSynthesis)
        if (!audioPayload?.audioData) {
          console.warn('[SERVER_TTS] Auto /api/tts yielded no audio; retrying explicit Gemini Flash -> Gemini Live:', lastTtsError);
          for (const retryEngine of ['gemini-flash', 'gemini-live']) {
            if (epoch !== ttsEpochRef.current) return;
            const retryPayload = await requestNeuralTts(retryEngine);
            if (retryPayload?.audioData) {
              audioPayload = retryPayload;
              break;
            }
          }
        }

        if (audioPayload?.audioData) {
          clientTtsAudioCache.set(clientCacheKey, {
            audioData: audioPayload.audioData,
            mimeType: audioPayload.mimeType,
          });
        }
      }

      if (epoch !== ttsEpochRef.current) return;

      if (audioPayload?.audioData) {
        voiceTelemetry.update('tts', {
          isOk: true,
          stateText: 'WORKING',
          detail: `Audio generated via ${audioPayload.engine || 'neural TTS'}`,
        });

        const clampedVolume = Math.max(0, Math.min(1, voiceVolume / 100));

        // Primary Playback: Web Audio API decoding
        try {
          const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
          const ctx = new AudioCtx();
          currentTtsCtxRef.current = ctx;
          if (ctx.state === 'suspended') {
            await ctx.resume().catch(() => {});
          }

          const raw = atob(audioPayload.audioData);
          const bytes = new Uint8Array(raw.length);
          for (let i = 0; i < raw.length; i++) {
            bytes[i] = raw.charCodeAt(i);
          }

          const audioBuffer = await ctx.decodeAudioData(bytes.buffer.slice(0));
          if (epoch !== ttsEpochRef.current) {
            if (ctx.state !== 'closed') {
              try { Promise.resolve(ctx.close()).catch(() => {}); } catch {}
            }
            return;
          }

          const source = ctx.createBufferSource();
          source.buffer = audioBuffer;
          currentTtsSourceRef.current = source;

          const gainNode = ctx.createGain();
          gainNode.gain.setValueAtTime(clampedVolume, ctx.currentTime);

          source.connect(gainNode);
          gainNode.connect(ctx.destination);

          let ended = false;
          const finishAudioBuffer = () => {
            if (ended) return;
            ended = true;
            if (browserTtsWatchdogRef.current) {
              clearTimeout(browserTtsWatchdogRef.current);
              browserTtsWatchdogRef.current = null;
            }
            if (epoch === ttsEpochRef.current) {
              currentTtsSourceRef.current = null;
              currentTtsCtxRef.current = null;
              if (ctx.state !== 'closed') {
                try {
                  Promise.resolve(ctx.close()).catch(() => {});
                } catch {}
              }
              handlePlaybackEnd(onDone);
            }
          };

          const bufferWatchdogMs = Math.max(4000, Math.ceil((audioBuffer.duration || 4) * 1000) + 2500);
          browserTtsWatchdogRef.current = setTimeout(() => {
            console.warn('[SERVER_TTS] Web Audio playback watchdog triggered after', bufferWatchdogMs, 'ms');
            finishAudioBuffer();
          }, bufferWatchdogMs);

          source.onended = finishAudioBuffer;
          source.start(0);
          voiceTelemetry.update('speaker', {
            isOk: true,
            stateText: 'PLAYING',
            detail: `Playing ${audioPayload.mimeType} via Web Audio (${audioBuffer.duration.toFixed(1)}s)`,
          });
          return;
        } catch (decodeErr) {
          console.warn('[SERVER_TTS] Web Audio decode failed, trying HTML5 Audio:', decodeErr);
          if (epoch !== ttsEpochRef.current) return;
          // Secondary Playback: HTML5 Audio element using Blob URL
          try {
            const raw = atob(audioPayload.audioData);
            const bytes = new Uint8Array(raw.length);
            for (let i = 0; i < raw.length; i++) {
              bytes[i] = raw.charCodeAt(i);
            }
            const blob = new Blob([bytes], { type: audioPayload.mimeType || 'audio/wav' });
            const blobUrl = URL.createObjectURL(blob);
            const audio = new Audio(blobUrl);
            audio.volume = clampedVolume;
            currentHtmlAudioRef.current = audio;

            audio.onended = () => {
              URL.revokeObjectURL(blobUrl);
              if (epoch === ttsEpochRef.current) {
                currentHtmlAudioRef.current = null;
                handlePlaybackEnd(onDone);
              }
            };
            audio.onerror = (audioEv) => {
              const evLabel = typeof audioEv === 'string' ? audioEv : audioEv?.type || 'error';
              console.warn('[SERVER_TTS] HTML5 Audio element playback notice:', evLabel);
              voiceTelemetry.update('speaker', {
                isOk: false,
                health: 'fail',
                stateText: 'NOT PLAYING',
                detail: `HTML5 Audio error: ${evLabel}`,
                error: String(evLabel),
              });
              URL.revokeObjectURL(blobUrl);
              if (epoch === ttsEpochRef.current) {
                currentHtmlAudioRef.current = null;
                handlePlaybackEnd(onDone);
              }
            };
            await audio.play();
            voiceTelemetry.update('speaker', {
              isOk: true,
              stateText: 'PLAYING',
              detail: `Playing ${audioPayload.mimeType} via HTML5 Audio`,
            });
            return;
          } catch (htmlAudioErr: any) {
            console.warn('[SERVER_TTS] HTML5 Audio fallback failed:', htmlAudioErr);
            voiceTelemetry.update('speaker', {
              isOk: false,
              health: 'fail',
              stateText: 'NOT PLAYING',
              detail: htmlAudioErr?.message || 'HTML5 Audio play blocked',
              error: htmlAudioErr?.message || String(htmlAudioErr),
            });
          }
        }
      } else {
        voiceTelemetry.update('tts', {
          isOk: false,
          health: 'fail',
          stateText: 'FAILED',
          detail: lastTtsError || 'All 3 neural TTS engines failed to return audio',
          error: lastTtsError || 'All 3 neural TTS engines unavailable',
        });
        voiceTelemetry.update('speaker', {
          isOk: false,
          health: 'fail',
          stateText: 'NOT PLAYING',
          detail: 'Skipped speaker playback because TTS audio generation failed',
          error: lastTtsError || 'No TTS audio available',
        });
      }
    } catch (e: any) {
      const errMsg = e?.message || String(e);
      console.warn('[SERVER_TTS] Neural TTS fetch/playback error:', errMsg);
      voiceTelemetry.update('tts', {
        isOk: false,
        health: 'fail',
        stateText: 'FAILED',
        detail: errMsg,
        error: errMsg,
      });
    }

    if (epoch === ttsEpochRef.current) {
      handlePlaybackEnd(onDone);
    }
  };

  // Dispatch next sentence chunk from queue
  const playNextSpeechQueueChunk = () => {
    if (speechQueueRef.current.length === 0) {
      isPlayingQueueRef.current = false;
      handlePlaybackEnd();
      return;
    }
    isPlayingQueueRef.current = true;
    const nextItem = speechQueueRef.current.shift()!;
    playServerTtsChunk(nextItem.text, nextItem.onDone);
  };

  // Enqueue a sentence chunk to start speaking immediately or queue seamlessly
  const enqueueSpeechChunk = (text: string, onDone?: () => void) => {
    const clean = text.replace(/[*#_`]/g, '').trim();
    if (!clean) {
      if (onDone) {
        try {
          onDone();
        } catch {}
      }
      if (!isPlayingQueueRef.current && speechQueueRef.current.length === 0) {
        handlePlaybackEnd();
      }
      return;
    }
    const now = Date.now();
    const prev =
      isPlayingQueueRef.current &&
      now - lastSpokenReplyRef.current.time < 5000 &&
      lastSpokenReplyRef.current.text
        ? `${lastSpokenReplyRef.current.text} `
        : '';
    lastSpokenReplyRef.current = { text: `${prev}${clean}`.slice(-500), time: now };
    speechManager.pauseForAssistantSpeaking();
    speechQueueRef.current.push({ text: clean, onDone });
    if (!isPlayingQueueRef.current) {
      playNextSpeechQueueChunk();
    }
  };

  // Speak a message with natural Neural TTS (clears previous and enqueues)
  const playServerTtsAudio = (text: string, onDone?: () => void) => {
    stopAllAudioPlayback();
    enqueueSpeechChunk(text, onDone);
  };

  const speakResponse = (text: string, onDone?: () => void) => {
    stopAllAudioPlayback();
    enqueueSpeechChunk(text, onDone);
  };

  // Initialize Smart Battery Voice Alert System with natural TTS pipeline
  useEffect(() => {
    batteryAlertSystem.init((text: string, onDone?: () => void) => {
      speakResponse(text, onDone);
      setLiveTranscript(text);
    });
  }, []);

  // Stream AI response chunks into low-latency sequential TTS playback
  // Sentence-level streaming: starts speaking the very first complete sentence immediately,
  // and routes long outputs (code, websites, documents) to visual card instead of speaking them aloud!
  const streamAndSpeakResponse = async (queryText: string, originalQuery: string) => {
    isProcessingRef.current = true;
    setIsButtonSpinning(true); // KEEP SPINNING CONTINUOUSLY during thinking gap!
    setAssistantState(AssistantState.THINKING);
    setVoiceStatus('processing');

    const opt = selectOptimalModelForRequest(queryText);
    const reqLogId = latencyLogger.startRequest({
      query: queryText,
      source: 'voice',
      model: opt.model,
      relevantToolCount: opt.relevantTools.length,
    });

    const streamAbort = new AbortController();
    chatStreamAbortRef.current = streamAbort;
    let reader: ReadableStreamDefaultReader<Uint8Array> | null = null;
    let handedOffToPlayback = false;

    try {
      // Cancel previous speech before starting new answer
      stopAllAudioPlayback();
      startThinkingWatchdog();

      const activeMode = personaModeRef.current;

      // Step 1: Perform bounded hierarchical memory lookup (Mode Memory -> Central Main Memory -> Final Personal Memory)
      await withTimeout(
        zoyaMemory.retrieveHierarchical(activeMode, queryText),
        2500,
        [] as any,
        'zoyaMemory.retrieveHierarchical'
      );

      // Step 2: Inject persistent mode-isolated memories from memory engine (bounded)
      const userMemories = await withTimeout(
        zoyaMemory.getMemories(activeMode),
        2000,
        [] as any,
        'zoyaMemory.getMemories'
      );

      const activeLang = recLanguageRef.current;
      const activeLangConfig = getLanguageConfig(activeLang);
      console.log('[GLOBAL_VOICE_CHAIN] [3. AI_START] Sending query to /api/chat-stream:', {
        query: queryText,
        personaMode: activeMode,
        selectedLanguage: getSelectedLanguageLabel(activeLangConfig.code),
        settingsCode: activeLangConfig.code,
        languageCode: getLiveSpeechLanguageCode(activeLangConfig.code),
      });

      const openTimeout = setTimeout(() => streamAbort.abort(), 12000);
      let response: Response;
      try {
        response = await fetch('/api/chat-stream', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          signal: streamAbort.signal,
          body: JSON.stringify({
            message: queryText,
            personaMode: activeMode,
            language: activeLangConfig.code,
            memories: userMemories,
            relevantToolNames: opt.relevantTools.map((t) => t.name),
            fastMode: opt.isSimpleRequest,
          }),
        });
      } finally {
        clearTimeout(openTimeout);
      }

      if (!response.ok || !response.body) {
        voiceTelemetry.update('geminiApi', {
          isOk: false,
          health: 'fail',
          stateText: 'ERROR',
          detail: `/api/chat-stream HTTP ${response.status}`,
          error: `HTTP ${response.status}`,
        });
        throw new Error(`Streaming failed with status: ${response.status}`);
      }
      voiceTelemetry.update('geminiApi', {
        isOk: true,
        stateText: 'CONNECTED',
        detail: `/api/chat-stream streaming (${activeLangConfig.code})`,
      });

      reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';
      let pendingSentenceBuffer = '';
      let fullCollectedReply = '';
      let spokenSentencesCount = 0;
      let spokenCharCount = 0;
      let firstTokenMarked = false;
      let firstSpeechMarked = false;
      let streamDone = false;

      const CHUNK_INACTIVITY_TIMEOUT_MS = 9500;
      const readChunkWithTimeout = async () => {
        let chunkTimer: ReturnType<typeof setTimeout> | null = null;
        try {
          return await Promise.race([
            reader!.read(),
            new Promise<never>((_, reject) => {
              chunkTimer = setTimeout(() => {
                streamAbort.abort();
                reject(new Error('CHAT_STREAM_CHUNK_TIMEOUT'));
              }, CHUNK_INACTIVITY_TIMEOUT_MS);
            }),
          ]);
        } finally {
          if (chunkTimer) clearTimeout(chunkTimer);
        }
      };

      while (!streamDone) {
        let chunkResult: ReadableStreamReadResult<Uint8Array>;
        try {
          chunkResult = await readChunkWithTimeout();
        } catch (readErr: any) {
          if (readErr?.message === 'CHAT_STREAM_CHUNK_TIMEOUT' && fullCollectedReply.trim().length > 0) {
            console.warn('[GLOBAL_VOICE_CHAIN] [3. AI_CHUNK_TIMEOUT] Stream stalled after partial reply; flushing buffered text');
            break;
          }
          throw readErr;
        }
        const { done, value } = chunkResult;
        if (done) {
          break;
        }

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() || '';

        for (const line of lines) {
          const trimmedLine = line.trim();
          if (!trimmedLine.startsWith('data:')) continue;
          const dataStr = trimmedLine.replace(/^data:\s*/, '').trim();
          if (dataStr === '[DONE]') {
            streamDone = true;
            break;
          }

          try {
            const parsed = JSON.parse(dataStr);
            if (parsed.text) {
              if (!firstTokenMarked) {
                firstTokenMarked = true;
                latencyLogger.markFirstToken(reqLogId);
              }
              const textChunk = parsed.text;
              fullCollectedReply += textChunk;
              pendingSentenceBuffer += textChunk;
              setLiveTranscript(fullCollectedReply);

              // Check for complete sentence boundary (Devanagari purna viram ।, ., ?, !, or newline \n)
              // Speak up to 3 conversational sentences smoothly (first sentence starts immediately; code/docs stay on visual card)
              let match: RegExpMatchArray | null;
              while (
                (match = pendingSentenceBuffer.match(/^([\s\S]+?[।?!.\n]+)([\s\S]*)$/)) !== null
              ) {
                const completeSentence = match[1].replace(/[*#_`]/g, '').trim();
                pendingSentenceBuffer = match[2];
                const isCodeChunk = /```|<html|<!DOCTYPE/i.test(completeSentence);
                if (
                  completeSentence &&
                  !isCodeChunk &&
                  spokenSentencesCount < 3 &&
                  spokenCharCount + completeSentence.length <= 420
                ) {
                  spokenSentencesCount++;
                  spokenCharCount += completeSentence.length;
                  if (!firstSpeechMarked) {
                    firstSpeechMarked = true;
                    latencyLogger.markFirstSpeech(reqLogId, completeSentence);
                  }
                  handedOffToPlayback = true;
                  enqueueSpeechChunk(completeSentence);
                } else {
                  break;
                }
              }
            }
          } catch {}
        }
      }

      const split = splitVoiceReplyAndVisualCard(fullCollectedReply);

      // Flush any trailing non-code sentence that didn't end with punctuation yet, or speak summary if nothing spoken yet
      const trailingClean = pendingSentenceBuffer.replace(/```[\s\S]*?```/g, '').replace(/[*#_`]/g, '').trim();
      if (spokenSentencesCount === 0 && split.spokenSummary) {
        if (!firstSpeechMarked) {
          firstSpeechMarked = true;
          latencyLogger.markFirstSpeech(reqLogId, split.spokenSummary);
        }
        spokenSentencesCount++;
        handedOffToPlayback = true;
        enqueueSpeechChunk(split.spokenSummary);
      } else if (
        trailingClean &&
        !split.routedToCard &&
        spokenSentencesCount < 3 &&
        spokenCharCount + trailingClean.length <= 420
      ) {
        handedOffToPlayback = true;
        enqueueSpeechChunk(trailingClean);
      }

      latencyLogger.markDone(reqLogId, {
        fullOutput: fullCollectedReply,
        spokenText: split.spokenSummary,
        routedToCard: split.routedToCard,
        status: 'completed',
      });

      if (fullCollectedReply.trim()) {
        const finalReply = fullCollectedReply.trim();
        console.log('[LOVE_VOICE_CHAIN] [3. AI_DONE] Reply received:', finalReply.slice(0, 120));
        voiceTelemetry.update('aiResponse', {
          isOk: true,
          stateText: 'RECEIVED',
          detail: finalReply.slice(0, 80),
        });
        setLiveTranscript(split.routedToCard ? split.spokenSummary : finalReply);
        logToHistory('voice', 'वॉयस बातचीत', `"${originalQuery}" -> ${finalReply}`);
        zoyaMemory.extractFromConversation(originalQuery, finalReply, personaMode, recLanguage);
        if (spokenSentencesCount === 0 && !split.spokenSummary && !isPlayingQueueRef.current) {
          handedOffToPlayback = true;
          handlePlaybackEnd();
        }
      } else {
        console.error('[LOVE_VOICE_CHAIN] [3. AI_ERROR] Empty reply received from /api/chat-stream; using fallbackChatQuery');
        voiceTelemetry.update('aiResponse', {
          isOk: false,
          health: 'fail',
          stateText: 'NOT RECEIVED',
          detail: 'Empty reply from /api/chat-stream',
          error: 'Empty stream response',
        });
        handedOffToPlayback = true;
        fallbackChatQuery(queryText, originalQuery);
      }
    } catch (streamErr: any) {
      console.error('[LOVE_VOICE_CHAIN] [3. AI_ERROR] Error in /api/chat-stream:', streamErr);
      voiceTelemetry.update('geminiApi', {
        isOk: false,
        health: 'fail',
        stateText: 'ERROR',
        detail: streamErr?.message || 'Chat stream request failed',
        error: streamErr?.message || String(streamErr),
      });
      voiceTelemetry.update('aiResponse', {
        isOk: false,
        health: 'fail',
        stateText: 'NOT RECEIVED',
        detail: streamErr?.message || 'Stream failed',
        error: streamErr?.message || String(streamErr),
      });
      latencyLogger.markDone(reqLogId, { status: 'error' });
      handedOffToPlayback = true;
      fallbackChatQuery(queryText, originalQuery);
    } finally {
      if (reader) {
        reader.cancel().catch(() => {});
      }
      if (chatStreamAbortRef.current === streamAbort) {
        chatStreamAbortRef.current = null;
      }
      if (!handedOffToPlayback && !isPlayingQueueRef.current && speechQueueRef.current.length === 0) {
        clearThinkingWatchdog();
        isProcessingRef.current = false;
        if (isGlobalMicOnRef.current || isLoveHandsFreeActiveRef.current) {
          setAssistantState(AssistantState.LISTENING);
          setVoiceStatus('listening');
          setMicPhase('listening');
          setIsButtonSpinning(true);
          speechManager.resumeAfterAssistantSpeaking();
        } else {
          setIsButtonSpinning(false);
          setAssistantState(AssistantState.IDLE);
          setVoiceStatus('idle');
          setMicPhase('off');
        }
      }
    }
  };

  const handleTapAvatar = () => {
    // If mic is currently listening or processing user speech, do not interrupt
    if (voiceStatus === 'listening' || voiceStatus === 'processing') return;

    const langConfig = getLanguageConfig(recLanguage);
    const templates = getLocalizedTemplates(langConfig.code);
    const isLove = personaMode === 'love';
    const picked = isLove ? templates.greetingLove : templates.greetingBoss;
    setLiveTranscript(picked);
    speakResponse(picked);
  };

  const handleResetChat = () => {
    const templates = getLocalizedTemplates(recLanguage);
    setLiveTranscript(templates.resetChatMsg);
    speakResponse(templates.resetChatMsg);
  };

  const resumeLoveHandsFreeIfSkipped = () => {
    if (!isGlobalMicOnRef.current && !isLoveHandsFreeActiveRef.current) return;
    isProcessingRef.current = false;
    setAssistantState(AssistantState.LISTENING);
    setVoiceStatus('listening');
    setMicPhase('listening');
    setIsButtonSpinning(true);
    speechManager.resumeAfterAssistantSpeaking();
    micStateMachine.reportSpeakEnd('skipped_turn');
  };

  const lastWebsiteDispatchRef = useRef<{ key: string; time: number }>({ key: '', time: 0 });
  const dispatchWebsiteCommand = async (
    rawQuery: string,
    source: 'voice' | 'manual' | 'live' | 'call' = 'voice',
    speakFeedback = true
  ) => {
    const cleanedQ =
      rawQuery
        .replace(/^(?:(hey|hello|helo|hi|ok|okay|namaste|suno)[,\s]+)?(zoya|joya|zoiya|soya)\b[,:;।.!?\-\s]*/i, '')
        .replace(/^(?:(हे|हैलो|हेलो|हलो|हाय|नमस्ते|नमस्कार|सुनो|प्रणाम|ओके)[,\s]+)?(जोया|ज़ोया|झोया|जया|जोय)[,:;।.!?\-\s]*/i, '')
        .trim() || rawQuery.trim();
    if (!cleanedQ) return;

    const now = Date.now();
    const normKey = cleanedQ.toLowerCase();
    if (lastWebsiteDispatchRef.current.key === normKey && now - lastWebsiteDispatchRef.current.time < 2200) {
      return;
    }
    lastWebsiteDispatchRef.current = { key: normKey, time: now };

    const isHindi = getLanguageConfig(recLanguageRef.current).code === 'hi-IN';
    const hasExistingSite = websiteBuilderController.hasGeneratedSite();
    const modalCurrentlyOpen = isWaitingForWebsiteRequirements();
    const looksLikeEdit = isExplicitWebsiteEditIntent(cleanedQ);
    const looksExplicitlyNew =
      /\b(new|another|different|fresh|brand new)\s+(site|website|webpage)\b/i.test(cleanedQ) ||
      /(नई|नया|दूसरी|दूसरा)\s*(वेबसाइट|साइट)/.test(cleanedQ);

    const isEditingCurrent =
      hasExistingSite && !looksExplicitlyNew && (modalCurrentlyOpen || looksLikeEdit);

    // Automatically leave home screen & open "Build a website" builder screen directly
    setIsMenuOpen(false);
    setShowTextChat(false);
    setShowVoiceCall(false);
    setIsVoiceOverlayOpen(false);
    setShowAppLauncher(false);
    setShowPythonStudio(false);
    setShowCodingAgent(false);
    setShowSketchCanvas(false);
    setIsSettingsOpen(false);
    setWebsitePrompt(cleanedQ);
    setShowWebsiteBuilder(true);

    // Start building immediately without any extra tap
    const buildRes = await triggerVoiceWebsiteBuild(cleanedQ, {
      forceNew: !isEditingCurrent,
    });

    const startMsg =
      buildRes.mode === 'edit'
        ? isHindi
          ? 'वेबसाइट में बदलाव लाइव लागू कर रही हूँ।'
          : 'Applying your changes live to the website.'
        : isHindi
        ? 'वेबसाइट बिल्डर खोल दिया है और लाइव बनाना शुरू कर दिया है।'
        : 'Opening the website builder and starting your live build now.';

    logToHistory('website', buildRes.mode === 'edit' ? 'Website Live Edit' : 'Website Live Build', `"${rawQuery}"`);
    setLiveTranscript(startMsg);
    if (speakFeedback && source !== 'live') {
      speakResponse(startMsg);
    }
  };
  const dispatchWebsiteCommandRef = useRef(dispatchWebsiteCommand);
  dispatchWebsiteCommandRef.current = dispatchWebsiteCommand;

  // Process recognized or typed query
  const handleProcessUserQuery = async (query: string, source: 'voice' | 'manual' = 'voice') => {
    const q = query.trim();
    if (!q) {
      isProcessingRef.current = false;
      setLiveTranscript('');
      if (isGlobalMicOnRef.current || isLoveHandsFreeActiveRef.current) {
        resumeLoveHandsFreeIfSkipped();
      } else {
        setAssistantState(AssistantState.IDLE);
        setVoiceStatus('idle');
      }
      return;
    }

    const now = Date.now();

    // Prevent Zoya's own spoken TTS response from triggering another submission if picked up by mic echo
    if (source === 'voice' && lastSpokenReplyRef.current.text) {
      const normSpoken = lastSpokenReplyRef.current.text
        .toLowerCase()
        .replace(/[.,!?;:।'"\-]/g, '')
        .trim();
      const normQuery = q
        .toLowerCase()
        .replace(/[.,!?;:।'"\-]/g, '')
        .trim();
      if (
        normSpoken &&
        normQuery.length >= 4 &&
        now - lastSpokenReplyRef.current.time < 6000 &&
        (normSpoken === normQuery || (normQuery.length > 10 && normSpoken.includes(normQuery)))
      ) {
        console.log('[MIC_TRACE] Ignoring Zoya own spoken TTS echo:', q);
        if (!hasManualTextRef.current) {
          setInputText('');
        }
        resumeLoveHandsFreeIfSkipped();
        return;
      }
    }

    if (
      lastProcessedQueryRef.current.query.toLowerCase() === q.toLowerCase() &&
      now - lastProcessedQueryRef.current.time < 1800
    ) {
      console.log('[MIC_TRACE] Deduplicating identical query within 1800ms:', q);
      if (source === 'voice' && !hasManualTextRef.current) {
        setInputText('');
      }
      resumeLoveHandsFreeIfSkipped();
      return;
    }
    lastProcessedQueryRef.current = { query: q, time: now };

    console.log('[LOVE_VOICE_CHAIN] [3. QUERY_DISPATCH] handleProcessUserQuery:', q, 'source:', source);
    voiceTelemetry.update('userMessage', {
      isOk: true,
      stateText: 'SUBMITTED',
      detail: `[${source}] "${q.slice(0, 80)}"`,
    });

    // CRITICAL: Pause microphone capture while Zoya processes, streams, and speaks
    // Prevents device speaker audio feedback loop, premature restarts, and barge-in cutoffs
    speechManager.pauseForAssistantSpeaking();

    // Clear input box when voice auto-submits (unless user is manually typing in the box)
    if (source === 'manual' || !hasManualTextRef.current) {
      isVoiceInputRef.current = false;
      hasManualTextRef.current = false;
      setInputText('');
    }

    // Set processing / thinking state with try/finally + 20s global THINKING watchdog
    isProcessingRef.current = true;
    setAssistantState(AssistantState.THINKING);
    setVoiceStatus('processing');
    setLiveTranscript(`"${q}"`);
    startThinkingWatchdog();

    let handedOff = false;
    try {
      // 0. Wake Word Detection ("Zoya", "Hey Zoya", "Hello Zoya", "Hello Hello", phonetic variants, "नमस्ते जोया", etc.)
      const langConfig = getLanguageConfig(recLanguage);
      const templates = getLocalizedTemplates(langConfig.code);
      const cleanLower = q
        .toLowerCase()
        .replace(/[.,!?;:।\-]/g, ' ')
        .replace(/\s+/g, ' ')
        .trim();
      const wakeCheck = speechManager.checkWakePhrase(cleanLower);
      const isWakeWordOnly =
        (wakeCheck.matched && !wakeCheck.remainingText) ||
        [
          'zoya', 'joya', 'zoiya', 'soya', 'zohra', 'zohaya', 'zoe', 'zoey', 'zora', 'johaia',
          'hello hello', 'helo helo',
          'hey zoya', 'hello zoya', 'helo zoya', 'hi zoya', 'ok zoya', 'okay zoya', 'namaste zoya', 'suno zoya',
          'hey joya', 'hello joya', 'hi joya', 'ok joya',
          'hello zohra', 'hey zohra', 'hello zohaya', 'hey zohaya', 'hello zoe', 'hey zoe', 'hello zoey', 'hey zoey',
          'जोया', 'ज़ोया', 'झोया', 'ज़ोहरा', 'जोहरा', 'ज़ोहाया', 'जोहाया', 'ज़ोई', 'जोई',
          'हैलो हैलो', 'हेलो हेलो', 'हलो हलो',
          'नमस्ते जोया', 'नमस्ते ज़ोया', 'सुनो जोया', 'सुनो ज़ोया',
          'हे जोया', 'हे ज़ोया', 'हेलो जोया', 'हेलो ज़ोया', 'हैलो जोया', 'हैलो ज़ोया', 'हलो जोया', 'हाय जोया',
          ...langConfig.wakeWords.map((w) => w.toLowerCase().replace(/[.,!?;:।\-]/g, '').trim()),
        ].includes(cleanLower);

      if (isWakeWordOnly) {
        voiceTelemetry.update('wakeWord', {
          isOk: true,
          stateText: 'DETECTED',
          detail: `Wake phrase "${q}" matched`,
        });
        logToHistory('voice', 'वेक वर्ड डिटेक्ट', `"${q}" -> जोया सक्रिय`);
        const isLove = personaMode === 'love';
        const reply = isLove ? templates.wakeReplyLove : templates.wakeReplyBoss;
        setLiveTranscript(reply);
        handedOff = true;
        speakResponse(reply);
        return;
      }

      if (wakeCheck.matched) {
        voiceTelemetry.update('wakeWord', {
          isOk: true,
          stateText: 'DETECTED',
          detail: `Wake prefix in "${q.slice(0, 60)}"`,
        });
      }

      // Strip wake word prefix if spoken together in one sentence (e.g. "Hey Zoya YouTube kholo" -> "YouTube kholo")
      let cleanedQ = (wakeCheck.matched && wakeCheck.remainingText ? wakeCheck.remainingText : q)
        .replace(/^(?:(hey|hello|helo|hi|ok|okay|namaste|suno)[,\s]+)?(zoya|zoyaa|zoia|zoiya|joya|joyaa|soya|zohra|zohaya|zoe|zoey|zora|johaia)\b[,:;।.!?\-\s]*/i, '')
        .replace(/^(?:(hello|helo)[,\s]+(?:hello|helo)\b[,:;।.!?\-\s]*)/i, '')
        .replace(/^(?:(हे|हैलो|हेलो|हलो|हाय|नमस्ते|नमस्कार|सुनो|प्रणाम|ओके)[,\s]+)?(जोया|ज़ोया|झोया|जया|जोय|ज़ोहरा|जोहरा|ज़ोहाया|जोहाया|ज़ोई|जोई)[,:;।.!?\-\s]*/i, '')
        .trim();
      if (!cleanedQ) cleanedQ = q;
      const lowerQ = cleanedQ.toLowerCase();
      const isHindi = langConfig.code === 'hi-IN';

      // Error handling: if audio is unintelligible or empty noise, ask user to repeat
      const speechChars = cleanedQ.replace(/[^a-zA-Z\u0900-\u0D7F0-9]/g, '').trim();
      if (!speechChars || speechChars.length < 2) {
        const isLove = personaMode === 'love';
        const repeatReply = isLove
          ? 'माफ़ करना मेरी जान, मुझे आपकी आवाज़ साफ़ सुनाई नहीं दी। क्या आप कृपया दोबारा बोल सकते हैं?'
          : 'माफ़ कीजिए बॉस, मुझे आपकी आवाज़ साफ़ सुनाई नहीं दी। क्या आप कृपया दोबारा बोल सकते हैं?';
        setLiveTranscript(repeatReply);
        handedOff = true;
        speakResponse(repeatReply);
        return;
      }

      // If TextChatModal is already open (and not a website builder command), route into TextChatModal
      if (showTextChatRef.current && !isWebsiteIntentPrompt(cleanedQ) && !isWaitingForWebsiteRequirements()) {
        isProcessingRef.current = false;
        setChatInitialPrompt(cleanedQ);
        resumeLoveHandsFreeIfSkipped();
        return;
      }

      // 0.3 Android Accessibility & Mobile Device Control Voice Command Dispatch
      const accessCmd = androidAccessibility.matchVoiceCommand(cleanedQ);
      if (accessCmd.isAccessibilityCommand && accessCmd.actionPayload) {
        try {
          const actionRes = await androidAccessibility.executeAction(accessCmd.actionPayload);

          let replyVoice = actionRes.message;
          if (actionRes.success) {
            if (isHindi) {
              if (accessCmd.actionPayload.action === 'open_app') {
                replyVoice = `${accessCmd.actionPayload.app} खोल रही हूँ...`;
              } else if (accessCmd.actionPayload.action === 'lock_device') {
                replyVoice = 'डिवाइस स्क्रीन लॉक कर दी गई है।';
              } else if (accessCmd.actionPayload.action === 'unlock_device') {
                replyVoice = 'अनलॉक सत्यापन शुरू किया गया है। कृपया अपने पिन, पासवर्ड या बायोमेट्रिक से पुष्टि करें।';
              } else if (accessCmd.actionPayload.action === 'scroll') {
                replyVoice = `पेज ${accessCmd.actionPayload.direction === 'up' ? 'ऊपर' : 'नीचे'} स्क्रॉल कर दिया गया है।`;
              } else if (accessCmd.actionPayload.action === 'global_action') {
                replyVoice = `${accessCmd.actionPayload.command} निष्पादित किया गया।`;
              } else if (accessCmd.actionPayload.action === 'type_text') {
                replyVoice = `टेक्स्ट टाइप कर दिया गया है।`;
              } else if (accessCmd.actionPayload.action === 'click_text') {
                replyVoice = `${accessCmd.actionPayload.text} पर क्लिक कर दिया गया है।`;
              } else if (accessCmd.actionPayload.action === 'read_screen') {
                replyVoice = `स्क्रीन को स्कैन कर लिया गया है। ${actionRes.data?.nodesCount || 0} तत्व मौजूद हैं।`;
              } else if (accessCmd.actionPayload.action === 'stop_listening') {
                await handleToggleAutomaticListening(false);
                replyVoice = 'माइक्रोफ़ोन सुनना बंद कर दिया गया है। जब भी ज़रूरत हो, टैप करें।';
              }
            } else if (accessCmd.actionPayload.action === 'stop_listening') {
              await handleToggleAutomaticListening(false);
              replyVoice = 'Background listening stopped. Tap whenever you need me.';
            }
          } else {
            if (isHindi) {
              if (accessCmd.actionPayload.action === 'lock_device') {
                if (actionRes.code === 'ACCESSIBILITY_REQUIRED' || (actionRes.message && actionRes.message.includes('Accessibility'))) {
                  replyVoice = 'स्क्रीन लॉक करने के लिए एक्सेसिबिलिटी सर्विस आवश्यक है। कृपया एंड्रॉइड सेटिंग्स में जाकर ज़ोया एक्सेसिबिलिटी सर्विस सक्षम करें।';
                } else if (actionRes.code === 'UNSUPPORTED_ANDROID_VERSION') {
                  replyVoice = 'स्क्रीन लॉक के लिए एंड्रॉइड 9.0 (Pie) या उससे नया वर्ज़न आवश्यक है।';
                } else {
                  replyVoice = `स्क्रीन लॉक नहीं हो सकी: ${actionRes.message || 'त्रुटि'}`;
                }
              } else if (accessCmd.actionPayload.action === 'unlock_device') {
                replyVoice = `अनलॉक चुनौती शुरू नहीं हो सकी: ${actionRes.message || 'त्रुटि'}`;
              }
            }
          }

          logToHistory('app', 'डिवाइस नियंत्रण (Accessibility)', `"${q}" -> ${actionRes.message}`);
          setLiveTranscript(replyVoice);
          handedOff = true;
          speakResponse(replyVoice);
          return;
        } catch (accessErr: any) {
          console.warn('[ACCESSIBILITY] Error executing voice action:', accessErr);
        }
      }

      const isLovePersona = personaMode === 'love';

      // 0.38 Python Engine & Autonomous Android App Builder Intent (disabled in Love Mode and yields to Website Builder)
      if (
        !isLovePersona &&
        !isWebsiteIntentPrompt(cleanedQ) &&
        (lowerQ.includes('python') ||
          lowerQ.includes('पायथन') ||
          lowerQ.includes('app banao') ||
          lowerQ.includes('app bana do') ||
          lowerQ.includes('make an app') ||
          lowerQ.includes('build an app') ||
          lowerQ.includes('create an app') ||
          lowerQ.includes('apk banao') ||
          lowerQ.includes('build apk') ||
          lowerQ.includes('android app') ||
          lowerQ.includes('ऐप बनाओ') ||
          lowerQ.includes('ऐप बनाएँ') ||
          lowerQ.includes('python script') ||
          lowerQ.includes('python code') ||
          lowerQ.includes('python studio') ||
          lowerQ.includes('run python'))
      ) {
        const isDirectAppCommand = /\b(app|apk|build)\b/.test(lowerQ) || lowerQ.includes('बनाओ');
        if (isDirectAppCommand && !lowerQ.startsWith('python') && !lowerQ.startsWith('पायथन')) {
          setPythonInitialPrompt(cleanedQ);
        } else {
          setPythonInitialPrompt('');
        }
        setShowPythonStudio(true);
        const replyMsg = isHindi 
          ? 'ज़ोया पायथन व ऐप बिल्डर स्टूडियो खोल रही हूँ।' 
          : 'Opening Zoya AI Python Studio and App Builder.';
        logToHistory('website', 'Python & App Builder', `"${q}" -> Python Studio`);
        setLiveTranscript(replyMsg);
        handedOff = true;
        speakResponse(replyMsg);
        return;
      }

      // 0.4 Website Builder Voice/Text Live Stream Intent (always opens directly and starts building immediately)
      if (isWaitingForWebsiteRequirements() || isWebsiteIntentPrompt(cleanedQ)) {
        handedOff = true;
        await dispatchWebsiteCommand(cleanedQ, source, true);
        return;
      }

      // 0.5 Part 1 Skills Intent Detection (artifacts-builder, brand-guidelines, canvas-design, changelog-generator, competitive-ads-extractor, connect-apps)
      const detectedSkill = !isLovePersona ? detectPart1SkillIntent(cleanedQ) : null;
      if (detectedSkill) {
        logToHistory('website', `Skill: ${detectedSkill}`, `"${q}" -> ${detectedSkill}`);
        isProcessingRef.current = false;
        setChatInitialPrompt(cleanedQ);
        setShowTextChat(true);
        return;
      }

      // 0.55 Battery Status Voice Command ("बैटरी कितनी है", "battery status", "battery percentage", "बैटरी चेक करो")
      if (
        !isLovePersona &&
        (lowerQ.includes('battery') ||
          lowerQ.includes('बैटरी') ||
          lowerQ.includes('charge kitna') ||
          lowerQ.includes('charging status'))
      ) {
        const bStatus = batteryAlertSystem.getStatus();
        const chargingStr = bStatus.isCharging ? 'और फोन चार्जर से कनेक्टेड है।' : 'और फोन डिस्चार्ज हो रहा है।';
        const reply = `फोन की बैटरी ${bStatus.levelPercent} परसेंट है, ${chargingStr}`;
        logToHistory('app', 'बैटरी स्टेटस', `"${q}" -> ${bStatus.levelPercent}%`);
        setLiveTranscript(reply);
        handedOff = true;
        speakResponse(reply);
        return;
      }

      // 0.6 YouTube & Favorite Singer Voice Commands (Requirement 4)
      const ytVoiceCmd = youtubeManager.parseVoiceCommand(cleanedQ);

      // 4A: "Zoya, play my favorite singer" / "मेरा पसंदीदा सिंगर चलाओ"
      if (ytVoiceCmd.isFavoriteSinger) {
        const targetSinger = youtubeManager.getPrimaryFavoriteSinger();
        if (targetSinger) {
          const res = await withTimeout(
            youtubeManager.getSingerTopTracks(targetSinger.name, targetSinger.channelId),
            4500,
            { videos: [] } as any,
            'youtubeManager.getSingerTopTracks'
          );
          const videos = res.videos || [];
          setYoutubeModalTitle(`Songs by Favorite Singer: ${targetSinger.name}`);
          setYoutubeModalSinger(targetSinger.name);
          setYoutubeModalVideos(videos);
          setShowYouTubeModal(true);

          const reply = `आपके पसंदीदा सिंगर ${targetSinger.name} के गाने यूट्यूब पर चला रही हूँ।`;
          logToHistory('app', 'पसंदीदा सिंगर (YouTube)', `"${q}" -> ${targetSinger.name}`);
          setLiveTranscript(reply);
          handedOff = true;
          speakResponse(reply, () => {
            if (videos.length > 0) {
              youtubeManager.openVideo(videos[0].videoId, videos[0].videoUrl);
            } else {
              youtubeManager.openVideo('', `https://www.youtube.com/results?search_query=${encodeURIComponent(targetSinger.name + ' songs')}`);
            }
          });
          return;
        } else {
          // No favorite singers saved yet -> guide user to Settings
          const reply = 'आपने अभी तक कोई पसंदीदा सिंगर नहीं चुना है। मैं सेटिंग्स में फेवरेट सिंगर्स का सेक्शन खोल रही हूँ।';
          logToHistory('app', 'पसंदीदा सिंगर', `"${q}" -> कोई सिंगर सेव नहीं`);
          setLiveTranscript(reply);
          handedOff = true;
          speakResponse(reply, () => {
            setSettingsInitialSection('youtube');
            setIsSettingsOpen(true);
          });
          return;
        }
      }

      // 4B: "Zoya, find songs by [Singer Name]" / "play songs by [Singer Name]" / "[Singer Name] ke gaane" / "गाना सुनाओ [Singer]"
      if (ytVoiceCmd.singerName) {
        const matchedName = ytVoiceCmd.singerName;
        const res = await withTimeout(
          youtubeManager.searchVideos(ytVoiceCmd.songName || 'best hit songs', matchedName, 10),
          4500,
          { videos: [] } as any,
          'youtubeManager.searchVideos(singer)'
        );
        const videos = res.videos || [];
        setYoutubeModalTitle(`Songs by ${matchedName}`);
        setYoutubeModalSinger(matchedName);
        setYoutubeModalVideos(videos);
        setShowYouTubeModal(true);

        const reply = `${matchedName} के गाने यूट्यूब पर ढूँढ लिए हैं। चला रही हूँ।`;
        logToHistory('app', 'यूट्यूब गाने (YouTube)', `"${q}" -> ${matchedName}`);
        setLiveTranscript(reply);
        handedOff = true;
        speakResponse(reply, () => {
          if (videos.length > 0) {
            youtubeManager.openVideo(videos[0].videoId, videos[0].videoUrl);
          } else {
            youtubeManager.openVideo('', `https://www.youtube.com/results?search_query=${encodeURIComponent(matchedName + ' songs')}`);
          }
        });
        return;
      }

      // 4C: Specific Song Search: "Zoya, play song Kesariya" / "song Chaleya chalao"
      if (ytVoiceCmd.songName) {
        const songTitle = ytVoiceCmd.songName;
        const res = await withTimeout(
          youtubeManager.searchVideos(songTitle, undefined, 10),
          4500,
          { videos: [] } as any,
          'youtubeManager.searchVideos(song)'
        );
        const videos = res.videos || [];
        setYoutubeModalTitle(`Song: ${songTitle}`);
        setYoutubeModalSinger(videos[0]?.channelTitle || '');
        setYoutubeModalVideos(videos);
        setShowYouTubeModal(true);

        const reply = `गाना ${songTitle} यूट्यूब पर ढूँढ लिया है। चला रही हूँ।`;
        logToHistory('app', 'यूट्यूब गाना', `"${q}" -> ${songTitle}`);
        setLiveTranscript(reply);
        handedOff = true;
        speakResponse(reply, () => {
          if (videos.length > 0) {
            youtubeManager.openVideo(videos[0].videoId, videos[0].videoUrl);
          } else {
            youtubeManager.openVideo('', `https://www.youtube.com/results?search_query=${encodeURIComponent(songTitle)}`);
          }
        });
        return;
      }

      // 0.7 3D Holographic AI Companion Voice Commands
      const hologramMatch = lowerQ.match(/(?:hologram|होलोग्राम|3d\s*hologram|floating\s*hologram)/i);
      if (hologramMatch) {
        if (lowerQ.includes('setting') || lowerQ.includes('style') || lowerQ.includes('बदलो') || lowerQ.includes('सेटिंग') || lowerQ.includes('change')) {
          const reply = '3D फ्लोटिंग होलोग्राम सेटिंग्स खोल रही हूँ। आप 23 स्टाइल्स में से कोई भी चुन सकते हैं।';
          logToHistory('app', 'होलोग्राम सेटिंग्स', `"${q}" -> Hologram Settings`);
          setLiveTranscript(reply);
          handedOff = true;
          speakResponse(reply, () => {
            setSettingsInitialSection('hologram');
            setIsSettingsOpen(true);
          });
          return;
        }

        if (lowerQ.includes('off') || lowerQ.includes('hide') || lowerQ.includes('close') || lowerQ.includes('बंद') || lowerQ.includes('छुपाओ')) {
          hologramManager.setEnabled(false);
          const reply = '3D फ्लोटिंग होलोग्राम बंद कर दिया गया है।';
          logToHistory('app', 'होलोग्राम बंद', `"${q}" -> Hologram Disabled`);
          setLiveTranscript(reply);
          handedOff = true;
          speakResponse(reply);
          return;
        }

        // Default: turn on / show hologram
        hologramManager.setEnabled(true);
        const reply = '3D फ्लोटिंग होलोग्राम सक्रिय कर दिया गया है। यह आपकी बातचीत के अनुसार गतिशील रहेगा।';
        logToHistory('app', 'होलोग्राम सक्रिय', `"${q}" -> Hologram Enabled`);
        setLiveTranscript(reply);
        handedOff = true;
        speakResponse(reply);
        return;
      }

      // 1. Action intents (tightened word boundaries, bypassed in Love Mode so emotional/casual speech stays in chat)
      if (!isLovePersona && (lowerQ.includes('youtube') || /\bkholo\b/.test(lowerQ) || /\bapp\b/.test(lowerQ) || /\bopen\b/.test(lowerQ))) {
        logToHistory('app', 'ऐप लॉन्च किया', `"${q}" -> YouTube खोला गया`);
        handedOff = true;
        speakResponse('यूट्यूब ऐप खोला जा रहा है।', () => {
          youtubeManager.openVideo('', 'https://www.youtube.com');
        });
        return;
      } 
      
      if (!isLovePersona && (/\bmummy\b/.test(lowerQ) || /\bcall\b/.test(lowerQ) || /\bphone\b/.test(lowerQ) || /\bfone\b/.test(lowerQ))) {
        setCallContact('Mummy');
        logToHistory('call', 'फ़ोन कॉल', `"${q}" -> Mummy को कॉल`);
        handedOff = true;
        speakResponse('मम्मी को कॉल मिलाया जा रहा है।', () => setShowPhoneCall(true));
        return;
      } 
      
      if (!isLovePersona && (lowerQ.includes('whatsapp') || /\bpapa\b/.test(lowerQ) || /\bmessage\b/.test(lowerQ) || /\bsandesh\b/.test(lowerQ))) {
        setMessageRecipient('Papa');
        logToHistory('message', 'व्हाट्सएप संदेश', `"${q}" -> पापा के लिए संदेश`);
        handedOff = true;
        speakResponse('पापा के लिए संदेश विंडो खोली गई है।', () => setShowMessageComposer(true));
        return;
      } 
      
      if (!isLovePersona && (/\bsketch\b/.test(lowerQ) || /\bdrawing\b/.test(lowerQ) || /\bphoto\b/.test(lowerQ) || /\bcanvas\b/.test(lowerQ))) {
        logToHistory('sketch', 'स्केच फोटो', `"${q}" -> कैनवास`);
        handedOff = true;
        speakResponse('स्केच और ड्राइंग कैनवास खोला गया है।', () => setShowSketchCanvas(true));
        return;
      }

      // 2. AI conversational query: Stream response for minimal latency with continuous spin
      handedOff = true;
      await streamAndSpeakResponse(cleanedQ, q);
    } catch (queryErr) {
      console.error('[GLOBAL_VOICE_CHAIN] Unhandled error in handleProcessUserQuery:', queryErr);
      if (!handedOff) {
        handedOff = true;
        fallbackChatQuery(q, q);
      }
    } finally {
      if (!handedOff && !isPlayingQueueRef.current && speechQueueRef.current.length === 0) {
        clearThinkingWatchdog();
        isProcessingRef.current = false;
        if (isGlobalMicOnRef.current || isLoveHandsFreeActiveRef.current) {
          resumeLoveHandsFreeIfSkipped();
        } else {
          setIsButtonSpinning(false);
          setAssistantState(AssistantState.IDLE);
          setVoiceStatus('idle');
          setMicPhase('off');
        }
      }
    }
  };

  const handleProcessUserQueryRef = useRef(handleProcessUserQuery);
  handleProcessUserQueryRef.current = handleProcessUserQuery;

  const fallbackChatQuery = (cleanedQ: string, originalQuery: string) => {
    const activeMode = personaModeRef.current;
    const activeLang = recLanguageRef.current;
    const reply = getLocalizedZoyaReply(cleanedQ, activeMode, activeLang);
    setLiveTranscript(reply);
    logToHistory('voice', 'वॉयस बातचीत', `"${originalQuery}" -> ${reply}`);
    speakResponse(reply);
    zoyaMemory.extractFromConversation(originalQuery, reply, activeMode, activeLang);
  };

  // Unified speech recognizer listener for real-time text display and wake word recognition
  // Uses live refs (assistantStateRef, isPersistentListeningRef, handleProcessUserQueryRef) to prevent stale closures
  const createSpeechListener = (): SpeechRecognizerListener => ({
    onHardwareStateChange: (info) => {
      console.log('[MIC_TRACE] onHardwareStateChange:', info);
      setHardwareState(info);
      if (info.state === 'error' && info.error) {
        setIsButtonSpinning(false);
        setLastMicError(info.error);
      }
    },
    onReady: () => {
      console.log('[MIC_TRACE] Recognizer ready');
      setMicPermissionState(speechManager.permissionState);
    },
    onListening: () => {
      console.log('[MIC_TRACE] Recognizer listening');
      micStateMachine.reportUserSpeechStarted();
      setAssistantState(AssistantState.LISTENING);
      setVoiceStatus('listening');
      setIsButtonSpinning(true);
    },
    onStandbyListening: () => {
      console.log('[MIC_TRACE] Standby steady (no UI flicker)');
      // In STANDBY mode, do NOT flip UI rapidly; keep state governed by micStateMachine
      setMicDebugLog('Standby (Hey Zoya wake-word active)');
    },
    onRmsChanged: (rmsdB: number) => {
      setGlobalAudioLevel(rmsdB);
      micStateMachine.reportAudioLevel(rmsdB);
      const userSpeaking =
        rmsdB > 0.035 &&
        assistantStateRef.current !== AssistantState.SPEAKING &&
        !isPlayingQueueRef.current;
      setGlobalUserSpeaking(userSpeaking);
      if (isGlobalMicOnRef.current && assistantStateRef.current !== AssistantState.SPEAKING) {
        setMicPhase(userSpeaking ? 'user_speaking' : 'listening');
      }
      if (rmsdB > 0.035 && assistantStateRef.current !== AssistantState.SPEAKING) {
        setIsButtonSpinning(true);
      }
    },
    onPartialResult: (text: string) => {
      // Ignore results while assistant is processing, playing, or speaking
      if (
        isProcessingRef.current ||
        isPlayingQueueRef.current ||
        speechManager.isPausedForSpeaking ||
        assistantStateRef.current === AssistantState.THINKING ||
        assistantStateRef.current === AssistantState.PROCESSING ||
        assistantStateRef.current === AssistantState.SPEAKING
      ) {
        return;
      }
      console.log('[MIC_TRACE] [LIVE_SPEECH] onPartialResult:', text);
      if (text.trim()) {
        setIsButtonSpinning(true);
      }
      // Only update input box with interim voice preview if user is not manually typing
      if (!isInputFocusedRef.current && !hasManualTextRef.current) {
        isVoiceInputRef.current = true;
        setInputText(text);
      }
      setLiveTranscript(text);
      setMicDebugLog(`Live: "${text}"`);
    },
    onWakeWordDetected: (wakePhrase: string, remainingText?: string) => {
      if (
        isProcessingRef.current ||
        isPlayingQueueRef.current ||
        speechManager.isPausedForSpeaking ||
        assistantStateRef.current === AssistantState.SPEAKING
      ) {
        console.log('[MIC_TRACE] Ignoring wake word during active speech/processing');
        return;
      }
      console.log('[MIC_TRACE] [WAKE_DETECTED] wakePhrase:', wakePhrase, 'Remaining:', remainingText);
      const fullText = remainingText && remainingText.trim().length > 0 
        ? `${wakePhrase} ${remainingText.trim()}` 
        : wakePhrase;

      setLiveTranscript(fullText);
      setIsWakeActive(true);
      setIsButtonSpinning(true);
      tonePlayer.playThinkingChirp();
      setMicDebugLog(`Wake: "${wakePhrase}"`);

      // Automatically submit recognized wake word / command directly without waiting for React inputText state
      handleProcessUserQueryRef.current(fullText, 'voice');
    },
    onResult: (finalText: string) => {
      if (
        isProcessingRef.current ||
        isPlayingQueueRef.current ||
        speechManager.isPausedForSpeaking ||
        assistantStateRef.current === AssistantState.SPEAKING
      ) {
        console.log('[MIC_TRACE] Ignoring final speech during active speech/processing');
        return;
      }
      console.log('[MIC_TRACE] [FINAL_SPEECH] onResult:', finalText);
      const text = finalText.trim();
      if (!text) return;

      setLiveTranscript(text);
      setIsWakeActive(true);
      setIsButtonSpinning(true);
      tonePlayer.playThinkingChirp();
      setMicDebugLog(`Captured: "${text}"`);

      // Automatically submit complete recognized voice command directly without requiring manual Send button click
      micStateMachine.reportUserSpeechFinalized(text);
      handleProcessUserQueryRef.current(text, 'voice');
    },
    onError: (errMsg: string) => {
      console.warn('[GLOBAL_VOICE_CHAIN] [VOICE_ERROR] Recognizer notice:', errMsg);
      if (errMsg && errMsg.toLowerCase().includes('network')) {
        console.warn('[MIC_TRACE] Network hiccup intercepted. Using MediaRecorder fallback.');
        setMicDebugLog('सुन रहा है');
        return;
      }
      setLastMicError(errMsg);
      setMicPermissionState(speechManager.permissionState);
      const isPermissionDenied =
        errMsg.includes('अनुमति') ||
        errMsg.includes('ब्लॉक') ||
        errMsg.toLowerCase().includes('permission') ||
        errMsg.toLowerCase().includes('not-allowed');
      if (isPermissionDenied) {
        setMicErrorNotice(MIC_PERMISSION_DENIED_HI);
        setGlobalMicError(MIC_PERMISSION_DENIED_HI);
        setGlobalMicOn(false);
        setIsLoveHandsFreeActive(false);
        setLoveVoiceEngine('none');
        setActiveEngine('none');
        setIsButtonSpinning(false);
        micStateMachine.setHandsFreeContinuous(false, 'none');
      } else {
        // Non-permission hiccup: keep global mic ON in background
        setMicDebugLog(`स्थिति: ${errMsg}`);
      }
    },
    onSttError: (sttErrMsg: string) => {
      console.warn('[GLOBAL_VOICE_CHAIN] [STT_NOTICE] Transient Speech-to-Text issue (mic stays ON):', sttErrMsg);
      setLastMicError(sttErrMsg);
      setMicDebugLog(`STT पुन:प्रयास: ${sttErrMsg}`);
    },
    onEnd: () => {
      console.log('[MIC_TRACE] Recognizer session ended');
      if (isGlobalMicOnRef.current || isLoveHandsFreeActiveRef.current) {
        return;
      }
      if (!isProcessingRef.current && assistantStateRef.current !== AssistantState.SPEAKING) {
        setIsButtonSpinning(false);
        // Only return to IDLE if state machine is not actively capturing
        if (micStateMachine.getState() !== 'CAPTURING' && micStateMachine.getState() !== 'ACTIVATING') {
          setAssistantState(AssistantState.IDLE);
          setVoiceStatus('idle');
        }
      }
    },
  });

  // Stop Global Always-On Mic (ONLY called when user manually clicks Stop)
  const stopGlobalMicSession = async () => {
    console.log('[GLOBAL_MIC] User manually stopped global always-on microphone');
    setGlobalMicOn(false);
    isGlobalMicOnRef.current = false;
    setGlobalAudioLevel(0);
    setGlobalUserSpeaking(false);
    setGlobalMicError(null);
    setActiveEngine('none');

    setIsLoveHandsFreeActive(false);
    setLoveVoiceEngine('none');
    isLoveHandsFreeActiveRef.current = false;
    loveVoiceEngineRef.current = 'none';
    micStateMachine.setHandsFreeContinuous(false, 'none');
    stopAllAudioPlayback();
    isProcessingRef.current = false;
    await geminiLiveVoiceClient.stop().catch(() => {});
    speechManager.setPreferMediaRecorder(false);
    await speechManager.disablePersistentListening().catch(() => {});
    await micStateMachine.requestStandby('User manually stopped global mic');
    setIsWakeActive(false);
    setAssistantState(AssistantState.IDLE);
    setVoiceStatus('idle');
    setIsButtonSpinning(false);
    clearThinkingWatchdog();
    audioLevelStore.set(0);
    setMicDebugLog('माइक बंद किया गया');
  };

  // Continuous MediaRecorder + /api/transcribe + /api/chat-stream + /api/tts fallback loop (always-on)
  const startMediaRecorderGlobalLoop = async (activeLangCode: string): Promise<boolean> => {
    const selectedLanguage = getSelectedLanguageLabel(activeLangCode);
    console.log('[GLOBAL_MIC] Starting continuous MediaRecorder fallback loop (auto-VAD + echo-gated barge-in):', {
      personaMode: personaModeRef.current,
      selectedLanguage,
      settingsCode: activeLangCode,
    });

    setLoveVoiceEngine('mediarecorder');
    loveVoiceEngineRef.current = 'mediarecorder';
    setActiveEngine('mediarecorder');
    micStateMachine.setHandsFreeContinuous(true, 'mediarecorder');
    speechManager.setPreferMediaRecorder(true);
    speechManager.setListener(createSpeechListener());

    const started = await speechManager.enablePersistentListening(activeLangCode, 1700);
    setMicPermissionState(speechManager.permissionState);
    if (!started || !isGlobalMicOnRef.current) {
      if (!isGlobalMicOnRef.current) return false;
      const errMsg = speechManager.lastError || MIC_PERMISSION_DENIED_HI;
      console.warn('[GLOBAL_MIC] [RECORD_START_FAILED]', errMsg);
      setMicErrorNotice(errMsg);
      setGlobalMicError(errMsg);
      setLastMicError(errMsg);
      setGlobalMicOn(false);
      isGlobalMicOnRef.current = false;
      setIsLoveHandsFreeActive(false);
      setLoveVoiceEngine('none');
      setActiveEngine('none');
      isLoveHandsFreeActiveRef.current = false;
      loveVoiceEngineRef.current = 'none';
      speechManager.setPreferMediaRecorder(false);
      micStateMachine.setHandsFreeContinuous(false, 'none');
      setAssistantState(AssistantState.IDLE);
      setVoiceStatus('idle');
      setIsButtonSpinning(false);
      return false;
    }

    setIsPersistentListening(true);
    setIsWakeActive(true);
    setAssistantState(AssistantState.LISTENING);
    setVoiceStatus('listening');
    setMicPhase('listening');
    setIsButtonSpinning(true);
    micStateMachine.reportExternalLiveState('CAPTURING', 'सुन रहा है');
    setMicDebugLog(`सुन रहा है (${selectedLanguage})`);
    return true;
  };

  // Start Global Always-On Mic across ALL modes and ALL screens:
  // Primary: Gemini Live Full-Duplex WS (with silent auto-reconnect & AEC)
  // Seamless fallback: Continuous MediaRecorder + /api/transcribe + /api/chat-stream + /api/tts
  const startGlobalMicSession = async (overrideLanguage?: string): Promise<boolean> => {
    const activeLangCode = getLanguageConfig(overrideLanguage || recLanguageRef.current).code;
    const speechLanguageCode = getLiveSpeechLanguageCode(activeLangCode);
    const selectedLanguage = getSelectedLanguageLabel(activeLangCode);
    const activeMode = personaModeRef.current;

    console.log('[GLOBAL_MIC] Turning global always-on mic ON:', {
      personaMode: activeMode,
      selectedLanguage,
      settingsCode: activeLangCode,
      speechConfigLanguageCode: speechLanguageCode,
    });

    setMicErrorNotice(null);
    setGlobalMicError(null);
    setLastMicError('None');

    // Run getUserMedia({ audio: true }) FIRST inside try/catch directly on mic button press
    if (typeof navigator === 'undefined' || !navigator.mediaDevices?.getUserMedia) {
      const errName = 'NotSupportedError';
      const errMsg = 'navigator.mediaDevices.getUserMedia unavailable';
      console.warn('[GLOBAL_MIC] getUserMedia failed:', errName, errMsg);
      const msg = MIC_PERMISSION_DENIED_HI;
      setMicErrorNotice(msg);
      setGlobalMicError(msg);
      setLastMicError(`${errName}: ${errMsg}`);
      setMicPermissionState('denied_by_user');
      return false;
    }

    try {
      const preflightStream = await navigator.mediaDevices.getUserMedia({ audio: true });
      preflightStream.getTracks().forEach((track) => {
        try {
          track.stop();
        } catch {}
      });
      setMicPermissionState('granted');
    } catch (err: any) {
      const errName = String(err?.name || 'Error');
      const errMsg = String(err?.message || err || '');
      console.warn('[GLOBAL_MIC] getUserMedia failed:', errName, errMsg);
      const msg =
        errName === 'NotAllowedError' || errName === 'PermissionDeniedError' || errName === 'SecurityError'
          ? MIC_PERMISSION_DENIED_HI
          : MIC_PERMISSION_DENIED_HI;
      setMicErrorNotice(msg);
      setGlobalMicError(msg);
      setLastMicError(`${errName}: ${errMsg}`);
      setMicPermissionState(errName === 'SecurityError' ? 'iframe_blocked' : 'denied_by_user');
      return false;
    }

    isProcessingRef.current = false;
    stopAllAudioPlayback();
    await speechManager.disablePersistentListening().catch(() => {});

    setGlobalMicOn(true);
    isGlobalMicOnRef.current = true;
    setMicPhase('listening');
    setIsLoveHandsFreeActive(true);
    isLoveHandsFreeActiveRef.current = true;
    setIsWakeActive(true);
    setAssistantState(AssistantState.LISTENING);
    setVoiceStatus('listening');
    setIsButtonSpinning(true);
    micStateMachine.setHandsFreeContinuous(true, 'gemini-live');
    micStateMachine.reportExternalLiveState('CAPTURING', 'सुन रहा है');

    const liveStarted = await geminiLiveVoiceClient.start(
      {
        personaMode: activeMode,
        language: activeLangCode,
        voiceName: getSelectedGeminiVoiceName(),
      },
      {
        onReady: () => {
          if (!isGlobalMicOnRef.current) return;
          setLoveVoiceEngine('gemini-live');
          loveVoiceEngineRef.current = 'gemini-live';
          setActiveEngine('gemini-live');
          setMicPhase('listening');
          setAssistantState(AssistantState.LISTENING);
          setVoiceStatus('listening');
          setIsButtonSpinning(true);
          micStateMachine.setHandsFreeContinuous(true, 'gemini-live');
          micStateMachine.reportExternalLiveState('CAPTURING', 'सुन रहा है');
          setMicDebugLog(`सुन रहा है (${selectedLanguage})`);
        },
        onAudioLevel: (lvl) => {
          setGlobalAudioLevel(lvl);
          micStateMachine.reportAudioLevel(lvl);
        },
        onUserSpeakingChange: (speaking) => {
          if (!isGlobalMicOnRef.current) return;
          setGlobalUserSpeaking(speaking);
          if (!geminiLiveVoiceClient.isSpeaking()) {
            setMicPhase(speaking ? 'user_speaking' : 'listening');
          }
        },
        onUserTranscript: (text, isFinal) => {
          if (!isGlobalMicOnRef.current) return;
          setLiveTranscript(text);
          if (isFinal && text.trim() && (isWebsiteIntentPrompt(text) || isWaitingForWebsiteRequirements())) {
            geminiLiveVoiceClient.interruptPlayback();
            void dispatchWebsiteCommandRef.current(text, 'live', false);
          }
        },
        onAssistantTranscript: (text) => {
          if (!isGlobalMicOnRef.current) return;
          setLiveTranscript(text);
        },
        onSpeakingChange: (speaking) => {
          if (!isGlobalMicOnRef.current) return;
          if (speaking) {
            setMicPhase('ai_speaking');
            setAssistantState(AssistantState.SPEAKING);
            setVoiceStatus('speaking');
            micStateMachine.reportExternalLiveState('SPEAKING', 'बोल रहा है');
          } else {
            setMicPhase('listening');
            setAssistantState(AssistantState.LISTENING);
            setVoiceStatus('listening');
            micStateMachine.reportExternalLiveState('CAPTURING', 'सुन रहा है');
          }
        },
        onInterrupted: () => {
          if (!isGlobalMicOnRef.current) return;
          setMicPhase('listening');
          setAssistantState(AssistantState.LISTENING);
          setVoiceStatus('listening');
          micStateMachine.reportExternalLiveState('CAPTURING', 'सुन रहा है');
        },
        onTurnComplete: (uText, aText) => {
          const curMode = personaModeRef.current;
          const curLang = recLanguageRef.current;
          if (uText) {
            voiceTelemetry.update('userMessage', {
              isOk: true,
              stateText: 'SUBMITTED',
              detail: `[live] "${uText.slice(0, 80)}"`,
            });
          }
          if (aText) {
            voiceTelemetry.update('aiResponse', {
              isOk: true,
              stateText: 'RECEIVED',
              detail: aText.slice(0, 80),
            });
          }
          if (uText || aText) {
            logToHistory('voice', 'वॉयस बातचीत', `"${uText}" -> ${aText}`);
            zoyaMemory.extractFromConversation(uText, aText, curMode, curLang);
          }
        },
        onAudioMissingForTurn: (aText) => {
          if (aText && isGlobalMicOnRef.current) {
            speakResponse(aText);
          }
        },
        onPermissionError: (msg) => {
          console.warn('[GLOBAL_MIC] Permission notice:', msg);
          setMicErrorNotice(msg);
          setGlobalMicError(msg);
          setLastMicError(msg);
          setMicPermissionState('denied_by_user');
          setGlobalMicOn(false);
          isGlobalMicOnRef.current = false;
          setIsLoveHandsFreeActive(false);
          isLoveHandsFreeActiveRef.current = false;
          setLoveVoiceEngine('none');
          setActiveEngine('none');
          micStateMachine.setHandsFreeContinuous(false, 'none');
          setAssistantState(AssistantState.IDLE);
          setVoiceStatus('idle');
          setIsButtonSpinning(false);
        },
        onFallbackRequired: async (reason) => {
          console.warn('[GLOBAL_MIC] Live session handed off to MediaRecorder loop (mic stays ON):', reason);
          if (!isGlobalMicOnRef.current) return;
          await startMediaRecorderGlobalLoop(recLanguageRef.current);
        },
      }
    );

    if (!isGlobalMicOnRef.current) {
      await geminiLiveVoiceClient.stop().catch(() => {});
      return false;
    }

    if (liveStarted) {
      setMicPermissionState('granted');
      return true;
    }

    // If Live client already handled fallback or permission error inside callbacks, return current global status
    return isGlobalMicOnRef.current;
  };

  const startGlobalMicSessionRef = useRef(startGlobalMicSession);
  startGlobalMicSessionRef.current = startGlobalMicSession;

  // Global Play / Stop Toggle across ALL modes:
  // Single tap starts global always-on listening; ONLY manual tap stops it.
  const handleTapToTalk = async () => {
    console.log('[GLOBAL_MIC] Mic button toggled by user', {
      personaMode: personaModeRef.current,
      isGlobalMicOn: isGlobalMicOnRef.current,
      language: recLanguageRef.current,
    });

    const now = Date.now();
    if (now - lastMicTapRef.current < 350) return;
    lastMicTapRef.current = now;

    if (isGlobalMicOnRef.current || isLoveHandsFreeActiveRef.current) {
      tonePlayer.playStopBeep();
      await stopGlobalMicSession();
      return;
    }

    const started = await startGlobalMicSession();
    if (started) {
      tonePlayer.playReadyBeep();
    }
  };

  const handleTapToTalkRef = useRef(handleTapToTalk);
  handleTapToTalkRef.current = handleTapToTalk;
  const stopGlobalMicSessionRef = useRef(stopGlobalMicSession);
  stopGlobalMicSessionRef.current = stopGlobalMicSession;

  useEffect(() => {
    registerStopHandler(() => stopGlobalMicSessionRef.current());
    registerToggleHandler(() => handleTapToTalkRef.current());
  }, [registerStopHandler, registerToggleHandler]);

  const handleRequestMicPermission = async () => {
    console.log('[MIC_TRACE] User triggered manual permission request');
    const result = await speechManager.requestMicrophonePermission();
    setMicPermissionState(result.state);
    if (result.granted) {
      setLastMicError('None');
      setMicDebugLog('माइक अनुमति प्राप्त!');
    } else {
      setLastMicError(result.message);
      setMicDebugLog(result.message);
    }
  };

  const handleSendInput = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputText.trim()) return;
    const text = inputText;
    hasManualTextRef.current = false;
    isVoiceInputRef.current = false;
    setInputText('');
    lastProcessedQueryRef.current = { query: '', time: 0 };
    handleProcessUserQuery(text, 'manual');
  };

  // Ensure speech listener is always registered and synchronized
  useEffect(() => {
    speechManager.setListener(createSpeechListener());
  }, [recLanguage, personaMode, automaticListening]);

  return (
    <div className="relative h-[100dvh] w-full bg-[#050214] text-white flex flex-col justify-between overflow-hidden select-none transition-colors duration-200">
      
      {/* COMPLETELY HIDE HOME SCREEN ELEMENTS WHEN SETTINGS IS OPEN (Requirement 3) */}
      {!isSettingsOpen && (
        <>
          {/* 5. BACKGROUND: Cosmic Purple Sky, Stars, Central Spotlight & Concentric Glowing Rings (or 3D Memory Preview if toggled in Settings) */}
          {use3DMemoryBackground ? (
            <div
              data-testid="zoya-3d-memory-background"
              className="absolute inset-0 z-0 pointer-events-none opacity-100 overflow-hidden transition-opacity duration-500 flex items-center justify-center bg-[#020906]"
            >
              <iframe
                ref={memoryBgIframeRef}
                src="/memory-system.html?context=background"
                title="Zoya 3D Memory Background Preview"
                className="w-full h-full border-0 pointer-events-none bg-[#020906]"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope"
              />
            </div>
          ) : (
            <div
              data-testid="zoya-cosmic-stage-background"
              className="absolute inset-0 z-0 pointer-events-none overflow-hidden bg-gradient-to-b from-[#08031d] via-[#110634] to-[#04010f]"
            >
              {/* Ambient Deep Purple Cosmic Glow */}
              <div className="absolute inset-0 bg-[radial-gradient(ellipse_75%_55%_at_50%_38%,rgba(88,28,175,0.32),transparent_75%)]" />

              {/* Smooth Clean Stage Backdrop (Star backgrounds and particles removed) */}
              {/* Soft Center Lighting (no polygon clipping or rectangular box borders) */}
              <div
                className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[540px] h-[540px] rounded-full pointer-events-none opacity-45 blur-3xl"
                style={{
                  background:
                    'radial-gradient(circle, rgba(147, 51, 234, 0.45) 0%, rgba(59, 130, 246, 0.22) 45%, transparent 70%)',
                }}
              />
            </div>
          )}

          {/* 1. TOP HEADER (Left: Hamburger Menu + Settings | Center: ZOYA AI (~20px) | Right: Instagram, Arrow, Image Gallery) */}
          <header className="relative z-30 w-full max-w-lg md:max-w-xl mx-auto flex items-center justify-between px-3 sm:px-5 pt-2.5 pb-1.5 shrink-0">
            {/* Left Side: Hamburger Menu (3 lines) + Settings Button */}
            <div className="flex items-center gap-2 sm:gap-2.5">
              <button
                onClick={() => setIsMenuOpen(true)}
                data-testid="header-menu-btn"
                className="w-10 h-10 sm:w-11 sm:h-11 rounded-full bg-[#120b2e]/90 hover:bg-[#1b1145] border border-purple-500/70 shadow-[0_0_15px_rgba(168,85,247,0.5)] flex items-center justify-center text-white transition-all active:scale-95 cursor-pointer"
                title="Menu"
              >
                <Menu className="w-5 h-5" />
              </button>

              <button
                onClick={() => {
                  setSettingsInitialSection('general');
                  setIsSettingsOpen(true);
                }}
                data-testid="header-settings-btn"
                className="w-10 h-10 sm:w-11 sm:h-11 rounded-full bg-[#120b2e]/90 hover:bg-[#1b1145] border border-purple-500/70 shadow-[0_0_15px_rgba(168,85,247,0.5)] flex items-center justify-center text-purple-200 hover:text-white transition-all active:scale-95 cursor-pointer"
                title="Settings"
              >
                <Settings className="w-5 h-5" />
              </button>
            </div>

            {/* Center: ZOYA AI (~20px, clear & attractive, no duplicate header text) */}
            <div className="flex items-center justify-center text-center px-1">
              <h1 className="text-[20px] sm:text-[22px] font-extrabold tracking-[0.12em] bg-gradient-to-r from-white via-purple-200 to-fuchsia-300 bg-clip-text text-transparent drop-shadow-[0_0_12px_rgba(192,132,252,0.55)] leading-none">
                ZOYA AI
              </h1>
            </div>

            {/* Right Side: Instagram, Arrow, and Image Gallery Buttons */}
            <div className="flex items-center gap-2 sm:gap-2.5">
              {/* Instagram / App Launcher Button */}
              <button
                onClick={() => setShowAppLauncher(true)}
                data-testid="header-instagram-btn"
                className="w-10 h-10 sm:w-11 sm:h-11 rounded-full bg-[#120b2e]/90 hover:bg-[#1b1145] border border-pink-500/70 shadow-[0_0_15px_rgba(236,72,153,0.45)] flex items-center justify-center text-pink-200 hover:text-white transition-all active:scale-95 cursor-pointer"
                title="Instagram & Social Apps"
              >
                <svg
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="w-4.5 h-4.5 sm:w-5 sm:h-5"
                  aria-hidden="true"
                >
                  <rect width="20" height="20" x="2" y="2" rx="5" ry="5" />
                  <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
                  <line x1="17.5" x2="17.51" y1="6.5" y2="6.5" />
                </svg>
              </button>

              {/* Arrow Button (Latency Log & Quick Panel) */}
              <button
                onClick={() => setShowLatencyLogModal(true)}
                data-testid="open-latency-log-btn"
                className="w-10 h-10 sm:w-11 sm:h-11 rounded-full bg-[#120b2e]/90 hover:bg-[#1b1145] border border-cyan-400/75 shadow-[0_0_15px_rgba(34,211,238,0.5)] flex items-center justify-center text-cyan-200 hover:text-white transition-all active:scale-95 cursor-pointer"
                title="Latency Log & Diagnostics"
              >
                <svg
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2.2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="w-5 h-5"
                  aria-hidden="true"
                >
                  <path d="m9 18 6-6-6-6" />
                </svg>
              </button>

              {/* Image Gallery / Create Image Button */}
              <button
                onClick={() => setShowSketchCanvas(true)}
                data-testid="header-gallery-btn"
                className="w-10 h-10 sm:w-11 sm:h-11 rounded-full bg-[#120b2e]/90 hover:bg-[#1b1145] border border-purple-500/70 shadow-[0_0_15px_rgba(168,85,247,0.5)] flex items-center justify-center text-purple-200 hover:text-white transition-all active:scale-95 cursor-pointer"
                title="Image Gallery & Sketch Studio"
              >
                <ImageIcon className="w-4.5 h-4.5 sm:w-5 sm:h-5" />
              </button>

              {/* Full System Diagnostics Button (1-Tap Mobile Access) */}
              <button
                onClick={() => setShowDiagnosticModal(true)}
                data-testid="header-diagnostics-btn"
                className="w-10 h-10 sm:w-11 sm:h-11 rounded-full bg-[#120b2e]/90 hover:bg-[#1b1145] border border-emerald-400/80 shadow-[0_0_15px_rgba(52,211,153,0.55)] flex items-center justify-center text-emerald-200 hover:text-white transition-all active:scale-95 cursor-pointer"
                title="System Diagnostics & Security Audit"
              >
                <Activity className="w-5 h-5 text-emerald-300" />
              </button>

              {/* 14 Living Avatars Showcase Button */}
              <button
                onClick={() => setShow14LivingShowcase(true)}
                data-testid="header-14-avatars-btn"
                className="w-10 h-10 sm:w-11 sm:h-11 rounded-full bg-[#120b2e]/90 hover:bg-[#1b1145] border border-cyan-400/70 shadow-[0_0_15px_rgba(34,211,238,0.5)] flex items-center justify-center text-cyan-200 hover:text-white transition-all active:scale-95 cursor-pointer"
                title="14 Living Avatars • Locked-Off Camera Shot"
              >
                <Sparkles className="w-4.5 h-4.5 sm:w-5 sm:h-5 text-cyan-300" />
              </button>
            </div>
          </header>

          {/* Global indicator is rendered persistently at root level below */}

          {/* 2. MAIN VIEWPORT: AVATAR CENTERED IN FOREGROUND CIRCULAR RING + NO ENCLOSING BOX */}
          <main className="relative z-10 flex-1 min-h-0 w-full max-w-lg md:max-w-xl mx-auto px-3 sm:px-4 flex flex-col justify-between overflow-hidden">
            
            {/* AVATAR STAGE: Centered Zoya Avatar with Glowing Circular Ring brought forward into foreground */}
            {!use3DMemoryBackground ? (
              <div className="relative w-full flex-1 min-h-0 flex items-center justify-center pointer-events-none py-1 overflow-visible">
                <div className="relative w-full h-full flex items-center justify-center overflow-visible pointer-events-auto">
                  
                  {/* Zoya Avatar: Layered cleanly in foreground without unwanted circular ring light */}
                  <div className="relative z-10 w-full h-full flex items-center justify-center overflow-visible">
                    <ZoyaAvatarDisplay
                      avatarStyle={avatarStyle}
                      voiceStatus={voiceStatus}
                      audioLevel={0}
                      onTapAvatar={handleTapAvatar}
                      is3DAvatarActive={is3DAvatarActive}
                      active3DAvatar={
                        getAllAvatars().find((a) => a.id === selected3DAvatarId) || ANIME_3D_AVATARS[0]
                      }
                      avatarScale={avatarScale}
                      avatarOffsetY={avatarOffsetY}
                    />
                  </div>
                </div>
              </div>
            ) : (
              <div className="relative w-full flex-1 min-h-0 pointer-events-none" />
            )}

            {/* 3 & 4. LIFTED MICROPHONE, SOUND WAVES, ALWAYS LISTENING, LARGER INPUT & LARGER 4 ACTION BUTTONS */}
            <div className="relative z-20 w-full flex flex-col items-center pt-1 pb-2 shrink-0">

              {/* Background Website Build / Ready Re-Entry Indicator */}
              {!showWebsiteBuilder &&
                (websiteBuildState.status === 'streaming' ||
                  websiteBuildState.status === 'ready' ||
                  websiteBuildState.status === 'error') && (
                  <button
                    type="button"
                    data-testid="home-website-building-indicator"
                    onClick={() => {
                      setIsMenuOpen(false);
                      setShowWebsiteBuilder(true);
                    }}
                    className={`mb-2 w-full max-w-[92vw] sm:max-w-md rounded-xl border px-3 py-2 flex items-center justify-between gap-2.5 text-left transition-all active:scale-[0.99] cursor-pointer shadow-lg ${
                      websiteBuildState.status === 'streaming'
                        ? 'bg-[#0c1a2e]/95 hover:bg-[#102440] border-cyan-400/60 text-cyan-100'
                        : websiteBuildState.status === 'error'
                        ? 'bg-[#2a0f18]/95 hover:bg-[#3a1522] border-rose-400/60 text-rose-100'
                        : 'bg-[#09211b]/95 hover:bg-[#0d2e26] border-emerald-400/60 text-emerald-100'
                    }`}
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      {websiteBuildState.status === 'streaming' ? (
                        <RefreshCw className="w-4 h-4 text-cyan-300 animate-spin shrink-0" />
                      ) : websiteBuildState.status === 'error' ? (
                        <AlertTriangle className="w-4 h-4 text-rose-300 shrink-0" />
                      ) : (
                        <Globe className="w-4 h-4 text-emerald-300 shrink-0" />
                      )}
                      <div className="min-w-0">
                        <div className="text-xs font-bold truncate tabular-nums">
                          {websiteBuildState.status === 'streaming'
                            ? `Website building… ${websiteBuildState.progress}%`
                            : websiteBuildState.status === 'error'
                            ? 'Website build interrupted · Tap to retry'
                            : `Website ready · ${websiteBuildState.title || 'View site'}`}
                        </div>
                        <div className="text-[10.5px] text-slate-300 truncate">
                          {websiteBuildState.status === 'streaming'
                            ? websiteBuildState.currentStep
                            : websiteBuildState.status === 'error'
                            ? websiteBuildState.error || 'Tap to reopen Website Builder'
                            : 'Tap to open editor, Download ZIP & Publish'}
                        </div>
                      </div>
                    </div>
                    <span className="text-[11px] font-semibold px-2 py-0.5 rounded bg-white/10 text-white shrink-0">
                      Open
                    </span>
                  </button>
                )}

              {/* Clear Mic Permission / Voice Error Banner */}
              {micErrorNotice && (
                <div
                  data-testid="mic-error-banner"
                  className="mb-1.5 px-3.5 py-2 rounded-2xl bg-rose-950/90 border border-rose-500/60 text-rose-100 text-xs font-medium flex flex-wrap items-center gap-2 shadow-lg max-w-[92vw]"
                >
                  <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                  <span className="leading-snug flex-1 min-w-[180px]">{micErrorNotice}</span>
                  {typeof window !== 'undefined' && (
                    <a
                      href={window.location.href}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-2.5 py-1 rounded-full bg-rose-500/25 hover:bg-rose-500/40 border border-rose-300/40 text-rose-50 text-[11px] font-semibold whitespace-nowrap transition-colors"
                    >
                      नए टैब में खोलो
                    </a>
                  )}
                  <button
                    type="button"
                    onClick={() => setMicErrorNotice(null)}
                    className="p-0.5 rounded-full hover:bg-rose-800/60 text-rose-200 cursor-pointer shrink-0"
                    title="बंद करें"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}

              {/* Wake-Word & Model Status Notification Banner */}
              {wakeWordNotice && (
                <div
                  className={`mb-1.5 px-4 py-1.5 rounded-full text-xs font-semibold flex items-center gap-2 shadow-lg animate-fadeIn text-center max-w-[90vw] ${
                    wakeWordNotice.type === 'error'
                      ? 'bg-rose-950/90 border border-rose-500/50 text-rose-200'
                      : wakeWordNotice.type === 'warning'
                      ? 'bg-amber-950/90 border border-amber-500/50 text-amber-200'
                      : 'bg-emerald-950/90 border border-emerald-500/50 text-emerald-200'
                  }`}
                >
                  <span className="truncate max-w-[320px]">{wakeWordNotice.message}</span>
                </div>
              )}

              {/* Live speech transcription toast when active */}
              {liveTranscript && (
                <div className="mb-1.5 px-3.5 py-1 bg-[#131130]/95 border border-pink-500/40 rounded-full text-xs text-pink-200 flex items-center gap-1.5 shadow-lg animate-fadeIn text-center max-w-[90vw]">
                  <Volume2 className="w-4 h-4 text-pink-400 shrink-0 animate-pulse" />
                  <span className="truncate max-w-[260px] font-medium">{liveTranscript}</span>
                </div>
              )}

              {/* Microphone with Sound Waves on Both Left and Right Sides (Shifted Upward & Enlarged) */}
              <div className="relative flex items-center justify-center gap-3.5 sm:gap-5">
                {/* Left Sound Waves (subscribed directly to audioLevelStore) */}
                <MicSoundWaves
                  side="left"
                  isVoiceActive={
                    voiceStatus === 'listening' ||
                    voiceStatus === 'speaking' ||
                    assistantState === AssistantState.LISTENING ||
                    assistantState === AssistantState.SPEAKING
                  }
                />

                {/* Center Circular Play / Mic Button (Enlarged with Neon Purple & Cyan Circular Frame) */}
                <div className="relative flex items-center justify-center shrink-0">
                  {assistantState !== AssistantState.IDLE && isWakeActive && (
                    <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-0">
                      <MorphingSphere
                        state={assistantState}
                        audioLevel={0}
                        size={112}
                      />
                    </div>
                  )}

                  <button
                    ref={homeMicBtnRef}
                    onClick={handleTapToTalk}
                    data-testid="home-mic-btn"
                    className="relative z-10 group p-1.5 rounded-full transition-all duration-200 active:scale-95 cursor-pointer flex items-center justify-center"
                    title={isMicActive ? 'माइक बंद करें' : 'माइक चालू करें'}
                    aria-label={isMicActive ? 'माइक बंद करें' : 'माइक चालू करें'}
                  >
                    {/* Outer Subtle Neon Purple & Cyan Glow Halo */}
                    <div
                      className={`absolute -inset-2 rounded-full blur-lg transition-all duration-300 ${
                        isMicActive
                          ? assistantState === AssistantState.SPEAKING
                            ? 'bg-gradient-to-tr from-cyan-400 via-purple-500 to-fuchsia-500 opacity-95 animate-pulse'
                            : 'bg-gradient-to-tr from-emerald-400 via-cyan-400 to-purple-500 opacity-95 animate-pulse'
                          : 'bg-gradient-to-tr from-purple-600/75 via-fuchsia-500/60 to-cyan-400/75 opacity-80 group-hover:opacity-100'
                      }`}
                    />

                    {/* Prominent Thick Neon Purple & Cyan Circular Frame */}
                    <div
                      className={`relative w-[84px] h-[84px] min-[360px]:w-[92px] min-[360px]:h-[92px] sm:w-[100px] sm:h-[100px] rounded-full p-[3.5px] sm:p-[4px] flex items-center justify-center transition-all duration-200 ${
                        isMicActive
                          ? 'bg-gradient-to-tr from-emerald-400 via-cyan-300 to-purple-400 shadow-[0_0_28px_rgba(52,211,153,0.75),0_0_16px_rgba(34,211,238,0.6)]'
                          : 'bg-gradient-to-tr from-purple-500 via-fuchsia-400 to-cyan-400 shadow-[0_0_26px_rgba(168,85,247,0.65),0_0_14px_rgba(34,211,238,0.5)] group-hover:shadow-[0_0_32px_rgba(168,85,247,0.85),0_0_18px_rgba(34,211,238,0.65)]'
                      }`}
                    >
                      {/* Inner Circular Frame Surface */}
                      <div className="relative w-full h-full rounded-full bg-gradient-to-b from-[#13082e] via-[#090318] to-black border-[1.5px] border-white/20 shadow-[inset_0_2px_12px_rgba(168,85,247,0.35),inset_0_-2px_10px_rgba(34,211,238,0.2)] flex items-center justify-center">
                        {isMicActive ? (
                          <Square className="w-8 h-8 min-[360px]:w-9 min-[360px]:h-9 sm:w-10 sm:h-10 text-white fill-white rounded-sm drop-shadow-[0_0_10px_rgba(255,255,255,0.65)] transition-transform group-hover:scale-105" />
                        ) : (
                          <Play className="w-9 h-9 min-[360px]:w-10 min-[360px]:h-10 sm:w-11 sm:h-11 text-white fill-white translate-x-[2px] drop-shadow-[0_0_12px_rgba(255,255,255,0.75)] transition-transform group-hover:scale-105" />
                        )}
                      </div>
                    </div>
                  </button>
                </div>

                {/* Right Sound Waves (subscribed directly to audioLevelStore) */}
                <MicSoundWaves
                  side="right"
                  isVoiceActive={
                    voiceStatus === 'listening' ||
                    voiceStatus === 'speaking' ||
                    assistantState === AssistantState.LISTENING ||
                    assistantState === AssistantState.SPEAKING
                  }
                />
              </div>

              {/* Global Always-On Mic Pill Button Directly Below Microphone */}
              <button
                type="button"
                onClick={handleTapToTalk}
                data-testid="always-listening-toggle-btn"
                className="mt-2 mb-2.5 px-5 py-2 rounded-full bg-[#130b2e]/95 hover:bg-[#1a103d] border border-purple-500/55 shadow-[0_0_18px_rgba(139,92,246,0.35)] flex items-center justify-center gap-2.5 transition-all active:scale-95 cursor-pointer"
              >
                <span
                  className={`w-3 h-3 rounded-full shrink-0 ${
                    hardwareState.state === 'error' || micErrorNotice
                      ? 'bg-rose-400 shadow-[0_0_8px_#fb7185]'
                      : isMicActive
                      ? 'bg-emerald-400 shadow-[0_0_8px_#34d399]'
                      : 'bg-amber-400 shadow-[0_0_8px_#fbbf24]'
                  }`}
                />
                <span className="text-xs sm:text-[13.5px] font-bold text-purple-100 tracking-wide">
                  {isMicActive
                    ? micPhase === 'ai_speaking' || voiceStatus === 'speaking'
                      ? 'ज़ोया बोल रही है • बंद करें'
                      : micPhase === 'processing' || voiceStatus === 'processing'
                      ? 'ज़ोया सोच रही है... • बंद करें'
                      : 'सुन रहा है • बंद करें'
                    : 'माइक चालू करें'}
                </span>
              </button>

              {/* Chat Input Bar: Enlarged [✦ Sparkles] "Ask me anything..." [➤ Larger Pink/Purple Send Button] */}
              <form
                onSubmit={handleSendInput}
                className="w-full bg-[#100926]/95 border border-purple-500/55 backdrop-blur-md rounded-full px-4 py-2 sm:py-2.5 flex items-center gap-2.5 shadow-[0_0_24px_rgba(139,92,246,0.32)] focus-within:border-purple-400 transition-colors"
              >
                <div className="pl-1 shrink-0">
                  <Sparkles className="w-5 h-5 text-purple-300" />
                </div>
                <input
                  type="text"
                  value={inputText}
                  onChange={(e) => {
                    const val = e.target.value;
                    isVoiceInputRef.current = false;
                    hasManualTextRef.current = val.trim().length > 0;
                    setInputText(val);
                  }}
                  onFocus={() => {
                    isInputFocusedRef.current = true;
                  }}
                  onBlur={() => {
                    isInputFocusedRef.current = false;
                  }}
                  placeholder="Ask me anything..."
                  className="w-full bg-transparent text-sm sm:text-base font-medium text-white placeholder-purple-200/55 outline-none px-1"
                />
                <button
                  type="submit"
                  className="w-10 h-10 sm:w-11 sm:h-11 rounded-full bg-gradient-to-tr from-pink-500 via-fuchsia-500 to-purple-500 hover:brightness-110 active:scale-95 flex items-center justify-center text-white shrink-0 shadow-[0_0_16px_rgba(236,72,153,0.8)] transition-all cursor-pointer"
                  title="Send"
                >
                  <Send className="w-4.5 h-4.5 sm:w-5 sm:h-5" />
                </button>
              </form>

              {/* 5 Enlarged Equal-Sized Action Buttons: Chat | Create Image | Write | Python | Agent */}
              <div className="grid grid-cols-5 gap-1.5 sm:gap-2.5 w-full mt-2.5">
                {/* 1. Chat */}
                <button
                  onClick={() => setShowTextChat(true)}
                  className="w-full h-[92px] sm:h-[102px] p-1.5 sm:p-2 rounded-2xl bg-[#110a2a]/95 hover:bg-[#180f38] border border-purple-500/55 shadow-[0_0_16px_rgba(168,85,247,0.25)] flex flex-col items-center justify-center text-center cursor-pointer transition-all active:scale-95 group"
                >
                  <div className="w-9 h-9 sm:w-11 sm:h-11 rounded-xl bg-purple-950/85 border border-purple-400/65 shadow-[0_0_12px_rgba(168,85,247,0.5)] flex items-center justify-center text-purple-200 group-hover:text-white transition-colors shrink-0">
                    <MessageSquare className="w-4.5 h-4.5 sm:w-5.5 sm:h-5.5" />
                  </div>
                  <h4 className="text-[11px] sm:text-[13.5px] font-extrabold text-white tracking-tight mt-1.5 leading-tight">
                    Chat
                  </h4>
                  <p className="text-[9px] sm:text-[11px] font-medium text-purple-200/85 leading-tight truncate w-full mt-0.5">
                    Answers
                  </p>
                </button>

                {/* 2. Create Image (Photo to sketch) */}
                <input
                  ref={sketchFileInputRef}
                  type="file"
                  accept="image/jpeg,image/png,image/webp,image/jpg,image/heic,image/*"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) {
                      setSelectedSketchFile(file);
                      setShowSketchCanvas(true);
                    }
                    e.target.value = '';
                  }}
                  className="hidden"
                />
                <button
                  onClick={() => {
                    sketchFileInputRef.current?.click();
                  }}
                  className="w-full h-[92px] sm:h-[102px] p-1.5 sm:p-2 rounded-2xl bg-[#0c132c]/95 hover:bg-[#111c3d] border border-cyan-400/55 shadow-[0_0_16px_rgba(34,211,238,0.25)] flex flex-col items-center justify-center text-center cursor-pointer transition-all active:scale-95 group"
                >
                  <div className="w-9 h-9 sm:w-11 sm:h-11 rounded-xl bg-cyan-950/85 border border-cyan-400/65 shadow-[0_0_12px_rgba(34,211,238,0.5)] flex items-center justify-center text-cyan-200 group-hover:text-white transition-colors shrink-0">
                    <ImageIcon className="w-4.5 h-4.5 sm:w-5.5 sm:h-5.5" />
                  </div>
                  <h4 className="text-[11px] sm:text-[13.5px] font-extrabold text-white tracking-tight mt-1.5 leading-tight truncate w-full">
                    Image
                  </h4>
                  <p className="text-[9px] sm:text-[11px] font-medium text-cyan-200/85 leading-tight truncate w-full mt-0.5">
                    Sketch
                  </p>
                </button>

                {/* 3. Build a Website (Reopens active/finished build or opens blank canvas) */}
                <button
                  data-testid="home-website-builder-btn"
                  onClick={() => setShowWebsiteBuilder(true)}
                  className="w-full h-[92px] sm:h-[102px] p-1.5 sm:p-2 rounded-2xl bg-[#1a0b2a]/95 hover:bg-[#25103a] border border-pink-500/55 shadow-[0_0_16px_rgba(236,72,153,0.25)] flex flex-col items-center justify-center text-center cursor-pointer transition-all active:scale-95 group"
                >
                  <div className="w-9 h-9 sm:w-11 sm:h-11 rounded-xl bg-pink-950/85 border border-pink-400/65 shadow-[0_0_12px_rgba(236,72,153,0.5)] flex items-center justify-center text-pink-200 group-hover:text-white transition-colors shrink-0">
                    <Globe className="w-4.5 h-4.5 sm:w-5.5 sm:h-5.5" />
                  </div>
                  <h4 className="text-[11px] sm:text-[13.5px] font-extrabold text-white tracking-tight mt-1.5 leading-tight truncate w-full">
                    {websiteBuildState.status === 'streaming'
                      ? `Building ${websiteBuildState.progress}%`
                      : 'Website'}
                  </h4>
                  <p className="text-[9px] sm:text-[11px] font-medium text-pink-200/85 leading-tight truncate w-full mt-0.5">
                    {websiteBuildState.status === 'streaming'
                      ? 'Live Build'
                      : websiteBuildState.status === 'ready'
                      ? 'Ready (100%)'
                      : 'Builder'}
                  </p>
                </button>

                {/* 4. Python */}
                <button
                  onClick={() => {
                    setPythonInitialPrompt('');
                    setShowPythonStudio(true);
                  }}
                  className="w-full h-[92px] sm:h-[102px] p-1.5 sm:p-2 rounded-2xl bg-[#091c24]/95 hover:bg-[#0d2833] border border-emerald-400/55 shadow-[0_0_16px_rgba(168,85,247,0.25)] flex flex-col items-center justify-center text-center cursor-pointer transition-all active:scale-95 group"
                >
                  <div className="w-9 h-9 sm:w-11 sm:h-11 rounded-xl bg-emerald-950/85 border border-emerald-400/65 shadow-[0_0_12px_rgba(16,185,129,0.5)] flex items-center justify-center text-emerald-300 group-hover:text-white transition-colors shrink-0">
                    <Code className="w-4.5 h-4.5 sm:w-5.5 sm:h-5.5" />
                  </div>
                  <h4 className="text-[11px] sm:text-[13.5px] font-extrabold text-white tracking-tight mt-1.5 leading-tight">
                    Python
                  </h4>
                  <p className="text-[9px] sm:text-[11px] font-medium text-emerald-200/85 leading-tight truncate w-full mt-0.5">
                    Scripts
                  </p>
                </button>

                {/* 5. Coding Agent */}
                <button
                  data-testid="home-coding-agent-btn"
                  onClick={() => setShowCodingAgent(true)}
                  className="w-full h-[92px] sm:h-[102px] p-1.5 sm:p-2 rounded-2xl bg-[#1b0a33]/95 hover:bg-[#280e4c] border border-violet-400/55 shadow-[0_0_16px_rgba(139,92,246,0.35)] flex flex-col items-center justify-center text-center cursor-pointer transition-all active:scale-95 group"
                >
                  <div className="w-9 h-9 sm:w-11 sm:h-11 rounded-xl bg-violet-950/85 border border-violet-400/65 shadow-[0_0_12px_rgba(139,92,246,0.5)] flex items-center justify-center text-violet-300 group-hover:text-white transition-colors shrink-0">
                    <Terminal className="w-4.5 h-4.5 sm:w-5.5 sm:h-5.5" />
                  </div>
                  <h4 className="text-[11px] sm:text-[13.5px] font-extrabold text-white tracking-tight mt-1.5 leading-tight">
                    Agent
                  </h4>
                  <p className="text-[9px] sm:text-[11px] font-medium text-violet-200/85 leading-tight truncate w-full mt-0.5">
                    Workspace
                  </p>
                </button>
              </div>
            </div>
          </main>

          {/* 3. ENLARGED BOTTOM NAVIGATION BAR (Home, Chat, Center Waveform Orb, History, Memory) */}
          <footer className="relative z-30 w-full max-w-lg md:max-w-xl mx-auto px-3 sm:px-4 pb-2.5 sm:pb-3.5 pt-1 shrink-0">
            <nav className="w-full px-3.5 sm:px-6 py-2 sm:py-2.5 bg-[#0e0824]/95 border border-purple-500/50 backdrop-blur-xl rounded-[28px] flex items-center justify-between shadow-[0_10px_36px_rgba(0,0,0,0.88),0_0_22px_rgba(139,92,246,0.25)]">
              
              {/* 1. Home (Active) */}
              <button
                onClick={() => {}}
                className="flex flex-col items-center justify-center h-[56px] sm:h-[62px] min-w-[58px] sm:min-w-[68px] rounded-2xl text-amber-400 active:scale-95 transition-all cursor-pointer"
              >
                <Home className="w-6 h-6 text-amber-400 drop-shadow-[0_0_8px_rgba(251,191,36,0.65)]" />
                <span className="text-xs sm:text-[13px] font-extrabold text-amber-400 tracking-wide mt-1">
                  Home
                </span>
                <span className="w-5 h-0.5 bg-amber-400 rounded-full mt-0.5 shadow-[0_0_8px_rgba(251,191,36,0.9)]" />
              </button>

              {/* 2. Chat */}
              <button
                onClick={() => setShowTextChat(true)}
                className="flex flex-col items-center justify-center h-[56px] sm:h-[62px] min-w-[58px] sm:min-w-[68px] rounded-2xl text-purple-200/90 hover:text-white active:scale-95 transition-all cursor-pointer"
              >
                <MessageSquare className="w-6 h-6" />
                <span className="text-xs sm:text-[13px] font-bold tracking-wide mt-1">
                  Chat
                </span>
                <span className="w-5 h-0.5 bg-transparent rounded-full mt-0.5" />
              </button>

              {/* Center Waveform Voice Orb (Enlarged) */}
              <button
                onClick={handleTapToTalk}
                className="relative flex items-center justify-center w-14 h-14 sm:w-16 sm:h-16 rounded-full bg-[#130a2e] border-[2.5px] border-purple-400/90 shadow-[0_0_26px_rgba(168,85,247,0.8),inset_0_0_14px_rgba(34,211,238,0.4)] active:scale-95 transition-transform cursor-pointer shrink-0 mx-1"
                title={isMicActive ? 'सुन रहा है • बंद करें' : 'माइक चालू करें'}
              >
                <div className="flex items-center justify-center gap-[3.5px]">
                  {[12, 20, 28, 20, 12].map((h, i) => (
                    <span
                      key={i}
                      style={{ height: `${h}px` }}
                      className={`w-[3px] rounded-full bg-gradient-to-t from-pink-400 via-purple-300 to-cyan-300 ${
                        isButtonSpinning ? 'animate-pulse' : ''
                      }`}
                    />
                  ))}
                </div>
              </button>

              {/* 3. History */}
              <button
                onClick={() => setIsHistoryOpen(true)}
                className="flex flex-col items-center justify-center h-[56px] sm:h-[62px] min-w-[58px] sm:min-w-[68px] rounded-2xl text-purple-200/90 hover:text-white active:scale-95 transition-all cursor-pointer"
                title="Activity History"
              >
                <History className="w-6 h-6" />
                <span className="text-xs sm:text-[13px] font-bold tracking-wide mt-1">
                  History
                </span>
                <span className="w-5 h-0.5 bg-transparent rounded-full mt-0.5" />
              </button>

              {/* 4. Memory */}
              <button
                onClick={() => setIsMemoryOpen(true)}
                className="flex flex-col items-center justify-center h-[56px] sm:h-[62px] min-w-[58px] sm:min-w-[68px] rounded-2xl text-purple-200/90 hover:text-white active:scale-95 transition-all cursor-pointer"
                title="Zoya Memory & Notes"
              >
                <Brain className="w-6 h-6" />
                <span className="text-xs sm:text-[13px] font-bold tracking-wide mt-1">
                  Memory
                </span>
                <span className="w-5 h-0.5 bg-transparent rounded-full mt-0.5" />
              </button>
            </nav>
          </footer>
        </>
      )}

      {/* Slide-in Menu Drawer (Contains 9 Quick Actions + Utilities + Bottom Nav) */}
      <ZoyaMenuDrawer
        isOpen={isMenuOpen}
        onClose={() => setIsMenuOpen(false)}
        onOpenInstagramGrowth={() => {
          setSettingsInitialSection('instagram_growth');
          setIsSettingsOpen(true);
        }}
        onOpenAppLauncher={() => setShowAppLauncher(true)}
        onOpenPhoneCall={() => {
          setCallContact('Mummy');
          setShowPhoneCall(true);
        }}
        onOpenMessageComposer={() => {
          setMessageRecipient('Papa');
          setShowMessageComposer(true);
        }}
        onOpenWebsiteBuilder={() => {
          setIsMenuOpen(false);
          setShowWebsiteBuilder(true);
        }}
        onOpenSketchCanvas={() => setShowSketchCanvas(true)}
        onOpenVoiceCall={() => setShowVoiceCall(true)}
        onOpenTextChat={() => setShowTextChat(true)}
        onOpenPythonStudio={() => setShowPythonStudio(true)}
        onOpenCodingAgent={() => setShowCodingAgent(true)}
        onOpenSettings={() => {
          setSettingsInitialSection('general');
          setIsSettingsOpen(true);
        }}
        onOpenHologramSettings={() => {
          setSettingsInitialSection('hologram');
          setIsSettingsOpen(true);
        }}
        onResetChat={handleResetChat}
        onOpenDiagnostic={() => setShowDiagnosticModal(true)}
        onOpenHistory={() => setIsHistoryOpen(true)}
        onOpenMemory={() => setIsMemoryOpen(true)}
        onOpen14LivingAvatarsShowcase={() => setShow14LivingShowcase(true)}
        personaMode={personaMode}
      />

      {/* History Modal */}
      <ZoyaHistoryModal
        isOpen={isHistoryOpen}
        onClose={() => setIsHistoryOpen(false)}
        onRepeatAction={(item) => {
          setIsHistoryOpen(false);
          handleProcessUserQuery(item.title);
        }}
      />

      {/* Memory Modal */}
      <ZoyaMemoryModal
        isOpen={isMemoryOpen}
        onClose={() => setIsMemoryOpen(false)}
        personaMode={personaMode}
        onSelectPersonaMode={handleSetPersonaMode}
        onOpenChat={() => setShowTextChat(true)}
        onOpenHistory={() => setIsHistoryOpen(true)}
      />

      {/* Settings Modal (Includes Voice System Section & 3D Memory Background Option) */}
      <ZoyaSettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        use3DMemoryBackground={use3DMemoryBackground}
        onToggle3DMemoryBackground={handleToggle3DMemoryBackground}
        onTapAvatar={handleTapAvatar}
        avatarStyle={avatarStyle}
        setAvatarStyle={setAvatarStyle}
        personaMode={personaMode}
        setPersonaMode={handleSetPersonaMode}
        voiceSpeed={voiceSpeed}
        setVoiceSpeed={setVoiceSpeed}
        voiceVolume={voiceVolume}
        onVoiceVolumeChange={handleSetVoiceVolume}
        automaticListening={automaticListening}
        onToggleAutomaticListening={handleToggleAutomaticListening}
        hardwareState={hardwareState}
        micPermissionState={micPermissionState}
        micDebugLog={micDebugLog}
        lastMicError={lastMicError}
        recLanguage={recLanguage}
        setRecLanguage={handleSetLanguage}
        isIframe={isIframe}
        voiceStatus={voiceStatus}
        onTapToTalk={handleTapToTalk}
        onRequestMicPermission={handleRequestMicPermission}
        onRunLiveListeningTest3Seconds={async () => {
          setMicDebugLog('Running real 3s microphone + STT capture test...');
          const res = await speechManager.runLiveListeningTest3Seconds();
          if (res.success && res.finalText) {
            setLiveTranscript(`"${res.finalText}"`);
            setMicDebugLog(`Transcribed (RMS ${res.peakRms?.toFixed(3) || '0'}): "${res.finalText}"`);
            handleProcessUserQuery(res.finalText, 'voice');
          } else {
            const err = res.error || 'No audible speech captured in 3s test';
            setLastMicError(err);
            setMicDebugLog(`3s Live Test Failed: ${err}`);
          }
        }}
        onRunPipelineTest={async () => {
          setMicDebugLog('Testing live mic -> STT pipeline...');
          const res = await speechManager.testLiveAudioPipeline();
          if (res.success && res.transcript) {
            setMicDebugLog(`Pipeline OK: "${res.transcript}"`);
          } else {
            const err = res.error || 'Live audio pipeline test failed';
            setLastMicError(err);
            setMicDebugLog(`Pipeline Failed: ${err}`);
          }
        }}
        initialSection={settingsInitialSection}
        onOpenPythonStudio={() => setShowPythonStudio(true)}
        selected3DAvatarId={selected3DAvatarId}
        onSelect3DAvatar={handleSelect3DAvatar}
        is3DAvatarActive={is3DAvatarActive}
        onToggle3DAvatar={handleToggle3DAvatar}
        onToggle3DAvatarGlobal={handleToggle3DAvatarGlobal}
        avatarScale={avatarScale}
        onChangeAvatarScale={handleChangeAvatarScale}
        avatarOffsetY={avatarOffsetY}
        onChangeAvatarOffsetY={handleChangeAvatarOffsetY}
        onResetAvatarControls={handleResetAvatarControls}
        onOpen14LivingAvatarsShowcase={() => setShow14LivingShowcase(true)}
      />


      {/* 7 Action Modals */}
      <AppLauncherModal
        isOpen={showAppLauncher}
        onClose={() => setShowAppLauncher(false)}
        initialApp="youtube"
      />

      <PhoneCallModal
        isOpen={showPhoneCall}
        onClose={() => setShowPhoneCall(false)}
        defaultContact={callContact}
      />

      <MessageComposerModal
        isOpen={showMessageComposer}
        onClose={() => setShowMessageComposer(false)}
        defaultRecipient={messageRecipient}
      />

      <WebsiteBuilderModal
        isOpen={showWebsiteBuilder}
        onClose={() => {
          setShowWebsiteBuilder(false);
          setIsMenuOpen(false);
          setWebsitePrompt('');
        }}
        initialPrompt={websitePrompt}
      />

      <SketchCanvasModal
        isOpen={showSketchCanvas}
        onClose={() => {
          setShowSketchCanvas(false);
          setSelectedSketchFile(null);
        }}
        initialFile={selectedSketchFile}
      />

      <FullVoiceCallModal
        isOpen={showVoiceCall}
        onClose={() => setShowVoiceCall(false)}
        avatarStyle={avatarStyle}
        language={recLanguage}
        personaMode={personaMode}
        onUserSpoke={(text) => {
          if (isWebsiteIntentPrompt(text) || isWaitingForWebsiteRequirements()) {
            void dispatchWebsiteCommandRef.current(text, 'call', true);
            return true;
          }
          return false;
        }}
      />

      <TextChatModal
        isOpen={showTextChat}
        onClose={() => setShowTextChat(false)}
        personaMode={personaMode}
        language={recLanguage}
        onSpeakText={speakResponse}
        initialPrompt={chatInitialPrompt}
        onClearInitialPrompt={() => setChatInitialPrompt('')}
        onOpenWebsiteBuilder={(prompt) => {
          showTextChatRef.current = false;
          setShowTextChat(false);
          void dispatchWebsiteCommandRef.current(prompt, 'manual', true);
        }}
        onOpenToolApiKeys={() => {
          setShowTextChat(false);
          setSettingsInitialSection('tool_api_keys');
          setIsSettingsOpen(true);
        }}
      />

      {/* Official YouTube Results & Playback Modal (Requirement 3 & 4) */}
      <YouTubeResultsModal
        isOpen={showYouTubeModal}
        onClose={() => setShowYouTubeModal(false)}
        title={youtubeModalTitle}
        singerName={youtubeModalSinger}
        videos={youtubeModalVideos}
      />

      {/* Complete Zoya Python Development & Autonomous App Builder Studio */}
      <PythonStudioModal
        isOpen={showPythonStudio}
        onClose={() => setShowPythonStudio(false)}
        initialPrompt={pythonInitialPrompt}
      />

      {/* Autonomous Coding Agent Workspace (Phase 6: 9 Tabs, Guard, Skills, MCP) */}
      <CodingAgentModal
        isOpen={showCodingAgent}
        onClose={() => setShowCodingAgent(false)}
      />

      {/* 14 Living Avatars Showcase: Locked-Off Camera Shot (Hair Breeze & Staggered Biological Blinking) */}
      <All14LivingAvatarsShowcase
        isOpen={show14LivingShowcase}
        onClose={() => setShow14LivingShowcase(false)}
      />

      {/* Voice Interaction Overlay (Ported from AssistantUI in OpenClawSession.kt) */}
      <VoiceInteractionOverlay
        isOpen={isVoiceOverlayOpen}
        state={assistantState}
        displayText={liveTranscript}
        userQuery={liveTranscript}
        partialText={liveTranscript}
        onClose={() => {
          stopAllAudioPlayback();
          speechManager.resumeAfterAssistantSpeaking();
          setIsVoiceOverlayOpen(false);
          if (isGlobalMicOnRef.current) {
            setAssistantState(AssistantState.LISTENING);
            setVoiceStatus('listening');
            setMicPhase('listening');
          } else {
            speechManager.stopListening();
            setAssistantState(AssistantState.IDLE);
            setVoiceStatus('idle');
            if (typeof window !== 'undefined' && (window as any).AndroidBridge?.resumeWakeWordListening) {
              (window as any).AndroidBridge.resumeWakeWordListening();
            }
          }
        }}
        onRetry={() => {
          handleTapToTalk();
        }}
        onInterrupt={() => {
          handleTapToTalk();
        }}
      />

      {/* 3D Floating Holographic AI Companion (23 Styles, Dynamic Glow, Draggable & Speaking Enlargement) */}
      {!isSettingsOpen && (
        <FloatingHologramOverlay
          voiceStatus={voiceStatus}
          onTapToTalk={handleTapToTalk}
          onOpenSettings={() => {
            setSettingsInitialSection('hologram');
            setIsSettingsOpen(true);
          }}
        />
      )}



      {/* On-Device Latency Log Modal (Round 5 Item 2) */}
      <LatencyLogModal
        isOpen={showLatencyLogModal}
        onClose={() => setShowLatencyLogModal(false)}
        onSpeakText={speakResponse}
      />

      {/* Diagnostic Modal */}
      {showDiagnosticModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-slate-950/90 backdrop-blur-md overflow-y-auto">
          <div className="relative w-full max-w-4xl bg-slate-900 rounded-3xl border border-slate-800 p-6 shadow-2xl max-h-[90vh] overflow-y-auto space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-base font-bold text-slate-100">
                System Diagnostic Report
              </h3>
              <button
                onClick={() => setShowDiagnosticModal(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <DiagnosticDashboard files={archiveFiles} />
          </div>
        </div>
      )}

      {/* Complete TTS Diagnostic Modal */}
      <TtsDiagnosticModal
        isOpen={showTtsDiagnosticModal}
        onClose={() => setShowTtsDiagnosticModal(false)}
      />

      {/* Persistent Global Corner Listening Indicator — Visible across EVERY mode, screen, tab & modal */}
      <ZoyaSmallListeningIndicator
        recLanguage={recLanguage}
        isHandsFreeActive={isGlobalMicOn}
        onStopHandsFree={stopGlobalMicSession}
        personaMode={personaMode}
      />
    </div>
  );
}
