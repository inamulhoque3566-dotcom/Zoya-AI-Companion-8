import React, { useState, useEffect, useRef } from 'react';
import {
  X,
  Play,
  Terminal,
  Smartphone,
  Download,
  Github,
  Sparkles,
  ShieldCheck,
  AlertTriangle,
  CheckCircle2,
  Code,
  FileCode,
  Loader2,
  Settings,
  ExternalLink,
  Copy,
  Check,
  RefreshCw,
  Trash2,
  PackageCheck,
  KeyRound,
  RotateCcw,
} from 'lucide-react';
import {
  pythonService,
  GeneratedAppProject,
  PythonRunResult,
  GitHubConnectionTestResponse,
} from '../../services/pythonService';
import { isRunningInAndroidApk } from '../../services/secretVault';

interface PythonStudioModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialPrompt?: string;
}

const SAMPLE_PYTHON_SCRIPTS = [
  {
    name: '📊 Data & Math Analyzer',
    code: `# Zoya Python 3.10 Sandbox
import math
import statistics

scores = [88, 92, 79, 95, 100, 84, 91]
print("Zoya Python Engine Active!")
print(f"Count: {len(scores)}")
print(f"Average: {statistics.mean(scores):.2f}")
print(f"Median: {statistics.median(scores)}")
print(f"Std Dev: {statistics.stdev(scores):.2f}")
`,
  },
  {
    name: '🔐 Password & Token Generator',
    code: `# Secure Token Generator
import secrets
import string

alphabet = string.ascii_letters + string.digits + "!@#$%^&*"
password = ''.join(secrets.choice(alphabet) for _ in range(16))
print("Generated Secure Password:", password)
print("Hex API Token:", secrets.token_hex(16))
`,
  },
  {
    name: '📱 Android Manifest Validator',
    code: `# Validates Android SDK & Package Naming Rules
import json

config = {
    "appName": "Zoya Smart Notes",
    "packageName": "com.zoya.smartnotes",
    "minSdk": 26,
    "targetSdk": 34,
    "permissions": ["INTERNET", "VIBRATE"]
}
print("Validating Android Build Spec:")
print(json.dumps(config, indent=2))
`,
  },
];

const SAMPLE_APP_IDEAS = [
  'Create a bilingual Hindi/English Daily Expense Tracker app with category summary and reset button',
  'एक स्मार्ट रिमाइंडर और नोट्स ऐप बनाओ जिसमें डार्क मोड और सर्च फ़ीचर हो',
  'Build a Pomodoro Study Timer & Task Checklist Android app in Kotlin',
  'Create a Unit & Currency Converter Android app with clean Material cards',
];

type StepStatus = 'idle' | 'running' | 'success' | 'error';

interface PipelineStepState {
  id: 'create_repo' | 'push_files' | 'push_workflow' | 'trigger_workflow' | 'poll_status' | 'get_apk';
  number: number;
  title: string;
  subtitle: string;
  status: StepStatus;
  detailText?: string;
  errorText?: string;
}

const INITIAL_PIPELINE_STEPS: PipelineStepState[] = [
  {
    id: 'create_repo',
    number: 1,
    title: 'Create Repository',
    subtitle: 'Create or verify repository via GitHub REST API',
    status: 'idle',
  },
  {
    id: 'push_files',
    number: 2,
    title: 'Push Project Files',
    subtitle: 'Upload Kotlin/Java source, layouts, and Gradle build files',
    status: 'idle',
  },
  {
    id: 'push_workflow',
    number: 3,
    title: 'Add GitHub Actions Workflow',
    subtitle: 'Push .github/workflows/build.yml (Gradle APK + Release asset publisher)',
    status: 'idle',
  },
  {
    id: 'trigger_workflow',
    number: 4,
    title: 'Run Workflow',
    subtitle: 'Dispatch GitHub Actions runner & capture workflow run ID',
    status: 'idle',
  },
  {
    id: 'poll_status',
    number: 5,
    title: 'Poll Gradle Build Status',
    subtitle: 'Monitor ubuntu-latest Gradle assembleDebug & Release asset upload',
    status: 'idle',
  },
  {
    id: 'get_apk',
    number: 6,
    title: 'Get APK (Native Bridge / Release Asset)',
    subtitle: 'Download compiled .apk into phone Downloads folder & launch installer',
    status: 'idle',
  },
];

export const PythonStudioModal: React.FC<PythonStudioModalProps> = ({
  isOpen,
  onClose,
  initialPrompt = '',
}) => {
  const [activeTab, setActiveTab] = useState<'app_builder' | 'python_ide' | 'settings'>('app_builder');
  const [pythonEnv, setPythonEnv] = useState<{
    available: boolean;
    version: string;
    executable: string;
    platform: string;
  }>({
    available: true,
    version: '3.10.12',
    executable: '/usr/bin/python3',
    platform: 'linux',
  });

  // Python IDE State
  const [hasStarted, setHasStarted] = useState<boolean>(false);
  const [code, setCode] = useState<string>('');
  const [files, setFiles] = useState<Record<string, string>>({});
  const [buildStep, setBuildStep] = useState<string>('idle');
  const [buildProgress, setBuildProgress] = useState<number>(0);
  const [stdinText, setStdinText] = useState<string>('');
  const [isRunningCode, setIsRunningCode] = useState<boolean>(false);
  const [runResult, setRunResult] = useState<PythonRunResult | null>(null);

  const resetToEmptyScreen = () => {
    setHasStarted(false);
    setCode('');
    setFiles({});
    setBuildStep('idle');
    setBuildProgress(0);
    setRunResult(null);
  };

  // Android App Builder State
  const [appPrompt, setAppPrompt] = useState<string>(initialPrompt || '');
  const [customAppName, setCustomAppName] = useState<string>('');
  const [preferredLang, setPreferredLang] = useState<'kotlin' | 'java'>('kotlin');
  const [isGeneratingApp, setIsGeneratingApp] = useState<boolean>(false);
  const [appError, setAppError] = useState<string>('');
  const [safetyBlocked, setSafetyBlocked] = useState<boolean>(false);
  const [generatedApp, setGeneratedApp] = useState<GeneratedAppProject | null>(null);
  const [selectedFileIndex, setSelectedFileIndex] = useState<number>(0);
  const [copiedFile, setCopiedFile] = useState<boolean>(false);

  // Local Source Code Bundle (.zip) State (Round 5 Item 3: NEVER named .apk)
  const [isPackagingLocal, setIsPackagingLocal] = useState<boolean>(false);
  const [localBundleInfo, setLocalBundleInfo] = useState<{
    fileName?: string;
    downloadUrl?: string;
    sizeBytes?: number;
    label?: string;
    message?: string;
    error?: string;
  } | null>(null);

  // GitHub Connection Test & 6-Step APK Pipeline State (Round 5 Item 4B & 4C)
  const [githubToken, setGithubToken] = useState<string>('');
  const [isPrivateRepo, setIsPrivateRepo] = useState<boolean>(false);
  const [isTestingGithub, setIsTestingGithub] = useState<boolean>(false);
  const [githubTestResult, setGithubTestResult] = useState<GitHubConnectionTestResponse | null>(null);

  const [pipelineSteps, setPipelineSteps] = useState<PipelineStepState[]>(INITIAL_PIPELINE_STEPS);
  const [isBuildingApk, setIsBuildingApk] = useState<boolean>(false);
  const [buildStatus, setBuildStatus] = useState<{
    stage: 'idle' | 'pushing' | 'building' | 'completed' | 'failed';
    message: string;
    owner?: string;
    repo?: string;
    repoUrl?: string;
    actionsUrl?: string;
    runId?: number;
    artifactUrl?: string;
    releaseAssetApiUrl?: string;
    releaseBrowserDownloadUrl?: string;
    releaseAssetName?: string;
    releaseTag?: string;
    jobSteps?: Array<{ name: string; status: string; conclusion: string | null }>;
  }>({ stage: 'idle', message: '' });

  // Native Bridge APK Download & Install State (Round 5 Item 4C)
  const [isDownloadingNativeApk, setIsDownloadingNativeApk] = useState<boolean>(false);
  const [nativeDownloadResult, setNativeDownloadResult] = useState<{
    success: boolean;
    usedNativeBridge: boolean;
    filePath?: string;
    fileName?: string;
    bytesDownloaded?: number;
    fallbackUrl?: string;
    message: string;
  } | null>(null);
  const [installFeedback, setInstallFeedback] = useState<string>('');

  // Custom AI Brain Settings State
  const [modelName, setModelName] = useState<string>(() => pythonService.getSavedModelConfig().modelName);
  const [customApiKey, setCustomApiKey] = useState<string>('');
  const [settingsSavedToast, setSettingsSavedToast] = useState<boolean>(false);

  const pollTimerRef = useRef<any>(null);

  useEffect(() => {
    if (isOpen) {
      pythonService.getStatus().then(setPythonEnv);
      pythonService.getSavedGitHubToken().then((t) => {
        if (t) setGithubToken(t);
      });
      pythonService.getSavedModelConfigAsync().then((cfg) => {
        setModelName(cfg.modelName);
        setCustomApiKey(cfg.apiKey);
      });
      if (initialPrompt && initialPrompt.trim()) {
        setAppPrompt(initialPrompt);
        setActiveTab('app_builder');
      } else {
        resetToEmptyScreen();
      }
    }
    return () => {
      if (pollTimerRef.current) clearInterval(pollTimerRef.current);
    };
  }, [isOpen, initialPrompt]);

  if (!isOpen) return null;

  const updateStepState = (
    stepId: PipelineStepState['id'],
    patch: Partial<PipelineStepState>
  ) => {
    setPipelineSteps((prev) =>
      prev.map((s) => (s.id === stepId ? { ...s, ...patch } : s))
    );
  };

  const resetPipelineSteps = () => {
    setPipelineSteps(INITIAL_PIPELINE_STEPS.map((s) => ({ ...s, status: 'idle', detailText: undefined, errorText: undefined })));
    setNativeDownloadResult(null);
    setInstallFeedback('');
  };

  const handleRunPython = async () => {
    if (!code.trim() || isRunningCode) return;
    setIsRunningCode(true);
    setRunResult(null);
    const res = await pythonService.runPythonCode(code, stdinText, 15000);
    setRunResult(res);
    setIsRunningCode(false);
  };

  const handleGenerateApp = async () => {
    if (!appPrompt.trim() || isGeneratingApp) return;
    setIsGeneratingApp(true);
    setAppError('');
    setSafetyBlocked(false);
    setGeneratedApp(null);
    setLocalBundleInfo(null);
    setBuildStatus({ stage: 'idle', message: '' });
    resetPipelineSteps();

    const res = await pythonService.generateAndroidApp({
      prompt: appPrompt,
      appName: customAppName || undefined,
      language: preferredLang,
    });

    setIsGeneratingApp(false);

    if (!res.success || !res.app) {
      setSafetyBlocked(Boolean(res.safetyBlocked));
      setAppError(res.error || 'Failed to generate Android project.');
      return;
    }

    setGeneratedApp(res.app);
    setSelectedFileIndex(0);

    // Automatically package local Source Code Bundle (.zip) — NEVER named .apk
    setIsPackagingLocal(true);
    const localRes = await pythonService.packageLocalSourceBundle({
      appName: res.app.appName,
      packageName: res.app.packageName,
      versionName: res.app.versionName,
      files: res.app.files,
    });
    setIsPackagingLocal(false);
    if (localRes.success) {
      setLocalBundleInfo({
        fileName: localRes.fileName,
        downloadUrl: localRes.downloadUrl,
        sizeBytes: localRes.sizeBytes,
        label: localRes.label || 'Source code bundle (.zip) - NOT an installable app',
        message: localRes.message,
      });
    } else {
      setLocalBundleInfo({
        error: localRes.error || 'Failed to package local source code bundle (.zip).',
      });
    }
  };

  const handleBuildLocalSourceBundleManual = async () => {
    if (!generatedApp || isPackagingLocal) return;
    setIsPackagingLocal(true);
    const localRes = await pythonService.packageLocalSourceBundle({
      appName: generatedApp.appName,
      packageName: generatedApp.packageName,
      versionName: generatedApp.versionName,
      files: generatedApp.files,
    });
    setIsPackagingLocal(false);
    if (localRes.success) {
      setLocalBundleInfo({
        fileName: localRes.fileName,
        downloadUrl: localRes.downloadUrl,
        sizeBytes: localRes.sizeBytes,
        label: localRes.label || 'Source code bundle (.zip) - NOT an installable app',
        message: localRes.message,
      });
    } else {
      setLocalBundleInfo({
        error: localRes.error || 'Failed to package local source code bundle (.zip).',
      });
    }
  };

  /**
   * ROUND 5 ITEM 4B:
   * Test GitHub Connection button handler.
   * Calls GET /user, displays username and token scopes, and clearly warns if repo or workflow scope is missing.
   */
  const handleTestGitHubConnection = async () => {
    const cleanToken = githubToken.trim();
    if (!cleanToken) {
      setGithubTestResult({
        success: false,
        message: 'Enter your GitHub Personal Access Token (ghp_...) first to test connection.',
        error: 'Missing token',
      });
      return;
    }

    setIsTestingGithub(true);
    setGithubTestResult(null);
    await pythonService.saveGitHubToken(cleanToken);
    const res = await pythonService.testGitHubConnection(cleanToken);
    setGithubTestResult(res);
    setIsTestingGithub(false);
  };

  /**
   * Executes a single step (or remaining steps from `startFromStep`) of the 6-Step GitHub APK Pipeline.
   * Every step shows real status, real error text, and a Retry button if it fails.
   */
  const runPipelineFromStep = async (
    startFromStep: PipelineStepState['id'] = 'create_repo'
  ) => {
    if (!generatedApp) return;
    const cleanToken = githubToken.trim();
    if (!cleanToken) {
      setActiveTab('settings');
      updateStepState(startFromStep, {
        status: 'error',
        errorText: 'Missing GitHub Personal Access Token. Enter your token above and click Test GitHub Connection.',
      });
      return;
    }

    await pythonService.saveGitHubToken(cleanToken);
    setIsBuildingApk(true);

    const repoSlug =
      generatedApp.appName.replace(/[^a-zA-Z0-9._-]/g, '-').toLowerCase() || 'zoya-android-app';
    let ownerName = buildStatus.owner || '';
    let repoUrl = buildStatus.repoUrl || '';
    let actionsUrl = buildStatus.actionsUrl || '';
    let activeRunId = buildStatus.runId;

    const stepOrder: PipelineStepState['id'][] = [
      'create_repo',
      'push_files',
      'push_workflow',
      'trigger_workflow',
      'poll_status',
      'get_apk',
    ];
    const startIndex = stepOrder.indexOf(startFromStep);

    for (let i = startIndex; i < stepOrder.length; i++) {
      const currentStep = stepOrder[i];

      if (
        currentStep === 'create_repo' ||
        currentStep === 'push_files' ||
        currentStep === 'push_workflow' ||
        currentStep === 'trigger_workflow'
      ) {
        updateStepState(currentStep, {
          status: 'running',
          errorText: undefined,
          detailText: `Running ${currentStep.replace('_', ' ')}...`,
        });
        setBuildStatus((prev) => ({
          ...prev,
          stage: 'pushing',
          message: `Executing Step ${i + 1}: ${currentStep.replace('_', ' ')}...`,
        }));

        const stepRes = await pythonService.triggerGitHubBuild({
          githubToken: cleanToken,
          repoName: generatedApp.appName,
          files: generatedApp.files,
          isPrivate: isPrivateRepo,
          step: currentStep,
        });

        if (!stepRes.success) {
          setIsBuildingApk(false);
          updateStepState(currentStep, {
            status: 'error',
            errorText: stepRes.error || `Step ${currentStep} failed.`,
            detailText: undefined,
          });
          setBuildStatus((prev) => ({
            ...prev,
            stage: 'failed',
            message: stepRes.error || `Failed at Step ${i + 1} (${currentStep}).`,
          }));
          return;
        }

        if (stepRes.owner) ownerName = stepRes.owner;
        if (stepRes.repoUrl) repoUrl = stepRes.repoUrl;
        if (stepRes.actionsUrl) actionsUrl = stepRes.actionsUrl;
        if (stepRes.runId) activeRunId = stepRes.runId;

        updateStepState(currentStep, {
          status: 'success',
          detailText: stepRes.message || 'Completed',
          errorText: undefined,
        });
      } else if (currentStep === 'poll_status') {
        if (!ownerName) {
          // Resolve owner from token test if retrying directly from poll_status
          const userCheck = await pythonService.testGitHubConnection(cleanToken);
          if (userCheck.success && userCheck.username) {
            ownerName = userCheck.username;
          } else {
            setIsBuildingApk(false);
            updateStepState('poll_status', {
              status: 'error',
              errorText: userCheck.error || 'Could not resolve repository owner. Retry from Step 1.',
            });
            return;
          }
        }

        updateStepState('poll_status', {
          status: 'running',
          detailText: 'Polling GitHub Actions runner every 6s...',
          errorText: undefined,
        });
        setBuildStatus((prev) => ({
          ...prev,
          stage: 'building',
          owner: ownerName,
          repo: repoSlug,
          repoUrl: repoUrl || `https://github.com/${ownerName}/${repoSlug}`,
          actionsUrl: actionsUrl || `https://github.com/${ownerName}/${repoSlug}/actions`,
          runId: activeRunId,
          message: 'GitHub Actions is compiling your Android APK & publishing Release asset...',
        }));

        // Start polling loop
        startStatusPollingLoop(ownerName, repoSlug, cleanToken, activeRunId);
        return; // Polling loop handles transitioning to Step 6 ('get_apk')
      } else if (currentStep === 'get_apk') {
        // Trigger Native Bridge APK download if Release asset is ready
        await handleDownloadReleaseApk();
        setIsBuildingApk(false);
        return;
      }
    }
  };

  const startStatusPollingLoop = (
    owner: string,
    repoSlug: string,
    token: string,
    runId?: number
  ) => {
    if (pollTimerRef.current) clearInterval(pollTimerRef.current);

    const pollOnce = async () => {
      const statusRes = await pythonService.checkGitHubBuildStatus({
        owner,
        repo: repoSlug,
        githubToken: token,
        runId,
      });

      if (!statusRes.success) {
        if (pollTimerRef.current) clearInterval(pollTimerRef.current);
        setIsBuildingApk(false);
        updateStepState('poll_status', {
          status: 'error',
          errorText: statusRes.error || 'Failed polling GitHub Actions status.',
        });
        setBuildStatus((prev) => ({
          ...prev,
          stage: 'failed',
          message: statusRes.error || 'Polling error.',
        }));
        return;
      }

      if (statusRes.status === 'completed') {
        if (pollTimerRef.current) clearInterval(pollTimerRef.current);
        setIsBuildingApk(false);

        if (statusRes.conclusion === 'success') {
          updateStepState('poll_status', {
            status: 'success',
            detailText: `Gradle assembleDebug & Release asset publish succeeded! (${statusRes.releaseTag || 'latest'})`,
            errorText: undefined,
          });
          updateStepState('get_apk', {
            status: 'success',
            detailText: statusRes.releaseAssetName
              ? `Ready: ${statusRes.releaseAssetName} (${statusRes.releaseTag || 'Release'})`
              : 'APK artifact & Release ready for download',
            errorText: undefined,
          });
          setBuildStatus((prev) => ({
            ...prev,
            stage: 'completed',
            message: 'APK compiled & published as a GitHub Release asset!',
            actionsUrl: statusRes.htmlUrl || prev.actionsUrl,
            artifactUrl: statusRes.artifactDownloadUrl,
            releaseAssetApiUrl: statusRes.releaseAssetApiUrl,
            releaseBrowserDownloadUrl: statusRes.releaseBrowserDownloadUrl,
            releaseAssetName: statusRes.releaseAssetName,
            releaseTag: statusRes.releaseTag,
            jobSteps: statusRes.steps,
          }));
        } else {
          const failedJobStep = (statusRes.steps || []).find(
            (s) => s.conclusion === 'failure'
          );
          const errDetail = failedJobStep
            ? `Workflow failed at step "${failedJobStep.name}" (conclusion: ${statusRes.conclusion}).`
            : `Build finished with status: ${statusRes.conclusion}. Check Actions log for details.`;
          updateStepState('poll_status', {
            status: 'error',
            errorText: errDetail,
          });
          setBuildStatus((prev) => ({
            ...prev,
            stage: 'failed',
            message: errDetail,
            actionsUrl: statusRes.htmlUrl || prev.actionsUrl,
            jobSteps: statusRes.steps,
          }));
        }
      } else {
        const activeJobStep = (statusRes.steps || []).find(
          (s) => s.status === 'in_progress'
        );
        updateStepState('poll_status', {
          status: 'running',
          detailText: activeJobStep
            ? `Running: ${activeJobStep.name} (${statusRes.status})...`
            : `Workflow status: ${statusRes.status}...`,
        });
        setBuildStatus((prev) => ({
          ...prev,
          jobSteps: statusRes.steps,
        }));
      }
    };

    void pollOnce();
    pollTimerRef.current = setInterval(pollOnce, 6000);
  };

  /**
   * ROUND 5 ITEM 4C:
   * Downloads the compiled Release Asset APK through the Native Android Bridge
   * (`AndroidBridge.downloadReleaseAssetApk`) into the phone's `Downloads` folder.
   */
  const handleDownloadReleaseApk = async () => {
    setIsDownloadingNativeApk(true);
    setInstallFeedback('');
    const fileName =
      buildStatus.releaseAssetName ||
      `${(generatedApp?.appName || 'zoya-app').replace(/\s+/g, '-')}-debug.apk`;

    const res = await pythonService.downloadReleaseApkViaNativeBridge({
      releaseAssetApiUrl: isPrivateRepo
        ? buildStatus.releaseAssetApiUrl || buildStatus.releaseBrowserDownloadUrl
        : buildStatus.releaseBrowserDownloadUrl || buildStatus.releaseAssetApiUrl,
      releaseBrowserDownloadUrl: buildStatus.releaseBrowserDownloadUrl,
      fileName,
      githubToken: githubToken.trim(),
    });

    setNativeDownloadResult(res);
    setIsDownloadingNativeApk(false);

    if (res.success) {
      updateStepState('get_apk', {
        status: 'success',
        detailText: res.message,
        errorText: undefined,
      });
    } else if (res.error !== 'ANDROID_BRIDGE_NOT_AVAILABLE_IN_BROWSER') {
      updateStepState('get_apk', {
        status: 'error',
        errorText: res.message,
      });
    }
  };

  const handleInstallDownloadedApk = (filePath: string) => {
    const res = pythonService.installDownloadedApkViaNativeBridge(filePath);
    setInstallFeedback(res.message);
  };

  const handleSaveSettings = async () => {
    await pythonService.saveGitHubToken(githubToken);
    await pythonService.saveModelConfig(modelName, customApiKey);
    setSettingsSavedToast(true);
    setTimeout(() => setSettingsSavedToast(false), 2500);
  };

  const handleCopyFileContent = () => {
    if (!generatedApp || !generatedApp.files[selectedFileIndex]) return;
    navigator.clipboard.writeText(generatedApp.files[selectedFileIndex].content);
    setCopiedFile(true);
    setTimeout(() => setCopiedFile(false), 1800);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-950/90 backdrop-blur-md animate-fade-in select-text">
      <div className="relative w-full max-w-5xl bg-[#090d1a] rounded-3xl border border-indigo-500/30 shadow-[0_0_60px_rgba(15,23,42,0.95)] overflow-hidden flex flex-col h-[92dvh]">
        {/* Top Header */}
        <div className="flex items-center justify-between px-4 sm:px-6 py-3.5 border-b border-slate-800 bg-slate-950/80 shrink-0">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-blue-600 via-cyan-500 to-emerald-400 flex items-center justify-center text-white shadow-lg shrink-0">
              <Code className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <h3 className="text-sm sm:text-base font-bold text-white truncate">
                  Zoya AI Python Studio &amp; Autonomous APK Builder
                </h3>
                <span
                  className={`px-2 py-0.5 text-[10px] font-mono rounded-full border ${
                    pythonEnv.available
                      ? 'bg-emerald-950/80 border-emerald-500/40 text-emerald-300'
                      : 'bg-rose-950/80 border-rose-500/40 text-rose-300'
                  }`}
                >
                  Python {pythonEnv.version}
                </span>
              </div>
              <p className="text-[11px] text-slate-400 truncate">
                Generate Android 8–15 apps, test GitHub connection, compile real APKs via GitHub Actions, or run Python 3 code
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-2 px-4 sm:px-6 py-2.5 bg-slate-950/50 border-b border-slate-800/80 shrink-0 overflow-x-auto">
          <button
            onClick={() => setActiveTab('app_builder')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer shrink-0 ${
              activeTab === 'app_builder'
                ? 'bg-gradient-to-r from-indigo-600 to-cyan-600 text-white shadow-md'
                : 'bg-slate-900/80 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            <Smartphone className="w-4 h-4" />
            <span>Autonomous Android App Builder</span>
          </button>

          <button
            onClick={() => setActiveTab('python_ide')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer shrink-0 ${
              activeTab === 'python_ide'
                ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-md'
                : 'bg-slate-900/80 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            <Terminal className="w-4 h-4" />
            <span>Python 3.10 Sandbox &amp; Runner</span>
          </button>

          <button
            onClick={() => setActiveTab('settings')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer shrink-0 ${
              activeTab === 'settings'
                ? 'bg-gradient-to-r from-purple-600 to-pink-600 text-white shadow-md'
                : 'bg-slate-900/80 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            <Settings className="w-4 h-4" />
            <span>GitHub Actions &amp; AI Brain Config</span>
          </button>
        </div>

        {/* Main Workspace Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-5">
          {/* ================================================================ */}
          {/* TAB 1: AUTONOMOUS ANDROID APP BUILDER                            */}
          {/* ================================================================ */}
          {activeTab === 'app_builder' && (
            <div className="space-y-5">
              {/* App Idea Input Card */}
              <div className="p-4 sm:p-5 rounded-2xl bg-slate-900/90 border border-indigo-500/30 space-y-4">
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-cyan-400" />
                    <h4 className="text-xs sm:text-sm font-bold text-white">
                      Describe Your Android App (Hindi, Hinglish, or English)
                    </h4>
                  </div>
                  <div className="flex items-center gap-1.5 text-[11px] text-emerald-400 bg-emerald-950/60 border border-emerald-500/30 px-2.5 py-1 rounded-full">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span>Safety &amp; Banking Shield Active</span>
                  </div>
                </div>

                {/* Quick Idea Chips */}
                <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
                  {SAMPLE_APP_IDEAS.map((idea, idx) => (
                    <button
                      key={idx}
                      onClick={() => setAppPrompt(idea)}
                      className="px-2.5 py-1 rounded-lg bg-slate-950 hover:bg-indigo-950/70 border border-slate-800 hover:border-indigo-500/40 text-[11px] text-slate-300 whitespace-nowrap cursor-pointer transition-colors"
                    >
                      {idea.slice(0, 48)}...
                    </button>
                  ))}
                </div>

                <textarea
                  value={appPrompt}
                  onChange={(e) => setAppPrompt(e.target.value)}
                  rows={3}
                  placeholder="उदाहरण: मेरे लिए एक दैनिक खर्च ट्रैकर या स्मार्ट नोट्स एंड्रॉइड ऐप बनाओ..."
                  className="w-full rounded-xl bg-slate-950 border border-slate-800 focus:border-cyan-500 p-3 text-xs sm:text-sm text-white placeholder-slate-500 outline-none resize-none"
                />

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="text-[11px] text-slate-400 block mb-1">
                      App Name (Optional)
                    </label>
                    <input
                      type="text"
                      value={customAppName}
                      onChange={(e) => setCustomAppName(e.target.value)}
                      placeholder="e.g. Zoya Smart Notes"
                      className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white outline-none focus:border-cyan-500"
                    />
                  </div>

                  <div>
                    <label className="text-[11px] text-slate-400 block mb-1">
                      Android Source Language
                    </label>
                    <div className="grid grid-cols-2 gap-1.5">
                      <button
                        type="button"
                        onClick={() => setPreferredLang('kotlin')}
                        className={`py-2 rounded-xl text-xs font-bold border cursor-pointer ${
                          preferredLang === 'kotlin'
                            ? 'bg-indigo-600/30 border-indigo-400 text-indigo-200'
                            : 'bg-slate-950 border-slate-800 text-slate-400'
                        }`}
                      >
                        Kotlin (Recommended)
                      </button>
                      <button
                        type="button"
                        onClick={() => setPreferredLang('java')}
                        className={`py-2 rounded-xl text-xs font-bold border cursor-pointer ${
                          preferredLang === 'java'
                            ? 'bg-indigo-600/30 border-indigo-400 text-indigo-200'
                            : 'bg-slate-950 border-slate-800 text-slate-400'
                        }`}
                      >
                        Java
                      </button>
                    </div>
                  </div>

                  <div className="flex items-end">
                    <button
                      onClick={handleGenerateApp}
                      disabled={isGeneratingApp || !appPrompt.trim()}
                      className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-cyan-500 via-blue-600 to-indigo-600 hover:brightness-110 disabled:opacity-50 text-white text-xs sm:text-sm font-bold flex items-center justify-center gap-2 shadow-lg cursor-pointer transition-all"
                    >
                      {isGeneratingApp ? (
                        <>
                          <Loader2 className="w-4 h-4 animate-spin" />
                          <span>Synthesizing Android Project...</span>
                        </>
                      ) : (
                        <>
                          <Sparkles className="w-4 h-4" />
                          <span>Generate Complete Android App</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>

                {/* Error or Safety Rejection Banner */}
                {appError && (
                  <div
                    className={`p-3.5 rounded-xl border flex items-start gap-2.5 text-xs ${
                      safetyBlocked
                        ? 'bg-rose-950/70 border-rose-500/60 text-rose-200'
                        : 'bg-amber-950/60 border-amber-500/50 text-amber-200'
                    }`}
                  >
                    <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5 text-rose-400" />
                    <div className="space-y-1">
                      <div className="font-bold">
                        {safetyBlocked
                          ? 'Blocked by Zoya Safety & Anti-Malware Policy'
                          : 'Generation Notice'}
                      </div>
                      <div>{appError}</div>
                    </div>
                  </div>
                )}
              </div>

              {/* ============================================================ */}
              {/* ITEM 4B: GITHUB CONNECTION TEST & TOKEN BAR (ON MAIN SCREEN) */}
              {/* ============================================================ */}
              <div
                data-testid="github-connection-panel"
                className="p-4 sm:p-5 rounded-2xl bg-slate-900/90 border border-purple-500/30 space-y-3"
              >
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <div className="flex items-center gap-2">
                    <Github className="w-4 h-4 text-purple-400" />
                    <h4 className="text-xs sm:text-sm font-bold text-white">
                      GitHub Actions APK Build Connection (Phone-Testable)
                    </h4>
                    <span className="px-2 py-0.5 text-[10px] rounded-md font-mono bg-slate-950 border border-slate-700 text-slate-300">
                      {isRunningInAndroidApk()
                        ? 'Android Keystore Active'
                        : 'Browser Memory Vault (No localStorage)'}
                    </span>
                  </div>
                  <a
                    href="https://github.com/settings/tokens/new?scopes=repo,workflow&description=Zoya+Android+APK+Builder"
                    target="_blank"
                    rel="noreferrer"
                    className="text-[11px] text-cyan-400 hover:underline flex items-center gap-1"
                  >
                    <span>Get Token (repo + workflow)</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>

                <div className="flex flex-col sm:flex-row gap-2">
                  <div className="flex-1 flex items-center gap-2 bg-slate-950 border border-slate-800 rounded-xl px-3 py-2">
                    <KeyRound className="w-4 h-4 text-purple-400 shrink-0" />
                    <input
                      type="password"
                      value={githubToken}
                      onChange={(e) => setGithubToken(e.target.value)}
                      placeholder="Enter GitHub PAT (ghp_...) on your phone to test & compile APKs"
                      className="w-full bg-transparent text-xs text-white font-mono outline-none"
                    />
                  </div>
                  <label className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-300 cursor-pointer shrink-0">
                    <input
                      type="checkbox"
                      checked={isPrivateRepo}
                      onChange={(e) => setIsPrivateRepo(e.target.checked)}
                      className="rounded"
                    />
                    <span>Private Repo</span>
                  </label>
                  <button
                    type="button"
                    data-testid="test-github-connection-btn"
                    onClick={handleTestGitHubConnection}
                    disabled={isTestingGithub}
                    className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 disabled:opacity-50 text-white text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer shrink-0 shadow-md"
                  >
                    {isTestingGithub ? (
                      <>
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                        <span>Testing GET /user...</span>
                      </>
                    ) : (
                      <>
                        <Github className="w-3.5 h-3.5" />
                        <span>Test GitHub Connection</span>
                      </>
                    )}
                  </button>
                </div>

                {/* Connection Test Result Banner */}
                {githubTestResult && (
                  <div
                    className={`p-3 rounded-xl border text-xs space-y-1.5 ${
                      !githubTestResult.success
                        ? 'bg-rose-950/70 border-rose-500/50 text-rose-200'
                        : githubTestResult.missingScopes && githubTestResult.missingScopes.length > 0
                        ? 'bg-amber-950/70 border-amber-500/50 text-amber-200'
                        : 'bg-emerald-950/70 border-emerald-500/50 text-emerald-200'
                    }`}
                  >
                    <div className="font-bold flex items-center justify-between flex-wrap gap-2">
                      <span>{githubTestResult.message}</span>
                      {githubTestResult.username && (
                        <span className="px-2 py-0.5 rounded bg-slate-950/70 font-mono text-[11px]">
                          User: @{githubTestResult.username}
                        </span>
                      )}
                    </div>
                    {githubTestResult.success && (
                      <div className="text-[11px] font-mono flex items-center gap-3 flex-wrap">
                        <span>
                          Detected Scopes:{' '}
                          {githubTestResult.scopes && githubTestResult.scopes.length > 0
                            ? githubTestResult.scopes.join(', ')
                            : githubTestResult.isFineGrained
                            ? 'Fine-Grained PAT'
                            : 'none'}
                        </span>
                        <span
                          className={
                            githubTestResult.hasRepoScope ? 'text-emerald-300' : 'text-rose-300 font-bold'
                          }
                        >
                          repo: {githubTestResult.hasRepoScope ? '✓ OK' : '✗ MISSING'}
                        </span>
                        <span
                          className={
                            githubTestResult.hasWorkflowScope
                              ? 'text-emerald-300'
                              : 'text-rose-300 font-bold'
                          }
                        >
                          workflow: {githubTestResult.hasWorkflowScope ? '✓ OK' : '✗ MISSING'}
                        </span>
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Generated Android Project Workspace */}
              {generatedApp && (
                <div className="space-y-4">
                  {/* Project Summary & Honest Bundle vs Real Cloud APK Bar */}
                  <div className="p-4 rounded-2xl bg-slate-900/95 border border-emerald-500/40 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                        <span className="text-sm font-bold text-white">
                          {generatedApp.appName}
                        </span>
                        <span className="px-2 py-0.5 text-[10px] font-mono rounded-md bg-slate-800 text-cyan-300">
                          {generatedApp.packageName}
                        </span>
                        <span className="px-2 py-0.5 text-[10px] font-mono rounded-md bg-indigo-950 text-indigo-300 border border-indigo-500/30">
                          API {generatedApp.minSdk}–{generatedApp.targetSdk} ({generatedApp.language.toUpperCase()})
                        </span>
                      </div>
                      <p className="text-xs text-slate-300">{generatedApp.description}</p>
                    </div>

                    <div className="flex items-center gap-2.5 flex-wrap shrink-0">
                      {/* ITEM 3: Clearly labeled Source Code Bundle (.zip) - NOT an installable app */}
                      {localBundleInfo?.downloadUrl ? (
                        <a
                          href={localBundleInfo.downloadUrl}
                          download={localBundleInfo.fileName}
                          className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 border border-amber-500/40 text-amber-200 text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-all"
                          title="Source code bundle (.zip) - NOT an installable app"
                        >
                          <Download className="w-3.5 h-3.5 text-amber-400" />
                          <span>
                            Source code bundle (.zip) - NOT an installable app
                          </span>
                        </a>
                      ) : (
                        <button
                          onClick={handleBuildLocalSourceBundleManual}
                          disabled={isPackagingLocal}
                          className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 border border-amber-500/40 text-amber-200 text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-all"
                        >
                          {isPackagingLocal ? (
                            <Loader2 className="w-3.5 h-3.5 animate-spin" />
                          ) : (
                            <PackageCheck className="w-3.5 h-3.5 text-amber-400" />
                          )}
                          <span>Source code bundle (.zip) - NOT an installable app</span>
                        </button>
                      )}

                      <button
                        onClick={() => runPipelineFromStep('create_repo')}
                        disabled={isBuildingApk}
                        className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:brightness-110 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-md transition-all"
                      >
                        {isBuildingApk ? (
                          <Loader2 className="w-3.5 h-3.5 animate-spin" />
                        ) : (
                          <Github className="w-3.5 h-3.5" />
                        )}
                        <span>Run 6-Step GitHub APK Pipeline</span>
                      </button>
                    </div>
                  </div>

                  {/* Honest Source Code Bundle Notice (Item 3) */}
                  {localBundleInfo?.downloadUrl && (
                    <div className="p-3.5 rounded-2xl bg-amber-950/30 border border-amber-500/40 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                      <div className="space-y-0.5">
                        <div className="text-xs font-bold text-amber-300 flex items-center gap-1.5">
                          <PackageCheck className="w-4 h-4" />
                          <span>
                            {localBundleInfo.fileName} — Source code bundle (.zip) - NOT an installable app
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-300">
                          {localBundleInfo.message} ({Math.round((localBundleInfo.sizeBytes || 0) / 1024)} KB)
                        </p>
                      </div>
                      <a
                        href={localBundleInfo.downloadUrl}
                        download={localBundleInfo.fileName}
                        className="px-4 py-2 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 border border-amber-400/50 text-amber-200 text-xs font-bold flex items-center gap-1.5 shrink-0"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>Download Source Bundle (.zip)</span>
                      </a>
                    </div>
                  )}

                  {/* ======================================================== */}
                  {/* ITEM 4B & 4C: VISIBLE 6-STEP GITHUB APK PIPELINE         */}
                  {/* ======================================================== */}
                  <div
                    data-testid="github-6step-pipeline"
                    className="p-4 rounded-2xl bg-slate-950/90 border border-cyan-500/35 space-y-3"
                  >
                    <div className="flex items-center justify-between flex-wrap gap-2">
                      <div>
                        <h4 className="text-xs sm:text-sm font-bold text-white flex items-center gap-2">
                          <Github className="w-4 h-4 text-cyan-400" />
                          <span>Step-by-Step GitHub Actions APK Build &amp; Release Pipeline</span>
                        </h4>
                        <p className="text-[11px] text-slate-400">
                          Each step shows live status and real error messages with an individual Retry button.
                        </p>
                      </div>
                      {buildStatus.actionsUrl && (
                        <a
                          href={buildStatus.actionsUrl}
                          target="_blank"
                          rel="noreferrer"
                          className="px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-cyan-300 text-xs font-semibold flex items-center gap-1.5"
                        >
                          <span>Open GitHub Actions Log</span>
                          <ExternalLink className="w-3.5 h-3.5" />
                        </a>
                      )}
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
                      {pipelineSteps.map((step) => (
                        <div
                          key={step.id}
                          className={`p-3 rounded-xl border flex flex-col justify-between gap-2 text-xs ${
                            step.status === 'success'
                              ? 'bg-emerald-950/35 border-emerald-500/40 text-emerald-100'
                              : step.status === 'running'
                              ? 'bg-cyan-950/40 border-cyan-400/60 text-cyan-100'
                              : step.status === 'error'
                              ? 'bg-rose-950/50 border-rose-500/60 text-rose-100'
                              : 'bg-slate-900/70 border-slate-800 text-slate-300'
                          }`}
                        >
                          <div className="space-y-1">
                            <div className="flex items-center justify-between gap-2">
                              <span className="font-bold">
                                {step.number}. {step.title}
                              </span>
                              <span
                                className={`px-1.5 py-0.5 text-[9.5px] font-mono rounded uppercase ${
                                  step.status === 'success'
                                    ? 'bg-emerald-500/20 text-emerald-300'
                                    : step.status === 'running'
                                    ? 'bg-cyan-500/25 text-cyan-200 animate-pulse'
                                    : step.status === 'error'
                                    ? 'bg-rose-500/30 text-rose-200 font-bold'
                                    : 'bg-slate-800 text-slate-400'
                                }`}
                              >
                                {step.status}
                              </span>
                            </div>
                            <p className="text-[10.5px] text-slate-400 leading-snug">
                              {step.subtitle}
                            </p>
                            {step.detailText && (
                              <div className="text-[10.5px] font-mono text-cyan-300 pt-0.5">
                                {step.detailText}
                              </div>
                            )}
                            {step.errorText && (
                              <div className="p-2 rounded-lg bg-rose-950/80 border border-rose-500/40 text-[10.5px] font-mono text-rose-200 mt-1">
                                Error: {step.errorText}
                              </div>
                            )}
                          </div>

                          <div className="flex items-center justify-end gap-1.5 pt-1">
                            <button
                              type="button"
                              onClick={() => runPipelineFromStep(step.id)}
                              disabled={isBuildingApk && step.status === 'running'}
                              className={`px-2.5 py-1 rounded-lg text-[10.5px] font-bold flex items-center gap-1 cursor-pointer ${
                                step.status === 'error'
                                  ? 'bg-rose-600 hover:bg-rose-500 text-white'
                                  : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700'
                              }`}
                            >
                              <RotateCcw className="w-3 h-3" />
                              <span>{step.status === 'error' ? 'Retry Step' : 'Run Step'}</span>
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Step 6 Native Bridge Download & Install Controls (Item 4C) */}
                    {(buildStatus.stage === 'completed' ||
                      buildStatus.releaseBrowserDownloadUrl ||
                      buildStatus.releaseAssetApiUrl) && (
                      <div className="p-3.5 rounded-xl bg-emerald-950/40 border border-emerald-500/50 space-y-2.5">
                        <div className="flex items-center justify-between flex-wrap gap-2">
                          <div className="text-xs font-bold text-emerald-300 flex items-center gap-1.5">
                            <CheckCircle2 className="w-4 h-4" />
                            <span>
                              Release Asset Ready:{' '}
                              {buildStatus.releaseAssetName || 'app-debug.apk'} (
                              {buildStatus.releaseTag || 'v1.0'})
                            </span>
                          </div>
                          <div className="flex items-center gap-2 flex-wrap">
                            <button
                              type="button"
                              onClick={handleDownloadReleaseApk}
                              disabled={isDownloadingNativeApk}
                              className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-md"
                            >
                              {isDownloadingNativeApk ? (
                                <Loader2 className="w-3.5 h-3.5 animate-spin" />
                              ) : (
                                <Download className="w-3.5 h-3.5" />
                              )}
                              <span>Download APK to Phone Downloads (Native Bridge)</span>
                            </button>

                            {nativeDownloadResult?.filePath && (
                              <button
                                type="button"
                                onClick={() =>
                                  handleInstallDownloadedApk(nativeDownloadResult.filePath!)
                                }
                                className="px-3.5 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-md"
                              >
                                <Smartphone className="w-3.5 h-3.5" />
                                <span>Install APK Now</span>
                              </button>
                            )}

                            {buildStatus.releaseBrowserDownloadUrl && (
                              <a
                                href={buildStatus.releaseBrowserDownloadUrl}
                                target="_blank"
                                rel="noreferrer"
                                className="px-3 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1.5"
                              >
                                <span>Direct Release Link</span>
                                <ExternalLink className="w-3.5 h-3.5" />
                              </a>
                            )}
                          </div>
                        </div>

                        {nativeDownloadResult && (
                          <div className="text-[11px] font-mono text-emerald-200 bg-slate-950/70 p-2 rounded-lg">
                            {nativeDownloadResult.message}
                          </div>
                        )}
                        {installFeedback && (
                          <div className="text-[11px] font-mono text-cyan-200 bg-slate-950/70 p-2 rounded-lg">
                            {installFeedback}
                          </div>
                        )}
                      </div>
                    )}
                  </div>

                  {/* Code Explorer & Viewer */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {/* File Tree */}
                    <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-2">
                      <div className="text-xs font-bold text-slate-300 px-1 flex items-center gap-1.5">
                        <FileCode className="w-4 h-4 text-cyan-400" />
                        <span>Generated Project Files ({generatedApp.files.length})</span>
                      </div>
                      <div className="space-y-1 max-h-[340px] overflow-y-auto pr-1">
                        {generatedApp.files.map((f, i) => (
                          <button
                            key={f.path}
                            onClick={() => setSelectedFileIndex(i)}
                            className={`w-full text-left px-3 py-2 rounded-xl text-xs transition-all cursor-pointer flex flex-col ${
                              selectedFileIndex === i
                                ? 'bg-indigo-600/25 border border-indigo-500/50 text-white'
                                : 'hover:bg-slate-800/70 text-slate-400 border border-transparent'
                            }`}
                          >
                            <span className="font-mono truncate font-semibold">{f.path}</span>
                            {f.description && (
                              <span className="text-[10px] text-slate-500 truncate">
                                {f.description}
                              </span>
                            )}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* File Code Content */}
                    <div className="md:col-span-2 p-3.5 rounded-2xl bg-slate-950 border border-slate-800 flex flex-col h-[380px]">
                      <div className="flex items-center justify-between pb-2.5 mb-2.5 border-b border-slate-800">
                        <span className="text-xs font-mono text-cyan-300 truncate">
                          {generatedApp.files[selectedFileIndex]?.path}
                        </span>
                        <button
                          onClick={handleCopyFileContent}
                          className="px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-700 text-[11px] text-slate-300 flex items-center gap-1 cursor-pointer"
                        >
                          {copiedFile ? (
                            <>
                              <Check className="w-3.5 h-3.5 text-emerald-400" />
                              <span>Copied</span>
                            </>
                          ) : (
                            <>
                              <Copy className="w-3.5 h-3.5" />
                              <span>Copy Code</span>
                            </>
                          )}
                        </button>
                      </div>
                      <pre className="flex-1 overflow-auto text-[11px] sm:text-xs font-mono text-slate-200 leading-relaxed whitespace-pre">
                        {generatedApp.files[selectedFileIndex]?.content}
                      </pre>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* ================================================================ */}
          {/* TAB 2: PYTHON 3.10 SANDBOX & RUNNER                              */}
          {/* ================================================================ */}
          {activeTab === 'python_ide' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <div className="flex items-center gap-1.5 overflow-x-auto">
                  {SAMPLE_PYTHON_SCRIPTS.map((s, idx) => (
                    <button
                      key={idx}
                      onClick={() => {
                        setCode(s.code);
                        setRunResult(null);
                      }}
                      className="px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-xs text-slate-300 cursor-pointer shrink-0"
                    >
                      {s.name}
                    </button>
                  ))}
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      setCode('');
                      setRunResult(null);
                    }}
                    className="px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-xs text-slate-400 hover:text-white flex items-center gap-1 cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Clear</span>
                  </button>
                  <button
                    onClick={handleRunPython}
                    disabled={isRunningCode || !code.trim()}
                    className="px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:brightness-110 disabled:opacity-50 text-white text-xs font-bold flex items-center gap-1.5 shadow-lg cursor-pointer"
                  >
                    {isRunningCode ? (
                      <>
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                        <span>Running...</span>
                      </>
                    ) : (
                      <>
                        <Play className="w-3.5 h-3.5" />
                        <span>Run Python 3</span>
                      </>
                    )}
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-300 block">
                    main.py (Python {pythonEnv.version} Isolated Subprocess)
                  </label>
                  <textarea
                    value={code}
                    onChange={(e) => setCode(e.target.value)}
                    rows={14}
                    spellCheck={false}
                    className="w-full rounded-2xl bg-slate-950 border border-slate-800 focus:border-emerald-500 p-3.5 text-xs font-mono text-emerald-100 outline-none resize-none leading-relaxed"
                  />
                  <div>
                    <label className="text-[11px] text-slate-400 block mb-1">
                      Standard Input (stdin - optional)
                    </label>
                    <input
                      type="text"
                      value={stdinText}
                      onChange={(e) => setStdinText(e.target.value)}
                      placeholder="Optional input lines for input()..."
                      className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs font-mono text-white outline-none"
                    />
                  </div>
                </div>

                <div className="space-y-2 flex flex-col">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-300">
                      Execution Output (stdout / stderr)
                    </span>
                    {runResult && (
                      <span
                        className={`text-[11px] font-mono ${
                          runResult.success ? 'text-emerald-400' : 'text-rose-400'
                        }`}
                      >
                        Exit: {runResult.exitCode} ({runResult.executionTimeMs} ms)
                      </span>
                    )}
                  </div>
                  <div className="flex-1 min-h-[280px] rounded-2xl bg-slate-950 border border-slate-800 p-4 font-mono text-xs overflow-auto space-y-2">
                    {!runResult && !isRunningCode && (
                      <div className="text-slate-500">
                        Click &quot;Run Python 3&quot; to execute your script in the Zoya sandbox.
                      </div>
                    )}
                    {isRunningCode && (
                      <div className="flex items-center gap-2 text-cyan-300">
                        <Loader2 className="w-4 h-4 animate-spin" />
                        <span>Executing Python subprocess...</span>
                      </div>
                    )}
                    {runResult?.stdout && (
                      <pre className="text-emerald-300 whitespace-pre-wrap">{runResult.stdout}</pre>
                    )}
                    {runResult?.stderr && (
                      <pre className="text-rose-400 whitespace-pre-wrap">{runResult.stderr}</pre>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ================================================================ */}
          {/* TAB 3: GITHUB ACTIONS APK BUILDER & AI BRAIN SETTINGS            */}
          {/* ================================================================ */}
          {activeTab === 'settings' && (
            <div className="space-y-4 max-w-2xl mx-auto">
              {/* Free GitHub Actions APK Build Config */}
              <div className="p-4 sm:p-5 rounded-2xl bg-slate-900/90 border border-purple-500/30 space-y-3">
                <div className="flex items-center gap-2.5">
                  <Github className="w-5 h-5 text-purple-400" />
                  <div>
                    <h4 className="text-sm font-bold text-white">
                      Free Cloud APK Builder (GitHub Actions Integration)
                    </h4>
                    <p className="text-[11px] text-slate-400">
                      Since mobile phones cannot run heavy Android SDK/Gradle compilers locally, Zoya pushes your generated Android project to your GitHub account, compiles the APK on GitHub Actions, and publishes it as a Release asset.
                    </p>
                  </div>
                </div>

                <div className="space-y-2 pt-1">
                  <label className="text-xs font-bold text-slate-300 block">
                    GitHub Personal Access Token (with `repo` and `workflow` scopes)
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="password"
                      value={githubToken}
                      onChange={(e) => setGithubToken(e.target.value)}
                      placeholder="ghp_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
                      className="flex-1 px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 focus:border-purple-500 text-xs font-mono text-white outline-none"
                    />
                    <button
                      type="button"
                      onClick={handleTestGitHubConnection}
                      disabled={isTestingGithub}
                      className="px-3.5 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold cursor-pointer shrink-0"
                    >
                      {isTestingGithub ? 'Testing...' : 'Test Connection'}
                    </button>
                  </div>
                  <p className="text-[11px] text-slate-400">
                    {isRunningInAndroidApk()
                      ? 'Stored in Android Keystore (EncryptedSharedPreferences AES256-GCM).'
                      : 'Browser Warning: Stored in encrypted session memory only (never written to localStorage).'}
                  </p>
                </div>
              </div>

              {/* AI Brain Model Configuration */}
              <div className="p-4 sm:p-5 rounded-2xl bg-slate-900/90 border border-cyan-500/30 space-y-3">
                <div className="flex items-center gap-2.5">
                  <Sparkles className="w-5 h-5 text-cyan-400" />
                  <div>
                    <h4 className="text-sm font-bold text-white">
                      Zoya AI Brain Model Configuration
                    </h4>
                    <p className="text-[11px] text-slate-400">
                      Choose which Gemini model synthesizes your Android Kotlin/Java source files.
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                  <div>
                    <label className="text-xs font-bold text-slate-300 block mb-1">
                      AI Model Name
                    </label>
                    <select
                      value={modelName}
                      onChange={(e) => setModelName(e.target.value)}
                      className="w-full px-3 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white outline-none"
                    >
                      <option value="gemini-2.5-flash">gemini-2.5-flash (Fast &amp; Reliable)</option>
                      <option value="gemini-2.5-pro">gemini-2.5-pro (Advanced Architecture)</option>
                      <option value="gemini-3-flash-preview">gemini-3-flash-preview</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-xs font-bold text-slate-300 block mb-1">
                      Custom Gemini API Key (Optional Override)
                    </label>
                    <input
                      type="password"
                      value={customApiKey}
                      onChange={(e) => setCustomApiKey(e.target.value)}
                      placeholder="Leave blank to use Zoya default key"
                      className="w-full px-3 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs font-mono text-white outline-none"
                    />
                  </div>
                </div>

                <div className="pt-2 flex items-center justify-between">
                  <button
                    onClick={handleSaveSettings}
                    className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:brightness-110 text-white text-xs font-bold cursor-pointer shadow-lg"
                  >
                    Save Studio Configuration
                  </button>
                  {settingsSavedToast && (
                    <span className="text-xs text-emerald-400 font-bold flex items-center gap-1">
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Configuration Saved!</span>
                    </span>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
