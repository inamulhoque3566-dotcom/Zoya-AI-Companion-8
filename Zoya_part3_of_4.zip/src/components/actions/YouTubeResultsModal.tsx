import React, { useState, useEffect } from 'react';
import {
  X,
  Youtube,
  Play,
  ExternalLink,
  Smartphone,
  Globe,
  Heart,
  Music,
  Share2,
  Check,
  RotateCw
} from 'lucide-react';
import {
  youtubeManager,
  YouTubeVideo,
  FavoriteSinger
} from '../../services/youtubeManager';

interface YouTubeResultsModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  singerName?: string;
  videos: YouTubeVideo[];
  autoPlayFirst?: boolean;
}

export const YouTubeResultsModal: React.FC<YouTubeResultsModalProps> = ({
  isOpen,
  onClose,
  title,
  singerName,
  videos,
  autoPlayFirst = false,
}) => {
  const [currentVideos, setCurrentVideos] = useState<YouTubeVideo[]>(videos);
  const [currentSinger, setCurrentSinger] = useState<string | undefined>(singerName);
  const [activeVideo, setActiveVideo] = useState<YouTubeVideo | null>(() => {
    return autoPlayFirst && videos.length > 0 ? videos[0] : null;
  });
  const [isSavedFavorite, setIsSavedFavorite] = useState<boolean>(() => {
    return singerName ? youtubeManager.isFavorite(singerName) : false;
  });
  const [isLoadingSinger, setIsLoadingSinger] = useState<boolean>(false);
  const [savedSingers, setSavedSingers] = useState<FavoriteSinger[]>(() => youtubeManager.getFavoriteSingers());

  useEffect(() => {
    setCurrentVideos(videos);
    setCurrentSinger(singerName);
    if (videos.length > 0) {
      setActiveVideo(videos[0]);
    } else {
      setActiveVideo(null);
    }
  }, [videos, singerName]);

  useEffect(() => {
    setIsSavedFavorite(currentSinger ? youtubeManager.isFavorite(currentSinger) : false);
    setSavedSingers(youtubeManager.getFavoriteSingers());
  }, [currentSinger, isOpen]);

  if (!isOpen) return null;

  const preferredApp = youtubeManager.getPreferredApp();

  const handlePlayInPreferredApp = (video: YouTubeVideo) => {
    youtubeManager.openVideo(video.videoId, video.videoUrl);
  };

  const handleOpenBrowser = (video: YouTubeVideo) => {
    window.open(video.videoUrl, '_blank', 'noopener,noreferrer');
  };

  const handleToggleFavorite = () => {
    if (!currentSinger) return;
    if (isSavedFavorite) {
      youtubeManager.removeFavoriteSinger(currentSinger);
      setIsSavedFavorite(false);
      setSavedSingers(youtubeManager.getFavoriteSingers());
    } else {
      youtubeManager.addFavoriteSinger({
        name: currentSinger,
        thumbnail: currentVideos[0]?.thumbnail || '',
        channelTitle: currentVideos[0]?.channelTitle || currentSinger,
      });
      setIsSavedFavorite(true);
      setSavedSingers(youtubeManager.getFavoriteSingers());
    }
  };

  const handleSwitchFavoriteSinger = async (singer: FavoriteSinger) => {
    setIsLoadingSinger(true);
    setCurrentSinger(singer.name);
    try {
      const res = await youtubeManager.getSingerTopTracks(singer.name, singer.channelId);
      if (res.videos && res.videos.length > 0) {
        setCurrentVideos(res.videos);
        setActiveVideo(res.videos[0]);
      } else {
        const searchRes = await youtubeManager.searchVideos('best hit songs', singer.name, 10);
        if (searchRes.videos && searchRes.videos.length > 0) {
          setCurrentVideos(searchRes.videos);
          setActiveVideo(searchRes.videos[0]);
        }
      }
    } finally {
      setIsLoadingSinger(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-slate-950/85 backdrop-blur-md animate-fade-in select-none">
      <div className="relative w-full max-w-2xl bg-slate-900 rounded-3xl border border-slate-800 shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-800 bg-slate-950/80">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-2xl bg-red-600 flex items-center justify-center text-white shrink-0 shadow-lg shadow-red-600/30">
              <Youtube className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <h3 className="text-base font-bold text-white truncate flex items-center gap-2">
                {currentSinger ? `Songs by ${currentSinger}` : (title || 'YouTube Music Search')}
              </h3>
              <p className="text-xs text-slate-400 truncate flex items-center gap-2">
                <span>{currentVideos.length} songs available</span>
                {preferredApp === 'youtube_app' && (
                  <span className="text-[10px] text-red-400 bg-red-950/80 px-2 py-0.5 rounded-full border border-red-500/30 font-mono">
                    Official App Mode
                  </span>
                )}
                {preferredApp === 'browser' && (
                  <span className="text-[10px] text-blue-400 bg-blue-950/80 px-2 py-0.5 rounded-full border border-blue-500/30 font-mono">
                    Browser Mode
                  </span>
                )}
                {preferredApp === 'auto' && (
                  <span className="text-[10px] text-purple-400 bg-purple-950/80 px-2 py-0.5 rounded-full border border-purple-500/30 font-mono">
                    Auto-Launch
                  </span>
                )}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {currentSinger && (
              <button
                type="button"
                onClick={handleToggleFavorite}
                className={`p-2 rounded-xl border text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer ${
                  isSavedFavorite
                    ? 'bg-pink-950/60 border-pink-500/50 text-pink-300'
                    : 'bg-slate-800 border-slate-700 text-slate-300 hover:text-white'
                }`}
                title={isSavedFavorite ? 'Favorite Singer (Saved)' : 'Add to Favorite Singers'}
              >
                <Heart className={`w-4 h-4 ${isSavedFavorite ? 'fill-pink-500 text-pink-500' : ''}`} />
                <span className="hidden sm:inline">{isSavedFavorite ? 'Favorite' : 'Save'}</span>
              </button>
            )}

            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Favorite Singers Multi-Selection Pills Bar */}
        {savedSingers.length > 0 && (
          <div className="flex items-center gap-1.5 px-5 py-2 bg-slate-950/60 border-b border-slate-800/80 overflow-x-auto">
            <span className="text-[10.5px] font-bold text-slate-400 shrink-0 uppercase tracking-wider">
              Favorites:
            </span>
            {savedSingers.map((s) => {
              const isSelected = currentSinger?.toLowerCase() === s.name.toLowerCase();
              return (
                <button
                  key={s.id}
                  type="button"
                  onClick={() => handleSwitchFavoriteSinger(s)}
                  disabled={isLoadingSinger}
                  className={`px-2.5 py-1 rounded-full text-xs font-semibold shrink-0 transition-colors flex items-center gap-1 cursor-pointer ${
                    isSelected
                      ? 'bg-purple-600 text-white shadow-sm'
                      : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
                  }`}
                >
                  <Music className="w-3 h-3 text-purple-300" />
                  <span>{s.name}</span>
                </button>
              );
            })}
          </div>
        )}

        {/* Embedded Video Player (if active video chosen) */}
        {activeVideo && (
          <div className="w-full bg-black shrink-0 relative border-b border-slate-800">
            <div className="relative aspect-video w-full max-h-[260px]">
              <iframe
                src={`https://www.youtube-nocookie.com/embed/${activeVideo.videoId}?autoplay=1&rel=0&modestbranding=1`}
                title={activeVideo.title}
                className="w-full h-full border-0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              />
            </div>
            
            {/* Active Video Quick Controls Bar */}
            <div className="p-3 bg-slate-950/90 flex items-center justify-between gap-3 border-t border-slate-800/80">
              <div className="min-w-0 flex-1">
                <p className="text-xs font-bold text-white truncate">
                  {activeVideo.title}
                </p>
                <p className="text-[10.5px] text-slate-400 truncate">
                  {activeVideo.channelTitle}
                </p>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => handlePlayInPreferredApp(activeVideo)}
                  className="px-3 py-1.5 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer shadow-sm"
                  title="Open video in preferred app"
                >
                  <Smartphone className="w-3.5 h-3.5" />
                  <span>Open in App</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleOpenBrowser(activeVideo)}
                  className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                  title="Open in new browser tab"
                >
                  <Globe className="w-3.5 h-3.5 text-blue-400" />
                  <span className="hidden sm:inline">Browser</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Video Results List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-2.5">
          {isLoadingSinger ? (
            <div className="text-center py-12 space-y-2">
              <RotateCw className="w-8 h-8 text-purple-400 animate-spin mx-auto" />
              <p className="text-xs text-slate-400">Loading tracks...</p>
            </div>
          ) : currentVideos.length === 0 ? (
            <div className="text-center py-12 space-y-2">
              <Music className="w-10 h-10 text-slate-600 mx-auto" />
              <p className="text-sm text-slate-400">
                No songs or videos found. Try another query or check your YouTube API key.
              </p>
            </div>
          ) : (
            currentVideos.map((vid) => {
              const isCurrent = activeVideo?.videoId === vid.videoId;
              return (
                <div
                  key={vid.videoId}
                  className={`p-2.5 rounded-2xl border transition-all flex items-center justify-between gap-3 ${
                    isCurrent
                      ? 'bg-red-950/30 border-red-500/80 shadow-[0_0_15px_rgba(239,68,68,0.2)]'
                      : 'bg-slate-950/60 hover:bg-slate-900 border-slate-800'
                  }`}
                >
                  {/* Thumbnail & Info */}
                  <div
                    onClick={() => setActiveVideo(vid)}
                    className="flex items-center gap-3 min-w-0 flex-1 cursor-pointer"
                  >
                    <div className="relative w-24 h-14 sm:w-28 sm:h-16 rounded-xl overflow-hidden bg-slate-800 shrink-0">
                      <img
                        src={vid.thumbnail}
                        alt={vid.title}
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute inset-0 bg-black/30 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
                        <div className="w-8 h-8 rounded-full bg-red-600 text-white flex items-center justify-center shadow-lg">
                          <Play className="w-4 h-4 fill-current ml-0.5" />
                        </div>
                      </div>
                    </div>

                    <div className="min-w-0 flex-1">
                      <h4 className="text-xs sm:text-sm font-bold text-white line-clamp-1 group-hover:text-red-400">
                        {vid.title}
                      </h4>
                      <p className="text-[11px] text-slate-400 truncate mt-0.5">
                        {vid.channelTitle}
                      </p>
                      {vid.publishedAt && (
                        <span className="text-[9.5px] text-slate-500 block mt-0.5">
                          {new Date(vid.publishedAt).toLocaleDateString()}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      type="button"
                      onClick={() => handlePlayInPreferredApp(vid)}
                      className="p-2 rounded-xl bg-red-600/20 hover:bg-red-600/40 text-red-300 border border-red-500/40 transition-colors cursor-pointer"
                      title="Launch in Preferred App"
                    >
                      <ExternalLink className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
