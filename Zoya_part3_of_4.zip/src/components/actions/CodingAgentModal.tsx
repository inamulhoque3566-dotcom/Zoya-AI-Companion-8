import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  X,
  Play,
  Square,
  Terminal,
  FolderTree,
  ShieldAlert,
  Sliders,
  History,
  FileCode,
  RotateCcw,
  Plus,
  RefreshCw,
  Server,
  Zap,
  Key,
  Lock,
  Unlock,
  Check,
  AlertTriangle,
  ExternalLink,
  ChevronRight,
  Eye,
  FileText,
  Cpu,
  Trash2,
  Download,
  Upload,
  Globe,
  Radio,
  Copy,
  Info,
} from 'lucide-react';
import { agentClient } from '../../services/agent/agentClient';
import type {
  AgentTaskState,
  AgentLogEntry,
  PendingApprovalRequest,
  SecurityAuditLogItem,
} from '../../services/agent/agentTypes';
import { maskSecrets } from '../../services/agent/secretMasker';

interface CodingAgentModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialTaskPrompt?: string;
}

type TabType =
  | 'agent'
  | 'approvals'
  | 'terminal'
  | 'files'
  | 'skills'
  | 'mcp'
  | 'history'
  | 'logs'
  | 'permissions';

export const CodingAgentModal: React.FC<CodingAgentModalProps> = ({
  isOpen,
  onClose,
  initialTaskPrompt = '',
}) => {
  // Navigation
  const [activeTab, setActiveTab] = useState<TabType>('agent');

  // Auth / Pairing State
  const [authToken, setAuthToken] = useState<string>(() => agentClient.getAuthToken() || '');
  const [ownerPassphrase, setOwnerPassphrase] = useState<string>('');
  const [passphraseStatus, setPassphraseStatus] = useState<string | null>(null);
  const [pairingCode, setPairingCode] = useState<string>('');
  const [pairingError, setPairingError] = useState<string | null>(null);
  const [pairingSuccess, setPairingSuccess] = useState<string | null>(null);

  // Tab 1: Agent State
  const [taskPrompt, setTaskPrompt] = useState<string>(initialTaskPrompt);
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [currentTask, setCurrentTask] = useState<AgentTaskState | null>(null);
  const [taskError, setTaskError] = useState<string | null>(null);

  // Tab 2: Approvals State
  const [pendingApprovals, setPendingApprovals] = useState<PendingApprovalRequest[]>([]);
  const [confirmingStrictId, setConfirmingStrictId] = useState<string | null>(null);
  const [approvalFeedback, setApprovalFeedback] = useState<string | null>(null);

  // Tab 3: Terminal State
  const [terminalCommand, setTerminalCommand] = useState<string>('');
  const [terminalHistory, setTerminalHistory] = useState<any[]>([]);
  const [terminalCwd, setTerminalCwd] = useState<string>('/workspace');
  const [terminalRunning, setTerminalRunning] = useState<boolean>(false);
  const [terminalOutput, setTerminalOutput] = useState<string>('');

  // Tab 4: Project Files State
  const [fileTree, setFileTree] = useState<any[]>([]);
  const [selectedFilePath, setSelectedFilePath] = useState<string>('');
  const [fileContent, setFileContent] = useState<string>('');
  const [originalFileContent, setOriginalFileContent] = useState<string>('');
  const [fileDiff, setFileDiff] = useState<string>('');
  const [fileChanges, setFileChanges] = useState<any[]>([]);
  const [isLoadingFile, setIsLoadingFile] = useState<boolean>(false);
  const [isSavingFile, setIsSavingFile] = useState<boolean>(false);

  // Tab 5: Skills Library State
  const [installedSkills, setInstalledSkills] = useState<any[]>([]);
  const [quarantinedSkills, setQuarantinedSkills] = useState<any[]>([]);
  const [importType, setImportType] = useState<'git' | 'folder' | 'zip'>('git');
  const [importInput, setImportInput] = useState<string>('https://github.com/anthropics/skills');
  const [activeScanReport, setActiveScanReport] = useState<any | null>(null);
  const [skillUpdateDiff, setSkillUpdateDiff] = useState<{ skillId: string; quarantineId: string; diff: string; scan: any } | null>(null);
  const [isSkillLoading, setIsSkillLoading] = useState<boolean>(false);
  const zipFileInputRef = useRef<HTMLInputElement | null>(null);

  // Tab 6: MCP Servers State
  const [mcpServers, setMcpServers] = useState<any[]>([]);
  const [discoveredMcpTools, setDiscoveredMcpTools] = useState<any[]>([]);
  const [mcpToolCallServerId, setMcpToolCallServerId] = useState<string>('');
  const [mcpToolCallName, setMcpToolCallName] = useState<string>('');
  const [mcpToolCallArgs, setMcpToolCallArgs] = useState<string>('{}');
  const [mcpToolCallResult, setMcpToolCallResult] = useState<string>('');
  const [showAddMcpModal, setShowAddMcpModal] = useState<boolean>(false);
  const [newMcpName, setNewMcpName] = useState<string>('local-python-mcp');
  const [newMcpTransport, setNewMcpTransport] = useState<'stdio' | 'http'>('stdio');
  const [newMcpCommand, setNewMcpCommand] = useState<string>('/usr/bin/python3');
  const [newMcpArgs, setNewMcpArgs] = useState<string>('/app/applet/workspace/mcp_test_server.py');
  const [newMcpUrl, setNewMcpUrl] = useState<string>('http://127.0.0.1:4889');
  const [newMcpAllowNetwork, setNewMcpAllowNetwork] = useState<boolean>(false);
  const [newMcpAllowLocalhost, setNewMcpAllowLocalhost] = useState<boolean>(true);

  // Tab 7: Task History State
  const [taskHistory, setTaskHistory] = useState<AgentTaskState[]>([]);

  // Tab 8: Security Audit Logs
  const [auditLogs, setAuditLogs] = useState<SecurityAuditLogItem[]>([]);
  const [auditFilter, setAuditFilter] = useState<string>('ALL');

  // Tab 9: Permissions & Security
  const [tokenRotatedMessage, setTokenRotatedMessage] = useState<string | null>(null);

  // Polling ref for pending approvals & live agent status
  const pollTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Initial Sync & Poller
  useEffect(() => {
    if (!isOpen) return;

    // Load initial token
    const token = agentClient.getAuthToken();
    if (token) setAuthToken(token);

    refreshApprovals();
    refreshTerminalCwd();

    // Set polling interval for live status & approvals badge
    pollTimerRef.current = setInterval(() => {
      refreshApprovals();
      if (isRunning) {
        checkAgentStatus();
      }
    }, 2000);

    return () => {
      if (pollTimerRef.current) clearInterval(pollTimerRef.current);
    };
  }, [isOpen, isRunning]);

  // Load tab-specific data when tab changes
  useEffect(() => {
    if (!isOpen) return;
    if (activeTab === 'terminal') {
      refreshTerminalHistory();
    } else if (activeTab === 'files') {
      refreshFiles();
    } else if (activeTab === 'skills') {
      refreshSkills();
    } else if (activeTab === 'mcp') {
      refreshMcp();
    } else if (activeTab === 'history') {
      refreshHistory();
    } else if (activeTab === 'logs') {
      refreshAuditLogs();
    }
  }, [activeTab, isOpen]);

  // ----------------------------------------------------
  // Helper: Pairing & Auth Bootstrap
  // ----------------------------------------------------
  const handleGeneratePairingCode = async () => {
    setPairingError(null);
    setPairingSuccess(null);
    if (!ownerPassphrase.trim()) {
      setPairingError('Enter owner passphrase first to generate a pairing code.');
      return;
    }
    const res = await agentClient.fetchPairingCode(ownerPassphrase.trim());
    if (res.success && res.pairingCode) {
      setPairingCode(res.pairingCode);
      setPairingSuccess(`One-time pairing code generated: ${res.pairingCode}`);
    } else {
      setPairingError(res.error || 'Failed to generate pairing code');
    }
  };

  const handleLoginOwner = async () => {
    if (!ownerPassphrase.trim()) {
      setPassphraseStatus('Please enter owner passphrase');
      return;
    }
    const res = await agentClient.loginOwnerPassphrase(ownerPassphrase.trim());
    if (res.success) {
      setPassphraseStatus('Authenticated! HttpOnly SameSite=Strict approval cookie active.');
    } else {
      setPassphraseStatus(res.error || 'Authentication failed');
    }
  };

  const handlePairSession = async () => {
    if (!pairingCode.trim()) {
      setPairingError('Please enter a valid pairing code.');
      return;
    }
    setPairingError(null);
    const res = await agentClient.pairWithCode(pairingCode.trim());
    if (res.success && res.token) {
      setAuthToken(res.token);
      setPairingSuccess('Session authenticated successfully!');
      // Also log in with passphrase if provided to activate approval cookie
      if (ownerPassphrase.trim()) {
        await agentClient.loginOwnerPassphrase(ownerPassphrase.trim());
      }
      refreshApprovals();
    } else {
      setPairingError(res.error || 'Pairing code invalid or already consumed.');
    }
  };

  const handleRotateToken = async () => {
    const res = await agentClient.rotateToken();
    if (res.success && res.token) {
      setAuthToken(res.token);
      setTokenRotatedMessage('Agent token rotated to new cryptographic secret.');
      setTimeout(() => setTokenRotatedMessage(null), 4000);
    }
  };

  // ----------------------------------------------------
  // Tab 1: Agent Task Actions
  // ----------------------------------------------------
  const handleStartTask = async () => {
    if (!taskPrompt.trim()) return;
    setTaskError(null);
    setIsRunning(true);
    setCurrentTask(null);

    const res = await agentClient.runTask({ prompt: taskPrompt.trim() });
    if (res.success && res.task) {
      setCurrentTask(res.task);
      if (res.task.status === 'completed' || res.task.status === 'failed') {
        setIsRunning(false);
      }
    } else {
      setIsRunning(false);
      setTaskError(res.error || 'Failed to start task.');
    }
  };

  const handleStopTask = async () => {
    const res = await agentClient.stopTask();
    if (res.success) {
      setIsRunning(false);
      checkAgentStatus();
    }
  };

  const checkAgentStatus = async () => {
    const res = await agentClient.getStatus();
    if (res.success && res.task) {
      setCurrentTask(res.task);
      if (res.task.status === 'completed' || res.task.status === 'failed' || res.task.status === 'aborted') {
        setIsRunning(false);
      }
    }
  };

  // ----------------------------------------------------
  // Tab 2: Approvals Actions (User Credential Flow)
  // ----------------------------------------------------
  const refreshApprovals = async () => {
    try {
      const res = await agentClient.getPendingApprovals();
      if (res.success && Array.isArray(res.pending)) {
        setPendingApprovals(res.pending);
      }
    } catch {}
  };

  const handleApprovalResponse = async (id: string, approve: boolean, isStrict: boolean) => {
    if (isStrict && approve && confirmingStrictId !== id) {
      setConfirmingStrictId(id);
      return;
    }

    setConfirmingStrictId(null);
    // Uses HttpOnly session cookie - no secrets exposed in JS memory
    const res = await agentClient.respondToApproval(id, approve);

    if (res.success) {
      setApprovalFeedback(`Request ${id} ${approve ? 'APPROVED' : 'DENIED'} successfully.`);
      setTimeout(() => setApprovalFeedback(null), 3000);
      refreshApprovals();
    } else {
      setApprovalFeedback(`Approval failed: ${res.message}`);
    }
  };

  // ----------------------------------------------------
  // Tab 3: Terminal Actions
  // ----------------------------------------------------
  const refreshTerminalHistory = async () => {
    const res = await agentClient.getTerminalHistory();
    if (res.success) {
      setTerminalHistory(res.history);
    }
  };

  const refreshTerminalCwd = async () => {
    const res = await agentClient.getTerminalCwd();
    if (res.success) {
      setTerminalCwd(res.relativeCwd || '/workspace');
    }
  };

  const handleExecuteTerminal = async () => {
    if (!terminalCommand.trim() || terminalRunning) return;
    setTerminalRunning(true);
    const cmd = terminalCommand.trim();
    setTerminalCommand('');

    const res = await agentClient.executeTerminalCommand(cmd);
    setTerminalRunning(false);

    if (res.success && res.result) {
      let text = `> ${cmd}\n`;
      if (res.result.stdout) text += `${res.result.stdout}\n`;
      if (res.result.stderr) text += `STDERR: ${res.result.stderr}\n`;
      text += `[Exit Code: ${res.result.exitCode} | Duration: ${res.result.durationMs}ms]`;
      setTerminalOutput(text);
      refreshTerminalHistory();
      refreshTerminalCwd();
    } else if (res.result?.pendingApprovalId) {
      setTerminalOutput(`> ${cmd}\n[APPROVAL REQUIRED]: ID ${res.result.pendingApprovalId}. Switch to Approvals tab.`);
      refreshApprovals();
    } else {
      setTerminalOutput(`> ${cmd}\nERROR: ${res.error || 'Command failed.'}`);
    }
  };

  // ----------------------------------------------------
  // Tab 4: Project Files Actions
  // ----------------------------------------------------
  const refreshFiles = async () => {
    const [treeRes, changesRes] = await Promise.all([
      agentClient.getFileTree(),
      agentClient.getFileChanges(),
    ]);
    if (treeRes.success) setFileTree(treeRes.tree?.children || []);
    if (changesRes.success) setFileChanges(changesRes.changes || []);
  };

  const handleSelectFile = async (path: string) => {
    setSelectedFilePath(path);
    setIsLoadingFile(true);
    setFileDiff('');

    const [fileRes, diffRes] = await Promise.all([
      agentClient.readFile(path),
      agentClient.getFileDiff(path),
    ]);

    setIsLoadingFile(false);
    if (fileRes.success && fileRes.file) {
      setFileContent(fileRes.file.content);
      setOriginalFileContent(fileRes.file.content);
    }
    if (diffRes.success) {
      setFileDiff(diffRes.diff);
    }
  };

  const handleSaveFile = async () => {
    if (!selectedFilePath) return;
    setIsSavingFile(true);
    const res = await agentClient.writeFile(selectedFilePath, fileContent);
    setIsSavingFile(false);

    if (res.success) {
      refreshFiles();
      handleSelectFile(selectedFilePath);
    } else if (res.result?.pendingApprovalId) {
      refreshApprovals();
      setActiveTab('approvals');
    }
  };

  const handleRevertFile = async (path: string) => {
    const res = await agentClient.revertFile(path);
    if (res.success) {
      refreshFiles();
      if (selectedFilePath === path) {
        handleSelectFile(path);
      }
    } else if ((res as any).pendingApprovalId) {
      refreshApprovals();
      setActiveTab('approvals');
    }
  };

  // ----------------------------------------------------
  // Tab 5: Skills Library Actions
  // ----------------------------------------------------
  const refreshSkills = async () => {
    setIsSkillLoading(true);
    const res = await agentClient.getSkills();
    setIsSkillLoading(false);
    if (res.success) {
      setInstalledSkills(res.installed || []);
      setQuarantinedSkills(res.quarantined || []);
    }
  };

  const handleImportSkill = async () => {
    if (!importInput.trim()) return;
    setIsSkillLoading(true);
    let res: any;
    if (importType === 'git') {
      res = await agentClient.importSkillGit(importInput.trim());
    } else if (importType === 'zip') {
      res = await agentClient.importSkillZip({ zipPath: importInput.trim() });
    } else {
      res = await agentClient.importSkillFolder(importInput.trim());
    }
    setIsSkillLoading(false);

    if (res.success && res.quarantineId) {
      // Automatically scan the imported skill
      const scanRes = await agentClient.scanSkill(res.quarantineId);
      if (scanRes.success) {
        setActiveScanReport(scanRes.report);
      }
      refreshSkills();
    }
  };

  const handleImportZipFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsSkillLoading(true);
    const reader = new FileReader();
    reader.onload = async () => {
      try {
        const dataUrl = reader.result as string;
        const base64 = dataUrl.split(',')[1] || dataUrl;
        const res = await agentClient.importSkillZip({ zipBase64: base64 });
        setIsSkillLoading(false);
        if (res.success && res.quarantineId) {
          const scanRes = await agentClient.scanSkill(res.quarantineId);
          if (scanRes.success) {
            setActiveScanReport(scanRes.report);
          }
          refreshSkills();
        }
      } catch (err) {
        setIsSkillLoading(false);
      }
    };
    reader.readAsDataURL(file);
    // Reset file input so same file can be selected again
    e.target.value = '';
  };

  const handleCheckSkillUpdate = async (skillId: string, qid: string) => {
    setIsSkillLoading(true);
    const res = await agentClient.getSkillUpdateDiff(skillId, qid);
    setIsSkillLoading(false);
    if (res.success) {
      setSkillUpdateDiff({ skillId, quarantineId: qid, diff: res.diff || '', scan: res.scan });
    }
  };

  const handleApplySkillUpdate = async (skillId: string, qid: string) => {
    setIsSkillLoading(true);
    const res = await agentClient.updateSkill(skillId, qid, true);
    setIsSkillLoading(false);
    if (res.success) {
      setSkillUpdateDiff(null);
      setActiveScanReport(null);
      refreshSkills();
    }
  };

  const handleInstallQuarantineSkill = async (qid: string, approved: boolean = true) => {
    setIsSkillLoading(true);
    const res = await agentClient.installSkill(qid, approved);
    setIsSkillLoading(false);
    if (res.success) {
      setActiveScanReport(null);
      refreshSkills();
    }
  };

  const handleToggleSkill = async (id: string, currentlyEnabled: boolean) => {
    if (currentlyEnabled) {
      await agentClient.disableSkill(id);
    } else {
      await agentClient.enableSkill(id);
    }
    refreshSkills();
  };

  const handleDeleteSkill = async (id: string) => {
    await agentClient.deleteSkill(id);
    refreshSkills();
  };

  // ----------------------------------------------------
  // Tab 6: MCP Actions
  // ----------------------------------------------------
  const refreshMcp = async () => {
    const [serversRes, toolsRes] = await Promise.all([
      agentClient.getMcpServers(),
      agentClient.getMcpTools(),
    ]);
    if (serversRes.success) setMcpServers(serversRes.servers || []);
    if (toolsRes.success) setDiscoveredMcpTools(toolsRes.tools || []);
  };

  const handleConnectMcp = async (id: string) => {
    await agentClient.connectMcpServer(id, true);
    refreshMcp();
  };

  const handleDisconnectMcp = async (id: string) => {
    await agentClient.disconnectMcpServer(id);
    refreshMcp();
  };

  const handleRemoveMcp = async (id: string) => {
    await agentClient.removeMcpServer(id);
    refreshMcp();
  };

  const handleAddMcpServer = async () => {
    const config: any = {
      name: newMcpName.trim(),
      transport: newMcpTransport,
    };
    if (newMcpTransport === 'stdio') {
      config.command = newMcpCommand.trim();
      config.args = newMcpArgs.trim().split(/\s+/).filter(Boolean);
      config.allowNetwork = newMcpAllowNetwork;
    } else {
      config.url = newMcpUrl.trim();
      config.allowLocalhost = newMcpAllowLocalhost;
    }

    const res = await agentClient.addMcpServer(config, true);
    if (res.success) {
      setShowAddMcpModal(false);
      refreshMcp();
    }
  };

  const handleCallMcpTool = async () => {
    if (!mcpToolCallServerId || !mcpToolCallName) return;
    let parsedArgs = {};
    try {
      parsedArgs = JSON.parse(mcpToolCallArgs || '{}');
    } catch {
      setMcpToolCallResult('Error: Arguments must be valid JSON.');
      return;
    }

    setMcpToolCallResult('Executing tool on MCP server...');
    const res = await agentClient.callMcpTool(mcpToolCallServerId, mcpToolCallName, parsedArgs, true);
    if (res.success && res.result) {
      setMcpToolCallResult(res.result.output);
    } else {
      setMcpToolCallResult(`Execution Failed: ${res.error || res.result?.output || 'Unknown error'}`);
    }
  };

  // ----------------------------------------------------
  // Tab 7 & 8: History & Logs
  // ----------------------------------------------------
  const refreshHistory = async () => {
    const res = await agentClient.getLogs();
    if (res.success) {
      setTaskHistory(res.logs || []);
    }
  };

  const refreshAuditLogs = async () => {
    const res = await agentClient.getSecurityLogs();
    if (res.success) {
      setAuditLogs(res.logs || []);
    }
  };

  const filteredLogs = useMemo(() => {
    if (auditFilter === 'ALL') return auditLogs;
    return auditLogs.filter((l) => l.action.includes(auditFilter) || l.level?.includes(auditFilter));
  }, [auditLogs, auditFilter]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-5xl h-[94vh] sm:h-[88vh] bg-slate-900 border border-purple-500/30 rounded-2xl shadow-2xl flex flex-col overflow-hidden text-slate-100 font-sans">
        
        {/* Top Header */}
        <div className="px-4 py-3 bg-slate-950/90 border-b border-purple-500/20 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-purple-600 via-indigo-600 to-cyan-500 flex items-center justify-center shadow-md">
              <Cpu className="w-4 h-4 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-white tracking-wide">ZOYA Coding Agent</h2>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-purple-950/80 border border-purple-500/40 text-purple-300 font-mono">
                  v1.0 • Isolated Sandbox
                </span>
              </div>
              <p className="text-[11px] text-slate-400">Autonomous Code, Tools, Skills & MCP Engine</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {!authToken && (
              <span className="text-[11px] bg-amber-500/20 text-amber-300 px-2.5 py-1 rounded-full border border-amber-500/40 flex items-center gap-1.5 animate-pulse">
                <AlertTriangle className="w-3 h-3" /> Pairing Required
              </span>
            )}
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab Navigation Bar (Horizontally scrollable for mobile 360px) */}
        <div 
          data-testid="coding-agent-tab-bar"
          className="bg-slate-950/60 border-b border-purple-500/20 px-2 py-1.5 flex items-center gap-1.5 overflow-x-auto no-scrollbar shrink-0"
        >
          {[
            { id: 'agent', label: 'Agent', icon: Zap },
            {
              id: 'approvals',
              label: 'Approvals',
              icon: ShieldAlert,
              badge: pendingApprovals.length,
            },
            { id: 'terminal', label: 'Terminal', icon: Terminal },
            { id: 'files', label: 'Project Files', icon: FolderTree },
            { id: 'skills', label: 'Skills', icon: FileCode },
            { id: 'mcp', label: 'MCP', icon: Server },
            { id: 'history', label: 'Task History', icon: History },
            { id: 'logs', label: 'Execution Logs', icon: FileText },
            { id: 'permissions', label: 'Permissions', icon: Lock },
          ].map((t) => {
            const Icon = t.icon;
            const isActive = activeTab === t.id;
            return (
              <button
                key={t.id}
                data-tab-id={t.id}
                onClick={() => setActiveTab(t.id as TabType)}
                className={`flex items-center gap-1.5 min-h-[44px] min-w-[44px] px-3.5 py-2.5 rounded-lg text-xs font-medium transition-all shrink-0 relative ${
                  isActive
                    ? 'bg-gradient-to-r from-purple-600/90 to-indigo-600/90 text-white shadow-sm font-semibold'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{t.label}</span>
                {Boolean(t.badge && t.badge > 0) && (
                  <span className="ml-1 px-1.5 py-0.5 text-[10px] font-bold rounded-full bg-rose-500 text-white shadow-xs animate-bounce">
                    {t.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Missing Auth / Pairing Banner */}
        {!authToken && (
          <div className="bg-amber-950/80 border-b border-amber-500/40 px-4 py-2 flex flex-col sm:flex-row sm:items-center justify-between gap-2 shrink-0 text-xs text-amber-200">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
              <span>
                Authentication required. Enter owner passphrase to generate code and pair this session.
              </span>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <input
                type="password"
                placeholder="Owner Passphrase"
                value={ownerPassphrase}
                onChange={(e) => setOwnerPassphrase(e.target.value)}
                className="bg-slate-900 border border-amber-500/40 rounded px-2 py-1 text-xs text-white w-36 focus:outline-none"
              />
              <button
                onClick={handleGeneratePairingCode}
                className="px-2.5 py-1 rounded bg-slate-800 text-amber-300 border border-amber-500/30 hover:bg-slate-700 text-xs font-semibold"
              >
                Get Code
              </button>
              <input
                type="text"
                placeholder="Pairing code"
                value={pairingCode}
                onChange={(e) => setPairingCode(e.target.value)}
                className="bg-slate-900 border border-amber-500/40 rounded px-2 py-1 text-xs text-white w-28 focus:outline-none"
              />
              <button
                onClick={handlePairSession}
                className="px-2.5 py-1 rounded bg-amber-500 text-slate-950 font-bold hover:bg-amber-400 text-xs"
              >
                Pair
              </button>
            </div>
          </div>
        )}

        {pairingSuccess && (
          <div className="bg-emerald-950/80 text-emerald-300 text-xs px-4 py-1.5 border-b border-emerald-500/30 flex items-center justify-between">
            <span>{pairingSuccess}</span>
            <button onClick={() => setPairingSuccess(null)}><X className="w-3 h-3" /></button>
          </div>
        )}

        {pairingError && (
          <div className="bg-rose-950/80 text-rose-300 text-xs px-4 py-1.5 border-b border-rose-500/30 flex items-center justify-between">
            <span>{pairingError}</span>
            <button onClick={() => setPairingError(null)}><X className="w-3 h-3" /></button>
          </div>
        )}

        {/* Main Content Area */}
        <div className="flex-1 overflow-y-auto p-3 sm:p-4 bg-slate-900/50">
          
          {/* ======================================================== */}
          {/* TAB 1: AGENT RUNNER                                      */}
          {/* ======================================================== */}
          {activeTab === 'agent' && (
            <div className="space-y-4 max-w-4xl mx-auto">
              {/* Task Input Box */}
              <div className="bg-slate-950/70 border border-purple-500/30 rounded-xl p-3 sm:p-4 shadow-md space-y-3">
                <label className="block text-xs font-bold uppercase tracking-wider text-purple-300">
                  Autonomous Task Instruction
                </label>
                <div className="flex flex-col sm:flex-row gap-2">
                  <textarea
                    rows={2}
                    value={taskPrompt}
                    onChange={(e) => setTaskPrompt(e.target.value)}
                    placeholder="e.g. Create a python utility math_ops.py with tests and run unittest"
                    className="flex-1 bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-xs sm:text-sm text-slate-100 focus:outline-none focus:border-purple-400 font-mono resize-none"
                  />
                  <div className="flex sm:flex-col gap-2 shrink-0">
                    {!isRunning ? (
                      <button
                        onClick={handleStartTask}
                        disabled={!taskPrompt.trim()}
                        className="flex-1 sm:flex-none min-h-[44px] min-w-[44px] px-5 py-2.5 rounded-lg bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-md transition-all disabled:opacity-50"
                      >
                        <Play className="w-4 h-4 fill-current" /> Run Task
                      </button>
                    ) : (
                      <button
                        onClick={handleStopTask}
                        className="flex-1 sm:flex-none min-h-[44px] min-w-[44px] px-5 py-2.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-md transition-all animate-pulse"
                      >
                        <Square className="w-4 h-4 fill-current" /> Stop
                      </button>
                    )}
                  </div>
                </div>
                {taskError && (
                  <p className="text-xs text-rose-400 font-mono">{taskError}</p>
                )}
              </div>

              {/* Live Steps & Progress */}
              {currentTask ? (
                <div className="space-y-3">
                  <div className="flex items-center justify-between text-xs text-slate-400 px-1">
                    <span className="font-mono">
                      Task: <strong className="text-white">{currentTask.taskId}</strong> ({currentTask.status})
                    </span>
                    <span>Steps: {currentTask.logs.length}</span>
                  </div>

                  {/* Step List */}
                  <div className="space-y-2">
                    {currentTask.logs.map((step: AgentLogEntry) => {
                      const isSuccess = step.status === 'success';
                      const isRunningStep = step.status === 'running';
                      return (
                        <div
                          key={step.stepNumber}
                          className="bg-slate-950/80 border border-purple-500/20 rounded-lg p-3 text-xs space-y-1.5"
                        >
                          <div className="flex items-center justify-between">
                            <span className="font-mono text-purple-400 font-semibold uppercase">
                              Step {step.stepNumber} [{step.phase}]
                            </span>
                            <span
                              className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                                isSuccess
                                  ? 'bg-emerald-500/20 text-emerald-300'
                                  : isRunningStep
                                  ? 'bg-amber-500/20 text-amber-300 animate-pulse'
                                  : 'bg-rose-500/20 text-rose-300'
                              }`}
                            >
                              {step.status}
                            </span>
                          </div>

                          {step.description && (
                            <p className="text-slate-300 whitespace-pre-wrap font-sans">
                              {maskSecrets(step.description)}
                            </p>
                          )}

                          {step.toolName && (
                            <div className="bg-slate-900/80 rounded p-2 font-mono text-[11px] text-cyan-300 space-y-1">
                              <div>Tool: <strong>{step.toolName}</strong></div>
                              {step.toolArgs && (
                                <div className="text-slate-400 text-[10px] overflow-x-auto">
                                  {maskSecrets(JSON.stringify(step.toolArgs))}
                                </div>
                              )}
                            </div>
                          )}

                          {step.toolResult && (
                            <div className="bg-slate-900 border border-slate-800 rounded p-2 font-mono text-[11px] text-slate-300 max-h-36 overflow-y-auto whitespace-pre-wrap">
                              {maskSecrets(step.toolResult.output)}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>

                  {/* Final Report */}
                  {currentTask.finalReport && (
                    <div className="bg-indigo-950/40 border border-indigo-500/40 rounded-xl p-4 space-y-2">
                      <h4 className="text-xs font-bold text-indigo-300 uppercase tracking-wider flex items-center gap-1.5">
                        <Check className="w-4 h-4 text-emerald-400" /> Final Report
                      </h4>
                      <div className="text-xs text-slate-200 whitespace-pre-wrap font-sans leading-relaxed">
                        {maskSecrets(currentTask.finalReport)}
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <div className="text-center py-12 text-slate-500 text-xs">
                  No active task running. Enter an instruction above to begin autonomous execution.
                </div>
              )}
            </div>
          )}

          {/* ======================================================== */}
          {/* TAB 2: APPROVALS (MOST IMPORTANT)                        */}
          {/* ======================================================== */}
          {activeTab === 'approvals' && (
            <div className="space-y-4 max-w-3xl mx-auto">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <ShieldAlert className="w-4 h-4 text-rose-400" /> Pending Approval Requests
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    Human-in-the-loop permission gateway. Approvals require dedicated user credentials.
                  </p>
                </div>
                <button
                  onClick={refreshApprovals}
                  className="px-2.5 py-1 text-xs rounded bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center gap-1"
                >
                  <RefreshCw className="w-3 h-3" /> Refresh
                </button>
              </div>

              {approvalFeedback && (
                <div className="bg-purple-950/70 border border-purple-500/40 text-purple-200 text-xs p-2 rounded">
                  {approvalFeedback}
                </div>
              )}

              {pendingApprovals.length === 0 ? (
                <div className="bg-slate-950/40 border border-slate-800 rounded-xl p-8 text-center text-slate-500 text-xs">
                  <Check className="w-6 h-6 mx-auto mb-2 text-emerald-500/60" />
                  No actions currently pending approval. All operations are authorized or idle.
                </div>
              ) : (
                <div className="space-y-3">
                  {pendingApprovals.map((req) => {
                    const isStrict = req.level === 'STRICT_APPROVAL_WITH_WARNING';
                    const isConfirming = confirmingStrictId === req.id;
                    return (
                      <div
                        key={req.id}
                        className={`bg-slate-950 border rounded-xl p-4 space-y-3 shadow-lg ${
                          isStrict ? 'border-rose-500/50 bg-rose-950/10' : 'border-purple-500/30'
                        }`}
                      >
                        <div className="flex items-start justify-between gap-2">
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="font-mono font-bold text-sm text-cyan-300">
                                {req.toolName}
                              </span>
                              <span
                                className={`text-[10px] px-2 py-0.5 rounded-full font-bold font-mono ${
                                  isStrict
                                    ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                                    : 'bg-purple-500/20 text-purple-300 border border-purple-500/40'
                                }`}
                              >
                                {req.level}
                              </span>
                            </div>
                            <p className="text-xs text-slate-300 mt-1">{req.reason}</p>
                          </div>
                          <span className="text-[10px] text-slate-500 font-mono">
                            ID: {req.id}
                          </span>
                        </div>

                        {req.warning && (
                          <div className="bg-rose-950/60 border border-rose-500/40 rounded p-2 text-xs text-rose-200 flex items-center gap-2 font-mono">
                            <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                            <span>{req.warning}</span>
                          </div>
                        )}

                        {/* Full Arguments & Preview */}
                        <div className="bg-slate-900 border border-slate-800 rounded p-2.5 font-mono text-xs text-slate-300 max-h-48 overflow-y-auto space-y-1">
                          <div className="text-[10px] text-slate-500 uppercase">Arguments & Binding:</div>
                          <pre className="text-[11px] whitespace-pre-wrap">
                            {maskSecrets(JSON.stringify(req.args, null, 2))}
                          </pre>
                        </div>

                        {/* Action Buttons */}
                        <div className="flex items-center justify-end gap-2 pt-1">
                          <button
                            data-testid="deny-action-btn"
                            onClick={() => handleApprovalResponse(req.id, false, isStrict)}
                            className="min-h-[44px] min-w-[44px] px-4 py-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold flex items-center justify-center"
                          >
                            Deny Action
                          </button>

                          <button
                            data-testid="approve-action-btn"
                            onClick={() => handleApprovalResponse(req.id, true, isStrict)}
                            className={`min-h-[44px] min-w-[44px] px-5 py-2.5 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                              isConfirming
                                ? 'bg-rose-600 hover:bg-rose-500 text-white animate-pulse'
                                : 'bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white shadow-md'
                            }`}
                          >
                            <Check className="w-4 h-4" />
                            {isConfirming ? 'Tap Again to Confirm Strict Action' : 'Approve Action'}
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* ======================================================== */}
          {/* TAB 3: TERMINAL SHELL                                    */}
          {/* ======================================================== */}
          {activeTab === 'terminal' && (
            <div className="space-y-3 max-w-4xl mx-auto flex flex-col h-full">
              {/* Terminal Header */}
              <div className="flex items-center justify-between text-xs font-mono text-slate-400 bg-slate-950 p-2 rounded-t-lg border border-purple-500/20">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-rose-500"></span>
                  <span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span>
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
                  <span className="text-slate-300 ml-2">appuser@zoya:{terminalCwd}$</span>
                </div>
                <button
                  onClick={() => agentClient.clearTerminalHistory().then(() => setTerminalHistory([]))}
                  className="text-[10px] text-slate-500 hover:text-slate-300"
                >
                  Clear History
                </button>
              </div>

              {/* Terminal Screen */}
              <div className="flex-1 min-h-[300px] bg-slate-950 border-x border-b border-purple-500/20 p-3 font-mono text-xs text-slate-200 overflow-y-auto space-y-2 rounded-b-lg">
                {terminalHistory.map((h, i) => (
                  <div key={i} className="border-b border-slate-900 pb-2">
                    <div className="text-purple-400 font-bold">$ {h.command}</div>
                    {h.stdout && <pre className="text-emerald-300 whitespace-pre-wrap">{maskSecrets(h.stdout)}</pre>}
                    {h.stderr && <pre className="text-rose-400 whitespace-pre-wrap">{maskSecrets(h.stderr)}</pre>}
                    <div className="text-[10px] text-slate-600 mt-1">
                      exit: {h.exitCode} • {h.durationMs}ms • {new Date(h.timestamp).toLocaleTimeString()}
                    </div>
                  </div>
                ))}
                {terminalOutput && (
                  <pre className="text-cyan-300 whitespace-pre-wrap">{maskSecrets(terminalOutput)}</pre>
                )}
                {terminalRunning && (
                  <div className="text-amber-400 animate-pulse flex items-center gap-1.5">
                    <RefreshCw className="w-3 h-3 animate-spin" /> Executing command under appuser isolation...
                  </div>
                )}
              </div>

              {/* Command Input Bar */}
              <div className="flex gap-2">
                <input
                  type="text"
                  value={terminalCommand}
                  onChange={(e) => setTerminalCommand(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleExecuteTerminal()}
                  placeholder="Enter shell command (e.g. ls -la, python3 -c '...')"
                  className="flex-1 min-h-[44px] bg-slate-950 border border-slate-700 rounded-lg px-3 py-2.5 text-xs font-mono text-slate-100 focus:outline-none focus:border-purple-400"
                />
                <button
                  data-testid="terminal-run-btn"
                  onClick={handleExecuteTerminal}
                  disabled={terminalRunning || !terminalCommand.trim()}
                  className="min-h-[44px] min-w-[64px] px-5 py-2.5 bg-purple-600 hover:bg-purple-500 text-white rounded-lg text-xs font-bold disabled:opacity-50 flex items-center justify-center"
                >
                  Send
                </button>
              </div>
            </div>
          )}

          {/* ======================================================== */}
          {/* TAB 4: PROJECT FILES & DIFFS                             */}
          {/* ======================================================== */}
          {activeTab === 'files' && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 h-full">
              {/* File Tree Column */}
              <div className="bg-slate-950 border border-purple-500/20 rounded-xl p-3 overflow-y-auto space-y-2">
                <div className="flex items-center justify-between text-xs font-bold text-slate-300 uppercase">
                  <span>Workspace Files</span>
                  <button onClick={refreshFiles}><RefreshCw className="w-3 h-3" /></button>
                </div>
                <div className="space-y-1">
                  {fileTree.map((item, idx) => (
                    <button
                      key={idx}
                      onClick={() => item.type === 'file' && handleSelectFile(item.path)}
                      className={`w-full text-left px-2 py-1.5 rounded text-xs font-mono flex items-center gap-1.5 truncate ${
                        selectedFilePath === item.path
                          ? 'bg-purple-600/30 text-purple-200 border border-purple-500/40'
                          : 'text-slate-400 hover:bg-slate-900 hover:text-slate-200'
                      }`}
                    >
                      {item.type === 'directory' ? '📁' : '📄'}
                      <span className="truncate">{item.name}</span>
                    </button>
                  ))}
                </div>

                {fileChanges.length > 0 && (
                  <div className="pt-3 border-t border-slate-900 space-y-1.5">
                    <span className="text-[10px] text-amber-400 font-bold uppercase tracking-wider">
                      Recent File Modifications
                    </span>
                    {fileChanges.map((c, i) => (
                      <div key={i} className="text-[11px] font-mono flex items-center justify-between text-slate-400">
                        <span className="truncate">{c.path}</span>
                        <button
                          onClick={() => handleRevertFile(c.path)}
                          title="Revert to snapshot"
                          className="text-rose-400 hover:text-rose-300 ml-2"
                        >
                          <RotateCcw className="w-3 h-3" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* File Editor & Diff Column */}
              <div className="md:col-span-2 bg-slate-950 border border-purple-500/20 rounded-xl p-3 flex flex-col space-y-2 overflow-hidden">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono text-cyan-300 font-bold truncate">
                    {selectedFilePath || 'Select a file to inspect / edit'}
                  </span>
                  {selectedFilePath && (
                    <div className="flex items-center gap-2">
                      <button
                        onClick={handleSaveFile}
                        disabled={isSavingFile}
                        className="px-3 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-xs font-bold"
                      >
                        {isSavingFile ? 'Saving...' : 'Save File'}
                      </button>
                    </div>
                  )}
                </div>

                <textarea
                  value={fileContent}
                  onChange={(e) => setFileContent(e.target.value)}
                  disabled={!selectedFilePath || isLoadingFile}
                  rows={14}
                  className="flex-1 bg-slate-900 border border-slate-800 rounded p-2.5 font-mono text-xs text-slate-200 focus:outline-none focus:border-purple-400 resize-none"
                />

                {fileDiff && (
                  <div className="bg-slate-900/80 border border-purple-500/20 rounded p-2 text-xs font-mono max-h-36 overflow-y-auto">
                    <div className="text-[10px] text-slate-500 font-bold mb-1">UNIFIED DIFF:</div>
                    <pre className="text-[11px] whitespace-pre-wrap text-slate-300">{fileDiff}</pre>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* ======================================================== */}
          {/* TAB 5: SKILLS LIBRARY                                    */}
          {/* ======================================================== */}
          {activeTab === 'skills' && (
            <div className="space-y-4 max-w-4xl mx-auto">
              {/* Import Bar */}
              <div className="bg-slate-950/80 border border-purple-500/30 rounded-xl p-3 sm:p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-bold text-purple-300 uppercase tracking-wider">
                    Import Skill into Quarantine Sandbox
                  </h3>
                  <div className="flex gap-2 text-xs font-mono">
                    <label className="flex items-center gap-1 cursor-pointer">
                      <input
                        type="radio"
                        checked={importType === 'git'}
                        onChange={() => setImportType('git')}
                      />
                      Git Repo
                    </label>
                    <label className="flex items-center gap-1 cursor-pointer">
                      <input
                        type="radio"
                        checked={importType === 'folder'}
                        onChange={() => setImportType('folder')}
                      />
                      Folder Path
                    </label>
                    <label className="flex items-center gap-1 cursor-pointer">
                      <input
                        type="radio"
                        checked={importType === 'zip'}
                        onChange={() => setImportType('zip')}
                      />
                      Zip Archive
                    </label>
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row gap-2">
                  {importType === 'zip' && (
                    <>
                      <input
                        ref={zipFileInputRef}
                        type="file"
                        accept=".zip,application/zip"
                        onChange={handleImportZipFile}
                        className="hidden"
                      />
                      <button
                        onClick={() => zipFileInputRef.current?.click()}
                        disabled={isSkillLoading}
                        className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 whitespace-nowrap"
                      >
                        <Upload className="w-3.5 h-3.5" /> Choose .zip File
                      </button>
                    </>
                  )}
                  <input
                    type="text"
                    value={importInput}
                    onChange={(e) => setImportInput(e.target.value)}
                    placeholder={
                      importType === 'git'
                        ? 'https://github.com/org/repo'
                        : importType === 'zip'
                        ? '/path/to/skill.zip or choose file'
                        : '/absolute/path/to/skill'
                    }
                    className="flex-1 bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs font-mono text-slate-100 focus:outline-none focus:border-purple-400"
                  />
                  <button
                    onClick={handleImportSkill}
                    disabled={isSkillLoading || !importInput.trim()}
                    className="px-4 py-2 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 disabled:opacity-50"
                  >
                    <Download className="w-3.5 h-3.5" /> Import & Scan
                  </button>
                </div>
              </div>

              {/* Skill Update Diff Review Modal */}
              {skillUpdateDiff && (
                <div className="bg-slate-950 border border-blue-500/50 rounded-xl p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-blue-300 uppercase flex items-center gap-1.5">
                      <FileCode className="w-4 h-4" /> Skill Update Diff Review ({skillUpdateDiff.skillId})
                    </span>
                    <button onClick={() => setSkillUpdateDiff(null)}><X className="w-4 h-4" /></button>
                  </div>
                  <div className="text-xs font-mono space-y-1 text-slate-300">
                    <div>Target Skill: <strong className="text-white">{skillUpdateDiff.skillId}</strong></div>
                    <div>New Quarantine Hash: {skillUpdateDiff.scan?.contentHash?.slice(0, 16)}...</div>
                    <div>New Version: {skillUpdateDiff.scan?.version || 'N/A'}</div>
                    <div>Risk Level: <strong className={skillUpdateDiff.scan?.riskLevel === 'HIGH' ? 'text-rose-400' : 'text-emerald-400'}>{skillUpdateDiff.scan?.riskLevel}</strong></div>
                  </div>
                  <div className="bg-slate-900 border border-slate-800 rounded-lg p-3 max-h-56 overflow-y-auto font-mono text-[11px] whitespace-pre-wrap">
                    {skillUpdateDiff.diff ? (
                      skillUpdateDiff.diff.split('\n').map((line, idx) => (
                        <div
                          key={idx}
                          className={
                            line.startsWith('+') && !line.startsWith('+++')
                              ? 'text-emerald-400 bg-emerald-950/20'
                              : line.startsWith('-') && !line.startsWith('---')
                              ? 'text-rose-400 bg-rose-950/20'
                              : line.startsWith('@@')
                              ? 'text-cyan-400'
                              : 'text-slate-400'
                          }
                        >
                          {line}
                        </div>
                      ))
                    ) : (
                      <span className="text-slate-500 italic">No file changes detected between versions.</span>
                    )}
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => setSkillUpdateDiff(null)}
                      className="flex-1 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold rounded-lg"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={() => handleApplySkillUpdate(skillUpdateDiff.skillId, skillUpdateDiff.quarantineId)}
                      className="flex-1 py-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold rounded-lg flex items-center justify-center gap-1.5"
                    >
                      <Check className="w-4 h-4" /> Approve & Apply Update
                    </button>
                  </div>
                </div>
              )}

              {/* Scan Report Modal/Card */}
              {activeScanReport && (
                <div className="bg-slate-950 border border-amber-500/50 rounded-xl p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-amber-300 uppercase flex items-center gap-1.5">
                      <AlertTriangle className="w-4 h-4" /> Quarantine Security Scan Report
                    </span>
                    <button onClick={() => setActiveScanReport(null)}><X className="w-4 h-4" /></button>
                  </div>
                  <div className="text-xs font-mono space-y-1">
                    <div>Skill: <strong>{activeScanReport.manifest?.name || activeScanReport.name}</strong> (v{activeScanReport.manifest?.version || activeScanReport.version})</div>
                    <div>Risk Level: <strong className={activeScanReport.riskLevel === 'HIGH' ? 'text-rose-400' : 'text-amber-400'}>{activeScanReport.riskLevel}</strong></div>
                    <div>Content Hash: {activeScanReport.contentHash}</div>
                  </div>

                  {/* Missing Dependencies Display */}
                  {activeScanReport.dependencies && (
                    (activeScanReport.dependencies.python?.missing?.length > 0) ||
                    (activeScanReport.dependencies.node?.missing?.length > 0) ||
                    (activeScanReport.dependencies.binaries?.missing?.length > 0)
                  ) && (
                    <div className="bg-amber-950/40 border border-amber-500/40 rounded-lg p-3 space-y-1.5 text-xs font-mono">
                      <div className="font-bold text-amber-300 flex items-center gap-1.5">
                        <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
                        Missing Dependencies Required by Skill:
                      </div>
                      {activeScanReport.dependencies.python?.missing?.length > 0 && (
                        <div className="text-amber-200">
                          <span className="text-amber-400 font-bold">Python Packages: </span>
                          {activeScanReport.dependencies.python.missing.join(', ')}
                        </div>
                      )}
                      {activeScanReport.dependencies.node?.missing?.length > 0 && (
                        <div className="text-amber-200">
                          <span className="text-amber-400 font-bold">Node Packages: </span>
                          {activeScanReport.dependencies.node.missing.join(', ')}
                        </div>
                      )}
                      {activeScanReport.dependencies.binaries?.missing?.length > 0 && (
                        <div className="text-amber-200">
                          <span className="text-amber-400 font-bold">CLI Tools: </span>
                          {activeScanReport.dependencies.binaries.missing.join(', ')}
                        </div>
                      )}
                      <div className="text-[11px] text-amber-300/70 italic mt-1">
                        Note: Skills engine does not auto-install unverified packages without explicit approval.
                      </div>
                    </div>
                  )}

                  {activeScanReport.findings?.length > 0 && (
                    <div className="bg-slate-900 p-2 rounded text-[11px] font-mono text-rose-300 space-y-1">
                      {activeScanReport.findings.map((f: any, i: number) => (
                        <div key={i}>[{f.severity || f.risk}] {f.file}:{f.line} - {f.pattern || f.message}</div>
                      ))}
                    </div>
                  )}

                  {installedSkills.some(s => s.id === (activeScanReport.manifest?.name || activeScanReport.name) || s.manifest?.name === (activeScanReport.manifest?.name || activeScanReport.name)) ? (
                    <button
                      onClick={() => {
                        const targetName = activeScanReport.manifest?.name || activeScanReport.name;
                        const match = installedSkills.find(s => s.id === targetName || s.manifest?.name === targetName);
                        if (match) handleCheckSkillUpdate(match.id, activeScanReport.quarantineId);
                      }}
                      className="w-full py-2 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-bold text-xs rounded-lg flex items-center justify-center gap-1.5"
                    >
                      <Eye className="w-4 h-4" /> Review Unified Diff & Update Existing Skill
                    </button>
                  ) : (
                    <button
                      onClick={() => handleInstallQuarantineSkill(activeScanReport.quarantineId, true)}
                      className="w-full py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-lg"
                    >
                      Install Skill to Engine
                    </button>
                  )}
                </div>
              )}

              {/* Installed Skills List */}
              <div className="space-y-2">
                <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                  Installed Skills ({installedSkills.length})
                </h4>
                {installedSkills.length === 0 ? (
                  <div className="bg-slate-950/40 border border-slate-800 rounded-xl p-6 text-center text-slate-500 text-xs">
                    No skills currently installed.
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {installedSkills.map((s) => (
                      <div
                        key={s.id}
                        className="bg-slate-950 border border-purple-500/20 rounded-xl p-3.5 space-y-2 flex flex-col justify-between"
                      >
                        <div>
                          <div className="flex items-center justify-between">
                            <h5 className="font-bold text-xs text-white">{s.manifest?.name || s.id}</h5>
                            <span
                              className={`text-[10px] px-2 py-0.5 rounded-full font-mono font-bold ${
                                s.status === 'enabled'
                                  ? 'bg-emerald-500/20 text-emerald-300'
                                  : 'bg-slate-800 text-slate-400'
                              }`}
                            >
                              {s.status}
                            </span>
                          </div>
                          <p className="text-[11px] text-slate-400 mt-1 line-clamp-2">
                            {s.manifest?.description}
                          </p>
                          {s.dependencies && (
                            ((s.dependencies.python?.missing?.length || 0) > 0) ||
                            ((s.dependencies.node?.missing?.length || 0) > 0) ||
                            ((s.dependencies.binaries?.missing?.length || 0) > 0)
                          ) && (
                            <div className="mt-1.5 px-2 py-1 rounded bg-amber-950/40 border border-amber-500/30 text-[10px] font-mono text-amber-300">
                              <span className="font-bold">Missing: </span>
                              {[
                                ...(s.dependencies.python?.missing || []).map((p: string) => `py:${p}`),
                                ...(s.dependencies.node?.missing || []).map((n: string) => `npm:${n}`),
                                ...(s.dependencies.binaries?.missing || []).map((b: string) => `bin:${b}`),
                              ].join(', ')}
                            </div>
                          )}
                        </div>

                        <div className="pt-2 border-t border-slate-900 flex items-center justify-between">
                          <span className="text-[10px] text-slate-500 font-mono">
                            Risk: {s.riskLevel || 'LOW'}
                          </span>
                          <div className="flex items-center gap-2">
                            <button
                              data-testid={`skill-toggle-${s.id}`}
                              onClick={() => handleToggleSkill(s.id, s.status === 'enabled')}
                              className="min-h-[44px] min-w-[64px] px-4 py-2.5 text-xs font-bold rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 flex items-center justify-center"
                            >
                              {s.status === 'enabled' ? 'Disable' : 'Enable'}
                            </button>
                            <button
                              data-testid={`skill-delete-${s.id}`}
                              onClick={() => handleDeleteSkill(s.id)}
                              className="min-h-[44px] min-w-[44px] p-2.5 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-slate-900 flex items-center justify-center"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* ======================================================== */}
          {/* TAB 6: MCP CLIENT & SERVERS                              */}
          {/* ======================================================== */}
          {activeTab === 'mcp' && (
            <div className="space-y-4 max-w-4xl mx-auto">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <Server className="w-4 h-4 text-cyan-400" /> Configured MCP Servers
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    Model Context Protocol stdio & HTTP/SSE external tool providers.
                  </p>
                </div>
                <button
                  onClick={() => setShowAddMcpModal(true)}
                  className="px-3 py-1.5 rounded-lg bg-gradient-to-r from-purple-600 to-indigo-600 text-white font-bold text-xs flex items-center gap-1.5"
                >
                  <Plus className="w-3.5 h-3.5" /> Add Server
                </button>
              </div>

              {/* Add Server Modal Dialog */}
              {showAddMcpModal && (
                <div className="bg-slate-950 border border-purple-500/40 rounded-xl p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-purple-300 uppercase">Register New MCP Server</span>
                    <button onClick={() => setShowAddMcpModal(false)}><X className="w-4 h-4" /></button>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                    <div>
                      <label className="block text-slate-400 mb-1">Server Name</label>
                      <input
                        type="text"
                        value={newMcpName}
                        onChange={(e) => setNewMcpName(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-400 mb-1">Transport</label>
                      <select
                        value={newMcpTransport}
                        onChange={(e: any) => setNewMcpTransport(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-white"
                      >
                        <option value="stdio">stdio (Subprocess)</option>
                        <option value="http">http (HTTP / SSE)</option>
                      </select>
                    </div>

                    {newMcpTransport === 'stdio' ? (
                      <>
                        <div>
                          <label className="block text-slate-400 mb-1">Executable Command</label>
                          <input
                            type="text"
                            value={newMcpCommand}
                            onChange={(e) => setNewMcpCommand(e.target.value)}
                            className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-white font-mono"
                          />
                        </div>
                        <div>
                          <label className="block text-slate-400 mb-1">Arguments</label>
                          <input
                            type="text"
                            value={newMcpArgs}
                            onChange={(e) => setNewMcpArgs(e.target.value)}
                            className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-white font-mono"
                          />
                        </div>
                      </>
                    ) : (
                      <div className="sm:col-span-2">
                        <label className="block text-slate-400 mb-1">Server URL</label>
                        <input
                          type="text"
                          value={newMcpUrl}
                          onChange={(e) => setNewMcpUrl(e.target.value)}
                          className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-white font-mono"
                        />
                      </div>
                    )}
                  </div>

                  <button
                    onClick={handleAddMcpServer}
                    className="w-full py-2 bg-gradient-to-r from-purple-600 to-indigo-600 text-white font-bold text-xs rounded-lg"
                  >
                    Save & Register Server
                  </button>
                </div>
              )}

              {/* Servers List */}
              <div className="space-y-3">
                {mcpServers.map((srv) => (
                  <div
                    key={srv.id}
                    className="bg-slate-950 border border-purple-500/20 rounded-xl p-3.5 space-y-2"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-sm text-white">{srv.name}</span>
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-800 font-mono text-slate-300">
                          {srv.transport}
                        </span>
                        <span
                          className={`text-[10px] px-2 py-0.5 rounded-full font-mono font-bold ${
                            srv.status === 'connected'
                              ? 'bg-emerald-500/20 text-emerald-300'
                              : 'bg-slate-800 text-slate-400'
                          }`}
                        >
                          {srv.status}
                        </span>
                      </div>

                      <div className="flex items-center gap-2">
                        {srv.status === 'connected' ? (
                          <button
                            data-testid={`mcp-disconnect-${srv.id}`}
                            onClick={() => handleDisconnectMcp(srv.id)}
                            className="min-h-[44px] min-w-[64px] px-4 py-2.5 text-xs font-semibold rounded-lg bg-slate-800 text-slate-300 hover:bg-slate-700 flex items-center justify-center"
                          >
                            Disconnect
                          </button>
                        ) : (
                          <button
                            data-testid={`mcp-connect-${srv.id}`}
                            onClick={() => handleConnectMcp(srv.id)}
                            className="min-h-[44px] min-w-[64px] px-4 py-2.5 text-xs rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold flex items-center justify-center"
                          >
                            Connect
                          </button>
                        )}
                        <button
                          data-testid={`mcp-remove-${srv.id}`}
                          onClick={() => handleRemoveMcp(srv.id)}
                          className="min-h-[44px] min-w-[44px] p-2.5 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-slate-900 flex items-center justify-center"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    <div className="text-[11px] font-mono text-slate-400">
                      {srv.transport === 'stdio' ? `${srv.command} ${(srv.args || []).join(' ')}` : srv.url}
                    </div>
                  </div>
                ))}
              </div>

              {/* Discovered Tools & Call Testing Form */}
              <div className="bg-slate-950 border border-purple-500/20 rounded-xl p-4 space-y-3">
                <h4 className="text-xs font-bold text-purple-300 uppercase tracking-wider">
                  Discovered MCP Tools & Execution Tester
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div>
                    <label className="block text-slate-400 mb-1">Select Tool</label>
                    <select
                      value={`${mcpToolCallServerId}:${mcpToolCallName}`}
                      onChange={(e) => {
                        const [sId, tName] = e.target.value.split(':');
                        setMcpToolCallServerId(sId);
                        setMcpToolCallName(tName);
                      }}
                      className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-white font-mono"
                    >
                      <option value="">Select a discovered tool...</option>
                      {discoveredMcpTools.map((t, idx) => (
                        <option key={idx} value={`${t.serverId}:${t.name}`}>
                          {t.serverName}: {t.name}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-slate-400 mb-1">Arguments (JSON)</label>
                    <input
                      type="text"
                      value={mcpToolCallArgs}
                      onChange={(e) => setMcpToolCallArgs(e.target.value)}
                      placeholder='{"expression": "48 * 29"}'
                      className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-white font-mono"
                    />
                  </div>
                </div>

                <button
                  data-testid="mcp-call-tool-btn"
                  onClick={handleCallMcpTool}
                  disabled={!mcpToolCallServerId || !mcpToolCallName}
                  className="min-h-[44px] min-w-[44px] px-5 py-2.5 bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs rounded-lg disabled:opacity-50 flex items-center justify-center"
                >
                  Call Tool via Permission Guard
                </button>

                {mcpToolCallResult && (
                  <pre className="bg-slate-900 border border-slate-800 rounded p-3 text-xs font-mono text-slate-200 whitespace-pre-wrap max-h-48 overflow-y-auto">
                    {maskSecrets(mcpToolCallResult)}
                  </pre>
                )}
              </div>
            </div>
          )}

          {/* ======================================================== */}
          {/* TAB 7: TASK HISTORY                                      */}
          {/* ======================================================== */}
          {activeTab === 'history' && (
            <div className="space-y-3 max-w-4xl mx-auto">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <History className="w-4 h-4 text-purple-400" /> Past Autonomous Tasks
                </h3>
                <button onClick={refreshHistory} className="text-xs text-slate-400 hover:text-white">
                  <RefreshCw className="w-3 h-3" />
                </button>
              </div>

              {taskHistory.length === 0 ? (
                <div className="bg-slate-950/40 border border-slate-800 rounded-xl p-8 text-center text-slate-500 text-xs">
                  No historical tasks recorded yet.
                </div>
              ) : (
                <div className="space-y-3">
                  {taskHistory.map((t) => (
                    <div
                      key={t.taskId}
                      className="bg-slate-950 border border-purple-500/20 rounded-xl p-3.5 space-y-2"
                    >
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-mono font-bold text-white">{t.taskId}</span>
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                            t.status === 'completed'
                              ? 'bg-emerald-500/20 text-emerald-300'
                              : 'bg-rose-500/20 text-rose-300'
                          }`}
                        >
                          {t.status}
                        </span>
                      </div>
                      <p className="text-xs text-slate-300 font-mono">{t.userPrompt}</p>
                      {t.finalReport && (
                        <div className="bg-slate-900 p-2.5 rounded text-xs text-slate-300 whitespace-pre-wrap font-sans">
                          {maskSecrets(t.finalReport)}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* ======================================================== */}
          {/* TAB 8: EXECUTION & SECURITY AUDIT LOGS                   */}
          {/* ======================================================== */}
          {activeTab === 'logs' && (
            <div className="space-y-3 max-w-4xl mx-auto">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <FileText className="w-4 h-4 text-indigo-400" /> Security & Execution Audit Trail
                </h3>
                <select
                  value={auditFilter}
                  onChange={(e) => setAuditFilter(e.target.value)}
                  className="bg-slate-900 border border-slate-700 rounded px-2 py-1 text-xs text-white"
                >
                  <option value="ALL">All Events</option>
                  <option value="BLOCKED">Blocked Violations</option>
                  <option value="APPROVAL">Approvals</option>
                  <option value="DENIED">Denied</option>
                  <option value="TOOL">Tool Calls</option>
                </select>
              </div>

              <div className="space-y-2 font-mono text-xs">
                {filteredLogs.map((l) => (
                  <div
                    key={l.id}
                    className="bg-slate-950 border border-slate-800 rounded p-2.5 space-y-1 text-slate-300"
                  >
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="font-bold text-purple-400">{l.action}</span>
                      <span className="text-slate-500">{new Date(l.timestamp).toLocaleTimeString()}</span>
                    </div>
                    <div className="text-slate-200">{maskSecrets(l.details)}</div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ======================================================== */}
          {/* TAB 9: PERMISSIONS AND SECURITY CONFIGURATION            */}
          {/* ======================================================== */}
          {activeTab === 'permissions' && (
            <div className="space-y-4 max-w-3xl mx-auto text-xs">
              {/* Credentials & Tokens */}
              <div className="bg-slate-950 border border-purple-500/30 rounded-xl p-4 space-y-3">
                <h4 className="font-bold text-purple-300 uppercase tracking-wider flex items-center gap-1.5">
                  <Key className="w-4 h-4 text-cyan-400" /> Authentication & Session Tokens
                </h4>
                <div className="space-y-2">
                  <div className="flex items-center justify-between bg-slate-900 p-2.5 rounded font-mono">
                    <div>
                      <div className="text-slate-400 text-[10px]">CURRENT AGENT TOKEN</div>
                      <div className="text-white">
                        {authToken ? `${authToken.slice(0, 14)}...${authToken.slice(-6)}` : '(None)'}
                      </div>
                    </div>
                    <button
                      data-testid="rotate-token-btn"
                      onClick={handleRotateToken}
                      className="min-h-[44px] min-w-[44px] px-4 py-2.5 bg-purple-600 hover:bg-purple-500 text-white rounded-lg font-bold text-xs flex items-center justify-center"
                    >
                      Rotate Token
                    </button>
                  </div>

                  {tokenRotatedMessage && (
                    <p className="text-emerald-400 text-[11px] font-mono">{tokenRotatedMessage}</p>
                  )}

                  <div className="bg-slate-900 p-2.5 rounded font-mono space-y-2">
                    <div className="text-slate-400 text-[10px]">OWNER PASSPHRASE AUTHENTICATION</div>
                    <div className="flex gap-2">
                      <input
                        type="password"
                        value={ownerPassphrase}
                        onChange={(e) => setOwnerPassphrase(e.target.value)}
                        placeholder="Enter owner passphrase"
                        className="flex-1 min-h-[44px] bg-slate-950 border border-slate-700 rounded-lg px-3 py-2.5 text-xs text-white"
                      />
                      <button
                        data-testid="owner-auth-btn"
                        onClick={handleLoginOwner}
                        className="min-h-[44px] min-w-[44px] px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-bold text-xs flex items-center justify-center"
                      >
                        Authenticate
                      </button>
                    </div>
                    {passphraseStatus && (
                      <p className="text-emerald-400 text-[11px] font-mono">{passphraseStatus}</p>
                    )}
                    <div className="text-[10px] text-slate-500">
                      Approvals use short-lived HttpOnly SameSite=Strict cookies. No secret or token stored in JS memory or browser storage.
                    </div>
                  </div>
                </div>
              </div>

              {/* Security Boundary Rules */}
              <div className="bg-slate-950 border border-purple-500/30 rounded-xl p-4 space-y-3">
                <h4 className="font-bold text-purple-300 uppercase tracking-wider flex items-center gap-1.5">
                  <Lock className="w-4 h-4 text-emerald-400" /> Kernel & Process Security Gates
                </h4>
                <div className="space-y-1.5 text-slate-300 font-mono text-[11px]">
                  <div>• Workspace Path: <strong className="text-white">/app/applet/workspace</strong></div>
                  <div>• Subprocess User: <strong className="text-white">appuser (UID 1000, GID 1000)</strong></div>
                  <div>• Network Isolation: <strong className="text-emerald-400">/usr/bin/unshare -n (active)</strong></div>
                  <div>• Environment Sanitization: <strong className="text-emerald-400">Strictly scrubbed (no API keys)</strong></div>
                  <div>• Secret Masking: <strong className="text-emerald-400">Extended 12-pattern regex redaction</strong></div>
                </div>
              </div>

              {/* Known Limitations */}
              <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-4 space-y-2 text-slate-400">
                <h5 className="font-bold text-slate-300 uppercase tracking-wider text-[11px] flex items-center gap-1.5">
                  <Info className="w-3.5 h-3.5 text-sky-400" /> Known Engine Limitations
                </h5>
                <ul className="list-disc pl-4 space-y-1 text-[11px]">
                  <li>Network-dependent MCP tools require explicit network permission approval.</li>
                  <li>Semantic steganography inside third-party outputs is treated as untrusted data.</li>
                  <li>SessionStorage holds session tokens; clearing browser session resets authorization.</li>
                </ul>
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};
