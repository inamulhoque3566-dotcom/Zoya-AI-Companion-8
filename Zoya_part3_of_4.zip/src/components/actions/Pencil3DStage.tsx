import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';

export interface PencilTargetState {
  normX: number; // [0..1] on paper canvas
  normY: number; // [0..1] on paper canvas
  isTouching: boolean; // true while actively laying graphite, false during travel hops
  isActive: boolean; // true while drawing/paused mid-sketch; false when resting at side
  isComplete: boolean; // true after final stroke finished
  strokeAngleRad: number; // current stroke tangent angle on paper
  pressure: number; // [0.2..1.0]
  stage: 'outlines' | 'details' | 'shading' | 'shadows';
}

interface Pencil3DStageProps {
  paperElementRef: React.RefObject<HTMLCanvasElement | null>;
  targetRef: React.MutableRefObject<PencilTargetState>;
  pencilStyle: 'realistic-graphite' | 'detailed-3d' | 'fine-line' | 'shaded-portrait';
}

// Module-level reusable math helpers (zero GC inside per-frame tick)
const _tmpColor = new THREE.Color();

function createPencilBarrelTexture(
  bodyHex: string,
  stripeHex: string,
  labelText: string
): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d');
  if (ctx) {
    // Rich lacquered base with subtle longitudinal coat sheen
    const grad = ctx.createLinearGradient(0, 0, 512, 0);
    grad.addColorStop(0, bodyHex);
    grad.addColorStop(0.5, stripeHex);
    grad.addColorStop(1, bodyHex);
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 512, 512);

    // Subtle lacquer micro-streaks
    ctx.fillStyle = 'rgba(255,255,255,0.04)';
    for (let i = 0; i < 64; i++) {
      ctx.fillRect(i * 8, 0, 2, 512);
    }

    // Fine gold foil edge pinstripe along barrel facets
    ctx.fillStyle = '#e6c675';
    for (let f = 0; f < 6; f++) {
      const fx = Math.round((f / 6) * 512);
      ctx.fillRect(fx, 0, 2, 512);
    }

    // Gold-stamped studio lettering along one primary facet
    ctx.save();
    ctx.translate(256, 260);
    ctx.rotate(-Math.PI / 2);
    ctx.font = 'bold 24px Georgia, serif';
    ctx.fillStyle = '#f3d98c';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(labelText, 0, 0);
    ctx.restore();
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.needsUpdate = true;
  return tex;
}

function createCedarConeTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 256;
  const ctx = canvas.getContext('2d');
  if (ctx) {
    const grad = ctx.createLinearGradient(0, 0, 0, 256);
    grad.addColorStop(0, '#c89566');
    grad.addColorStop(0.5, '#dfb284');
    grad.addColorStop(1, '#b88252');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 256, 256);

    // Fine longitudinal cedar wood grain fibers
    for (let i = 0; i < 140; i++) {
      const x = (i * 19) % 256;
      ctx.strokeStyle =
        i % 3 === 0 ? 'rgba(130, 74, 34, 0.22)' : 'rgba(255, 226, 194, 0.18)';
      ctx.lineWidth = 1 + (i % 2);
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.bezierCurveTo(x + 4, 85, x - 4, 170, x + 2, 256);
      ctx.stroke();
    }

    // Scalloped sharpener collar border near top of cone
    ctx.fillStyle = 'rgba(110, 62, 30, 0.28)';
    for (let f = 0; f < 6; f++) {
      const cx = (f + 0.5) * (256 / 6);
      ctx.beginPath();
      ctx.arc(cx, 252, 22, Math.PI, 0);
      ctx.fill();
    }
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.needsUpdate = true;
  return tex;
}

function createContactShadowTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 128;
  canvas.height = 128;
  const ctx = canvas.getContext('2d');
  if (ctx) {
    const grad = ctx.createRadialGradient(64, 64, 4, 64, 64, 62);
    grad.addColorStop(0, 'rgba(18, 14, 24, 0.52)');
    grad.addColorStop(0.35, 'rgba(24, 18, 32, 0.25)');
    grad.addColorStop(1, 'rgba(24, 18, 32, 0)');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 128, 128);
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.needsUpdate = true;
  return tex;
}

export const Pencil3DStage: React.FC<Pencil3DStageProps> = ({
  paperElementRef,
  targetRef,
  pencilStyle,
}) => {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const styleRef = useRef(pencilStyle);
  styleRef.current = pencilStyle;

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // 1. Software WebGL detection per Three.js performance standard
    const isSoftwareGl = (() => {
      try {
        const probe = document.createElement('canvas').getContext('webgl2');
        if (!probe) return true;
        const ext = probe.getExtension('WEBGL_debug_renderer_info');
        const param = ext ? ext.UNMASKED_RENDERER_WEBGL : probe.RENDERER;
        const gpu = String(probe.getParameter(param) || '');
        probe.getExtension('WEBGL_lose_context')?.loseContext();
        return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
      } catch {
        return false;
      }
    })();

    const width = Math.max(1, container.clientWidth);
    const height = Math.max(1, container.clientHeight);

    const renderer = new THREE.WebGLRenderer({
      alpha: true,
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance',
    });
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.12;
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio || 1, 2));
    renderer.setSize(width, height);
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.domElement.style.width = '100%';
    renderer.domElement.style.height = '100%';
    renderer.domElement.style.display = 'block';
    renderer.domElement.style.pointerEvents = 'none';
    container.appendChild(renderer.domElement);

    const scene = new THREE.Scene();

    // Studio environment reflection for realistic brass ferrule & graphite tip sheen
    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    const envTex = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    scene.environment = envTex;
    pmremGenerator.dispose();

    // Straight-down PerspectiveCamera with up=(0,0,-1) guarantees (worldX, 0, worldZ)
    // maps linearly to exact pixel coordinates on the underlying 2D paper canvas while
    // preserving true 3D perspective on the tilted pencil shaft rising above the paper.
    const fovDeg = 34;
    const camY = 10.5;
    const camera = new THREE.PerspectiveCamera(fovDeg, width / height, 0.5, 40);
    camera.position.set(0, camY, 0);
    camera.up.set(0, 0, -1);
    camera.lookAt(0, 0, 0);

    // 3-Point Studio Lighting Rig
    const hemiLight = new THREE.HemisphereLight(0xebf2ff, 0x7c6a58, 0.9);
    scene.add(hemiLight);

    const keyLight = new THREE.DirectionalLight(0xfff4e2, 2.35);
    keyLight.position.set(-4.5, 9.5, -3.5);
    keyLight.castShadow = !isSoftwareGl;
    keyLight.shadow.mapSize.width = 1024;
    keyLight.shadow.mapSize.height = 1024;
    keyLight.shadow.camera.near = 1;
    keyLight.shadow.camera.far = 22;
    keyLight.shadow.camera.left = -6;
    keyLight.shadow.camera.right = 6;
    keyLight.shadow.camera.top = 6;
    keyLight.shadow.camera.bottom = -6;
    keyLight.shadow.bias = -0.0005;
    keyLight.shadow.normalBias = 0.02;
    scene.add(keyLight);

    const rimLight = new THREE.DirectionalLight(0xb7ccff, 0.85);
    rimLight.position.set(5, 4.5, 4.5);
    scene.add(rimLight);

    // Transparent shadow-receiving ground plane at y = 0 (aligned with drawing paper)
    const shadowPlaneGeo = new THREE.PlaneGeometry(24, 24);
    shadowPlaneGeo.rotateX(-Math.PI / 2);
    const shadowPlaneMat = new THREE.ShadowMaterial({ opacity: 0.24 });
    const shadowPlane = new THREE.Mesh(shadowPlaneGeo, shadowPlaneMat);
    shadowPlane.position.y = 0;
    shadowPlane.receiveShadow = true;
    scene.add(shadowPlane);

    // Soft contact shadow decal directly beneath pencil tip (works on all GPUs + software GL)
    const contactShadowTex = createContactShadowTexture();
    const contactShadowGeo = new THREE.PlaneGeometry(0.45, 0.45);
    contactShadowGeo.rotateX(-Math.PI / 2);
    const contactShadowMat = new THREE.MeshBasicMaterial({
      map: contactShadowTex,
      transparent: true,
      depthWrite: false,
      opacity: 0.45,
    });
    const contactShadowMesh = new THREE.Mesh(contactShadowGeo, contactShadowMat);
    contactShadowMesh.position.set(0, 0.004, 0);
    scene.add(contactShadowMesh);

    // =========================================================================
    // COMPOSITE 6-PART PROCEDURAL 3D GRAPHITE PENCIL (Pivoted at tip = 0,0,0)
    // =========================================================================
    const pencilRoot = new THREE.Group();
    const pencilTiltGroup = new THREE.Group();
    pencilRoot.add(pencilTiltGroup);
    scene.add(pencilRoot);

    const maxAniso = renderer.capabilities.getMaxAnisotropy();

    // 1. Sharpened Graphite Lead Tip (height 0.20 from y=0.0 to y=0.20)
    const leadProfile = [
      new THREE.Vector2(0.0, 0.0),
      new THREE.Vector2(0.011, 0.015),
      new THREE.Vector2(0.044, 0.205),
      new THREE.Vector2(0.0, 0.205),
    ];
    const leadGeo = new THREE.LatheGeometry(leadProfile, 24);
    const leadMat = new THREE.MeshStandardMaterial({
      color: 0x202226,
      metalness: 0.48,
      roughness: 0.34,
    });
    const leadMesh = new THREE.Mesh(leadGeo, leadMat);
    leadMesh.castShadow = true;
    pencilTiltGroup.add(leadMesh);

    // 2. Exposed Shaved Cedar Wood Collar (y=0.195 to y=0.72)
    const woodTex = createCedarConeTexture();
    woodTex.anisotropy = maxAniso;
    const woodProfile = [
      new THREE.Vector2(0.042, 0.195),
      new THREE.Vector2(0.095, 0.44),
      new THREE.Vector2(0.142, 0.69),
      new THREE.Vector2(0.146, 0.725),
      new THREE.Vector2(0.0, 0.725),
    ];
    const woodGeo = new THREE.LatheGeometry(woodProfile, 24);
    const woodMat = new THREE.MeshStandardMaterial({
      map: woodTex,
      roughness: 0.76,
      metalness: 0.02,
    });
    const woodMesh = new THREE.Mesh(woodGeo, woodMat);
    woodMesh.castShadow = true;
    pencilTiltGroup.add(woodMesh);

    // 3. Hexagonal Lacquered Barrel (y=0.72 to y=3.92)
    const barrelLen = 3.2;
    const barrelGeo = new THREE.CylinderGeometry(0.15, 0.15, barrelLen, 6, 1);
    const barrelTex = createPencilBarrelTexture(
      '#1d2b53',
      '#283b72',
      'ZOYA  ART  •  2B  GRAPHITE'
    );
    barrelTex.anisotropy = maxAniso;
    const barrelMat = new THREE.MeshPhysicalMaterial({
      map: barrelTex,
      roughness: 0.3,
      metalness: 0.12,
      clearcoat: 0.72,
      clearcoatRoughness: 0.18,
    });
    const barrelMesh = new THREE.Mesh(barrelGeo, barrelMat);
    barrelMesh.position.y = 0.72 + barrelLen * 0.5;
    barrelMesh.castShadow = true;
    pencilTiltGroup.add(barrelMesh);

    // 4. Painted Crown Trim Ring (y=3.92 to y=4.04)
    const crownGeo = new THREE.CylinderGeometry(0.152, 0.152, 0.12, 24);
    const crownMat = new THREE.MeshStandardMaterial({
      color: 0xd4af37,
      metalness: 0.78,
      roughness: 0.25,
    });
    const crownMesh = new THREE.Mesh(crownGeo, crownMat);
    crownMesh.position.y = 3.98;
    crownMesh.castShadow = true;
    pencilTiltGroup.add(crownMesh);

    // 5. Crimped Brass Ferrule (y=4.04 to y=4.44)
    const ferruleProfile = [
      new THREE.Vector2(0.15, 4.04),
      new THREE.Vector2(0.156, 4.07),
      new THREE.Vector2(0.146, 4.10),
      new THREE.Vector2(0.156, 4.14),
      new THREE.Vector2(0.148, 4.18),
      new THREE.Vector2(0.153, 4.28),
      new THREE.Vector2(0.146, 4.33),
      new THREE.Vector2(0.156, 4.37),
      new THREE.Vector2(0.146, 4.41),
      new THREE.Vector2(0.15, 4.44),
      new THREE.Vector2(0.0, 4.44),
    ];
    const ferruleGeo = new THREE.LatheGeometry(ferruleProfile, 28);
    const ferruleMat = new THREE.MeshStandardMaterial({
      color: 0xd8b45c,
      metalness: 0.92,
      roughness: 0.22,
    });
    const ferruleMesh = new THREE.Mesh(ferruleGeo, ferruleMat);
    ferruleMesh.castShadow = true;
    pencilTiltGroup.add(ferruleMesh);

    // 6. Matte Coral-Pink Rubber Eraser (y=4.44 to y=4.74)
    const eraserProfile = [
      new THREE.Vector2(0.0, 4.44),
      new THREE.Vector2(0.138, 4.44),
      new THREE.Vector2(0.138, 4.65),
      new THREE.Vector2(0.12, 4.71),
      new THREE.Vector2(0.075, 4.745),
      new THREE.Vector2(0.0, 4.755),
    ];
    const eraserGeo = new THREE.LatheGeometry(eraserProfile, 24);
    const eraserMat = new THREE.MeshStandardMaterial({
      color: 0xe3848e,
      roughness: 0.88,
      metalness: 0.0,
    });
    const eraserMesh = new THREE.Mesh(eraserGeo, eraserMat);
    eraserMesh.castShadow = true;
    pencilTiltGroup.add(eraserMesh);

    // Subtle style-reactive barrel tint update helper
    let appliedStyle = '';
    const syncStyleTint = (st: string) => {
      if (st === appliedStyle) return;
      appliedStyle = st;
      if (st === 'fine-line') {
        _tmpColor.setHex(0x88b4d8); // cool technical pencil tint
      } else if (st === 'detailed-3d') {
        _tmpColor.setHex(0xc8a468); // warm amber cedar artist pencil
      } else if (st === 'shaded-portrait') {
        _tmpColor.setHex(0x6e6a7a); // deep charcoal 6B look
      } else {
        _tmpColor.setHex(0xffffff); // classic cobalt-indigo studio 2B
      }
      barrelMat.color.copy(_tmpColor);
    };
    syncStyleTint(styleRef.current);

    if (!isSoftwareGl) {
      renderer.compile(scene, camera);
    }

    // Current interpolated kinematics state (pre-allocated scalars)
    let curX = 0;
    let curZ = 0;
    let curLift = 0.25;
    let curTiltX = 0.56;
    let curTiltZ = -0.58;
    let curSpinY = 0.35;
    let stageW = width;
    let stageH = height;

    const updateSize = () => {
      if (!container) return;
      const w = Math.max(1, container.clientWidth);
      const h = Math.max(1, container.clientHeight);
      if (w !== stageW || h !== stageH) {
        stageW = w;
        stageH = h;
        camera.aspect = w / h;
        camera.updateProjectionMatrix();
        renderer.setSize(w, h);
      }
    };

    const resizeObs = new ResizeObserver(() => updateSize());
    resizeObs.observe(container);

    // Animation loop with software WebGL pacing when needed
    let frameId = 0;
    let disposed = false;
    let lastTime = performance.now();

    function afterDraw(cb: () => void) {
      const gl = renderer.getContext() as WebGL2RenderingContext;
      if (!gl || typeof gl.fenceSync !== 'function') {
        frameId = window.setTimeout(cb, 80);
        return;
      }
      const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
      gl.flush();
      const poll = () => {
        if (disposed) {
          if (sync) gl.deleteSync(sync);
          return;
        }
        const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
        if (state === gl.UNSIGNALED) {
          frameId = window.setTimeout(poll, 5);
        } else {
          if (sync) gl.deleteSync(sync);
          frameId = window.setTimeout(cb, 80);
        }
      };
      frameId = window.setTimeout(poll, 5);
    }

    function tick() {
      if (disposed) return;
      const now = performance.now();
      const delta = Math.min(0.08, Math.max(0.001, (now - lastTime) / 1000));
      lastTime = now;

      syncStyleTint(styleRef.current);

      const paperEl = paperElementRef.current;
      const target = targetRef.current;

      const visH = 2 * camY * Math.tan(THREE.MathUtils.degToRad(fovDeg * 0.5));
      const visW = visH * (stageW / Math.max(1, stageH));

      let targetWorldX = 0;
      let targetWorldZ = 0;
      let targetLift = 0.3;

      if (paperEl && container) {
        const sRect = container.getBoundingClientRect();
        const pRect = paperEl.getBoundingClientRect();
        if (sRect.width > 0 && sRect.height > 0 && pRect.width > 0 && pRect.height > 0) {
          const sx = (pRect.left - sRect.left) + target.normX * pRect.width;
          const sy = (pRect.top - sRect.top) + target.normY * pRect.height;
          const u = sx / sRect.width - 0.5;
          const v = sy / sRect.height - 0.5;
          targetWorldX = u * visW;
          targetWorldZ = v * visH;
        }
      }

      if (target.isComplete) {
        // Rest gracefully near bottom-right margin of paper
        if (paperEl && container) {
          const sRect = container.getBoundingClientRect();
          const pRect = paperEl.getBoundingClientRect();
          if (sRect.width > 0 && sRect.height > 0) {
            const restSx = (pRect.right - sRect.left) - 18;
            const restSy = (pRect.bottom - sRect.top) - 18;
            targetWorldX = (restSx / sRect.width - 0.5) * visW;
            targetWorldZ = (restSy / sRect.height - 0.5) * visH;
          }
        }
        targetLift = 0.04;
      } else if (!target.isActive) {
        targetLift = 0.35;
      } else {
        targetLift = target.isTouching ? 0.0 : 0.32;
      }

      // Smooth frame-rate independent damping for natural artist wrist weight
      const posLambda = target.isTouching ? 28 : 16;
      curX = THREE.MathUtils.damp(curX, targetWorldX, posLambda, delta);
      curZ = THREE.MathUtils.damp(curZ, targetWorldZ, posLambda, delta);
      curLift = THREE.MathUtils.damp(curLift, targetLift, 18, delta);

      // Subtle hand tilt variation matching stroke direction & shading pressure
      const dirBiasX = Math.sin(target.strokeAngleRad) * 0.06;
      const dirBiasZ = Math.cos(target.strokeAngleRad) * 0.06;
      const handWave = target.isTouching ? Math.sin(now * 0.014) * 0.018 : 0;

      const desiredTiltX = target.isComplete
        ? 1.48 // almost flat resting on paper edge
        : 0.54 + dirBiasX + handWave;
      const desiredTiltZ = target.isComplete
        ? -0.22
        : -0.58 + dirBiasZ - handWave * 0.6;
      const desiredSpinY = target.isComplete
        ? 0.45
        : target.stage === 'shading' || target.stage === 'shadows'
        ? 0.52
        : 0.25;

      curTiltX = THREE.MathUtils.damp(curTiltX, desiredTiltX, 10, delta);
      curTiltZ = THREE.MathUtils.damp(curTiltZ, desiredTiltZ, 10, delta);
      curSpinY = THREE.MathUtils.damp(curSpinY, desiredSpinY, 6, delta);

      pencilRoot.position.set(curX, curLift, curZ);
      pencilTiltGroup.rotation.set(curTiltX, curSpinY, curTiltZ);

      // Contact shadow scales & softens naturally as pencil lifts off paper
      const liftRatio = Math.min(1, curLift / 0.35);
      contactShadowMesh.position.set(curX + liftRatio * 0.08, 0.004, curZ + liftRatio * 0.06);
      contactShadowMesh.scale.setScalar(1.0 + liftRatio * 0.9);
      contactShadowMat.opacity = target.isComplete
        ? 0.28
        : 0.46 * (1 - liftRatio * 0.72);

      renderer.render(scene, camera);

      if (isSoftwareGl) {
        afterDraw(tick);
      } else {
        frameId = requestAnimationFrame(tick);
      }
    }

    frameId = requestAnimationFrame(tick);

    return () => {
      disposed = true;
      cancelAnimationFrame(frameId);
      clearTimeout(frameId);
      resizeObs.disconnect();

      leadGeo.dispose();
      leadMat.dispose();
      woodGeo.dispose();
      woodMat.dispose();
      woodTex.dispose();
      barrelGeo.dispose();
      barrelMat.dispose();
      barrelTex.dispose();
      crownGeo.dispose();
      crownMat.dispose();
      ferruleGeo.dispose();
      ferruleMat.dispose();
      eraserGeo.dispose();
      eraserMat.dispose();
      shadowPlaneGeo.dispose();
      shadowPlaneMat.dispose();
      contactShadowGeo.dispose();
      contactShadowMat.dispose();
      contactShadowTex.dispose();
      envTex.dispose();
      renderer.dispose();

      if (renderer.domElement.parentElement === container) {
        container.removeChild(renderer.domElement);
      }
    };
  }, [paperElementRef, targetRef]);

  return (
    <div
      ref={mountRef}
      data-testid="pencil-3d-webgl-stage"
      className="pointer-events-none absolute inset-0 z-20 overflow-visible"
      aria-hidden="true"
    />
  );
};
