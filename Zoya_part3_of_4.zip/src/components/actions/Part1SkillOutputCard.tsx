import React, { useEffect, useRef, useState } from 'react';
import {
  Code2,
  Download,
  Eye,
  Palette,
  Sparkles,
  FileText,
  Copy,
  Check,
  KeyRound,
  ExternalLink,
  AlertTriangle,
  Layers,
  Megaphone,
  GitBranch,
  Plug,
} from 'lucide-react';
import {
  Part1SkillOutput,
  CanvasDesignSkillPayload,
} from '../../services/zoyaSkillsPart1';
import {
  BRAND_PALETTE_PRESETS,
  BrandPresetId,
  getBrandGuidelinesConfig,
  saveBrandGuidelinesConfig,
} from '../../services/toolApiKeysConfig';

interface Part1SkillOutputCardProps {
  output: Part1SkillOutput;
  onOpenToolApiKeys?: () => void;
}

export const Part1SkillOutputCard: React.FC<Part1SkillOutputCardProps> = ({
  output,
  onOpenToolApiKeys,
}) => {
  const [artifactTab, setArtifactTab] = useState<'preview' | 'code'>('preview');
  const [showPhilosophy, setShowPhilosophy] = useState<boolean>(false);
  const [copiedMd, setCopiedMd] = useState<boolean>(false);
  const [activeBrandPresetId, setActiveBrandPresetId] = useState<BrandPresetId>(
    () => getBrandGuidelinesConfig().presetId
  );
  const [brandEnabled, setBrandEnabled] = useState<boolean>(
    () => getBrandGuidelinesConfig().enabled
  );

  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Draw the high-craft museum poster when output.kind === 'canvas-design'
  useEffect(() => {
    if (output.kind !== 'canvas-design') return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    drawPosterOnCanvas(ctx, canvas.width, canvas.height, output);
  }, [output]);

  const handleDownloadText = (filename: string, content: string, mime = 'text/markdown') => {
    const blob = new Blob([content], { type: `${mime};charset=utf-8` });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleCopyText = (text: string) => {
    try {
      navigator.clipboard.writeText(text);
      setCopiedMd(true);
      setTimeout(() => setCopiedMd(false), 1800);
    } catch {}
  };

  const handleDownloadCanvasPng = (title: string) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const dataUrl = canvas.toDataURL('image/png');
    const a = document.createElement('a');
    a.href = dataUrl;
    a.download = `${title.toLowerCase().replace(/[^a-z0-9]+/g, '-') || 'zoya-poster'}.png`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  // ==========================================================================
  // 1. ARTIFACTS BUILDER CARD
  // ==========================================================================
  if (output.kind === 'artifacts-builder') {
    return (
      <div className="mt-3 rounded-2xl border border-purple-500/40 bg-[#0d0c20] overflow-hidden shadow-xl">
        <div className="px-3.5 py-2.5 bg-[#151332] border-b border-purple-500/30 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2 min-w-0">
            <Layers className="w-4 h-4 text-amber-400 shrink-0" />
            <span className="text-xs font-bold text-white truncate">
              {output.title}
            </span>
            <span className="text-[10px] px-2 py-0.5 rounded-md bg-purple-950/90 border border-purple-500/30 text-purple-200">
              {output.brandApplied}
            </span>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => setArtifactTab('preview')}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-medium flex items-center gap-1 cursor-pointer transition-colors ${
                artifactTab === 'preview'
                  ? 'bg-purple-600 text-white'
                  : 'bg-slate-900 text-slate-300 hover:text-white'
              }`}
            >
              <Eye className="w-3 h-3" />
              <span>Preview</span>
            </button>
            <button
              type="button"
              onClick={() => setArtifactTab('code')}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-medium flex items-center gap-1 cursor-pointer transition-colors ${
                artifactTab === 'code'
                  ? 'bg-purple-600 text-white'
                  : 'bg-slate-900 text-slate-300 hover:text-white'
              }`}
            >
              <Code2 className="w-3 h-3" />
              <span>HTML</span>
            </button>
            <button
              type="button"
              onClick={() =>
                handleDownloadText(
                  `${output.title.toLowerCase().replace(/[^a-z0-9]+/g, '-')}.html`,
                  output.htmlCode,
                  'text/html'
                )
              }
              className="px-2.5 py-1 rounded-lg text-[11px] font-medium bg-emerald-600/90 hover:bg-emerald-500 text-white flex items-center gap-1 cursor-pointer transition-colors"
              title="Download Single-File HTML Artifact"
            >
              <Download className="w-3 h-3" />
              <span>.HTML</span>
            </button>
          </div>
        </div>

        {artifactTab === 'preview' ? (
          <div className="w-full bg-[#faf9f5]">
            <iframe
              title={output.title}
              srcDoc={output.htmlCode}
              sandbox="allow-scripts"
              className="w-full h-[340px] border-0"
            />
          </div>
        ) : (
          <pre className="p-3 text-[11px] font-mono text-emerald-300 bg-slate-950 overflow-x-auto max-h-[300px]">
            {output.htmlCode}
          </pre>
        )}

        <div className="px-3.5 py-2 bg-[#111026] border-t border-purple-500/20 flex flex-wrap gap-1.5">
          {output.features.map((f, i) => (
            <span
              key={i}
              className="text-[10px] text-slate-300 bg-slate-900/90 border border-slate-800 px-2 py-0.5 rounded-md"
            >
              • {f}
            </span>
          ))}
        </div>
      </div>
    );
  }

  // ==========================================================================
  // 2. BRAND GUIDELINES CARD
  // ==========================================================================
  if (output.kind === 'brand-guidelines') {
    const activePreset =
      BRAND_PALETTE_PRESETS.find((p) => p.id === activeBrandPresetId) ||
      output.preset;

    const handleSelectPreset = (id: BrandPresetId) => {
      setActiveBrandPresetId(id);
      saveBrandGuidelinesConfig({ enabled: brandEnabled, presetId: id });
    };

    const handleToggleEnabled = () => {
      const next = !brandEnabled;
      setBrandEnabled(next);
      saveBrandGuidelinesConfig({ enabled: next, presetId: activeBrandPresetId });
    };

    const swatches = [
      { label: 'Dark Ink', hex: activePreset.colors.dark },
      { label: 'Warm Light', hex: activePreset.colors.light },
      { label: 'Primary Accent', hex: activePreset.colors.accentPrimary },
      { label: 'Secondary Blue', hex: activePreset.colors.accentSecondary },
      { label: 'Botanical Green', hex: activePreset.colors.accentTertiary },
      { label: 'Mid Gray', hex: activePreset.colors.midGray },
    ];

    return (
      <div className="mt-3 rounded-2xl border border-amber-500/40 bg-[#121124] p-3.5 space-y-3 shadow-xl">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Palette className="w-4 h-4 text-amber-400" />
            <span className="text-xs font-bold text-white">
              Brand Guidelines ({activePreset.name})
            </span>
          </div>
          <button
            type="button"
            onClick={handleToggleEnabled}
            className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold cursor-pointer transition-colors ${
              brandEnabled
                ? 'bg-emerald-600/90 text-white'
                : 'bg-slate-800 text-slate-400'
            }`}
          >
            {brandEnabled ? 'Active on All Designs' : 'Paused'}
          </button>
        </div>

        {/* Swatches Grid */}
        <div className="grid grid-cols-3 gap-2">
          {swatches.map((sw) => (
            <div
              key={sw.label}
              className="p-2 rounded-xl bg-slate-950/80 border border-slate-800 flex items-center gap-2"
            >
              <div
                className="w-6 h-6 rounded-lg border border-white/20 shrink-0"
                style={{ backgroundColor: sw.hex }}
              />
              <div className="min-w-0">
                <div className="text-[10px] font-semibold text-slate-200 truncate">
                  {sw.label}
                </div>
                <div className="text-[9.5px] font-mono text-slate-400 uppercase">
                  {sw.hex}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Typography Pairing */}
        <div className="p-2.5 rounded-xl bg-slate-950/70 border border-slate-800 text-[11px] text-slate-300 flex items-center justify-between">
          <span>
            <strong>Headings:</strong> {activePreset.typography.headingFont.split(',')[0]}
          </span>
          <span>
            <strong>Body:</strong> {activePreset.typography.bodyFont.split(',')[0]}
          </span>
        </div>

        {/* Switch Brand Style Preset */}
        <div className="flex flex-wrap gap-1.5 pt-1">
          {BRAND_PALETTE_PRESETS.map((p) => (
            <button
              key={p.id}
              type="button"
              onClick={() => handleSelectPreset(p.id)}
              className={`px-2.5 py-1 rounded-lg text-[10.5px] font-medium border cursor-pointer transition-colors ${
                activeBrandPresetId === p.id
                  ? 'bg-purple-600/40 border-purple-400 text-white'
                  : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              {p.name}
            </button>
          ))}
        </div>
      </div>
    );
  }

  // ==========================================================================
  // 3. CANVAS DESIGN CARD (Philosophy Manifesto + Downloadable HTML5 Poster)
  // ==========================================================================
  if (output.kind === 'canvas-design') {
    return (
      <div className="mt-3 rounded-2xl border border-pink-500/40 bg-[#100e22] overflow-hidden shadow-xl">
        <div className="px-3.5 py-2.5 bg-[#191636] border-b border-pink-500/30 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-pink-400" />
            <span className="text-xs font-bold text-white">
              {output.movementName} — Poster Canvas
            </span>
          </div>
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => setShowPhilosophy((prev) => !prev)}
              className="px-2.5 py-1 rounded-lg text-[11px] font-medium bg-slate-900 hover:bg-slate-800 text-slate-200 flex items-center gap-1 cursor-pointer"
            >
              <FileText className="w-3 h-3 text-pink-400" />
              <span>{showPhilosophy ? 'Hide Philosophy' : 'Philosophy .MD'}</span>
            </button>
            <button
              type="button"
              onClick={() => handleDownloadCanvasPng(output.posterTitle)}
              className="px-2.5 py-1 rounded-lg text-[11px] font-semibold bg-pink-600 hover:bg-pink-500 text-white flex items-center gap-1 cursor-pointer"
            >
              <Download className="w-3 h-3" />
              <span>Download .PNG</span>
            </button>
          </div>
        </div>

        {showPhilosophy && (
          <div className="p-3.5 bg-slate-950/90 border-b border-slate-800 text-[11px] text-slate-300 space-y-2 max-h-[220px] overflow-y-auto">
            <div className="flex items-center justify-between">
              <span className="text-[10px] uppercase tracking-wider text-pink-400 font-bold">
                Step 1: Aesthetic Philosophy Manifesto (.md)
              </span>
              <button
                type="button"
                onClick={() =>
                  handleDownloadText(
                    `${output.movementName.toLowerCase().replace(/\s+/g, '-')}-philosophy.md`,
                    output.philosophyMarkdown
                  )
                }
                className="text-[10px] text-sky-400 hover:underline flex items-center gap-1 cursor-pointer"
              >
                <Download className="w-3 h-3" /> Save .MD
              </button>
            </div>
            <pre className="whitespace-pre-wrap font-sans leading-relaxed">
              {output.philosophyMarkdown}
            </pre>
          </div>
        )}

        {/* High-Craft Poster Canvas Render */}
        <div className="p-3 bg-slate-950 flex flex-col items-center">
          <canvas
            ref={canvasRef}
            width={600}
            height={800}
            className="w-full max-w-[320px] h-auto rounded-lg shadow-2xl border border-white/15"
          />
        </div>
      </div>
    );
  }

  // ==========================================================================
  // 4. CHANGELOG GENERATOR CARD
  // ==========================================================================
  if (output.kind === 'changelog-generator') {
    return (
      <div className="mt-3 rounded-2xl border border-emerald-500/40 bg-[#0e1520] p-3.5 space-y-3 shadow-xl">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-2.5">
          <div className="flex items-center gap-2">
            <GitBranch className="w-4 h-4 text-emerald-400" />
            <div>
              <div className="text-xs font-bold text-white">
                {output.versionTitle}
              </div>
              <div className="text-[10px] text-slate-400">
                {output.releaseDate} · Filtered {output.filteredOutCount} internal noise commits
              </div>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => handleCopyText(output.markdownText)}
              className="px-2.5 py-1 rounded-lg text-[11px] font-medium bg-slate-900 hover:bg-slate-800 text-slate-200 flex items-center gap-1 cursor-pointer"
            >
              {copiedMd ? (
                <>
                  <Check className="w-3 h-3 text-emerald-400" />
                  <span>Copied</span>
                </>
              ) : (
                <>
                  <Copy className="w-3 h-3" />
                  <span>Copy MD</span>
                </>
              )}
            </button>
            <button
              type="button"
              onClick={() => handleDownloadText('CHANGELOG.md', output.markdownText)}
              className="px-2.5 py-1 rounded-lg text-[11px] font-semibold bg-emerald-600 hover:bg-emerald-500 text-white flex items-center gap-1 cursor-pointer"
            >
              <Download className="w-3 h-3" />
              <span>CHANGELOG.md</span>
            </button>
          </div>
        </div>

        <div className="space-y-2.5">
          {output.sections.map((sec) => (
            <div
              key={sec.category}
              className="p-2.5 rounded-xl bg-slate-950/75 border border-slate-800/90 space-y-1.5"
            >
              <div className="text-[11px] font-bold text-emerald-300 uppercase tracking-wider">
                {sec.category}
              </div>
              <ul className="space-y-1 text-xs text-slate-200 list-disc list-inside">
                {sec.items.map((item, i) => (
                  <li key={i} className="leading-relaxed">
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    );
  }

  // ==========================================================================
  // 5. COMPETITIVE ADS EXTRACTOR CARD
  // ==========================================================================
  if (output.kind === 'competitive-ads-extractor') {
    return (
      <div className="mt-3 rounded-2xl border border-sky-500/40 bg-[#0d1424] p-3.5 space-y-3 shadow-xl">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-2.5">
          <div className="flex items-center gap-2">
            <Megaphone className="w-4 h-4 text-sky-400" />
            <div>
              <div className="text-xs font-bold text-white">
                Competitive Ad Intelligence
              </div>
              <div className="text-[10px] text-slate-400 truncate max-w-[210px]">
                {output.competitorSubject}
              </div>
            </div>
          </div>

          <button
            type="button"
            onClick={() =>
              handleDownloadText('competitor-ads-analysis.md', output.markdownReport)
            }
            className="px-2.5 py-1 rounded-lg text-[11px] font-semibold bg-sky-600 hover:bg-sky-500 text-white flex items-center gap-1 cursor-pointer"
          >
            <Download className="w-3 h-3" />
            <span>Report .MD</span>
          </button>
        </div>

        {/* Key Problems Highlighted */}
        <div className="space-y-1.5">
          <div className="text-[10.5px] font-bold uppercase tracking-wider text-sky-300">
            Key Problems & Pain Hooks
          </div>
          {output.problemsHighlighted.map((p, idx) => (
            <div
              key={idx}
              className="p-2.5 rounded-xl bg-slate-950/80 border border-slate-800 space-y-1"
            >
              <div className="text-xs font-semibold text-white">{p.problem}</div>
              <div className="text-[11px] text-amber-300 italic">{p.copyHook}</div>
              <div className="text-[10.5px] text-slate-400">
                Why it works: {p.whyItWorks}
              </div>
            </div>
          ))}
        </div>

        {/* Creative Patterns & Copy Formulas */}
        <div className="grid grid-cols-1 gap-2">
          {output.creativePatterns.slice(0, 2).map((c, idx) => (
            <div
              key={idx}
              className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800/80"
            >
              <div className="text-[11px] font-bold text-purple-300">
                {c.patternName}
              </div>
              <div className="text-[11px] text-slate-300 mt-0.5">
                {c.formatStructure}
              </div>
            </div>
          ))}
        </div>

        {/* Recommendations */}
        <div className="p-2.5 rounded-xl bg-emerald-950/30 border border-emerald-500/30 space-y-1">
          <div className="text-[10.5px] font-bold uppercase tracking-wider text-emerald-300">
            Actionable Recommendations for Your Ads
          </div>
          <ul className="text-[11px] text-slate-200 space-y-1 list-disc list-inside">
            {output.recommendations.map((r, idx) => (
              <li key={idx}>{r}</li>
            ))}
          </ul>
        </div>
      </div>
    );
  }

  // ==========================================================================
  // 6. CONNECT APPS (COMPOSIO) CARD
  // ==========================================================================
  if (output.kind === 'connect-apps') {
    return (
      <div
        className={`mt-3 rounded-2xl border p-3.5 space-y-3 shadow-xl ${
          output.hasComposioKey
            ? 'border-indigo-500/40 bg-[#101229]'
            : 'border-amber-500/50 bg-[#1c1410]'
        }`}
      >
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Plug
              className={`w-4 h-4 ${
                output.hasComposioKey ? 'text-indigo-400' : 'text-amber-400'
              }`}
            />
            <span className="text-xs font-bold text-white">
              Connect Apps · {output.detectedApp}
            </span>
          </div>
          <span
            className={`text-[10px] px-2 py-0.5 rounded-full font-semibold ${
              output.hasComposioKey
                ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/40'
                : 'bg-amber-950 text-amber-300 border border-amber-500/40'
            }`}
          >
            {output.hasComposioKey ? 'Key Configured' : 'API Key Required'}
          </span>
        </div>

        {!output.hasComposioKey ? (
          <div className="p-3 rounded-xl bg-black/40 border border-amber-500/30 space-y-2.5">
            <div className="flex items-start gap-2 text-xs text-amber-200">
              <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              <span>
                To connect external apps ({output.detectedApp}) via Composio Tool Router, please enter your{' '}
                <strong>Composio API Key</strong> in{' '}
                <strong>Settings → Tool API Keys</strong>.
              </span>
            </div>
            {onOpenToolApiKeys && (
              <button
                type="button"
                onClick={onOpenToolApiKeys}
                className="w-full py-2 px-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
              >
                <KeyRound className="w-3.5 h-3.5" />
                <span>Open Settings → Tool API Keys</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        ) : (
          <div className="space-y-2.5">
            <div className="p-2.5 rounded-xl bg-slate-950/80 border border-slate-800 space-y-1 text-[11px]">
              <div className="flex justify-between text-slate-400">
                <span>Composio Key:</span>
                <span className="font-mono text-emerald-300">
                  {output.maskedKeyPreview}
                </span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Tool Router Action:</span>
                <span className="font-mono text-indigo-300">
                  {output.detectedAction}
                </span>
              </div>
              {Object.entries(output.actionParameters).map(([k, v]) => (
                <div key={k} className="flex justify-between gap-2 text-slate-300">
                  <span className="text-slate-500 shrink-0">{k}:</span>
                  <span className="truncate text-right">{v}</span>
                </div>
              ))}
            </div>

            {output.directIntentUrl && (
              <a
                href={output.directIntentUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-2 px-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs flex items-center justify-center gap-1.5 transition-colors no-underline cursor-pointer"
              >
                <span>{output.fallbackActionLabel || 'Launch Direct Action'}</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            )}

            <div className="p-2.5 rounded-xl bg-indigo-950/40 border border-indigo-500/30 text-[11px] text-indigo-200 leading-relaxed">
              <strong>Coming Soon / Live OAuth Preview Notice:</strong> Your Composio API Key is saved and the action payload is structured. Executing real actions on external accounts requires a live Composio MCP / OAuth redirect backend, so no external email or Slack message was sent.
            </div>
          </div>
        )}

        {!output.hasComposioKey && output.directIntentUrl && (
          <a
            href={output.directIntentUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-100 font-semibold text-xs flex items-center justify-center gap-1.5 transition-colors no-underline cursor-pointer border border-slate-700"
          >
            <span>{output.fallbackActionLabel || 'Launch Direct Action'} (No API Key Required)</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        )}
      </div>
    );
  }

  return null;
};

/**
 * Renders a high-craft Swiss / Museum-grade poster on HTML5 Canvas
 * following the 90% visual design / 10% contextual typography rule from canvas-design.
 */
function drawPosterOnCanvas(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  spec: CanvasDesignSkillPayload
) {
  const { bg, fg, accent1, accent2, accent3, muted } = spec.palette;

  // 1. Background fill
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, w, h);

  // 2. Outer architectural frame & Swiss modular grid hairlines
  const margin = 36;
  ctx.strokeStyle = fg;
  ctx.lineWidth = 1.5;
  ctx.strokeRect(margin, margin, w - margin * 2, h - margin * 2);

  // Subtle internal grid lines
  ctx.strokeStyle = muted;
  ctx.lineWidth = 0.6;
  ctx.globalAlpha = 0.45;
  const colW = (w - margin * 2) / 4;
  for (let i = 1; i < 4; i++) {
    ctx.beginPath();
    ctx.moveTo(margin + colW * i, margin);
    ctx.lineTo(margin + colW * i, h - margin);
    ctx.stroke();
  }
  ctx.beginPath();
  ctx.moveTo(margin, h * 0.68);
  ctx.lineTo(w - margin, h * 0.68);
  ctx.stroke();
  ctx.globalAlpha = 1;

  // 3. Primary Visual Composition (90% visual artwork)
  ctx.save();
  ctx.beginPath();
  ctx.rect(margin + 8, margin + 42, w - (margin + 8) * 2, h * 0.68 - margin - 50);
  ctx.clip();

  if (spec.compositionStyle === 'swiss_brutalist') {
    // Bold asymmetric architectural blocks
    ctx.fillStyle = fg;
    ctx.fillRect(margin + 24, margin + 60, 240, 380);

    ctx.fillStyle = accent1;
    ctx.beginPath();
    ctx.arc(w * 0.62, h * 0.36, 135, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = accent2;
    ctx.fillRect(w * 0.48, h * 0.42, 220, 110);

    // Repeating geometric rhythm bars
    ctx.fillStyle = accent3;
    for (let i = 0; i < 9; i++) {
      ctx.fillRect(margin + 44 + i * 22, margin + 84, 10, 320);
    }
  } else if (spec.compositionStyle === 'kinetic_construct') {
    // Concentric harmonic waves & diagonal constructivist beam
    ctx.fillStyle = fg;
    ctx.fillRect(margin + 16, margin + 52, w - (margin + 16) * 2, 440);

    for (let r = 210; r >= 30; r -= 26) {
      ctx.beginPath();
      ctx.arc(w / 2, h * 0.36, r, 0, Math.PI * 2);
      ctx.strokeStyle = r % 52 === 0 ? accent1 : r % 39 === 0 ? accent2 : accent3;
      ctx.lineWidth = 5;
      ctx.stroke();
    }

    ctx.fillStyle = accent1;
    ctx.beginPath();
    ctx.arc(w / 2, h * 0.36, 34, 0, Math.PI * 2);
    ctx.fill();
  } else {
    // Chromatic Silence / Analog Meditation — poised geometric balance
    ctx.fillStyle = accent2;
    ctx.fillRect(margin + 28, margin + 66, w - (margin + 28) * 2, 210);

    ctx.fillStyle = accent1;
    ctx.beginPath();
    ctx.arc(w / 2, margin + 276, 118, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = fg;
    ctx.beginPath();
    ctx.arc(w / 2, margin + 276, 54, 0, Math.PI, false);
    ctx.fill();

    // Precision calibration lines
    ctx.strokeStyle = accent3;
    ctx.lineWidth = 2;
    for (let y = margin + 320; y <= margin + 450; y += 16) {
      ctx.beginPath();
      ctx.moveTo(margin + 60, y);
      ctx.lineTo(w - margin - 60, y);
      ctx.stroke();
    }
  }
  ctx.restore();

  // 4. Top Archival Metadata Bar
  ctx.fillStyle = fg;
  ctx.font = '600 11px Poppins, Arial, sans-serif';
  ctx.fillText(`REF // ${spec.referenceCode}`, margin + 16, margin + 26);
  ctx.textAlign = 'right';
  ctx.fillText(`EDITION 01 · ${spec.dateStamp}`, w - margin - 16, margin + 26);
  ctx.textAlign = 'left';

  // 5. Lower-Third Typographic Hierarchy (Poppins + Lora)
  const textTop = h * 0.68 + 38;
  ctx.fillStyle = accent1;
  ctx.font = '700 11px Poppins, Arial, sans-serif';
  ctx.fillText(spec.posterSubtitle, margin + 20, textTop);

  ctx.fillStyle = fg;
  ctx.font = '700 28px Poppins, Arial, sans-serif';
  ctx.fillText(spec.posterTitle.slice(0, 22), margin + 20, textTop + 38);

  ctx.fillStyle = muted;
  ctx.font = 'italic 13px Lora, Georgia, serif';
  ctx.fillText(
    `Movement: ${spec.movementName} — Systematic Form, Chromatic Restraint & Spatial Harmony.`,
    margin + 20,
    textTop + 68
  );

  // Palette Swatch Strip at bottom-left
  const swatches = [fg, accent1, accent2, accent3, muted];
  swatches.forEach((hex, idx) => {
    ctx.fillStyle = hex;
    ctx.fillRect(margin + 20 + idx * 28, h - margin - 34, 20, 14);
  });

  // Registration crosshair at bottom-right
  const cx = w - margin - 34;
  const cy = h - margin - 27;
  ctx.strokeStyle = fg;
  ctx.lineWidth = 1.2;
  ctx.beginPath();
  ctx.arc(cx, cy, 8, 0, Math.PI * 2);
  ctx.moveTo(cx - 13, cy);
  ctx.lineTo(cx + 13, cy);
  ctx.moveTo(cx, cy - 13);
  ctx.lineTo(cx, cy + 13);
  ctx.stroke();
}
