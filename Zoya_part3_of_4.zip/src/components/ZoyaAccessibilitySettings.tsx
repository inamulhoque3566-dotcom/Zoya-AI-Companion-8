import React, { useState, useEffect } from 'react';
import {
  Smartphone,
  ShieldCheck,
  ShieldAlert,
  Play,
  ArrowUp,
  ArrowDown,
  Home,
  CornerUpLeft,
  Bell,
  Type,
  MousePointerClick,
  Eye,
  ExternalLink,
  RefreshCw,
  CheckCircle2,
  Lock,
  Unlock,
  Plus,
  Trash2,
  Search,
  AlertTriangle,
} from 'lucide-react';
import {
  androidAccessibility,
  AccessibilityBridgeStatus,
} from '../services/androidAccessibility';
import {
  runBankingShieldInstalledAppsAudit,
  addCustomBlockedPackage,
  removeCustomBlockedPackage,
  getCustomBlockedPackages,
  BankingShieldSelfTestReport,
} from '../services/bankingSafetyConfig';

interface ZoyaAccessibilitySettingsProps {
  mode: 'accessibility' | 'device_lock';
}

export const ZoyaAccessibilitySettings: React.FC<ZoyaAccessibilitySettingsProps> = ({ mode }) => {
  const [status, setStatus] = useState<any>({
    bridgeAvailable: false,
    serviceConnected: false,
    serviceEnabledInSettings: false,
    currentPackage: '',
    sdkInt: 34,
    lockScreenSupported: true,
    isDeviceLocked: false,
    isDeviceSecure: true,
  });
  const [actionFeedback, setActionFeedback] = useState<string>('');
  const [customText, setCustomText] = useState<string>('');
  const [customClickTarget, setCustomClickTarget] = useState<string>('');
  const [customAppName, setCustomAppName] = useState<string>('WhatsApp');
  const [screenSummary, setScreenSummary] = useState<any>(null);

  // Banking Shield Self-Test State (Round 5 Item 6)
  const [probeApps, setProbeApps] = useState<Array<{ packageName: string; appName: string }>>([]);
  const [shieldReport, setShieldReport] = useState<BankingShieldSelfTestReport>(() =>
    runBankingShieldInstalledAppsAudit([])
  );
  const [newPkgInput, setNewPkgInput] = useState<string>('');
  const [newAppLabelInput, setNewAppLabelInput] = useState<string>('');
  const [filterMode, setFilterMode] = useState<'all' | 'flagged' | 'blocked'>('all');
  const [customBlockedList, setCustomBlockedList] = useState<string[]>(() =>
    getCustomBlockedPackages()
  );

  const refreshStatus = () => {
    const s = androidAccessibility.getStatus();
    setStatus(s);
  };

  const refreshBankingShieldAudit = (
    extraList: Array<{ packageName: string; appName: string }> = probeApps
  ) => {
    setCustomBlockedList(getCustomBlockedPackages());
    setShieldReport(runBankingShieldInstalledAppsAudit(extraList));
  };

  useEffect(() => {
    refreshStatus();
    refreshBankingShieldAudit();
    const timer = setInterval(refreshStatus, 3000);
    return () => clearInterval(timer);
  }, []);

  const runAction = async (payload: any) => {
    setActionFeedback('निष्पादित किया जा रहा है...');
    const res = await androidAccessibility.executeAction(payload);
    setActionFeedback(res.message);
    if (payload.action === 'read_screen' && res.data) {
      setScreenSummary(res.data);
    }
    refreshStatus();
  };

  const handleAddPackageToBlocklist = (pkg: string) => {
    const clean = pkg.trim().toLowerCase();
    if (!clean) return;
    addCustomBlockedPackage(clean);
    refreshBankingShieldAudit();
    setActionFeedback(`Added "${clean}" to Banking Shield Blocklist.`);
  };

  const handleRemoveCustomPackage = (pkg: string) => {
    removeCustomBlockedPackage(pkg);
    refreshBankingShieldAudit();
    setActionFeedback(`Removed "${pkg}" from custom blocklist.`);
  };

  const handleTestOrAddCustomApp = (e: React.FormEvent) => {
    e.preventDefault();
    const pkg = newPkgInput.trim();
    const label = newAppLabelInput.trim() || pkg;
    if (!pkg) return;

    const updatedProbes = [{ packageName: pkg, appName: label }, ...probeApps];
    setProbeApps(updatedProbes);
    refreshBankingShieldAudit(updatedProbes);
    setNewPkgInput('');
    setNewAppLabelInput('');
  };

  const filteredApps = shieldReport.apps.filter((app) => {
    if (filterMode === 'flagged') return app.flaggedUnblockedFinancial;
    if (filterMode === 'blocked') return app.isBlocked;
    return true;
  });

  if (mode === 'device_lock') {
    return (
      <div className="space-y-4">
        {/* Device Lock & Keyguard Status Card */}
        <div className="p-4 rounded-2xl bg-slate-950/90 border border-indigo-500/30 space-y-3">
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-xl bg-indigo-500/15 border border-indigo-500/40 flex items-center justify-center text-indigo-400">
                <Lock className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-xs sm:text-sm font-bold text-white flex items-center gap-1.5">
                  <span>डिवाइस लॉक और अनलॉक नियंत्रण</span>
                </h4>
                <p className="text-[11px] text-slate-400">
                  Android 9+ Accessibility Lock & Official Keyguard Unlock
                </p>
              </div>
            </div>

            <button
              onClick={refreshStatus}
              className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 cursor-pointer"
              title="Refresh Lock Status"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
          </div>

          {/* Environment & Requirement Badges */}
          <div className="grid grid-cols-2 gap-2 pt-1">
            <div className="p-2.5 rounded-xl bg-slate-900/90 border border-slate-800">
              <span className="text-[10px] text-slate-400 block">Accessibility Service</span>
              <span
                className={`text-xs font-bold ${
                  status.serviceConnected ? 'text-emerald-400' : 'text-amber-300'
                }`}
              >
                {status.serviceConnected
                  ? 'सक्रिय (Connected)'
                  : status.bridgeAvailable
                  ? 'अक्षम (Enable in Settings)'
                  : 'Web Preview Simulation'}
              </span>
            </div>
            <div className="p-2.5 rounded-xl bg-slate-900/90 border border-slate-800">
              <span className="text-[10px] text-slate-400 block">Android API Support</span>
              <span
                className={`text-xs font-bold ${
                  status.lockScreenSupported !== false ? 'text-cyan-400' : 'text-rose-400'
                }`}
              >
                {status.lockScreenSupported !== false
                  ? `Supported (API ${status.sdkInt || 34} >= 28)`
                  : `Unsupported (API ${status.sdkInt} < 28)`}
              </span>
            </div>
          </div>

          {!status.serviceConnected && (
            <div className="p-2.5 rounded-xl bg-amber-950/30 border border-amber-500/30 text-[11px] text-amber-200/90 leading-relaxed">
              स्क्रीन लॉक करने के लिए <b>Zoya Accessibility Service</b> आवश्यक है। नीचे दिए गए बटन से एंड्रॉइड एक्सेसिबिलिटी सेटिंग्स खोलें और ज़ोया को ऑन करें।
            </div>
          )}

          <button
            onClick={() => {
              const opened = androidAccessibility.openAccessibilitySettings();
              if (!opened) {
                setActionFeedback(
                  'APK इंस्टॉल करने के बाद यह बटन सीधे Android Settings -> Accessibility खोलता है।'
                );
              }
            }}
            className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:brightness-110 text-white text-xs font-bold flex items-center justify-center gap-2 shadow-lg cursor-pointer transition-all active:scale-98"
          >
            <ExternalLink className="w-4 h-4" />
            <span>Open Android Accessibility Settings</span>
          </button>
        </div>

        {/* Immediate Lock & Unlock Action Buttons */}
        <div className="p-4 rounded-2xl bg-slate-950/90 border border-slate-800 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-200">
              त्वरित लॉक / अनलॉक परीक्षण (Quick Test)
            </span>
            <span className="text-[10px] text-indigo-400 font-mono">GLOBAL_ACTION_LOCK_SCREEN</span>
          </div>

          <div className="grid grid-cols-2 gap-2.5">
            <button
              onClick={() => runAction({ action: 'lock_device' })}
              className="py-3 px-3 rounded-xl bg-rose-950/50 hover:bg-rose-900/60 border border-rose-500/40 flex flex-col items-center gap-1.5 text-rose-200 cursor-pointer transition-all active:scale-95"
            >
              <Lock className="w-5 h-5 text-rose-400" />
              <span className="text-xs font-bold">Lock Screen Now</span>
              <span className="text-[10px] text-rose-300/70">फोन लॉक करो</span>
            </button>

            <button
              onClick={() => runAction({ action: 'unlock_device' })}
              className="py-3 px-3 rounded-xl bg-emerald-950/50 hover:bg-emerald-900/60 border border-emerald-500/40 flex flex-col items-center gap-1.5 text-emerald-200 cursor-pointer transition-all active:scale-95"
            >
              <Unlock className="w-5 h-5 text-emerald-400" />
              <span className="text-xs font-bold">Request Unlock</span>
              <span className="text-[10px] text-emerald-300/70">अनलॉक प्रॉम्प्ट खोलें</span>
            </button>
          </div>

          {actionFeedback && (
            <div className="p-2.5 rounded-xl bg-indigo-950/50 border border-indigo-500/30 flex items-center gap-2 text-xs text-indigo-200">
              <CheckCircle2 className="w-4 h-4 text-indigo-400 shrink-0" />
              <span className="truncate">{actionFeedback}</span>
            </div>
          )}
        </div>

        {/* Security & Biometric Policy Explanation */}
        <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800/80 space-y-2 text-[11px] text-slate-400 leading-relaxed">
          <div className="font-bold text-slate-200 flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Android OS सुरक्षा नीति (Security Architecture):</span>
          </div>
          <p>
            • <b>Screen Lock:</b> Android 9.0 (Pie, API 28+) पर <code>GLOBAL_ACTION_LOCK_SCREEN</code> के माध्यम से बिना किसी पासवर्ड के तुरंत स्क्रीन लॉक हो जाती है।
          </p>
          <p>
            • <b>Device Unlock:</b> Android सुरक्षा नियमों के अनुसार कोई भी ऐप बिना यूज़र के PIN/Pattern/Biometric के सुरक्षित लॉकस्क्रीन को बाईपास नहीं कर सकता। <b>"फ़ोन अनलॉक करो"</b> बोलने पर ज़ोया <code>KeyguardManager.requestDismissKeyguard()</code> और <code>FLAG_TURN_SCREEN_ON</code> के ज़रिए स्क्रीन जगाकर आधिकारिक अनलॉक संवाद खोलती है।
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Status Banner */}
      <div className="p-4 rounded-2xl bg-slate-950/90 border border-cyan-500/30 space-y-3">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div
              className={`w-10 h-10 rounded-xl flex items-center justify-center border ${
                status.serviceConnected
                  ? 'bg-emerald-500/15 border-emerald-500/40 text-emerald-400'
                  : 'bg-cyan-500/15 border-cyan-500/40 text-cyan-400'
              }`}
            >
              {status.serviceConnected ? (
                <ShieldCheck className="w-5 h-5" />
              ) : (
                <Smartphone className="w-5 h-5" />
              )}
            </div>
            <div>
              <h4 className="text-xs sm:text-sm font-bold text-white flex items-center gap-1.5">
                <span>Zoya Accessibility Service</span>
                <span
                  className={`px-2 py-0.5 text-[10px] rounded-full font-semibold ${
                    status.serviceConnected
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                      : status.bridgeAvailable
                      ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                      : 'bg-purple-500/20 text-purple-300 border border-purple-500/40'
                  }`}
                >
                  {status.serviceConnected
                    ? 'Connected (Native APK)'
                    : status.bridgeAvailable
                    ? 'Permission Required'
                    : 'Web Simulator Active'}
                </span>
              </h4>
              <p className="text-[11px] text-slate-400">
                {status.serviceConnected
                  ? 'ज़ोया आपके पूरे फ़ोन को आवाज़ से नियंत्रित करने के लिए तैयार है।'
                  : 'मोबाइल नियंत्रण, स्क्रॉल, टैप, टाइपिंग और किसी भी ऐप को खोलने की सुविधा।'}
              </p>
            </div>
          </div>

          <button
            onClick={refreshStatus}
            className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 cursor-pointer"
            title="Refresh Status"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>

        {/* Open Android Accessibility Settings Button */}
        <button
          onClick={() => {
            const opened = androidAccessibility.openAccessibilitySettings();
            if (!opened) {
              setActionFeedback(
                'APK इंस्टॉल करने के बाद यह बटन सीधे Android Settings -> Accessibility खोलता है।'
              );
            }
          }}
          className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-cyan-600 to-indigo-600 hover:brightness-110 text-white text-xs font-bold flex items-center justify-center gap-2 shadow-lg cursor-pointer transition-all active:scale-98"
        >
          <ExternalLink className="w-4 h-4" />
          <span>Open Android Accessibility Settings (मोबाइल सेटिंग्स खोलें)</span>
        </button>
      </div>

      {/* ===================================================================== */}
      {/* ITEM 6: BANKING SHIELD SELF-TEST SCREEN (RUNS ON PHONE & PREVIEW)     */}
      {/* ===================================================================== */}
      <div
        data-testid="banking-shield-selftest-panel"
        className="p-4 rounded-2xl bg-slate-950/95 border border-emerald-500/40 space-y-3"
      >
        <div className="flex items-start justify-between gap-2">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/15 border border-emerald-500/40 flex items-center justify-center text-emerald-400 shrink-0">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h4 className="text-xs sm:text-sm font-bold text-white">
                  Banking Shield Self-Test (फ़ोन ऐप सुरक्षा जांच)
                </h4>
                <span
                  className={`px-2 py-0.5 text-[10px] rounded-md font-mono font-bold ${
                    shieldReport.source === 'android_package_manager'
                      ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/40'
                      : 'bg-amber-950 text-amber-300 border border-amber-500/40'
                  }`}
                >
                  {shieldReport.source === 'android_package_manager'
                    ? 'LIVE PHONE APPS (PackageManager)'
                    : 'WEB PREVIEW SAMPLE APPS'}
                </span>
              </div>
              <p className="text-[11px] text-slate-400">
                Scans installed apps, shows which are BLOCKED from Accessibility, and flags any unblocked app matching financial keywords (<code>pay</code>, <code>bank</code>, <code>upi</code>, <code>wallet</code>, <code>fin</code>).
              </p>
            </div>
          </div>

          <button
            onClick={() => refreshBankingShieldAudit()}
            className="px-2.5 py-1.5 rounded-xl bg-emerald-600/20 hover:bg-emerald-600/30 border border-emerald-500/40 text-emerald-300 text-[11px] font-bold flex items-center gap-1.5 cursor-pointer shrink-0"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Re-Scan</span>
          </button>
        </div>

        {/* Summary Counters */}
        <div className="grid grid-cols-3 gap-2">
          <button
            onClick={() => setFilterMode('all')}
            className={`p-2.5 rounded-xl border text-left cursor-pointer transition-all ${
              filterMode === 'all'
                ? 'bg-slate-800 border-cyan-400/60'
                : 'bg-slate-900/90 border-slate-800 hover:bg-slate-800/60'
            }`}
          >
            <span className="text-[10px] text-slate-400 block">Installed Scanned</span>
            <span className="text-sm font-black text-white">{shieldReport.totalScanned}</span>
          </button>

          <button
            onClick={() => setFilterMode('blocked')}
            className={`p-2.5 rounded-xl border text-left cursor-pointer transition-all ${
              filterMode === 'blocked'
                ? 'bg-emerald-950/80 border-emerald-400'
                : 'bg-emerald-950/30 border-emerald-500/30 hover:bg-emerald-950/50'
            }`}
          >
            <span className="text-[10px] text-emerald-300/80 block">Blocked (Protected)</span>
            <span className="text-sm font-black text-emerald-400">{shieldReport.blockedCount}</span>
          </button>

          <button
            onClick={() => setFilterMode('flagged')}
            className={`p-2.5 rounded-xl border text-left cursor-pointer transition-all ${
              filterMode === 'flagged'
                ? 'bg-amber-950/80 border-amber-400'
                : shieldReport.flaggedUnblockedCount > 0
                ? 'bg-amber-950/40 border-amber-500/50 hover:bg-amber-950/60'
                : 'bg-slate-900/90 border-slate-800'
            }`}
          >
            <span className="text-[10px] text-amber-300/90 block">Flagged Unblocked</span>
            <span
              className={`text-sm font-black ${
                shieldReport.flaggedUnblockedCount > 0 ? 'text-amber-400' : 'text-slate-400'
              }`}
            >
              {shieldReport.flaggedUnblockedCount}
            </span>
          </button>
        </div>

        {/* Warning banner if any financial-looking app is unblocked */}
        {shieldReport.flaggedUnblockedCount > 0 && (
          <div className="p-2.5 rounded-xl bg-amber-950/50 border border-amber-500/50 flex items-center justify-between gap-2 text-[11px] text-amber-200">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
              <span>
                <b>{shieldReport.flaggedUnblockedCount} installed app(s)</b> have financial keywords in their name or package but are not blocked yet. Click <b>+ Block</b> below to protect them.
              </span>
            </div>
          </div>
        )}

        {/* Custom Package Probe & Manual Blocklist Adder */}
        <form onSubmit={handleTestOrAddCustomApp} className="space-y-2 pt-1">
          <div className="text-[11px] font-bold text-slate-300 flex items-center gap-1.5">
            <Search className="w-3.5 h-3.5 text-cyan-400" />
            <span>Test or Add Any Package / Financial App to Blocklist:</span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
            <input
              type="text"
              value={newPkgInput}
              onChange={(e) => setNewPkgInput(e.target.value)}
              placeholder="Package (e.g. com.mycoop.finapp)"
              className="px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white outline-none focus:border-emerald-400 font-mono"
            />
            <div className="flex gap-1.5">
              <input
                type="text"
                value={newAppLabelInput}
                onChange={(e) => setNewAppLabelInput(e.target.value)}
                placeholder="App Name (optional)"
                className="flex-1 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white outline-none focus:border-emerald-400"
              />
              <button
                type="submit"
                className="px-3 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold cursor-pointer shrink-0"
              >
                Check
              </button>
              <button
                type="button"
                onClick={() => {
                  if (newPkgInput.trim()) {
                    handleAddPackageToBlocklist(newPkgInput.trim());
                    setNewPkgInput('');
                    setNewAppLabelInput('');
                  }
                }}
                className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1 cursor-pointer shrink-0"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Block</span>
              </button>
            </div>
          </div>
        </form>

        {/* Installed Apps Audit Table */}
        <div className="max-h-56 overflow-y-auto space-y-1.5 pr-1">
          {filteredApps.map((app) => (
            <div
              key={app.packageName}
              className={`p-2.5 rounded-xl border flex items-center justify-between gap-2 text-xs ${
                app.flaggedUnblockedFinancial
                  ? 'bg-amber-950/40 border-amber-500/50 text-amber-100'
                  : app.isBlocked
                  ? 'bg-emerald-950/25 border-emerald-500/30 text-slate-200'
                  : 'bg-slate-900/70 border-slate-800 text-slate-300'
              }`}
            >
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-1.5 flex-wrap">
                  <span className="font-bold truncate">{app.appName}</span>
                  {app.isBlocked ? (
                    <span className="px-1.5 py-0.5 text-[9px] font-bold rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                      BLOCKED
                    </span>
                  ) : app.flaggedUnblockedFinancial ? (
                    <span className="px-1.5 py-0.5 text-[9px] font-bold rounded bg-amber-500/25 text-amber-300 border border-amber-500/50 flex items-center gap-1">
                      <ShieldAlert className="w-2.5 h-2.5" />
                      UNBLOCKED FINANCIAL
                    </span>
                  ) : (
                    <span className="px-1.5 py-0.5 text-[9px] font-mono rounded bg-slate-800 text-slate-400">
                      ALLOWED
                    </span>
                  )}
                </div>
                <div className="text-[10px] font-mono text-slate-400 truncate">
                  {app.packageName}
                </div>
                <div className="text-[10px] text-slate-500 truncate">{app.matchedReason}</div>
              </div>

              <div className="shrink-0 flex items-center gap-1">
                {!app.isBlocked && (
                  <button
                    onClick={() => handleAddPackageToBlocklist(app.packageName)}
                    className={`px-2.5 py-1 rounded-lg text-[10px] font-bold flex items-center gap-1 cursor-pointer ${
                      app.flaggedUnblockedFinancial
                        ? 'bg-amber-500 hover:bg-amber-400 text-slate-950'
                        : 'bg-slate-800 hover:bg-emerald-700 text-slate-200'
                    }`}
                  >
                    <Plus className="w-3 h-3" />
                    <span>Add to Blocklist</span>
                  </button>
                )}
                {app.isCustomBlocked && (
                  <button
                    onClick={() => handleRemoveCustomPackage(app.packageName)}
                    className="p-1.5 rounded-lg bg-rose-950/60 hover:bg-rose-900 border border-rose-500/40 text-rose-300 cursor-pointer"
                    title="Remove from custom blocklist"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>

        {customBlockedList.length > 0 && (
          <div className="pt-1 text-[10px] text-emerald-300/90 font-mono">
            Custom User Blocklist ({customBlockedList.length}): {customBlockedList.join(', ')}
          </div>
        )}
      </div>

      {/* Interactive Control Pad (Test or Trigger Device Actions) */}
      <div className="p-4 rounded-2xl bg-slate-950/90 border border-slate-800 space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-slate-200">
            मोबाइल नेविगेशन और जेस्चर कंट्रोल (Live Control Pad)
          </span>
          <span className="text-[10px] text-cyan-400 font-mono">Hindi + English Voice Ready</span>
        </div>

        {/* Global Navigation & Scroll Buttons */}
        <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
          <button
            onClick={() => runAction({ action: 'global_action', command: 'BACK' })}
            className="p-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 flex flex-col items-center gap-1 text-slate-200 cursor-pointer active:scale-95"
          >
            <CornerUpLeft className="w-4 h-4 text-cyan-400" />
            <span className="text-[10px] font-medium">Back (पीछे)</span>
          </button>

          <button
            onClick={() => runAction({ action: 'global_action', command: 'HOME' })}
            className="p-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 flex flex-col items-center gap-1 text-slate-200 cursor-pointer active:scale-95"
          >
            <Home className="w-4 h-4 text-emerald-400" />
            <span className="text-[10px] font-medium">Home (होम)</span>
          </button>

          <button
            onClick={() => runAction({ action: 'scroll', direction: 'down' })}
            className="p-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 flex flex-col items-center gap-1 text-slate-200 cursor-pointer active:scale-95"
          >
            <ArrowDown className="w-4 h-4 text-pink-400" />
            <span className="text-[10px] font-medium">Scroll Down</span>
          </button>

          <button
            onClick={() => runAction({ action: 'scroll', direction: 'up' })}
            className="p-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 flex flex-col items-center gap-1 text-slate-200 cursor-pointer active:scale-95"
          >
            <ArrowUp className="w-4 h-4 text-pink-400" />
            <span className="text-[10px] font-medium">Scroll Up</span>
          </button>

          <button
            onClick={() => runAction({ action: 'global_action', command: 'NOTIFICATIONS' })}
            className="p-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 flex flex-col items-center gap-1 text-slate-200 cursor-pointer active:scale-95"
          >
            <Bell className="w-4 h-4 text-amber-400" />
            <span className="text-[10px] font-medium">Alerts</span>
          </button>

          <button
            onClick={() => runAction({ action: 'read_screen' })}
            className="p-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 flex flex-col items-center gap-1 text-slate-200 cursor-pointer active:scale-95"
          >
            <Eye className="w-4 h-4 text-purple-400" />
            <span className="text-[10px] font-medium">Read Screen</span>
          </button>
        </div>

        {/* Open Any Installed App */}
        <div className="pt-2 border-t border-slate-800/80 flex flex-col sm:flex-row gap-2">
          <div className="flex-1 flex items-center gap-2 bg-slate-900 border border-slate-800 rounded-xl px-3 py-1.5">
            <Play className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
            <input
              type="text"
              value={customAppName}
              onChange={(e) => setCustomAppName(e.target.value)}
              placeholder="App Name (WhatsApp, YouTube, Instagram...)"
              className="w-full bg-transparent text-xs text-white outline-none"
            />
          </div>
          <button
            onClick={() => runAction({ action: 'open_app', app: customAppName })}
            className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold cursor-pointer shrink-0"
          >
            ऐप खोलें (Open App)
          </button>
        </div>

        {/* Click Element by Visible Text */}
        <div className="flex flex-col sm:flex-row gap-2">
          <div className="flex-1 flex items-center gap-2 bg-slate-900 border border-slate-800 rounded-xl px-3 py-1.5">
            <MousePointerClick className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
            <input
              type="text"
              value={customClickTarget}
              onChange={(e) => setCustomClickTarget(e.target.value)}
              placeholder="Button/Text to Click (e.g. Search, Send, Play)"
              className="w-full bg-transparent text-xs text-white outline-none"
            />
          </div>
          <button
            onClick={() =>
              customClickTarget.trim() &&
              runAction({ action: 'click_text', text: customClickTarget.trim() })
            }
            className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold cursor-pointer shrink-0"
          >
            क्लिक करें (Click Text)
          </button>
        </div>

        {/* Type Text into Active Input Field */}
        <div className="flex flex-col sm:flex-row gap-2">
          <div className="flex-1 flex items-center gap-2 bg-slate-900 border border-slate-800 rounded-xl px-3 py-1.5">
            <Type className="w-3.5 h-3.5 text-pink-400 shrink-0" />
            <input
              type="text"
              value={customText}
              onChange={(e) => setCustomText(e.target.value)}
              placeholder="Type text into focused input box..."
              className="w-full bg-transparent text-xs text-white outline-none"
            />
          </div>
          <button
            onClick={() =>
              customText.trim() && runAction({ action: 'type_text', text: customText.trim() })
            }
            className="px-4 py-2 rounded-xl bg-pink-600 hover:bg-pink-500 text-white text-xs font-bold cursor-pointer shrink-0"
          >
            टाइप करें (Type Text)
          </button>
        </div>

        {/* Action Feedback Toast */}
        {actionFeedback && (
          <div className="p-2.5 rounded-xl bg-indigo-950/50 border border-indigo-500/30 flex items-center gap-2 text-xs text-indigo-200">
            <CheckCircle2 className="w-4 h-4 text-indigo-400 shrink-0" />
            <span className="truncate">{actionFeedback}</span>
          </div>
        )}

        {/* Screen Context Inspector Output */}
        {screenSummary && (
          <div className="p-3 rounded-xl bg-slate-900/90 border border-slate-700 text-[11px] text-slate-300 space-y-1 max-h-36 overflow-y-auto font-mono">
            <div className="text-cyan-300 font-bold">
              Package: {screenSummary.packageName} ({screenSummary.nodesCount} interactive nodes)
            </div>
            {(screenSummary.nodes || []).map((n: any, idx: number) => (
              <div key={idx} className="truncate text-slate-400">
                • [{n.text || n.desc}] {n.clickable ? '(Clickable)' : ''}{' '}
                {n.editable ? '(Input)' : ''}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Supported Hindi & English Voice Commands Guide */}
      <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800/80 space-y-2">
        <div className="text-xs font-bold text-purple-300">
          उदाहरण वॉयस कमांड (Speak Directly to Zoya):
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 text-[11px] text-slate-300">
          <div>• "ज़ोया, व्हाट्सएप खोलो" (Open WhatsApp)</div>
          <div>• "ज़ोया, नीचे स्क्रॉल करो" (Scroll down)</div>
          <div>• "ज़ोया, पीछे जाओ / होम पर जाओ" (Go back / Home)</div>
          <div>• "ज़ोया, स्क्रीन लॉक करो / अनलॉक करो" (Lock / Unlock)</div>
          <div>• "ज़ोया, Search पर क्लिक करो" (Click on Search)</div>
          <div>• "ज़ोया, टाइप करो नमस्ते" (Type Namaste)</div>
        </div>
      </div>
    </div>
  );
};
