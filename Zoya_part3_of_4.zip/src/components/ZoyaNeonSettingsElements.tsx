import React, { useState, useEffect } from 'react';
import { Check, Copy, Sparkles, Play, RefreshCw, Zap, TrendingUp, MessageCircle, Hash, Clock, Share2 } from 'lucide-react';

/* ============================================================================
   1. EXACT 3D NEON SVG ICONS MATCHING REFERENCE SCREENSHOT
   ============================================================================ */

export const Neon3DGearBadge: React.FC<{ className?: string }> = ({ className = 'w-12 h-12 sm:w-13 sm:h-13' }) => (
  <svg viewBox="0 0 64 64" fill="none" className={className} aria-hidden="true">
    <defs>
      <radialGradient id="gearRingGlow" cx="50%" cy="50%" r="50%">
        <stop offset="0%" stopColor="#38bdf8" stopOpacity="0.45" />
        <stop offset="65%" stopColor="#a855f7" stopOpacity="0.65" />
        <stop offset="100%" stopColor="#0ea5e9" stopOpacity="0.95" />
      </radialGradient>
      <linearGradient id="gearMetal3D" x1="12" y1="10" x2="52" y2="54" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#ffffff" />
        <stop offset="38%" stopColor="#e9d5ff" />
        <stop offset="72%" stopColor="#a855f7" />
        <stop offset="100%" stopColor="#38bdf8" />
      </linearGradient>
      <linearGradient id="gearCoreGrad" x1="22" y1="22" x2="42" y2="42" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#a855f7" />
        <stop offset="50%" stopColor="#3b0764" />
        <stop offset="100%" stopColor="#22d3ee" />
      </linearGradient>
    </defs>
    {/* Outer Cyan/Purple Glowing Double Ring */}
    <circle cx="32" cy="32" r="30" fill="url(#gearRingGlow)" stroke="#38bdf8" strokeWidth="1.8" />
    <circle cx="32" cy="32" r="26.5" fill="#13072e" stroke="#c084fc" strokeWidth="1.5" strokeOpacity="0.85" />
    {/* 3D Gear Shadow Extrusion */}
    <path
      d="M35.2 12.8L37 16.9C38.6 17.4 40.1 18.3 41.3 19.4L45.6 18.1L48.8 23.6L45.5 26.7C45.9 28.4 45.9 30.1 45.5 31.8L48.8 34.9L45.6 40.4L41.3 39.1C40.1 40.2 38.6 41.1 37 41.6L35.2 45.7H28.8L27 41.6C25.4 41.1 23.9 40.2 22.7 39.1L18.4 40.4L15.2 34.9L18.5 31.8C18.1 30.1 18.1 28.4 18.5 26.7L15.2 23.6L18.4 18.1L22.7 19.4C23.9 18.3 25.4 17.4 27 16.9L28.8 12.8H35.2Z"
      transform="translate(0, 2.2)"
      fill="#3b0764"
      opacity="0.85"
    />
    {/* 3D Gear Main Metallic Face */}
    <path
      d="M35.2 12.8L37 16.9C38.6 17.4 40.1 18.3 41.3 19.4L45.6 18.1L48.8 23.6L45.5 26.7C45.9 28.4 45.9 30.1 45.5 31.8L48.8 34.9L45.6 40.4L41.3 39.1C40.1 40.2 38.6 41.1 37 41.6L35.2 45.7H28.8L27 41.6C25.4 41.1 23.9 40.2 22.7 39.1L18.4 40.4L15.2 34.9L18.5 31.8C18.1 30.1 18.1 28.4 18.5 26.7L15.2 23.6L18.4 18.1L22.7 19.4C23.9 18.3 25.4 17.4 27 16.9L28.8 12.8H35.2Z"
      transform="translate(0, 1.2)"
      fill="url(#gearMetal3D)"
      stroke="#ffffff"
      strokeWidth="1.1"
    />
    {/* Inner Gear Rim & Glowing Core */}
    <circle cx="32" cy="30.5" r="8.5" fill="url(#gearCoreGrad)" stroke="#f5d0fe" strokeWidth="1.8" />
    <circle cx="32" cy="30.5" r="4.2" fill="#e0f2fe" />
  </svg>
);

export const NeonInstagram3DIcon: React.FC<{ className?: string }> = ({ className = 'w-9 h-9 sm:w-10 sm:h-10' }) => (
  <svg viewBox="0 0 48 48" fill="none" className={className} aria-hidden="true">
    <defs>
      <radialGradient id="ig3dGrad" cx="28%" cy="95%" r="105%">
        <stop offset="0%" stopColor="#fde047" />
        <stop offset="26%" stopColor="#fb923c" />
        <stop offset="55%" stopColor="#ec4899" />
        <stop offset="85%" stopColor="#9333ea" />
        <stop offset="100%" stopColor="#4f46e5" />
      </radialGradient>
    </defs>
    {/* 3D Bottom Extrusion */}
    <rect x="5" y="7" width="38" height="37" rx="11" fill="#581c87" />
    {/* Glossy Main Body */}
    <rect x="5" y="4.5" width="38" height="37" rx="11" fill="url(#ig3dGrad)" stroke="#fbcfe8" strokeWidth="1.2" />
    {/* Top Specular Gloss */}
    <path d="M14 6.5H34C38.5 6.5 41 9 41 13C34 10.5 14 10.5 7 13C7 9 9.5 6.5 14 6.5Z" fill="white" fillOpacity="0.32" />
    {/* Camera Frame */}
    <rect x="12.5" y="12" width="23" height="22" rx="6.5" stroke="#ffffff" strokeWidth="2.6" />
    <circle cx="24" cy="23" r="5.3" stroke="#ffffff" strokeWidth="2.6" />
    <circle cx="30.8" cy="16.4" r="1.6" fill="#ffffff" />
  </svg>
);

export const NeonCube3DIcon: React.FC<{ className?: string }> = ({ className = 'w-9 h-9 sm:w-10 sm:h-10' }) => (
  <svg viewBox="0 0 48 48" fill="none" className={className} aria-hidden="true">
    <defs>
      <linearGradient id="cubeTop" x1="24" y1="5" x2="24" y2="24" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#e0f2fe" />
        <stop offset="100%" stopColor="#38bdf8" />
      </linearGradient>
      <linearGradient id="cubeLeft" x1="7" y1="14" x2="24" y2="42" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#38bdf8" />
        <stop offset="100%" stopColor="#0284c7" />
      </linearGradient>
      <linearGradient id="cubeRight" x1="41" y1="14" x2="24" y2="42" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#0ea5e9" />
        <stop offset="100%" stopColor="#1d4ed8" />
      </linearGradient>
    </defs>
    {/* Top Face */}
    <polygon points="24,5 41,14.5 24,24 7,14.5" fill="url(#cubeTop)" stroke="#e0f2fe" strokeWidth="1.4" strokeLinejoin="round" />
    {/* Left Face */}
    <polygon points="7,14.5 24,24 24,43 7,33.5" fill="url(#cubeLeft)" stroke="#bae6fd" strokeWidth="1.4" strokeLinejoin="round" />
    {/* Right Face */}
    <polygon points="41,14.5 24,24 24,43 41,33.5" fill="url(#cubeRight)" stroke="#7dd3fc" strokeWidth="1.4" strokeLinejoin="round" />
    {/* Glowing Center Vertex Highlight */}
    <circle cx="24" cy="24" r="2.2" fill="#ffffff" />
  </svg>
);

export const NeonPalette3DIcon: React.FC<{ className?: string }> = ({ className = 'w-9 h-9 sm:w-10 sm:h-10' }) => (
  <svg viewBox="0 0 48 48" fill="none" className={className} aria-hidden="true">
    <defs>
      <linearGradient id="pal3D" x1="8" y1="7" x2="40" y2="41" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#f5d0fe" />
        <stop offset="45%" stopColor="#c084fc" />
        <stop offset="100%" stopColor="#7e22ce" />
      </linearGradient>
    </defs>
    {/* 3D Shadow */}
    <path
      d="M24 9C14.1 9 6 16.4 6 25.5C6 34.6 13.8 41 21.5 41C24.3 41 26.2 39.1 26.2 36.7C26.2 35.5 25.6 34.5 25.6 33.4C25.6 31.8 27 30.6 28.8 30.6H32.2C37.8 30.6 42 26.5 42 21.2C42 14.3 33.9 9 24 9Z"
      fill="#3b0764"
    />
    {/* 3D Main Palette Body */}
    <path
      d="M24 6.5C14.1 6.5 6 13.9 6 23C6 32.1 13.8 38.5 21.5 38.5C24.3 38.5 26.2 36.6 26.2 34.2C26.2 33 25.6 32 25.6 30.9C25.6 29.3 27 28.1 28.8 28.1H32.2C37.8 28.1 42 24 42 18.7C42 11.8 33.9 6.5 24 6.5Z"
      fill="url(#pal3D)"
      stroke="#f5d0fe"
      strokeWidth="1.5"
    />
    {/* Palette Wells */}
    <circle cx="15.5" cy="18.5" r="2.7" fill="#3b0764" stroke="#f5d0fe" strokeWidth="1" />
    <circle cx="22.5" cy="14" r="2.7" fill="#3b0764" stroke="#f5d0fe" strokeWidth="1" />
    <circle cx="30.5" cy="16" r="2.7" fill="#3b0764" stroke="#f5d0fe" strokeWidth="1" />
    <circle cx="15.5" cy="27" r="2.8" fill="#3b0764" stroke="#f5d0fe" strokeWidth="1" />
  </svg>
);

export const NeonYouTube3DIcon: React.FC<{ className?: string }> = ({ className = 'w-9 h-9 sm:w-10 sm:h-10' }) => (
  <svg viewBox="0 0 48 48" fill="none" className={className} aria-hidden="true">
    <defs>
      <linearGradient id="yt3D" x1="6" y1="10" x2="42" y2="38" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#ff4d4d" />
        <stop offset="50%" stopColor="#ef4444" />
        <stop offset="100%" stopColor="#b91c1c" />
      </linearGradient>
    </defs>
    {/* 3D Bottom Shadow */}
    <rect x="5" y="13" width="38" height="26" rx="8.5" fill="#7f1d1d" />
    {/* Glossy Red Body */}
    <rect x="5" y="10.5" width="38" height="26" rx="8.5" fill="url(#yt3D)" stroke="#fecaca" strokeWidth="1.2" />
    {/* Play Triangle */}
    <polygon points="20.5,17.5 31,23.5 20.5,29.5" fill="#ffffff" />
  </svg>
);

export const NeonCode3DIcon: React.FC<{ className?: string }> = ({ className = 'w-9 h-9 sm:w-10 sm:h-10' }) => (
  <svg viewBox="0 0 48 48" fill="none" className={className} aria-hidden="true">
    <defs>
      <linearGradient id="code3D" x1="6" y1="10" x2="42" y2="38" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#f5d0fe" />
        <stop offset="50%" stopColor="#c084fc" />
        <stop offset="100%" stopColor="#7c3aed" />
      </linearGradient>
    </defs>
    {/* Shadow Layer */}
    <path
      d="M16 16L7 25L16 34M32 16L41 25L32 34M27 12L21 38"
      stroke="#4c1d95"
      strokeWidth="4.6"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    {/* Glowing Main Layer */}
    <path
      d="M16 14.5L7 23.5L16 32.5M32 14.5L41 23.5L32 32.5M27 10.5L21 36.5"
      stroke="url(#code3D)"
      strokeWidth="4.2"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

export const NeonLock3DIcon: React.FC<{ className?: string }> = ({ className = 'w-9 h-9 sm:w-10 sm:h-10' }) => (
  <svg viewBox="0 0 48 48" fill="none" className={className} aria-hidden="true">
    <defs>
      <linearGradient id="lock3D" x1="10" y1="8" x2="38" y2="42" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#bbf7d0" />
        <stop offset="45%" stopColor="#4ade80" />
        <stop offset="100%" stopColor="#16a34a" />
      </linearGradient>
    </defs>
    {/* Shackle */}
    <path
      d="M16.5 21V15.5C16.5 11.1 19.9 7.5 24 7.5C28.1 7.5 31.5 11.1 31.5 15.5V21"
      stroke="url(#lock3D)"
      strokeWidth="4.2"
      strokeLinecap="round"
    />
    {/* 3D Body Shadow */}
    <rect x="11" y="22.5" width="26" height="20" rx="6" fill="#14532d" />
    {/* 3D Body */}
    <rect x="11" y="20" width="26" height="20" rx="6" fill="url(#lock3D)" stroke="#dcfce7" strokeWidth="1.2" />
    {/* Keyhole */}
    <circle cx="24" cy="28.2" r="2.6" fill="#052e16" />
    <path d="M22.7 29.8L22 34.8H26L25.3 29.8H22.7Z" fill="#052e16" />
  </svg>
);

export const NeonSmartphone3DIcon: React.FC<{ className?: string }> = ({ className = 'w-9 h-9 sm:w-10 sm:h-10' }) => (
  <svg viewBox="0 0 48 48" fill="none" className={className} aria-hidden="true">
    <defs>
      <linearGradient id="phone3D" x1="12" y1="6" x2="36" y2="42" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#fef08a" />
        <stop offset="50%" stopColor="#fbbf24" />
        <stop offset="100%" stopColor="#d97706" />
      </linearGradient>
    </defs>
    {/* 3D Shadow */}
    <rect x="13" y="7.5" width="22" height="36" rx="5" fill="#78350f" />
    {/* 3D Gold Frame */}
    <rect x="13" y="5.5" width="22" height="36" rx="5" fill="url(#phone3D)" stroke="#fef9c3" strokeWidth="1.3" />
    {/* Inner Screen */}
    <rect x="16" y="10" width="16" height="24.5" rx="2" fill="#451a03" stroke="#fde68a" strokeWidth="0.8" />
    {/* Home Dot */}
    <circle cx="24" cy="38" r="1.6" fill="#451a03" />
  </svg>
);

export const NeonBrain3DIcon: React.FC<{ className?: string }> = ({ className = 'w-9 h-9 sm:w-10 sm:h-10' }) => (
  <svg viewBox="0 0 48 48" fill="none" className={className} aria-hidden="true">
    <defs>
      <linearGradient id="brain3D" x1="8" y1="8" x2="40" y2="40" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#fbcfe8" />
        <stop offset="50%" stopColor="#f472b6" />
        <stop offset="100%" stopColor="#db2777" />
      </linearGradient>
    </defs>
    {/* Left Hemisphere */}
    <path
      d="M22.5 11.5C22.5 9.3 20.7 7.5 18.5 7.5C16.6 7.5 15 8.8 14.6 10.6C12 10.9 10 13.1 10 15.8C10 16.9 10.3 17.9 10.9 18.7C9.1 19.8 8 21.8 8 24C8 26.5 9.4 28.6 11.5 29.6C11.2 30.4 11 31.2 11 32.1C11 35.4 13.7 38 17 38C17.8 38 18.5 37.8 19.2 37.5C20.2 39 22.5 38.5 22.5 36.2V11.5Z"
      fill="url(#brain3D)"
      stroke="#fce7f3"
      strokeWidth="1.5"
    />
    {/* Right Hemisphere */}
    <path
      d="M25.5 11.5C25.5 9.3 27.3 7.5 29.5 7.5C31.4 7.5 33 8.8 33.4 10.6C36 10.9 38 13.1 38 15.8C38 16.9 37.7 17.9 37.1 18.7C38.9 19.8 40 21.8 40 24C40 26.5 38.6 28.6 36.5 29.6C36.8 30.4 37 31.2 37 32.1C37 35.4 34.3 38 31 38C30.2 38 29.5 37.8 28.8 37.5C27.8 39 25.5 38.5 25.5 36.2V11.5Z"
      fill="url(#brain3D)"
      stroke="#fce7f3"
      strokeWidth="1.5"
    />
    {/* Gyri Folds */}
    <path d="M14.5 16.5C17 16.5 18.5 18 18.5 20.5M13 24.5C16 24.5 18 26 18 28.5M15.5 32.5C17.5 32.5 19.5 31 19.5 29" stroke="#831843" strokeWidth="1.8" strokeLinecap="round" />
    <path d="M33.5 16.5C31 16.5 29.5 18 29.5 20.5M35 24.5C32 24.5 30 26 30 28.5M32.5 32.5C30.5 32.5 28.5 31 28.5 29" stroke="#831843" strokeWidth="1.8" strokeLinecap="round" />
  </svg>
);

export const NeonHeart3DIcon: React.FC<{ className?: string }> = ({ className = 'w-9 h-9 sm:w-10 sm:h-10' }) => (
  <svg viewBox="0 0 48 48" fill="none" className={className} aria-hidden="true">
    <defs>
      <linearGradient id="heart3D" x1="8" y1="8" x2="40" y2="40" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#fbcfe8" />
        <stop offset="45%" stopColor="#f472b6" />
        <stop offset="100%" stopColor="#db2777" />
      </linearGradient>
    </defs>
    {/* 3D Extrusion Shadow */}
    <path
      d="M24 39.5L21.2 37C11.4 28.1 5.5 22.8 5.5 15.8C5.5 10.2 9.9 5.8 15.5 5.8C18.7 5.8 21.8 7.3 24 9.7C26.2 7.3 29.3 5.8 32.5 5.8C38.1 5.8 42.5 10.2 42.5 15.8C42.5 22.8 36.6 28.1 26.8 37L24 39.5Z"
      transform="translate(0, 2)"
      stroke="#831843"
      strokeWidth="4.8"
      strokeLinejoin="round"
    />
    {/* 3D Glowing Heart Outline */}
    <path
      d="M24 39.5L21.2 37C11.4 28.1 5.5 22.8 5.5 15.8C5.5 10.2 9.9 5.8 15.5 5.8C18.7 5.8 21.8 7.3 24 9.7C26.2 7.3 29.3 5.8 32.5 5.8C38.1 5.8 42.5 10.2 42.5 15.8C42.5 22.8 36.6 28.1 26.8 37L24 39.5Z"
      stroke="url(#heart3D)"
      strokeWidth="4.4"
      strokeLinejoin="round"
    />
  </svg>
);

export const NeonGlobe3DIcon: React.FC<{ className?: string }> = ({ className = 'w-9 h-9 sm:w-10 sm:h-10' }) => (
  <svg viewBox="0 0 48 48" fill="none" className={className} aria-hidden="true">
    <defs>
      <radialGradient id="globe3D" cx="35%" cy="30%" r="70%">
        <stop offset="0%" stopColor="#bae6fd" />
        <stop offset="55%" stopColor="#0ea5e9" />
        <stop offset="100%" stopColor="#1d4ed8" />
      </radialGradient>
    </defs>
    <circle cx="24" cy="24" r="17" fill="url(#globe3D)" stroke="#e0f2fe" strokeWidth="2.2" />
    <ellipse cx="24" cy="24" rx="8.5" ry="17" stroke="#e0f2fe" strokeWidth="2" />
    <path d="M7.5 24H40.5M9.5 16.5H38.5M9.5 31.5H38.5" stroke="#e0f2fe" strokeWidth="1.8" />
  </svg>
);

export const NeonAiChip3DIcon: React.FC<{ className?: string }> = ({ className = 'w-12 h-12 sm:w-13 sm:h-13' }) => (
  <svg viewBox="0 0 64 64" fill="none" className={className} aria-hidden="true">
    <defs>
      <radialGradient id="chipRing" cx="50%" cy="50%" r="50%">
        <stop offset="0%" stopColor="#0284c7" stopOpacity="0.35" />
        <stop offset="75%" stopColor="#1e3a8a" stopOpacity="0.85" />
        <stop offset="100%" stopColor="#38bdf8" stopOpacity="1" />
      </radialGradient>
      <linearGradient id="chipBody" x1="16" y1="16" x2="48" y2="48" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#38bdf8" />
        <stop offset="55%" stopColor="#0284c7" />
        <stop offset="100%" stopColor="#1e3a8a" />
      </linearGradient>
    </defs>
    {/* Circular Tech Ring */}
    <circle cx="32" cy="32" r="29" fill="url(#chipRing)" stroke="#38bdf8" strokeWidth="1.8" />
    <circle cx="32" cy="32" r="25" stroke="#7dd3fc" strokeWidth="0.9" strokeDasharray="5 3" />
    {/* Tilted 3D Microchip Pins & Package */}
    <g transform="rotate(-24 32 32)">
      {/* Pins Top/Bottom/Left/Right */}
      {[22, 27, 32, 37, 42].map((pos) => (
        <React.Fragment key={pos}>
          <rect x={pos - 1.2} y="11" width="2.4" height="5" rx="1" fill="#7dd3fc" />
          <rect x={pos - 1.2} y="48" width="2.4" height="5" rx="1" fill="#38bdf8" />
          <rect x="11" y={pos - 1.2} width="5" height="2.4" rx="1" fill="#7dd3fc" />
          <rect x="48" y={pos - 1.2} width="5" height="2.4" rx="1" fill="#38bdf8" />
        </React.Fragment>
      ))}
      {/* 3D Chip Base Shadow */}
      <rect x="16" y="18.5" width="32" height="31" rx="6" fill="#0f172a" />
      {/* 3D Chip Top Surface */}
      <rect x="16" y="16" width="32" height="31" rx="6" fill="url(#chipBody)" stroke="#bae6fd" strokeWidth="1.6" />
      {/* InnerGlowing Brain on Chip */}
      <path
        d="M31 23C28.8 23 27 24.5 27 26.5C25.2 27 24 28.6 24 30.5C24 32.5 25.3 34 27 34.6C27 36.5 28.8 38 31 38V23ZM33 23C35.2 23 37 24.5 37 26.5C38.8 27 40 28.6 40 30.5C40 32.5 38.7 34 37 34.6C37 36.5 35.2 38 33 38V23Z"
        stroke="#ffffff"
        strokeWidth="1.8"
        fill="#e0f2fe"
        fillOpacity="0.25"
      />
    </g>
  </svg>
);

export const NeonAvatar3DIcon: React.FC<{ className?: string }> = ({ className = 'w-9 h-9 sm:w-10 sm:h-10' }) => (
  <svg viewBox="0 0 48 48" fill="none" className={className} aria-hidden="true">
    <defs>
      <linearGradient id="avatarCrown3D" x1="12" y1="6" x2="36" y2="18" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#fef08a" />
        <stop offset="50%" stopColor="#f59e0b" />
        <stop offset="100%" stopColor="#d97706" />
      </linearGradient>
      <linearGradient id="avatarBody3D" x1="10" y1="16" x2="38" y2="42" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#f5d0fe" />
        <stop offset="50%" stopColor="#d946ef" />
        <stop offset="100%" stopColor="#7e22ce" />
      </linearGradient>
    </defs>
    {/* Princess Crown */}
    <path
      d="M14 14L17.5 8L24 12.5L30.5 8L34 14H14Z"
      fill="url(#avatarCrown3D)"
      stroke="#fef9c3"
      strokeWidth="1.2"
      strokeLinejoin="round"
    />
    {/* 3D Head */}
    <circle cx="24" cy="21" r="6.2" fill="url(#avatarBody3D)" stroke="#fae8ff" strokeWidth="1.4" />
    {/* 3D Royal Gown Shoulders */}
    <path
      d="M10.5 40.5C11.5 33.2 16.8 29.2 24 29.2C31.2 29.2 36.5 33.2 37.5 40.5H10.5Z"
      fill="url(#avatarBody3D)"
      stroke="#fae8ff"
      strokeWidth="1.4"
      strokeLinejoin="round"
    />
  </svg>
);

export const NeonVoiceMic3DIcon: React.FC<{ className?: string }> = ({ className = 'w-9 h-9 sm:w-10 sm:h-10' }) => (
  <svg viewBox="0 0 48 48" fill="none" className={className} aria-hidden="true">
    <defs>
      <linearGradient id="mic3D" x1="16" y1="6" x2="32" y2="32" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#bae6fd" />
        <stop offset="50%" stopColor="#38bdf8" />
        <stop offset="100%" stopColor="#0284c7" />
      </linearGradient>
    </defs>
    {/* 3D Mic Capsule */}
    <rect x="18" y="7" width="12" height="20" rx="6" fill="url(#mic3D)" stroke="#e0f2fe" strokeWidth="1.5" />
    {/* Sound Waves Left & Right */}
    <path
      d="M12 17V21M8 14.5V23.5M36 17V21M40 14.5V23.5"
      stroke="#f472b6"
      strokeWidth="2.4"
      strokeLinecap="round"
    />
    {/* Mic Stand & Base */}
    <path
      d="M14 21C14 26.5 18.5 31 24 31C29.5 31 34 26.5 34 21M24 31V39M17.5 39H30.5"
      stroke="#7dd3fc"
      strokeWidth="2.6"
      strokeLinecap="round"
    />
  </svg>
);

export const NeonGeminiKey3DIcon: React.FC<{ className?: string }> = ({ className = 'w-9 h-9 sm:w-10 sm:h-10' }) => (
  <svg viewBox="0 0 48 48" fill="none" className={className} aria-hidden="true">
    <defs>
      <linearGradient id="gemKey3D" x1="6" y1="8" x2="42" y2="40" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#fde68a" />
        <stop offset="45%" stopColor="#c084fc" />
        <stop offset="100%" stopColor="#38bdf8" />
      </linearGradient>
    </defs>
    {/* Gemini Sparkle Star */}
    <path
      d="M34 6C34 11 37 14 42 14C37 14 34 17 34 22C34 17 31 14 26 14C31 14 34 11 34 6Z"
      fill="#38bdf8"
      stroke="#e0f2fe"
      strokeWidth="1.1"
    />
    {/* 3D Key Ring & Blade */}
    <circle cx="17" cy="28" r="8.5" fill="url(#gemKey3D)" stroke="#ffffff" strokeWidth="1.5" />
    <circle cx="17" cy="28" r="3.2" fill="#1e1040" />
    <path
      d="M25 28H41V33.5M35.5 28V35.5"
      stroke="url(#gemKey3D)"
      strokeWidth="3.8"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

export const NeonToolApi3DIcon: React.FC<{ className?: string }> = ({ className = 'w-9 h-9 sm:w-10 sm:h-10' }) => (
  <svg viewBox="0 0 48 48" fill="none" className={className} aria-hidden="true">
    <defs>
      <linearGradient id="toolApi3D" x1="8" y1="8" x2="40" y2="40" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#67e8f9" />
        <stop offset="50%" stopColor="#38bdf8" />
        <stop offset="100%" stopColor="#6366f1" />
      </linearGradient>
    </defs>
    {/* Central API Hub Hexagon */}
    <polygon
      points="24,13 33.5,18.5 33.5,29.5 24,35 14.5,29.5 14.5,18.5"
      fill="url(#toolApi3D)"
      stroke="#e0f2fe"
      strokeWidth="1.5"
      strokeLinejoin="round"
    />
    {/* Connected Nodes */}
    <path
      d="M24 6V13M24 35V42M7 15L14.5 18.5M33.5 29.5L41 33M41 15L33.5 18.5M14.5 29.5L7 33"
      stroke="#f472b6"
      strokeWidth="2.4"
      strokeLinecap="round"
    />
    <circle cx="24" cy="24" r="3.5" fill="#ffffff" />
  </svg>
);

/* ============================================================================
   2. REUSABLE 3D NEON TOP HEADER (EXACT SCREENSHOT BLUEPRINT)
   ============================================================================ */

interface ZoyaNeonHeaderProps {
  title: string;
  subtitle?: string;
  onBack: () => void;
  onHome: () => void;
}

export const ZoyaNeonHeader: React.FC<ZoyaNeonHeaderProps> = ({
  title,
  subtitle = 'Customize Your Zoya Experience',
  onBack,
  onHome,
}) => {
  return (
    <header className="relative w-full pt-1 pb-0.5 px-2.5 sm:px-3.5 shrink-0 z-20 select-none overflow-hidden">
      {/* Background Neon Light Waves behind Header */}
      <svg
        viewBox="0 0 440 90"
        fill="none"
        className="absolute inset-x-0 top-0 w-full h-full pointer-events-none opacity-95"
        preserveAspectRatio="none"
      >
        <defs>
          <linearGradient id="waveCyan" x1="0" y1="45" x2="440" y2="45" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#06b6d4" stopOpacity="0.95" />
            <stop offset="30%" stopColor="#3b82f6" stopOpacity="0.45" />
            <stop offset="70%" stopColor="#a855f7" stopOpacity="0.45" />
            <stop offset="100%" stopColor="#d946ef" stopOpacity="0.95" />
          </linearGradient>
          <linearGradient id="wavePurple" x1="0" y1="65" x2="440" y2="65" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#22d3ee" stopOpacity="0.85" />
            <stop offset="50%" stopColor="#6366f1" stopOpacity="0.18" />
            <stop offset="100%" stopColor="#ec4899" stopOpacity="0.85" />
          </linearGradient>
        </defs>
        <path
          d="M-10 52 C 55 78, 125 82, 220 74 C 315 66, 385 78, 450 50"
          stroke="url(#waveCyan)"
          strokeWidth="2.4"
          fill="none"
        />
        <path
          d="M-10 66 C 65 92, 145 64, 220 82 C 295 94, 375 64, 450 66"
          stroke="url(#wavePurple)"
          strokeWidth="1.8"
          fill="none"
        />
      </svg>

      {/* Main Header Row: [ <- Back ]   [ (Gear) Settings ]   [ Home ] */}
      <div className="relative z-10 flex items-center justify-between gap-2">
        {/* Left Circular Glowing Back Button */}
        <button
          type="button"
          onClick={onBack}
          data-testid="settings-back-btn"
          title="Back"
          aria-label="Back"
          className="relative w-[clamp(38px,5.6dvh,45px)] h-[clamp(38px,5.6dvh,45px)] rounded-full flex items-center justify-center shrink-0 cursor-pointer active:scale-95 transition-transform group"
          style={{
            background: 'radial-gradient(circle at 35% 28%, #4c1d95 0%, #1e1040 58%, #0d0826 100%)',
            border: '2px solid rgba(168, 85, 247, 0.85)',
            boxShadow:
              '0 0 18px rgba(168, 85, 247, 0.65), inset 0 1.5px 2px rgba(255, 255, 255, 0.45), inset 0 -2px 6px rgba(56, 189, 248, 0.45)',
          }}
        >
          <svg
            viewBox="0 0 24 24"
            fill="none"
            className="w-[clamp(18px,2.7dvh,21px)] h-[clamp(18px,2.7dvh,21px)] text-white drop-shadow-[0_0_8px_rgba(255,255,255,0.9)]"
          >
            <path
              d="M19 12H5M5 12L11.5 5.5M5 12L11.5 18.5"
              stroke="currentColor"
              strokeWidth="2.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </button>

        {/* Center 3D Glossy Asymmetric Capsule Banner: Gear + Title */}
        <div
          className="relative flex-1 max-w-[265px] sm:max-w-[290px] h-[clamp(42px,6.4dvh,52px)] rounded-l-[36px] rounded-r-[28px] px-2.5 sm:px-3.5 flex items-center gap-2.5 sm:gap-3 overflow-hidden"
          style={{
            background:
              'radial-gradient(90% 140% at 22% 15%, rgba(168, 85, 247, 0.42) 0%, rgba(23, 15, 62, 0.96) 52%, rgba(9, 10, 38, 0.98) 100%)',
            border: '2px solid rgba(168, 85, 247, 0.82)',
            boxShadow:
              '0 0 24px rgba(168, 85, 247, 0.55), 0 4px 16px rgba(6, 182, 212, 0.3), inset 0 2px 2px rgba(255, 255, 255, 0.42), inset 0 -2px 6px rgba(34, 211, 238, 0.5)',
          }}
        >
          {/* Top-left Magenta Flare */}
          <div className="absolute -top-1 left-10 w-24 h-1.5 bg-gradient-to-r from-transparent via-fuchsia-300 to-transparent blur-[1px]" />
          {/* Bottom-left Cyan Rim Highlight */}
          <div className="absolute -bottom-0.5 left-6 w-28 h-1 bg-gradient-to-r from-transparent via-cyan-300 to-transparent" />

          {/* 3D Gear Badge */}
          <Neon3DGearBadge className="w-[clamp(34px,5.2dvh,43px)] h-[clamp(34px,5.2dvh,43px)] shrink-0 drop-shadow-[0_0_10px_rgba(56,189,248,0.65)]" />

          {/* Glowing Title */}
          <h2
            className={`font-extrabold tracking-wide text-white truncate leading-none ${
              title === 'Settings'
                ? 'text-[clamp(20px,3.2dvh,27px)]'
                : 'text-[clamp(15px,2.3dvh,18.5px)]'
            }`}
            style={{
              textShadow: '0 0 14px rgba(216, 180, 254, 0.95), 0 0 28px rgba(168, 85, 247, 0.7)',
            }}
          >
            {title}
          </h2>
        </div>

        {/* Right Circular Glowing Home Button */}
        <button
          type="button"
          onClick={onHome}
          data-testid="settings-home-btn"
          title="Back to Zoya Home"
          aria-label="Home"
          className="relative w-[clamp(38px,5.6dvh,45px)] h-[clamp(38px,5.6dvh,45px)] rounded-full flex items-center justify-center shrink-0 cursor-pointer active:scale-95 transition-transform group"
          style={{
            background: 'radial-gradient(circle at 35% 28%, #581c87 0%, #241046 58%, #0e0726 100%)',
            border: '2px solid rgba(192, 132, 252, 0.85)',
            boxShadow:
              '0 0 18px rgba(192, 132, 252, 0.65), inset 0 1.5px 2px rgba(255, 255, 255, 0.45), inset 0 -2px 6px rgba(236, 72, 153, 0.4)',
          }}
        >
          <svg
            viewBox="0 0 24 24"
            fill="none"
            className="w-[clamp(18px,2.7dvh,21px)] h-[clamp(18px,2.7dvh,21px)] drop-shadow-[0_0_8px_rgba(245,208,254,0.9)]"
          >
            <path
              d="M3 10.8L12 3.5L21 10.8V20C21 20.6 20.6 21 20 21H14.5V15H9.5V21H4C3.4 21 3 20.6 3 20V10.8Z"
              fill="url(#homeGrad)"
              stroke="#ffffff"
              strokeWidth="1.5"
              strokeLinejoin="round"
            />
            <defs>
              <linearGradient id="homeGrad" x1="3" y1="3.5" x2="21" y2="21" gradientUnits="userSpaceOnUse">
                <stop offset="0%" stopColor="#ffffff" />
                <stop offset="60%" stopColor="#f5d0fe" />
                <stop offset="100%" stopColor="#c084fc" />
              </linearGradient>
            </defs>
          </svg>
        </button>
      </div>

      {/* Subtitle Line: ──── Customize Your Zoya Experience ──── */}
      <div className="relative z-10 flex items-center justify-center gap-2 mt-0.5 px-3">
        <span className="h-[1.5px] flex-1 max-w-[64px] bg-gradient-to-r from-transparent via-purple-400/75 to-cyan-300/90 rounded-full" />
        <span
          className="text-[clamp(10px,1.5dvh,12px)] font-bold tracking-wide text-cyan-300 truncate"
          style={{ textShadow: '0 0 10px rgba(34, 211, 238, 0.85)' }}
        >
          {subtitle}
        </span>
        <span className="h-[1.5px] flex-1 max-w-[64px] bg-gradient-to-l from-transparent via-purple-400/75 to-cyan-300/90 rounded-full" />
      </div>
    </header>
  );
};

/* ============================================================================
   3. REUSABLE 3D NEON PILL CARD (EXACT SCREENSHOT BLUEPRINT & AUTO-FIT HEIGHT)
   ============================================================================ */

export interface ZoyaNeonMenuCardProps {
  title: string;
  subtitle: string;
  accentVariant: 'pink' | 'cyan';
  icon: React.ReactNode;
  onClick: () => void;
  testId?: string;
  flexibleHeight?: boolean;
}

export const ZoyaNeonMenuCard: React.FC<ZoyaNeonMenuCardProps> = ({
  title,
  subtitle,
  accentVariant,
  icon,
  onClick,
  testId,
  flexibleHeight = false,
}) => {
  const isPink = accentVariant === 'pink';

  return (
    <button
      type="button"
      onClick={onClick}
      data-testid={testId}
      className={`relative w-full ${
        flexibleHeight
          ? 'flex-1 min-h-[38px] py-1'
          : 'min-h-[48px] sm:min-h-[52px] py-1.5'
      } rounded-[18px] sm:rounded-[22px] pl-3.5 pr-2.5 sm:pr-3 flex items-center justify-between overflow-hidden cursor-pointer transition-all duration-150 active:scale-[0.985] group ${
        isPink ? 'zoya-neon-pill-pink' : 'zoya-neon-pill-cyan'
      }`}
    >
      {/* Left 3D Glowing Neon Crescent Lip */}
      <div
        className="absolute left-0 top-0 bottom-0 w-[16px] sm:w-[18px] rounded-l-[18px] sm:rounded-l-[20px] pointer-events-none"
        style={{
          background: isPink
            ? 'linear-gradient(180deg, #f472b6 0%, #d946ef 48%, #9333ea 100%)'
            : 'linear-gradient(180deg, #67e8f9 0%, #06b6d4 48%, #2563eb 100%)',
          boxShadow: isPink
            ? '4px 0 14px rgba(236, 72, 153, 0.85), inset 2px 0 2px rgba(255, 255, 255, 0.7)'
            : '4px 0 14px rgba(6, 182, 212, 0.85), inset 2px 0 2px rgba(255, 255, 255, 0.7)',
          clipPath: 'polygon(0 0, 100% 0, 52% 20%, 42% 50%, 52% 80%, 100% 100%, 0 100%)',
        }}
      />

      {/* Top Specular Gloss Line */}
      <div className="absolute top-0 left-6 right-8 h-[1.5px] bg-gradient-to-r from-white/55 via-white/25 to-transparent pointer-events-none" />

      {/* Right Diagonal Light Wave Sheen */}
      <div
        className="absolute right-10 inset-y-0 w-32 pointer-events-none opacity-45"
        style={{
          background: isPink
            ? 'linear-gradient(115deg, transparent 20%, rgba(168, 85, 247, 0.36) 50%, transparent 80%)'
            : 'linear-gradient(115deg, transparent 20%, rgba(56, 189, 248, 0.36) 50%, transparent 80%)',
        }}
      />

      {/* Left 3D Icon + Title & Subtitle */}
      <div className="relative z-10 flex items-center gap-2.5 sm:gap-3.5 min-w-0 pl-1.5 flex-1">
        <div className="shrink-0 w-[clamp(28px,4.5dvh,38px)] h-[clamp(28px,4.5dvh,38px)] flex items-center justify-center transition-transform duration-150 group-hover:scale-105 [&>svg]:w-full [&>svg]:h-full">
          {icon}
        </div>
        <div className="min-w-0 flex-1 text-left">
          <div
            className="text-[clamp(12.5px,1.9dvh,15.5px)] font-extrabold text-white tracking-tight leading-tight truncate"
            style={{ textShadow: '0 1px 6px rgba(0,0,0,0.75)' }}
          >
            {title}
          </div>
          <div className="text-[clamp(10px,1.45dvh,12px)] font-normal text-purple-100/90 leading-tight truncate mt-[1px]">
            {subtitle}
          </div>
        </div>
      </div>

      {/* Right Circular Neon Chevron Button (>) */}
      <div
        className="relative z-10 w-[clamp(24px,3.6dvh,31px)] h-[clamp(24px,3.6dvh,31px)] rounded-full flex items-center justify-center shrink-0 ml-2 transition-transform group-hover:translate-x-0.5"
        style={{
          background: 'radial-gradient(circle at 35% 30%, #3b1c71 0%, #17123a 70%, #0d0a24 100%)',
          border: isPink ? '1.5px solid rgba(192, 132, 252, 0.85)' : '1.5px solid rgba(56, 189, 248, 0.85)',
          boxShadow: isPink
            ? '0 0 10px rgba(168, 85, 247, 0.55), inset 0 1px 1px rgba(255,255,255,0.35)'
            : '0 0 10px rgba(56, 189, 248, 0.55), inset 0 1px 1px rgba(255,255,255,0.35)',
        }}
      >
        <svg viewBox="0 0 24 24" fill="none" className="w-[clamp(13px,2dvh,16px)] h-[clamp(13px,2dvh,16px)] text-white">
          <path
            d="M9.5 6.5L15 12L9.5 17.5"
            stroke="currentColor"
            strokeWidth="2.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      </div>
    </button>
  );
};

/* ============================================================================
   4. INSTAGRAM GROWTH SYSTEM — ZERO-RUPEE AUTOMATION SUBPAGE
   ============================================================================ */

interface IgGrowthConfig {
  zeroRupeeAutoEnabled: boolean;
  autoCommentToDmEnabled: boolean;
  autoHashtagSeoEnabled: boolean;
  dailyReelSchedulerEnabled: boolean;
  nicheTopic: string;
  triggerKeyword: string;
  autoDmMessage: string;
  preferredLanguage: 'Hinglish' | 'Hindi' | 'English';
}

const DEFAULT_IG_CONFIG: IgGrowthConfig = {
  zeroRupeeAutoEnabled: true,
  autoCommentToDmEnabled: true,
  autoHashtagSeoEnabled: true,
  dailyReelSchedulerEnabled: true,
  nicheTopic: 'AI Tech, Motivation & Digital Creator Growth',
  triggerKeyword: 'ZOYA',
  autoDmMessage: 'Hey Boss! Here is the free Zero-Rupee AI Automation guide & link you requested: https://zoya.ai/growth',
  preferredLanguage: 'Hinglish',
};

export const ZoyaInstagramGrowthSubpage: React.FC = () => {
  const [config, setConfig] = useState<IgGrowthConfig>(() => {
    try {
      const saved = localStorage.getItem('zoya_ig_growth_config');
      return saved ? { ...DEFAULT_IG_CONFIG, ...JSON.parse(saved) } : DEFAULT_IG_CONFIG;
    } catch {
      return DEFAULT_IG_CONFIG;
    }
  });

  const [generatedHook, setGeneratedHook] = useState<string>(
    '🔥 Stop spending ₹10,000 on ads! Yeh 3 Zero-Rupee AI tricks aapke Reels ko 7 din mein 10x viral kar dengi — #3 sabse powerful hai!'
  );
  const [generatedHashtags, setGeneratedHashtags] = useState<string>(
    '#InstagramGrowthIndia #ZeroRupeeMarketing #AIReelsIndia #ViralReelsHacks #DigitalCreatorIndia #ZoyaAI #ReelsAlgorithm2026 #OrganicReach #CreatorEconomy #ExplorePageIndia'
  );
  const [copiedLabel, setCopiedLabel] = useState<string>('');

  useEffect(() => {
    try {
      localStorage.setItem('zoya_ig_growth_config', JSON.stringify(config));
    } catch {}
  }, [config]);

  const handleGenerateViralPack = () => {
    const hooksByLang: Record<IgGrowthConfig['preferredLanguage'], string[]> = {
      Hinglish: [
        `🚀 "${config.nicheTopic}" mein 0 followers se 50K pahunchne ka Zero-Rupee Blueprint! Save kar lo warna kho jayega.`,
        `⚡ 99% creators yeh galti karte hain! Bina ₹1 kharch kiye Instagram Algorithm ko aise train karein (${config.nicheTopic}).`,
        `💎 Comment "${config.triggerKeyword}" aur main aapko free Zero-Rupee Automation Kit seedhe DM mein bhej dungi!`,
      ],
      Hindi: [
        `🔥 बिना एक रुपया खर्च किए "${config.nicheTopic}" में अपने रील्स को एक्सप्लोर पेज पर पहुँचाने के 3 गुप्त तरीके!`,
        `✨ आज ही इस ऑटोमेशन ट्रिक को अपनाएं और अपनी ऑर्गेनिक रीच 5 गुना बढ़ाएं। कमेंट में "${config.triggerKeyword}" लिखें!`,
      ],
      English: [
        `🚀 The Zero-Rupee Organic Growth Blueprint for ${config.nicheTopic}: 3 algorithm triggers that 10x your Reels retention in 48 hours!`,
        `⚡ Comment "${config.triggerKeyword}" below and my AI will automatically DM you the complete Zero-Rupee workflow!`,
      ],
    };
    const pool = hooksByLang[config.preferredLanguage];
    const nextHook = pool[Math.floor(Math.random() * pool.length)];
    setGeneratedHook(nextHook);

    const slug = config.nicheTopic
      .replace(/[^a-zA-Z0-9 ]/g, '')
      .split(' ')
      .filter(Boolean)
      .slice(0, 3)
      .join('');
    setGeneratedHashtags(
      `#${slug || 'AICreator'} #ZeroRupeeAutomation #InstagramGrowth2026 #ViralReelsIndia #ExplorePage #OrganicGrowthHacks #ZoyaAIAutomation #ReelsViralTrick #CreatorGrowthSystem #TrendingReelsIndia`
    );
  };

  const handleCopy = (text: string, label: string) => {
    try {
      navigator.clipboard.writeText(text);
      setCopiedLabel(label);
      setTimeout(() => setCopiedLabel(''), 2000);
    } catch {}
  };

  return (
    <div className="space-y-3.5 text-white pb-6">
      {/* Hero Banner Card */}
      <div className="zoya-neon-pill-pink rounded-[22px] p-4 relative overflow-hidden">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <NeonInstagram3DIcon className="w-11 h-11 shrink-0" />
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-[15px] sm:text-[16px] font-extrabold text-white">
                  Zero-Rupee Growth Engine
                </h3>
                <span className="px-2 py-0.5 text-[10px] font-bold rounded-full bg-pink-500/30 border border-pink-400/60 text-pink-200">
                  ₹0 ACTIVE
                </span>
              </div>
              <p className="text-xs text-purple-100/85 mt-0.5">
                100% Free Organic Reels SEO, Viral Hooks & Comment-to-DM Automation
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() =>
              setConfig((prev) => ({ ...prev, zeroRupeeAutoEnabled: !prev.zeroRupeeAutoEnabled }))
            }
            className={`relative inline-flex h-7 w-13 shrink-0 cursor-pointer rounded-full border transition-all ${
              config.zeroRupeeAutoEnabled
                ? 'bg-gradient-to-r from-pink-500 to-purple-600 border-pink-300 shadow-[0_0_14px_rgba(236,72,153,0.8)]'
                : 'bg-slate-800 border-slate-600'
            }`}
          >
            <span
              className={`inline-block h-5.5 w-5.5 transform rounded-full bg-white shadow-md transition-transform mt-0.5 ${
                config.zeroRupeeAutoEnabled ? 'translate-x-6.5' : 'translate-x-0.5'
              }`}
            />
          </button>
        </div>
      </div>

      {/* Automation Toggles Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
        <button
          type="button"
          onClick={() =>
            setConfig((prev) => ({ ...prev, autoCommentToDmEnabled: !prev.autoCommentToDmEnabled }))
          }
          className="zoya-neon-pill-cyan rounded-[18px] p-3 text-left flex items-center justify-between gap-2 cursor-pointer"
        >
          <div className="flex items-center gap-2.5 min-w-0">
            <MessageCircle className="w-5 h-5 text-cyan-300 shrink-0" />
            <div className="min-w-0">
              <div className="text-xs font-bold text-white truncate">Comment-to-DM</div>
              <div className="text-[10.5px] text-cyan-200/80 truncate">
                Keyword: "{config.triggerKeyword}"
              </div>
            </div>
          </div>
          <span
            className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
              config.autoCommentToDmEnabled
                ? 'bg-emerald-500/25 text-emerald-300 border border-emerald-400/50'
                : 'bg-slate-800 text-slate-400'
            }`}
          >
            {config.autoCommentToDmEnabled ? 'ON' : 'OFF'}
          </span>
        </button>

        <button
          type="button"
          onClick={() =>
            setConfig((prev) => ({ ...prev, autoHashtagSeoEnabled: !prev.autoHashtagSeoEnabled }))
          }
          className="zoya-neon-pill-pink rounded-[18px] p-3 text-left flex items-center justify-between gap-2 cursor-pointer"
        >
          <div className="flex items-center gap-2.5 min-w-0">
            <Hash className="w-5 h-5 text-pink-300 shrink-0" />
            <div className="min-w-0">
              <div className="text-xs font-bold text-white truncate">Smart Hashtag SEO</div>
              <div className="text-[10.5px] text-purple-200/80 truncate">Explore Page Booster</div>
            </div>
          </div>
          <span
            className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
              config.autoHashtagSeoEnabled
                ? 'bg-emerald-500/25 text-emerald-300 border border-emerald-400/50'
                : 'bg-slate-800 text-slate-400'
            }`}
          >
            {config.autoHashtagSeoEnabled ? 'ON' : 'OFF'}
          </span>
        </button>

        <button
          type="button"
          onClick={() =>
            setConfig((prev) => ({
              ...prev,
              dailyReelSchedulerEnabled: !prev.dailyReelSchedulerEnabled,
            }))
          }
          className="zoya-neon-pill-cyan rounded-[18px] p-3 text-left flex items-center justify-between gap-2 cursor-pointer"
        >
          <div className="flex items-center gap-2.5 min-w-0">
            <Clock className="w-5 h-5 text-cyan-300 shrink-0" />
            <div className="min-w-0">
              <div className="text-xs font-bold text-white truncate">Peak Slot Alerts</div>
              <div className="text-[10.5px] text-cyan-200/80 truncate">9 AM • 3 PM • 7:30 PM</div>
            </div>
          </div>
          <span
            className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
              config.dailyReelSchedulerEnabled
                ? 'bg-emerald-500/25 text-emerald-300 border border-emerald-400/50'
                : 'bg-slate-800 text-slate-400'
            }`}
          >
            {config.dailyReelSchedulerEnabled ? 'ON' : 'OFF'}
          </span>
        </button>
      </div>

      {/* Niche & Trigger Configuration Card */}
      <div className="zoya-neon-pill-cyan rounded-[20px] p-4 space-y-3">
        <div className="flex items-center justify-between">
          <h4 className="text-xs sm:text-sm font-extrabold text-white flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-cyan-300" />
            Creator Niche & Auto-DM Trigger Setup
          </h4>
          <div className="flex items-center gap-1">
            {(['Hinglish', 'Hindi', 'English'] as const).map((lang) => (
              <button
                key={lang}
                type="button"
                onClick={() => setConfig((prev) => ({ ...prev, preferredLanguage: lang }))}
                className={`px-2.5 py-1 rounded-full text-[10.5px] font-bold cursor-pointer transition-all ${
                  config.preferredLanguage === lang
                    ? 'bg-gradient-to-r from-cyan-500 to-purple-600 text-white shadow-[0_0_10px_rgba(34,211,238,0.5)]'
                    : 'bg-[#0e0c2a] text-purple-200/75 border border-purple-500/40'
                }`}
              >
                {lang}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          <div>
            <label className="block text-[11px] font-semibold text-cyan-200 mb-1">
              Your Content Niche / Topic
            </label>
            <input
              type="text"
              value={config.nicheTopic}
              onChange={(e) => setConfig((prev) => ({ ...prev, nicheTopic: e.target.value }))}
              className="w-full px-3 py-2 rounded-xl bg-[#090820] border border-cyan-400/50 text-xs text-white outline-none focus:border-cyan-300"
              placeholder="e.g., AI Tech, Fitness, Finance"
            />
          </div>
          <div>
            <label className="block text-[11px] font-semibold text-pink-200 mb-1">
              Comment Trigger Keyword
            </label>
            <input
              type="text"
              value={config.triggerKeyword}
              onChange={(e) =>
                setConfig((prev) => ({ ...prev, triggerKeyword: e.target.value.toUpperCase() }))
              }
              className="w-full px-3 py-2 rounded-xl bg-[#090820] border border-pink-400/50 text-xs text-white font-bold outline-none focus:border-pink-300"
              placeholder="ZOYA"
            />
          </div>
        </div>

        <div>
          <label className="block text-[11px] font-semibold text-purple-200 mb-1">
            Zero-Rupee Auto-DM Reply Template
          </label>
          <input
            type="text"
            value={config.autoDmMessage}
            onChange={(e) => setConfig((prev) => ({ ...prev, autoDmMessage: e.target.value }))}
            className="w-full px-3 py-2 rounded-xl bg-[#090820] border border-purple-400/50 text-xs text-white outline-none focus:border-purple-300"
          />
        </div>
      </div>

      {/* Viral Hook & Hashtag Generator Card */}
      <div className="zoya-neon-pill-pink rounded-[20px] p-4 space-y-3">
        <div className="flex items-center justify-between gap-2">
          <h4 className="text-xs sm:text-sm font-extrabold text-white flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-pink-300" />
            AI Viral Reel Hook & SEO Pack
          </h4>
          <button
            type="button"
            onClick={handleGenerateViralPack}
            className="px-3 py-1.5 rounded-full bg-gradient-to-r from-pink-500 via-fuchsia-500 to-purple-600 text-white text-xs font-bold flex items-center gap-1.5 shadow-[0_0_14px_rgba(236,72,153,0.65)] active:scale-95 cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            Generate New Pack
          </button>
        </div>

        <div className="p-3 rounded-xl bg-[#0b0824]/90 border border-purple-400/45 space-y-1.5">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-pink-300">Viral 3-Second Reel Hook</span>
            <button
              type="button"
              onClick={() => handleCopy(generatedHook, 'hook')}
              className="text-[11px] text-cyan-300 hover:text-white flex items-center gap-1 cursor-pointer"
            >
              {copiedLabel === 'hook' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              {copiedLabel === 'hook' ? 'Copied!' : 'Copy Hook'}
            </button>
          </div>
          <p className="text-xs text-white leading-relaxed">{generatedHook}</p>
        </div>

        <div className="p-3 rounded-xl bg-[#0b0824]/90 border border-cyan-400/45 space-y-1.5">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-cyan-300">Zero-Rupee Explore Hashtags</span>
            <button
              type="button"
              onClick={() => handleCopy(generatedHashtags, 'tags')}
              className="text-[11px] text-cyan-300 hover:text-white flex items-center gap-1 cursor-pointer"
            >
              {copiedLabel === 'tags' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              {copiedLabel === 'tags' ? 'Copied!' : 'Copy Tags'}
            </button>
          </div>
          <p className="text-[11px] text-cyan-100/90 font-mono leading-relaxed break-words">
            {generatedHashtags}
          </p>
        </div>
      </div>
    </div>
  );
};
