import React, { useState, useEffect } from 'react';
import { Heart, CheckCircle2, Send, BookHeart, Trash2, PlusCircle, Loader2 } from 'lucide-react';

export interface LoveModeEntry {
  id: string;
  createdAt: string;
  q1PainFace: string;
  q2BrokenNight: string;
  q3DidMostForWhom: string;
  q4TearsMemory: string;
  q5Forgiveness: string;
  q6FirstWords: string;
  q7PainDepth: number | null;
  q8WhenBrokenAction: string;
  q9MostMissed: string;
  q10TrulyUnderstood: string;
  q11LetterToSelf: string;
}

const DRAFT_STORAGE_KEY = 'zoya_love_mode_draft_v1';
const ENTRIES_STORAGE_KEY = 'zoya_love_mode_entries_v1';

const CONFIRMATION_MESSAGE =
  'तुमने अपना दिल खोलकर रख दिया, यह हिम्मत का काम है। तुम्हारा दर्द सच्चा है, और तुम अकेले नहीं हो। अगर मन बहुत भारी है, तो किसी भरोसेमंद इंसान से ज़रूर बात करना।';

const Q8_OPTIONS = [
  'चुप हो जाता हूँ',
  'रो लेता हूँ',
  'हँसकर छुपा लेता हूँ',
  'किसी को बताता हूँ',
];

const Q9_OPTIONS = [
  'साथ',
  'भरोसा',
  'परवाह',
  'कोई अपना',
];

const Q10_OPTIONS = [
  'हाँ',
  'नहीं',
  'शायद',
  'पता नहीं',
];

interface DraftState {
  q1PainFace: string;
  q2BrokenNight: string;
  q3DidMostForWhom: string;
  q4TearsMemory: string;
  q5Forgiveness: string;
  q6FirstWords: string;
  q7PainDepth: number | null;
  q8WhenBrokenAction: string;
  q9MostMissed: string;
  q10TrulyUnderstood: string;
  q11LetterToSelf: string;
}

const EMPTY_DRAFT: DraftState = {
  q1PainFace: '',
  q2BrokenNight: '',
  q3DidMostForWhom: '',
  q4TearsMemory: '',
  q5Forgiveness: '',
  q6FirstWords: '',
  q7PainDepth: null,
  q8WhenBrokenAction: '',
  q9MostMissed: '',
  q10TrulyUnderstood: '',
  q11LetterToSelf: '',
};

export const LoveModeReflectionPanel: React.FC = () => {
  const [draft, setDraft] = useState<DraftState>(() => {
    try {
      const saved = localStorage.getItem(DRAFT_STORAGE_KEY);
      if (saved) return { ...EMPTY_DRAFT, ...JSON.parse(saved) };
    } catch {}
    return EMPTY_DRAFT;
  });

  const [entries, setEntries] = useState<LoveModeEntry[]>(() => {
    try {
      const saved = localStorage.getItem(ENTRIES_STORAGE_KEY);
      if (saved) return JSON.parse(saved);
    } catch {}
    return [];
  });

  const [activeTab, setActiveTab] = useState<'write' | 'saved'>('write');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submittedEntry, setSubmittedEntry] = useState<LoveModeEntry | null>(null);
  const [formError, setFormError] = useState<string | null>(null);

  useEffect(() => {
    try {
      localStorage.setItem(DRAFT_STORAGE_KEY, JSON.stringify(draft));
    } catch {}
  }, [draft]);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch('/api/love-mode/entries');
        if (!res.ok) return;
        const data = await res.json();
        if (!cancelled && data?.success && Array.isArray(data.entries)) {
          setEntries(data.entries);
          try {
            localStorage.setItem(ENTRIES_STORAGE_KEY, JSON.stringify(data.entries));
          } catch {}
        }
      } catch {
        // Fallback to localStorage entries silently
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  const updateField = <K extends keyof DraftState>(key: K, value: DraftState[K]) => {
    setFormError(null);
    setDraft((prev) => ({ ...prev, [key]: value }));
  };

  const hasAnyAnswer =
    draft.q1PainFace.trim() !== '' ||
    draft.q2BrokenNight.trim() !== '' ||
    draft.q3DidMostForWhom.trim() !== '' ||
    draft.q4TearsMemory.trim() !== '' ||
    draft.q5Forgiveness.trim() !== '' ||
    draft.q6FirstWords.trim() !== '' ||
    draft.q7PainDepth !== null ||
    draft.q8WhenBrokenAction !== '' ||
    draft.q9MostMissed !== '' ||
    draft.q10TrulyUnderstood !== '' ||
    draft.q11LetterToSelf.trim() !== '';

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSubmitting) return;

    if (!hasAnyAnswer) {
      setFormError('कम से कम एक बात लिखो या चुनो — खामोशी के बीच भी एक सच काफी है।');
      return;
    }

    setIsSubmitting(true);
    setFormError(null);

    const newEntry: LoveModeEntry = {
      id: `love_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
      createdAt: new Date().toISOString(),
      ...draft,
    };

    try {
      const res = await fetch('/api/love-mode/entries', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newEntry),
      });
      const data = await res.json().catch(() => null);
      const savedEntry: LoveModeEntry = data?.entry || newEntry;

      setEntries((prev) => {
        const next = [savedEntry, ...prev.filter((item) => item.id !== savedEntry.id)];
        try {
          localStorage.setItem(ENTRIES_STORAGE_KEY, JSON.stringify(next));
        } catch {}
        return next;
      });
      setSubmittedEntry(savedEntry);
      setDraft(EMPTY_DRAFT);
      try {
        localStorage.removeItem(DRAFT_STORAGE_KEY);
      } catch {}
    } catch {
      setEntries((prev) => {
        const next = [newEntry, ...prev];
        try {
          localStorage.setItem(ENTRIES_STORAGE_KEY, JSON.stringify(next));
        } catch {}
        return next;
      });
      setSubmittedEntry(newEntry);
      setDraft(EMPTY_DRAFT);
      try {
        localStorage.removeItem(DRAFT_STORAGE_KEY);
      } catch {}
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeleteEntry = async (id: string) => {
    setEntries((prev) => {
      const next = prev.filter((item) => item.id !== id);
      try {
        localStorage.setItem(ENTRIES_STORAGE_KEY, JSON.stringify(next));
      } catch {}
      return next;
    });
    try {
      await fetch(`/api/love-mode/entries/${encodeURIComponent(id)}`, { method: 'DELETE' });
    } catch {}
  };

  return (
    <div
      data-testid="love-mode-reflection-panel"
      className="rounded-[24px] bg-[#13182e] border border-pink-400/30 shadow-[0_0_25px_rgba(236,72,153,0.12)] overflow-hidden"
    >
      {/* Header Banner */}
      <div className="p-5 bg-gradient-to-br from-[#1f1638] via-[#181b36] to-[#13182e] border-b border-pink-400/20 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-pink-500/20 border border-pink-400/35 text-pink-300 flex items-center justify-center shrink-0">
              <Heart className="w-4.5 h-4.5" />
            </div>
            <div>
              <span className="text-[11px] font-bold uppercase tracking-wider text-pink-300">
                Love Mode • अंतरंग डायरी
              </span>
              <h2 className="text-[20px] font-extrabold text-[#F3F5FF] leading-snug">
                जो कभी किसी से नहीं कहा
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-1.5 bg-[#0E1224] p-1 rounded-xl border border-[#262D4D]">
            <button
              type="button"
              onClick={() => setActiveTab('write')}
              className={`px-3 py-1.5 rounded-lg text-[12px] font-bold transition-colors cursor-pointer ${
                activeTab === 'write'
                  ? 'bg-pink-500/25 text-pink-200 border border-pink-400/40'
                  : 'text-[#A7AFD0] hover:text-white'
              }`}
            >
              लिखें
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('saved')}
              className={`px-3 py-1.5 rounded-lg text-[12px] font-bold transition-colors cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'saved'
                  ? 'bg-pink-500/25 text-pink-200 border border-pink-400/40'
                  : 'text-[#A7AFD0] hover:text-white'
              }`}
            >
              <BookHeart className="w-3.5 h-3.5" />
              <span>सहेजी बातें ({entries.length})</span>
            </button>
          </div>
        </div>

        <p className="text-[13.5px] leading-relaxed text-[#D8DDF8] font-medium">
          यह जगह सिर्फ़ तुम्हारी है। यहाँ आँसू भी चलेंगे, खामोशी भी, और अधूरी बातें भी। जो सच है, वही लिखना।
        </p>
      </div>

      {/* Confirmation State */}
      {activeTab === 'write' && submittedEntry && (
        <div className="p-5 space-y-4">
          <div
            data-testid="love-mode-confirmation"
            className="p-5 rounded-2xl bg-gradient-to-br from-pink-500/15 via-purple-500/10 to-[#171C33] border border-pink-400/40 space-y-3"
          >
            <div className="flex items-center gap-2 text-pink-300 font-bold text-[15px]">
              <CheckCircle2 className="w-5 h-5 shrink-0" />
              <span>सहेजा गया</span>
            </div>
            <p className="text-[14.5px] leading-relaxed text-[#F3F5FF] font-medium">
              {CONFIRMATION_MESSAGE}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={() => setSubmittedEntry(null)}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-pink-500/20 hover:bg-pink-500/30 border border-pink-400/40 text-pink-200 text-[13px] font-bold transition-colors cursor-pointer"
            >
              <PlusCircle className="w-4 h-4" />
              <span>फिर से कुछ लिखें</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setSubmittedEntry(null);
                setActiveTab('saved');
              }}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#1C2342] hover:bg-[#232b50] border border-[#323C69] text-[#D8DDF8] text-[13px] font-bold transition-colors cursor-pointer"
            >
              <BookHeart className="w-4 h-4" />
              <span>सहेजी हुई बातें देखें ({entries.length})</span>
            </button>
          </div>
        </div>
      )}

      {/* Questionnaire Form */}
      {activeTab === 'write' && !submittedEntry && (
        <form onSubmit={handleSubmit} className="p-5 space-y-5">
          {/* 1. Long Answer */}
          <div className="space-y-2">
            <label className="block text-[14px] font-bold text-[#F3F5FF]">
              1. अगर तुम्हारा दर्द एक चेहरा होता, तो वह कैसा दिखता?
            </label>
            <textarea
              rows={3}
              value={draft.q1PainFace}
              onChange={(e) => updateField('q1PainFace', e.target.value)}
              placeholder="लंबा जवाब लिखो..."
              className="w-full rounded-xl bg-[#0E1224] border border-[#262D4D] focus:border-pink-400/60 focus:outline-none px-3.5 py-2.5 text-[13.5px] text-[#F3F5FF] placeholder-[#6B7499] resize-y"
            />
          </div>

          {/* 2. Long Answer */}
          <div className="space-y-2">
            <label className="block text-[14px] font-bold text-[#F3F5FF]">
              2. वह कौन सी रात थी जब तुम सबसे ज़्यादा टूटे? उस रात क्या हुआ था?
            </label>
            <textarea
              rows={3}
              value={draft.q2BrokenNight}
              onChange={(e) => updateField('q2BrokenNight', e.target.value)}
              placeholder="लंबा जवाब लिखो..."
              className="w-full rounded-xl bg-[#0E1224] border border-[#262D4D] focus:border-pink-400/60 focus:outline-none px-3.5 py-2.5 text-[13.5px] text-[#F3F5FF] placeholder-[#6B7499] resize-y"
            />
          </div>

          {/* 3. Long Answer */}
          <div className="space-y-2">
            <label className="block text-[14px] font-bold text-[#F3F5FF]">
              3. किसके लिए तुमने सबसे ज़्यादा किया, और बदले में क्या मिला?
            </label>
            <textarea
              rows={3}
              value={draft.q3DidMostForWhom}
              onChange={(e) => updateField('q3DidMostForWhom', e.target.value)}
              placeholder="लंबा जवाब लिखो..."
              className="w-full rounded-xl bg-[#0E1224] border border-[#262D4D] focus:border-pink-400/60 focus:outline-none px-3.5 py-2.5 text-[13.5px] text-[#F3F5FF] placeholder-[#6B7499] resize-y"
            />
          </div>

          {/* 4. Long Answer */}
          <div className="space-y-2">
            <label className="block text-[14px] font-bold text-[#F3F5FF]">
              4. वह कौन सी बात है जिसे सोचकर आज भी आँखें भर आती हैं?
            </label>
            <textarea
              rows={3}
              value={draft.q4TearsMemory}
              onChange={(e) => updateField('q4TearsMemory', e.target.value)}
              placeholder="लंबा जवाब लिखो..."
              className="w-full rounded-xl bg-[#0E1224] border border-[#262D4D] focus:border-pink-400/60 focus:outline-none px-3.5 py-2.5 text-[13.5px] text-[#F3F5FF] placeholder-[#6B7499] resize-y"
            />
          </div>

          {/* 5. Short Answer */}
          <div className="space-y-2">
            <label className="block text-[14px] font-bold text-[#F3F5FF]">
              5. किसे तुम माफ़ करना चाहते हो, और किससे माफ़ी चाहते हो?
            </label>
            <input
              type="text"
              value={draft.q5Forgiveness}
              onChange={(e) => updateField('q5Forgiveness', e.target.value)}
              placeholder="छोटा जवाब लिखो..."
              className="w-full rounded-xl bg-[#0E1224] border border-[#262D4D] focus:border-pink-400/60 focus:outline-none px-3.5 py-2.5 text-[13.5px] text-[#F3F5FF] placeholder-[#6B7499]"
            />
          </div>

          {/* 6. Long Answer */}
          <div className="space-y-2">
            <label className="block text-[14px] font-bold text-[#F3F5FF]">
              6. अगर वह इंसान आज सामने आ जाए, तो पहली बात क्या कहोगे?
            </label>
            <textarea
              rows={3}
              value={draft.q6FirstWords}
              onChange={(e) => updateField('q6FirstWords', e.target.value)}
              placeholder="लंबा जवाब लिखो..."
              className="w-full rounded-xl bg-[#0E1224] border border-[#262D4D] focus:border-pink-400/60 focus:outline-none px-3.5 py-2.5 text-[13.5px] text-[#F3F5FF] placeholder-[#6B7499] resize-y"
            />
          </div>

          {/* 7. Linear Scale 1 to 10 */}
          <div className="space-y-2.5">
            <label className="block text-[14px] font-bold text-[#F3F5FF]">
              7. तुम्हारा दर्द अभी कितना गहरा है? (1 से 10)
            </label>
            <div className="grid grid-cols-5 sm:grid-cols-10 gap-2">
              {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((num) => {
                const selected = draft.q7PainDepth === num;
                return (
                  <button
                    key={num}
                    type="button"
                    onClick={() => updateField('q7PainDepth', num)}
                    className={`h-10 rounded-xl font-bold text-[13.5px] border transition-all cursor-pointer ${
                      selected
                        ? 'bg-pink-500 text-white border-pink-300 shadow-[0_0_12px_rgba(236,72,153,0.45)]'
                        : 'bg-[#0E1224] text-[#C4CBE8] border-[#262D4D] hover:border-pink-400/40'
                    }`}
                  >
                    {num}
                  </button>
                );
              })}
            </div>
            <div className="flex justify-between text-[11px] text-[#8E97BC] font-medium px-0.5">
              <span>1 — हल्का</span>
              <span>10 — बहुत गहरा</span>
            </div>
          </div>

          {/* 8. Single Choice */}
          <div className="space-y-2.5">
            <label className="block text-[14px] font-bold text-[#F3F5FF]">
              8. जब तुम टूटते हो, तब तुम क्या करते हो?
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {Q8_OPTIONS.map((opt) => {
                const selected = draft.q8WhenBrokenAction === opt;
                return (
                  <button
                    key={opt}
                    type="button"
                    onClick={() => updateField('q8WhenBrokenAction', opt)}
                    className={`px-3.5 py-2.5 rounded-xl border text-left text-[13px] font-semibold flex items-center gap-2.5 transition-all cursor-pointer ${
                      selected
                        ? 'bg-pink-500/20 border-pink-400 text-[#F3F5FF]'
                        : 'bg-[#0E1224] border-[#262D4D] text-[#B8C0E0] hover:border-pink-400/40'
                    }`}
                  >
                    <span
                      className={`w-4 h-4 rounded-full border flex items-center justify-center shrink-0 ${
                        selected ? 'border-pink-300 bg-pink-500' : 'border-[#4A5584]'
                      }`}
                    >
                      {selected && <span className="w-1.5 h-1.5 rounded-full bg-white" />}
                    </span>
                    <span>{opt}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* 9. Single Choice */}
          <div className="space-y-2.5">
            <label className="block text-[14px] font-bold text-[#F3F5FF]">
              9. तुम्हें सबसे ज़्यादा किस चीज़ की कमी खलती है?
            </label>
            <div className="grid grid-cols-2 gap-2">
              {Q9_OPTIONS.map((opt) => {
                const selected = draft.q9MostMissed === opt;
                return (
                  <button
                    key={opt}
                    type="button"
                    onClick={() => updateField('q9MostMissed', opt)}
                    className={`px-3.5 py-2.5 rounded-xl border text-left text-[13px] font-semibold flex items-center gap-2.5 transition-all cursor-pointer ${
                      selected
                        ? 'bg-pink-500/20 border-pink-400 text-[#F3F5FF]'
                        : 'bg-[#0E1224] border-[#262D4D] text-[#B8C0E0] hover:border-pink-400/40'
                    }`}
                  >
                    <span
                      className={`w-4 h-4 rounded-full border flex items-center justify-center shrink-0 ${
                        selected ? 'border-pink-300 bg-pink-500' : 'border-[#4A5584]'
                      }`}
                    >
                      {selected && <span className="w-1.5 h-1.5 rounded-full bg-white" />}
                    </span>
                    <span>{opt}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* 10. Single Choice */}
          <div className="space-y-2.5">
            <label className="block text-[14px] font-bold text-[#F3F5FF]">
              10. क्या तुम्हें कभी किसी ने सच में समझा है?
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {Q10_OPTIONS.map((opt) => {
                const selected = draft.q10TrulyUnderstood === opt;
                return (
                  <button
                    key={opt}
                    type="button"
                    onClick={() => updateField('q10TrulyUnderstood', opt)}
                    className={`px-3.5 py-2.5 rounded-xl border text-left text-[13px] font-semibold flex items-center gap-2.5 transition-all cursor-pointer ${
                      selected
                        ? 'bg-pink-500/20 border-pink-400 text-[#F3F5FF]'
                        : 'bg-[#0E1224] border-[#262D4D] text-[#B8C0E0] hover:border-pink-400/40'
                    }`}
                  >
                    <span
                      className={`w-4 h-4 rounded-full border flex items-center justify-center shrink-0 ${
                        selected ? 'border-pink-300 bg-pink-500' : 'border-[#4A5584]'
                      }`}
                    >
                      {selected && <span className="w-1.5 h-1.5 rounded-full bg-white" />}
                    </span>
                    <span>{opt}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* 11. Long Answer Letter to Self */}
          <div className="space-y-2">
            <label className="block text-[14px] font-bold text-[#F3F5FF]">
              11. अपने आप को एक चिट्ठी लिखो: उस इंसान को जो सबसे ज़्यादा थका हुआ है।
            </label>
            <textarea
              rows={4}
              value={draft.q11LetterToSelf}
              onChange={(e) => updateField('q11LetterToSelf', e.target.value)}
              placeholder="अपने सबसे थके हुए रूप के नाम एक चिट्ठी लिखो..."
              className="w-full rounded-xl bg-[#0E1224] border border-[#262D4D] focus:border-pink-400/60 focus:outline-none px-3.5 py-2.5 text-[13.5px] text-[#F3F5FF] placeholder-[#6B7499] resize-y"
            />
          </div>

          {formError && (
            <div className="px-3.5 py-2.5 rounded-xl bg-rose-500/15 border border-rose-400/35 text-rose-200 text-[12.5px] font-medium">
              {formError}
            </div>
          )}

          <div className="pt-1 flex items-center justify-end">
            <button
              type="submit"
              disabled={isSubmitting}
              data-testid="love-mode-submit-btn"
              className="inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-400 hover:to-purple-500 text-white font-bold text-[14px] shadow-[0_0_20px_rgba(236,72,153,0.35)] transition-all cursor-pointer disabled:opacity-60"
            >
              {isSubmitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
              <span>{isSubmitting ? 'सहेजा जा रहा है...' : 'दिल की बात सहेजें'}</span>
            </button>
          </div>
        </form>
      )}

      {/* Saved Entries Tab */}
      {activeTab === 'saved' && (
        <div className="p-5 space-y-4">
          {entries.length === 0 ? (
            <div className="p-6 rounded-2xl bg-[#0E1224] border border-[#262D4D] text-center space-y-2">
              <p className="text-[14px] font-semibold text-[#D8DDF8]">
                अभी कोई बात सहेजी नहीं गई है।
              </p>
              <button
                type="button"
                onClick={() => setActiveTab('write')}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-pink-500/20 border border-pink-400/35 text-pink-200 text-[12.5px] font-bold cursor-pointer"
              >
                <PlusCircle className="w-3.5 h-3.5" />
                <span>पहली बात लिखें</span>
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              {entries.map((entry) => (
                <div
                  key={entry.id}
                  className="p-4 rounded-2xl bg-[#0E1224] border border-[#262D4D] space-y-2.5"
                >
                  <div className="flex items-center justify-between gap-2 border-b border-[#1E2440] pb-2">
                    <span className="text-[12px] font-semibold text-pink-300">
                      {new Date(entry.createdAt).toLocaleString('hi-IN')}
                      {entry.q7PainDepth !== null ? ` • दर्द स्तर: ${entry.q7PainDepth}/10` : ''}
                    </span>
                    <button
                      type="button"
                      onClick={() => handleDeleteEntry(entry.id)}
                      className="p-1.5 rounded-lg text-[#8E97BC] hover:text-rose-300 hover:bg-rose-500/10 transition-colors cursor-pointer"
                      title="हटाएं"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <div className="space-y-1.5 text-[12.5px] text-[#D8DDF8]">
                    {entry.q1PainFace && <p><strong className="text-pink-200">दर्द का चेहरा:</strong> {entry.q1PainFace}</p>}
                    {entry.q2BrokenNight && <p><strong className="text-pink-200">सबसे भारी रात:</strong> {entry.q2BrokenNight}</p>}
                    {entry.q3DidMostForWhom && <p><strong className="text-pink-200">सबसे ज़्यादा किया:</strong> {entry.q3DidMostForWhom}</p>}
                    {entry.q4TearsMemory && <p><strong className="text-pink-200">आँखें भर आने वाली बात:</strong> {entry.q4TearsMemory}</p>}
                    {entry.q5Forgiveness && <p><strong className="text-pink-200">माफ़ी:</strong> {entry.q5Forgiveness}</p>}
                    {entry.q6FirstWords && <p><strong className="text-pink-200">पहली बात:</strong> {entry.q6FirstWords}</p>}
                    {entry.q8WhenBrokenAction && <p><strong className="text-pink-200">टूटने पर:</strong> {entry.q8WhenBrokenAction}</p>}
                    {entry.q9MostMissed && <p><strong className="text-pink-200">सबसे ज़्यादा कमी:</strong> {entry.q9MostMissed}</p>}
                    {entry.q10TrulyUnderstood && <p><strong className="text-pink-200">किसी ने समझा:</strong> {entry.q10TrulyUnderstood}</p>}
                    {entry.q11LetterToSelf && (
                      <p className="pt-1 border-t border-[#1E2440]">
                        <strong className="text-pink-200">अपने नाम चिट्ठी:</strong> {entry.q11LetterToSelf}
                      </p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
