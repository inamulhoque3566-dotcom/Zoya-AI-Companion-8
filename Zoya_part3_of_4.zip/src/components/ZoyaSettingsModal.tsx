import React, { useState, useEffect, useRef } from 'react';
import {
  ChevronLeft,
  ChevronRight,
  Home,
  Hexagon,
  Disc,
  User,
  AudioLines,
  Globe,
  Heart,
  PlaySquare,
  Code2,
  Lock,
  Accessibility,
  KeyRound,
  PenTool,
  Brain,
  Check,
  Settings,
  Sparkles,
  ExternalLink,
  Volume2,
  Mic,
  Sliders,
  Search,
  Play,
  Square,
  RotateCw,
  Crown,
  Briefcase,
  Laugh,
  HeartHandshake,
  GraduationCap,
  Utensils,
  Drama,
  Palette,
  Eye,
  EyeOff,
  Smartphone,
  Shield,
  ShieldCheck,
  AlertTriangle,
  Trash2,
  Copy,
  Zap,
  CheckCircle2,
  Activity,
  Layers,
  Maximize2,
  ZoomIn,
  Power,
  RotateCcw,
  BatteryCharging,
  Battery,
  Upload,
  Bell,
  BellOff,
  Info,
  Plane,
  Package,
  Download,
  Loader2,
} from 'lucide-react';
import { batteryAlertSystem, BatteryAlertStatus } from '../services/battery/batteryAlertSystem';
import { themeManager, APP_THEMES, AppThemeId } from '../services/themeManager';
import { ZoyaMemoryView } from './ZoyaMemoryView';
import { ZoyaAccessibilitySettings } from './ZoyaAccessibilitySettings';
import { ZoyaDeviceLockSettings } from './ZoyaDeviceLockSettings';
import { ZoyaYouTubeSettings } from './ZoyaYouTubeSettings';
import { ZoyaHologramSettings } from './ZoyaHologramSettings';
import { ZoyaInstagramGrowthSubpage } from './ZoyaNeonSettingsElements';
import { LoveModeReflectionPanel } from './LoveModeReflectionPanel';
import type { HardwareStateInfo } from '../services/speech/SpeechTypes';
import type { MicPermissionState } from '../services/speech/SpeechRecognizerManager';
import { speechManager } from '../services/speech/SpeechRecognizerManager';

import { ZoyaLiving3DAvatar } from './3d/ZoyaLiving3DAvatar';
import { BlinkingAvatarImage } from './avatar/BlinkingAvatarImage';
import { ZoyaSmallListeningIndicator } from './voice/ZoyaSmallListeningIndicator';
import type { AvatarStyle } from './ZoyaAvatarDisplay';
import {
  ANIME_3D_AVATARS,
  getAllAvatars,
  saveCustomAvatar,
  deleteCustomAvatar,
  getSaved3DAvatarId,
  save3DAvatarId,
  getIs3DAvatarEnabled,
  saveIs3DAvatarEnabled,
  get3DAvatarScale,
  save3DAvatarScale,
  get3DAvatarOffsetY,
  save3DAvatarOffsetY,
  get3DAvatarLiveliness,
  save3DAvatarLiveliness,
  type Anime3DAvatar,
} from '../data/anime3DAvatars';
import {
  INDIAN_LANGUAGES,
  IndianLanguageConfig,
  getLanguageConfig,
} from '../services/languageConfig';
import {
  zoyaVoiceManager,
  ZOYA_AVAILABLE_VOICES,
  ZoyaVoiceItem,
} from '../services/zoyaVoiceManager';
import {
  TOOL_API_KEYS_REGISTRY,
  ToolApiKeyDefinition,
  getAllToolApiKeys,
  setToolApiKey,
  BRAND_PALETTE_PRESETS,
  BrandPresetId,
  getBrandGuidelinesConfig,
  saveBrandGuidelinesConfig,
} from '../services/toolApiKeysConfig';
import {
  getDecryptedSecretSync,
  storeEncryptedSecret,
  purgeDeprecatedClientSecrets,
  runSecretVaultSelfTest,
  SecretVaultSelfTestResult,
} from '../services/secretVault';
import { testElevenLabsConnection } from '../services/ttsDiagnosticService';
import { agentClient } from '../services/agent/agentClient';

export interface ZoyaSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  avatarStyle: AvatarStyle;
  setAvatarStyle: (style: AvatarStyle) => void;
  personaMode: string;
  setPersonaMode: (mode: string) => void;
  voiceSpeed: number;
  setVoiceSpeed: (speed: number) => void;
  voiceVolume?: number;
  onVoiceVolumeChange?: (vol: number) => void;
  recLanguage: string;
  setRecLanguage: (langCode: string) => void;
  automaticListening: boolean;
  onToggleAutomaticListening: (enabled: boolean) => void;
  hardwareState: HardwareStateInfo;
  micPermissionState: MicPermissionState;
  micDebugLog: string;
  lastMicError: string;
  isIframe: boolean;
  voiceStatus: 'idle' | 'listening' | 'processing' | 'speaking';
  onTapToTalk: () => void;
  onRequestMicPermission: () => void;
  onRunLiveListeningTest3Seconds: () => Promise<void>;
  onRunPipelineTest: () => Promise<void>;
  initialSection?: string;
  use3DMemoryBackground?: boolean;
  onToggle3DMemoryBackground?: (enabled: boolean) => void;
  onTapAvatar?: () => void;
  onOpenPythonStudio?: () => void;
  selected3DAvatarId?: string;
  onSelect3DAvatar?: (id: string) => void;
  is3DAvatarActive?: boolean;
  onToggle3DAvatar?: (id: string) => void;
  onToggle3DAvatarGlobal?: (enabled: boolean) => void;
  avatarScale?: number;
  onChangeAvatarScale?: (scale: number) => void;
  avatarOffsetY?: number;
  onChangeAvatarOffsetY?: (offset: number) => void;
  onResetAvatarControls?: () => void;
  onOpen14LivingAvatarsShowcase?: () => void;
}

export interface PersonalityModeConfig {
  id: string;
  name: string;
  addressLabel: string;
  desc: string;
  icon: React.ElementType;
}

export const PERSONALITY_MODES: PersonalityModeConfig[] = [
  {
    id: 'girlfriend',
    name: 'GF Mode',
    addressLabel: 'संबोधन: "Boss"',
    desc: 'गहरी परवाह, आत्मीयता व वफादारी। संबोधन: केवल "Boss"।',
    icon: Crown,
  },
  {
    id: 'love',
    name: 'Love Mode',
    addressLabel: 'संबोधन: "Jaan"',
    desc: 'प्यार भरा, नरम व अपनापन लिए AI साथी • भावना को समझे, नाम व बातें याद रखे, सुरक्षित सीमाओं के साथ।',
    icon: Heart,
  },
  {
    id: 'professional',
    name: 'Professional',
    addressLabel: 'संबोधन: "Boss"',
    desc: 'संक्षिप्त, सटीक, औपचारिक व कार्य-केंद्रित व्यावसायिक संवाद।',
    icon: Briefcase,
  },
  {
    id: 'funny',
    name: 'Funny',
    addressLabel: 'संबोधन: "Boss"',
    desc: 'मजाकिया, हास्यप्रद व चुटीले जवाब। हर बात में मुस्कान व मस्ती।',
    icon: Laugh,
  },
  {
    id: 'companion',
    name: 'Companion',
    addressLabel: 'संबोधन: "Boss"',
    desc: 'सच्चा साथी, गहरी सहानुभूति, संबल व निष्ठावान वफादारी।',
    icon: HeartHandshake,
  },
  {
    id: 'teacher',
    name: 'Teacher',
    addressLabel: 'संबोधन: "Boss"',
    desc: 'धैर्यवान व्याख्या, सिखाने का सरल अंदाज व अवधारणात्मक स्पष्टता।',
    icon: GraduationCap,
  },
  {
    id: 'developer',
    name: 'Developer',
    addressLabel: 'संबोधन: "Boss"',
    desc: 'तकनीकी विशेषज्ञता, क्लीन कोड, आर्किटेक्चर व तीव्र डिबगिंग।',
    icon: Code2,
  },
  {
    id: 'hungry',
    name: 'Hungry',
    addressLabel: 'संबोधन: "Boss"',
    desc: 'स्वादिष्ट व्यंजनों की शौकीन, हर बातचीत में लजीज जायके का तड़का।',
    icon: Utensils,
  },
  {
    id: 'nautanki',
    name: 'Nautanki',
    addressLabel: 'संबोधन: "Boss"',
    desc: 'नाटकीय, फिल्मी व अत्यधिक उत्साही बॉलीवुड ड्रामा व एक्सप्रेशन्स।',
    icon: Drama,
  },
  {
    id: 'custom',
    name: 'Custom',
    addressLabel: 'संबोधन: "Boss"',
    desc: 'व्यक्तिगत व अनुकूलनीय शैली, आपके हर निर्देश के अनुसार लचीली।',
    icon: Sparkles,
  },
];

export const SETTING_GROUPS = [
  { id: 'appearance', label: 'दिखावट' },
  { id: 'voice_lang', label: 'आवाज़ और भाषा' },
  { id: 'apps_tools', label: 'ऐप्स और टूल्स' },
  { id: 'security', label: 'सुरक्षा' },
  { id: 'api_memory', label: 'API और मेमोरी' },
];

export const ZoyaSettingsModal: React.FC<ZoyaSettingsModalProps> = ({
  isOpen,
  onClose,
  avatarStyle,
  setAvatarStyle,
  personaMode,
  setPersonaMode,
  voiceSpeed,
  setVoiceSpeed,
  voiceVolume = 1,
  onVoiceVolumeChange,
  recLanguage,
  setRecLanguage,
  automaticListening,
  onToggleAutomaticListening,
  hardwareState,
  micPermissionState,
  micDebugLog,
  lastMicError,
  isIframe,
  voiceStatus,
  onTapToTalk,
  onRequestMicPermission,
  onRunLiveListeningTest3Seconds,
  onRunPipelineTest,
  initialSection = 'general',
  use3DMemoryBackground = true,
  onToggle3DMemoryBackground,
  onTapAvatar,
  onOpenPythonStudio,
  selected3DAvatarId: propSelected3DId,
  onSelect3DAvatar: propOnSelect3D,
  is3DAvatarActive: propIs3DActive,
  onToggle3DAvatar: propOnToggle3D,
  onToggle3DAvatarGlobal: propOnToggle3DGlobal,
  avatarScale: propAvatarScale,
  onChangeAvatarScale: propOnChangeScale,
  avatarOffsetY: propAvatarOffsetY,
  onChangeAvatarOffsetY: propOnChangeOffsetY,
  onResetAvatarControls: propOnResetControls,
  onOpen14LivingAvatarsShowcase,
}) => {
  const [activeItemId, setActiveItemId] = useState<string | null>(null);

  // Appearance State
  const [currentTheme, setCurrentTheme] = useState<AppThemeId>(() => themeManager.getTheme());
  const [isReduceMotion, setIsReduceMotion] = useState<boolean>(() => themeManager.isReduceMotion());

  // 10 Japanese 3D Anime Avatars State (supports controlled from App or fallback to localStorage)
  const [localSelected3DId, setLocalSelected3DId] = useState<string>(() => getSaved3DAvatarId());
  const selected3DAvatarId = propSelected3DId !== undefined ? propSelected3DId : localSelected3DId;

  const [localIs3DActive, setLocalIs3DActive] = useState<boolean>(() => getIs3DAvatarEnabled());
  const is3DAvatarActive = propIs3DActive !== undefined ? propIs3DActive : localIs3DActive;

  // Sync state if props change from outside
  useEffect(() => {
    if (propSelected3DId !== undefined) {
      setLocalSelected3DId(propSelected3DId);
    }
  }, [propSelected3DId]);

  useEffect(() => {
    if (propIs3DActive !== undefined) {
      setLocalIs3DActive(propIs3DActive);
    }
  }, [propIs3DActive]);

  // Listen to cross-component permanent avatar events
  useEffect(() => {
    const handleAvatarSelected = (e: Event) => {
      const customEvent = e as CustomEvent<{ avatarId: string }>;
      if (customEvent.detail?.avatarId) {
        setLocalSelected3DId(customEvent.detail.avatarId);
        setLocalIs3DActive(true);
      }
    };
    const handleAvatarEnabled = (e: Event) => {
      const customEvent = e as CustomEvent<{ enabled: boolean }>;
      if (typeof customEvent.detail?.enabled === 'boolean') {
        setLocalIs3DActive(customEvent.detail.enabled);
      }
    };
    window.addEventListener('zoya-avatar-selected', handleAvatarSelected);
    window.addEventListener('zoya-avatar-enabled-changed', handleAvatarEnabled);
    return () => {
      window.removeEventListener('zoya-avatar-selected', handleAvatarSelected);
      window.removeEventListener('zoya-avatar-enabled-changed', handleAvatarEnabled);
    };
  }, []);

  const [localScale, setLocalScale] = useState<number>(() => get3DAvatarScale());
  const avatarScale = propAvatarScale !== undefined ? propAvatarScale : localScale;

  const [localOffsetY, setLocalOffsetY] = useState<number>(() => get3DAvatarOffsetY());
  const avatarOffsetY = propAvatarOffsetY !== undefined ? propAvatarOffsetY : localOffsetY;

  const [preview3DAvatar, setPreview3DAvatar] = useState<Anime3DAvatar | null>(null);
  const [avatarTab, setAvatarTab] = useState<'3d_japanese' | 'classic'>('3d_japanese');

  // Full HD Avatars List (incorporates all built-in and user-uploaded custom avatars)
  const [allAvatarsList, setAllAvatarsList] = useState<Anime3DAvatar[]>(() => getAllAvatars());
  const [isUploadingAvatar, setIsUploadingAvatar] = useState<boolean>(false);
  const [uploadAvatarError, setUploadAvatarError] = useState<string | null>(null);
  const avatarFileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const handleCustomAvatarsUpdate = (e: Event) => {
      const customEvent = e as CustomEvent<Anime3DAvatar[]>;
      if (customEvent.detail) {
        setAllAvatarsList(getAllAvatars());
      }
    };
    window.addEventListener('zoya-custom-avatars-updated', handleCustomAvatarsUpdate);
    return () => {
      window.removeEventListener('zoya-custom-avatars-updated', handleCustomAvatarsUpdate);
    };
  }, []);

  const handleUploadAvatarFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsUploadingAvatar(true);
    setUploadAvatarError(null);

    try {
      const reader = new FileReader();
      const base64Promise = new Promise<string>((resolve, reject) => {
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = reject;
      });
      reader.readAsDataURL(file);
      const base64Data = await base64Promise;

      const cleanName = file.name.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' ') || 'Custom 3D Avatar';

      const response = await fetch('/api/avatar/process-upload', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ image: base64Data, name: cleanName }),
      });

      if (!response.ok) {
        throw new Error(`Upload processing failed: ${response.statusText}`);
      }

      const data = await response.json();
      if (data.success && data.avatar) {
        saveCustomAvatar(data.avatar);
        setAllAvatarsList(getAllAvatars());
        handleSelect3DAvatar(data.avatar.id);
      } else {
        throw new Error(data.error || 'Failed to process avatar');
      }
    } catch (err: any) {
      console.error('[AvatarUpload] Error:', err);
      setUploadAvatarError(err?.message || 'अवतार प्रोसेस करने में त्रुटि। कृपया पुनः प्रयास करें।');
    } finally {
      setIsUploadingAvatar(false);
      if (avatarFileInputRef.current) {
        avatarFileInputRef.current.value = '';
      }
    }
  };

  const handleSelect3DAvatar = (avatarId: string) => {
    if (!avatarId) return;
    setLocalSelected3DId(avatarId);
    save3DAvatarId(avatarId);
    setLocalIs3DActive(true);
    saveIs3DAvatarEnabled(true);
    if (propOnSelect3D) {
      propOnSelect3D(avatarId);
    }
  };

  const handleToggleAvatar = (avatarId: string) => {
    if (is3DAvatarActive && selected3DAvatarId === avatarId) {
      // Explicitly turn OFF currently active avatar
      setLocalIs3DActive(false);
      saveIs3DAvatarEnabled(false);
      if (propOnToggle3D) {
        propOnToggle3D(avatarId);
      }
    } else {
      // Turn ON or switch to this avatar
      handleSelect3DAvatar(avatarId);
      if (propOnToggle3D) {
        propOnToggle3D(avatarId);
      }
    }
  };

  const handleToggleGlobal3D = (enabled: boolean) => {
    if (propOnToggle3DGlobal) {
      propOnToggle3DGlobal(enabled);
    } else {
      setLocalIs3DActive(enabled);
      saveIs3DAvatarEnabled(enabled);
    }
  };

  const handleScaleChange = (scale: number) => {
    if (propOnChangeScale) {
      propOnChangeScale(scale);
    } else {
      setLocalScale(scale);
      save3DAvatarScale(scale);
    }
  };

  const handleOffsetYChange = (offset: number) => {
    if (propOnChangeOffsetY) {
      propOnChangeOffsetY(offset);
    } else {
      setLocalOffsetY(offset);
      save3DAvatarOffsetY(offset);
    }
  };

  const [livelinessK, setLivelinessK] = useState<number>(() => get3DAvatarLiveliness());

  const handleLivelinessChange = (k: number) => {
    setLivelinessK(k);
    save3DAvatarLiveliness(k);
  };

  const handleResetControls = () => {
    setLivelinessK(1.0);
    save3DAvatarLiveliness(1.0);
    if (propOnResetControls) {
      propOnResetControls();
    } else {
      setLocalScale(1.0);
      save3DAvatarScale(1.0);
      setLocalOffsetY(0);
      save3DAvatarOffsetY(0);
    }
  };

  // Voice State
  const [currentVoiceId, setCurrentVoiceId] = useState<string>(() => {
    try {
      return localStorage.getItem('zoya_selected_voice_id') || 'gemini-kore';
    } catch {
      return 'gemini-kore';
    }
  });
  const [isPlayingAudioPreview, setIsPlayingAudioPreview] = useState<string | null>(null);

  // ElevenLabs Primary TTS Settings State (Key stays strictly on server proxy; never stored in browser)
  const [elevenLabsApiKey, setElevenLabsApiKey] = useState<string>('');
  const [elevenLabsConfiguredOnServer, setElevenLabsConfiguredOnServer] = useState<boolean>(false);
  const [elevenLabsVoiceId, setElevenLabsVoiceId] = useState<string>(() => {
    try {
      return localStorage.getItem('zoya_elevenlabs_voice_id') || '21m00Tcm4TlvDq8ikWAM';
    } catch {
      return '21m00Tcm4TlvDq8ikWAM';
    }
  });
  const [showElevenLabsKey, setShowElevenLabsKey] = useState<boolean>(false);
  const [isTestingElevenConnection, setIsTestingElevenConnection] = useState<boolean>(false);
  const [isTestingElevenVoice, setIsTestingElevenVoice] = useState<boolean>(false);
  const [elevenConnectionStatus, setElevenConnectionStatus] = useState<{
    status: 'idle' | 'success' | 'error';
    message?: string;
    tier?: string;
    voiceName?: string;
    latencyMs?: number;
  }>({ status: 'idle' });
  const [savedElevenToast, setSavedElevenToast] = useState<boolean>(false);
  const activeElevenAudioRef = useRef<HTMLAudioElement | null>(null);

  // Language Search Filter
  const [langSearchQuery, setLangSearchQuery] = useState<string>('');

  // Gemini API Key & Connection Test State
  const [customApiKey, setCustomApiKey] = useState<string>(() =>
    getDecryptedSecretSync('zoya_gemini_api_key')
  );
  const [showApiKey, setShowApiKey] = useState<boolean>(false);
  const [isTestingGemini, setIsTestingGemini] = useState<boolean>(false);
  const [geminiTestResult, setGeminiTestResult] = useState<{
    success: boolean;
    latencyMs?: number;
    message: string;
  } | null>(null);
  const [selectedGeminiModel, setSelectedGeminiModel] = useState<string>(() => {
    try {
      return localStorage.getItem('zoya_ai_model_name') || 'gemini-2.5-flash';
    } catch {
      return 'gemini-2.5-flash';
    }
  });
  const [vaultSelfTestResult, setVaultSelfTestResult] = useState<SecretVaultSelfTestResult | null>(null);
  const [isRunningVaultTest, setIsRunningVaultTest] = useState<boolean>(false);

  // Tool API Keys State
  const [toolApiKeysMap, setToolApiKeysMap] = useState<Record<string, string>>(() => getAllToolApiKeys());
  const [brandConfig, setBrandConfig] = useState(() => getBrandGuidelinesConfig());
  const [savedToolKeyToastId, setSavedToolKeyToastId] = useState<string | null>(null);

  // Smart Battery Voice Alerts State (Synchronized with batteryAlertSystem)
  const [batteryStatus, setBatteryStatus] = useState<BatteryAlertStatus>(() => batteryAlertSystem.getStatus());
  const [isBatteryVoiceAlertsEnabled, setIsBatteryVoiceAlertsEnabled] = useState<boolean>(() => batteryAlertSystem.isEnabled());
  const [isChargingAnnouncementsEnabled, setIsChargingAnnouncementsEnabled] = useState<boolean>(() => batteryAlertSystem.isChargingAnnouncementsEnabled());
  const [isLowBatteryWarningsEnabled, setIsLowBatteryWarningsEnabled] = useState<boolean>(() => batteryAlertSystem.isLowBatteryWarningsEnabled());
  const [isFlightModeAnnouncementsEnabled, setIsFlightModeAnnouncementsEnabled] = useState<boolean>(() => batteryAlertSystem.isFlightModeAnnouncementsEnabled());
  const [isAppInstallAnnouncementsEnabled, setIsAppInstallAnnouncementsEnabled] = useState<boolean>(() => batteryAlertSystem.isAppInstallAnnouncementsEnabled());
  const [simulatedLevel, setSimulatedLevel] = useState<number>(() => batteryAlertSystem.getStatus().levelPercent);

  // OpenWakeWord "Hey Zoya" Wake-Word State
  const [wakeSensitivity, setWakeSensitivity] = useState<number>(() => {
    try {
      const v = localStorage.getItem('zoya_wakeword_sensitivity');
      return v ? parseFloat(v) : 0.6;
    } catch {
      return 0.6;
    }
  });
  const [wakeDebugFallback, setWakeDebugFallback] = useState<boolean>(() => {
    try {
      return localStorage.getItem('zoya_wakeword_debug_fallback') === 'true';
    } catch {
      return false;
    }
  });
  const [wakeStatus, setWakeStatus] = useState<{
    success?: boolean;
    engine?: string;
    engineVersion?: string;
    wakeWord?: string;
    modelPath?: string;
    modelExists?: boolean;
    isImportedModel?: boolean;
    importedModelPath?: string;
        isKeyInvalid?: boolean;
        sensitivity?: number;
    debugFallbackEnabled?: boolean;
    hasMicPermission?: boolean;
    canDrawOverlay?: boolean;
    hasNotificationPermission?: boolean;
    isBatteryOptimizationIgnored?: boolean;
  } | null>(null);
  const [isRestartingWakeEngine, setIsRestartingWakeEngine] = useState<boolean>(false);
  const [wakeKeySavedSuccess, setWakeKeySavedSuccess] = useState<boolean>(false);
  const [isImportingModel, setIsImportingModel] = useState<boolean>(false);
  const [importModelNotice, setImportModelNotice] = useState<{ message: string; success: boolean } | null>(null);
  const modelFileInputRef = useRef<HTMLInputElement | null>(null);

  const refreshWakeStatus = () => {
    try {
      const bridge = (window as any).AndroidBridge;
      if (bridge && typeof bridge.getWakeWordStatusJson === 'function') {
        const raw = bridge.getWakeWordStatusJson();
        const parsed = JSON.parse(raw);
        setWakeStatus(parsed);
        if (typeof parsed.sensitivity === 'number') setWakeSensitivity(parsed.sensitivity);
        if (typeof parsed.debugFallbackEnabled === 'boolean') setWakeDebugFallback(parsed.debugFallbackEnabled);
      }
    } catch {}
  };

  useEffect(() => {
    refreshWakeStatus();
    fetch('/api/elevenlabs/status')
      .then((r) => (r.ok ? r.json() : null))
      .then((data) => {
        if (data) {
          setElevenLabsConfiguredOnServer(Boolean(data.configured));
          if (data.voiceId && !localStorage.getItem('zoya_elevenlabs_voice_id')) {
            setElevenLabsVoiceId(data.voiceId);
          }
        }
      })
      .catch(() => {});
    const handleFocus = () => {
      refreshWakeStatus();
    };
    window.addEventListener('focus', handleFocus);
    return () => window.removeEventListener('focus', handleFocus);
  }, []);

  const handleImportModelFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.name.endsWith('.onnx')) {
      setImportModelNotice({ message: 'कृपया वैध .onnx मॉडल फ़ाइल चुनें (Valid .onnx file required)', success: false });
      return;
    }
    setIsImportingModel(true);
    const reader = new FileReader();
    reader.onload = async () => {
      try {
        const base64 = (reader.result as string).split(',')[1];
        const bridge = (window as any).AndroidBridge;
        if (bridge && typeof bridge.importWakeWordModel === 'function') {
          const resRaw = bridge.importWakeWordModel(base64, file.name);
          const res = JSON.parse(resRaw);
          if (res.success) {
            setImportModelNotice({ message: 'Hey Zoya मॉडल (.onnx) सफलतापूर्वक इंटरनल स्टोरेज में लोड हो गया ✓', success: true });
            refreshWakeStatus();
          } else {
            setImportModelNotice({ message: `आयात विफल: ${res.error || 'अमान्य फ़ाइल'}`, success: false });
          }
        } else {
          try {
            localStorage.setItem('zoya_imported_ppn_name', file.name);
            localStorage.setItem('zoya_imported_ppn_size', file.size.toString());
            setImportModelNotice({ message: `मॉडल (${file.name}) सेव हो गया ✓ (Android APK में इंटरनल स्टोरेज पर लोड होगा)`, success: true });
          } catch {
            setImportModelNotice({ message: 'फ़ाइल सेव नहीं हो सकी', success: false });
          }
        }
      } catch (err: any) {
        setImportModelNotice({ message: `त्रुटि: ${err.message}`, success: false });
      } finally {
        setIsImportingModel(false);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleRemoveImportedModel = () => {
    const bridge = (window as any).AndroidBridge;
    if (bridge && typeof bridge.removeWakeWordModel === 'function') {
      bridge.removeWakeWordModel();
    }
    try {
      localStorage.removeItem('zoya_imported_ppn_name');
      localStorage.removeItem('zoya_imported_ppn_size');
    } catch {}
    refreshWakeStatus();
    setImportModelNotice({ message: 'कस्टम मॉडल हटा दिया गया', success: true });
    setTimeout(() => setImportModelNotice(null), 3000);
  };



  const handleUpdateWakeSensitivity = (val: number) => {
    setWakeSensitivity(val);
    try {
      localStorage.setItem('zoya_wakeword_sensitivity', val.toString());
      const bridge = (window as any).AndroidBridge;
      if (bridge && typeof bridge.setWakeWordSensitivity === 'function') {
        bridge.setWakeWordSensitivity(val);
      }
    } catch {}
  };

  const handleToggleWakeDebugFallback = (val: boolean) => {
    setWakeDebugFallback(val);
    try {
      localStorage.setItem('zoya_wakeword_debug_fallback', val ? 'true' : 'false');
      const bridge = (window as any).AndroidBridge;
      if (bridge && typeof bridge.setWakeWordDebugFallback === 'function') {
        bridge.setWakeWordDebugFallback(val);
      }
    } catch {}
  };

  const handleSaveElevenLabs = async () => {
    const trimmedKey = elevenLabsApiKey.trim();
    const trimmedVoice = elevenLabsVoiceId.trim() || '21m00Tcm4TlvDq8ikWAM';
    try {
      localStorage.setItem('zoya_elevenlabs_voice_id', trimmedVoice);
    } catch {}
    // Ensure any legacy client copy is permanently deleted; store exclusively on the server proxy
    purgeDeprecatedClientSecrets();
    try {
      const res = await fetch('/api/elevenlabs/config', {
        method: 'POST',
        headers: agentClient.getOwnerFetchHeaders({ 'Content-Type': 'application/json' }),
        credentials: 'include',
        body: JSON.stringify({
          ...(trimmedKey ? { apiKey: trimmedKey } : {}),
          voiceId: trimmedVoice,
        }),
      });
      if (res.ok) {
        const data = await res.json().catch(() => ({}));
        setElevenLabsConfiguredOnServer(Boolean(data.configured));
        setSavedElevenToast(true);
        setTimeout(() => setSavedElevenToast(false), 2500);
      } else {
        const errData = await res.json().catch(() => ({}));
        setElevenConnectionStatus({
          status: 'error',
          message:
            res.status === 401 || res.status === 403
              ? 'Owner authentication required in Coding Agent to update server ElevenLabs key.'
              : errData?.error || `Failed to save ElevenLabs config (HTTP ${res.status})`,
        });
      }
    } catch (err: any) {
      setElevenConnectionStatus({
        status: 'error',
        message: err?.message || 'Failed to contact server ElevenLabs config endpoint.',
      });
    }
    setElevenLabsApiKey('');
    setElevenLabsVoiceId(trimmedVoice);
  };

  const handleTestElevenConnection = async () => {
    setIsTestingElevenConnection(true);
    setElevenConnectionStatus({ status: 'idle' });
    try {
      if (elevenLabsApiKey.trim()) {
        const cfgRes = await fetch('/api/elevenlabs/config', {
          method: 'POST',
          headers: agentClient.getOwnerFetchHeaders({ 'Content-Type': 'application/json' }),
          credentials: 'include',
          body: JSON.stringify({
            apiKey: elevenLabsApiKey.trim(),
            voiceId: elevenLabsVoiceId.trim() || undefined,
          }),
        }).catch(() => null);
        setElevenLabsApiKey('');
        if (cfgRes && cfgRes.ok) {
          setElevenLabsConfiguredOnServer(true);
        }
      }
      const res = await testElevenLabsConnection(elevenLabsVoiceId);
      if (res.success) {
        setElevenConnectionStatus({
          status: 'success',
          message: `सत्यापित (Verified): ${res.voiceName || 'Voice OK'} · ${res.latencyMs}ms`,
          tier: res.subscriptionTier,
          voiceName: res.voiceName,
          latencyMs: res.latencyMs,
        });
      } else {
        setElevenConnectionStatus({
          status: 'error',
          message: res.error || 'Connection verification failed',
          latencyMs: res.latencyMs,
        });
      }
    } catch (err: any) {
      setElevenConnectionStatus({
        status: 'error',
        message: err?.message || 'Verification error',
      });
    } finally {
      setIsTestingElevenConnection(false);
    }
  };

  const handleTestElevenVoice = async () => {
    if (isTestingElevenVoice) {
      if (activeElevenAudioRef.current) {
        try {
          activeElevenAudioRef.current.pause();
          activeElevenAudioRef.current.src = '';
        } catch {}
        activeElevenAudioRef.current = null;
      }
      setIsTestingElevenVoice(false);
      return;
    }

    setIsTestingElevenVoice(true);
    try {
      if (elevenLabsApiKey.trim()) {
        const cfgRes = await fetch('/api/elevenlabs/config', {
          method: 'POST',
          headers: agentClient.getOwnerFetchHeaders({ 'Content-Type': 'application/json' }),
          credentials: 'include',
          body: JSON.stringify({
            apiKey: elevenLabsApiKey.trim(),
            voiceId: elevenLabsVoiceId.trim() || undefined,
          }),
        }).catch(() => null);
        setElevenLabsApiKey('');
        if (cfgRes && cfgRes.ok) {
          setElevenLabsConfiguredOnServer(true);
        }
      }
      const res = await fetch('/api/tts', {
        method: 'POST',
        headers: agentClient.getOwnerFetchHeaders({ 'Content-Type': 'application/json' }),
        credentials: 'include',
        body: JSON.stringify({
          text: 'नमस्ते! यह आपकी इलेवेनलैब्स वॉयस आईडी का सीधा परीक्षण है।',
          language: 'hi-IN',
          forceEngine: 'elevenlabs',
          elevenLabsVoiceId: elevenLabsVoiceId.trim() || undefined,
        }),
      });
      const data = await res.json().catch(() => ({}));
      if (data?.audioData) {
        const audio = new Audio(`data:${data.mimeType || 'audio/mpeg'};base64,${data.audioData}`);
        activeElevenAudioRef.current = audio;
        audio.onended = () => setIsTestingElevenVoice(false);
        audio.onerror = () => setIsTestingElevenVoice(false);
        await audio.play();
      } else {
        setElevenConnectionStatus({
          status: 'error',
          message: `ElevenLabs Voice Test Error: ${data?.error || `HTTP ${res.status}: No audio returned`}`,
        });
        setIsTestingElevenVoice(false);
      }
    } catch (err: any) {
      setElevenConnectionStatus({
        status: 'error',
        message: `Voice Test Error: ${err?.message || 'Network error'}`,
      });
      setIsTestingElevenVoice(false);
    }
  };

  const handleManualRestartWakeEngine = () => {
    setIsRestartingWakeEngine(true);
    try {
      const bridge = (window as any).AndroidBridge;
      if (bridge && typeof bridge.restartWakeWordEngine === 'function') {
        bridge.restartWakeWordEngine();
      }
    } catch {}
    setTimeout(() => {
      setIsRestartingWakeEngine(false);
      refreshWakeStatus();
    }, 700);
  };

  useEffect(() => {
    const handleUpdate = (status: BatteryAlertStatus) => {
      setBatteryStatus(status);
      setIsBatteryVoiceAlertsEnabled(status.enabled);
      setIsChargingAnnouncementsEnabled(status.chargingAnnouncementsEnabled);
      setIsLowBatteryWarningsEnabled(status.lowBatteryWarningsEnabled);
      setIsFlightModeAnnouncementsEnabled(status.flightModeAnnouncementsEnabled);
      setIsAppInstallAnnouncementsEnabled(status.appInstallAnnouncementsEnabled);
    };
    batteryAlertSystem.addListener(handleUpdate);
    return () => {
      batteryAlertSystem.removeListener(handleUpdate);
    };
  }, []);

  const handleToggleBatteryVoiceAlerts = (enabled: boolean) => {
    batteryAlertSystem.setEnabled(enabled);
    setIsBatteryVoiceAlertsEnabled(enabled);
  };

  const handleToggleChargingAnnouncements = (enabled: boolean) => {
    batteryAlertSystem.setChargingAnnouncementsEnabled(enabled);
    setIsChargingAnnouncementsEnabled(enabled);
  };

  const handleToggleLowBatteryWarnings = (enabled: boolean) => {
    batteryAlertSystem.setLowBatteryWarningsEnabled(enabled);
    setIsLowBatteryWarningsEnabled(enabled);
  };

  const handleToggleFlightModeAnnouncements = (enabled: boolean) => {
    batteryAlertSystem.setFlightModeAnnouncementsEnabled(enabled);
    setIsFlightModeAnnouncementsEnabled(enabled);
  };

  const handleToggleAppInstallAnnouncements = (enabled: boolean) => {
    batteryAlertSystem.setAppInstallAnnouncementsEnabled(enabled);
    setIsAppInstallAnnouncementsEnabled(enabled);
  };

  // Listen for external theme/motion events
  useEffect(() => {
    const onThemeChange = () => setCurrentTheme(themeManager.getTheme());
    const onMotionChange = () => setIsReduceMotion(themeManager.isReduceMotion());
    window.addEventListener('zoya-theme-changed', onThemeChange);
    window.addEventListener('zoya-motion-changed', onMotionChange);
    return () => {
      window.removeEventListener('zoya-theme-changed', onThemeChange);
      window.removeEventListener('zoya-motion-changed', onMotionChange);
    };
  }, []);

  // Sync initialSection on open
  useEffect(() => {
    if (isOpen) {
      if (initialSection && initialSection !== 'general') {
        setActiveItemId(initialSection);
      } else {
        setActiveItemId(null);
      }
      setToolApiKeysMap(getAllToolApiKeys());
      setBrandConfig(getBrandGuidelinesConfig());
      refreshWakeStatus();
    }
  }, [isOpen, initialSection]);

  const [zipPhase, setZipPhase] = useState<'idle' | 'preparing' | 'archiving' | 'generated' | 'started' | 'failed'>('idle');
  const [zipStatusDetail, setZipStatusDetail] = useState<string>('');
  const [zipError, setZipError] = useState<string | null>(null);
  const [manualDownloadUrl, setManualDownloadUrl] = useState<string | null>(null);
  const [zipSummary, setZipSummary] = useState<{ totalFiles: number; zipSizeBytes: number } | null>(null);

  const isPreparingZip = zipPhase === 'preparing' || zipPhase === 'archiving';

  useEffect(() => {
    return () => {
      if (manualDownloadUrl) {
        URL.revokeObjectURL(manualDownloadUrl);
      }
    };
  }, [manualDownloadUrl]);

  if (!isOpen) return null;

  const handleBack = () => {
    if (activeItemId !== null) {
      setActiveItemId(null);
    } else {
      onClose();
    }
  };

  const handleHome = () => {
    setActiveItemId(null);
    onClose();
  };

  // Helper to get subtitle/preview value on main list
  const getDynamicValue = (id: string): string => {
    switch (id) {
      case 'hologram':
        return 'Neon Ring';
      case 'appearance': {
        const t = APP_THEMES[currentTheme];
        return t ? t.name : 'Cosmic';
      }
      case 'avatar': {
        const a3d = allAvatarsList.find((a) => a.id === selected3DAvatarId) || ANIME_3D_AVATARS.find((a) => a.id === selected3DAvatarId);
        if (a3d) return `${a3d.name} (3D)`;
        if (avatarStyle === 'classic') return 'Zoya';
        return allAvatarsList[0]?.name ? `${allAvatarsList[0].name} (3D)` : '3D Anime Avatar';
      }
      case 'voice': {
        const v = ZOYA_AVAILABLE_VOICES.find((item) => item.id === currentVoiceId);
        return v ? `${v.name} (${v.gender === 'Female' ? 'नारी' : 'पुरुष'})` : 'Zoya (नारी)';
      }
      case 'language': {
        const l = getLanguageConfig(recLanguage);
        return l ? l.nativeName : 'हिंदी';
      }
      case 'mode': {
        const m = PERSONALITY_MODES.find((item) => item.id === personaMode);
        return m ? m.name : 'Friendly';
      }
      case 'youtube':
        return 'सभी गाने';
      case 'python_studio':
        return 'Python 3';
      case 'device_lock':
        return 'PIN';
      case 'accessibility':
        return 'बंद';
      case 'api_key':
        return selectedGeminiModel.includes('flash') ? 'Gemini Flash' : 'Gemini';
      case 'tool_api_keys':
        return 'Search';
      case 'memory':
        return use3DMemoryBackground ? 'चालू (ON)' : 'बंद (OFF)';
      case 'instagram_growth':
        return '₹0 Active';
      case 'download_project':
        switch (zipPhase) {
          case 'preparing':
            return 'Preparing...';
          case 'archiving':
            return 'Creating ZIP...';
          case 'generated':
            return 'Ready';
          case 'started':
            return 'Started';
          case 'failed':
            return 'Failed';
          default:
            return 'ZIP';
        }
      case 'battery_alerts':
        return isBatteryVoiceAlertsEnabled ? 'चालू (ON)' : 'बंद (OFF)';
      default:
        return 'खोलें';
    }
  };

  const formatZipSizeMb = (bytes: number) => `${(bytes / (1024 * 1024)).toFixed(1)} MB`;

  const handleDownloadProjectZip = async () => {
    if (isPreparingZip) return;
    const EXPORT_FILENAME = 'Zoya_AI_Companion_Full_Project.zip';

    const fetchWithRetry = async (url: string, init?: RequestInit, retries = 3): Promise<Response> => {
      let lastErr: any;
      for (let attempt = 0; attempt <= retries; attempt++) {
        try {
          const res = await fetch(url, { credentials: 'same-origin', ...init });
          if ((res.status === 502 || res.status === 503 || res.status === 504) && attempt < retries) {
            await new Promise((r) => setTimeout(r, 400 * (attempt + 1)));
            continue;
          }
          return res;
        } catch (err) {
          lastErr = err;
          if (attempt < retries) {
            await new Promise((r) => setTimeout(r, 400 * (attempt + 1)));
            continue;
          }
        }
      }
      throw lastErr;
    };

    setZipError(null);
    setZipSummary(null);
    setManualDownloadUrl((prev) => {
      if (prev && prev.startsWith('blob:')) URL.revokeObjectURL(prev);
      return null;
    });
    setZipPhase('preparing');
    setZipStatusDetail('Collecting project files...');

    try {
      const startRes = await fetchWithRetry('/api/project/export/start', { method: 'POST' }, 3);
      const startData = await startRes.json().catch(() => ({}));
      if (!startRes.ok || !startData?.success || !startData?.jobId) {
        throw new Error(startData?.error || `Failed to start export (${startRes.status})`);
      }

      const jobId: string = startData.jobId;
      let statusData: any = null;
      let consecutivePollErrors = 0;

      while (true) {
        await new Promise((resolve) => setTimeout(resolve, 400));
        let statusRes: Response;
        try {
          statusRes = await fetchWithRetry(`/api/project/export/status/${encodeURIComponent(jobId)}`, undefined, 2);
          consecutivePollErrors = 0;
        } catch (pollErr) {
          consecutivePollErrors++;
          if (consecutivePollErrors >= 4) throw pollErr;
          continue;
        }
        statusData = await statusRes.json().catch(() => ({}));
        if (!statusRes.ok) {
          throw new Error(statusData?.error || `Export status error (${statusRes.status})`);
        }
        if (statusData.phase === 'failed') {
          throw new Error(statusData.error || 'Server failed to generate project ZIP.');
        }
        if (statusData.phase === 'preparing') {
          setZipPhase('preparing');
          setZipStatusDetail('Scanning project directories...');
        } else if (statusData.phase === 'archiving') {
          setZipPhase('archiving');
          const filesLabel =
            statusData.totalFiles > 0
              ? `${statusData.processedFiles}/${statusData.totalFiles} files`
              : 'Archiving...';
          setZipStatusDetail(`${filesLabel} • ${statusData.archivePercent || 0}%`);
        } else if (statusData.phase === 'ready') {
          if (!statusData.verified || !statusData.zipSizeBytes || statusData.zipSizeBytes <= 0) {
            throw new Error('Generated ZIP archive failed integrity verification.');
          }
          break;
        }
      }

      const totalZipBytes: number = statusData.zipSizeBytes;
      const totalFiles: number = statusData.totalFiles || 0;
      const directDownloadUrl = `/api/project/export/download/${encodeURIComponent(jobId)}`;
      const CHUNK_SIZE = 4 * 1024 * 1024;
      const blobChunks: BlobPart[] = [];
      let offset = 0;

      setZipPhase('archiving');
      try {
        while (offset < totalZipBytes) {
          const chunkLen = Math.min(CHUNK_SIZE, totalZipBytes - offset);
          const chunkRes = await fetchWithRetry(
            `/api/project/export/chunk/${encodeURIComponent(jobId)}?offset=${offset}&length=${chunkLen}`,
            undefined,
            3
          );
          if (!chunkRes.ok) {
            throw new Error(`Archive transfer failed at byte ${offset} (${chunkRes.status})`);
          }
          const buf = await chunkRes.arrayBuffer();
          if (buf.byteLength === 0) {
            throw new Error('Received unexpected empty chunk while reading ZIP archive.');
          }
          blobChunks.push(buf);
          offset += buf.byteLength;
          const pct = Math.min(100, Math.round((offset / totalZipBytes) * 100));
          setZipStatusDetail(
            `Assembling archive • ${formatZipSizeMb(offset)} / ${formatZipSizeMb(totalZipBytes)} (${pct}%)`
          );
        }

        const zipBlob = new Blob(blobChunks, { type: 'application/zip' });
        if (zipBlob.size !== totalZipBytes) {
          throw new Error(`ZIP size mismatch (${zipBlob.size} vs ${totalZipBytes} bytes).`);
        }

        // Verify ZIP magic bytes (PK\x03\x04) before claiming ZIP was generated
        const sigBytes = new Uint8Array(await zipBlob.slice(0, 4).arrayBuffer());
        if (sigBytes[0] !== 0x50 || sigBytes[1] !== 0x4b || sigBytes[2] !== 0x03 || sigBytes[3] !== 0x04) {
          throw new Error('Downloaded archive failed ZIP header verification.');
        }

        const blobUrl = URL.createObjectURL(zipBlob);
        setManualDownloadUrl(blobUrl);
        setZipSummary({ totalFiles, zipSizeBytes: zipBlob.size });
        setZipPhase('generated');
        setZipStatusDetail(`${totalFiles} files • ${formatZipSizeMb(zipBlob.size)}`);

        const inIframe = (() => {
          if (isIframe) return true;
          try {
            return window.self !== window.top;
          } catch {
            return true;
          }
        })();
        const hasActiveGesture =
          typeof navigator !== 'undefined' &&
          'userActivation' in navigator &&
          Boolean((navigator as any).userActivation?.isActive);

        // Only claim "Download started" automatically when browser still holds a valid user gesture
        // and is not inside a restricted iframe. Otherwise present the synchronous <a download> button
        // so the user's direct tap triggers Chrome's native download manager into Downloads.
        if (!inIframe && hasActiveGesture) {
          const link = document.createElement('a');
          link.href = blobUrl;
          link.download = EXPORT_FILENAME;
          link.style.display = 'none';
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
          setZipPhase('started');
          setZipStatusDetail(`${EXPORT_FILENAME} (${formatZipSizeMb(zipBlob.size)})`);
        }
      } catch (chunkErr) {
        // Fallback to direct server streaming link if in-browser chunk assembly was interrupted
        console.warn('[DownloadProjectZip] Falling back to direct download URL:', chunkErr);
        setManualDownloadUrl(directDownloadUrl);
        setZipSummary({ totalFiles, zipSizeBytes: totalZipBytes });
        setZipPhase('generated');
        setZipStatusDetail(`${totalFiles} files • ${formatZipSizeMb(totalZipBytes)} (tap Save ZIP)`);
      }
    } catch (err: any) {
      console.error('[DownloadProjectZip] Error:', err);
      const rawMsg = err?.message || 'Unable to generate project ZIP archive.';
      const message =
        rawMsg === 'Failed to fetch'
          ? 'Connection to server was interrupted. Please try again.'
          : rawMsg;
      setZipPhase('failed');
      setZipError(message);
      setZipStatusDetail(message);
    }
  };

  // Category Configuration for the 5 Main Groups
  const SETTINGS_CATEGORIES = [
    // Group 1: दिखावट
    {
      id: 'hologram',
      groupId: 'appearance',
      title: '3D Hologram',
      subtitle: '23 स्टाइल, डायनामिक इफ़ेक्ट',
      renderIcon: () => <Hexagon className="w-5 h-5" />,
    },
    {
      id: 'appearance',
      groupId: 'appearance',
      title: 'Theme & Look',
      subtitle: '8 थीम, मोशन कम करें',
      renderIcon: () => <Disc className="w-5 h-5" />,
    },
    {
      id: 'avatar',
      groupId: 'appearance',
      title: 'Avatar',
      subtitle: '10 जापानी 3D एनिमे अवतार',
      renderIcon: () => <User className="w-5 h-5" />,
    },

    // Group 2: आवाज़ और भाषा
    {
      id: 'battery_alerts',
      groupId: 'voice_lang',
      title: 'Battery Voice Alerts',
      subtitle: isBatteryVoiceAlertsEnabled ? 'चालू (ON) · चार्जर व 20%, 10%, 3%' : 'बंद (OFF)',
      renderIcon: () => <BatteryCharging className="w-5 h-5" />,
    },
    {
      id: 'voice',
      groupId: 'voice_lang',
      title: 'Voice Settings',
      subtitle: 'आवाज़ और स्पीड',
      renderIcon: () => <AudioLines className="w-5 h-5" />,
    },
    {
      id: 'language',
      groupId: 'voice_lang',
      title: 'Language',
      subtitle: 'भाषा चुनें',
      renderIcon: () => <Globe className="w-5 h-5" />,
    },
    {
      id: 'mode',
      groupId: 'voice_lang',
      title: 'Mode Options',
      subtitle: 'असिस्टेंट का मोड',
      renderIcon: () => <Heart className="w-5 h-5" />,
    },

    // Group 3: ऐप्स और टूल्स
    {
      id: 'youtube',
      groupId: 'apps_tools',
      title: 'YouTube & Singers',
      subtitle: 'फ़ेवरेट सिंगर्स का डेटा',
      renderIcon: () => <PlaySquare className="w-5 h-5" />,
    },
    {
      id: 'python_studio',
      groupId: 'apps_tools',
      title: 'Python Studio',
      subtitle: 'कोड इंजन और स्क्रिप्ट',
      renderIcon: () => <Code2 className="w-5 h-5" />,
    },
    {
      id: 'instagram_growth',
      groupId: 'apps_tools',
      title: 'Instagram Growth',
      subtitle: 'ज़ीरो-रुपया ऑटोमेशन',
      renderIcon: () => <Sparkles className="w-5 h-5" />,
    },
    {
      id: 'download_project',
      groupId: 'apps_tools',
      title: 'DOWNLOAD COMPLETE PROJECT (ZIP)',
      subtitle: 'Zoya_AI_Companion_Full_Project.zip',
      renderIcon: () => <Download className="w-5 h-5" />,
    },

    // Group 4: सुरक्षा
    {
      id: 'device_lock',
      groupId: 'security',
      title: 'Device Lock',
      subtitle: 'PIN और पासवर्ड',
      renderIcon: () => <Lock className="w-5 h-5" />,
    },
    {
      id: 'accessibility',
      groupId: 'security',
      title: 'Accessibility',
      subtitle: 'डिवाइस कंट्रोल',
      renderIcon: () => <Accessibility className="w-5 h-5" />,
    },

    // Group 5: API और मेमोरी
    {
      id: 'api_key',
      groupId: 'api_memory',
      title: 'API Settings',
      subtitle: 'Gemini और ElevenLabs',
      renderIcon: () => <KeyRound className="w-5 h-5" />,
    },
    {
      id: 'tool_api_keys',
      groupId: 'api_memory',
      title: 'Tool API Keys',
      subtitle: 'बाहरी टूल की keys',
      renderIcon: () => <PenTool className="w-5 h-5" />,
    },
    {
      id: 'memory',
      groupId: 'api_memory',
      title: 'Memory System',
      subtitle: 'अल्ट्रा-एडवांस्ड मेमोरी',
      renderIcon: () => <Brain className="w-5 h-5" />,
    },
  ];

  // Test Gemini connection
  const handleTestGeminiConnection = async () => {
    setIsTestingGemini(true);
    setGeminiTestResult(null);
    const startMs = Date.now();
    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: 'Ping connection check',
          personaMode,
          language: recLanguage,
          geminiApiKey: customApiKey.trim() || undefined,
        }),
      });
      const latencyMs = Date.now() - startMs;
      const data = await res.json().catch(() => ({}));
      if (res.ok && data?.reply) {
        setGeminiTestResult({
          success: true,
          latencyMs,
          message: `सफल कनेक्शन (Connected ✓ in ${latencyMs}ms)`,
        });
      } else {
        setGeminiTestResult({
          success: false,
          latencyMs,
          message: data?.error || `सर्वर रिस्पॉन्स: ${res.status}`,
        });
      }
    } catch (err: any) {
      setGeminiTestResult({
        success: false,
        message: err?.message || 'नेटवर्क कनेक्शन त्रुटि',
      });
    } finally {
      setIsTestingGemini(false);
    }
  };

  // Run Secret Vault Self-Test
  const handleRunVaultTest = async () => {
    setIsRunningVaultTest(true);
    try {
      const res = await runSecretVaultSelfTest();
      setVaultSelfTestResult(res);
    } finally {
      setIsRunningVaultTest(false);
    }
  };

  return (
    <div
      data-testid="zoya-settings-fullscreen"
      className="fixed inset-0 z-50 w-screen h-[100dvh] bg-[#0E1224] text-[#F3F5FF] flex flex-col overflow-hidden select-none"
      style={{
        paddingTop: 'env(safe-area-inset-top, 0px)',
        paddingBottom: 'env(safe-area-inset-bottom, 0px)',
      }}
    >
      {/* Top Header: Always visible, fixed, matching photo */}
      <header className="w-full shrink-0 h-[72px] px-[18px] flex items-center justify-between bg-[#0E1224] border-b border-[#262D4D]/40 z-30">
        <button
          type="button"
          onClick={handleBack}
          data-testid="settings-top-back-btn"
          className="h-[48px] px-5 rounded-[24px] bg-[#171C33] border border-[#262D4D] text-[#F3F5FF] text-[16px] font-bold flex items-center gap-2 hover:bg-[#1d2340] active:scale-95 transition-all cursor-pointer shadow-sm"
        >
          <ChevronLeft className="w-5 h-5 text-[#F3F5FF]" />
          <span>Back</span>
        </button>

        <button
          type="button"
          onClick={handleHome}
          data-testid="settings-top-home-btn"
          className="h-[48px] px-5 rounded-[24px] bg-[#171C33] border border-[#262D4D] text-[#F3F5FF] text-[16px] font-bold flex items-center gap-2 hover:bg-[#1d2340] active:scale-95 transition-all cursor-pointer shadow-sm"
        >
          <Home className="w-5 h-5 text-[#F3F5FF]" />
          <span>Home</span>
        </button>
      </header>

      {/* Content Area */}
      {activeItemId === null ? (
        /* ============================================================== */
        /* 1. SETTINGS MAIN LIST VIEW (EXACT PHOTO LAYOUT)                */
        /* ============================================================== */
        <div className="flex-1 min-h-0 overflow-y-auto overflow-x-hidden px-[18px] pb-12">
          <h1 className="text-[28px] font-extrabold text-[#F3F5FF] pt-2 pb-4 tracking-tight">
            Settings
          </h1>

          <div className="space-y-6">
            {SETTING_GROUPS.map((group) => {
              const groupItems = SETTINGS_CATEGORIES.filter((item) => item.groupId === group.id);
              if (groupItems.length === 0) return null;

              return (
                <div key={group.id} className="w-full">
                  <h3 className="text-[13px] font-bold text-[#A7AFD0] mb-2 px-1 tracking-wide">
                    {group.label}
                  </h3>

                  <div className="w-full bg-[#171C33] border border-[#262D4D] rounded-[20px] overflow-hidden divide-y divide-[#232A48] shadow-md">
                    {groupItems.map((item) => {
                      const dynamicVal = getDynamicValue(item.id);

                      if (item.id === 'battery_alerts') {
                        return (
                          <div
                            key={item.id}
                            data-testid="settings-row-battery-alerts"
                            className="w-full min-h-[66px] px-4 py-2 flex items-center justify-between text-left hover:bg-[#1c223d] transition-colors group"
                          >
                            <button
                              type="button"
                              onClick={() => setActiveItemId('battery_alerts')}
                              className="flex items-center gap-3.5 min-w-0 flex-1 pr-2 text-left cursor-pointer"
                            >
                              <div
                                className={`w-[40px] h-[40px] rounded-[12px] flex items-center justify-center shrink-0 shadow-sm transition-colors ${
                                  isBatteryVoiceAlertsEnabled
                                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-400/40'
                                    : 'bg-[#8C9BFF]/16 text-[#B4BEFF]'
                                }`}
                              >
                                <BatteryCharging className="w-5 h-5" />
                              </div>

                              <div className="min-w-0 flex-1">
                                <div className="text-[16px] font-bold text-[#F3F5FF] leading-tight truncate flex items-center gap-2">
                                  <span>{item.title}</span>
                                  <span
                                    className={`px-2 py-0.5 rounded-full text-[10px] font-black tracking-wide ${
                                      isBatteryVoiceAlertsEnabled
                                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-400/40'
                                        : 'bg-[#252d54] text-[#A7AFD0]'
                                    }`}
                                  >
                                    {isBatteryVoiceAlertsEnabled ? 'ALERTS ON' : 'ALERTS OFF'}
                                  </span>
                                  <span className="text-[11px] font-mono text-cyan-300 bg-cyan-950/60 border border-cyan-500/30 px-1.5 py-0.5 rounded">
                                    {batteryStatus.levelPercent}% {batteryStatus.isCharging ? '⚡' : '🔋'}
                                  </span>
                                </div>
                                <div className="text-[12.5px] font-medium text-[#A7AFD0] leading-tight truncate mt-1">
                                  {isBatteryVoiceAlertsEnabled
                                    ? 'चार्जर कनेक्ट/डिस्कनेक्ट व 20%, 10%, 3% पर तत्काल वॉयस'
                                    : 'बंद है: ऑन करें ताकि चार्जर व लो-बैटरी पर आवाज़ मिले'}
                                </div>
                              </div>
                            </button>

                            <div className="flex items-center gap-2.5 shrink-0 ml-2">
                              {/* Functional Battery Voice Alerts ON/OFF Toggle */}
                              <button
                                type="button"
                                role="switch"
                                aria-checked={isBatteryVoiceAlertsEnabled}
                                data-testid="settings-battery-alerts-quick-toggle"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleToggleBatteryVoiceAlerts(!isBatteryVoiceAlertsEnabled);
                                }}
                                className={`w-[54px] h-[30px] rounded-full p-[3px] transition-all duration-200 shrink-0 flex items-center cursor-pointer ${
                                  isBatteryVoiceAlertsEnabled
                                    ? 'bg-emerald-500 shadow-[0_0_14px_rgba(16,185,129,0.55)]'
                                    : 'bg-[#2A3156] border border-[#3b477c]'
                                }`}
                                title={
                                  isBatteryVoiceAlertsEnabled
                                    ? 'बैटरी वॉयस अलर्ट्स बंद करें (Turn OFF)'
                                    : 'बैटरी वॉयस अलर्ट्स चालू करें (Turn ON)'
                                }
                              >
                                <div
                                  className={`w-[24px] h-[24px] rounded-full bg-white shadow-md transition-transform duration-200 flex items-center justify-center ${
                                    isBatteryVoiceAlertsEnabled ? 'translate-x-[24px]' : 'translate-x-0'
                                  }`}
                                >
                                  <span
                                    className={`text-[8px] font-black ${
                                      isBatteryVoiceAlertsEnabled ? 'text-emerald-700' : 'text-slate-600'
                                    }`}
                                  >
                                    {isBatteryVoiceAlertsEnabled ? 'ON' : 'OFF'}
                                  </span>
                                </div>
                              </button>

                              <button
                                type="button"
                                onClick={() => setActiveItemId('battery_alerts')}
                                className="p-1.5 rounded-lg hover:bg-white/10 text-[#A7AFD0] hover:text-white transition-colors cursor-pointer"
                                title="Battery Voice Alerts विवरण व टेस्ट खोलें"
                              >
                                <ChevronRight className="w-[18px] h-[18px]" />
                              </button>
                            </div>
                          </div>
                        );
                      }

                      if (item.id === 'memory') {
                        return (
                          <div
                            key={item.id}
                            data-testid="settings-row-memory"
                            className="w-full min-h-[66px] px-4 py-2 flex items-center justify-between text-left hover:bg-[#1c223d] transition-colors group"
                          >
                            <button
                              type="button"
                              onClick={() => setActiveItemId('memory')}
                              className="flex items-center gap-3.5 min-w-0 flex-1 pr-2 text-left cursor-pointer"
                            >
                              <div
                                className={`w-[40px] h-[40px] rounded-[12px] flex items-center justify-center shrink-0 shadow-sm transition-colors ${
                                  use3DMemoryBackground
                                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-400/40'
                                    : 'bg-[#8C9BFF]/16 text-[#B4BEFF]'
                                }`}
                              >
                                {item.renderIcon()}
                              </div>

                              <div className="min-w-0 flex-1">
                                <div className="text-[16px] font-bold text-[#F3F5FF] leading-tight truncate flex items-center gap-2">
                                  <span>{item.title}</span>
                                  <span
                                    className={`px-2 py-0.5 rounded-full text-[10px] font-black tracking-wide ${
                                      use3DMemoryBackground
                                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-400/40'
                                        : 'bg-[#252d54] text-[#A7AFD0]'
                                    }`}
                                  >
                                    {use3DMemoryBackground ? 'HOME ON' : 'HOME OFF'}
                                  </span>
                                </div>
                                <div className="text-[12.5px] font-medium text-[#A7AFD0] leading-tight truncate mt-1">
                                  {use3DMemoryBackground
                                    ? '3D मेमोरी होम पर चालू • अवतार Avatar सेक्शन में सुरक्षित'
                                    : 'ON करें: होम स्क्रीन पर 3D मेमोरी सिस्टम दिखाएं'}
                                </div>
                              </div>
                            </button>

                            <div className="flex items-center gap-2.5 shrink-0 ml-2">
                              {/* Functional Home Screen Memory System ON/OFF Toggle */}
                              <button
                                type="button"
                                role="switch"
                                aria-checked={use3DMemoryBackground}
                                data-testid="settings-memory-home-toggle"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  onToggle3DMemoryBackground?.(!use3DMemoryBackground);
                                }}
                                className={`w-[54px] h-[30px] rounded-full p-[3px] transition-all duration-200 shrink-0 flex items-center cursor-pointer ${
                                  use3DMemoryBackground
                                    ? 'bg-emerald-500 shadow-[0_0_14px_rgba(16,185,129,0.55)]'
                                    : 'bg-[#2A3156] border border-[#3b477c]'
                                }`}
                                title={
                                  use3DMemoryBackground
                                    ? 'होम स्क्रीन से 3D Memory System हटाएं और अवतार वापस लाएं (Turn OFF)'
                                    : 'होम स्क्रीन पर 3D Memory System चालू करें और अवतार को Avatar सेक्शन में भेजें (Turn ON)'
                                }
                              >
                                <div
                                  className={`w-[24px] h-[24px] rounded-full bg-white shadow-md transition-transform duration-200 flex items-center justify-center ${
                                    use3DMemoryBackground ? 'translate-x-[24px]' : 'translate-x-0'
                                  }`}
                                >
                                  <span
                                    className={`text-[8px] font-black ${
                                      use3DMemoryBackground ? 'text-emerald-700' : 'text-slate-600'
                                    }`}
                                  >
                                    {use3DMemoryBackground ? 'ON' : 'OFF'}
                                  </span>
                                </div>
                              </button>

                              <button
                                type="button"
                                onClick={() => setActiveItemId('memory')}
                                className="p-1.5 rounded-lg hover:bg-white/10 text-[#A7AFD0] hover:text-white transition-colors cursor-pointer"
                                title="Memory System खोलें"
                              >
                                <ChevronRight className="w-[18px] h-[18px]" />
                              </button>
                            </div>
                          </div>
                        );
                      }

                      if (item.id === 'download_project') {
                        const phaseTitle =
                          zipPhase === 'preparing'
                            ? 'Preparing project files'
                            : zipPhase === 'archiving'
                              ? 'Creating ZIP archive'
                              : zipPhase === 'generated'
                                ? 'ZIP successfully generated'
                                : zipPhase === 'started'
                                  ? 'Download started'
                                  : zipPhase === 'failed'
                                    ? 'Download failed'
                                    : item.title;

                        const phaseSubtitle =
                          zipPhase === 'failed'
                            ? zipError || 'Unable to generate ZIP archive'
                            : zipPhase !== 'idle'
                              ? zipStatusDetail || item.subtitle
                              : item.subtitle;

                        return (
                          <div key={item.id} className="w-full">
                            <button
                              type="button"
                              disabled={isPreparingZip}
                              onClick={handleDownloadProjectZip}
                              data-testid="settings-row-download-project"
                              className="w-full h-[66px] px-4 flex items-center justify-between text-left hover:bg-[#1c223d] active:bg-[#202747] transition-colors cursor-pointer disabled:opacity-80 disabled:cursor-wait group"
                            >
                              <div className="flex items-center gap-3.5 min-w-0 flex-1 pr-2">
                                <div className="w-[40px] h-[40px] rounded-[12px] bg-[#8C9BFF]/16 flex items-center justify-center shrink-0 text-[#B4BEFF] shadow-sm">
                                  {isPreparingZip ? (
                                    <Loader2 className="w-5 h-5 animate-spin" />
                                  ) : (
                                    item.renderIcon()
                                  )}
                                </div>

                                <div className="min-w-0 flex-1">
                                  <div
                                    className={`text-[15.5px] font-bold leading-tight truncate ${
                                      zipPhase === 'failed'
                                        ? 'text-rose-300'
                                        : zipPhase === 'started' || zipPhase === 'generated'
                                          ? 'text-emerald-300'
                                          : 'text-[#F3F5FF]'
                                    }`}
                                  >
                                    {phaseTitle}
                                  </div>
                                  <div
                                    className={`text-[12.5px] font-medium leading-tight truncate mt-1 ${
                                      zipPhase === 'failed' ? 'text-rose-200/90' : 'text-[#A7AFD0]'
                                    }`}
                                  >
                                    {phaseSubtitle}
                                  </div>
                                </div>
                              </div>

                              <div className="flex items-center gap-2 shrink-0 ml-2">
                                <span className="text-[13px] font-bold text-[#B4BEFF]">
                                  {dynamicVal}
                                </span>
                                {!isPreparingZip && (
                                  <ChevronRight className="w-[18px] h-[18px] text-[#A7AFD0] group-hover:translate-x-0.5 transition-transform" />
                                )}
                              </div>
                            </button>

                            {manualDownloadUrl && !isPreparingZip && (zipPhase === 'generated' || zipPhase === 'started') && (
                              <div className="px-4 py-2.5 bg-[#12162b] border-t border-[#232A48] flex items-center justify-between gap-2">
                                <div className="min-w-0 flex-1">
                                  <div className="text-[12px] font-semibold text-[#F3F5FF] truncate">
                                    {zipPhase === 'started'
                                      ? 'Download started — check browser Downloads'
                                      : 'ZIP successfully generated — tap Save to download'}
                                  </div>
                                  {zipSummary && (
                                    <div className="text-[11px] text-[#A7AFD0] truncate">
                                      Zoya_AI_Companion_Full_Project.zip ({formatZipSizeMb(zipSummary.zipSizeBytes)})
                                    </div>
                                  )}
                                </div>
                                <a
                                  href={manualDownloadUrl}
                                  download="Zoya_AI_Companion_Full_Project.zip"
                                  onClick={() => {
                                    setZipPhase('started');
                                    if (zipSummary) {
                                      setZipStatusDetail(
                                        `Zoya_AI_Companion_Full_Project.zip (${formatZipSizeMb(zipSummary.zipSizeBytes)})`
                                      );
                                    }
                                  }}
                                  data-testid="settings-manual-download-project-link"
                                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-[10px] bg-[#8C9BFF]/20 hover:bg-[#8C9BFF]/30 border border-[#8C9BFF]/40 text-[#B4BEFF] text-[12.5px] font-bold shrink-0 transition-colors"
                                >
                                  <Download className="w-3.5 h-3.5" />
                                  <span>Save ZIP</span>
                                </a>
                              </div>
                            )}
                          </div>
                        );
                      }

                      return (
                        <button
                          key={item.id}
                          type="button"
                          onClick={() => setActiveItemId(item.id)}
                          data-testid={`settings-row-${item.id}`}
                          className="w-full h-[66px] px-4 flex items-center justify-between text-left hover:bg-[#1c223d] active:bg-[#202747] transition-colors cursor-pointer group"
                        >
                          <div className="flex items-center gap-3.5 min-w-0 flex-1 pr-2">
                            <div className="w-[40px] h-[40px] rounded-[12px] bg-[#8C9BFF]/16 flex items-center justify-center shrink-0 text-[#B4BEFF] shadow-sm">
                              {item.renderIcon()}
                            </div>

                            <div className="min-w-0 flex-1">
                              <div className="text-[16px] font-bold text-[#F3F5FF] leading-tight truncate">
                                {item.title}
                              </div>
                              <div className="text-[13px] font-medium text-[#A7AFD0] leading-tight truncate mt-1">
                                {item.subtitle}
                              </div>
                            </div>
                          </div>

                          <div className="flex items-center gap-2 shrink-0 ml-2">
                            <span className="text-[13px] font-bold text-[#B4BEFF]">
                              {dynamicVal}
                            </span>
                            <ChevronRight className="w-[18px] h-[18px] text-[#A7AFD0] group-hover:translate-x-0.5 transition-transform" />
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      ) : (
        /* ============================================================== */
        /* 2. SUBPAGE DETAIL VIEW — RESTORED COMPLETE REAL CONTROLS       */
        /* ============================================================== */
        <div className="flex-1 min-h-0 overflow-y-auto overflow-x-hidden px-[18px] pb-12">
          {/* CATEGORY 1: 3D HOLOGRAM */}
          {activeItemId === 'hologram' && (
            <div className="animate-fadeIn pt-2">
              <ZoyaHologramSettings
                onBack={() => setActiveItemId(null)}
                voiceStatus={voiceStatus}
              />
            </div>
          )}

          {/* CATEGORY 2: THEME & LOOK / APPEARANCE */}
          {activeItemId === 'appearance' && (
            <div className="animate-fadeIn pt-2 space-y-6">
              <div>
                <h1 className="text-[26px] font-extrabold text-[#F3F5FF]">
                  Theme & Look
                </h1>
                <p className="text-[13px] font-medium text-[#A7AFD0] mt-1">
                  8 संपूर्ण थीम्स, रंग पैलेट और मोशन कम करने की सुविधा
                </p>
              </div>

              {/* 8 Themes Grid */}
              <div>
                <h3 className="text-[13px] font-bold text-[#A7AFD0] mb-3 px-1">
                  थीम चुनें (8 Themes Available)
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {(Object.keys(APP_THEMES) as AppThemeId[]).map((tId) => {
                    const theme = APP_THEMES[tId];
                    const isSelected = currentTheme === tId;
                    return (
                      <button
                        key={tId}
                        type="button"
                        onClick={() => {
                          themeManager.setTheme(tId);
                          setCurrentTheme(tId);
                        }}
                        className={`p-4 rounded-[18px] border text-left flex flex-col justify-between gap-3 transition-all cursor-pointer ${
                          isSelected
                            ? 'bg-[#1e2548] border-[#8C9BFF] shadow-[0_0_15px_rgba(140,155,255,0.3)]'
                            : 'bg-[#171C33] hover:bg-[#1d2342] border-[#262D4D]'
                        }`}
                      >
                        <div className="flex items-start justify-between gap-2">
                          <div>
                            <div className="text-[15px] font-bold text-[#F3F5FF] flex items-center gap-2">
                              {theme.name}
                              <span className="text-[12px] font-normal text-[#A7AFD0]">
                                ({theme.nativeName})
                              </span>
                            </div>
                            <p className="text-[12px] text-[#A7AFD0] mt-1 line-clamp-1">
                              {theme.desc}
                            </p>
                          </div>
                          {isSelected && (
                            <div className="w-5 h-5 rounded-full bg-[#8C9BFF] text-[#0B1030] flex items-center justify-center shrink-0">
                              <Check className="w-3.5 h-3.5 stroke-[3]" />
                            </div>
                          )}
                        </div>

                        {/* Color swatches */}
                        <div className="flex items-center gap-1.5 pt-1">
                          {theme.previewColors.map((c, i) => (
                            <span
                              key={i}
                              style={{ backgroundColor: c }}
                              className="w-4 h-4 rounded-full border border-white/20 shadow-xs"
                            />
                          ))}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Reduce Motion Card */}
              <div className="p-4 rounded-[20px] bg-[#171C33] border border-[#262D4D] flex items-center justify-between shadow-md">
                <div className="pr-3">
                  <div className="text-[15px] font-bold text-[#F3F5FF]">
                    मोशन कम करें (Reduce Motion)
                  </div>
                  <p className="text-[12px] text-[#A7AFD0] mt-0.5">
                    अनावश्यक एनिमेशन, पल्सिंग और ब्लिंक को धीमा या बंद करें (आंखों के आराम के लिए)
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    const next = !isReduceMotion;
                    themeManager.setReduceMotion(next);
                    setIsReduceMotion(next);
                  }}
                  className={`w-[52px] h-[30px] rounded-full p-[3px] transition-colors duration-200 shrink-0 flex items-center cursor-pointer ${
                    isReduceMotion ? 'bg-[#6D7CFF]' : 'bg-[#2A3156]'
                  }`}
                >
                  <div
                    className={`w-[24px] h-[24px] rounded-full bg-white shadow-md transition-transform duration-200 ${
                      isReduceMotion ? 'translate-x-[22px]' : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>

              {/* Quick Jump to Avatar */}
              <button
                type="button"
                onClick={() => setActiveItemId('avatar')}
                className="w-full p-4 rounded-[20px] bg-[#171C33] hover:bg-[#1d2342] border border-[#262D4D] flex items-center justify-between text-left transition-colors cursor-pointer"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-[#8C9BFF]/20 flex items-center justify-center text-[#B4BEFF]">
                    <User className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-[15px] font-bold text-[#F3F5FF]">
                      Avatar Style
                    </div>
                    <div className="text-[12px] text-[#A7AFD0]">
                      10 जापानी 3D एनिमे व क्लासिक अवतार चुनें
                    </div>
                  </div>
                </div>
                <ChevronRight className="w-5 h-5 text-[#A7AFD0]" />
              </button>
            </div>
          )}

          {/* CATEGORY 3: AVATAR SETTINGS — FULL 3D AVATARS */}
          {activeItemId === 'avatar' && (
            <div className="animate-fadeIn pt-2 space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                <div>
                  <h1 className="text-[26px] font-extrabold text-[#F3F5FF] tracking-tight">
                    Avatar Settings
                  </h1>
                  <p className="text-[13px] font-medium text-[#A7AFD0] mt-1">
                    Full HD लिविंग अवतार संग्रह • क्रिस्टल क्लियर फेस, संपूर्ण ओरिजिनल परिधान व स्वाभाविक ग्राउंड अलाइनमेंट
                  </p>
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  {onOpen14LivingAvatarsShowcase && (
                    <button
                      type="button"
                      onClick={onOpen14LivingAvatarsShowcase}
                      data-testid="open-14-avatars-showcase-btn"
                      className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-purple-600 via-indigo-600 to-cyan-500 hover:from-purple-500 hover:to-cyan-400 text-white text-[12px] font-black flex items-center gap-1.5 transition-all cursor-pointer shadow-md active:scale-95 shrink-0"
                      title="14 Living Avatars Showcase: Locked-Off Camera Shot with Live Breeze & Staggered Biological Blinking"
                    >
                      <Sparkles className="w-3.5 h-3.5 text-cyan-200" />
                      <span>🎥 14 Living Avatars (Locked Camera)</span>
                    </button>
                  )}
                  <span className="px-3 py-1 rounded-full bg-[#8C9BFF]/15 border border-[#8C9BFF]/35 text-[#B4BEFF] text-[12px] font-extrabold shrink-0">
                    {allAvatarsList.length} Full HD Avatars
                  </span>
                  <label className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700 text-white text-[12px] font-extrabold flex items-center gap-1.5 transition-all cursor-pointer shadow-md active:scale-95 shrink-0">
                    <Upload className="w-3.5 h-3.5" />
                    <span>{isUploadingAvatar ? 'प्रोसेसिंग...' : 'कस्टम अवतार अपलोड'}</span>
                    <input
                      ref={avatarFileInputRef}
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={handleUploadAvatarFile}
                      disabled={isUploadingAvatar}
                    />
                  </label>
                </div>
              </div>

              {uploadAvatarError && (
                <div className="p-3 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-[12.5px] font-semibold flex items-center justify-between">
                  <span>{uploadAvatarError}</span>
                  <button
                    type="button"
                    onClick={() => setUploadAvatarError(null)}
                    className="text-white font-bold ml-2 cursor-pointer"
                  >
                    ✕
                  </button>
                </div>
              )}

              {/* Active Selected 3D Avatar Showcase Banner & Display Controls */}
              {(() => {
                const active3D = allAvatarsList.find((a) => a.id === selected3DAvatarId) || allAvatarsList[0];
                return (
                  <div className="p-4 sm:p-5 rounded-[22px] bg-gradient-to-r from-[#171C33] via-[#1c2242] to-[#171C33] border-2 border-[#8C9BFF]/60 shadow-[0_0_24px_rgba(140,155,255,0.25)] flex flex-col gap-4">
                    <div className="flex flex-col sm:flex-row items-center gap-4">
                      {/* Character Transparent Preview Box */}
                      <div className="relative w-28 h-40 sm:w-32 sm:h-44 rounded-2xl bg-[#090C19] border border-[#8C9BFF]/50 overflow-hidden shrink-0 shadow-lg group flex items-center justify-center p-1">
                        <BlinkingAvatarImage
                          avatarId={active3D.id}
                          src={active3D.transparentPng}
                          alt={active3D.name}
                          imageClassName="transition-transform duration-300 group-hover:scale-105"
                        />
                        <button
                          type="button"
                          onClick={() => setPreview3DAvatar(active3D)}
                          className="absolute bottom-1.5 right-1.5 p-1.5 rounded-lg bg-[#0E1224]/85 text-white/90 hover:text-white border border-white/20 transition-all cursor-pointer shadow-md"
                          title="बड़ा देखें"
                        >
                          <Maximize2 className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <div className="flex-1 text-center sm:text-left min-w-0">
                        <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 mb-1.5">
                          {use3DMemoryBackground ? (
                            <span className="px-2.5 py-0.5 rounded-full bg-cyan-500/20 border border-cyan-400/50 text-cyan-200 text-[11px] font-extrabold flex items-center gap-1.5">
                              <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
                              अवतार सेक्शन में सुरक्षित • 3D Memory होम पर चालू है
                            </span>
                          ) : is3DAvatarActive ? (
                            <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-400/50 text-emerald-300 text-[11px] font-extrabold flex items-center gap-1.5 shadow-[0_0_10px_rgba(52,211,153,0.3)]">
                              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                              होम स्क्रीन पर चालू • ACTIVE ON
                            </span>
                          ) : (
                            <span className="px-2.5 py-0.5 rounded-full bg-amber-500/20 border border-amber-400/40 text-amber-300 text-[11px] font-extrabold flex items-center gap-1.5">
                              <span className="w-2 h-2 rounded-full bg-amber-400" />
                              होम स्क्रीन पर बंद • OFF (Classic Active)
                            </span>
                          )}
                          <span className="px-2 py-0.5 rounded-full bg-[#8C9BFF]/20 text-[#B4BEFF] text-[11px] font-bold">
                            {active3D.tag}
                          </span>
                        </div>

                        <h2 className="text-[20px] font-extrabold text-white flex items-center justify-center sm:justify-start gap-2">
                          {active3D.name}
                          <span className="text-[14px] font-medium text-[#B4BEFF]">
                            ({active3D.japaneseName})
                          </span>
                        </h2>

                        <p className="text-[13px] text-[#C4CDFA] font-medium mt-1">
                          {active3D.outfit}
                        </p>
                        <p className="text-[12px] text-[#A7AFD0] mt-1 leading-relaxed">
                          {active3D.description}
                        </p>

                        <div className="mt-3 flex flex-wrap items-center justify-center sm:justify-start gap-2.5">
                          {/* Master Home Screen Display Toggle Button */}
                          <button
                            type="button"
                            onClick={() => {
                              if (use3DMemoryBackground) {
                                handleToggleGlobal3D(true);
                              } else {
                                handleToggleGlobal3D(!is3DAvatarActive);
                              }
                            }}
                            data-testid="master-avatar-toggle-btn"
                            className={`px-4 py-2 rounded-xl text-[13px] font-black flex items-center gap-2 transition-all cursor-pointer active:scale-95 shadow-md ${
                              is3DAvatarActive && !use3DMemoryBackground
                                ? 'bg-rose-500 hover:bg-rose-600 text-white shadow-[0_0_16px_rgba(244,63,94,0.4)]'
                                : 'bg-emerald-500 hover:bg-emerald-600 text-slate-950 shadow-[0_0_16px_rgba(16,185,129,0.4)]'
                            }`}
                          >
                            <Power className="w-4 h-4 stroke-[2.5]" />
                            <span>
                              {is3DAvatarActive && !use3DMemoryBackground
                                ? 'होम स्क्रीन से हटाएं (Turn OFF)'
                                : 'होम स्क्रीन पर चालू करें (Turn ON)'}
                            </span>
                          </button>

                          <button
                            type="button"
                            onClick={() => setPreview3DAvatar(active3D)}
                            className="px-4 py-2 rounded-xl bg-[#1e2548] hover:bg-[#28315e] border border-[#37416e] text-[#B4BEFF] text-[12.5px] font-bold flex items-center gap-1.5 transition-all cursor-pointer active:scale-95 shadow-sm"
                          >
                            <ZoomIn className="w-4 h-4" />
                            <span>फुल प्रीव्यू देखें</span>
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* Avatar Display Controls (Scale & Vertical Offset) */}
                    <div className="mt-2 pt-3 border-t border-[#2d3663] bg-[#101426]/70 rounded-xl p-3.5 space-y-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Sliders className="w-4 h-4 text-[#8C9BFF]" />
                          <span className="text-[13px] font-extrabold text-[#F3F5FF]">
                            अवतार डिस्प्ले कंट्रोल (Display Controls)
                          </span>
                        </div>
                        <button
                          type="button"
                          onClick={handleResetControls}
                          className="px-2.5 py-1 rounded-lg bg-[#1a213e] hover:bg-[#26305a] border border-[#354170] text-[#A7AFD0] hover:text-white text-[11px] font-bold flex items-center gap-1 transition-all cursor-pointer"
                          title="डिफ़ॉल्ट साइज व पोजीशन रीसेट करें"
                        >
                          <RotateCcw className="w-3 h-3" />
                          <span>रीसेट (Default)</span>
                        </button>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        {/* Size / Scale Slider */}
                        <div className="bg-[#171C33] border border-[#262D4D] rounded-xl p-2.5">
                          <div className="flex items-center justify-between text-[12px] mb-1.5">
                            <span className="text-[#A7AFD0] font-medium">अवतार का आकार (Scale):</span>
                            <span className="text-[#8C9BFF] font-black">{Math.round(avatarScale * 100)}%</span>
                          </div>
                          <input
                            type="range"
                            min="0.7"
                            max="1.4"
                            step="0.05"
                            value={avatarScale}
                            onChange={(e) => handleScaleChange(parseFloat(e.target.value))}
                            className="w-full accent-[#8C9BFF] cursor-pointer"
                          />
                        </div>

                        {/* Vertical Offset Slider */}
                        <div className="bg-[#171C33] border border-[#262D4D] rounded-xl p-2.5">
                          <div className="flex items-center justify-between text-[12px] mb-1.5">
                            <span className="text-[#A7AFD0] font-medium">ऊपर/नीचे पोजीशन (Y-Offset):</span>
                            <span className="text-[#8C9BFF] font-black">
                              {avatarOffsetY > 0 ? `+${avatarOffsetY}px` : `${avatarOffsetY}px`}
                            </span>
                          </div>
                          <input
                            type="range"
                            min="-50"
                            max="50"
                            step="2"
                            value={avatarOffsetY}
                            onChange={(e) => handleOffsetYChange(parseFloat(e.target.value))}
                            className="w-full accent-[#8C9BFF] cursor-pointer"
                          />
                        </div>

                        {/* Liveliness K Slider (जीवंतता) */}
                        <div className="bg-[#171C33] border border-[#262D4D] rounded-xl p-2.5 sm:col-span-2">
                          <div className="flex items-center justify-between text-[12px] mb-1.5">
                            <span className="text-[#A7AFD0] font-medium">जीवंतता (Liveliness K Factor):</span>
                            <span className="text-[#8C9BFF] font-black">{livelinessK.toFixed(2)}x</span>
                          </div>
                          <input
                            type="range"
                            min="0.2"
                            max="1.8"
                            step="0.05"
                            value={livelinessK}
                            onChange={(e) => handleLivelinessChange(parseFloat(e.target.value))}
                            className="w-full accent-[#8C9BFF] cursor-pointer"
                          />
                          <div className="flex justify-between text-[10px] text-[#717b9e] mt-1 font-mono">
                            <span>0.2x (शांत / Calmer)</span>
                            <span>1.0x (स्वाभाविक / Default)</span>
                            <span>1.8x (सक्रिय / High Energy)</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })()}

              {/* Avatar Collection Tabs */}
              <div className="flex items-center gap-2 p-1.5 rounded-2xl bg-[#13172c] border border-[#262D4D]">
                <button
                  type="button"
                  onClick={() => setAvatarTab('3d_japanese')}
                  className={`flex-1 py-2.5 px-3 rounded-xl text-[13px] font-bold transition-all flex items-center justify-center gap-2 cursor-pointer ${
                    avatarTab === '3d_japanese'
                      ? 'bg-[#8C9BFF] text-[#0B1030] shadow-[0_0_15px_rgba(140,155,255,0.4)]'
                      : 'text-[#A7AFD0] hover:text-white'
                  }`}
                >
                  <Sparkles className="w-4 h-4" />
                  <span>लिविंग अवतार संग्रह (Living HD)</span>
                  <span className={`px-1.5 py-0.2 rounded-md text-[10px] font-black ${
                    avatarTab === '3d_japanese' ? 'bg-[#0B1030]/20 text-[#0B1030]' : 'bg-[#1e2548] text-[#B4BEFF]'
                  }`}>
                    {allAvatarsList.length}
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => setAvatarTab('classic')}
                  className={`flex-1 py-2.5 px-3 rounded-xl text-[13px] font-bold transition-all flex items-center justify-center gap-2 cursor-pointer ${
                    avatarTab === 'classic'
                      ? 'bg-[#8C9BFF] text-[#0B1030] shadow-[0_0_15px_rgba(140,155,255,0.4)]'
                      : 'text-[#A7AFD0] hover:text-white'
                  }`}
                >
                  <Crown className="w-4 h-4" />
                  <span>क्लासिक ज़ोया स्टाइल्स</span>
                  <span className={`px-1.5 py-0.2 rounded-md text-[10px] font-black ${
                    avatarTab === 'classic' ? 'bg-[#0B1030]/20 text-[#0B1030]' : 'bg-[#1e2548] text-[#B4BEFF]'
                  }`}>
                    2
                  </span>
                </button>
              </div>

              {/* TAB 1: FULL HD LIVING AVATARS GRID WITH INDIVIDUAL ON/OFF BUTTONS */}
              {avatarTab === '3d_japanese' && (
                <div className="space-y-4 animate-fadeIn">
                  <div className="flex items-center justify-between px-1">
                    <h3 className="text-[14px] font-bold text-[#F3F5FF]">
                      Full HD लिविंग अवतार (जीवंत श्वास व स्वाभाविक पलकें)
                    </h3>
                    <span className="text-[12px] font-medium text-[#A7AFD0]">
                      पारदर्शी PNG • अल्फा मैट • 0 एज लाइन्स • स्वाभाविक पलकें
                    </span>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 gap-3.5 sm:gap-4">
                    {allAvatarsList.map((av, index) => {
                      const isThisSelected = selected3DAvatarId === av.id;
                      const isThisActiveOnHomeScreen = isThisSelected && is3DAvatarActive && !use3DMemoryBackground;

                      return (
                        <div
                          key={av.id}
                          onClick={() => handleSelect3DAvatar(av.id)}
                          className={`group relative rounded-[20px] border p-3 flex flex-col justify-between transition-all duration-200 cursor-pointer ${
                            isThisActiveOnHomeScreen
                              ? 'bg-[#1e2548] border-emerald-400 shadow-[0_0_22px_rgba(52,211,153,0.3)] ring-1 ring-emerald-400'
                              : isThisSelected
                              ? 'bg-[#1a203f] border-[#8C9BFF] shadow-[0_0_16px_rgba(140,155,255,0.25)]'
                              : 'bg-[#171C33] hover:bg-[#1d2342] border-[#262D4D]'
                          }`}
                        >
                          {/* Image Box with Full HD Transparent Avatar */}
                          <div className="relative w-full aspect-[9/15] rounded-xl bg-[#090C19] border border-[#262D4D] overflow-hidden mb-2.5 flex items-center justify-center p-1.5">
                            <BlinkingAvatarImage
                              avatarId={av.id}
                              src={av.transparentPng}
                              alt={av.name}
                              imageClassName="transition-transform duration-300 group-hover:scale-105"
                              loading="lazy"
                            />

                            {/* Top Badge: Number & Tag */}
                            <div className="absolute top-2 left-2 right-2 flex items-center justify-between pointer-events-none">
                              <span className="px-2 py-0.5 rounded-md bg-[#0E1224]/90 backdrop-blur-md text-[#8C9BFF] text-[10px] font-black border border-[#8C9BFF]/30">
                                #{index + 1}
                              </span>
                              <span className="px-2 py-0.5 rounded-md bg-[#0E1224]/90 backdrop-blur-md text-[#E0E7FF] text-[10px] font-bold border border-white/10 truncate max-w-[90px]">
                                {av.tag}
                              </span>
                            </div>

                            {/* Zoom Icon Button */}
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                setPreview3DAvatar(av);
                              }}
                              className="absolute bottom-2 right-2 w-7 h-7 rounded-lg bg-[#0E1224]/85 hover:bg-[#8C9BFF] text-white hover:text-[#0B1030] border border-white/20 flex items-center justify-center transition-all cursor-pointer shadow-md"
                              title="फुल प्रीव्यू"
                            >
                              <Maximize2 className="w-3.5 h-3.5" />
                            </button>

                            {/* Active Indicator Overlay */}
                            {isThisActiveOnHomeScreen && (
                              <div className="absolute top-2 right-2 px-2 py-0.5 rounded-full bg-emerald-500 text-slate-950 font-black text-[9px] flex items-center gap-1 shadow-md border border-white/40">
                                <span className="w-1.5 h-1.5 rounded-full bg-slate-950 animate-ping" />
                                <span>ON</span>
                              </div>
                            )}
                          </div>

                          {/* Info */}
                          <div className="flex-1 flex flex-col justify-between">
                            <div>
                              <div className="flex items-center justify-between gap-1.5 mb-1">
                                <h4 className="text-[13.5px] font-extrabold text-[#F3F5FF] leading-snug truncate">
                                  {av.name}
                                </h4>
                                <div className="flex items-center gap-1.5 shrink-0">
                                  {av.isCustom && (
                                    <button
                                      type="button"
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        deleteCustomAvatar(av.id);
                                        setAllAvatarsList(getAllAvatars());
                                      }}
                                      className="p-1 rounded-lg bg-rose-500/20 hover:bg-rose-500 text-rose-300 hover:text-white border border-rose-500/40 transition-all cursor-pointer"
                                      title="अवतार हटाएं"
                                    >
                                      <Trash2 className="w-3.5 h-3.5" />
                                    </button>
                                  )}
                                  {/* Dedicated Individual ON/OFF Switch Pill for this Avatar */}
                                  <button
                                    type="button"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      handleToggleAvatar(av.id);
                                    }}
                                    data-testid={`avatar-pill-toggle-${av.id}`}
                                    className={`w-11 h-6 rounded-full p-0.5 transition-colors duration-200 shrink-0 flex items-center cursor-pointer ${
                                      isThisActiveOnHomeScreen
                                        ? 'bg-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.5)]'
                                        : 'bg-[#252d54] border border-[#3b477c]'
                                    }`}
                                    title={
                                      isThisActiveOnHomeScreen
                                        ? `${av.name} को होम स्क्रीन से हटाएं (Turn OFF)`
                                        : `${av.name} को होम स्क्रीन पर चालू करें (Turn ON)`
                                    }
                                  >
                                    <div
                                      className={`w-5 h-5 rounded-full bg-white shadow-md transform transition-transform duration-200 flex items-center justify-center ${
                                        isThisActiveOnHomeScreen ? 'translate-x-5' : 'translate-x-0'
                                      }`}
                                    >
                                      <span
                                        className={`text-[7.5px] font-black ${
                                          isThisActiveOnHomeScreen ? 'text-emerald-700' : 'text-slate-600'
                                        }`}
                                      >
                                        {isThisActiveOnHomeScreen ? 'ON' : 'OFF'}
                                      </span>
                                    </div>
                                  </button>
                                </div>
                              </div>
                              <p className="text-[11px] font-medium text-[#B4BEFF] truncate">
                                {av.japaneseName}
                              </p>
                              <p className="text-[11px] text-[#A7AFD0] mt-1 line-clamp-2 leading-relaxed">
                                {av.description}
                              </p>
                            </div>

                            {/* INDIVIDUAL CONTROLS: ACTION BUTTON & PREVIEW BUTTON */}
                            <div className="mt-3 space-y-1.5">
                              <button
                                type="button"
                                onClick={() => handleToggleAvatar(av.id)}
                                data-testid={`avatar-toggle-btn-${av.id}`}
                                className={`w-full py-2 px-2 rounded-xl text-[12px] font-black flex items-center justify-center gap-1.5 transition-all cursor-pointer active:scale-95 ${
                                  isThisActiveOnHomeScreen
                                    ? 'bg-emerald-500 hover:bg-emerald-600 text-slate-950 shadow-[0_0_14px_rgba(52,211,153,0.4)]'
                                    : 'bg-[#1e2548] hover:bg-[#283260] text-[#B4BEFF] hover:text-white border border-[#333f72]'
                                }`}
                              >
                                <Power className="w-3.5 h-3.5 stroke-[2.5]" />
                                <span>
                                  {isThisActiveOnHomeScreen
                                    ? 'चालू है (ON) • बंद करें'
                                    : 'चालू करें (Turn ON)'}
                                </span>
                              </button>

                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setPreview3DAvatar(av);
                                }}
                                className="w-full py-1.5 px-2 rounded-lg bg-[#111528] hover:bg-[#1a203d] border border-[#262f54] text-[#A7AFD0] hover:text-[#C4CDFA] text-[11px] font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                              >
                                <Eye className="w-3 h-3 text-[#8C9BFF]" />
                                <span>प्रीव्यू देखें (Preview)</span>
                              </button>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* TAB 2: CLASSIC STYLES GRID */}
              {avatarTab === 'classic' && (
                <div className="space-y-4 animate-fadeIn">
                  <div className="flex items-center justify-between px-1">
                    <h3 className="text-[14px] font-bold text-[#F3F5FF]">
                      क्लासिक ज़ोया स्टाइल्स (Classic Styles)
                    </h3>
                    <span className="text-[12px] font-medium text-[#A7AFD0]">
                      पारंपरिक 3D व साड़ी
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                    {[
                      {
                        id: 'classic',
                        title: 'Zoya 3D Living Avatar',
                        desc: 'क्रीम साटन शर्ट, ब्लैक हेयर, चश्मा, हाई-वेस्टेड ब्लू डेनिम शॉर्ट्स व गोल्डन बटन्स (फुल 3D रियल-टाइम अवतार)',
                        img: '/assets/images/zoya_new_avatar_transparent.png',
                      },
                    ].map((av) => {
                      const isSelected = selected3DAvatarId === av.id;
                      return (
                        <button
                          key={av.id}
                          type="button"
                          onClick={() => {
                            setAvatarStyle(av.id as AvatarStyle);
                            handleSelect3DAvatar(av.id);
                          }}
                          className={`p-3.5 rounded-[20px] border text-left flex items-center gap-3.5 transition-all cursor-pointer ${
                            isSelected
                              ? 'bg-[#1e2548] border-[#8C9BFF] shadow-[0_0_18px_rgba(140,155,255,0.35)]'
                              : 'bg-[#171C33] hover:bg-[#1d2342] border-[#262D4D]'
                          }`}
                        >
                          <div className="w-16 h-16 rounded-xl bg-[#0E1224] border border-[#262D4D] overflow-hidden shrink-0 flex items-center justify-center p-0.5">
                            <BlinkingAvatarImage
                              avatarId={av.id}
                              src={av.img}
                              alt={av.title}
                              imageClassName="w-full h-full object-contain"
                            />
                          </div>
                          <div className="min-w-0 flex-1">
                            <div className="text-[15px] font-bold text-[#F3F5FF] flex items-center justify-between">
                              <span className="truncate">{av.title}</span>
                              {isSelected && (
                                <span className="px-2 py-0.5 rounded-full bg-[#8C9BFF] text-[#0B1030] text-[10px] font-extrabold shrink-0">
                                  ACTIVE ✓
                                </span>
                              )}
                            </div>
                            <p className="text-[12px] text-[#A7AFD0] mt-1 line-clamp-2">
                              {av.desc}
                            </p>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Full Preview Modal for Transparent 3D Anime Avatars */}
              {preview3DAvatar && (
                <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
                  <div className="relative w-full max-w-md bg-[#13172c] border-2 border-[#8C9BFF]/60 rounded-[26px] p-5 shadow-2xl flex flex-col items-center max-h-[92vh] overflow-y-auto">
                    {/* Close Button */}
                    <button
                      type="button"
                      onClick={() => setPreview3DAvatar(null)}
                      className="absolute top-4 right-4 w-9 h-9 rounded-full bg-[#1b213d] hover:bg-[#28315e] border border-[#3b477a] text-white flex items-center justify-center transition-all cursor-pointer shadow-md"
                      title="बंद करें"
                    >
                      ✕
                    </button>

                    {/* Full HD 3D Avatar Preview with Natural Ground Alignment */}
                    <div className="relative w-full aspect-[9/15] max-h-[52vh] rounded-2xl bg-[#090C19] border border-[#262D4D] overflow-hidden flex items-center justify-center shadow-xl p-3">
                      <ZoyaLiving3DAvatar
                        key={preview3DAvatar.id}
                        avatarId={preview3DAvatar.id}
                        className="w-full h-full"
                      />
                      <span className="absolute top-3 left-3 px-3 py-1 rounded-full bg-[#0E1224]/90 border border-[#8C9BFF]/40 text-[#B4BEFF] text-[11px] font-extrabold backdrop-blur-md z-10 pointer-events-none">
                        {preview3DAvatar.tag}
                      </span>
                      <span className="absolute bottom-3 left-3 px-2.5 py-0.5 rounded-full bg-sky-500/20 border border-sky-400/40 text-sky-300 text-[10px] font-bold backdrop-blur-md z-10 pointer-events-none flex items-center gap-1.5">
                        <span className="w-1.5 h-1.5 rounded-full bg-sky-400" />
                        Full HD 3D प्रस्तुति
                      </span>
                    </div>

                    {/* Details */}
                    <div className="w-full mt-4 text-center">
                      <h3 className="text-[22px] font-extrabold text-white flex items-center justify-center gap-2">
                        {preview3DAvatar.name}
                        <span className="text-[15px] font-semibold text-[#8C9BFF]">
                          {preview3DAvatar.japaneseName}
                        </span>
                      </h3>
                      <p className="text-[13px] font-bold text-[#B4BEFF] mt-1">
                        {preview3DAvatar.outfit}
                      </p>
                      <p className="text-[12.5px] text-[#A7AFD0] mt-1.5 leading-relaxed">
                        {preview3DAvatar.description}
                      </p>
                      <p className="text-[11px] text-sky-300 font-semibold mt-2">
                        ✦ Full HD 3D • ओरिजिनल आउटफिट व क्रिस्टल क्लियर एज स्पष्टता
                      </p>
                    </div>

                    {/* Action ON/OFF Toggle Button */}
                    <div className="mt-4 w-full flex flex-col gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          handleToggleAvatar(preview3DAvatar.id);
                          setPreview3DAvatar(null);
                        }}
                        className={`w-full py-3 px-5 rounded-2xl text-[14px] font-black flex items-center justify-center gap-2 transition-all cursor-pointer active:scale-95 shadow-lg ${
                          selected3DAvatarId === preview3DAvatar.id && is3DAvatarActive
                            ? 'bg-rose-500 hover:bg-rose-600 text-white shadow-[0_0_20px_rgba(244,63,94,0.4)]'
                            : 'bg-emerald-500 hover:bg-emerald-600 text-slate-950 shadow-[0_0_20px_rgba(16,185,129,0.5)]'
                        }`}
                      >
                        <Power className="w-4 h-4 stroke-[2.5]" />
                        <span>
                          {selected3DAvatarId === preview3DAvatar.id && is3DAvatarActive
                            ? 'होम स्क्रीन से हटाएं (Turn OFF)'
                            : 'होम स्क्रीन पर चालू करें (Turn ON)'}
                        </span>
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* 3D Background Toggle */}
              <div className="p-4 rounded-[20px] bg-[#171C33] border border-[#262D4D] flex items-center justify-between shadow-md">
                <div className="pr-3">
                  <div className="text-[15px] font-bold text-[#F3F5FF]">
                    3D स्टेज व मेमोरी बैकग्राउंड
                  </div>
                  <p className="text-[12px] text-[#A7AFD0] mt-0.5">
                    होम स्क्रीन के पीछे लाइव 3D पाइपलाइन और ग्लोइंग इफ़ेक्ट सक्रिय करें
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => onToggle3DMemoryBackground?.(!use3DMemoryBackground)}
                  className={`w-[52px] h-[30px] rounded-full p-[3px] transition-colors duration-200 shrink-0 flex items-center cursor-pointer ${
                    use3DMemoryBackground ? 'bg-[#6D7CFF]' : 'bg-[#2A3156]'
                  }`}
                >
                  <div
                    className={`w-[24px] h-[24px] rounded-full bg-white shadow-md transition-transform duration-200 ${
                      use3DMemoryBackground ? 'translate-x-[22px]' : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>

              {/* Tap Avatar Reaction Test Button */}
              {onTapAvatar && (
                <button
                  type="button"
                  onClick={onTapAvatar}
                  className="w-full py-3 rounded-full bg-[#8C9BFF]/20 hover:bg-[#8C9BFF]/30 border border-[#8C9BFF]/40 text-[#8C9BFF] text-xs font-bold flex items-center justify-center gap-2 cursor-pointer transition-all active:scale-98"
                >
                  <Sparkles className="w-4 h-4" />
                  अवतार एक्सप्रेशन व इमोशन टेस्ट करें (Tap Avatar)
                </button>
              )}
            </div>
          )}
          {/* CATEGORY 4: VOICE SETTINGS */}
          {activeItemId === 'voice' && (
            <div className="animate-fadeIn pt-2 space-y-6">
              <div>
                <h1 className="text-[26px] font-extrabold text-[#F3F5FF]">
                  Voice Settings
                </h1>
                <p className="text-[13px] font-medium text-[#A7AFD0] mt-1">
                  11 न्यूरल आवाज़ें, बोलने की गति, वॉल्यूम और माइक्रोफ़ोन सिस्टम
                </p>
              </div>

              {/* All 11 Available Voices */}
              <div>
                <h3 className="text-[13px] font-bold text-[#A7AFD0] mb-3 px-1">
                  न्यूरल आवाज़ चुनें (11 Neural Voices)
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {ZOYA_AVAILABLE_VOICES.map((v) => {
                    const isSelected = currentVoiceId === v.id;
                    return (
                      <div
                        key={v.id}
                        className={`p-3.5 rounded-[18px] border flex flex-col justify-between gap-3 transition-all ${
                          isSelected
                            ? 'bg-[#1e2548] border-[#8C9BFF] shadow-[0_0_15px_rgba(140,155,255,0.3)]'
                            : 'bg-[#171C33] border-[#262D4D]'
                        }`}
                      >
                        <div className="flex items-start justify-between gap-2">
                          <div>
                            <div className="text-[15px] font-bold text-[#F3F5FF] flex items-center gap-2">
                              {v.displayName}
                              <span className="px-1.5 py-0.5 rounded text-[10px] font-extrabold bg-[#8C9BFF]/20 text-[#8C9BFF]">
                                {v.gender}
                              </span>
                              {v.badge && (
                                <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-pink-500/20 text-pink-300">
                                  {v.badge}
                                </span>
                              )}
                            </div>
                            <p className="text-[11px] text-[#A7AFD0] mt-1">
                              {v.providerLabel}
                            </p>
                            <p className="text-[12px] text-slate-300 mt-1 line-clamp-2">
                              {v.description}
                            </p>
                          </div>
                        </div>

                        <div className="flex items-center justify-between gap-2 pt-2 border-t border-[#232A48]">
                          {/* Play Sample Preview Button */}
                          <button
                            type="button"
                            onClick={() => {
                              setIsPlayingAudioPreview(v.id);
                              const previewUrl = `/data/voice_previews/${v.name}.wav`;
                              const a = new Audio(previewUrl);
                              a.play().catch(() => {});
                              a.onended = () => setIsPlayingAudioPreview(null);
                              a.onerror = () => setIsPlayingAudioPreview(null);
                            }}
                            className="px-3 py-1.5 rounded-lg bg-[#8C9BFF]/20 hover:bg-[#8C9BFF]/30 text-[#8C9BFF] text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                          >
                            <Play className="w-3.5 h-3.5" />
                            {isPlayingAudioPreview === v.id ? 'चल रहा है...' : 'नमूना सुनें'}
                          </button>

                          {/* Select Voice Button */}
                          <button
                            type="button"
                            onClick={() => {
                              setCurrentVoiceId(v.id);
                              try {
                                localStorage.setItem('zoya_selected_voice_id', v.id);
                              } catch {}
                            }}
                            className={`px-3 py-1.5 rounded-lg text-xs font-bold cursor-pointer transition-all ${
                              isSelected
                                ? 'bg-[#8C9BFF] text-[#0B1030]'
                                : 'bg-[#262D4D] hover:bg-[#323b63] text-white'
                            }`}
                          >
                            {isSelected ? 'सक्रिय ✓' : 'चुनें'}
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>


              {/* TTS Diagnostic Form & System Audit Launcher Card */}
              <div className="p-4 rounded-[20px] bg-gradient-to-r from-[#171C3D] to-[#121B3A] border border-[#8C9BFF]/40 space-y-2 shadow-lg">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-lg bg-[#8C9BFF]/20 border border-[#8C9BFF]/40 flex items-center justify-center text-[#8C9BFF] shrink-0">
                      <Volume2 className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-white">TTS Diagnostic Form & System Audit</h4>
                      <p className="text-[11px] text-slate-300">
                        सम्पूर्ण 3-इंजन इन्वेंटरी, प्राथमिक क्रम, लाइव लेटेंसी व फॉलबैक सुरक्षा जांच
                      </p>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      onClose();
                      window.dispatchEvent(new CustomEvent('open-tts-diagnostic'));
                    }}
                    className="px-3.5 py-1.5 rounded-lg bg-[#8C9BFF] hover:bg-[#7888FF] text-[#0B1030] text-xs font-black shrink-0 transition-all cursor-pointer shadow-md"
                  >
                    डायग्नोस्टिक फॉर्म खोलें ↗
                  </button>
                </div>
              </div>

              {/* Voice Speed Slider */}
              <div className="p-4 rounded-[20px] bg-[#171C33] border border-[#262D4D] space-y-3 shadow-md">
                <div className="flex items-center justify-between">
                  <span className="text-[15px] font-bold text-[#F3F5FF]">
                    बोलने की गति (Speech Speed): {voiceSpeed.toFixed(1)}x
                  </span>
                  <div className="flex gap-1.5">
                    {[0.8, 1.0, 1.2, 1.5].map((preset) => (
                      <button
                        key={preset}
                        type="button"
                        onClick={() => setVoiceSpeed(preset)}
                        className={`px-2 py-0.5 rounded text-[11px] font-bold cursor-pointer ${
                          voiceSpeed === preset
                            ? 'bg-[#8C9BFF] text-[#0B1030]'
                            : 'bg-[#262D4D] text-slate-300'
                        }`}
                      >
                        {preset}x
                      </button>
                    ))}
                  </div>
                </div>
                <input
                  type="range"
                  min="0.5"
                  max="2.0"
                  step="0.1"
                  value={voiceSpeed}
                  onChange={(e) => setVoiceSpeed(parseFloat(e.target.value))}
                  className="w-full accent-[#8C9BFF] cursor-pointer"
                />
              </div>

              {/* Voice Volume Slider */}
              <div className="p-4 rounded-[20px] bg-[#171C33] border border-[#262D4D] space-y-3 shadow-md">
                <div className="flex items-center justify-between">
                  <span className="text-[15px] font-bold text-[#F3F5FF]">
                    आवाज़ का स्तर (Volume): {Math.round(voiceVolume * 100)}%
                  </span>
                  <Volume2 className="w-4 h-4 text-[#8C9BFF]" />
                </div>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={voiceVolume}
                  onChange={(e) => onVoiceVolumeChange?.(parseFloat(e.target.value))}
                  className="w-full accent-[#8C9BFF] cursor-pointer"
                />
              </div>

              {/* Always-On Listening Switch + Live Mic/Wake-Word Status Indicator */}
              <div className="p-4 rounded-[20px] bg-[#171C33] border border-[#262D4D] space-y-3 shadow-md">
                <div className="flex items-center justify-between">
                  <div className="pr-3">
                    <div className="text-[15px] font-bold text-[#F3F5FF]">
                      हमेशा सुनना (Always-On Listening)
                    </div>
                    <p className="text-[12px] text-[#A7AFD0] mt-0.5">
                      माइक बटन दबाए बिना 'Hello Zoya' या 'नमस्ते जोया' कहकर सीधे बात करें
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => onToggleAutomaticListening(!automaticListening)}
                    className={`w-[52px] h-[30px] rounded-full p-[3px] transition-colors duration-200 shrink-0 flex items-center cursor-pointer ${
                      automaticListening ? 'bg-[#6D7CFF]' : 'bg-[#2A3156]'
                    }`}
                  >
                    <div
                      className={`w-[24px] h-[24px] rounded-full bg-white shadow-md transition-transform duration-200 ${
                        automaticListening ? 'translate-x-[22px]' : 'translate-x-0'
                      }`}
                    />
                  </button>
                </div>

                <div className="pt-2 border-t border-[#232A48] flex flex-wrap items-center justify-between gap-2">
                  <span className="text-[11.5px] font-semibold text-[#A7AFD0]">
                    वर्तमान वेक-वर्ड व माइक स्थिति (Live Status):
                  </span>
                  <ZoyaSmallListeningIndicator recLanguage={recLanguage} variant="inline" />
                </div>
              </div>

              {/* HEY ZOYA WAKE-WORD ENGINE (OPENWAKEWORD) */}
              <div className="p-4 rounded-[20px] bg-[#171C33] border border-[#262D4D] space-y-4 shadow-lg">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <div className="text-[16px] font-bold text-[#F3F5FF] flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-[#8C9BFF]" />
                      "Hey Zoya" Wake-Word Engine
                    </div>
                    <p className="text-[12px] text-[#A7AFD0] mt-0.5">
                      OpenWakeWord + SpeechRecognizer (ऑन-डिवाइस वेक डिटेक्शन)
                    </p>
                  </div>
                  <span className="px-2 py-0.5 rounded-full text-[11px] font-extrabold bg-[#8C9BFF]/20 text-[#8C9BFF] shrink-0">
                    OpenWakeWord
                  </span>
                </div>

                {/* Hidden File Input for .onnx Import */}
                <input
                  type="file"
                  ref={modelFileInputRef}
                  onChange={handleImportModelFile}
                  accept=".onnx"
                  className="hidden"
                />

                {/* Model File Status & Import Action (hey_zoya.onnx) */}
                {wakeStatus?.modelExists ? (
                  <div className="p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 space-y-2">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-start gap-2.5">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                        <div className="text-[12px]">
                          <div className="font-bold text-emerald-300">
                            Hey Zoya मॉडल लोड हो गया है ✓
                          </div>
                          <div className="text-emerald-200/80 font-mono text-[11px] mt-0.5 break-all">
                            {wakeStatus?.isImportedModel ? `इंटरनल स्टोरेज: ${wakeStatus?.modelPath}` : 'assets/keywords/hey_zoya.onnx'}
                          </div>
                        </div>
                      </div>
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-300 shrink-0">
                        {wakeStatus?.isImportedModel ? 'CUSTOM IMPORT' : 'BUILT-IN ASSET'}
                      </span>
                    </div>

                    <div className="flex items-center gap-2 pt-1 border-t border-emerald-500/20">
                      <button
                        type="button"
                        onClick={() => modelFileInputRef.current?.click()}
                        disabled={isImportingModel}
                        className="px-2.5 py-1 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-200 text-xs font-bold flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                      >
                        <Upload className="w-3.5 h-3.5" />
                        {isImportingModel ? 'आयात हो रहा है...' : 'नया .onnx आयात करें'}
                      </button>
                      {wakeStatus?.isImportedModel && (
                        <button
                          type="button"
                          onClick={handleRemoveImportedModel}
                          className="px-2.5 py-1 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 text-xs font-bold flex items-center gap-1 cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          कस्टम मॉडल हटाएँ
                        </button>
                      )}
                    </div>
                  </div>
                ) : (
                  <div className="p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/30 space-y-2.5">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2 text-amber-300 text-[13px] font-bold">
                        <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
                        Hey Zoya model file missing
                      </div>
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-300">
                        FALLBACK ACTIVE
                      </span>
                    </div>
                    <p className="text-[12px] text-amber-200/90 leading-relaxed">
                      "Hey Zoya" ऑन-डिवाइस सुनने के लिए आपकी <span className="font-mono font-bold text-white">hey_zoya.onnx</span> मॉडल फ़ाइल आवश्यक है। आप इसे सीधे यहाँ से इम्पोर्ट कर सकते हैं:
                    </p>
                    <div className="flex flex-wrap items-center gap-2 pt-0.5">
                      <button
                        type="button"
                        onClick={() => modelFileInputRef.current?.click()}
                        disabled={isImportingModel}
                        className="px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold flex items-center gap-1.5 cursor-pointer disabled:opacity-50 shadow-md"
                      >
                        <Upload className="w-3.5 h-3.5" />
                        {isImportingModel ? 'आयात हो रहा है...' : 'Import Hey Zoya model (.onnx)'}
                      </button>
                      <a
                        href="https://github.com/dscripka/openWakeWord"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-[11px] text-[#8C9BFF] hover:underline flex items-center gap-1 ml-auto"
                      >
                        OpenWakeWord Docs <ExternalLink className="w-3 h-3" />
                      </a>
                    </div>
                    <div className="text-[11px] text-amber-200/80 bg-black/30 p-2.5 rounded-lg space-y-1 font-mono">
                      <div>1. Train hey_zoya.onnx with OpenWakeWord Colab</div>
                      <div>2. Name: "Hey Zoya" | Platform: Android | Engine: v4.0.0</div>
                      <div>3. Download .onnx and click button above to load into app.</div>
                    </div>
                  </div>
                )}

                {/* Import Model Notice */}
                {importModelNotice && (
                  <div
                    className={`p-2.5 rounded-xl text-xs font-semibold flex items-center gap-2 ${
                      importModelNotice.success
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                        : 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                    }`}
                  >
                    {importModelNotice.success ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    ) : (
                      <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                    )}
                    <span>{importModelNotice.message}</span>
                  </div>
                )}

                {/* Debug Fallback Mode Switch */}
                <div className="p-3 rounded-xl bg-[#0E1224] border border-[#262D4D] flex items-center justify-between gap-3">
                  <div className="pr-2">
                    <div className="text-[13px] font-bold text-[#F3F5FF] flex items-center gap-1.5">
                      Debug Fallback Mode (COMPUTER keyword)
                      {wakeDebugFallback && (
                        <span className="px-1.5 py-0.2 rounded text-[10px] bg-amber-500/20 text-amber-300 font-bold">
                          DEBUG
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-[#A7AFD0] mt-0.5">
                      जब तक hey_zoya.onnx अपलोड न हो, तब तक केवल टेस्टिंग के लिए 'COMPUTER' शब्द का प्रयोग करें (Zero silent fallback)।
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleToggleWakeDebugFallback(!wakeDebugFallback)}
                    className={`w-[44px] h-[26px] rounded-full p-[2px] transition-colors duration-200 shrink-0 flex items-center cursor-pointer ${
                      wakeDebugFallback ? 'bg-amber-500' : 'bg-[#2A3156]'
                    }`}
                  >
                    <div
                      className={`w-[22px] h-[22px] rounded-full bg-white shadow-md transition-transform duration-200 ${
                        wakeDebugFallback ? 'translate-x-[18px]' : 'translate-x-0'
                      }`}
                    />
                  </button>
                </div>

                {/* Sensitivity Slider */}
                <div className="space-y-1.5 pt-1">
                  <div className="flex items-center justify-between text-[13px]">
                    <span className="font-bold text-[#F3F5FF]">
                      वेक संवेदनशीलता (Sensitivity): {(wakeSensitivity * 100).toFixed(0)}%
                    </span>
                    <span className="text-[11px] text-[#A7AFD0]">
                      {wakeSensitivity < 0.4 ? 'Low' : wakeSensitivity > 0.7 ? 'High' : 'Default (0.6)'}
                    </span>
                  </div>
                  <input
                    type="range"
                    min="0.1"
                    max="1.0"
                    step="0.05"
                    value={wakeSensitivity}
                    onChange={(e) => handleUpdateWakeSensitivity(parseFloat(e.target.value))}
                    className="w-full accent-[#8C9BFF] cursor-pointer"
                  />
                  <div className="flex justify-between text-[10px] text-slate-400">
                    <span>0.1 (Fewer false alarms)</span>
                    <span>0.6 (Recommended)</span>
                    <span>1.0 (Most sensitive)</span>
                  </div>
                </div>

                {/* Restart & Test Engine */}
                <div className="pt-2 border-t border-[#232A48] flex flex-wrap items-center justify-between gap-2">
                  <div className="text-[11px] text-slate-400">
                    आवाज़ सिर्फ फोन में पहचानी जाती है (100% on-device, zero cloud audio).
                  </div>
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={refreshWakeStatus}
                      className="px-2.5 py-1 rounded-lg bg-[#262D4D] hover:bg-[#323b63] text-white text-xs font-bold cursor-pointer"
                    >
                      Refresh Status
                    </button>
                    <button
                      type="button"
                      onClick={handleManualRestartWakeEngine}
                      disabled={isRestartingWakeEngine}
                      className="px-3 py-1 rounded-lg bg-[#8C9BFF]/20 hover:bg-[#8C9BFF]/30 text-[#8C9BFF] text-xs font-bold flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                    >
                      <RotateCw className={`w-3.5 h-3.5 ${isRestartingWakeEngine ? 'animate-spin' : ''}`} />
                      {isRestartingWakeEngine ? 'रीस्टार्ट हो रहा है...' : 'रीस्टार्ट इंजन'}
                    </button>
                  </div>
                </div>
              </div>

              {/* COMPACT PERMISSIONS BLOCK (Requirement 6) */}
              <div className="p-4 rounded-[20px] bg-[#171C33] border border-[#262D4D] space-y-3.5 shadow-lg">
                <div className="flex items-center justify-between">
                  <div className="text-[15px] font-bold text-[#F3F5FF] flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-emerald-400" />
                    डिवाइस अनुमतियाँ (System Permissions)
                  </div>
                  <button
                    type="button"
                    onClick={refreshWakeStatus}
                    className="text-[11px] text-[#8C9BFF] hover:underline cursor-pointer"
                  >
                    जाँचें (Refresh)
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  {/* 1. Microphone Permission */}
                  <div className="p-2.5 rounded-xl bg-[#0E1224] border border-[#262D4D] flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Mic className="w-3.5 h-3.5 text-[#8C9BFF]" />
                      <span className="text-slate-200 font-medium">Microphone</span>
                    </div>
                    {(wakeStatus?.hasMicPermission || micPermissionState === 'granted') ? (
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-300">
                        GRANTED ✓
                      </span>
                    ) : (
                      <button
                        type="button"
                        onClick={onRequestMicPermission}
                        className="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-500/20 text-rose-300 hover:bg-rose-500/30 cursor-pointer"
                      >
                        ALLOW
                      </button>
                    )}
                  </div>

                  {/* 2. Notifications Permission (Android 13+) */}
                  <div className="p-2.5 rounded-xl bg-[#0E1224] border border-[#262D4D] flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Bell className="w-3.5 h-3.5 text-[#8C9BFF]" />
                      <span className="text-slate-200 font-medium">Notifications</span>
                    </div>
                    {wakeStatus?.hasNotificationPermission ?? true ? (
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-300">
                        GRANTED ✓
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-300">
                        NEEDED
                      </span>
                    )}
                  </div>

                  {/* 3. Overlay (Draw Over Other Apps) */}
                  <div className="p-2.5 rounded-xl bg-[#0E1224] border border-[#262D4D] flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Layers className="w-3.5 h-3.5 text-[#8C9BFF]" />
                      <span className="text-slate-200 font-medium">Overlay Bubble</span>
                    </div>
                    {wakeStatus?.canDrawOverlay ? (
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-300">
                        GRANTED ✓
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-300">
                        OPTIONAL
                      </span>
                    )}
                  </div>

                  {/* 4. Battery Optimization Ignored */}
                  <div className="p-2.5 rounded-xl bg-[#0E1224] border border-[#262D4D] flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Zap className="w-3.5 h-3.5 text-[#8C9BFF]" />
                      <span className="text-slate-200 font-medium">Battery Unrestricted</span>
                    </div>
                    {wakeStatus?.isBatteryOptimizationIgnored ? (
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-300">
                        ACTIVE ✓
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-300">
                        OPT-IN
                      </span>
                    )}
                  </div>
                </div>

                {/* Wake Word Service Control */}
                <div className="pt-2 border-t border-[#232A48] flex items-center justify-between">
                  <div className="text-xs text-slate-300">
                    <span className="font-semibold text-white">Wake-Word Service:</span>{' '}
                    {wakeStatus?.modelExists ? (
                      <span className="text-emerald-400 font-bold">सक्रिय (Running)</span>
                    ) : (
                      <span className="text-amber-400 font-bold">प्रतीक्षारत (Awaiting .onnx)</span>
                    )}
                  </div>
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        const bridge = (window as any).AndroidBridge;
                        if (bridge && typeof bridge.startWakeWordService === 'function') {
                          bridge.startWakeWordService();
                          refreshWakeStatus();
                        }
                      }}
                      className="px-2.5 py-1 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 text-xs font-bold cursor-pointer"
                    >
                      Start Service
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        const bridge = (window as any).AndroidBridge;
                        if (bridge && typeof bridge.stopWakeWordService === 'function') {
                          bridge.stopWakeWordService();
                          refreshWakeStatus();
                        }
                      }}
                      className="px-2.5 py-1 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 text-xs font-bold cursor-pointer"
                    >
                      Stop Service
                    </button>
                  </div>
                </div>
              </div>

              {/* ANDROID 14+ MICROPHONE ARCHITECTURE EXPLANATION (Requirement 6) */}
              <div className="p-3.5 rounded-xl bg-[#0B1024] border border-[#2A3358] space-y-2 text-xs">
                <div className="flex items-center gap-2 text-cyan-300 font-bold text-[13px]">
                  <Info className="w-4 h-4 text-cyan-400 shrink-0" />
                  Android 14+ बैकग्राउंड वेक व माइक्रोफ़ोन गाइड
                </div>
                <div className="text-slate-300/90 leading-relaxed space-y-1.5 text-[11.5px]">
                  <p>
                    • <strong className="text-white">स्क्रीन खुली रहने पर (Foreground):</strong> OpenWakeWord वेक-वर्ड इंजन 100% ऑन-डिवाइस कार्य करता है। बिना किसी नेटवर्क लेटेंसी के "Hey Zoya" तुरंत एक्टिवेट होता है।
                  </p>
                  <p>
                    • <strong className="text-white">दूसरी ऐप्स में (Background):</strong> Android 14+ के कड़े सुरक्षा नियमों के तहत माइक्रोफ़ोन केवल सिस्टम 'Foreground Service' नोटिफिकेशन के साथ ही चालू रह सकता है। Zoya की बैकग्राउंड सर्विस इसी सुरक्षित नियम का पालन करती है।
                  </p>
                  <p>
                    • <strong className="text-white">बैटरी सुरक्षा:</strong> Android द्वारा बैकग्राउंड प्रोसेस को स्लीप में जाने से रोकने के लिए Battery Optimization को 'Don't optimize / Unrestricted' पर सेट रखें।
                  </p>
                </div>
              </div>

              {/* Microphone Hardware Diagnostics HUD */}
              <div className="p-4 rounded-[20px] bg-[#171C33] border border-[#262D4D] space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-[14px] font-bold text-[#F3F5FF] flex items-center gap-2">
                    <Mic className="w-4 h-4 text-[#8C9BFF]" />
                    माइक्रोफ़ोन स्थिति व डायग्नोस्टिक्स
                  </span>
                  <span
                    className={`px-2 py-0.5 rounded-full text-[11px] font-extrabold ${
                      micPermissionState === 'granted'
                        ? 'bg-emerald-500/20 text-emerald-300'
                        : 'bg-amber-500/20 text-amber-300'
                    }`}
                  >
                    {micPermissionState.toUpperCase()}
                  </span>
                </div>
                <p className="text-[12px] text-[#A7AFD0]">
                  स्टेटस लॉग: {micDebugLog}
                </p>
                <div className="flex flex-wrap gap-2 pt-1">
                  <button
                    type="button"
                    onClick={onRequestMicPermission}
                    className="px-3 py-1.5 rounded-lg bg-[#8C9BFF]/20 hover:bg-[#8C9BFF]/30 text-[#8C9BFF] text-xs font-bold cursor-pointer"
                  >
                    माइक अनुमति माँगें
                  </button>
                  <button
                    type="button"
                    onClick={onRunLiveListeningTest3Seconds}
                    className="px-3 py-1.5 rounded-lg bg-purple-500/20 hover:bg-purple-500/30 text-purple-200 text-xs font-bold cursor-pointer"
                  >
                    3-सेकंड टेस्ट रन करें
                  </button>
                  <button
                    type="button"
                    onClick={onRunPipelineTest}
                    className="px-3 py-1.5 rounded-lg bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-200 text-xs font-bold cursor-pointer"
                  >
                    पाइपलाइन लेटेंसी टेस्ट
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* CATEGORY 5: LANGUAGE SETTINGS */}
          {activeItemId === 'language' && (
            <div className="animate-fadeIn pt-2 space-y-5">
              <div>
                <h1 className="text-[26px] font-extrabold text-[#F3F5FF]">
                  Language Settings
                </h1>
                <p className="text-[13px] font-medium text-[#A7AFD0] mt-1">
                  भारत की सभी 22 अनुसूचित भाषाएं + English (23 Official Languages)
                </p>
              </div>

              {/* Search Bar */}
              <div className="relative w-full">
                <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-[#A7AFD0]" />
                <input
                  type="text"
                  value={langSearchQuery}
                  onChange={(e) => setLangSearchQuery(e.target.value)}
                  placeholder="खोजें / Search 23 languages..."
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-[#171C33] border border-[#262D4D] text-[#F3F5FF] placeholder-[#A7AFD0] text-sm outline-none focus:border-[#8C9BFF]"
                />
              </div>

              {/* All 23 Languages List */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {INDIAN_LANGUAGES.filter(
                  (l) =>
                    l.name.toLowerCase().includes(langSearchQuery.toLowerCase()) ||
                    l.nativeName.toLowerCase().includes(langSearchQuery.toLowerCase())
                ).map((lang) => {
                  const isSelected = recLanguage === lang.code;
                  return (
                    <button
                      key={lang.code}
                      type="button"
                      onClick={() => setRecLanguage(lang.code)}
                      className={`p-3.5 rounded-[18px] border text-left flex items-start gap-3.5 transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-[#1e2548] border-[#8C9BFF] shadow-[0_0_15px_rgba(140,155,255,0.3)]'
                          : 'bg-[#171C33] hover:bg-[#1d2342] border-[#262D4D]'
                      }`}
                    >
                      {/* Native Script Badge Icon */}
                      <div className="w-11 h-11 rounded-xl bg-[#8C9BFF]/20 text-[#8C9BFF] flex items-center justify-center font-bold text-lg shrink-0">
                        {lang.badgeSymbol}
                      </div>

                      <div className="min-w-0 flex-1">
                        <div className="flex items-center justify-between">
                          <span className="text-[15px] font-bold text-[#F3F5FF]">
                            {lang.nativeName}
                          </span>
                          {isSelected && (
                            <span className="px-2 py-0.5 rounded-full bg-[#8C9BFF] text-[#0B1030] text-[10px] font-extrabold">
                              SELECTED ✓
                            </span>
                          )}
                        </div>
                        <div className="text-[12px] text-[#A7AFD0] mt-0.5">
                          {lang.name} • {lang.script}
                        </div>
                        <div className="text-[11px] text-slate-300 mt-1 line-clamp-1">
                          वेक वर्ड: {lang.wakeWords.slice(0, 3).join(', ')}
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* CATEGORY 6: MODE OPTIONS */}
          {activeItemId === 'mode' && (
            <div className="animate-fadeIn pt-2 space-y-5">
              <div>
                <h1 className="text-[26px] font-extrabold text-[#F3F5FF]">
                  Mode Options
                </h1>
                <p className="text-[13px] font-medium text-[#A7AFD0] mt-1">
                  10 व्यक्तित्व शैलियाँ: संबोधन, लहजा और प्रतिक्रिया मोड
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                {PERSONALITY_MODES.map((m) => {
                  const isSelected = personaMode === m.id;
                  const Icon = m.icon;
                  return (
                    <button
                      key={m.id}
                      type="button"
                      onClick={() => setPersonaMode(m.id)}
                      className={`p-4 rounded-[20px] border text-left flex items-start gap-3.5 transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-[#1e2548] border-[#8C9BFF] shadow-[0_0_15px_rgba(140,155,255,0.3)]'
                          : 'bg-[#171C33] hover:bg-[#1d2342] border-[#262D4D]'
                      }`}
                    >
                      <div className="w-11 h-11 rounded-xl bg-[#8C9BFF]/20 text-[#8C9BFF] flex items-center justify-center shrink-0">
                        <Icon className="w-5 h-5" />
                      </div>

                      <div className="min-w-0 flex-1">
                        <div className="flex items-center justify-between">
                          <span className="text-[16px] font-bold text-[#F3F5FF]">
                            {m.name}
                          </span>
                          {isSelected && (
                            <span className="px-2 py-0.5 rounded-full bg-[#8C9BFF] text-[#0B1030] text-[10px] font-extrabold">
                              ACTIVE ✓
                            </span>
                          )}
                        </div>
                        <span className="inline-block mt-0.5 px-2 py-0.5 rounded bg-purple-500/20 text-purple-200 text-[11px] font-bold">
                          {m.addressLabel}
                        </span>
                        <p className="text-[12px] text-[#A7AFD0] mt-1.5">
                          {m.desc}
                        </p>
                      </div>
                    </button>
                  );
                })}
              </div>

              {personaMode === 'love' && (
                <LoveModeReflectionPanel />
              )}
            </div>
          )}

          {/* CATEGORY 7: YOUTUBE & SINGERS */}
          {activeItemId === 'youtube' && (
            <div className="animate-fadeIn pt-2">
              <ZoyaYouTubeSettings
                onBack={() => setActiveItemId(null)}
              />
            </div>
          )}

          {/* CATEGORY 8: PYTHON STUDIO */}
          {activeItemId === 'python_studio' && (
            <div className="animate-fadeIn pt-2 space-y-6">
              <div>
                <h1 className="text-[26px] font-extrabold text-[#F3F5FF]">
                  Python Studio Engine
                </h1>
                <p className="text-[13px] font-medium text-[#A7AFD0] mt-1">
                  Python 3.10 कोर एग्जीक्यूशन, डेटा साइंस, और बैकएंड सर्वर
                </p>
              </div>

              {/* Runtime Environment Card */}
              <div className="p-4 rounded-[20px] bg-[#171C33] border border-[#262D4D] space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Code2 className="w-5 h-5 text-emerald-400" />
                    <span className="text-[15px] font-bold text-[#F3F5FF]">
                      Python 3.10.12 Runtime
                    </span>
                  </div>
                  <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-bold">
                    ACTIVE ✓
                  </span>
                </div>
                <p className="text-[12px] text-[#A7AFD0]">
                  सर्वर सबप्रोसेस सैंडबॉक्स में 30-सेकंड टाइमआउट वॉचडॉग और प्रोसेस आइसोलेशन सक्रिय है।
                  वर्कस्पेस: <code className="text-purple-300">/data/python_projects/</code>
                </p>
              </div>

              {/* Verified Installed Packages */}
              <div className="p-4 rounded-[20px] bg-[#171C33] border border-[#262D4D] space-y-2.5">
                <h3 className="text-[13px] font-bold text-[#A7AFD0]">
                  सत्यापित लाइब्रेरीज़ (Verified Packages)
                </h3>
                <div className="flex flex-wrap gap-2">
                  {[
                    'numpy',
                    'pandas',
                    'matplotlib',
                    'pillow',
                    'openpyxl',
                    'reportlab',
                    'requests',
                    'beautifulsoup4',
                    'flask',
                    'pytest',
                  ].map((pkg) => (
                    <span
                      key={pkg}
                      className="px-2.5 py-1 rounded-lg bg-[#0E1224] border border-[#262D4D] text-xs font-mono text-cyan-300 flex items-center gap-1.5"
                    >
                      <Check className="w-3 h-3 text-emerald-400" />
                      {pkg}
                    </span>
                  ))}
                </div>
              </div>

              {/* Sample Projects Showcase */}
              <div className="p-4 rounded-[20px] bg-[#171C33] border border-[#262D4D] space-y-2">
                <h3 className="text-[13px] font-bold text-[#A7AFD0]">
                  उपलब्ध टेम्पलेट्स (Built-in Projects)
                </h3>
                <ul className="text-xs text-slate-300 space-y-1.5 list-disc list-inside">
                  <li>Data Science & Sales Analytics (Matplotlib Charts)</li>
                  <li>Enterprise PDF Invoice Generator (ReportLab)</li>
                  <li>Q4 Financial Ledger (OpenPyXL Excel Sheets)</li>
                  <li>Micro REST API Server (Flask)</li>
                  <li>Android APK Build Diagnostics Engine</li>
                </ul>
              </div>

              {/* Launch IDE Button */}
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onOpenPythonStudio?.();
                }}
                className="w-full h-[54px] rounded-full bg-[#8C9BFF] hover:bg-[#9caafb] text-[#0B1030] text-[16px] font-bold flex items-center justify-center gap-2 shadow-lg cursor-pointer transition-all active:scale-98"
              >
                <Code2 className="w-5 h-5" />
                Python Studio IDE खोलें (Open IDE)
              </button>
            </div>
          )}

          {/* CATEGORY 9: DEVICE LOCK */}
          {activeItemId === 'device_lock' && (
            <div className="animate-fadeIn pt-2">
              <ZoyaDeviceLockSettings
                onBack={() => setActiveItemId(null)}
              />
            </div>
          )}

          {/* CATEGORY 10: ACCESSIBILITY */}
          {activeItemId === 'accessibility' && (
            <div className="animate-fadeIn pt-2">
              <ZoyaAccessibilitySettings
                mode="accessibility"
              />
            </div>
          )}

          {/* CATEGORY 11: GEMINI API SETTINGS */}
          {activeItemId === 'api_key' && (
            <div className="animate-fadeIn pt-2 space-y-6">
              <div>
                <h1 className="text-[26px] font-extrabold text-[#F3F5FF]">
                  Gemini API Settings
                </h1>
                <p className="text-[13px] font-medium text-[#A7AFD0] mt-1">
                  Google Gemini AI कुंजी, मॉडल चयन व लेटेंसी टेस्ट
                </p>
              </div>

              {/* API Key Input */}
              <div className="p-4 rounded-[20px] bg-[#171C33] border border-[#262D4D] space-y-4">
                {/* Gemini API Key */}
                <div className="space-y-3">
                  <label className="block text-[14px] font-bold text-[#F3F5FF]">
                    कस्टम Gemini API Key (वैकल्पिक):
                  </label>
                  <div className="relative">
                    <input
                      type={showApiKey ? 'text' : 'password'}
                      value={customApiKey}
                      onChange={(e) => setCustomApiKey(e.target.value)}
                      placeholder="AIzaSy..."
                      className="w-full pl-3 pr-10 py-2.5 rounded-xl bg-[#0E1224] border border-[#262D4D] text-[#F3F5FF] placeholder-slate-500 font-mono text-xs outline-none focus:border-[#8C9BFF]"
                    />
                    <button
                      type="button"
                      onClick={() => setShowApiKey(!showApiKey)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-[#A7AFD0] hover:text-white"
                    >
                      {showApiKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                  <div className="flex flex-wrap gap-2 pt-1">
                    <button
                      type="button"
                      onClick={() => {
                        try {
                          storeEncryptedSecret('zoya_gemini_api_key', customApiKey.trim());
                          alert('API Key सुरक्षित रूप से सेव हो गई!');
                        } catch {}
                      }}
                      className="px-4 py-2 rounded-xl bg-[#8C9BFF] text-[#0B1030] text-xs font-bold cursor-pointer hover:bg-[#9caafb]"
                    >
                      सेव करें (Save Key)
                    </button>
                    <button
                      type="button"
                      onClick={handleTestGeminiConnection}
                      className="px-4 py-2 rounded-xl bg-[#8C9BFF]/20 hover:bg-[#8C9BFF]/30 text-[#8C9BFF] text-xs font-bold cursor-pointer"
                    >
                      {isTestingGemini ? 'परीक्षण जारी है...' : 'कनेक्शन टेस्ट करें (Ping)'}
                    </button>
                  </div>
                  {geminiTestResult && (
                    <p
                      className={`text-xs font-medium pt-1 ${
                        geminiTestResult.success ? 'text-emerald-400' : 'text-red-400'
                      }`}
                    >
                      {geminiTestResult.message}
                    </p>
                  )}
                </div>

                {/* ElevenLabs API Configuration (Directly Below Gemini API Key) */}
                <div className="border-t border-[#262D4D] pt-4 space-y-4">
                  {/* ElevenLabs API Key */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <label className="block text-[14px] font-bold text-[#F3F5FF]">
                        ElevenLabs API Key:
                      </label>
                      <span className="text-[10px] font-mono text-purple-300 bg-purple-500/10 px-2 py-0.5 rounded-full border border-purple-500/30">
                        {elevenLabsConfiguredOnServer ? 'Server Configured: Yes' : 'Server Configured: No'}
                      </span>
                    </div>
                    <div className="relative">
                      <input
                        type={showElevenLabsKey ? 'text' : 'password'}
                        value={elevenLabsApiKey}
                        onChange={(e) => setElevenLabsApiKey(e.target.value)}
                        placeholder={elevenLabsConfiguredOnServer ? 'सर्वर पर सेव है (बदलने के लिए नया key दर्ज करें)' : 'sk_... या ElevenLabs API Key दर्ज करें (Server Proxy)'}
                        className="w-full pl-3 pr-10 py-2.5 rounded-xl bg-[#0E1224] border border-[#262D4D] text-[#F3F5FF] placeholder-slate-500 font-mono text-xs outline-none focus:border-[#8C9BFF]"
                      />
                      <button
                        type="button"
                        onClick={() => setShowElevenLabsKey(!showElevenLabsKey)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-[#A7AFD0] hover:text-white cursor-pointer"
                        title={showElevenLabsKey ? 'छिपाएँ' : 'दिखाएँ'}
                      >
                        {showElevenLabsKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>

                  {/* ElevenLabs Voice ID */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <label className="block text-[14px] font-bold text-[#F3F5FF]">
                        ElevenLabs Voice ID:
                      </label>
                      <span className="text-[11px] font-mono text-slate-400">
                        डिफ़ॉल्ट: 21m00Tcm4TlvDq8ikWAM (Rachel)
                      </span>
                    </div>
                    <input
                      type="text"
                      value={elevenLabsVoiceId}
                      onChange={(e) => setElevenLabsVoiceId(e.target.value)}
                      placeholder="e.g. 21m00Tcm4TlvDq8ikWAM"
                      className="w-full px-3 py-2.5 rounded-xl bg-[#0E1224] border border-[#262D4D] text-[#F3F5FF] placeholder-slate-500 font-mono text-xs outline-none focus:border-[#8C9BFF]"
                    />
                    {/* Preset Voice ID quick chips */}
                    <div className="flex flex-wrap gap-1.5 pt-0.5">
                      {[
                        { name: 'Rachel', id: '21m00Tcm4TlvDq8ikWAM' },
                        { name: 'Domi', id: 'AZnzlk1XvdvUeBnXmlld' },
                        { name: 'Bella', id: 'EXAVITQu4vr4xnSDxMaL' },
                        { name: 'Antoni', id: 'ErXwobaYiN019PkySvjV' },
                        { name: 'Elli', id: 'MF3mGyEYCl7XYWbV9V6O' },
                        { name: 'Josh', id: 'TxGEqnHWrfWFTfGW9XjX' },
                      ].map((preset) => (
                        <button
                          key={preset.id}
                          type="button"
                          onClick={() => setElevenLabsVoiceId(preset.id)}
                          className={`px-2 py-0.5 rounded text-[11px] font-mono transition-colors cursor-pointer ${
                            elevenLabsVoiceId === preset.id
                              ? 'bg-[#8C9BFF]/30 text-[#8C9BFF] border border-[#8C9BFF]'
                              : 'bg-[#0E1224] text-slate-400 hover:text-slate-200 border border-[#262D4D]'
                          }`}
                        >
                          {preset.name}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Actions for ElevenLabs */}
                  <div className="flex flex-wrap items-center gap-2 pt-1">
                    <button
                      type="button"
                      onClick={handleSaveElevenLabs}
                      className="px-4 py-2 rounded-xl bg-[#8C9BFF] text-[#0B1030] text-xs font-bold cursor-pointer hover:bg-[#9caafb]"
                    >
                      {savedElevenToast ? 'सहेजा गया ✓' : 'सेव करें (Save ElevenLabs)'}
                    </button>
                    <button
                      type="button"
                      onClick={handleTestElevenConnection}
                      disabled={isTestingElevenConnection}
                      className="px-4 py-2 rounded-xl bg-[#8C9BFF]/20 hover:bg-[#8C9BFF]/30 text-[#8C9BFF] text-xs font-bold cursor-pointer disabled:opacity-50"
                    >
                      {isTestingElevenConnection ? 'जांच जारी...' : 'कनेक्शन टेस्ट करें (Test Connection)'}
                    </button>
                    <button
                      type="button"
                      onClick={handleTestElevenVoice}
                      disabled={isTestingElevenVoice}
                      className="px-4 py-2 rounded-xl bg-purple-500/20 hover:bg-purple-500/30 text-purple-300 text-xs font-bold cursor-pointer disabled:opacity-50 flex items-center gap-1.5"
                    >
                      <Play className={`w-3.5 h-3.5 ${isTestingElevenVoice ? 'animate-bounce' : ''}`} />
                      <span>{isTestingElevenVoice ? 'चल रहा है (रोकें)' : 'वॉयस टेस्ट (Test Voice)'}</span>
                    </button>
                  </div>

                  {elevenConnectionStatus.message && (
                    <p
                      className={`text-xs font-medium pt-1 ${
                        elevenConnectionStatus.status === 'success' ? 'text-emerald-400' : 'text-red-400'
                      }`}
                    >
                      {elevenConnectionStatus.message}
                    </p>
                  )}
                  {savedElevenToast && (
                    <p className="text-xs font-bold text-emerald-400 flex items-center gap-1 pt-1">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>ElevenLabs API Key व Voice ID सुरक्षित रूप से सेव हो गए!</span>
                    </p>
                  )}
                </div>
              </div>

              {/* AI Model Selector */}
              <div className="p-4 rounded-[20px] bg-[#171C33] border border-[#262D4D] space-y-3">
                <h3 className="text-[14px] font-bold text-[#F3F5FF]">
                  AI मॉडल चयन (Model Selection)
                </h3>
                <div className="grid grid-cols-1 gap-2">
                  {[
                    {
                      id: 'gemini-2.5-flash',
                      title: 'gemini-2.5-flash',
                      desc: 'अल्ट्रा-फास्ट रिस्पॉन्स, दैनिक बातचीत और त्वरित उत्तरों के लिए सर्वश्रेष्ठ (अनुशंसित)',
                    },
                    {
                      id: 'gemini-2.5-pro',
                      title: 'gemini-2.5-pro',
                      desc: 'गहन तर्क, कोडिंग और जटिल समस्याओं के समाधान के लिए',
                    },
                    {
                      id: 'gemini-2.0-flash',
                      title: 'gemini-2.0-flash',
                      desc: 'न्यूनतम लेटेंसी और रियल-टाइम स्ट्रीमिंग के लिए',
                    },
                  ].map((m) => {
                    const isSelected = selectedGeminiModel === m.id;
                    return (
                      <button
                        key={m.id}
                        type="button"
                        onClick={() => {
                          setSelectedGeminiModel(m.id);
                          try {
                            localStorage.setItem('zoya_ai_model_name', m.id);
                          } catch {}
                        }}
                        className={`p-3 rounded-xl border text-left flex items-center justify-between cursor-pointer ${
                          isSelected
                            ? 'bg-[#1e2548] border-[#8C9BFF]'
                            : 'bg-[#0E1224] border-[#262D4D]'
                        }`}
                      >
                        <div>
                          <div className="text-xs font-mono font-bold text-[#F3F5FF]">
                            {m.title}
                          </div>
                          <div className="text-[11px] text-[#A7AFD0] mt-0.5">
                            {m.desc}
                          </div>
                        </div>
                        {isSelected && <Check className="w-4 h-4 text-[#8C9BFF]" />}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Secret Vault Self-Test */}
              <div className="p-4 rounded-[20px] bg-[#171C33] border border-[#262D4D] space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-[14px] font-bold text-[#F3F5FF] flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-emerald-400" />
                    Secret Vault सुरक्षा जांच (AES-256-GCM)
                  </span>
                  <button
                    type="button"
                    onClick={handleRunVaultTest}
                    className="px-3 py-1 rounded-lg bg-[#8C9BFF]/20 hover:bg-[#8C9BFF]/30 text-[#8C9BFF] text-xs font-bold"
                  >
                    {isRunningVaultTest ? 'जाँच जारी...' : 'सेल्फ़-टेस्ट रन करें'}
                  </button>
                </div>
                {vaultSelfTestResult && (
                  <p className="text-xs text-emerald-400">
                    {vaultSelfTestResult.details}
                  </p>
                )}
              </div>
            </div>
          )}

          {/* CATEGORY 12: TOOL API KEYS */}
          {activeItemId === 'tool_api_keys' && (
            <div className="animate-fadeIn pt-2 space-y-6">
              <div>
                <h1 className="text-[26px] font-extrabold text-[#F3F5FF]">
                  Tool API Keys
                </h1>
                <p className="text-[13px] font-medium text-[#A7AFD0] mt-1">
                  Composio, GitHub PAT, Ad Library व ब्रांड गाइडलाइन्स
                </p>
              </div>

              {/* Master Tools List */}
              <div className="space-y-3.5">
                {TOOL_API_KEYS_REGISTRY.map((tool) => (
                  <div
                    key={tool.id}
                    className="p-4 rounded-[20px] bg-[#171C33] border border-[#262D4D] space-y-2.5 shadow-md"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-[14px] font-bold text-[#F3F5FF]">
                        {tool.label}
                      </span>
                      <span className="text-[11px] font-medium text-purple-300">
                        {tool.serviceName}
                      </span>
                    </div>
                    <p className="text-[12px] text-[#A7AFD0]">
                      {tool.description}
                    </p>
                    <input
                      type="password"
                      value={toolApiKeysMap[tool.id] || ''}
                      onChange={(e) =>
                        setToolApiKeysMap({
                          ...toolApiKeysMap,
                          [tool.id]: e.target.value,
                        })
                      }
                      placeholder={tool.placeholder}
                      className="w-full px-3 py-2 rounded-xl bg-[#0E1224] border border-[#262D4D] text-[#F3F5FF] placeholder-slate-600 font-mono text-xs outline-none focus:border-[#8C9BFF]"
                    />
                    <div className="flex items-center justify-between pt-1">
                      <span className="text-[11px] text-[#A7AFD0]">
                        {tool.docsHint}
                      </span>
                      <button
                        type="button"
                        onClick={() => {
                          setToolApiKey(tool.id, toolApiKeysMap[tool.id] || '');
                          setSavedToolKeyToastId(tool.id);
                          setTimeout(() => setSavedToolKeyToastId(null), 2000);
                        }}
                        className="px-3 py-1.5 rounded-lg bg-[#8C9BFF] hover:bg-[#9caafb] text-[#0B1030] text-xs font-bold cursor-pointer"
                      >
                        {savedToolKeyToastId === tool.id ? 'सेव हो गया ✓' : 'सेव करें'}
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              {/* Brand Guidelines Card */}
              <div className="p-4 rounded-[20px] bg-[#171C33] border border-[#262D4D] space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-[14px] font-bold text-[#F3F5FF]">
                      Brand Guidelines Configuration
                    </h3>
                    <p className="text-[12px] text-[#A7AFD0] mt-0.5">
                      ब्रांड के अनुकूल रंग, पैलेट और लोगो शैली सेट करें
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      const next = { ...brandConfig, enabled: !brandConfig.enabled };
                      setBrandConfig(next);
                      saveBrandGuidelinesConfig(next);
                    }}
                    className={`w-[52px] h-[30px] rounded-full p-[3px] transition-colors duration-200 shrink-0 flex items-center cursor-pointer ${
                      brandConfig.enabled ? 'bg-[#6D7CFF]' : 'bg-[#2A3156]'
                    }`}
                  >
                    <div
                      className={`w-[24px] h-[24px] rounded-full bg-white shadow-md transition-transform duration-200 ${
                        brandConfig.enabled ? 'translate-x-[22px]' : 'translate-x-0'
                      }`}
                    />
                  </button>
                </div>

                {brandConfig.enabled && (
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 pt-2 border-t border-[#232A48]">
                    {BRAND_PALETTE_PRESETS.map((preset) => {
                      const isSelected = brandConfig.presetId === preset.id;
                      return (
                        <button
                          key={preset.id}
                          type="button"
                          onClick={() => {
                            const next = { ...brandConfig, presetId: preset.id };
                            setBrandConfig(next);
                            saveBrandGuidelinesConfig(next);
                          }}
                          className={`p-2.5 rounded-xl border text-left text-xs cursor-pointer ${
                            isSelected
                              ? 'bg-[#1e2548] border-[#8C9BFF]'
                              : 'bg-[#0E1224] border-[#262D4D]'
                          }`}
                        >
                          <div className="font-bold text-[#F3F5FF] truncate">{preset.name}</div>
                          <div className="flex gap-1 mt-1.5">
                            <span
                              style={{ backgroundColor: preset.colors.accentPrimary }}
                              className="w-3.5 h-3.5 rounded-full"
                            />
                            <span
                              style={{ backgroundColor: preset.colors.accentSecondary }}
                              className="w-3.5 h-3.5 rounded-full"
                            />
                            <span
                              style={{ backgroundColor: preset.colors.accentTertiary }}
                              className="w-3.5 h-3.5 rounded-full"
                            />
                          </div>
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* CATEGORY 13: MEMORY SYSTEM */}
          {activeItemId === 'memory' && (
            <div className="animate-fadeIn pt-2 space-y-3">
              {/* Functional Home Screen 3D Memory System ON/OFF Toggle Card */}
              <div className="p-4 rounded-[20px] bg-[#171C33] border border-emerald-400/50 flex items-center justify-between gap-3 shadow-[0_0_18px_rgba(16,185,129,0.18)]">
                <div className="min-w-0 flex-1">
                  <div className="text-[15px] font-extrabold text-[#F3F5FF] flex items-center gap-2">
                    <span>Home Screen 3D Memory System</span>
                    <span
                      className={`px-2 py-0.5 rounded-full text-[10px] font-black ${
                        use3DMemoryBackground
                          ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-400/40'
                          : 'bg-[#252d54] text-[#A7AFD0]'
                      }`}
                    >
                      {use3DMemoryBackground ? 'ON' : 'OFF'}
                    </span>
                  </div>
                  <p className="text-[12px] text-[#A7AFD0] mt-0.5 leading-snug">
                    {use3DMemoryBackground
                      ? 'चालू (ON): होम स्क्रीन पर 3D Memory System दिख रहा है और अवतार Avatar सेक्शन में सुरक्षित है।'
                      : 'बंद (OFF): होम स्क्रीन पर आपका चुना हुआ अवतार दिख रहा है। ON करने पर 3D Memory System दिखेगा।'}
                  </p>
                </div>

                <button
                  type="button"
                  role="switch"
                  aria-checked={use3DMemoryBackground}
                  data-testid="subpage-memory-home-toggle"
                  onClick={() => onToggle3DMemoryBackground?.(!use3DMemoryBackground)}
                  className={`w-[58px] h-[32px] rounded-full p-[3px] transition-all duration-200 shrink-0 flex items-center cursor-pointer ${
                    use3DMemoryBackground
                      ? 'bg-emerald-500 shadow-[0_0_16px_rgba(16,185,129,0.6)]'
                      : 'bg-[#2A3156] border border-[#3b477c]'
                  }`}
                >
                  <div
                    className={`w-[26px] h-[26px] rounded-full bg-white shadow-md transition-transform duration-200 flex items-center justify-center ${
                      use3DMemoryBackground ? 'translate-x-[26px]' : 'translate-x-0'
                    }`}
                  >
                    <span
                      className={`text-[8.5px] font-black ${
                        use3DMemoryBackground ? 'text-emerald-700' : 'text-slate-600'
                      }`}
                    >
                      {use3DMemoryBackground ? 'ON' : 'OFF'}
                    </span>
                  </div>
                </button>
              </div>

              <div className="w-full h-[76vh] rounded-[22px] border border-emerald-400/60 bg-[#020906] overflow-hidden shadow-[0_0_24px_rgba(32,246,169,0.22)]">
                <ZoyaMemoryView
                  activePersonaMode={personaMode}
                  currentPersonaMode={personaMode}
                  onSelectPersonaMode={(m) => setPersonaMode(m)}
                  isInsideModal={true}
                  onBack={() => setActiveItemId(null)}
                  onClose={() => setActiveItemId(null)}
                />
              </div>
            </div>
          )}

          {/* CATEGORY: SMART BATTERY VOICE ALERT SYSTEM */}
          {/* CATEGORY 13: BATTERY & SYSTEM VOICE ALERTS */}
          {activeItemId === 'battery_alerts' && (
            <div className="animate-fadeIn pt-1 space-y-5 pb-6">
              {/* Subpage Header */}
              <div className="flex items-center justify-between pb-2 border-b border-[#262D4D]">
                <div>
                  <h2 className="text-[20px] font-extrabold text-[#F3F5FF] flex items-center gap-2">
                    <BatteryCharging className="w-5 h-5 text-emerald-400" />
                    <span>Battery & System Announcements</span>
                  </h2>
                  <p className="text-[12.5px] text-[#A7AFD0] mt-0.5">
                    चार्जर स्थिति, कम-बैटरी (20%, 10%, 3%), फ़्लाइट मोड और ऐप इंस्टॉलेशन पर आवाज़
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setActiveItemId(null)}
                  className="px-3 py-1.5 rounded-full bg-[#1e2544] hover:bg-[#28325a] text-[#B4BEFF] text-[12px] font-bold border border-[#3b477c] transition-all cursor-pointer"
                >
                  सेटिंग्स में वापस
                </button>
              </div>

              {/* 1. MASTER ON/OFF SWITCH CARD */}
              <div
                className={`w-full rounded-[20px] p-5 border transition-all duration-200 ${
                  isBatteryVoiceAlertsEnabled
                    ? 'bg-gradient-to-br from-[#10242b] via-[#121c38] to-[#161233] border-emerald-500/50 shadow-[0_0_24px_rgba(16,185,129,0.22)]'
                    : 'bg-[#14182e] border-[#2a3359]'
                }`}
              >
                <div className="flex items-center justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-2.5">
                      <span className="text-[17px] font-extrabold text-[#F3F5FF]">
                        Master Voice Alerts — ON/OFF
                      </span>
                      <span
                        className={`px-2.5 py-0.5 rounded-full text-[11px] font-black tracking-wider uppercase ${
                          isBatteryVoiceAlertsEnabled
                            ? 'bg-emerald-500/25 text-emerald-300 border border-emerald-400/50 shadow-[0_0_10px_rgba(16,185,129,0.4)]'
                            : 'bg-red-500/20 text-red-300 border border-red-500/30'
                        }`}
                      >
                        {isBatteryVoiceAlertsEnabled ? 'चालू (ON)' : 'बंद (OFF)'}
                      </span>
                    </div>
                    <p className="text-[13px] text-[#A7AFD0] mt-1.5 leading-relaxed">
                      {isBatteryVoiceAlertsEnabled
                        ? 'सक्रिय (ON): चार्जर, डिस्चार्ज चेतावनियाँ, फ़्लाइट मोड और ऐप इंस्टॉलेशन पर ज़ोया की आवाज़ सुनाई देगी।'
                        : 'निष्क्रिय (OFF): सभी सिस्टम व बैटरी वॉयस अलर्ट्स पूरी तरह म्यूट हैं। कोई आवाज़ नहीं आएगी।'}
                    </p>
                  </div>

                  {/* Big Toggle Switch */}
                  <button
                    type="button"
                    role="switch"
                    aria-checked={isBatteryVoiceAlertsEnabled}
                    data-testid="subpage-battery-voice-master-toggle"
                    onClick={() => handleToggleBatteryVoiceAlerts(!isBatteryVoiceAlertsEnabled)}
                    className={`w-[68px] h-[36px] rounded-full p-[3px] transition-all duration-200 shrink-0 flex items-center cursor-pointer ${
                      isBatteryVoiceAlertsEnabled
                        ? 'bg-emerald-500 shadow-[0_0_18px_rgba(16,185,129,0.7)]'
                        : 'bg-[#2A3156] border border-[#3b477c]'
                    }`}
                  >
                    <div
                      className={`w-[30px] h-[30px] rounded-full bg-white shadow-md transition-transform duration-200 flex items-center justify-center ${
                        isBatteryVoiceAlertsEnabled ? 'translate-x-[32px]' : 'translate-x-0'
                      }`}
                    >
                      <span
                        className={`text-[9.5px] font-black ${
                          isBatteryVoiceAlertsEnabled ? 'text-emerald-700' : 'text-slate-600'
                        }`}
                      >
                        {isBatteryVoiceAlertsEnabled ? 'ON' : 'OFF'}
                      </span>
                    </div>
                  </button>
                </div>

                <div className="mt-3.5 pt-3 border-t border-white/10 flex items-center justify-between text-[11.5px] text-[#8C9BFF]">
                  <span>स्थायी सुरक्षा: ऐप व फोन रीस्टार्ट के बाद भी यह सेटिंग सुरक्षित रहेगी।</span>
                  <span className="font-mono text-white/70">Master: {isBatteryVoiceAlertsEnabled ? 'true' : 'false'}</span>
                </div>
              </div>

              {/* 2. SPECIFIC ANNOUNCEMENT TOGGLES (Section 6) */}
              <div className="w-full bg-[#171C33] border border-[#262D4D] rounded-[20px] p-4.5 space-y-3 shadow-md">
                <div className="flex items-center gap-2 pb-2 border-b border-[#232A48]">
                  <Sliders className="w-4.5 h-4.5 text-cyan-400" />
                  <span className="text-[14px] font-bold text-[#F3F5FF]">
                    घोषणा प्राथमिकताएं (Announcement Preferences)
                  </span>
                </div>

                <div className="space-y-3">
                  {/* Toggle: Speak charging announcements */}
                  <div className="flex items-center justify-between gap-3 p-3 rounded-[14px] bg-[#101426] border border-[#222948]">
                    <div className="min-w-0 flex-1">
                      <div className="text-[13.5px] font-bold text-[#F3F5FF] flex items-center gap-2">
                        <Zap className="w-4 h-4 text-emerald-400" />
                        <span>Speak charging announcements</span>
                      </div>
                      <p className="text-[12px] text-[#A7AFD0] mt-0.5">
                        चार्जर लगाने और निकालने पर वर्तमान बैटरी प्रतिशत की आवाज़
                      </p>
                    </div>
                    <button
                      type="button"
                      role="switch"
                      aria-checked={isChargingAnnouncementsEnabled}
                      onClick={() => handleToggleChargingAnnouncements(!isChargingAnnouncementsEnabled)}
                      className={`w-[48px] h-[26px] rounded-full p-[2px] transition-all duration-200 shrink-0 flex items-center cursor-pointer ${
                        isChargingAnnouncementsEnabled ? 'bg-emerald-500 shadow-[0_0_12px_rgba(16,185,129,0.5)]' : 'bg-[#2A3156]'
                      }`}
                    >
                      <div
                        className={`w-[22px] h-[22px] rounded-full bg-white shadow transition-transform duration-200 ${
                          isChargingAnnouncementsEnabled ? 'translate-x-[22px]' : 'translate-x-0'
                        }`}
                      />
                    </button>
                  </div>

                  {/* Toggle: Speak low-battery warnings (20% / 10% / 3%) */}
                  <div className="flex items-center justify-between gap-3 p-3 rounded-[14px] bg-[#101426] border border-[#222948]">
                    <div className="min-w-0 flex-1">
                      <div className="text-[13.5px] font-bold text-[#F3F5FF] flex items-center gap-2">
                        <AlertTriangle className="w-4 h-4 text-amber-400" />
                        <span>Speak low-battery warnings (20% / 10% / 3%)</span>
                      </div>
                      <p className="text-[12px] text-[#A7AFD0] mt-0.5">
                        डिस्चार्ज होते समय 20%, 10% और 3% पर सटीक वॉयस चेतावनियाँ
                      </p>
                    </div>
                    <button
                      type="button"
                      role="switch"
                      aria-checked={isLowBatteryWarningsEnabled}
                      onClick={() => handleToggleLowBatteryWarnings(!isLowBatteryWarningsEnabled)}
                      className={`w-[48px] h-[26px] rounded-full p-[2px] transition-all duration-200 shrink-0 flex items-center cursor-pointer ${
                        isLowBatteryWarningsEnabled ? 'bg-emerald-500 shadow-[0_0_12px_rgba(16,185,129,0.5)]' : 'bg-[#2A3156]'
                      }`}
                    >
                      <div
                        className={`w-[22px] h-[22px] rounded-full bg-white shadow transition-transform duration-200 ${
                          isLowBatteryWarningsEnabled ? 'translate-x-[22px]' : 'translate-x-0'
                        }`}
                      />
                    </button>
                  </div>

                  {/* Toggle: Speak flight mode on/off */}
                  <div className="flex items-center justify-between gap-3 p-3 rounded-[14px] bg-[#101426] border border-[#222948]">
                    <div className="min-w-0 flex-1">
                      <div className="text-[13.5px] font-bold text-[#F3F5FF] flex items-center gap-2">
                        <Plane className="w-4 h-4 text-sky-400" />
                        <span>Speak flight mode on/off</span>
                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-sky-950/80 text-sky-300 border border-sky-500/30">
                          Offline TTS
                        </span>
                      </div>
                      <p className="text-[12px] text-[#A7AFD0] mt-0.5">
                        फ़्लाइट मोड ऑन/ऑफ़ होने पर ऑफलाइन आवाज़ (ब्राउज़र में approximate)
                      </p>
                    </div>
                    <button
                      type="button"
                      role="switch"
                      aria-checked={isFlightModeAnnouncementsEnabled}
                      onClick={() => handleToggleFlightModeAnnouncements(!isFlightModeAnnouncementsEnabled)}
                      className={`w-[48px] h-[26px] rounded-full p-[2px] transition-all duration-200 shrink-0 flex items-center cursor-pointer ${
                        isFlightModeAnnouncementsEnabled ? 'bg-emerald-500 shadow-[0_0_12px_rgba(16,185,129,0.5)]' : 'bg-[#2A3156]'
                      }`}
                    >
                      <div
                        className={`w-[22px] h-[22px] rounded-full bg-white shadow transition-transform duration-200 ${
                          isFlightModeAnnouncementsEnabled ? 'translate-x-[22px]' : 'translate-x-0'
                        }`}
                      />
                    </button>
                  </div>

                  {/* Toggle: Speak app install/uninstall */}
                  <div className="flex items-center justify-between gap-3 p-3 rounded-[14px] bg-[#101426] border border-[#222948]">
                    <div className="min-w-0 flex-1">
                      <div className="text-[13.5px] font-bold text-[#F3F5FF] flex items-center gap-2">
                        <Package className="w-4 h-4 text-purple-400" />
                        <span>Speak app install/uninstall</span>
                      </div>
                      <p className="text-[12px] text-[#A7AFD0] mt-0.5">
                        ऐप इंस्टॉल या अनइन्स्टॉल होने पर वास्तविक नाम के साथ घोषणा
                      </p>
                    </div>
                    <button
                      type="button"
                      role="switch"
                      aria-checked={isAppInstallAnnouncementsEnabled}
                      onClick={() => handleToggleAppInstallAnnouncements(!isAppInstallAnnouncementsEnabled)}
                      className={`w-[48px] h-[26px] rounded-full p-[2px] transition-all duration-200 shrink-0 flex items-center cursor-pointer ${
                        isAppInstallAnnouncementsEnabled ? 'bg-emerald-500 shadow-[0_0_12px_rgba(16,185,129,0.5)]' : 'bg-[#2A3156]'
                      }`}
                    >
                      <div
                        className={`w-[22px] h-[22px] rounded-full bg-white shadow transition-transform duration-200 ${
                          isAppInstallAnnouncementsEnabled ? 'translate-x-[22px]' : 'translate-x-0'
                        }`}
                      />
                    </button>
                  </div>
                </div>
              </div>

              {/* 3. LIVE PHONE BATTERY & HARDWARE STATUS */}
              <div className="w-full bg-[#171C33] border border-[#262D4D] rounded-[20px] p-4.5 shadow-md">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <Battery className="w-4.5 h-4.5 text-cyan-400" />
                    <span className="text-[14px] font-bold text-[#F3F5FF]">लाइव फोन बैटरी स्थिति (Live Device Status)</span>
                  </div>
                  <div className="flex items-center gap-2">
                    {batteryStatus.isAirplaneMode && (
                      <span className="text-[11px] font-bold px-2 py-0.5 rounded bg-amber-950 text-amber-300 border border-amber-500/40 flex items-center gap-1">
                        <Plane className="w-3 h-3" /> Flight Mode
                      </span>
                    )}
                    <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-500/40">
                      {batteryStatus.source}
                    </span>
                  </div>
                </div>

                {/* Battery Meter */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-3">
                  <div className="bg-[#101426] border border-[#222948] rounded-[14px] p-3 flex items-center gap-3">
                    <div
                      className={`w-12 h-12 rounded-xl flex items-center justify-center shrink-0 ${
                        batteryStatus.isCharging
                          ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-400/40 shadow-[0_0_12px_rgba(16,185,129,0.3)]'
                          : batteryStatus.levelPercent <= 10
                          ? 'bg-red-500/20 text-red-400 border border-red-400/40 shadow-[0_0_12px_rgba(239,68,68,0.3)]'
                          : batteryStatus.levelPercent <= 20
                          ? 'bg-amber-500/20 text-amber-400 border border-amber-400/40'
                          : 'bg-cyan-500/20 text-cyan-400 border border-cyan-400/40'
                      }`}
                    >
                      {batteryStatus.isCharging ? (
                        <Zap className="w-6 h-6 animate-pulse" />
                      ) : (
                        <Battery className="w-6 h-6" />
                      )}
                    </div>
                    <div>
                      <div className="text-[22px] font-extrabold text-[#F3F5FF] leading-none">
                        {batteryStatus.levelPercent}%
                      </div>
                      <div className="text-[12px] font-semibold text-[#A7AFD0] mt-1">
                        {batteryStatus.isCharging ? 'चार्जर कनेक्टेड ⚡' : 'बैटरी पावर (डिस्चार्जिंग) 🔋'}
                      </div>
                    </div>
                  </div>

                  <div className="bg-[#101426] border border-[#222948] rounded-[14px] p-3 flex flex-col justify-center">
                    <div className="text-[11px] font-bold text-[#A7AFD0] uppercase tracking-wider">अंतिम रिकॉर्डेड इवेंट</div>
                    <div className="text-[13px] font-bold text-[#F3F5FF] truncate mt-0.5">
                      {batteryStatus.lastEvent}
                    </div>
                    <div className="text-[11px] text-cyan-300/80 truncate mt-1">
                      {batteryStatus.lastAnnouncement ? `"${batteryStatus.lastAnnouncement}"` : 'कोई सक्रिय अलर्ट नहीं'}
                    </div>
                  </div>
                </div>

                {/* Progress Bar */}
                <div className="w-full bg-[#101426] rounded-full h-2.5 overflow-hidden border border-[#222948]">
                  <div
                    className={`h-full transition-all duration-500 ${
                      batteryStatus.isCharging
                        ? 'bg-gradient-to-r from-emerald-500 to-cyan-400'
                        : batteryStatus.levelPercent <= 10
                        ? 'bg-gradient-to-r from-red-600 to-red-400'
                        : batteryStatus.levelPercent <= 20
                        ? 'bg-gradient-to-r from-amber-600 to-amber-400'
                        : 'bg-gradient-to-r from-cyan-500 to-blue-400'
                    }`}
                    style={{ width: `${Math.max(4, Math.min(100, batteryStatus.levelPercent))}%` }}
                  />
                </div>
              </div>

              {/* 4. EXACT RULES & DIALOGUES VIEW (FROM CONFIG) */}
              <div className="w-full bg-[#171C33] border border-[#262D4D] rounded-[20px] p-4.5 space-y-3 shadow-md">
                <div className="flex items-center gap-2 pb-2 border-b border-[#232A48]">
                  <ShieldCheck className="w-4.5 h-4.5 text-emerald-400" />
                  <span className="text-[14px] font-bold text-[#F3F5FF]">
                    सटीक वॉयस संवाद एवं नियम (Configured Dialogues)
                  </span>
                </div>

                <div className="space-y-2.5 text-[13px]">
                  {/* 1. Charger Connected Normal */}
                  <div className="p-3 rounded-[14px] bg-[#101426] border border-emerald-500/25">
                    <div className="flex items-center justify-between font-bold text-emerald-300">
                      <span>🔌 1. चार्जर कनेक्ट होने पर (&lt;95%)</span>
                      <span className="text-[11px] px-2 py-0.5 rounded bg-emerald-950 text-emerald-300">तत्काल</span>
                    </div>
                    <div className="mt-1.5 p-2 rounded-lg bg-[#080c18] font-mono text-[12px] text-emerald-200">
                      &quot;{batteryAlertSystem.config.dialogues.chargerConnectedNormal}&quot;
                    </div>
                  </div>

                  {/* 1b. Charger Connected Full */}
                  <div className="p-3 rounded-[14px] bg-[#101426] border border-emerald-500/25">
                    <div className="flex items-center justify-between font-bold text-emerald-300">
                      <span>⚡ 1b. चार्जर कनेक्ट होने पर (≥95% Full)</span>
                      <span className="text-[11px] px-2 py-0.5 rounded bg-emerald-950 text-emerald-300">लगभग फुल</span>
                    </div>
                    <div className="mt-1.5 p-2 rounded-lg bg-[#080c18] font-mono text-[12px] text-emerald-200">
                      &quot;{batteryAlertSystem.config.dialogues.chargerConnectedFull}&quot;
                    </div>
                  </div>

                  {/* 2. Charger Disconnected */}
                  <div className="p-3 rounded-[14px] bg-[#101426] border border-cyan-500/25">
                    <div className="flex items-center justify-between font-bold text-cyan-300">
                      <span>🔌 2. चार्जर हटाने पर (Unplugged)</span>
                      <span className="text-[11px] px-2 py-0.5 rounded bg-cyan-950 text-cyan-300">तत्काल</span>
                    </div>
                    <div className="mt-1.5 p-2 rounded-lg bg-[#080c18] font-mono text-[12px] text-cyan-200">
                      &quot;{batteryAlertSystem.config.dialogues.chargerDisconnected}&quot;
                    </div>
                  </div>

                  {/* 3. Low Battery 20% */}
                  <div className="p-3 rounded-[14px] bg-[#101426] border border-amber-500/30">
                    <div className="flex items-center justify-between font-bold text-amber-300">
                      <span>⚠️ 3. 20% सीमा (डिस्चार्जिंग चक्र में केवल 1 बार)</span>
                      <span className="text-[11px] px-2 py-0.5 rounded bg-amber-950 text-amber-300">
                        {batteryStatus.announcedThresholds.twenty ? 'इस चक्र में बोला गया' : 'सक्रिय'}
                      </span>
                    </div>
                    <div className="mt-1.5 p-2 rounded-lg bg-[#080c18] font-mono text-[12px] text-amber-200">
                      &quot;{batteryAlertSystem.config.dialogues.lowBattery20}&quot;
                    </div>
                  </div>

                  {/* 3b. Low Battery 10% */}
                  <div className="p-3 rounded-[14px] bg-[#101426] border border-orange-500/30">
                    <div className="flex items-center justify-between font-bold text-orange-300">
                      <span>🚨 4. 10% सीमा (डिस्चार्जिंग चक्र में केवल 1 बार)</span>
                      <span className="text-[11px] px-2 py-0.5 rounded bg-orange-950 text-orange-300">
                        {batteryStatus.announcedThresholds.ten ? 'इस चक्र में बोला गया' : 'सक्रिय'}
                      </span>
                    </div>
                    <div className="mt-1.5 p-2 rounded-lg bg-[#080c18] font-mono text-[12px] text-orange-200">
                      &quot;{batteryAlertSystem.config.dialogues.lowBattery10}&quot;
                    </div>
                  </div>

                  {/* 3c. Critical Low 3% */}
                  <div className="p-3 rounded-[14px] bg-[#101426] border border-red-500/35">
                    <div className="flex items-center justify-between font-bold text-red-300">
                      <span>🔥 5. 3% क्रिटिकल सीमा (सर्वोच्च प्राथमिकता)</span>
                      <span className="text-[11px] px-2 py-0.5 rounded bg-red-950 text-red-300">
                        {batteryStatus.announcedThresholds.three ? 'इस चक्र में बोला गया' : 'सक्रिय'}
                      </span>
                    </div>
                    <div className="mt-1.5 p-2 rounded-lg bg-[#080c18] font-mono text-[12px] text-red-200">
                      &quot;{batteryAlertSystem.config.dialogues.lowBattery3}&quot;
                    </div>
                  </div>

                  {/* 4. Flight Mode */}
                  <div className="p-3 rounded-[14px] bg-[#101426] border border-sky-500/30">
                    <div className="flex items-center justify-between font-bold text-sky-300">
                      <span>✈️ 6. फ़्लाइट मोड (Flight Mode ON / OFF)</span>
                      <span className="text-[11px] px-2 py-0.5 rounded bg-sky-950 text-sky-300">Offline TTS</span>
                    </div>
                    <div className="mt-1.5 space-y-1 font-mono text-[12px]">
                      <div className="p-1.5 rounded bg-[#080c18] text-sky-200">
                        ON: &quot;{batteryAlertSystem.config.dialogues.flightModeOn}&quot;
                      </div>
                      <div className="p-1.5 rounded bg-[#080c18] text-sky-200">
                        OFF: &quot;{batteryAlertSystem.config.dialogues.flightModeOff}&quot;
                      </div>
                    </div>
                  </div>

                  {/* 5. App Install / Uninstall */}
                  <div className="p-3 rounded-[14px] bg-[#101426] border border-purple-500/30">
                    <div className="flex items-center justify-between font-bold text-purple-300">
                      <span>📦 7. ऐप इंस्टॉलेशन एवं अनइन्स्टॉलेशन</span>
                      <span className="text-[11px] px-2 py-0.5 rounded bg-purple-950 text-purple-300">वास्तविक नाम</span>
                    </div>
                    <div className="mt-1.5 space-y-1 font-mono text-[12px]">
                      <div className="p-1.5 rounded bg-[#080c18] text-purple-200">
                        इंस्टॉल: &quot;{batteryAlertSystem.config.dialogues.appInstalled}&quot;
                      </div>
                      <div className="p-1.5 rounded bg-[#080c18] text-purple-200">
                        अनइन्स्टॉल: &quot;{batteryAlertSystem.config.dialogues.appUninstalled}&quot;
                      </div>
                    </div>
                  </div>
                </div>

                {/* Plain-Language Android Background Rules */}
                <div className="p-3.5 rounded-[14px] bg-[#12162a] border border-[#262D4D] text-[12px] space-y-1.5 text-[#8C9BFF]">
                  <div className="font-bold text-[#F3F5FF] flex items-center gap-2">
                    <Info className="w-4 h-4 text-cyan-400" />
                    <span>Android बैकग्राउंड व्यवहार व सुरक्षा नियम:</span>
                  </div>
                  <div>✔ ऐप खुला होने या ज़ोया सर्विस चालू होने पर घोषणाएं तत्काल व बिना रुकावट होती हैं।</div>
                  <div>✔ गहरे बैकग्राउंड में Android OS के आक्रामक बैटरी सेवर ब्रॉडकास्ट को स्क्रीन ऑन होने तक धीमा कर सकते हैं।</div>
                  <div>✔ फ़्लाइट मोड घोषणाएं बिना इंटरनेट के डिवाइस के ऑफलाइन TTS से तुरंत बोली जाती हैं।</div>
                  <div>✔ बोलते समय ज़ोया का माइक स्वतः पॉज़ हो जाता है, ताकि उसकी खुद की आवाज़ रिकॉर्ड न हो।</div>
                  <div>✔ यदि कॉल सक्रिय हो या पहले से कोई उत्तर बोला जा रहा हो, तो घोषणा कतार में रखी जाती है (3% को छोड़कर)। 15 सेकंड से पुरानी घोषणा कतार से हटा दी जाती है।</div>
                </div>
              </div>

              {/* 5. INTERACTIVE LIVE TEST BUTTONS (Section 6) */}
              <div className="w-full bg-[#171C33] border border-[#262D4D] rounded-[20px] p-4.5 space-y-3.5 shadow-md">
                <div className="flex items-center justify-between pb-2 border-b border-[#232A48]">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-4.5 h-4.5 text-purple-400" />
                    <span className="text-[14px] font-bold text-[#F3F5FF]">
                      लाइव वॉयस टेस्टिंग बटन (Test Every Dialogue Type)
                    </span>
                  </div>
                  <span className="text-[11px] text-[#A7AFD0]">तुरंत सुनें</span>
                </div>

                <p className="text-[12.5px] text-[#A7AFD0]">
                  नीचे दिए गए बटनों को दबाकर वास्तविक हार्डवेयर इवेंट किए बिना ज़ोया की असली आवाज़ का परीक्षण करें:
                </p>

                {/* 10 Test Buttons */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <button
                    type="button"
                    onClick={() => batteryAlertSystem.simulateEvent('connected')}
                    className="p-3 rounded-[14px] bg-[#101c24] hover:bg-[#142834] border border-emerald-500/40 text-emerald-300 text-[12.5px] font-bold flex items-center justify-between active:scale-[0.98] transition-all cursor-pointer shadow-sm"
                  >
                    <span>🔌 टेस्ट: चार्जर इन (&lt;95%)</span>
                    <Play className="w-4 h-4 text-emerald-400" />
                  </button>

                  <button
                    type="button"
                    onClick={() => batteryAlertSystem.simulateEvent('connected_full')}
                    className="p-3 rounded-[14px] bg-[#102422] hover:bg-[#143430] border border-teal-500/40 text-teal-300 text-[12.5px] font-bold flex items-center justify-between active:scale-[0.98] transition-all cursor-pointer shadow-sm"
                  >
                    <span>⚡ टेस्ट: चार्जर इन (≥95% Full)</span>
                    <Play className="w-4 h-4 text-teal-400" />
                  </button>

                  <button
                    type="button"
                    onClick={() => batteryAlertSystem.simulateEvent('disconnected')}
                    className="p-3 rounded-[14px] bg-[#101a2c] hover:bg-[#14243e] border border-cyan-500/40 text-cyan-300 text-[12.5px] font-bold flex items-center justify-between active:scale-[0.98] transition-all cursor-pointer shadow-sm"
                  >
                    <span>⚡ टेस्ट: चार्जर आउट (Power off)</span>
                    <Play className="w-4 h-4 text-cyan-400" />
                  </button>

                  <button
                    type="button"
                    onClick={() => batteryAlertSystem.simulateEvent('20')}
                    className="p-3 rounded-[14px] bg-[#221c10] hover:bg-[#2e2614] border border-amber-500/40 text-amber-300 text-[12.5px] font-bold flex items-center justify-between active:scale-[0.98] transition-all cursor-pointer shadow-sm"
                  >
                    <span>⚠️ टेस्ट: 20% चेतावनी</span>
                    <Play className="w-4 h-4 text-amber-400" />
                  </button>

                  <button
                    type="button"
                    onClick={() => batteryAlertSystem.simulateEvent('10')}
                    className="p-3 rounded-[14px] bg-[#261510] hover:bg-[#341d14] border border-orange-500/40 text-orange-300 text-[12.5px] font-bold flex items-center justify-between active:scale-[0.98] transition-all cursor-pointer shadow-sm"
                  >
                    <span>🚨 टेस्ट: 10% चेतावनी</span>
                    <Play className="w-4 h-4 text-orange-400" />
                  </button>

                  <button
                    type="button"
                    onClick={() => batteryAlertSystem.simulateEvent('3')}
                    className="p-3 rounded-[14px] bg-[#260e14] hover:bg-[#36131c] border border-red-500/40 text-red-300 text-[12.5px] font-bold flex items-center justify-between active:scale-[0.98] transition-all cursor-pointer shadow-sm"
                  >
                    <span>🔥 टेस्ट: 3% आपातकालीन चेतावनी</span>
                    <Play className="w-4 h-4 text-red-400" />
                  </button>

                  <button
                    type="button"
                    onClick={() => batteryAlertSystem.simulateEvent('flight_on')}
                    className="p-3 rounded-[14px] bg-[#0e1a2c] hover:bg-[#13233a] border border-sky-500/40 text-sky-300 text-[12.5px] font-bold flex items-center justify-between active:scale-[0.98] transition-all cursor-pointer shadow-sm"
                  >
                    <span>✈️ टेस्ट: Flight Mode ON</span>
                    <Play className="w-4 h-4 text-sky-400" />
                  </button>

                  <button
                    type="button"
                    onClick={() => batteryAlertSystem.simulateEvent('flight_off')}
                    className="p-3 rounded-[14px] bg-[#0e2424] hover:bg-[#123030] border border-cyan-500/40 text-cyan-300 text-[12.5px] font-bold flex items-center justify-between active:scale-[0.98] transition-all cursor-pointer shadow-sm"
                  >
                    <span>📶 टेस्ट: Flight Mode OFF</span>
                    <Play className="w-4 h-4 text-cyan-400" />
                  </button>

                  <button
                    type="button"
                    onClick={() => batteryAlertSystem.simulateEvent('app_install')}
                    className="p-3 rounded-[14px] bg-[#1a102c] hover:bg-[#251540] border border-purple-500/40 text-purple-300 text-[12.5px] font-bold flex items-center justify-between active:scale-[0.98] transition-all cursor-pointer shadow-sm"
                  >
                    <span>📦 टेस्ट: App Installed</span>
                    <Play className="w-4 h-4 text-purple-400" />
                  </button>

                  <button
                    type="button"
                    onClick={() => batteryAlertSystem.simulateEvent('app_uninstall')}
                    className="p-3 rounded-[14px] bg-[#261026] hover:bg-[#361436] border border-fuchsia-500/40 text-fuchsia-300 text-[12.5px] font-bold flex items-center justify-between active:scale-[0.98] transition-all cursor-pointer shadow-sm"
                  >
                    <span>🗑️ टेस्ट: App Uninstalled</span>
                    <Play className="w-4 h-4 text-fuchsia-400" />
                  </button>
                </div>

                {/* Custom Level Simulator Slider */}
                <div className="pt-2 border-t border-[#232A48] space-y-2">
                  <div className="flex items-center justify-between text-[12.5px]">
                    <span className="font-bold text-[#F3F5FF]">कस्टम बैटरी स्तर सिमुलेटर:</span>
                    <span className="font-mono text-cyan-300 font-bold">{simulatedLevel}%</span>
                  </div>
                  <input
                    type="range"
                    min="1"
                    max="100"
                    value={simulatedLevel}
                    onChange={(e) => setSimulatedLevel(parseInt(e.target.value, 10))}
                    className="w-full accent-cyan-400 cursor-pointer"
                  />
                  <div className="flex flex-wrap gap-2">
                    <button
                      type="button"
                      onClick={() => batteryAlertSystem.simulateEvent('custom', simulatedLevel)}
                      className="flex-1 py-2 px-3 rounded-[12px] bg-[#1e2544] hover:bg-[#28325a] text-[#B4BEFF] text-[12px] font-bold border border-[#3b477c] transition-all cursor-pointer text-center"
                    >
                      लागू करें ({simulatedLevel}%)
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setSimulatedLevel(20);
                        batteryAlertSystem.simulateEvent('20');
                      }}
                      className="py-2 px-3 rounded-[12px] bg-amber-950/70 hover:bg-amber-900/70 text-amber-200 text-[12px] font-bold border border-amber-500/40 transition-all cursor-pointer"
                    >
                      20% सेट
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setSimulatedLevel(10);
                        batteryAlertSystem.simulateEvent('10');
                      }}
                      className="py-2 px-3 rounded-[12px] bg-orange-950/70 hover:bg-orange-900/70 text-orange-200 text-[12px] font-bold border border-orange-500/40 transition-all cursor-pointer"
                    >
                      10% सेट
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setSimulatedLevel(3);
                        batteryAlertSystem.simulateEvent('3');
                      }}
                      className="py-2 px-3 rounded-[12px] bg-red-950/70 hover:bg-red-900/70 text-red-200 text-[12px] font-bold border border-red-500/40 transition-all cursor-pointer"
                    >
                      3% सेट
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* CATEGORY 14: INSTAGRAM GROWTH SYSTEM */}
          {activeItemId === 'instagram_growth' && (
            <div className="animate-fadeIn pt-2">
              <ZoyaInstagramGrowthSubpage />
            </div>
          )}

          {/* Persistent Return Button at bottom of subpage */}
          <button
            type="button"
            onClick={() => setActiveItemId(null)}
            className="w-full h-[52px] rounded-full bg-[#8C9BFF] hover:bg-[#9caafb] active:scale-[0.98] text-[#0B1030] text-[16px] font-bold flex items-center justify-center shadow-lg transition-all cursor-pointer mt-8"
          >
            सेव करके वापस जाएँ (Return to Settings)
          </button>
        </div>
      )}
    </div>
  );
};
