import React, { useEffect } from 'react';

export interface ZoyaMemoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  personaMode?: string;
  onSelectPersonaMode?: (mode: string) => void;
  onOpenChat?: () => void;
  onOpenHistory?: () => void;
}

export const ZoyaMemoryModal: React.FC<ZoyaMemoryModalProps> = ({
  isOpen,
  onClose,
  onSelectPersonaMode,
  onOpenChat,
  onOpenHistory,
}) => {
  useEffect(() => {
    if (!isOpen) return;

    const handleMessage = (e: MessageEvent) => {
      if (!e.data || typeof e.data !== 'object') return;
      if (e.data.type === 'ZOYA_CLOSE_MEMORY') {
        onClose();
      } else if (e.data.type === 'ZOYA_SELECT_MODE' && typeof e.data.mode === 'string') {
        onSelectPersonaMode?.(e.data.mode);
      } else if (e.data.type === 'ZOYA_NAV') {
        if (e.data.tab === 'chat') {
          onClose();
          onOpenChat?.();
        } else if (e.data.tab === 'history') {
          onClose();
          onOpenHistory?.();
        }
      }
    };

    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, [isOpen, onClose, onSelectPersonaMode, onOpenChat, onOpenHistory]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#010503]/95 backdrop-blur-xl animate-fade-in p-0 overflow-hidden">
      <div className="relative w-full h-[100dvh] bg-[#020906] flex flex-col overflow-hidden text-white">
        <iframe
          src="/memory-system.html"
          title="Zoya Memory System"
          className="w-full h-full border-0 bg-[#020906]"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope"
        />
      </div>
    </div>
  );
};

