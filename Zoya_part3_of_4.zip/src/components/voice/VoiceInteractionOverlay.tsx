import React from 'react';
import { X, Mic, RefreshCw, VolumeX } from 'lucide-react';
import { AssistantState } from '../../services/speech/SpeechTypes';
import { useAudioLevel } from '../../services/speech/audioLevelStore';
import { MorphingSphere } from './MorphingSphere';

interface VoiceInteractionOverlayProps {
  isOpen: boolean;
  state: AssistantState;
  displayText: string;
  userQuery: string;
  partialText: string;
  errorMessage?: string | null;
  audioLevel?: number;
  onClose: () => Unit;
  onRetry: () => Unit;
  onInterrupt?: () => Unit;
}

type Unit = void;

/**
 * AssistantUI ported from OpenClawSession.kt
 */
export const VoiceInteractionOverlay: React.FC<VoiceInteractionOverlayProps> = ({
  isOpen,
  state,
  displayText,
  userQuery,
  partialText,
  errorMessage,
  audioLevel = 0,
  onClose,
  onRetry,
  onInterrupt,
}) => {
  const liveAudioLevel = useAudioLevel();
  const effectiveAudioLevel = audioLevel > 0 ? audioLevel : liveAudioLevel;
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4 bg-black/75 backdrop-blur-md animate-fade-in">
      <div className="w-full max-w-lg rounded-3xl bg-slate-900 border border-slate-800 p-6 shadow-2xl flex flex-col items-center gap-6 relative">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white rounded-full bg-slate-800/60 hover:bg-slate-800 transition-colors"
          title="बंद करें"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header / Assistant State */}
        <div className="text-center pt-2">
          <h3 className="text-lg font-semibold text-white tracking-wide">
            {state === AssistantState.LISTENING
              ? 'सुन रही हूँ...'
              : state === AssistantState.PROCESSING
              ? 'प्रोसेसिंग...'
              : state === AssistantState.THINKING
              ? 'सोच रही हूँ...'
              : state === AssistantState.SPEAKING
              ? 'जोया बोल रही है'
              : state === AssistantState.ERROR
              ? 'त्रुटि'
              : 'जोया असिस्टेंट'}
          </h3>
          <p className="text-xs text-slate-400 mt-1">
            {state === AssistantState.SPEAKING
              ? 'बीच में रोकने के लिए स्फीयर पर टैप करें'
              : 'स्पष्ट और सामान्य आवाज़ में बोलें'}
          </p>
        </div>

        {/* Morphing Sphere */}
        <div className="py-2">
          <MorphingSphere
            state={state}
            audioLevel={effectiveAudioLevel}
            size={140}
            onClick={() => {
              if (state === AssistantState.SPEAKING && onInterrupt) {
                onInterrupt();
              } else if (state === AssistantState.IDLE || state === AssistantState.ERROR) {
                onRetry();
              }
            }}
          />
        </div>

        {/* Real-time Subtitles / Text Content */}
        <div className="w-full min-h-[70px] flex flex-col items-center justify-center text-center px-4">
          {errorMessage ? (
            <p className="text-rose-400 text-sm font-medium">{errorMessage}</p>
          ) : displayText ? (
            <p className="text-white text-base font-medium leading-relaxed">{displayText}</p>
          ) : partialText ? (
            <p className="text-sky-300 text-base font-medium animate-pulse">"{partialText}"</p>
          ) : userQuery ? (
            <p className="text-slate-300 text-sm italic">"{userQuery}"</p>
          ) : (
            <p className="text-slate-500 text-sm">बोलना शुरू कीजिए...</p>
          )}
        </div>

        {/* Actions Bar */}
        <div className="w-full flex items-center justify-center gap-4 pt-2 border-t border-slate-800/80">
          {state === AssistantState.SPEAKING ? (
            <button
              onClick={onInterrupt}
              className="flex items-center gap-2 px-5 py-2.5 rounded-full bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold tracking-wide transition-all shadow-md active:scale-95"
            >
              <VolumeX className="w-4 h-4 text-sky-400" />
              <span>रोकें और बोलें (Barge-In)</span>
            </button>
          ) : state === AssistantState.ERROR ? (
            <button
              onClick={onRetry}
              className="flex items-center gap-2 px-5 py-2.5 rounded-full bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold tracking-wide transition-all shadow-md active:scale-95"
            >
              <RefreshCw className="w-4 h-4" />
              <span>पुनः प्रयास करें</span>
            </button>
          ) : (
            <button
              onClick={state === AssistantState.LISTENING ? onClose : onRetry}
              className="flex items-center gap-2 px-5 py-2.5 rounded-full bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold tracking-wide transition-all shadow-md active:scale-95"
            >
              <Mic className="w-4 h-4" />
              <span>{state === AssistantState.LISTENING ? 'पूरा हुआ' : 'माइक चालू करें'}</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
