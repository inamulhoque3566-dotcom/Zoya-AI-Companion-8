import React from 'react';
import { useAudioLevel } from '../../services/speech/audioLevelStore';

const LEFT_BAR_HEIGHTS = [12, 20, 28, 22, 34, 24, 18, 26, 14];
const RIGHT_BAR_HEIGHTS = [14, 26, 18, 24, 34, 22, 28, 20, 12];

interface MicSoundWavesProps {
  side: 'left' | 'right';
  isVoiceActive: boolean;
}

export const MicSoundWaves: React.FC<MicSoundWavesProps> = React.memo(({ side, isVoiceActive }) => {
  const audioLevel = useAudioLevel();
  const heights = side === 'left' ? LEFT_BAR_HEIGHTS : RIGHT_BAR_HEIGHTS;

  return (
    <div
      data-testid={`mic-soundwaves-${side}`}
      className="flex items-center gap-1 sm:gap-1.5 h-10 px-1"
      aria-hidden="true"
    >
      {heights.map((barH, idx) => {
        const dynamicScale = isVoiceActive
          ? 0.78 + ((idx % 3) + 1) * 0.22 + audioLevel * 0.6
          : 1;
        return (
          <span
            key={`${side}-wave-${idx}`}
            style={{
              height: `${Math.min(36, Math.round(barH * dynamicScale))}px`,
            }}
            className={`w-[3px] sm:w-[3.5px] rounded-full transition-all duration-150 ${
              idx % 2 === 0
                ? 'bg-gradient-to-t from-purple-500 via-cyan-400 to-cyan-200 shadow-[0_0_8px_rgba(34,211,238,0.85)]'
                : 'bg-gradient-to-t from-fuchsia-500 via-purple-400 to-cyan-300 shadow-[0_0_8px_rgba(168,85,247,0.8)]'
            } ${isVoiceActive ? 'animate-pulse' : 'opacity-95'}`}
          />
        );
      })}
    </div>
  );
});

MicSoundWaves.displayName = 'MicSoundWaves';
