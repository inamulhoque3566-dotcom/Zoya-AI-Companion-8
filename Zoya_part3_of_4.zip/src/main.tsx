import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { purgeDeprecatedClientSecrets } from './services/secretVault';
import { GlobalMicProvider } from './contexts/GlobalMicContext';

purgeDeprecatedClientSecrets();

if (typeof window !== 'undefined') {
  // Intercept and suppress benign ResizeObserver undelivered notifications
  window.addEventListener('error', (e: ErrorEvent) => {
    const msg = typeof e?.message === 'string' ? e.message : '';
    if (
      msg.includes('ResizeObserver loop completed with undelivered notifications') ||
      msg.includes('ResizeObserver loop limit exceeded')
    ) {
      e.stopImmediatePropagation();
      e.preventDefault();
    }
  });
}

createRoot(document.getElementById('root')!).render(
  <GlobalMicProvider>
    <App />
  </GlobalMicProvider>
);

