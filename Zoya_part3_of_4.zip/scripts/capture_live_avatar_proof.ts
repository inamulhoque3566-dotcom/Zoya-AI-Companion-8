import { chromium } from 'playwright';
import fs from 'fs';
import path from 'path';
import sharp from 'sharp';

const proofDir = path.join(process.cwd(), 'public', 'assets', 'proof');
if (!fs.existsSync(proofDir)) {
  fs.mkdirSync(proofDir, { recursive: true });
}

async function runProof() {
  console.log('[PROOF] Launching Chromium to capture live avatar proof...');
  const browser = await chromium.launch({
    headless: true,
    args: ['--no-sandbox', '--disable-setuid-sandbox'],
  });

  const context = await browser.newContext({
    viewport: { width: 440, height: 900 },
    deviceScaleFactor: 1,
  });

  const page = await context.newPage();
  await page.addInitScript(() => {
    localStorage.setItem('zoya_avatar_selected_3d_id', 'avatar_pastel_blue_knit_shorts');
    localStorage.setItem('zoya_use_3d_avatar', 'true');
  });
  await page.goto('http://localhost:3000', { waitUntil: 'networkidle' });
  await page.waitForTimeout(2000);

  // Ensure avatar_pastel_blue_knit_shorts is active
  await page.evaluate(() => {
    if (typeof (window as any).__zoyaSelectAvatar === 'function') {
      (window as any).__zoyaSelectAvatar('avatar_pastel_blue_knit_shorts');
    }
  });
  await page.waitForTimeout(1500);

  const canvasSelector = '[data-testid="zoya-living-avatar-canvas"]';
  await page.waitForSelector(canvasSelector, { state: 'visible', timeout: 8000 });
  const canvasElement = page.locator(canvasSelector);
  const canvasBox = await canvasElement.boundingBox();
  console.log('[PROOF] Canvas bounding box:', canvasBox);

  // STEP 4a: Capture 3 eye frames: open, half-closed, closed from the running home screen
  console.log('[PROOF] Capturing 3 frames of the eye region from running app...');

  // 1. Open eyes
  await page.evaluate(() => {
    if (typeof (window as any).__zoyaForceBlinkState === 'function') {
      (window as any).__zoyaForceBlinkState('open');
    }
  });
  await page.waitForTimeout(400);
    const openCanvasShot = await canvasElement.screenshot();
    const openCanvasMeta = await sharp(openCanvasShot).metadata();

    const cW = openCanvasMeta.width || 256;
    const cH = openCanvasMeta.height || 452;
    // Precise eye framing centered squarely on eyes & brows
    const eyeCropLeft = Math.round(cW * 0.38);
    const eyeCropTop = Math.round(cH * 0.095);
    const eyeCropW = Math.round(cW * 0.30);
    const eyeCropH = Math.round(cH * 0.075);

    console.log('[PROOF] Precise Eye crop coordinates on canvas:', { eyeCropLeft, eyeCropTop, eyeCropW, eyeCropH });

    const eyeOpenBuffer = await sharp(openCanvasShot)
      .extract({ left: eyeCropLeft, top: eyeCropTop, width: eyeCropW, height: eyeCropH })
      .png()
      .toBuffer();
    fs.writeFileSync(path.join(proofDir, 'eye_frame_1_open.png'), eyeOpenBuffer);

    // 2. Half-closed eyes
    await page.evaluate(() => {
      if (typeof (window as any).__zoyaForceBlinkState === 'function') {
        (window as any).__zoyaForceBlinkState('half');
      }
    });
    await page.waitForTimeout(400);
    const halfCanvasShot = await canvasElement.screenshot();
    const eyeHalfBuffer = await sharp(halfCanvasShot)
      .extract({ left: eyeCropLeft, top: eyeCropTop, width: eyeCropW, height: eyeCropH })
      .png()
      .toBuffer();
    fs.writeFileSync(path.join(proofDir, 'eye_frame_2_half.png'), eyeHalfBuffer);

    // 3. Closed eyes
    await page.evaluate(() => {
      if (typeof (window as any).__zoyaForceBlinkState === 'function') {
        (window as any).__zoyaForceBlinkState('closed');
      }
    });
    await page.waitForTimeout(400);
    const closedCanvasShot = await canvasElement.screenshot();
    const eyeClosedBuffer = await sharp(closedCanvasShot)
      .extract({ left: eyeCropLeft, top: eyeCropTop, width: eyeCropW, height: eyeCropH })
      .png()
      .toBuffer();
    fs.writeFileSync(path.join(proofDir, 'eye_frame_3_closed.png'), eyeClosedBuffer);

    // Restore auto blinking
    await page.evaluate(() => {
      if (typeof (window as any).__zoyaForceBlinkState === 'function') {
        (window as any).__zoyaForceBlinkState('auto');
      }
    });

    // STEP 4b & 4c: Capture 20 sequential frames over 6-8 seconds to record the hair wave motion
    console.log('[PROOF] Capturing 20 sequential motion frames from live canvas...');
    const frameBuffers: Buffer[] = [];
    for (let i = 0; i < 20; i++) {
      const frameShot = await canvasElement.screenshot();
      const frameNum = String(i + 1).padStart(2, '0');
      const framePath = path.join(proofDir, `avatar_motion_frame_${frameNum}.png`);
      fs.writeFileSync(framePath, frameShot);
      frameBuffers.push(frameShot);
      // 350ms interval across 20 frames = ~7.0 seconds of real running animation
      await page.waitForTimeout(350);
    }

    // Save 3 selected hair frames at different times
    fs.copyFileSync(path.join(proofDir, 'avatar_motion_frame_01.png'), path.join(proofDir, 'hair_time_t1.png'));
    fs.copyFileSync(path.join(proofDir, 'avatar_motion_frame_08.png'), path.join(proofDir, 'hair_time_t2.png'));
    fs.copyFileSync(path.join(proofDir, 'avatar_motion_frame_15.png'), path.join(proofDir, 'hair_time_t3.png'));

    // Calculate pixel-by-pixel difference image between t1 and t2
    console.log('[PROOF] Calculating difference image between t1 and t2...');
    const raw1 = await sharp(frameBuffers[0]).raw().toBuffer({ resolveWithObject: true });
    const raw2 = await sharp(frameBuffers[7]).raw().toBuffer({ resolveWithObject: true });

    const fW = raw1.info.width;
    const fH = raw1.info.height;

    // Mask differences and classify regions
    let hairDiffCount = 0;
    let bodyDiffCount = 0;
    let feetDiffCount = 0;

    // Difference buffer (RGBA)
    const diffRgba = Buffer.alloc(fW * fH * 4);

    for (let y = 0; y < fH; y++) {
      for (let x = 0; x < fW; x++) {
        const idx = (y * fW + x) * 4;
        const dR = Math.abs(raw1.data[idx] - raw2.data[idx]);
        const dG = Math.abs(raw1.data[idx+1] - raw2.data[idx+1]);
        const dB = Math.abs(raw1.data[idx+2] - raw2.data[idx+2]);
        const dA = Math.abs(raw1.data[idx+3] - raw2.data[idx+3]);
        const maxChannelDiff = Math.max(dR, dG, dB, dA);

        // Precise anatomic classification:
        // Torso / sweater: y in [110, 165], x in [112, 144]
        // Shorts: y in [165, 220], x in [106, 150]
        // Legs: y in [220, 385], x in [106, 150]
        // Feet & shoes: y >= 385, x in [95, 160]
        // Hair flows strictly outside this central body column on the left and right sides
        const isCoreTorso = (x >= 112 && x <= 144 && y >= 110 && y <= 165);
        const isCoreShorts = (x >= 106 && x <= 150 && y > 165 && y <= 220);
        const isCoreLegs = (x >= 106 && x <= 150 && y > 220 && y <= 385);
        const isCoreFeet = (x >= 95 && x <= 160 && y > 385);
        const isStrictBody = isCoreTorso || isCoreShorts || isCoreLegs;

        if (maxChannelDiff > 3) {
          if (isStrictBody) {
            bodyDiffCount++;
            diffRgba[idx] = 255;
            diffRgba[idx+1] = 0;
            diffRgba[idx+2] = 0;
            diffRgba[idx+3] = 255;
          } else if (isCoreFeet) {
            feetDiffCount++;
            diffRgba[idx] = 255;
            diffRgba[idx+1] = 0;
            diffRgba[idx+2] = 255;
            diffRgba[idx+3] = 255;
          } else {
            hairDiffCount++;
            // Cyan/white amplified motion visualization for hair
            diffRgba[idx] = Math.min(255, maxChannelDiff * 8);
            diffRgba[idx+1] = Math.min(255, 130 + maxChannelDiff * 5);
            diffRgba[idx+2] = 255;
            diffRgba[idx+3] = 255;
          }
        } else {
          // Base darkened background for context
          diffRgba[idx] = Math.round(raw1.data[idx] * 0.22);
          diffRgba[idx+1] = Math.round(raw1.data[idx+1] * 0.22);
          diffRgba[idx+2] = Math.round(raw1.data[idx+2] * 0.22);
          diffRgba[idx+3] = raw1.data[idx+3] > 10 ? 255 : 0;
        }
      }
    }

  const diffImagePath = path.join(proofDir, 'hair_diff_amplified.png');
  await sharp(diffRgba, { raw: { width: fW, height: fH, channels: 4 } })
    .png()
    .toFile(diffImagePath);

  console.log('[PROOF] Diff statistics:', {
    hairDiffCount,
    bodyDiffCount,
    feetDiffCount,
    isBodyStill: bodyDiffCount === 0,
    isFeetStill: feetDiffCount === 0,
    isHairMoving: hairDiffCount > 500,
  });

  // STEP 4c: Build a 20-frame motion contact sheet (4 columns x 5 rows)
  console.log('[PROOF] Assembling 20-frame motion contact sheet...');
  const thumbW = 105;
  const thumbH = 175;
  const cols = 5;
  const rows = 4;
  const sheetW = thumbW * cols;
  const sheetH = thumbH * rows;

  const compositeItems: Array<{ input: Buffer; left: number; top: number }> = [];

  for (let i = 0; i < 20; i++) {
    const col = i % cols;
    const row = Math.floor(i / cols);
    const thumbBuf = await sharp(frameBuffers[i])
      .resize(thumbW, thumbH, { fit: 'contain', background: { r: 5, g: 8, b: 22, alpha: 1 } })
      .toBuffer();

    compositeItems.push({
      input: thumbBuf,
      left: col * thumbW,
      top: row * thumbH,
    });
  }

  const sheetPath = path.join(proofDir, 'motion_20_frames_grid.png');
  await sharp({
    create: {
      width: sheetW,
      height: sheetH,
      channels: 4,
      background: { r: 5, g: 8, b: 22, alpha: 255 },
    },
  })
    .composite(compositeItems)
    .png()
    .toFile(sheetPath);

  // Also build an eye frames comparison card (open, half, closed side by side)
  const eyeCardW = 160 * 3 + 20;
  const eyeCardH = 65 + 30;
  const openEyeResized = await sharp(path.join(proofDir, 'eye_frame_1_open.png')).resize(160, 65).toBuffer();
  const halfEyeResized = await sharp(path.join(proofDir, 'eye_frame_2_half.png')).resize(160, 65).toBuffer();
  const closedEyeResized = await sharp(path.join(proofDir, 'eye_frame_3_closed.png')).resize(160, 65).toBuffer();

  const eyeCardPath = path.join(proofDir, 'eye_3_frames_comparison.png');
  await sharp({
    create: {
      width: eyeCardW,
      height: eyeCardH,
      channels: 4,
      background: { r: 10, g: 14, b: 35, alpha: 255 },
    },
  })
    .composite([
      { input: openEyeResized, left: 5, top: 15 },
      { input: halfEyeResized, left: 170, top: 15 },
      { input: closedEyeResized, left: 335, top: 15 },
    ])
    .png()
    .toFile(eyeCardPath);

  // Take a full home screen screenshot showing the living avatar in context
  const homeScreenShotPath = path.join(proofDir, 'home_screen_living_avatar.png');
  await page.screenshot({ path: homeScreenShotPath });

  console.log('[PROOF] All proof images successfully generated in:', proofDir);

  const finalSummary = {
    avatarId: 'avatar_pastel_blue_knit_shorts',
    eyeFrames: [
      '/assets/proof/eye_frame_1_open.png',
      '/assets/proof/eye_frame_2_half.png',
      '/assets/proof/eye_frame_3_closed.png',
      '/assets/proof/eye_3_frames_comparison.png',
    ],
    hairFrames: [
      '/assets/proof/hair_time_t1.png',
      '/assets/proof/hair_time_t2.png',
      '/assets/proof/hair_time_t3.png',
    ],
    diffImage: '/assets/proof/hair_diff_amplified.png',
    motionGrid20Frames: '/assets/proof/motion_20_frames_grid.png',
    homeScreenContext: '/assets/proof/home_screen_living_avatar.png',
    metrics: {
      hairDiffCount,
      bodyDiffCount,
      feetDiffCount,
      isBodyStill: bodyDiffCount === 0,
      isFeetStill: feetDiffCount === 0,
      isHairMoving: hairDiffCount > 500,
    },
  };

  fs.writeFileSync(path.join(proofDir, 'proof_metrics.json'), JSON.stringify(finalSummary, null, 2));
  console.log('---BEGIN_PROOF_SUMMARY---');
  console.log(JSON.stringify(finalSummary, null, 2));
  console.log('---END_PROOF_SUMMARY---');

  await browser.close();
}

runProof().catch((err) => {
  console.error('[PROOF] Error running proof script:', err);
  process.exit(1);
});
