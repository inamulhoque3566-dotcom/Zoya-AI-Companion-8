const sharp = require('sharp');

async function inspectAvatarB() {
  const meta = await sharp('public/assets/images/avatars_3d/transparent/avatar_midnight_gold_zari_saree.png').metadata();
  console.log('Avatar B transparent meta:', meta);

  const { data, info } = await sharp('public/assets/images/avatars_3d/transparent/avatar_midnight_gold_zari_saree.png')
    .raw()
    .toBuffer({ resolveWithObject: true });

  const w = info.width;
  const h = info.height;

  // 1. Check bottom rows: saree hem edge & feet (y from 1200 to 1536)
  console.log('--- Scanning bottom of saree for hem edge and feet (y=1250..1536) ---');
  let maxY = -1;
  let minActiveY = h;
  for (let y = 1250; y < h; y += 10) {
    let count = 0;
    let minX = w, maxX = -1;
    for (let x = 0; x < w; x++) {
      const a = data[(y * w + x) * 4 + 3];
      if (a > 10) {
        count++;
        if (x < minX) minX = x;
        if (x > maxX) maxX = x;
      }
    }
    if (count > 0) {
      if (y > maxY) maxY = y;
      if (y < minActiveY) minActiveY = y;
      console.log(`y=${y}: count=${count}, span=[${minX}..${maxX}]`);
    }
  }
  console.log(`Bottom-most active Y in Avatar B: ${maxY} (total height: ${h})`);

  // Let's inspect the pristine source: public/assets/aistudio/file_00000000c0d4821189e14bf178224f8d_f1687d5b.png
  const src = await sharp('public/assets/aistudio/file_00000000c0d4821189e14bf178224f8d_f1687d5b.png')
    .raw()
    .toBuffer({ resolveWithObject: true });

  let srcMaxY = -1;
  for (let y = 1250; y < src.info.height; y += 10) {
    let count = 0;
    let minX = w, maxX = -1;
    for (let x = 0; x < w; x++) {
      const a = src.data[(y * w + x) * 4 + 3];
      if (a > 10) {
        count++;
        if (x < minX) minX = x;
        if (x > maxX) maxX = x;
      }
    }
    if (count > 0) {
      if (y > srcMaxY) srcMaxY = y;
      console.log(`SRC y=${y}: count=${count}, span=[${minX}..${maxX}]`);
    }
  }
  console.log(`Bottom-most active Y in Avatar B SOURCE: ${srcMaxY}`);

  // Also check if pristine_sources/avatar_midnight_gold_zari_saree.jpg has feet!
  const srcJpg = await sharp('pristine_sources/avatar_midnight_gold_zari_saree.jpg')
    .raw()
    .toBuffer({ resolveWithObject: true });
  console.log('pristine JPG info:', srcJpg.info);
}

inspectAvatarB().catch(console.error);
