const fs = require('fs');
const path = require('path');
const sharp = require('sharp');

const OUTPUT_DIR = path.join(__dirname, '../public/assets/cleaned_cards');
if (!fs.existsSync(OUTPUT_DIR)) {
  fs.mkdirSync(OUTPUT_DIR, { recursive: true });
}

const CARDS = [
  { id: 1, name: 'Peasant Blouse & Lavender Skirt', file: 'public/assets/aistudio/IMG_20261107_215024_31a3bd2f.jpg', sparkle: { x: 404, y: 746, r: 24 }, dressRepair: 'peasant_blouse' },
  { id: 2, name: 'Pink Rib Knit & White Maxi', file: 'public/assets/aistudio/IMG_20261107_214934_8d1e7d13.jpg', sparkle: { x: 399, y: 764, r: 24 }, dressRepair: 'none' },
  { id: 3, name: 'Boho Floral Mini Dress', file: 'public/assets/aistudio/IMG_20261107_215038_2d959489.jpg', sparkle: { x: 411, y: 727, r: 24 }, dressRepair: 'none' },
  { id: 4, name: 'Midnight Royal Black Gown', file: 'public/assets/aistudio/IMG_20261107_214920_95529242.jpg', sparkle: { x: 424, y: 734, r: 24 }, dressRepair: 'none' },
  { id: 5, name: 'Sapphire Celestial Gown', file: 'public/assets/aistudio/IMG_20261107_214834_2cc2c15e.jpg', sparkle: { x: 404, y: 819, r: 24 }, dressRepair: 'none' },
  { id: 6, name: 'Blush Pink Butterfly Fairy Gown', file: 'public/assets/aistudio/IMG_20261107_214849_3f40370c.jpg', sparkle: { x: 396, y: 751, r: 24 }, dressRepair: 'blush_pink' },
  { id: 7, name: 'Red Cardigan & Floral Skirt', file: 'public/assets/aistudio/IMG_20261107_214817_ecccd031.jpg', sparkle: { x: 432, y: 699, r: 24 }, dressRepair: 'none' },
  { id: 8, name: 'Traditional Elegant Saree', file: 'public/assets/aistudio/IMG_20261107_214634_8d7cd9df.jpg', sparkle: null, dressRepair: 'none' },
  { id: 9, name: 'Floral Palazzo Pants Ensemble', file: 'public/assets/aistudio/IMG_20261107_214905_239ff410.jpg', sparkle: { x: 447, y: 712, r: 24 }, dressRepair: 'none' },
  { id: 10, name: 'Sage Daisy Gingham Dress', file: 'public/assets/aistudio/IMG_20261107_214800_ca1436a6.jpg', sparkle: { x: 444, y: 778, r: 24 }, dressRepair: 'none' },
  { id: 11, name: 'Boho Brown Scarf & Skirt', file: 'public/assets/aistudio/IMG_20261107_214739_e6c5eba6.jpg', sparkle: { x: 395, y: 691, r: 24 }, dressRepair: 'none' },
  { id: 12, name: 'Lilac Tulle Ruffle Gown', file: 'public/assets/aistudio/IMG_20261107_214947_05ef7886.jpg', sparkle: { x: 402, y: 757, r: 24 }, dressRepair: 'none' },
  { id: 13, name: 'Royal Plum Zari Anarkali', file: 'public/assets/aistudio/IMG_20261107_214720_4ad023a7.jpg', sparkle: { x: 459, y: 836, r: 24 }, dressRepair: 'none' },
  { id: 14, name: 'Classic Sweater & Glasses (Zoya)', file: 'public/assets/aistudio/IMG_20261107_214701_98c05f1c.jpg', sparkle: { x: 410, y: 848, r: 24 }, dressRepair: 'zoya' },
];

async function processCard(cardInfo) {
  const { id, name, file, sparkle, dressRepair } = cardInfo;
  console.log(`\n========================================`);
  console.log(`[Card ${id}/14] Processing: ${name}`);
  console.log(`Input: ${file}`);

  const img = sharp(path.join(__dirname, '..', file));
  const { data, info } = await img.raw().toBuffer({ resolveWithObject: true });
  const W = info.width;
  const H = info.height;
  const channels = info.channels;

  // Make an RGBA output buffer
  const outBuf = Buffer.alloc(W * H * 4);

  // Copy entire input to output buffer first
  for (let y = 0; y < H; y++) {
    for (let x = 0; x < W; x++) {
      const srcIdx = (y * W + x) * channels;
      const dstIdx = (y * W + x) * 4;
      outBuf[dstIdx] = data[srcIdx];
      outBuf[dstIdx + 1] = data[srcIdx + 1];
      outBuf[dstIdx + 2] = data[srcIdx + 2];
      outBuf[dstIdx + 3] = 255;
    }
  }

  // 1. Establish the clean card viewport background color per row
  // We sample left margin (x = 0.08*W to 0.16*W) and right margin (x = 0.84*W to 0.92*W)
  const bgRow = new Array(H);
  for (let y = 0; y < H; y++) {
    let rSum = 0, gSum = 0, bSum = 0, cnt = 0;
    const minX1 = Math.floor(W * 0.08), maxX1 = Math.floor(W * 0.16);
    const minX2 = Math.floor(W * 0.84), maxX2 = Math.floor(W * 0.92);

    for (let x = minX1; x <= maxX1; x += 2) {
      const idx = (y * W + x) * channels;
      rSum += data[idx]; gSum += data[idx + 1]; bSum += data[idx + 2]; cnt++;
    }
    for (let x = minX2; x <= maxX2; x += 2) {
      const idx = (y * W + x) * channels;
      rSum += data[idx]; gSum += data[idx + 1]; bSum += data[idx + 2]; cnt++;
    }
    // Baseline dark navy card background: #090D19 ~ (9, 13, 25)
    const r = Math.max(7, Math.min(15, Math.round(rSum / cnt)));
    const g = Math.max(10, Math.min(18, Math.round(gSum / cnt)));
    const b = Math.max(20, Math.min(30, Math.round(bSum / cnt)));
    bgRow[y] = [r, g, b];
  }

  // 2. Identify the avatar viewport bounds
  // Find cyan pill "● Full HD 3D प्रस्तुति" dot to get exact bottom boundary of the avatar viewport
  let dotY = -1, dotX = -1;
  for (let y = Math.floor(H * 0.50); y < Math.floor(H * 0.85); y++) {
    for (let x = Math.floor(W * 0.08); x < Math.floor(W * 0.28); x++) {
      const idx = (y * W + x) * channels;
      const r = data[idx], g = data[idx + 1], b = data[idx + 2];
      if (r < 30 && g > 140 && b > 190) {
        dotY = y;
        dotX = x;
        break;
      }
    }
    if (dotY !== -1) break;
  }

  const yTop = Math.floor(H * 0.08); // right below top pill badge
  // In Zoya card (id 14), floor extends down to y ~ 970 and cyan pill is at 1011
  // In other cards, avatar ends before dotY - 5
  const yBottom = dotY !== -1 ? dotY - 6 : Math.floor(H * 0.68);
  const xLeft = Math.floor(W * 0.07);
  const xRight = Math.floor(W * 0.93);

  console.log(`Avatar viewport: X=[${xLeft}, ${xRight}], Y=[${yTop}, ${yBottom}] (Cyan pill dot at ${dotX}, ${dotY})`);

  // Helper: check if pixel is sparkle diamond
  const isSparklePixel = (x, y, r, g, b) => {
    if (sparkle) {
      const dx = x - sparkle.x;
      const dy = y - sparkle.y;
      if (dx * dx + dy * dy <= sparkle.r * sparkle.r) {
        return true;
      }
    }
    // Additional detection for any diamond icon in lower right quadrant
    if (x > W * 0.60 && x < W * 0.80 && y > H * 0.48 && y < H * 0.72) {
      if (r > 45 && g > 45 && b > 65 && b < 165) {
        // Sparkle diamond has lavender/blue tint and is distinct from dark navy
        if (Math.abs(r - g) < 22 && b > g + 8 && b > r + 5) {
          return true;
        }
      }
    }
    return false;
  };

  // Helper: check if pixel is unwanted purple strip / duplicate background (cards 1-13)
  const isPurpleStrip = (x, y, r, g, b) => {
    if (id === 14) return false;
    // Purple strip signature:
    // 1. Blue-violet dominance over green: (b >= 28 && b > g + 12 && g <= 26)
    if (b >= 28 && b > g + 12 && g <= 26) return true;
    // 2. Dark purple core:
    if (r >= 14 && r <= 38 && g <= 18 && b >= 34 && b <= 75) return true;
    // 3. Dark violet fringe:
    if (b > g + 10 && b >= 25 && r <= 48 && g <= 22) return true;
    // 4. In Card 10 (Daisy Gingham), horizontal bars & butterfly icons at y in [170, 350]:
    if (id === 10 && y >= 170 && y <= 350) {
      if ((b >= 28 || r >= 14) && g <= 26 && !(r > 150 && g > 150)) {
        return true;
      }
    }
    return false;
  };

  // Helper: check if pixel is unwanted white box / floor patch (card 14 Zoya)
  const isZoyaArtifact = (x, y, r, g, b) => {
    if (id !== 14) return false;
    // 1. Blue/grey horizontal banner at y in [230..280] outside head & hair:
    if (y >= 230 && y <= 285 && (x < 240 || x > 365)) {
      if (b > 60 && g > 45 && r > 40) return true;
    }
    // 2. Upper body / shoulder white edges:
    if (y >= 150 && y <= 500 && (x < 235 || x > 375)) {
      if (r > 60 && g > 60 && b > 60) return true;
    }
    // 3. White patches beside pleated skirt: y in [700..875], x < 215 or x > 385:
    if (y >= 700 && y <= 875 && (x < 215 || x > 385)) {
      if (r > 60 || g > 60 || b > 60) return true;
    }
    // 4. White floor patch at y in [875..968]:
    if (y >= 875 && y <= 968) {
      // Outside her shoes (shoes: x in [266..345], y in [920..956])
      const isShoeLeft = (x >= 268 && x <= 302 && y >= 920 && y <= 956 && r < 75 && g < 75 && b < 75);
      const isShoeRight = (x >= 312 && x <= 346 && y >= 920 && y <= 956 && r < 75 && g < 75 && b < 75);
      const isSockLeft = (x >= 274 && x <= 298 && y >= 875 && y < 920);
      const isSockRight = (x >= 316 && x <= 340 && y >= 875 && y < 920);
      
      if (!isShoeLeft && !isShoeRight && !isSockLeft && !isSockRight) {
        // Any pixel that is part of the white floor box or floor shadow:
        if (r > 15 || g > 15 || b > 25) return true;
      }
    }
    return false;
  };

  // 3. Clean Viewport Pixels (Remove duplicate backgrounds, strips, boxes, sparkles)
  for (let y = yTop; y <= yBottom; y++) {
    for (let x = xLeft; x <= xRight; x++) {
      const dstIdx = (y * W + x) * 4;
      const r = outBuf[dstIdx];
      const g = outBuf[dstIdx + 1];
      const b = outBuf[dstIdx + 2];

      // Remove sparkle icon
      if (isSparklePixel(x, y, r, g, b)) {
        const bg = bgRow[y];
        outBuf[dstIdx] = bg[0];
        outBuf[dstIdx + 1] = bg[1];
        outBuf[dstIdx + 2] = bg[2];
        continue;
      }

      // Remove purple strip (cards 1-13)
      if (isPurpleStrip(x, y, r, g, b)) {
        const bg = bgRow[y];
        outBuf[dstIdx] = bg[0];
        outBuf[dstIdx + 1] = bg[1];
        outBuf[dstIdx + 2] = bg[2];
        continue;
      }

      // Remove white box / floor patch (card 14)
      if (isZoyaArtifact(x, y, r, g, b)) {
        const bg = bgRow[y];
        outBuf[dstIdx] = bg[0];
        outBuf[dstIdx + 1] = bg[1];
        outBuf[dstIdx + 2] = bg[2];
        continue;
      }
    }
  }

  // 4. Dress Repair: Special Handling for Damaged Skirts & Gowns
  if (dressRepair === 'peasant_blouse') {
    console.log(`Applying Dress Repair for Peasant Blouse Lavender Skirt...`);
    const xCenter = Math.floor(W * 0.49);
    for (let y = Math.floor(H * 0.42); y <= Math.floor(H * 0.50); y++) {
      // Find left skirt edge at this y
      let leftSkirtX = xCenter;
      for (let x = xCenter; x >= xLeft; x--) {
        const idx = (y * W + x) * 4;
        const r = outBuf[idx], g = outBuf[idx + 1], b = outBuf[idx + 2];
        if (r > 140 && g > 110 && b > 120) {
          leftSkirtX = x;
        } else break;
      }
      const skirtRadius = xCenter - leftSkirtX;
      if (skirtRadius > 60) {
        const targetRightX = xCenter + skirtRadius;
        for (let x = xCenter; x <= targetRightX; x++) {
          const idx = (y * W + x) * 4;
          const r = outBuf[idx], g = outBuf[idx + 1], b = outBuf[idx + 2];
          const isSkirt = (r > 130 && g > 100 && b > 110);
          if (!isSkirt) {
            const mirrorX = xCenter - (x - xCenter);
            const mirrorIdx = (y * W + mirrorX) * 4;
            outBuf[idx] = outBuf[mirrorIdx];
            outBuf[idx + 1] = outBuf[mirrorIdx + 1];
            outBuf[idx + 2] = outBuf[mirrorIdx + 2];
          }
        }
      }
    }
  } else if (dressRepair === 'blush_pink') {
    console.log(`Applying Dress Repair for Blush Pink Butterfly Fairy Gown...`);
    const xCenter = Math.floor(W * 0.495);
    for (let y = Math.floor(H * 0.38); y <= Math.floor(H * 0.50); y++) {
      const progress = (y - Math.floor(H * 0.38)) / (Math.floor(H * 0.50) - Math.floor(H * 0.38));
      const expectedRadius = Math.round(95 + progress * 105);

      for (let dx = 0; dx <= expectedRadius; dx++) {
        const xL = xCenter - dx;
        const xR = xCenter + dx;

        const idxL = (y * W + xL) * 4;
        const isL = (outBuf[idxL] > 140 && outBuf[idxL + 1] > 110 && outBuf[idxL + 2] > 120);
        const idxR = (y * W + xR) * 4;
        const isR = (outBuf[idxR] > 140 && outBuf[idxR + 1] > 110 && outBuf[idxR + 2] > 120);

        if (!isL && isR) {
          outBuf[idxL] = outBuf[idxR];
          outBuf[idxL + 1] = outBuf[idxR + 1];
          outBuf[idxL + 2] = outBuf[idxR + 2];
        } else if (!isR && isL) {
          outBuf[idxR] = outBuf[idxL];
          outBuf[idxR + 1] = outBuf[idxL + 1];
          outBuf[idxR + 2] = outBuf[idxL + 2];
        }
      }
    }
  } else if (dressRepair === 'zoya') {
    console.log(`Applying Dress & Floor Repair for Zoya...`);
    const xCenter = Math.floor(W * 0.50);
    // Smooth brown pleated skirt contour and restore rich brown tone (#53392d)
    for (let y = Math.floor(H * 0.44); y <= Math.floor(H * 0.65); y++) {
      let minX = xCenter, maxX = xCenter;
      for (let x = xCenter; x >= xLeft; x--) {
        const idx = (y * W + x) * 4;
        if (outBuf[idx] > 35 && outBuf[idx + 1] > 22 && outBuf[idx + 2] > 18 && outBuf[idx] < 150) {
          minX = x;
        } else break;
      }
      for (let x = xCenter; x <= xRight; x++) {
        const idx = (y * W + x) * 4;
        if (outBuf[idx] > 35 && outBuf[idx + 1] > 22 && outBuf[idx + 2] > 18 && outBuf[idx] < 150) {
          maxX = x;
        } else break;
      }
      for (let x = minX; x <= maxX; x++) {
        const idx = (y * W + x) * 4;
        const r = outBuf[idx], g = outBuf[idx + 1], b = outBuf[idx + 2];
        if (r > 135 && g > 135 && b > 135) {
          outBuf[idx] = 85;
          outBuf[idx + 1] = 58;
          outBuf[idx + 2] = 46;
        }
      }
    }
  }

  // 5. Feet on the Ground: Add Soft, Subtle Contact Shadow directly under the soles
  const shoeBottomTargets = {
    1: 794,
    2: 825,
    3: 779,
    4: 783,
    5: 847,
    6: 781,
    7: 739,
    8: 872,
    9: 772,
    10: 856,
    11: 796,
    12: 812,
    13: 883,
    14: 955,
  };

  const actualShoeY = shoeBottomTargets[id] || Math.floor(H * 0.62);
  let shoeMinX = W, shoeMaxX = 0;
  for (let y = actualShoeY - 20; y <= actualShoeY; y++) {
    for (let x = Math.floor(W * 0.32); x <= Math.floor(W * 0.68); x++) {
      const idx = (y * W + x) * 4;
      const r = outBuf[idx], g = outBuf[idx + 1], b = outBuf[idx + 2];
      const bg = bgRow[y];
      if (Math.abs(r - bg[0]) > 14 || Math.abs(g - bg[1]) > 14 || Math.abs(b - bg[2]) > 18) {
        if (x < shoeMinX) shoeMinX = x;
        if (x > shoeMaxX) shoeMaxX = x;
      }
    }
  }

  if (shoeMinX < shoeMaxX) {
    const shadowCenterX = Math.round((shoeMinX + shoeMaxX) / 2);
    const shadowCenterY = actualShoeY + 1;
    const shadowRadiusX = Math.round((shoeMaxX - shoeMinX) * 0.56);
    const shadowRadiusY = Math.max(7, Math.round(shadowRadiusX * 0.20));

    console.log(`Adding grounded contact shadow under feet at (${shadowCenterX}, ${shadowCenterY}), Rx=${shadowRadiusX}, Ry=${shadowRadiusY}`);

    for (let dy = -shadowRadiusY; dy <= shadowRadiusY + 5; dy++) {
      for (let dx = -shadowRadiusX; dx <= shadowRadiusX; dx++) {
        const px = shadowCenterX + dx;
        const py = shadowCenterY + dy;
        if (px < xLeft || px > xRight || py < yTop || py > yBottom) continue;

        const dist = Math.sqrt((dx / shadowRadiusX) ** 2 + (dy / shadowRadiusY) ** 2);
        if (dist <= 1.0) {
          const shadowOpacity = Math.max(0, 0.44 * (1.0 - dist) ** 1.5);
          const idx = (py * W + px) * 4;

          const r = outBuf[idx], g = outBuf[idx + 1], b = outBuf[idx + 2];
          // Do not darken the shoe itself
          const isShoe = (py <= actualShoeY - 2 && (r > 38 || g > 30 || b > 38));
          if (!isShoe) {
            outBuf[idx] = Math.round(r * (1.0 - shadowOpacity * 0.70));
            outBuf[idx + 1] = Math.round(g * (1.0 - shadowOpacity * 0.70));
            outBuf[idx + 2] = Math.round(b * (1.0 - shadowOpacity * 0.70));
          }
        }
      }
    }
  }

  // 6. Subpixel Edge Anti-aliasing (Double-buffered to avoid streak cascade)
  const readBuf = Buffer.from(outBuf);
  for (let y = yTop; y <= yBottom; y++) {
    const bg = bgRow[y];
    for (let x = xLeft + 1; x < xRight - 1; x++) {
      const idx = (y * W + x) * 4;
      const r = readBuf[idx], g = readBuf[idx + 1], b = readBuf[idx + 2];

      const isCurrentBg = (Math.abs(r - bg[0]) <= 8 && Math.abs(g - bg[1]) <= 8 && Math.abs(b - bg[2]) <= 10);
      if (isCurrentBg) {
        const leftIdx = (y * W + (x - 1)) * 4;
        const rightIdx = (y * W + (x + 1)) * 4;
        const isLeftAvatar = (Math.abs(readBuf[leftIdx] - bg[0]) > 28 || Math.abs(readBuf[leftIdx + 1] - bg[1]) > 28);
        const isRightAvatar = (Math.abs(readBuf[rightIdx] - bg[0]) > 28 || Math.abs(readBuf[rightIdx + 1] - bg[1]) > 28);

        if (isLeftAvatar && !isRightAvatar) {
          outBuf[idx] = Math.round(0.32 * readBuf[leftIdx] + 0.68 * bg[0]);
          outBuf[idx + 1] = Math.round(0.32 * readBuf[leftIdx + 1] + 0.68 * bg[1]);
          outBuf[idx + 2] = Math.round(0.32 * readBuf[leftIdx + 2] + 0.68 * bg[2]);
        } else if (isRightAvatar && !isLeftAvatar) {
          outBuf[idx] = Math.round(0.32 * readBuf[rightIdx] + 0.68 * bg[0]);
          outBuf[idx + 1] = Math.round(0.32 * readBuf[rightIdx + 1] + 0.68 * bg[1]);
          outBuf[idx + 2] = Math.round(0.32 * readBuf[rightIdx + 2] + 0.68 * bg[2]);
        }
      }
    }
  }

  // 7. Write clean full card image (PNG & JPEG)
  const padId = String(id).padStart(2, '0');
  const outPngPath = path.join(OUTPUT_DIR, `card_${padId}.png`);
  const outJpgPath = path.join(OUTPUT_DIR, `card_${padId}.jpg`);

  await sharp(outBuf, { raw: { width: W, height: H, channels: 4 } })
    .png({ quality: 100, compressionLevel: 8 })
    .toFile(outPngPath);

  await sharp(outBuf, { raw: { width: W, height: H, channels: 4 } })
    .jpeg({ quality: 98 })
    .toFile(outJpgPath);

  console.log(`✓ Card ${id} saved successfully: ${outPngPath}`);
  return { id, name, png: `/assets/cleaned_cards/card_${padId}.png`, jpg: `/assets/cleaned_cards/card_${padId}.jpg` };
}

(async () => {
  console.log("Starting Master Avatar Background Cleanup for all 14 images...");
  const results = [];
  for (const card of CARDS) {
    const res = await processCard(card);
    results.push(res);
  }
  fs.writeFileSync(path.join(OUTPUT_DIR, 'manifest.json'), JSON.stringify(results, null, 2));
  console.log(`\nALL 14 CARDS COMPLETED FLAWLESSLY!`);
})();
