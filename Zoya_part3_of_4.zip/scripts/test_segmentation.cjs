const sharp = require('sharp');
const path = require('path');
const fs = require('fs');

async function testSegmentation() {
  const srcPath = path.join(__dirname, '../src/assets/images/zoya_3d_sweater_glasses_1793764031303.jpg');
  const { data: origRgb, info } = await sharp(srcPath).removeAlpha().raw().toBuffer({ resolveWithObject: true });
  const W = info.width, H = info.height;

  // 1. Calibrate row background from margins
  const rowBg = new Array(H);
  for (let y = 0; y < H; y++) {
    let r = 0, g = 0, b = 0, c = 0;
    for (let x = 0; x < 15; x++) {
      const i1 = (y * W + x) * 3;
      const i2 = (y * W + (W - 1 - x)) * 3;
      r += origRgb[i1] + origRgb[i2];
      g += origRgb[i1 + 1] + origRgb[i2 + 1];
      b += origRgb[i1 + 2] + origRgb[i2 + 2];
      c += 2;
    }
    rowBg[y] = [r / c, g / c, b / c];
  }

  // 2. Skirt hem per column: find exact bottom edge of the brown skirt
  const skirtHem = new Int32Array(W).fill(0);
  for (let x = 185; x <= 585; x++) {
    for (let y = 1100; y <= 1225; y++) {
      const idx = (y * W + x) * 3;
      const r = origRgb[idx], g = origRgb[idx + 1], b = origRgb[idx + 2];
      // Brown fabric
      const isBrown = (r > 35 && g > 25 && b > 20 && r > g && g >= b - 8 && (r - b) >= 6);
      if (isBrown) {
        skirtHem[x] = y;
      }
    }
  }
  // Smooth pinholes
  for (let x = 190; x <= 580; x++) {
    if (skirtHem[x] === 0 && skirtHem[x - 1] > 0 && skirtHem[x + 1] > 0) {
      skirtHem[x] = Math.round((skirtHem[x - 1] + skirtHem[x + 1]) / 2);
    }
  }

  // 3. Classify pixels: 0 = background, 1 = foreground
  const isBg = new Uint8Array(W * H);

  for (let y = 0; y < H; y++) {
    const [bgR, bgG, bgB] = rowBg[y];
    for (let x = 0; x < W; x++) {
      const idx = y * W + x;
      const idx3 = idx * 3;
      const r = origRgb[idx3], g = origRgb[idx3 + 1], b = origRgb[idx3 + 2];

      // Definite background zones:
      if (y < 28 || y > 1361 || x < 185 || x > 585) {
        isBg[idx] = 1;
        continue;
      }

      // Below skirt hem:
      const hemY = skirtHem[x];
      const isBelowSkirt = (hemY > 0 && y > hemY) || (hemY === 0 && y >= 1180);

      if (isBelowSkirt) {
        // Only legs/socks/shoes exist below skirt hem
        // Left leg/sock: x in [325..378]
        // Right leg/sock: x in [400..454]
        // Shoes base: y >= 1335 && x in [324..458]
        const inLeftLeg = (x >= 324 && x <= 378 && y <= 1361);
        const inRightLeg = (x >= 398 && x <= 456 && y <= 1361);
        const inShoeBase = (y >= 1335 && y <= 1361 && x >= 324 && x <= 458);

        if (!inLeftLeg && !inRightLeg && !inShoeBase) {
          isBg[idx] = 1;
          continue;
        }

        // Inside leg/sock/shoe candidate area:
        // Distinguish from background:
        const dist = Math.sqrt((r - bgR) ** 2 + (g - bgG) ** 2 + (b - bgB) ** 2);
        const chroma = Math.max(Math.abs(r - g), Math.abs(r - b), Math.abs(g - b));
        const isShoeDark = (r < 95 && g < 95 && b < 95);
        const isSkin = (r > 120 && g > 90 && b > 80 && (r - g) > 10);
        
        // For sock: sock is white/ribbed, but at the edges of the sock
        // Check if pixel is neutral grey background:
        if (isShoeDark || isSkin) {
          isBg[idx] = 0; // foreground
        } else if (dist < 18 && chroma <= 4) {
          isBg[idx] = 1; // background
        } else {
          // Sock body
          isBg[idx] = 0; // foreground
        }
        continue;
      }

      // Upper body (Head, Hair, Face, Sweater, Skirt):
      const dist = Math.sqrt((r - bgR) ** 2 + (g - bgG) ** 2 + (b - bgB) ** 2);
      const chroma = Math.max(Math.abs(r - g), Math.abs(r - b), Math.abs(g - b));
      const warmth = (r - b) + (r - g);

      // Studio background is neutral grey: chroma <= 6, warmth <= 4, dist < 30
      if (dist < 24 && chroma <= 6 && warmth <= 4) {
        isBg[idx] = 1;
      } else if (dist < 36 && chroma <= 4 && warmth <= 2) {
        isBg[idx] = 1;
      } else {
        isBg[idx] = 0;
      }
    }
  }

  // 4. Perform flood fill from borders to identify all connected background
  // This guarantees that any enclosed character texture (even if it had low chroma)
  // won't be eaten unless it is connected to the outer boundary
  const bgConnected = new Uint8Array(W * H);
  const queue = new Int32Array(W * H);
  let qHead = 0, qTail = 0;

  // Enqueue outer border pixels
  for (let x = 0; x < W; x++) {
    // top row
    bgConnected[x] = 1;
    queue[qTail++] = x;
    // bottom row
    const bIdx = (H - 1) * W + x;
    bgConnected[bIdx] = 1;
    queue[qTail++] = bIdx;
  }
  for (let y = 1; y < H - 1; y++) {
    // left column
    const lIdx = y * W;
    bgConnected[lIdx] = 1;
    queue[qTail++] = lIdx;
    // right column
    const rIdx = y * W + (W - 1);
    bgConnected[rIdx] = 1;
    queue[qTail++] = rIdx;
  }

  while (qHead < qTail) {
    const curr = queue[qHead++];
    const cx = curr % W;
    const cy = Math.floor(curr / W);

    const neighbors = [curr - 1, curr + 1, curr - W, curr + W];
    for (let k = 0; k < 4; k++) {
      const nIdx = neighbors[k];
      const nx = nIdx % W;
      const ny = Math.floor(nIdx / W);
      if (nx >= 0 && nx < W && ny >= 0 && ny < H) {
        if (bgConnected[nIdx] === 0 && isBg[nIdx] === 1) {
          bgConnected[nIdx] = 1;
          queue[qTail++] = nIdx;
        }
      }
    }
  }

  console.log(`Total pixels: ${W * H}, Background connected pixels: ${qTail}`);
  const fgPixelCount = W * H - qTail;
  console.log(`Foreground pixels: ${fgPixelCount}`);

  // Check silhouette bounds of foreground
  let minX = W, maxX = 0, minY = H, maxY = 0;
  for (let y = 0; y < H; y++) {
    for (let x = 0; x < W; x++) {
      const idx = y * W + x;
      if (bgConnected[idx] === 0) {
        if (x < minX) minX = x;
        if (x > maxX) maxX = x;
        if (y < minY) minY = y;
        if (y > maxY) maxY = y;
      }
    }
  }
  console.log(`Foreground bounds: X=[${minX}..${maxX}], Y=[${minY}..${maxY}]`);
}
testSegmentation().catch(console.error);
