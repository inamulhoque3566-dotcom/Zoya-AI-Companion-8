import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import express from 'express';
import {
  agentAuth,
  requireOwnerOrAgentAuth,
  createEndpointRateLimiter,
  AGENT_COOKIE_CONFIG,
  AgentAuthManager,
} from '../src/services/agent/agentAuth.ts';
import { maskSecrets } from '../src/services/agent/secretMasker.ts';
import { isBlockedFinancialPackage, ALLOWED_AUTOMATION_PACKAGES } from '../src/services/bankingSafetyConfig.ts';
import { validateApiKey } from '../src/services/serverYouTubeService.ts';
import {
  purgeDeprecatedClientSecrets,
  initializeSecretVault,
  getDecryptedSecretSync,
} from '../src/services/secretVault.ts';

function buildTestApp() {
  const app = express();
  app.use(express.json());

  const ttsElevenRateLimiter = createEndpointRateLimiter({
    name: 'tts-elevenlabs-test',
    maxRequestsPerIp: 30,
    windowMs: 60 * 1000,
  });

  app.post('/api/agent/auth/owner/reset-limit', agentAuth, (req, res) => {
    const { setupCode } = req.body || {};
    const headerSetup = typeof req.headers['x-setup-code'] === 'string' ? req.headers['x-setup-code'] : undefined;
    const effectiveSetup = (typeof setupCode === 'string' ? setupCode : undefined) || headerSetup;
    const clientIp = req.socket?.remoteAddress || 'unknown';
    const result = AgentAuthManager.checkAndTrackResetLimit(clientIp, effectiveSetup);
    if (result.allowed) {
      return res.json({ success: true });
    }
    return res.status(result.status).json({
      success: false,
      error: result.error,
      waitSeconds: result.waitSeconds,
    });
  });

  app.post('/api/agent/auth/pairing-code', (req, res) => {
    const clientIp = req.socket?.remoteAddress || 'unknown';
    const rate = AgentAuthManager.checkPairingEndpointRateLimit(clientIp, 'pair_issue');
    if (!rate.allowed) {
      if (rate.waitSeconds) res.setHeader('Retry-After', String(rate.waitSeconds));
      return res.status(429).json({ success: false, error: rate.error, waitSeconds: rate.waitSeconds });
    }
    return res.status(401).json({ success: false, error: 'Passphrase required' });
  });

  app.get('/api/agent/auth/token', (req, res) => {
    const clientIp = req.socket?.remoteAddress || 'unknown';
    const rate = AgentAuthManager.checkPairingEndpointRateLimit(clientIp, 'pair_consume');
    if (!rate.allowed) {
      if (rate.waitSeconds) res.setHeader('Retry-After', String(rate.waitSeconds));
      return res.status(429).json({ success: false, error: rate.error, waitSeconds: rate.waitSeconds });
    }
    if (!AgentAuthManager.isLocalOrTrustedOrigin(req)) {
      return res.status(403).json({ success: false, code: 'PAIRING_CODE_REQUIRED' });
    }
    const token = AgentAuthManager.getOrCreateToken();
    const pairedSession = AgentAuthManager.createPairedSession();
    res.setHeader(
      'Set-Cookie',
      `zoya_agent_paired_session=${pairedSession}; Path=/; HttpOnly; SameSite=${AGENT_COOKIE_CONFIG.sameSite}; Secure; Max-Age=3600`
    );
    return res.json({ success: true, token, pairedSession });
  });

  app.get('/api/agent/status', agentAuth, (_req, res) => {
    res.json({ success: true, ok: true });
  });

  app.post('/api/elevenlabs/config', requireOwnerOrAgentAuth, ttsElevenRateLimiter, (_req, res) => {
    res.json({ success: true, configured: false });
  });
  app.post('/api/tts', requireOwnerOrAgentAuth, ttsElevenRateLimiter, (_req, res) => {
    res.json({ success: true, ok: true });
  });
  app.post('/api/tts/preview', requireOwnerOrAgentAuth, ttsElevenRateLimiter, (_req, res) => {
    res.json({ success: true, ok: true });
  });
  app.get('/api/tts/diagnostics', requireOwnerOrAgentAuth, ttsElevenRateLimiter, (_req, res) => {
    res.json({ status: 'ok', policy: { roboticSpeechSynthesisBlocked: true } });
  });
  app.post('/api/elevenlabs/test-connection', requireOwnerOrAgentAuth, ttsElevenRateLimiter, (_req, res) => {
    res.json({ success: true });
  });

  return app;
}

async function startServer(app: express.Express): Promise<{ server: http.Server; baseUrl: string }> {
  const server = http.createServer(app);
  await new Promise<void>((resolve) => server.listen(0, '127.0.0.1', () => resolve()));
  const addr = server.address() as { port: number };
  return { server, baseUrl: `http://127.0.0.1:${addr.port}` };
}

test('1. No token returns 401', async () => {
  const { server, baseUrl } = await startServer(buildTestApp());
  try {
    const res = await fetch(`${baseUrl}/api/agent/status`);
    assert.equal(res.status, 401);
  } finally {
    await new Promise<void>((resolve) => server.close(() => resolve()));
  }
});

test('2. Wrong token returns 401', async () => {
  const { server, baseUrl } = await startServer(buildTestApp());
  try {
    const res = await fetch(`${baseUrl}/api/agent/status`, {
      headers: { Authorization: 'Bearer totally_wrong_secret_token_value' },
    });
    assert.equal(res.status, 401);
  } finally {
    await new Promise<void>((resolve) => server.close(() => resolve()));
  }
});

test('3. Empty Bearer returns 401', async () => {
  const { server, baseUrl } = await startServer(buildTestApp());
  try {
    const res = await fetch(`${baseUrl}/api/agent/status`, {
      headers: { Authorization: 'Bearer ' },
    });
    assert.equal(res.status, 401);
  } finally {
    await new Promise<void>((resolve) => server.close(() => resolve()));
  }
});

test('4. /api/agent/auth/owner/reset-limit without auth returns 401', async () => {
  const { server, baseUrl } = await startServer(buildTestApp());
  try {
    const res = await fetch(`${baseUrl}/api/agent/auth/owner/reset-limit`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ setupCode: 'anything' }),
    });
    assert.equal(res.status, 401);
  } finally {
    await new Promise<void>((resolve) => server.close(() => resolve()));
  }
});

test('5a. Reverse-proxy request (X-Forwarded-For on 127.0.0.1) without pairing code returns 403', async () => {
  const token = AgentAuthManager.getOrCreateToken();
  const { server, baseUrl } = await startServer(buildTestApp());
  try {
    const res = await fetch(`${baseUrl}/api/agent/status`, {
      headers: {
        Authorization: `Bearer ${token}`,
        'X-Forwarded-For': '203.0.113.42',
      },
    });
    assert.equal(res.status, 403);
  } finally {
    await new Promise<void>((resolve) => server.close(() => resolve()));
  }
});

test('5b. Non-loopback remoteAddress peer without pairing code returns 403', async () => {
  const token = AgentAuthManager.getOrCreateToken();
  let statusCode = 0;
  let body: any = null;
  let nextCalled = false;

  const mockReq = {
    headers: { authorization: `Bearer ${token}` },
    socket: { remoteAddress: '203.0.113.99' },
  } as any;
  const mockRes = {
    status(code: number) {
      statusCode = code;
      return this;
    },
    json(payload: any) {
      body = payload;
      return this;
    },
  } as any;

  agentAuth(mockReq, mockRes, () => {
    nextCalled = true;
  });

  assert.equal(nextCalled, false);
  assert.equal(statusCode, 403);
  assert.equal(body?.code, 'PAIRING_CODE_REQUIRED');
});

test('6a. Expired pairing code returns 403', async () => {
  const token = AgentAuthManager.getOrCreateToken();
  const expiredCode = AgentAuthManager.generatePairingCode(-1000);
  const { server, baseUrl } = await startServer(buildTestApp());
  try {
    const res = await fetch(`${baseUrl}/api/agent/status`, {
      headers: {
        Authorization: `Bearer ${token}`,
        'X-Forwarded-For': '203.0.113.42',
        'x-agent-pairing-code': expiredCode,
      },
    });
    assert.equal(res.status, 403);
  } finally {
    await new Promise<void>((resolve) => server.close(() => resolve()));
  }
});

test('6b. Valid 128-bit single-use pairing code succeeds once (200) and then returns 403 on reuse', async () => {
  const token = AgentAuthManager.getOrCreateToken();
  const pairingCode = AgentAuthManager.generatePairingCode();
  assert.ok(pairingCode.length >= 32, 'Pairing code must be at least 128 bits (32 hex chars)');

  const { server, baseUrl } = await startServer(buildTestApp());
  try {
    const first = await fetch(`${baseUrl}/api/agent/status`, {
      headers: {
        Authorization: `Bearer ${token}`,
        'X-Forwarded-For': '203.0.113.42',
        'x-agent-pairing-code': pairingCode,
      },
    });
    assert.equal(first.status, 200);

    const replay = await fetch(`${baseUrl}/api/agent/status`, {
      headers: {
        Authorization: `Bearer ${token}`,
        'X-Forwarded-For': '203.0.113.42',
        'x-agent-pairing-code': pairingCode,
      },
    });
    assert.equal(replay.status, 403);
  } finally {
    await new Promise<void>((resolve) => server.close(() => resolve()));
  }
});

test('7a. Authenticated reset-limit uses req.socket.remoteAddress (ignores spoofed X-Forwarded-For)', async () => {
  AgentAuthManager.clearAllResetLimits();
  const token = AgentAuthManager.getOrCreateToken();
  const setupCode = AgentAuthManager.getOrCreateSetupCode();

  const { server, baseUrl } = await startServer(buildTestApp());
  try {
    // Attempt 1 with X-Forwarded-For: 10.0.0.1 -> 401 + backoff tracked under 127.0.0.1
    const attempt1 = await fetch(`${baseUrl}/api/agent/auth/owner/reset-limit`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
        'X-Forwarded-For': '10.0.0.1',
        'x-agent-pairing-code': AgentAuthManager.generatePairingCode(),
      },
      body: JSON.stringify({ setupCode: 'wrong_code' }),
    });
    assert.equal(attempt1.status, 401);

    // Attempt 2 spoofing a completely different X-Forwarded-For: 10.0.0.2 -> STILL blocked (429) on same socket IP!
    const attempt2 = await fetch(`${baseUrl}/api/agent/auth/owner/reset-limit`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
        'X-Forwarded-For': '10.0.0.2',
        'x-agent-pairing-code': AgentAuthManager.generatePairingCode(),
      },
      body: JSON.stringify({ setupCode: 'wrong_code' }),
    });
    assert.equal(attempt2.status, 429);

    AgentAuthManager.clearAllResetLimits();
    const validRes = await fetch(`${baseUrl}/api/agent/auth/owner/reset-limit`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ setupCode }),
    });
    assert.equal(validRes.status, 200);
  } finally {
    AgentAuthManager.clearAllResetLimits();
    await new Promise<void>((resolve) => server.close(() => resolve()));
  }
});

test('7b. Attacker IP lockout does NOT lock out owner IP; distributed flood triggers global counter (429)', () => {
  AgentAuthManager.clearAllResetLimits();
  const setupCode = AgentAuthManager.getOrCreateSetupCode();
  const attackerIp = '198.51.100.10';
  const ownerIp = '198.51.100.20';

  // Attacker fails on attackerIp -> locked out with 429
  const firstFail = AgentAuthManager.checkAndTrackResetLimit(attackerIp, 'wrong');
  assert.equal(firstFail.status, 401);
  const attackerLocked = AgentAuthManager.checkAndTrackResetLimit(attackerIp, 'wrong');
  assert.equal(attackerLocked.status, 429);

  // Separate owner IP is NOT locked out by the attacker's per-IP bucket
  const ownerOk = AgentAuthManager.checkAndTrackResetLimit(ownerIp, setupCode);
  assert.equal(ownerOk.allowed, true);
  assert.equal(ownerOk.status, 200);

  // Global counter stops distributed attacks across 20 distinct IPs
  AgentAuthManager.clearAllResetLimits();
  for (let i = 1; i <= 20; i++) {
    const r = AgentAuthManager.checkAndTrackResetLimit(`203.0.113.${i}`, 'bad_code');
    assert.equal(r.allowed, false);
  }
  const globalBlocked = AgentAuthManager.checkAndTrackResetLimit('203.0.113.250', setupCode);
  assert.equal(globalBlocked.allowed, false);
  assert.equal(globalBlocked.status, 429);
  AgentAuthManager.clearAllResetLimits();
});

test('8. Token file permissions enforce 0o600 on file and 0o700 on directory', () => {
  AgentAuthManager.getOrCreateToken();
  const secureDir = fs.existsSync('/root') ? '/root/.zoya' : path.join(process.cwd(), 'data', '.secure');
  const tokenFile = path.join(secureDir, 'agent_auth_token.json');
  if (fs.existsSync(tokenFile)) {
    const dirMode = fs.statSync(secureDir).mode & 0o777;
    const fileMode = fs.statSync(tokenFile).mode & 0o777;
    assert.equal(dirMode, 0o700);
    assert.equal(fileMode, 0o600);
  }
});

test('9. secretMasker redacts OpenAI, Anthropic, GitHub, sk_* and xi-api-key without touching MD5/UUIDs', () => {
  const md5 = 'd41d8cd98f00b204e9800998ecf8427e';
  const uuid = '550e8400-e29b-41d4-a716-446655440000';
  const sample = [
    `md5=${md5}`,
    `uuid=${uuid}`,
    `openai=sk-projAbCdEfGhIjKlMnOpQrStUvWxYz1234`,
    `anthropic=sk-ant-api03-AbCdEfGhIjKlMnOpQrStUvWxYz`,
    `github=ghp_1234567890abcdefghijklmnopqrstuvwxyzABCD`,
    `eleven1=sk_0123456789abcdef0123456789abcdef`,
    `xi-api-key: fedcba9876543210fedcba9876543210`,
  ].join('\n');

  const out = maskSecrets(sample);
  assert.ok(out.includes(md5), 'MD5 hash must NOT be redacted');
  assert.ok(out.includes(uuid), 'UUID must NOT be redacted');
  assert.ok(!out.includes('sk-projAbCdEfGhIjKlMnOpQrStUvWxYz1234'));
  assert.ok(!out.includes('sk-ant-api03-AbCdEfGhIjKlMnOpQrStUvWxYz'));
  assert.ok(!out.includes('ghp_1234567890abcdefghijklmnopqrstuvwxyzABCD'));
  assert.ok(!out.includes('sk_0123456789abcdef0123456789abcdef'));
  assert.ok(!out.includes('fedcba9876543210fedcba9876543210'));
});

test('10. Fail-closed allowlist blocks unknown packages and contains ZERO browser packages', () => {
  assert.equal(isBlockedFinancialPackage('com.whatsapp'), false);
  assert.equal(isBlockedFinancialPackage('com.random.unknown.app'), true);
  assert.equal(isBlockedFinancialPackage('com.phonepe.app'), true);
  assert.equal(isBlockedFinancialPackage('in.org.npci.upiapp'), true);

  const browserPackages = [
    'com.android.chrome',
    'org.mozilla.firefox',
    'com.opera.browser',
    'com.brave.browser',
    'com.microsoft.emmx',
    'com.sec.android.app.sbrowser',
  ];
  for (const b of browserPackages) {
    assert.equal(ALLOWED_AUTOMATION_PACKAGES.includes(b), false, `TS allowlist must not include browser ${b}`);
    assert.equal(isBlockedFinancialPackage(b), true, `Browser package ${b} must be blocked`);
  }

  const ktPath = path.join(
    process.cwd(),
    'android/app/src/main/java/com/openclaw/assistant/bridge/accessibility/BankingSafetyConfig.kt'
  );
  const ktContent = fs.readFileSync(ktPath, 'utf8');
  assert.ok(ktContent.includes('ALLOWED_AUTOMATION_PACKAGES'));
  assert.ok(!ktContent.includes('.*cred.*'));
  assert.ok(!ktContent.includes('.*upi.*'));
  for (const b of browserPackages) {
    assert.ok(!ktContent.includes(b), `Kotlin allowlist must not include browser ${b}`);
  }
});

test('11. serverYouTubeService handles 403 and 429 cleanly without parsing HTML/error as success', async () => {
  const origFetch = globalThis.fetch;
  try {
    globalThis.fetch = (async () =>
      new Response(JSON.stringify({ error: { message: 'Quota exceeded' } }), {
        status: 429,
        headers: { 'Content-Type': 'application/json' },
      })) as typeof fetch;
    const res429 = await validateApiKey('AIzaDummyTestKey1234567890');
    assert.equal(res429.valid, false);
    assert.ok(res429.error?.includes('429') || res429.error?.toLowerCase().includes('rate'));

    globalThis.fetch = (async () =>
      new Response(JSON.stringify({ error: { message: 'Forbidden' } }), {
        status: 403,
        headers: { 'Content-Type': 'application/json' },
      })) as typeof fetch;
    const res403 = await validateApiKey('AIzaDummyTestKey1234567890');
    assert.equal(res403.valid, false);
    assert.ok(res403.error?.includes('403'));
  } finally {
    globalThis.fetch = origFetch;
  }
});

test('12. All 5 TTS & ElevenLabs routes reject unauthenticated requests (401) and enforce 30/min rate limit (429)', async () => {
  const token = AgentAuthManager.getOrCreateToken();
  const { server, baseUrl } = await startServer(buildTestApp());
  try {
    const endpoints: Array<{ method: string; path: string }> = [
      { method: 'POST', path: '/api/elevenlabs/config' },
      { method: 'POST', path: '/api/tts' },
      { method: 'POST', path: '/api/tts/preview' },
      { method: 'GET', path: '/api/tts/diagnostics' },
      { method: 'POST', path: '/api/elevenlabs/test-connection' },
    ];

    for (const ep of endpoints) {
      const r = await fetch(`${baseUrl}${ep.path}`, { method: ep.method });
      assert.equal(r.status, 401, `${ep.method} ${ep.path} must return 401 without auth`);
    }

    // Authenticated requests pass up to 30 req/min even across spoofed X-Forwarded-For headers, then 31st returns 429
    const pairedSession = AgentAuthManager.createPairedSession();
    for (let i = 1; i <= 30; i++) {
      const okRes = await fetch(`${baseUrl}/api/tts/diagnostics`, {
        headers: {
          Authorization: `Bearer ${token}`,
          'x-agent-paired-session': pairedSession,
          'X-Forwarded-For': `198.51.100.${i}`,
        },
      });
      assert.equal(okRes.status, 200, `Authenticated request #${i} should succeed`);
    }
    const limitedRes = await fetch(`${baseUrl}/api/tts/diagnostics`, {
      headers: {
        Authorization: `Bearer ${token}`,
        'x-agent-paired-session': pairedSession,
        'X-Forwarded-For': '198.51.100.250',
      },
    });
    assert.equal(limitedRes.status, 429);
    assert.ok(limitedRes.headers.get('retry-after'));
  } finally {
    await new Promise<void>((resolve) => server.close(() => resolve()));
  }
});

test('13. Pairing-code consume & issue endpoints enforce socket-IP rate limit (429)', async () => {
  AgentAuthManager.clearPairingRateLimits();
  const { server, baseUrl } = await startServer(buildTestApp());
  try {
    // Consume endpoint: 10 attempts allowed per socket IP (ignoring XFF), 11th returns 429
    for (let i = 1; i <= 10; i++) {
      const r = await fetch(`${baseUrl}/api/agent/auth/token`, {
        headers: {
          'X-Forwarded-For': `10.10.0.${i}`,
          'x-agent-pairing-code': 'invalid_code',
        },
      });
      assert.equal(r.status, 403);
    }
    const consumeBlocked = await fetch(`${baseUrl}/api/agent/auth/token`, {
      headers: { 'X-Forwarded-For': '10.10.0.99' },
    });
    assert.equal(consumeBlocked.status, 429);

    // Issue endpoint: 10 attempts allowed per socket IP, 11th returns 429
    for (let i = 1; i <= 10; i++) {
      const r = await fetch(`${baseUrl}/api/agent/auth/pairing-code`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-Forwarded-For': `10.20.0.${i}` },
        body: JSON.stringify({}),
      });
      assert.equal(r.status, 401);
    }
    const issueBlocked = await fetch(`${baseUrl}/api/agent/auth/pairing-code`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Forwarded-For': '10.20.0.99' },
      body: JSON.stringify({}),
    });
    assert.equal(issueBlocked.status, 429);
  } finally {
    AgentAuthManager.clearPairingRateLimits();
    await new Promise<void>((resolve) => server.close(() => resolve()));
  }
});

test('14. Browser owner proxy flow: pairing bootstrap mints pairedSession allowing /api/agent/status through X-Forwarded-For', async () => {
  AgentAuthManager.clearPairingRateLimits();
  const pairingCode = AgentAuthManager.generatePairingCode();
  const { server, baseUrl } = await startServer(buildTestApp());
  try {
    // 1. Exchange single-use pairing code over X-Forwarded-For proxy
    const bootstrapRes = await fetch(`${baseUrl}/api/agent/auth/token`, {
      headers: {
        'X-Forwarded-For': '203.0.113.55',
        'x-agent-pairing-code': pairingCode,
      },
    });
    assert.equal(bootstrapRes.status, 200);
    const setCookie = bootstrapRes.headers.get('set-cookie') || '';
    assert.ok(setCookie.includes('zoya_agent_paired_session='), 'Must set HttpOnly paired session cookie');
    const bootstrapData = (await bootstrapRes.json()) as { token: string; pairedSession: string };
    assert.ok(bootstrapData.token);
    assert.ok(bootstrapData.pairedSession);

    // 2. Bearer-only without paired session over X-Forwarded-For is STILL rejected (403)
    const tokenOnlyRes = await fetch(`${baseUrl}/api/agent/status`, {
      headers: {
        Authorization: `Bearer ${bootstrapData.token}`,
        'X-Forwarded-For': '203.0.113.55',
      },
    });
    assert.equal(tokenOnlyRes.status, 403);

    // 3. Bearer + pairedSession header (or cookie) over X-Forwarded-For succeeds (200)
    const proxiedOwnerRes = await fetch(`${baseUrl}/api/agent/status`, {
      headers: {
        Authorization: `Bearer ${bootstrapData.token}`,
        'x-agent-paired-session': bootstrapData.pairedSession,
        'X-Forwarded-For': '203.0.113.55',
      },
    });
    assert.equal(proxiedOwnerRes.status, 200);
  } finally {
    AgentAuthManager.clearPairingRateLimits();
    await new Promise<void>((resolve) => server.close(() => resolve()));
  }
});

test('15. Migration purges legacy zoya_elevenlabs_api_key from localStorage on startup and blocks reading it', () => {
  const store = new Map<string, string>([['zoya_elevenlabs_api_key', 'sk_legacy_secret_value']]);
  const origLocalStorage = (globalThis as any).localStorage;
  try {
    (globalThis as any).localStorage = {
      getItem: (k: string) => (store.has(k) ? store.get(k)! : null),
      setItem: (k: string, v: string) => store.set(k, v),
      removeItem: (k: string) => store.delete(k),
    };
    purgeDeprecatedClientSecrets();
    initializeSecretVault();
    assert.equal(store.has('zoya_elevenlabs_api_key'), false, 'zoya_elevenlabs_api_key must be deleted on startup');
    assert.equal(getDecryptedSecretSync('zoya_elevenlabs_api_key'), '', 'Must never read zoya_elevenlabs_api_key');
  } finally {
    if (origLocalStorage === undefined) {
      delete (globalThis as any).localStorage;
    } else {
      (globalThis as any).localStorage = origLocalStorage;
    }
  }
});
