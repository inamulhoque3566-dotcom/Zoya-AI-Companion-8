/**
 * Verification Script: Strict 3-Engine TTS System Diagnostic Inventory & Pipeline Verification
 * 1. PRIMARY: ElevenLabs TTS (eleven_turbo_v2_5)
 * 2. BACKUP: Google Gemini Flash TTS (gemini-3.8-flash-lite-tts)
 * 3. FALLBACK: Google Gemini Live API (gemini-3.8-live)
 */
import { buildTtsInventory, TtsServerAuditData } from '../src/services/ttsDiagnosticService';

console.log('=== [TTS_STRICT_3_ENGINE_DIAGNOSTIC_VERIFICATION_START] ===');

// Mock server audit telemetry
const mockServerAudit: TtsServerAuditData = {
  status: 'ok',
  timestamp: new Date().toISOString(),
  totalMainEngines: 3,
  engines: [
    {
      id: 'elevenlabs',
      name: 'ElevenLabs TTS',
      model: 'eleven_turbo_v2_5',
      provider: 'ElevenLabs',
      role: 'PRIMARY',
      configured: false,
      voiceId: '21m00Tcm4TlvDq8ikWAM',
      voiceName: 'Rachel (Natural Female)',
    },
    {
      id: 'gemini-flash',
      name: 'Google Gemini Flash TTS',
      model: 'gemini-3.8-flash-lite-tts',
      provider: 'Google Gemini',
      role: 'BACKUP',
      configured: true,
      voiceName: 'Kore (24kHz HD WAV)',
    },
    {
      id: 'gemini-live',
      name: 'Google Gemini Live API',
      model: 'gemini-3.8-live',
      provider: 'Google Gemini',
      role: 'FALLBACK',
      configured: true,
      voiceName: 'Kore (Bidirectional Audio)',
    },
  ],
  env: {
    hasElevenLabsKey: false, // Default mode: Gemini Flash is active backup
    hasGeminiKey: true,
    elevenLabsVoiceId: '21m00Tcm4TlvDq8ikWAM',
    geminiDefaultVoice: 'Kore',
  },
  quota: {
    geminiCooldownActive: false,
    geminiCooldownRemainingSec: 0,
  },
  cache: {
    inMemoryCount: 42,
    inFlightDeduplications: 0,
  },
  policy: {
    roboticSpeechSynthesisBlocked: true,
    androidSystemTtsBlockedInChat: true,
    offlineEmergencyTtsEnabled: true,
  },
};

// 1. Audit Inventory: must have EXACTLY 3 main engines
const inventory = buildTtsInventory(mockServerAudit);

console.log(`Detected total TTS systems: ${inventory.length}`);
if (inventory.length !== 3) {
  console.error(`FAIL: Expected exactly 3 integrated TTS engines, found ${inventory.length}`);
  process.exit(1);
}

// 2. Verify all 3 engines, provider, models, and priority roles
const expectedEngines: Array<{ id: string; provider: string; model: string; role: string }> = [
  { id: 'elevenlabs', provider: 'ElevenLabs', model: 'eleven_turbo_v2_5', role: 'PRIMARY' },
  { id: 'gemini-flash', provider: 'Google Gemini', model: 'gemini-3.8-flash-lite-tts', role: 'BACKUP' },
  { id: 'gemini-live', provider: 'Google Gemini', model: 'gemini-3.8-live', role: 'FALLBACK' },
];

for (const expected of expectedEngines) {
  const found = inventory.find((e) => e.id === expected.id);
  if (!found) {
    console.error(`FAIL: Missing engine in inventory: ${expected.id}`);
    process.exit(1);
  }
  if (found.provider !== expected.provider) {
    console.error(`FAIL: Engine ${expected.id} expected provider ${expected.provider}, got ${found.provider}`);
    process.exit(1);
  }
  if (found.model !== expected.model) {
    console.error(`FAIL: Engine ${expected.id} expected model ${expected.model}, got ${found.model}`);
    process.exit(1);
  }
  if (found.role !== expected.role) {
    console.error(`FAIL: Engine ${expected.id} expected role ${expected.role}, got ${found.role}`);
    process.exit(1);
  }
  console.log(`✓ Engine verified: [${found.id}] ${found.name} | Model: ${found.model} | Role: ${found.role} | Active: ${found.active}`);
}

// 3. Verify roles and active state when ElevenLabs key is present
const mockAuditWithEleven: TtsServerAuditData = {
  ...mockServerAudit,
  env: {
    ...mockServerAudit.env,
    hasElevenLabsKey: true,
  },
};
const inventoryWithEleven = buildTtsInventory(mockAuditWithEleven);
const elevenPrimary = inventoryWithEleven.find((e) => e.id === 'elevenlabs');
const geminiBackup = inventoryWithEleven.find((e) => e.id === 'gemini-flash');
const geminiLiveFallback = inventoryWithEleven.find((e) => e.id === 'gemini-live');

if (!elevenPrimary?.active || elevenPrimary.role !== 'PRIMARY') {
  console.error(`FAIL: Expected elevenlabs to be active PRIMARY when key is present`);
  process.exit(1);
}
if (geminiBackup?.active || geminiBackup.role !== 'BACKUP') {
  console.error(`FAIL: Expected gemini-flash to be standby BACKUP when elevenlabs is active`);
  process.exit(1);
}
if (geminiLiveFallback?.role !== 'FALLBACK') {
  console.error(`FAIL: Expected gemini-live to be FALLBACK`);
  process.exit(1);
}
console.log('✓ Verified: 3-Tier priority strictly maintained (ElevenLabs Primary -> Gemini Flash Backup -> Gemini Live Fallback).');

// 4. Verify security: No plaintext API keys are ever exposed in apiKeyMasked
for (const item of inventory) {
  if (item.apiKeyMasked.includes('sk_') || item.apiKeyMasked.includes('AIza')) {
    console.error(`FAIL: Raw API key leaked in inventory item: ${item.id}`);
    process.exit(1);
  }
}
console.log('✓ Verified: Security check passed. No API keys are leaked in plain text.');

// 5. Verify policy check
if (!mockServerAudit.policy.roboticSpeechSynthesisBlocked || !mockServerAudit.policy.androidSystemTtsBlockedInChat) {
  console.error('FAIL: Robotic fallback policy must be strictly blocked');
  process.exit(1);
}
console.log('✓ Verified: Zero Robotic Voice Policy is strictly active & enforced.');

console.log('=== [ALL TTS STRICT 3-ENGINE TESTS PASSED SUCCESSFULLY] ===');
