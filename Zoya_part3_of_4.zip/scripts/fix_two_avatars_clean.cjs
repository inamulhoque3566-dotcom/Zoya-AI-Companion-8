const sharp = require('sharp');
const fs = require('fs');

async function fixAvatarA() {
  console.log('Fixing Avatar A (Pastel Blue Knit & Pink Shorts)...');

  // Load pristine source: public/assets/aistudio/file_00000000eb7881fa8a888c25bfc4c0f7_32dd4f88.png
  const { data, info } = await sharp('public/assets/aistudio/file_00000000eb7881fa8a888c25bfc4c0f7_32dd4f88.png')
    .raw()
    .toBuffer({ resolveWithObject: true });

  const w = info.width;
  const h = info.height;
  const out = Buffer.from(data);

  let cleanedFragments = 0;
  let cleanedSliver = 0;
  let cleanedGroundShadow = 0;

  // 1. Remove black vertical sliver and leftover fragments between the legs
  // Between legs coordinates: y from 1350 to 1540, x from 450 to 510
  for (let y = 1350; y <= 1540; y++) {
    for (let x = 455; x <= 515; x++) {
      const idx = (y * w + x) * 4;
      const a = out[idx + 3];
      if (a > 0) {
        const r = out[idx], g = out[idx + 1], b = out[idx + 2];
        // The background sliver is black/dark grey (r,g,b < 65) or isolated fringe between the legs
        // Avatar's legs are skin tones (r > 190, g > 140, b > 140) and pink sneakers/socks
        const isLegSkinOrSneaker = (r > 175 && g > 125 && b > 125);
        if (!isLegSkinOrSneaker) {
          out[idx + 3] = 0;
          cleanedSliver++;
        }
      }
    }
  }

  // 2. Remove floating fragments / leftover background outside the legs below shorts (y > 940)
  // Left side of left leg (x < 370) and right side of right leg (x > 620)
  for (let y = 940; y < h; y++) {
    for (let x = 0; x < w; x++) {
      if (x < 370 || x > 620) {
        const idx = (y * w + x) * 4;
        if (out[idx + 3] > 0) {
          out[idx + 3] = 0;
          cleanedFragments++;
        }
      }
    }
  }

  // Also clean the isolated sliver area between y=945..975 outside x=375
  for (let y = 945; y <= 980; y++) {
    for (let x = 340; x <= 375; x++) {
      const idx = (y * w + x) * 4;
      if (out[idx + 3] > 0) {
        out[idx + 3] = 0;
        cleanedFragments++;
      }
    }
  }

  // 3. Remove ground shadow below shoes (y > 1660) and faint ground contact fringes (alpha < 60 near very bottom)
  for (let y = 1650; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const idx = (y * w + x) * 4;
      const a = out[idx + 3];
      if (a > 0) {
        const r = out[idx], g = out[idx + 1], b = out[idx + 2];
        // If below soles or faint floor shadow
        if (y >= 1662 || (y >= 1658 && a < 120 && r < 180)) {
          out[idx + 3] = 0;
          cleanedGroundShadow++;
        }
      }
    }
  }

  // 4. Eliminate any faint sub-alpha noise (< 10) in the entire image
  for (let i = 0; i < out.length; i += 4) {
    if (out[i + 3] < 12) {
      out[i + 3] = 0;
    }
  }

  console.log(`Avatar A cleaned: sliverPixels=${cleanedSliver}, fragments=${cleanedFragments}, groundShadow=${cleanedGroundShadow}`);

  // Save to transparent path
  const transPath = 'public/assets/images/avatars_3d/transparent/avatar_pastel_blue_knit_shorts.png';
  const pngBuffer = await sharp(out, { raw: { width: w, height: h, channels: 4 } })
    .png({ compressionLevel: 8 })
    .toBuffer();

  fs.writeFileSync(transPath, pngBuffer);
  console.log(`Saved transparent PNG: ${transPath}`);

  // Update modular layer body_skin.png
  const modularPath = 'public/assets/images/avatars_modular/avatar_pastel_blue_knit_shorts/body_skin.png';
  if (fs.existsSync('public/assets/images/avatars_modular/avatar_pastel_blue_knit_shorts')) {
    fs.writeFileSync(modularPath, pngBuffer);
    console.log(`Saved modular fallback: ${modularPath}`);
  }

  // Generate card preview JPG on subtle dark gradient background
  const cardBgSvg = `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}">
    <defs>
      <radialGradient id="cardBg" cx="50%" cy="40%" r="65%">
        <stop offset="0%" stop-color="#1e1b4b"/>
        <stop offset="60%" stop-color="#0f172a"/>
        <stop offset="100%" stop-color="#020617"/>
      </radialGradient>
    </defs>
    <rect width="${w}" height="${h}" fill="url(#cardBg)"/>
  </svg>`;
  const cardBgBuf = Buffer.from(cardBgSvg);
  const cardJpgPath = 'public/assets/images/avatars_3d/avatar_pastel_blue_knit_shorts.jpg';
  await sharp(cardBgBuf)
    .resize(w, h)
    .composite([{ input: pngBuffer, top: 0, left: 0 }])
    .jpeg({ quality: 92 })
    .toFile(cardJpgPath);
  console.log(`Saved card JPG preview: ${cardJpgPath}`);
}

async function fixAvatarB() {
  console.log('\nFixing Avatar B (Midnight Black & Gold Zari Saree)...');

  // Load pristine source: public/assets/aistudio/file_00000000c0d4821189e14bf178224f8d_f1687d5b.png
  const { data, info } = await sharp('public/assets/aistudio/file_00000000c0d4821189e14bf178224f8d_f1687d5b.png')
    .raw()
    .toBuffer({ resolveWithObject: true });

  const w = info.width;
  const h = info.height;
  const out = Buffer.from(data);

  // Eliminate faint stray alpha noise (< 10) while preserving sheer fabric (alpha 20..220)
  let cleanedNoise = 0;
  for (let i = 0; i < out.length; i += 4) {
    if (out[i + 3] < 12) {
      out[i + 3] = 0;
      cleanedNoise++;
    }
  }

  console.log(`Avatar B cleaned stray alpha noise: ${cleanedNoise}`);

  const transPath = 'public/assets/images/avatars_3d/transparent/avatar_midnight_gold_zari_saree.png';
  const pngBuffer = await sharp(out, { raw: { width: w, height: h, channels: 4 } })
    .png({ compressionLevel: 8 })
    .toBuffer();

  fs.writeFileSync(transPath, pngBuffer);
  console.log(`Saved transparent PNG: ${transPath}`);

  // Update modular layer body_skin.png
  const modularPath = 'public/assets/images/avatars_modular/avatar_midnight_gold_zari_saree/body_skin.png';
  if (fs.existsSync('public/assets/images/avatars_modular/avatar_midnight_gold_zari_saree')) {
    fs.writeFileSync(modularPath, pngBuffer);
    console.log(`Saved modular fallback: ${modularPath}`);
  }

  // Generate card preview JPG on subtle dark gradient background
  const cardBgSvg = `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}">
    <defs>
      <radialGradient id="cardBg" cx="50%" cy="40%" r="65%">
        <stop offset="0%" stop-color="#1e1b4b"/>
        <stop offset="60%" stop-color="#0f172a"/>
        <stop offset="100%" stop-color="#020617"/>
      </radialGradient>
    </defs>
    <rect width="${w}" height="${h}" fill="url(#cardBg)"/>
  </svg>`;
  const cardBgBuf = Buffer.from(cardBgSvg);
  const cardJpgPath = 'public/assets/images/avatars_3d/avatar_midnight_gold_zari_saree.jpg';
  await sharp(cardBgBuf)
    .resize(w, h)
    .composite([{ input: pngBuffer, top: 0, left: 0 }])
    .jpeg({ quality: 92 })
    .toFile(cardJpgPath);
  console.log(`Saved card JPG preview: ${cardJpgPath}`);
}

async function main() {
  await fixAvatarA();
  await fixAvatarB();
}

main().catch(console.error);
