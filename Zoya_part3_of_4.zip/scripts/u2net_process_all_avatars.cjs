const fs = require('fs');
const path = require('path');
const sharp = require('sharp');
const { removeBackground } = require('@imgly/background-removal-node');

// All 20 avatars with their highest quality uncorrupted source files
const AVATARS_CONFIG = [
  {
    id: 'boho_mini_dress',
    name: 'Boho Floral Mini Dress',
    src: 'pristine_sources/avatar_boho_mini_dress.jpg',
    transparentPath: 'public/assets/images/avatars_3d/transparent/avatar_boho_mini_dress.png',
    previewPath: 'public/assets/images/avatars_3d/avatar_boho_mini_dress.jpg',
    modularPath: 'public/assets/images/avatars_modular/boho_mini_dress/body_skin.png',
  },
  {
    id: 'peasant_blouse_skirt',
    name: 'Peasant Blouse & Lavender Skirt',
    src: 'pristine_sources/avatar_peasant_blouse_skirt.jpg',
    transparentPath: 'public/assets/images/avatars_3d/transparent/avatar_peasant_blouse_skirt.png',
    previewPath: 'public/assets/images/avatars_3d/avatar_peasant_blouse_skirt.jpg',
    modularPath: 'public/assets/images/avatars_modular/peasant_blouse_skirt/body_skin.png',
  },
  {
    id: 'pink_knit_maxi',
    name: 'Pink Rib Knit & White Maxi',
    src: 'pristine_sources/avatar_pink_knit_maxi.jpg',
    transparentPath: 'public/assets/images/avatars_3d/transparent/avatar_pink_knit_maxi.png',
    previewPath: 'public/assets/images/avatars_3d/avatar_pink_knit_maxi.jpg',
    modularPath: 'public/assets/images/avatars_modular/pink_knit_maxi/body_skin.png',
  },
  {
    id: 'floral_palazzo_pants',
    name: 'Floral Palazzo Pants Ensemble',
    src: 'pristine_sources/avatar_floral_palazzo_pants.jpg',
    transparentPath: 'public/assets/images/avatars_3d/transparent/avatar_floral_palazzo_pants.png',
    previewPath: 'public/assets/images/avatars_3d/avatar_floral_palazzo_pants.jpg',
    modularPath: 'public/assets/images/avatars_modular/floral_palazzo_pants/body_skin.png',
  },
  {
    id: 'red_cardigan_floral',
    name: 'Red Cardigan & Floral Skirt',
    src: 'pristine_sources/avatar_red_cardigan_floral.jpg',
    transparentPath: 'public/assets/images/avatars_3d/transparent/avatar_red_cardigan_floral.png',
    previewPath: 'public/assets/images/avatars_3d/avatar_red_cardigan_floral.jpg',
    modularPath: 'public/assets/images/avatars_modular/red_cardigan_floral/body_skin.png',
  },
  {
    id: 'plum_royal_anarkali',
    name: 'Royal Plum Zari Anarkali',
    src: 'pristine_sources/avatar_plum_royal_anarkali.jpg',
    transparentPath: 'public/assets/images/avatars_3d/transparent/avatar_plum_royal_anarkali.png',
    previewPath: 'public/assets/images/avatars_3d/avatar_plum_royal_anarkali.jpg',
    modularPath: 'public/assets/images/avatars_modular/plum_royal_anarkali/body_skin.png',
  },
  {
    id: 'ivory_floral_anarkali',
    name: 'Ivory & Rose Floral Anarkali',
    src: 'pristine_sources/avatar_ivory_floral_anarkali.jpg',
    transparentPath: 'public/assets/images/avatars_3d/transparent/avatar_ivory_floral_anarkali.png',
    previewPath: 'public/assets/images/avatars_3d/avatar_ivory_floral_anarkali.jpg',
    modularPath: 'public/assets/images/avatars_modular/ivory_floral_anarkali/body_skin.png',
  },
  {
    id: 'classic',
    name: 'Classic Sweater & Glasses (Zoya)',
    src: 'pristine_sources/zoya_3d_sweater_glasses.jpg',
    transparentPath: 'public/assets/images/zoya_new_avatar_transparent.png',
    altTransparentPath: 'public/assets/images/avatars_3d/transparent/anime_princess_3d.png',
    previewPath: 'public/assets/images/zoya_master_render.jpg',
    modularPath: 'public/assets/images/avatars_modular/classic/body_skin.png',
  },
  {
    id: 'elegant_saree',
    name: 'Traditional Elegant Saree',
    src: 'pristine_sources/elegant_saree_avatar.jpg',
    transparentPath: 'public/assets/images/elegant_saree_avatar_transparent.png',
    altTransparentPath: 'public/assets/images/avatars_3d/transparent/elegant_saree.png',
    previewPath: 'public/assets/images/elegant_saree_avatar.jpg',
    modularPath: 'public/assets/images/avatars_modular/elegant_saree/body_skin.png',
  },
  {
    id: 'avatar_urban_crop_hoodie',
    name: 'Urban Crop Hoodie & Cargo Joggers',
    src: 'public/assets/aistudio/file_00000000d12881f68a210961f707e2f7_2252122d.png',
    transparentPath: 'public/assets/images/avatars_3d/transparent/avatar_urban_crop_hoodie.png',
    previewPath: 'public/assets/images/avatars_3d/avatar_urban_crop_hoodie.jpg',
    modularPath: 'public/assets/images/avatars_modular/avatar_urban_crop_hoodie/body_skin.png',
  },
  {
    id: 'avatar_white_ruffle_babydoll',
    name: 'White Satin Ruffle Babydoll',
    src: 'public/assets/aistudio/file_00000000714082118158b0be2e90f7cf_7fe119d0.png',
    transparentPath: 'public/assets/images/avatars_3d/transparent/avatar_white_ruffle_babydoll.png',
    previewPath: 'public/assets/images/avatars_3d/avatar_white_ruffle_babydoll.jpg',
    modularPath: 'public/assets/images/avatars_modular/avatar_white_ruffle_babydoll/body_skin.png',
  },
  {
    id: 'avatar_pink_athleisure_track',
    name: 'Pink Athleisure Tracksuit',
    src: 'pristine_sources/avatar_pink_athleisure_track.jpg',
    transparentPath: 'public/assets/images/avatars_3d/transparent/avatar_pink_athleisure_track.png',
    previewPath: 'public/assets/images/avatars_3d/avatar_pink_athleisure_track.jpg',
    modularPath: 'public/assets/images/avatars_modular/avatar_pink_athleisure_track/body_skin.png',
  },
  {
    id: 'avatar_scarlet_peasant_cargo',
    name: 'Scarlet Peasant Blouse & Olive Skirt',
    src: 'public/assets/aistudio/file_0000000091d48207b6f9f29a32014cf0_bd82fc9f.png',
    transparentPath: 'public/assets/images/avatars_3d/transparent/avatar_scarlet_peasant_cargo.png',
    previewPath: 'public/assets/images/avatars_3d/avatar_scarlet_peasant_cargo.jpg',
    modularPath: 'public/assets/images/avatars_modular/avatar_scarlet_peasant_cargo/body_skin.png',
  },
  {
    id: 'avatar_pastel_blue_knit_shorts',
    name: 'Pastel Blue Knit & Pink Shorts',
    src: 'public/assets/aistudio/file_00000000eb7881fa8a888c25bfc4c0f7_32dd4f88.png',
    transparentPath: 'public/assets/images/avatars_3d/transparent/avatar_pastel_blue_knit_shorts.png',
    previewPath: 'public/assets/images/avatars_3d/avatar_pastel_blue_knit_shorts.jpg',
    modularPath: 'public/assets/images/avatars_modular/avatar_pastel_blue_knit_shorts/body_skin.png',
  },
  {
    id: 'avatar_violet_ruffle_cocktail',
    name: 'Violet Off-Shoulder Frill Dress',
    src: 'pristine_sources/avatar_violet_ruffle_cocktail.jpg',
    transparentPath: 'public/assets/images/avatars_3d/transparent/avatar_violet_ruffle_cocktail.png',
    previewPath: 'public/assets/images/avatars_3d/avatar_violet_ruffle_cocktail.jpg',
    modularPath: 'public/assets/images/avatars_modular/avatar_violet_ruffle_cocktail/body_skin.png',
  },
  {
    id: 'avatar_slate_blue_regal_kurta',
    name: 'Slate Blue Regal Kurta & Cape',
    src: 'public/assets/aistudio/file_000000009b6081f589589ca050473a44_1a702475.png',
    transparentPath: 'public/assets/images/avatars_3d/transparent/avatar_slate_blue_regal_kurta.png',
    previewPath: 'public/assets/images/avatars_3d/avatar_slate_blue_regal_kurta.jpg',
    modularPath: 'public/assets/images/avatars_modular/avatar_slate_blue_regal_kurta/body_skin.png',
  },
  {
    id: 'avatar_midnight_gold_zari_saree',
    name: 'Midnight Black & Gold Zari Saree',
    src: 'public/assets/aistudio/file_00000000c0d4821189e14bf178224f8d_f1687d5b.png',
    transparentPath: 'public/assets/images/avatars_3d/transparent/avatar_midnight_gold_zari_saree.png',
    previewPath: 'public/assets/images/avatars_3d/avatar_midnight_gold_zari_saree.jpg',
    modularPath: 'public/assets/images/avatars_modular/avatar_midnight_gold_zari_saree/body_skin.png',
  },
  {
    id: 'avatar_black_lace_mermaid_saree',
    name: 'Black Embroidered Mermaid Saree',
    src: 'pristine_sources/avatar_black_lace_mermaid_saree.jpg',
    transparentPath: 'public/assets/images/avatars_3d/transparent/avatar_black_lace_mermaid_saree.png',
    previewPath: 'public/assets/images/avatars_3d/avatar_black_lace_mermaid_saree.jpg',
    modularPath: 'public/assets/images/avatars_modular/avatar_black_lace_mermaid_saree/body_skin.png',
  },
  {
    id: 'avatar_nautical_denim_shorts',
    name: 'Silk Blouse & Nautical Denim Shorts',
    src: 'public/assets/aistudio/file_000000009d4482078f1192d031bddc07_a2c80c89.png',
    transparentPath: 'public/assets/images/avatars_3d/transparent/avatar_nautical_denim_shorts.png',
    previewPath: 'public/assets/images/avatars_3d/avatar_nautical_denim_shorts.jpg',
    modularPath: 'public/assets/images/avatars_modular/avatar_nautical_denim_shorts/body_skin.png',
  },
  {
    id: 'avatar_parisian_beret_skater',
    name: 'Parisian Beret & Pleated Skirt',
    src: 'pristine_sources/avatar_parisian_beret_skater.jpg',
    transparentPath: 'public/assets/images/avatars_3d/transparent/avatar_parisian_beret_skater.png',
    previewPath: 'public/assets/images/avatars_3d/avatar_parisian_beret_skater.jpg',
    modularPath: 'public/assets/images/avatars_modular/avatar_parisian_beret_skater/body_skin.png',
  }
];

fs.mkdirSync('public/assets/images/verification_magenta', { recursive: true });

async function processAll() {
  const auditResults = [];
  console.log(`Starting U2-Net processing of all ${AVATARS_CONFIG.length} avatars...`);

  for (let idx = 0; idx < AVATARS_CONFIG.length; idx++) {
    const avatar = AVATARS_CONFIG[idx];
    const t0 = Date.now();
    console.log(`[${idx + 1}/${AVATARS_CONFIG.length}] Segmenting ${avatar.name} (${avatar.id}) from ${avatar.src}...`);

    // 1. Read source
    const inputBuffer = fs.readFileSync(avatar.src);
    const mimeType = avatar.src.endsWith('.png') ? 'image/png' : 'image/jpeg';
    const blob = new Blob([inputBuffer], { type: mimeType });

    // 2. Run U2-Net AI background removal
    const resultBlob = await removeBackground(blob);
    const rawRmbgBuffer = Buffer.from(await resultBlob.arrayBuffer());

    // 3. Post-process alpha for pristine edge clarity
    const img = sharp(rawRmbgBuffer);
    const meta = await img.metadata();
    const rawPixels = await img.raw().toBuffer();

    for (let i = 3; i < rawPixels.length; i += 4) {
      const a = rawPixels[i];
      if (a >= 240) {
        rawPixels[i] = 255;
      } else if (a <= 8) {
        rawPixels[i] = 0;
      } else {
        rawPixels[i] = Math.round(((a - 8) / (240 - 8)) * 255);
      }
    }

    const cleanPngBuffer = await sharp(rawPixels, {
      raw: { width: meta.width, height: meta.height, channels: 4 }
    }).png({ compressionLevel: 8 }).toBuffer();

    // 4. Save transparent PNG to destination(s)
    fs.mkdirSync(path.dirname(avatar.transparentPath), { recursive: true });
    fs.writeFileSync(avatar.transparentPath, cleanPngBuffer);
    if (avatar.altTransparentPath) {
      fs.mkdirSync(path.dirname(avatar.altTransparentPath), { recursive: true });
      fs.writeFileSync(avatar.altTransparentPath, cleanPngBuffer);
    }

    // 5. Save to modular body_skin layer
    if (avatar.modularPath) {
      fs.mkdirSync(path.dirname(avatar.modularPath), { recursive: true });
      fs.writeFileSync(avatar.modularPath, cleanPngBuffer);
    }

    // 6. Generate Verification Magenta Composite (#FF00FF)
    const magentaBg = await sharp({
      create: {
        width: meta.width,
        height: meta.height,
        channels: 4,
        background: { r: 255, g: 0, b: 255, alpha: 1 }
      }
    }).png().toBuffer();

    const magentaComposite = await sharp(magentaBg)
      .composite([{ input: cleanPngBuffer, blend: 'over' }])
      .png()
      .toBuffer();

    const magentaProofPath = `public/assets/images/verification_magenta/${avatar.id}_magenta.png`;
    fs.writeFileSync(magentaProofPath, magentaComposite);

    // 7. Update Preview thumbnail for Settings card
    const previewBg = await sharp({
      create: {
        width: meta.width,
        height: meta.height,
        channels: 3,
        background: { r: 10, g: 15, b: 30 }
      }
    }).jpeg({ quality: 90 }).toBuffer();

    const previewComposite = await sharp(previewBg)
      .composite([{ input: cleanPngBuffer, blend: 'over' }])
      .jpeg({ quality: 92 })
      .toBuffer();

    fs.mkdirSync(path.dirname(avatar.previewPath), { recursive: true });
    fs.writeFileSync(avatar.previewPath, previewComposite);

    // 8. Compute audit statistics
    let alpha0 = 0, alphaMid = 0, alpha255 = 0;
    for (let i = 3; i < rawPixels.length; i += 4) {
      const a = rawPixels[i];
      if (a === 0) alpha0++;
      else if (a === 255) alpha255++;
      else alphaMid++;
    }

    // Corner alphas
    const cTL = rawPixels[3];
    const cTR = rawPixels[(meta.width - 1) * 4 + 3];
    const cBL = rawPixels[((meta.height - 1) * meta.width) * 4 + 3];
    const cBR = rawPixels[((meta.height - 1) * meta.width + meta.width - 1) * 4 + 3];

    // Find bounding box of visible content
    let minY = meta.height, maxY = 0, minX = meta.width, maxX = 0;
    for (let y = 0; y < meta.height; y++) {
      for (let x = 0; x < meta.width; x++) {
        if (rawPixels[(y * meta.width + x) * 4 + 3] > 0) {
          if (y < minY) minY = y;
          if (y > maxY) maxY = y;
          if (x < minX) minX = x;
          if (x > maxX) maxX = x;
        }
      }
    }

    const elapsed = Date.now() - t0;
    console.log(`✓ Completed ${avatar.id} in ${elapsed}ms: ${meta.width}x${meta.height}, a0=${alpha0}, aMid=${alphaMid}, a255=${alpha255}`);

    auditResults.push({
      id: avatar.id,
      name: avatar.name,
      file: avatar.transparentPath,
      dimensions: `${meta.width}x${meta.height}`,
      alpha0,
      alphaMid,
      alpha255,
      corners: [cTL, cTR, cBL, cBR],
      visibleBbox: { minX, maxX, minY, maxY },
      feetY: maxY,
      magentaProof: magentaProofPath,
      elapsedMs: elapsed
    });
  }

  fs.writeFileSync('scripts/u2net_audit_results.json', JSON.stringify(auditResults, null, 2));
  console.log('ALL 20 AVATARS PROCESSED AND VERIFIED SUCCESSFULLY!');
}

processAll().catch(err => {
  console.error('Processing error:', err);
  process.exit(1);
});
