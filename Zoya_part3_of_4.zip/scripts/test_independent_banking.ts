import {
  isPackageBlocked,
  isBrowserPackage,
  isBrowserHostBlocked,
  evaluateDeviceActionSafety,
} from '../src/services/bankingSafetyConfig.js';

interface TestCase {
  name: string;
  category: 'BANKING/FINTECH' | 'HARMLESS' | 'BROWSER_FINANCIAL' | 'BROWSER_SAFE';
  packageName: string;
  browserUrl?: string | null;
  expectedBlocked: boolean;
  notes: string;
}

// 1. Independent list of >= 60 Real Banking, UPI, Broker, and Crypto packages
const BANKING_APPS: Array<{ pkg: string; name: string }> = [
  // UPI & Wallets
  { pkg: 'com.phonepe.app', name: 'PhonePe' },
  { pkg: 'com.google.android.apps.nbu.paisa.user', name: 'Google Pay' },
  { pkg: 'net.one97.paytm', name: 'Paytm' },
  { pkg: 'in.org.npci.upiapp', name: 'BHIM UPI' },
  { pkg: 'com.dreamplug.androidapp', name: 'CRED (Official Play Store)' },
  { pkg: 'com.cred.android', name: 'CRED (Legacy)' },
  { pkg: 'com.mobikwik_new', name: 'MobiKwik' },
  { pkg: 'com.freecharge.android', name: 'Freecharge' },
  { pkg: 'com.naviapp', name: 'Navi UPI & Loans' },
  { pkg: 'money.jupiter', name: 'Jupiter Money' },
  { pkg: 'com.fi.money', name: 'Fi Money' },
  { pkg: 'org.openlake.slice', name: 'Slice' },
  { pkg: 'com.postpe.app', name: 'PostPe' },
  { pkg: 'com.bharatpe.app', name: 'BharatPe Merchant' },
  { pkg: 'org.altruist.BajajExperia', name: 'Bajaj Finserv' },
  { pkg: 'com.indiabulls.consumer', name: 'Dhani' },
  { pkg: 'com.tatadigital.tcp', name: 'Tata Neu UPI' },
  { pkg: 'com.airtel.thanks', name: 'Airtel Payments Bank' },
  { pkg: 'com.jio.myjio', name: 'Jio Payments' },
  { pkg: 'com.finobank.bpay', name: 'Fino BPay' },
  { pkg: 'com.ippb.mobilebanking', name: 'India Post Payments Bank' },
  { pkg: 'com.paywithring', name: 'Ring Pay' },
  { pkg: 'com.lazypay.android', name: 'LazyPay' },
  { pkg: 'com.simpl.android', name: 'Simpl' },
  { pkg: 'money.freo.save', name: 'Freo Save' },
  { pkg: 'com.uni.cards', name: 'Uni Cards' },

  // Stock Brokers & Investment Apps
  { pkg: 'com.zerodha.kite3', name: 'Zerodha Kite' },
  { pkg: 'com.nextbillion.groww', name: 'Groww Stocks & Mutual Funds' },
  { pkg: 'in.upstox.app', name: 'Upstox Pro' },
  { pkg: 'com.msf.angelmobile', name: 'Angel One' },
  { pkg: 'com.fivepaisa.trade', name: '5paisa Trading' },
  { pkg: 'com.dhan.live', name: 'Dhan Stock Trading' },
  { pkg: 'in.indmoney', name: 'INDmoney' },
  { pkg: 'com.etmoney.android', name: 'ET Money' },
  { pkg: 'com.scripbox.app', name: 'Scripbox Wealth' },
  { pkg: 'com.myjar.app', name: 'Jar Digital Gold' },
  { pkg: 'com.gullak.app', name: 'Gullak Savings' },
  { pkg: 'com.motilalofficial', name: 'Motilal Oswal' },
  { pkg: 'com.sharekhan', name: 'Sharekhan' },
  { pkg: 'com.hdfcsec.investright', name: 'HDFC Sky / Securities' },
  { pkg: 'com.icicisecurities', name: 'ICICI Direct' },

  // Indian Bank Mobile Banking
  { pkg: 'com.sbi.lotusintouch', name: 'YONO SBI' },
  { pkg: 'com.sbi.upi', name: 'BHIM SBI Pay' },
  { pkg: 'com.sbi.SBIFreedomPlus', name: 'State Bank Anywhere' },
  { pkg: 'com.snapwork.hdfc', name: 'HDFC Bank MobileBanking' },
  { pkg: 'com.hdfcbank.payzapp', name: 'HDFC PayZapp' },
  { pkg: 'com.csam.icici.bank.imobile', name: 'ICICI iMobile Pay' },
  { pkg: 'com.icicibank.pockets', name: 'ICICI Pockets' },
  { pkg: 'com.axis.mobile', name: 'Axis Mobile' },
  { pkg: 'com.axis.open', name: 'Axis Open' },
  { pkg: 'com.msf.kbank.mobile', name: 'Kotak Mobile Banking' },
  { pkg: 'com.kotak.cherry', name: 'Kotak Cherry' },
  { pkg: 'com.pnb.pnbone', name: 'PNB ONE' },
  { pkg: 'com.bankofbaroda.mconnect', name: 'bob World' },
  { pkg: 'com.canarabank.mobility', name: 'Canara ai1' },
  { pkg: 'com.unionbank.ecommerce.mobile.android', name: 'Union Bank Vyom' },
  { pkg: 'com.indusind.mpassbook', name: 'IndusMobile' },
  { pkg: 'com.idfcfirstbank.optimus', name: 'IDFC FIRST Bank' },
  { pkg: 'com.yesbank', name: 'YES Mobile' },
  { pkg: 'com.boi.bankofindia', name: 'BOI Mobile' },
  { pkg: 'com.infrasofttech.centmobile', name: 'Central Bank Cent Mobile' },
  { pkg: 'com.federalbank.fedmobile', name: 'FedMobile' },
  { pkg: 'com.rblbank.mobank', name: 'RBL MoBank' },
  { pkg: 'com.sc.scmobile.in', name: 'Standard Chartered India' },
  { pkg: 'com.hsbc.in.hsbcpersonalbanking', name: 'HSBC India' },

  // Global Banking & Crypto
  { pkg: 'com.paypal.android.p2pmobile', name: 'PayPal' },
  { pkg: 'com.squareup.cash', name: 'Cash App' },
  { pkg: 'com.venmo', name: 'Venmo' },
  { pkg: 'com.chase.sig.android', name: 'Chase Mobile' },
  { pkg: 'com.revolut.revolut', name: 'Revolut' },
  { pkg: 'com.transferwise.android', name: 'Wise' },
  { pkg: 'com.monzo.android', name: 'Monzo' },
  { pkg: 'com.binance.dev', name: 'Binance' },
  { pkg: 'com.coinbase.android', name: 'Coinbase' },
  { pkg: 'co.coinodc.cx', name: 'CoinDCX' },
  { pkg: 'com.wazirx.android', name: 'WazirX' },
  { pkg: 'com.mudrex.app', name: 'Mudrex' },
  { pkg: 'com.kucoin.android', name: 'KuCoin' },
  { pkg: 'com.kraken.invest.app', name: 'Kraken' },
  { pkg: 'com.bitbns', name: 'Bitbns' },
];

// 2. Independent list of >= 40 Harmless Apps (including false-positive traps)
const HARMLESS_APPS: Array<{ pkg: string; name: string; trap?: string }> = [
  { pkg: 'com.spotify.music', name: 'Spotify Music' },
  { pkg: 'com.whatsapp', name: 'WhatsApp Messenger' },
  { pkg: 'com.instagram.android', name: 'Instagram' },
  { pkg: 'com.google.android.youtube', name: 'YouTube' },
  { pkg: 'com.google.android.apps.maps', name: 'Google Maps' },
  { pkg: 'com.google.android.gm', name: 'Gmail' },
  { pkg: 'com.google.android.deskclock', name: 'Clock' },
  { pkg: 'com.google.android.calculator', name: 'Calculator' },
  { pkg: 'com.google.android.GoogleCamera', name: 'Google Camera' },
  { pkg: 'com.slack', name: 'Slack' },
  { pkg: 'com.github.android', name: 'GitHub Mobile' },
  { pkg: 'org.telegram.messenger', name: 'Telegram' },
  { pkg: 'com.discord', name: 'Discord' },
  { pkg: 'com.reddit.frontpage', name: 'Reddit' },
  { pkg: 'com.netflix.mediaclient', name: 'Netflix' },
  { pkg: 'com.amazon.mShop.android.shopping', name: 'Amazon Shopping' },
  { pkg: 'com.flipkart.android', name: 'Flipkart' },
  { pkg: 'com.microsoft.teams', name: 'Microsoft Teams' },
  { pkg: 'com.zoom.videomeetings', name: 'Zoom Meetings' },
  { pkg: 'com.duolingo', name: 'Duolingo' },
  { pkg: 'com.valvesoftware.android.steam.community', name: 'Steam' },
  { pkg: 'com.supercell.clashofclans', name: 'Clash of Clans' },
  { pkg: 'com.rovio.baba', name: 'Angry Birds' },
  { pkg: 'com.weather.Weather', name: 'The Weather Channel' },
  { pkg: 'com.strava', name: 'Strava GPS Fitness' },
  { pkg: 'com.audible.application', name: 'Audible Audiobooks' },
  { pkg: 'com.pinterest', name: 'Pinterest' },
  { pkg: 'com.linkedin.android', name: 'LinkedIn' },
  { pkg: 'com.ubercab', name: 'Uber' },
  { pkg: 'com.olacabs.customer', name: 'Ola Cabs' },
  { pkg: 'com.zomato', name: 'Zomato Food' },
  { pkg: 'in.swiggy.android', name: 'Swiggy Food' },

  // Deliberate False-Positive Trap Apps (contain substrings like 'pay', 'bank', 'cash', 'money')
  { pkg: 'com.google.android.apps.wallpaper', name: 'Google Wallpapers', trap: 'Contains "paper" (not pay)' },
  { pkg: 'com.payless.shoesource', name: 'Payless Shoes', trap: 'Contains "pay" prefix' },
  { pkg: 'com.gameloft.android.ANMP.GloftPAYW', name: 'Gameloft Asphalt PAYW', trap: 'Contains "PAYW"' },
  { pkg: 'com.banker.puzzle.game', name: 'River Banker Puzzle Game', trap: 'Game named Banker' },
  { pkg: 'com.cashword.puzzle', name: 'Crossword Cashword Game', trap: 'Crossword puzzle' },
  { pkg: 'com.moneymanager.expense', name: 'Budget Note / Expense Tracker', trap: 'Offline budget note tracker' },
  { pkg: 'com.applepay.news', name: 'Apple Tech News Feed', trap: 'Informational news feed' },
  { pkg: 'com.payback.de', name: 'Payback Loyalty Points', trap: 'Loyalty coupon aggregator' },
  { pkg: 'com.adobe.reader', name: 'Adobe Acrobat Reader', trap: 'Document viewer' },
  { pkg: 'com.dropbox.android', name: 'Dropbox Cloud Storage', trap: 'Cloud file sync' },
  { pkg: 'com.vlc.android', name: 'VLC Media Player', trap: 'Open-source media player' },
  { pkg: 'org.wikipedia', name: 'Wikipedia Reader', trap: 'Encyclopedia reader' },
  { pkg: 'com.notion.id', name: 'Notion Workspace', trap: 'Productivity notes' },
];

// 3. Browser & Chrome Custom Tabs Scenarios
const BROWSER_TEST_CASES: Array<{
  browserPkg: string;
  url: string | null;
  expectBlocked: boolean;
  scenario: string;
}> = [
  // Chrome
  { browserPkg: 'com.android.chrome', url: 'https://retail.onlinesbi.sbi/retail/login.htm', expectBlocked: true, scenario: 'Chrome -> SBI Netbanking' },
  { browserPkg: 'com.android.chrome', url: 'https://netbanking.hdfcbank.com/netbanking/', expectBlocked: true, scenario: 'Chrome -> HDFC Netbanking' },
  { browserPkg: 'com.android.chrome', url: 'https://checkout.razorpay.com/v1/checkout.js', expectBlocked: true, scenario: 'Chrome -> Razorpay Gateway' },
  { browserPkg: 'com.android.chrome', url: 'https://wikipedia.org/wiki/India', expectBlocked: false, scenario: 'Chrome -> Wikipedia (Safe)' },
  { browserPkg: 'com.android.chrome', url: 'https://news.ycombinator.com', expectBlocked: false, scenario: 'Chrome -> Hacker News (Safe)' },
  { browserPkg: 'com.android.chrome', url: '', expectBlocked: true, scenario: 'Chrome -> Address bar hidden/empty (Fail-closed)' },
  { browserPkg: 'com.android.chrome', url: null, expectBlocked: true, scenario: 'Chrome -> Null URL (Fail-closed)' },

  // Samsung Internet
  { browserPkg: 'com.sec.android.app.sbrowser', url: 'https://infinity.icicibank.com', expectBlocked: true, scenario: 'Samsung Internet -> ICICI Netbanking' },
  { browserPkg: 'com.sec.android.app.sbrowser', url: 'https://github.com/trending', expectBlocked: false, scenario: 'Samsung Internet -> GitHub (Safe)' },

  // Brave Browser
  { browserPkg: 'com.brave.browser', url: 'https://omni.axisbank.co.in/axisaxis/', expectBlocked: true, scenario: 'Brave -> Axis Omni Netbanking' },
  { browserPkg: 'com.brave.browser', url: 'https://stackoverflow.com/questions/1234', expectBlocked: false, scenario: 'Brave -> StackOverflow (Safe)' },

  // Opera Browser
  { browserPkg: 'com.opera.browser', url: 'https://netbanking.kotak.com', expectBlocked: true, scenario: 'Opera -> Kotak Netbanking' },
  { browserPkg: 'com.opera.browser', url: 'https://medium.com/@tech/article', expectBlocked: false, scenario: 'Opera -> Medium (Safe)' },

  // DuckDuckGo Privacy Browser
  { browserPkg: 'com.duckduckgo.mobile.android', url: 'https://checkout.stripe.com/c/pay/cs_live_123', expectBlocked: true, scenario: 'DuckDuckGo -> Stripe Checkout' },
  { browserPkg: 'com.duckduckgo.mobile.android', url: 'https://duckduckgo.com/?q=weather', expectBlocked: false, scenario: 'DuckDuckGo -> Search Result (Safe)' },

  // Chrome Custom Tabs (invoked by third-party app with Chrome engine)
  { browserPkg: 'com.android.chrome', url: 'https://pgi.billdesk.com/pgidsk/pgmerc/payment.jsp', expectBlocked: true, scenario: 'Chrome Custom Tab -> Billdesk Gateway' },
  { browserPkg: 'com.android.chrome', url: 'https://payu.in/gateway/pay', expectBlocked: true, scenario: 'Chrome Custom Tab -> PayU Gateway' },
  { browserPkg: 'org.chromium.chrome', url: 'https://bobibanking.com', expectBlocked: true, scenario: 'Chromium CCT -> Bank of Baroda' },
  { browserPkg: 'org.chromium.chrome', url: 'https://developer.android.com/guide', expectBlocked: false, scenario: 'Chromium CCT -> Android Docs (Safe)' },
];

async function runIndependentBankingTests() {
  console.log('================================================================');
  console.log('ZOYA INDEPENDENT BANKING & BROKER SAFETY TEST SUITE (ROUND 4)');
  console.log('================================================================');

  let passedCount = 0;
  let failedCount = 0;
  const failureList: string[] = [];

  // Group 1: 60+ Banking, UPI, & Broker Apps
  console.log(`\n--- GROUP 1: TESTING ${BANKING_APPS.length} REAL FINANCIAL APPS (EXPECTED: BLOCKED) ---`);
  for (const app of BANKING_APPS) {
    const isBlocked = isPackageBlocked(app.pkg);
    const evalResult = evaluateDeviceActionSafety(app.pkg, null);
    const success = isBlocked && !evalResult.isSafe;

    if (success) {
      passedCount++;
      // console.log(`[PASS] ${app.name} (${app.pkg}) -> BLOCKED`);
    } else {
      failedCount++;
      const err = `[FAIL] Financial app allowed! ${app.name} (${app.pkg}): isBlocked=${isBlocked}, isSafe=${evalResult.isSafe}`;
      console.error(err);
      failureList.push(err);
    }
  }
  console.log(`Group 1 result: ${passedCount} / ${BANKING_APPS.length} passed.`);

  // Group 2: 40+ Harmless Apps & Traps
  const group2Start = passedCount;
  console.log(`\n--- GROUP 2: TESTING ${HARMLESS_APPS.length} HARMLESS APPS & TRAPS (EXPECTED: ALLOWED) ---`);
  for (const app of HARMLESS_APPS) {
    const isBlocked = isPackageBlocked(app.pkg);
    const evalResult = evaluateDeviceActionSafety(app.pkg, null);
    const success = !isBlocked && evalResult.isSafe;

    if (success) {
      passedCount++;
    } else {
      failedCount++;
      const err = `[FAIL] Harmless app incorrectly blocked! ${app.name} (${app.pkg}): isBlocked=${isBlocked}, reason=${evalResult.reason}`;
      console.error(err);
      failureList.push(err);
    }
  }
  console.log(`Group 2 result: ${passedCount - group2Start} / ${HARMLESS_APPS.length} passed.`);

  // Group 3: Browser & Chrome Custom Tabs Scenarios
  const group3Start = passedCount;
  console.log(`\n--- GROUP 3: TESTING ${BROWSER_TEST_CASES.length} BROWSER & CCT SCENARIOS ---`);
  for (const tc of BROWSER_TEST_CASES) {
    const evalResult = evaluateDeviceActionSafety(tc.browserPkg, tc.url, {
      failClosedIfUnknownBrowserUrl: true,
    });
    const isBlocked = !evalResult.isSafe;
    const success = isBlocked === tc.expectBlocked;

    if (success) {
      passedCount++;
      console.log(`[PASS] ${tc.scenario} -> ${isBlocked ? 'BLOCKED' : 'ALLOWED'}`);
    } else {
      failedCount++;
      const err = `[FAIL] Browser scenario failed: ${tc.scenario}. Expected blocked=${tc.expectBlocked}, got blocked=${isBlocked} (${evalResult.reason})`;
      console.error(err);
      failureList.push(err);
    }
  }
  console.log(`Group 3 result: ${passedCount - group3Start} / ${BROWSER_TEST_CASES.length} passed.`);

  const totalTests = BANKING_APPS.length + HARMLESS_APPS.length + BROWSER_TEST_CASES.length;
  console.log('\n================================================================');
  console.log(`SUMMARY: ${passedCount} / ${totalTests} PASSED (Failures: ${failedCount})`);
  console.log('================================================================\n');

  if (failedCount > 0) {
    process.exit(1);
  }
}

runIndependentBankingTests().catch((err) => {
  console.error('Test suite crashed:', err);
  process.exit(1);
});
