const sharp = require('sharp');
const fs = require('fs');

async function fixAvatarB() {
  console.log('=== FIXING AVATAR B (MIDNIGHT GOLD ZARI SAREE) ===');

  // Load pristine source
  const srcImg = sharp('public/assets/aistudio/file_00000000c0d4821189e14bf178224f8d_f1687d5b.png');
  const { data, info } = await srcImg.raw().toBuffer({ resolveWithObject: true });
  const w = info.width;
  const h = info.height;

  const out = Buffer.from(data);

  // 1. Clean border fringe and background noise (alpha <= 12)
  let noiseCleaned = 0;
  for (let i = 0; i < out.length; i += 4) {
    if (out[i + 3] <= 12) {
      out[i + 3] = 0;
      noiseCleaned++;
    }
  }
  console.log(`Cleaned faint noise alpha <= 12: ${noiseCleaned} pixels`);

  // 2. Clean outer edge border line on row 1535 and borders (x=0, x=w-1, y=0, y=h-1)
  for (let x = 0; x < w; x++) {
    out[x * 4 + 3] = 0; // Top edge
    out[((h - 1) * w + x) * 4 + 3] = 0; // Bottom row 1535
  }
  for (let y = 0; y < h; y++) {
    out[(y * w) * 4 + 3] = 0; // Left column 0
    out[(y * w + w - 1) * 4 + 3] = 0; // Right column w-1
  }

  // 3. Clean navy halos around hair fringe (y: 80..420)
  let hairHalosCleaned = 0;
  for (let y = 80; y < 420; y++) {
    for (let x = 180; x < 840; x++) {
      const idx = (y * w + x) * 4;
      const a = out[idx + 3];
      if (a > 0 && a < 180) {
        const r = out[idx], g = out[idx+1], b = out[idx+2];
        // If bluish background tint (b > r + 15 and b > 25)
        if (b > r + 15 && b > 25) {
          out[idx + 3] = 0;
          hairHalosCleaned++;
        }
      }
    }
  }
  console.log(`Cleaned hair navy halos: ${hairHalosCleaned} pixels`);

  // 4. Smooth & preserve sheer fabric: keep all sheer veil and saree folds intact
  // The saree hem naturally rests on the floor at y ~ 1520..1530.
  // We keep the authentic hem and gold embroidery completely preserved, ensuring no jagged gaps or erosion!

  // 5. Save perfected transparent PNG
  const outPngPath = 'public/assets/images/avatars_3d/transparent/avatar_midnight_gold_zari_saree.png';
  const outPngBuf = await sharp(out, { raw: { width: w, height: h, channels: 4 } })
    .png({ compressionLevel: 8 })
    .toBuffer();

  fs.writeFileSync(outPngPath, outPngBuf);
  console.log(`✓ Saved ${outPngPath}`);

  // Sync to modular fallback
  const modularPath = 'public/assets/images/avatars_modular/avatar_midnight_gold_zari_saree/body_skin.png';
  fs.writeFileSync(modularPath, outPngBuf);
  console.log(`✓ Synced ${modularPath}`);

  // Update preview JPG card
  const cardBgSvg = `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}">
    <defs>
      <radialGradient id="cardBg" cx="50%" cy="40%" r="65%">
        <stop offset="0%" stop-color="#1e1b4b"/>
        <stop offset="60%" stop-color="#0f172a"/>
        <stop offset="100%" stop-color="#020617"/>
      </radialGradient>
    </defs>
    <rect width="${w}" height="${h}" fill="url(#cardBg)"/>
  </svg>`;
  const cardBgBuf = Buffer.from(cardBgSvg);
  const jpgPath = 'public/assets/images/avatars_3d/avatar_midnight_gold_zari_saree.jpg';
  await sharp(cardBgBuf)
    .resize(w, h)
    .composite([{ input: outPngBuf, top: 0, left: 0 }])
    .jpeg({ quality: 92 })
    .toFile(jpgPath);
  console.log(`✓ Updated card preview: ${jpgPath}`);

  // 6. Generate Verification Magenta Composite and Zooms
  const magenta = await sharp({
    create: { width: w, height: h, channels: 4, background: { r: 255, g: 0, b: 255, alpha: 1 } }
  }).png().toBuffer();

  const fullMagenta = await sharp(magenta)
    .composite([{ input: outPngBuf }])
    .png()
    .toBuffer();

  fs.writeFileSync('proof_artifacts/avatar_b_fixed_full_magenta.png', fullMagenta);

  // Zoom 1: Bottom hem edge on bright magenta
  await sharp(fullMagenta)
    .extract({ left: 160, top: 1330, width: 700, height: 200 })
    .toFile('proof_artifacts/avatar_b_fixed_hem_zoom_magenta.png');

  // Zoom 2: Hands and waist
  await sharp(fullMagenta)
    .extract({ left: 280, top: 500, width: 480, height: 420 })
    .toFile('proof_artifacts/avatar_b_fixed_hands_zoom_magenta.png');

  // Zoom 3: Sheer Pallu drape
  await sharp(fullMagenta)
    .extract({ left: 580, top: 400, width: 420, height: 600 })
    .toFile('proof_artifacts/avatar_b_fixed_pallu_zoom_magenta.png');

  console.log('✓ Proof artifacts created for Avatar B');
}

fixAvatarB().catch(console.error);
