const sharp = require('sharp');

async function findDifferences() {
  const src = await sharp('public/assets/aistudio/file_00000000eb7881fa8a888c25bfc4c0f7_32dd4f88.png')
    .raw()
    .toBuffer({ resolveWithObject: true });

  const cur = await sharp('public/assets/images/avatars_3d/transparent/avatar_pastel_blue_knit_shorts.png')
    .raw()
    .toBuffer({ resolveWithObject: true });

  const w = src.info.width;
  const h = src.info.height;

  let addedPixels = 0;
  let removedPixels = 0;

  console.log('--- Analyzing differences between pristine source and current transparent PNG ---');
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const idx = (y * w + x) * 4;
      const aSrc = src.data[idx + 3];
      const aCur = cur.data[idx + 3];

      if (aSrc === 0 && aCur > 0) {
        addedPixels++;
        if (addedPixels <= 20) {
          console.log(`Pixel was transparent in source, but active in cur: (${x}, ${y}) rgba=(${cur.data[idx]},${cur.data[idx+1]},${cur.data[idx+2]},${aCur})`);
        }
      } else if (aSrc > 20 && aCur === 0) {
        removedPixels++;
      }
    }
  }

  console.log(`Summary for Avatar A: addedPixels=${addedPixels}, removedPixels=${removedPixels}`);
}

findDifferences().catch(console.error);
