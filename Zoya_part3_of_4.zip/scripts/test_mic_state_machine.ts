/**
 * Comprehensive Unit Test Suite for MicStateMachine & Audio Single-Recorder Invariant
 *
 * Verifies:
 * 1. Debouncing: Rapid user taps (<400ms) are safely ignored (no flicker / duplicate recorders).
 * 2. STANDBY vs CAPTURING:
 *    - In STANDBY mode, speech recognition is HALTED; only wake-word is active.
 *    - In CAPTURING mode, speech recognition is ACTIVE; wake-word is strictly paused.
 * 3. Silence Handling: Recognizer ending on silence does NOT crash to OFF; smoothly returns to STANDBY.
 * 4. 8-second Silence Timeout: Automatically reverts to STANDBY without user intervention.
 * 5. Single-Recorder Mutex: Native wake word and speech recognizer are NEVER active simultaneously.
 * 6. TTS Speaking Coordination:
 *    - During TTS (SPEAKING), all mic recording is blocked (no audio feedback/echo).
 *    - When TTS finishes, 500ms post-reverb decay is waited before returning to STANDBY.
 *    - 25s watchdog protects against stuck audio state.
 * 7. Call Isolation:
 *    - requestPauseForCall transitions to PAUSED_BY_CALL, disarming both wake word and recognizer.
 *    - requestResumeAfterCall safely restores STANDBY.
 * 8. Barge-In: Tapping or triggering wake-word during TTS immediately aborts speech and activates mic.
 */

import { micStateMachine, MicStateSnapshot } from '../src/services/speech/MicStateMachine';

interface MockNativeBridge {
  pauseCalls: number;
  resumeCalls: number;
  isPaused: boolean;
  status: any;
}

function setupMockEnvironment(): {
  mockBridge: MockNativeBridge;
  mockRec: {
    starts: number;
    stops: number;
    isActive: boolean;
  };
} {
  const mockBridge: MockNativeBridge = {
    pauseCalls: 0,
    resumeCalls: 0,
    isPaused: false,
    status: {
      hasAccessKey: true,
      modelExists: true,
      serviceRunning: true,
      isPaused: false,
      debugFallbackEnabled: false,
      hasNotificationPermission: true,
      isBatteryOptimizationIgnored: true,
    },
  };

  (globalThis as any).window = {
    AndroidBridge: {
      pauseWakeWordListening: () => {
        mockBridge.pauseCalls++;
        mockBridge.isPaused = true;
      },
      resumeWakeWordListening: () => {
        mockBridge.resumeCalls++;
        mockBridge.isPaused = false;
      },
      getWakeWordStatusJson: () => JSON.stringify(mockBridge.status),
    },
  };

  const mockRec = {
    starts: 0,
    stops: 0,
    isActive: false,
  };

  micStateMachine.registerSpeechRecognizerAdapter({
    start: async () => {
      mockRec.starts++;
      mockRec.isActive = true;
      return true;
    },
    stop: async () => {
      mockRec.stops++;
      mockRec.isActive = false;
    },
    isActive: () => mockRec.isActive,
  });

  return { mockBridge, mockRec };
}

function delay(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

let passedTests = 0;
let totalTests = 0;

function assert(condition: boolean, testName: string, detail?: string) {
  totalTests++;
  if (!condition) {
    console.error(`❌ FAILED: ${testName} ${detail ? `(${detail})` : ''}`);
    throw new Error(`Test failed: ${testName}`);
  } else {
    passedTests++;
    console.log(`✅ PASSED: ${testName}`);
  }
}

async function runTests() {
  console.log('--- STARTING ZOYA MIC STATE MACHINE TEST SUITE ---');
  const { mockBridge, mockRec } = setupMockEnvironment();

  // 1. Initial State Check
  await micStateMachine.requestStandby('Test initial');
  let snap = micStateMachine.getSnapshot();
  assert(snap.state === 'STANDBY', '1. Initial state is STANDBY');
  assert(!snap.isSpeechRecActive, '1b. Speech recognition is halted in STANDBY');

  // 2. Debouncing Rapid Clicks (<400ms)
  const click1 = await micStateMachine.requestActivate('button_tap');
  const click2 = await micStateMachine.requestActivate('button_tap');
  assert(click1 === true, '2a. First activation accepted');
  assert(click2 === false, '2b. Rapid activation within 400ms debounced');
  assert(micStateMachine.getState() === 'CAPTURING' || micStateMachine.getState() === 'ACTIVATING', '2c. State remains active');

  // 3. Single-Recorder Mutex Invariant
  // When CAPTURING, native wake word MUST be paused and speech rec MUST be active
  assert(mockBridge.isPaused === true, '3a. Wake-word is paused when speech mic is active');
  assert(mockRec.isActive === true, '3b. Speech recognizer adapter is active');
  assert(!(mockBridge.isPaused === false && mockRec.isActive === true), '3c. MUTEX INVARIANT: Both are never active simultaneously');

  // 4. Standby Return from Active State
  await delay(450); // wait past debounce
  await micStateMachine.requestStandby('Utterance done');
  assert(micStateMachine.getState() === 'STANDBY', '4a. State transitions cleanly to STANDBY');
  assert(mockRec.isActive === false, '4b. Speech recognizer is stopped in STANDBY');
  assert(mockBridge.isPaused === false, '4c. Native Porcupine wake word resumed in STANDBY');

  // 5. Speech Recognizer Ending on Silence during CAPTURING
  await delay(450);
  await micStateMachine.requestActivate('button_tap');
  assert(micStateMachine.isCapturing() || micStateMachine.getState() === 'ACTIVATING', '5a. Activated for speech test');
  // Simulate browser speech recognizer session ending abruptly on silence
  micStateMachine.reportUserSpeechFinalized('हेलो जोया');
  assert(micStateMachine.getState() === 'PROCESSING', '5b. Finalized speech switches state to PROCESSING ("Thinking")');

  // 6. TTS Coordination & 500ms Post-Reverb Room Decay
  micStateMachine.reportSpeakStart('test_tts');
  assert(micStateMachine.getState() === 'SPEAKING', '6a. State machine enters SPEAKING on TTS start');
  assert(mockRec.isActive === false, '6b. Speech recognizer is stopped while assistant speaks (no echo)');
  assert(mockBridge.isPaused === true, '6c. Wake word is paused while assistant speaks');

  // Finish TTS
  micStateMachine.reportSpeakEnd('test_tts');
  assert(micStateMachine.getState() === 'SPEAKING', '6d. Still in SPEAKING during 500ms post-reverb room decay window');
  await delay(550); // wait out 500ms reverb decay
  assert(micStateMachine.getState() === 'STANDBY', '6e. Safely returned to STANDBY after post-reverb delay');
  assert(mockBridge.isPaused === false, '6f. Wake-word automatically resumed');

  // 7. Barge-In during TTS
  micStateMachine.reportSpeakStart('test_tts');
  assert(micStateMachine.getState() === 'SPEAKING', '7a. Speaking started');
  await delay(450);
  await micStateMachine.requestActivate('wake_word');
  assert(micStateMachine.getState() === 'CAPTURING' || micStateMachine.getState() === 'ACTIVATING', '7b. Barge-in successfully interrupted TTS and activated mic');

  // Return to standby
  await delay(450);
  await micStateMachine.requestStandby('reset');

  // 8. Phone Call / Voice Call Hardware Isolation
  await micStateMachine.requestPauseForCall('phone');
  assert(micStateMachine.getState() === 'PAUSED_BY_CALL', '8a. State is PAUSED_BY_CALL');
  assert(mockBridge.isPaused === true, '8b. Wake word paused for call');
  assert(mockRec.isActive === false, '8c. Speech rec stopped for call');
  // Attempting to activate during call must be blocked
  const blockedActivate = await micStateMachine.requestActivate('button_tap');
  assert(blockedActivate === false, '8d. Activation strictly blocked while call active');

  // End call
  await micStateMachine.requestResumeAfterCall('phone');
  assert(micStateMachine.getState() === 'STANDBY', '8e. Returning from call safely restores STANDBY');
  assert(mockBridge.isPaused === false, '8f. Wake-word resumed after call ends');

  // 9. 8-second Silence Timeout Watchdog
  await delay(450);
  await micStateMachine.requestActivate('button_tap');
  assert(micStateMachine.getState() === 'CAPTURING' || micStateMachine.getState() === 'ACTIVATING', '9a. Activated for timeout test');
  // Trigger timeout directly to verify transition
  await micStateMachine.triggerSilenceTimeoutForTesting();
  assert(micStateMachine.getState() === 'STANDBY', '9b. Silence timeout automatically returned to STANDBY');
  assert(mockBridge.isPaused === false, '9c. Wake-word safely re-armed on silence timeout');

  console.log(`\n🎉 ALL ${passedTests}/${totalTests} TESTS PASSED SUCCESSFULLY!`);
}

runTests().catch((e) => {
  console.error('Test execution failed:', e);
  process.exit(1);
});
