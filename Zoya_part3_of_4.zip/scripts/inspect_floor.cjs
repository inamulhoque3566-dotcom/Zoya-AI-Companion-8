const sharp = require('sharp');
const path = require('path');

async function inspectShoesFloor() {
  const src = path.join(__dirname, '../src/assets/images/zoya_3d_sweater_glasses_1793764031303.jpg');
  const { data, info } = await sharp(src).removeAlpha().raw().toBuffer({ resolveWithObject: true });
  const W = info.width, H = info.height;

  console.log('--- Under shoes & floor area (y >= 1340) ---');
  for (let y = 1340; y < H; y += 4) {
    let rowMinR = 255, rowMaxR = 0;
    let minX = -1, maxX = -1;
    for (let x = 200; x < 600; x++) {
      const idx = (y * W + x) * 3;
      const r = data[idx], g = data[idx+1], b = data[idx+2];
      if (r < 100) { // dark pixel (shoe or shadow)
        if (minX === -1) minX = x;
        maxX = x;
      }
    }
    console.log(`y=${y}: dark pixels from x=${minX} to ${maxX}`);
  }
}
inspectShoesFloor().catch(console.error);
