const sharp = require('sharp');

async function inspectHairAndHem() {
  const src = await sharp('public/assets/aistudio/file_00000000c0d4821189e14bf178224f8d_f1687d5b.png')
    .raw()
    .toBuffer({ resolveWithObject: true });

  const w = src.info.width;
  const h = src.info.height;

  // Let's check for any bright or grey background halos around dark hair (y: 0..400)
  console.log('--- Checking hair boundary for bright background halos (y < 400) ---');
  let brightHaloCount = 0;
  for (let y = 10; y < 400; y++) {
    for (let x = 150; x < 900; x++) {
      const idx = (y * w + x) * 4;
      const a = src.data[idx + 3];
      if (a > 10 && a < 220) {
        const r = src.data[idx], g = src.data[idx+1], b = src.data[idx+2];
        // If edge pixel is washed out / grey / light background
        if (r > 120 && g > 120 && b > 120 && Math.abs(r - g) < 20 && Math.abs(g - b) < 20) {
          brightHaloCount++;
          if (brightHaloCount <= 10) {
            console.log(`Halo at (${x}, ${y}): rgba=(${r},${g},${b},${a})`);
          }
        }
      }
    }
  }
  console.log('Total bright/grey halo pixels around upper body/hair:', brightHaloCount);

  // Check hem border at bottom (y > 1500)
  console.log('\n--- Checking hem border for bright or disconnected pixels ---');
  let hemOutliers = 0;
  for (let y = 1500; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const idx = (y * w + x) * 4;
      const a = src.data[idx + 3];
      if (a > 10) {
        if (x < 180 || x > 995) {
          hemOutliers++;
        }
      }
    }
  }
  console.log('Hem outliers outside [180..995]:', hemOutliers);
}

inspectHairAndHem().catch(console.error);
