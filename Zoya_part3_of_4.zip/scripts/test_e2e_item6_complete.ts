import path from 'path';
import fs from 'fs';
import JSZip from 'jszip';
import { AgentAuthManager } from '../src/services/agent/agentAuth.ts';

const BASE_URL = 'http://localhost:3000';
const BROWSER_UA = 'Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 Chrome/120.0';
const TEST_PASSPHRASE = 'OwnerSecurePassphrase2026!';

let sessionCookie: string | null = null;

async function req(endpoint: string, options: any = {}) {
  const url = `${BASE_URL}${endpoint}`;
  const headers: Record<string, string> = {
    'User-Agent': BROWSER_UA,
    'Content-Type': 'application/json',
    ...(options.headers || {}),
  };
  if (sessionCookie && !headers['Cookie'] && !headers['cookie']) {
    headers['Cookie'] = sessionCookie;
  }
  const res = await fetch(url, {
    ...options,
    headers,
    body: options.body ? (typeof options.body === 'string' ? options.body : JSON.stringify(options.body)) : undefined,
  });
  const text = await res.text();
  let json: any = null;
  try {
    json = JSON.parse(text);
  } catch {}

  const setCookie = res.headers.get('set-cookie');
  if (setCookie) {
    const match = setCookie.match(/zoya_approval_session=([^;]+)/);
    if (match) {
      sessionCookie = `zoya_approval_session=${match[1]}`;
    }
  }

  return { status: res.status, headers: res.headers, raw: text, data: json };
}

async function runItem6E2E() {
  console.log('========================================================================');
  console.log('🚀 ITEM 6: FULL ENDPOINT E2E (SKILLS LIFECYCLE & OFFICIAL FILESYSTEM MCP)');
  console.log('========================================================================\n');

  // Authenticate owner and get session cookie
  console.log('--- Step 0: Owner Auth & Pairing Token ---');
  const setupCode = AgentAuthManager.getOrCreateSetupCode();
  try {
    AgentAuthManager.setOwnerPassphraseWithSetupCode(TEST_PASSPHRASE, setupCode);
  } catch {}

  await req('/api/agent/auth/owner/login', {
    method: 'POST',
    body: { passphrase: TEST_PASSPHRASE },
  });
  const pairRes = await req('/api/agent/auth/pairing-code', {
    method: 'POST',
    body: { passphrase: TEST_PASSPHRASE },
  });
  const pairingCode = pairRes.data?.pairingCode;
  const tokenRes = await req('/api/agent/auth/token', {
    headers: { 'x-agent-pairing-code': pairingCode },
  });
  const token = tokenRes.data?.token;
  console.log(`Authenticated with Token: ${token?.slice(0, 20)}...`);
  console.log(`Approval Session Cookie: ${sessionCookie}`);

  const authHeaders = {
    Authorization: `Bearer ${token}`,
  };

  // 1. Skill Import - Folder
  console.log('\n--- Step 1: Import Skill via Folder ---');
  const folderSkillPath = path.join(process.cwd(), 'workspace', 'skills_test_fixtures', 'valid_math_skill');
  const folderRes = await req('/api/agent/skills/import/folder', {
    method: 'POST',
    headers: authHeaders,
    body: { folderPath: folderSkillPath },
  });
  console.log(`[POST /api/agent/skills/import/folder] Status: ${folderRes.status}`);
  console.log(`Response: ${folderRes.raw}`);
  const folderQuarantineId = folderRes.data?.quarantineId;

  // 2. Skill Import - Zip
  console.log('\n--- Step 2: Import Skill via Zip ---');
  const zip = new JSZip();
  zip.file('SKILL.md', '---\nname: e2e-math-helper\nversion: 1.0.0\ndescription: Calculates math in isolated python sandbox\n---\n# Math Helper Skill');
  zip.file('calculate.py', 'import sys\nprint("ZOYA_SKILL_RESULT: 42 * 42 = " + str(42 * 42))\n');
  const zipBuf = await zip.generateAsync({ type: 'nodebuffer' });
  const zipRes = await req('/api/agent/skills/import/zip', {
    method: 'POST',
    headers: authHeaders,
    body: { zipBase64: zipBuf.toString('base64') },
  });
  console.log(`[POST /api/agent/skills/import/zip] Status: ${zipRes.status}`);
  console.log(`Response: ${zipRes.raw}`);
  const zipQuarantineId = zipRes.data?.quarantineId;

  // 3. Skill Import - Git
  console.log('\n--- Step 3: Import Skill via Git ---');
  const gitRes = await req('/api/agent/skills/import/git', {
    method: 'POST',
    headers: authHeaders,
    body: {
      repoUrl: 'https://github.com/anthropics/skills',
      subpath: 'skills/algorithmic-art',
    },
  });
  console.log(`[POST /api/agent/skills/import/git] Status: ${gitRes.status}`);
  console.log(`Response: ${gitRes.raw}`);

  // 4. Scan, Install & Enable the Zip skill
  console.log(`\n--- Step 4: Scan Quarantine Skill (${zipQuarantineId}) ---`);
  const scanRes = await req(`/api/agent/skills/scan/${zipQuarantineId}`, {
    headers: authHeaders,
  });
  console.log(`[GET /api/agent/skills/scan/${zipQuarantineId}] Status: ${scanRes.status}`);
  console.log(`Response: ${scanRes.raw}`);

  console.log(`\n--- Step 5: Install Skill from Quarantine (${zipQuarantineId}) ---`);
  const installRes = await req(`/api/agent/skills/install/${zipQuarantineId}`, {
    method: 'POST',
    headers: authHeaders,
  });
  console.log(`[POST /api/agent/skills/install/${zipQuarantineId}] Status: ${installRes.status}`);
  console.log(`Response: ${installRes.raw}`);
  const installedSkillId = installRes.data?.skill?.id || 'e2e-math-helper';

  console.log(`\n--- Step 6: Enable Skill (${installedSkillId}) ---`);
  const enableRes = await req(`/api/agent/skills/${installedSkillId}/enable`, {
    method: 'POST',
    headers: authHeaders,
  });
  console.log(`[POST /api/agent/skills/${installedSkillId}/enable] Status: ${enableRes.status}`);
  console.log(`Response: ${enableRes.raw}`);

  // 5. Run Skill Script with Approval
  console.log(`\n--- Step 7: Run Skill Script (${installedSkillId} / calculate.py) Requiring Approval ---`);
  const runSkillTrigger = await req(`/api/agent/skills/${installedSkillId}/run`, {
    method: 'POST',
    headers: authHeaders,
    body: {
      scriptPath: 'calculate.py',
      args: [],
    },
  });
  console.log(`[POST /api/agent/skills/${installedSkillId}/run] Status: ${runSkillTrigger.status}`);
  console.log(`Response: ${runSkillTrigger.raw}`);
  const skillPendingId = runSkillTrigger.data?.pendingApproval?.id || runSkillTrigger.data?.pendingApprovalId;

  if (skillPendingId) {
    console.log(`Pending approval created: ${skillPendingId}. User approves via session cookie...`);
    const appRes = await req(`/api/agent/approvals/${skillPendingId}/respond`, {
      method: 'POST',
      headers: { Cookie: sessionCookie },
      body: { approve: true },
    });
    console.log(`[POST /api/agent/approvals/${skillPendingId}/respond] Status: ${appRes.status}, Body: ${appRes.raw}`);

    const runApproved = await req(`/api/agent/skills/${installedSkillId}/run`, {
      method: 'POST',
      headers: authHeaders,
      body: {
        scriptPath: 'calculate.py',
        args: [],
        approvalId: skillPendingId,
      },
    });
    console.log(`[POST /api/agent/skills/${installedSkillId}/run (with approvalId)] Status: ${runApproved.status}`);
    console.log(`Execution Output: ${runApproved.raw}`);
  }

  // 6. Connect Official @modelcontextprotocol/server-filesystem through endpoints
  console.log('\n--- Step 8: Register Real @modelcontextprotocol/server-filesystem through Endpoints ---');
  const workspaceRoot = path.join(process.cwd(), 'workspace');
  const serverPath = path.join(process.cwd(), 'node_modules', '@modelcontextprotocol', 'server-filesystem', 'dist', 'index.js');

  const mcpReg = await req('/api/agent/mcp/servers', {
    method: 'POST',
    headers: authHeaders,
    body: {
      name: 'official-filesystem-mcp',
      transport: 'stdio',
      command: process.execPath,
      args: [serverPath, workspaceRoot],
      cwd: workspaceRoot,
      allowNetwork: false,
      approved: true,
    },
  });
  console.log(`[POST /api/agent/mcp/servers] Status: ${mcpReg.status}`);
  console.log(`Response: ${mcpReg.raw}`);
  const fsServerId = mcpReg.data?.server?.id;

  console.log(`\n--- Step 9: Connect MCP Server (${fsServerId}) ---`);
  const mcpConnect = await req(`/api/agent/mcp/servers/${fsServerId}/connect`, {
    method: 'POST',
    headers: authHeaders,
    body: { approved: true },
  });
  console.log(`[POST /api/agent/mcp/servers/${fsServerId}/connect] Status: ${mcpConnect.status}`);
  console.log(`Response: ${mcpConnect.raw}`);

  // 7. Call list_directory through endpoint
  console.log('\n--- Step 10: Call list_directory on Allowed Workspace through Endpoints ---');
  const listDirRes = await req('/api/agent/mcp/tools/call', {
    method: 'POST',
    headers: authHeaders,
    body: {
      serverId: fsServerId,
      toolName: 'list_directory',
      arguments: { path: workspaceRoot },
      approved: true,
    },
  });
  console.log(`[POST /api/agent/mcp/tools/call: list_directory] Status: ${listDirRes.status}`);
  console.log(`Tool Output:\n${listDirRes.raw}`);

  // 8. Call read_file on /etc/passwd through endpoint -> Denied
  console.log('\n--- Step 11: Call read_file on /etc/passwd through Endpoints (Must be Denied) ---');
  const readPasswdRes = await req('/api/agent/mcp/tools/call', {
    method: 'POST',
    headers: authHeaders,
    body: {
      serverId: fsServerId,
      toolName: 'read_file',
      arguments: { path: '/etc/passwd' },
      approved: true,
    },
  });
  console.log(`[POST /api/agent/mcp/tools/call: read_file /etc/passwd] Status: ${readPasswdRes.status}`);
  console.log(`Security Rejection Output:\n${readPasswdRes.raw}`);

  // Cleanup server
  await req(`/api/agent/mcp/servers/${fsServerId}`, {
    method: 'DELETE',
    headers: authHeaders,
  });

  console.log('\n========================================================================');
  console.log('✅ ITEM 6 FULL E2E SUITE COMPLETED SUCCESSFULLY WITH ALL RAW OUTPUTS');
  console.log('========================================================================');
}

runItem6E2E().catch((err) => {
  console.error('Item 6 E2E Failed:', err);
  process.exit(1);
});
