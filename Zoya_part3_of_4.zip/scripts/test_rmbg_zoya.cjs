const ort = require('onnxruntime-node');
const sharp = require('sharp');
const fs = require('fs');
const path = require('path');

async function runRmbgZoya() {
  const modelPath = './node_modules/@xenova/transformers/.cache/briaai/RMBG-1.4/onnx/model_quantized.onnx';
  if (!fs.existsSync(modelPath)) {
    console.error('Model not found at:', modelPath);
    return;
  }
  console.log('Loading RMBG-1.4 session...');
  const session = await ort.InferenceSession.create(modelPath);

  const inputJpg = 'src/assets/images/zoya_3d_sweater_glasses_1793764031303.jpg';
  const meta = await sharp(inputJpg).metadata();
  console.log('Input image dims:', meta.width, meta.height);

  // Resize to 1024x1024 RGB
  const resized = await sharp(inputJpg)
    .resize(1024, 1024, { fit: 'fill' })
    .removeAlpha()
    .raw()
    .toBuffer();

  const floatData = new Float32Array(3 * 1024 * 1024);
  const channelSize = 1024 * 1024;
  for (let i = 0; i < channelSize; i++) {
    const r = resized[i * 3];
    const g = resized[i * 3 + 1];
    const b = resized[i * 3 + 2];
    floatData[i] = (r / 255.0 - 0.5);
    floatData[channelSize + i] = (g / 255.0 - 0.5);
    floatData[2 * channelSize + i] = (b / 255.0 - 0.5);
  }

  const inputTensor = new ort.Tensor('float32', floatData, [1, 3, 1024, 1024]);
  const feeds = {};
  feeds[session.inputNames[0]] = inputTensor;

  console.log('Running inference on Zoya...');
  const results = await session.run(feeds);
  const outputTensor = results[session.outputNames[0]];

  const maskData = outputTensor.data;
  const mask8 = new Uint8Array(1024 * 1024);
  for (let i = 0; i < 1024 * 1024; i++) {
    let val = maskData[i];
    let byteVal = Math.round(Math.min(1, Math.max(0, val)) * 255);
    mask8[i] = byteVal;
  }

  // Resize mask to original dims
  const { data: resizedMask } = await sharp(mask8, {
    raw: { width: 1024, height: 1024, channels: 1 }
  })
    .resize(meta.width, meta.height)
    .raw()
    .toBuffer({ resolveWithObject: true });

  const originalRgb = await sharp(inputJpg).removeAlpha().raw().toBuffer();
  const outRgba = new Uint8Array(meta.width * meta.height * 4);
  const totalPixels = meta.width * meta.height;

  for (let i = 0; i < totalPixels; i++) {
    let a = resizedMask[i];
    // Threshold low noise
    if (a < 15) a = 0;
    outRgba[i * 4] = originalRgb[i * 3];
    outRgba[i * 4 + 1] = originalRgb[i * 3 + 1];
    outRgba[i * 4 + 2] = originalRgb[i * 3 + 2];
    outRgba[i * 4 + 3] = a;
  }

  const outPath = 'public/assets/images/test_rmbg_zoya.png';
  await sharp(outRgba, {
    raw: { width: meta.width, height: meta.height, channels: 4 }
  })
    .png()
    .toFile(outPath);

  console.log('Saved result to:', outPath);

  // Check bottom alpha in RMBG output!
  let bottomAlpha = 0;
  for (let y = meta.height - 50; y < meta.height; y++) {
    for (let x = 0; x < meta.width; x++) {
      if (outRgba[(y * meta.width + x) * 4 + 3] > 10) bottomAlpha++;
    }
  }
  console.log('RMBG bottom 50px alpha count:', bottomAlpha);
}

runRmbgZoya().catch(console.error);
