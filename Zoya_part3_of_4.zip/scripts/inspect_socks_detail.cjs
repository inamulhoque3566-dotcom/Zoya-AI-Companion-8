const sharp = require('sharp');
const path = require('path');

async function inspectSocksDetail() {
  const src = path.join(__dirname, '../src/assets/images/zoya_3d_sweater_glasses_1793764031303.jpg');
  const { data, info } = await sharp(src).removeAlpha().raw().toBuffer({ resolveWithObject: true });
  const W = info.width, H = info.height;

  console.log('--- Sock pixels in detail ---');
  // Check left sock at y=1240, 1260, 1280, 1300, 1320
  for (const y of [1220, 1240, 1260, 1280, 1300, 1315]) {
    let sockPixels = [];
    for (let x = 330; x <= 370; x += 5) {
      const idx = (y * W + x) * 3;
      sockPixels.push(`x=${x}:[${data[idx]},${data[idx+1]},${data[idx+2]}]`);
    }
    console.log(`Left Sock y=${y}: ` + sockPixels.join(' '));
  }
}
inspectSocksDetail().catch(console.error);
