const sharp = require('sharp');

async function inspectAvatarBSaree() {
  const cur = await sharp('public/assets/images/avatars_3d/transparent/avatar_midnight_gold_zari_saree.png')
    .raw()
    .toBuffer({ resolveWithObject: true });
  const src = await sharp('public/assets/aistudio/file_00000000c0d4821189e14bf178224f8d_f1687d5b.png')
    .raw()
    .toBuffer({ resolveWithObject: true });

  const w = cur.info.width;
  const h = cur.info.height;

  // Compare cur vs src across the whole image
  let curAlphaZero_srcNonZero = 0;
  let curAlphaNonZero_srcZero = 0;

  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const idx = (y * w + x) * 4;
      const cA = cur.data[idx + 3];
      const sA = src.data[idx + 3];

      if (cA === 0 && sA > 20) curAlphaZero_srcNonZero++;
      if (cA > 20 && sA === 0) curAlphaNonZero_srcZero++;
    }
  }

  console.log(`Avatar B diff: pixels wiped in cur=${curAlphaZero_srcNonZero}, pixels added in cur=${curAlphaNonZero_srcZero}`);

  // Let's inspect where pixels were wiped in cur!
  // Saree hem / pleats?
  const wipedRegions = {};
  for (let y = 0; y < h; y += 50) {
    let count = 0;
    for (let x = 0; x < w; x++) {
      const idx = (y * w + x) * 4;
      if (cur.data[idx + 3] === 0 && src.data[idx + 3] > 20) count++;
    }
    if (count > 0) {
      wipedRegions[`y=${y}`] = count;
    }
  }
  console.log('Wiped pixel counts by Y coordinate:', wipedRegions);
}

inspectAvatarBSaree().catch(console.error);
