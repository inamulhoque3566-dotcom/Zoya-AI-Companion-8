const sharp = require('sharp');

async function inspectSrcPngDirect() {
  const src = await sharp('public/assets/aistudio/file_00000000c0d4821189e14bf178224f8d_f1687d5b.png')
    .raw()
    .toBuffer({ resolveWithObject: true });

  const w = src.info.width;
  const h = src.info.height;

  // Let's inspect the borders/background of file_00000000c0d4821189e14bf178224f8d_f1687d5b.png
  console.log('file_00000000c0d4821189e14bf178224f8d_f1687d5b.png corner alphas:');
  console.log('Top-left (0,0):', src.data[3]);
  console.log('Top-right (w-1, 0):', src.data[(w - 1) * 4 + 3]);
  console.log('Bottom-left (0, h-1):', src.data[((h - 1) * w) * 4 + 3]);
  console.log('Bottom-right (w-1, h-1):', src.data[((h - 1) * w + w - 1) * 4 + 3]);

  // Is the background in file_00000000c0d4821189e14bf178224f8d_f1687d5b.png completely transparent (alpha=0)?
  let borderNonZero = 0;
  for (let x = 0; x < w; x++) {
    if (src.data[x * 4 + 3] > 0) borderNonZero++;
    if (src.data[((h - 1) * w + x) * 4 + 3] > 0) borderNonZero++;
  }
  for (let y = 0; y < h; y++) {
    if (src.data[(y * w) * 4 + 3] > 0) borderNonZero++;
    if (src.data[(y * w + w - 1) * 4 + 3] > 0) borderNonZero++;
  }
  console.log('Border non-zero pixels in source PNG:', borderNonZero);

  // Check pristine_sources/avatar_midnight_gold_zari_saree.jpg
  // Does it have a white or grey background or what?
  const jpg = await sharp('pristine_sources/avatar_midnight_gold_zari_saree.jpg')
    .raw()
    .toBuffer({ resolveWithObject: true });

  console.log('JPG corner colors:');
  console.log('Top-left:', jpg.data[0], jpg.data[1], jpg.data[2]);
  console.log('Bottom-left:', jpg.data[((h-1)*w)*3], jpg.data[((h-1)*w)*3+1], jpg.data[((h-1)*w)*3+2]);
}

inspectSrcPngDirect().catch(console.error);
