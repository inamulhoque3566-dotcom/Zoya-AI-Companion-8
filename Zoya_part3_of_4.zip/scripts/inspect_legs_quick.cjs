const sharp = require('sharp');

async function inspectAvatarA() {
  const { data, info } = await sharp('public/assets/images/avatars_3d/transparent/avatar_pastel_blue_knit_shorts.png')
    .raw()
    .toBuffer({ resolveWithObject: true });

  const w = info.width;
  const h = info.height;
  console.log('Image dimensions:', w, 'x', h);

  // Scan rows from y=900 to bottom
  for (let y = 900; y < h; y += 40) {
    let minX = -1, maxX = -1, count = 0;
    // Check separate regions: left side (x < 400), center (400..550), right side (x > 550)
    let leftCount = 0, centerCount = 0, rightCount = 0;
    for (let x = 0; x < w; x++) {
      const a = data[(y * w + x) * 4 + 3];
      if (a > 10) {
        if (minX === -1) minX = x;
        maxX = x;
        count++;
        if (x < 420) leftCount++;
        else if (x < 530) centerCount++;
        else rightCount++;
      }
    }
    console.log(`y=${y}: minX=${minX}, maxX=${maxX}, total=${count} | left=${leftCount}, center=${centerCount}, right=${rightCount}`);
  }
}

inspectAvatarA().catch(console.error);
