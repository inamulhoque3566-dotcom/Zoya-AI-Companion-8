const sharp = require('sharp');
const path = require('path');
const fs = require('fs');

async function generateFlawlessZoya() {
  const srcPath = path.join(__dirname, '../src/assets/images/zoya_3d_sweater_glasses_1793764031303.jpg');
  const destPublic = path.join(__dirname, '../public/assets/images/anime_princess_3d_transparent.png');
  const destDist = path.join(__dirname, '../dist/assets/images/anime_princess_3d_transparent.png');

  const { data: origRgb, info } = await sharp(srcPath).removeAlpha().raw().toBuffer({ resolveWithObject: true });
  const W = info.width;
  const H = info.height;
  console.log(`Source dimensions: ${W}x${H}`);

  // 1. Precise background calibration per row from outer margins (x in [0..14] and [W-15..W-1])
  const rowBg = new Array(H);
  for (let y = 0; y < H; y++) {
    let r = 0, g = 0, b = 0, c = 0;
    for (let x = 0; x < 15; x++) {
      const i1 = (y * W + x) * 3;
      const i2 = (y * W + (W - 1 - x)) * 3;
      r += origRgb[i1] + origRgb[i2];
      g += origRgb[i1 + 1] + origRgb[i2 + 1];
      b += origRgb[i1 + 2] + origRgb[i2 + 2];
      c += 2;
    }
    rowBg[y] = [r / c, g / c, b / c];
  }

  // 2. Skirt hem detection: for each column x, find the exact bottom y of the brown skirt
  const skirtHem = new Int32Array(W).fill(0);
  for (let x = 185; x <= 585; x++) {
    for (let y = 1100; y <= 1225; y++) {
      const idx = (y * W + x) * 3;
      const r = origRgb[idx], g = origRgb[idx + 1], b = origRgb[idx + 2];
      // Brown fabric condition:
      const isBrown = (r > 38 && g > 25 && b > 20 && r > g && g >= b - 6 && (r - b) >= 8);
      if (isBrown) {
        skirtHem[x] = y;
      }
    }
  }

  // Filter 1px pinholes in skirt hem
  for (let x = 190; x <= 580; x++) {
    if (skirtHem[x] === 0 && skirtHem[x - 1] > 0 && skirtHem[x + 1] > 0) {
      skirtHem[x] = Math.round((skirtHem[x - 1] + skirtHem[x + 1]) / 2);
    }
  }

  // 3. Exact leg & shoe envelopes
  // Leg bounds per row for y from 1200 down to 1362
  const isInsideLegOrShoe = (x, y) => {
    if (y < 1190 || y > 1361) return false;

    // Left leg / sock / shoe
    let lMin, lMax;
    if (y < 1250) {
      lMin = 325;
      lMax = 373;
    } else if (y < 1320) {
      lMin = 322;
      lMax = 388;
    } else if (y < 1354) {
      lMin = 321;
      lMax = 388;
    } else {
      lMin = 332;
      lMax = 385;
    }

    if (x >= lMin && x <= lMax) {
      // Check if pixel is actual leg/sock/shoe (not shadow)
      const idx = (y * W + x) * 3;
      const r = origRgb[idx], g = origRgb[idx + 1], b = origRgb[idx + 2];
      const [bgR, bgG, bgB] = rowBg[y];
      const dist = Math.sqrt((r - bgR) ** 2 + (g - bgG) ** 2 + (b - bgB) ** 2);
      const isSkin = (r > 120 && g > 90 && b > 80 && (r - g) > 12);
      const isShoe = (r < 95 && g < 95 && b < 95);
      const isSock = (r > 130 && r < 218 && g > 130 && g < 218 && b > 130 && b < 218);
      if (isSkin || isShoe || isSock || dist > 18) {
        return true;
      }
    }

    // Right leg / sock / shoe
    let rMin, rMax;
    if (y < 1250) {
      rMin = 405;
      rMax = 454;
    } else if (y < 1320) {
      rMin = 394;
      rMax = 465;
    } else if (y < 1354) {
      rMin = 394;
      rMax = 465;
    } else {
      rMin = 398;
      rMax = 455;
    }

    if (x >= rMin && x <= rMax) {
      const idx = (y * W + x) * 3;
      const r = origRgb[idx], g = origRgb[idx + 1], b = origRgb[idx + 2];
      const [bgR, bgG, bgB] = rowBg[y];
      const dist = Math.sqrt((r - bgR) ** 2 + (g - bgG) ** 2 + (b - bgB) ** 2);
      const isSkin = (r > 120 && g > 90 && b > 80 && (r - g) > 12);
      const isShoe = (r < 95 && g < 95 && b < 95);
      const isSock = (r > 130 && r < 218 && g > 130 && g < 218 && b > 130 && b < 218);
      if (isSkin || isShoe || isSock || dist > 18) {
        return true;
      }
    }

    return false;
  };

  // 4. Initial foreground mask (0 = bg, 255 = fg)
  const fgMask = new Uint8Array(W * H);

  for (let y = 0; y < H; y++) {
    const [bgR, bgG, bgB] = rowBg[y];
    for (let x = 0; x < W; x++) {
      const idx = y * W + x;
      const idx3 = idx * 3;
      const r = origRgb[idx3], g = origRgb[idx3 + 1], b = origRgb[idx3 + 2];

      // Definite background regions:
      if (y < 28 || y > 1361) {
        fgMask[idx] = 0;
        continue;
      }

      // Lateral margins (hair/sweater/skirt are all within x in [185..585])
      if (x < 180 || x > 590) {
        fgMask[idx] = 0;
        continue;
      }

      // Lower body section: below skirt hem
      if (y >= 1150) {
        const hemY = skirtHem[x];
        const isBelowSkirtHem = (hemY > 0 && y > hemY) || (hemY === 0 && (x < 320 || x > 465));
        if (isBelowSkirtHem) {
          // Below skirt hem: ONLY legs/shoes are foreground!
          if (isInsideLegOrShoe(x, y)) {
            fgMask[idx] = 255;
          } else {
            fgMask[idx] = 0;
          }
          continue;
        }
      }

      // Torso, Sweater, Hair, Skirt:
      // White sweater protection: y in [220, 560], x in [250, 520]
      if (y >= 220 && y <= 560 && x >= 250 && x <= 520) {
        fgMask[idx] = 255;
        continue;
      }

      // Skirt body protection: y in [560, 1150], x in [210, 560]
      if (y >= 560 && y <= 1150 && x >= 210 && x <= 560) {
        fgMask[idx] = 255;
        continue;
      }

      // Head & Hair: y in [28, 220], x in [260, 510]
      if (y >= 28 && y <= 220 && x >= 265 && x <= 505) {
        fgMask[idx] = 255;
        continue;
      }

      // Near outer silhouette (hair strands, sweater sleeves, skirt edge)
      const dist = Math.sqrt((r - bgR) ** 2 + (g - bgG) ** 2 + (b - bgB) ** 2);
      const chroma = Math.max(Math.abs(r - g), Math.abs(r - b), Math.abs(g - b));

      // Studio backdrop is neutral grey (|r-g| + |g-b| <= 6, dist < 32)
      if (dist < 26 && chroma <= 8) {
        fgMask[idx] = 0;
      } else if (dist < 40 && chroma <= 5) {
        fgMask[idx] = 0;
      } else if (dist > 30 || chroma > 9) {
        fgMask[idx] = 255;
      } else {
        fgMask[idx] = 0;
      }
    }
  }

  // 5. Keep only the main connected character component (eliminates any stray noise dots)
  const visited = new Uint8Array(W * H);
  const queue = new Int32Array(W * H);
  let qHead = 0, qTail = 0;

  // Seed queue with center of character (chest/torso at x=384, y=400)
  const seedIdx = 400 * W + 384;
  visited[seedIdx] = 1;
  queue[qTail++] = seedIdx;

  while (qHead < qTail) {
    const curr = queue[qHead++];
    const cx = curr % W;
    const cy = Math.floor(curr / W);

    const neighbors = [curr - 1, curr + 1, curr - W, curr + W];
    for (let k = 0; k < 4; k++) {
      const nIdx = neighbors[k];
      const nx = nIdx % W;
      const ny = Math.floor(nIdx / W);
      if (nx >= 0 && nx < W && ny >= 0 && ny < H) {
        if (fgMask[nIdx] === 255 && visited[nIdx] === 0) {
          visited[nIdx] = 1;
          queue[qTail++] = nIdx;
        }
      }
    }
  }

  console.log(`Connected character pixels found: ${qTail}`);

  // 6. Generate final smooth RGBA with feathered, antialiased edge
  const outRgba = new Uint8Array(W * H * 4);

  for (let y = 0; y < H; y++) {
    const [bgR, bgG, bgB] = rowBg[y];
    for (let x = 0; x < W; x++) {
      const idx = y * W + x;
      const idx3 = idx * 3;
      const idx4 = idx * 4;

      const r = origRgb[idx3];
      const g = origRgb[idx3 + 1];
      const b = origRgb[idx3 + 2];

      if (visited[idx] === 0) {
        // Transparent background
        outRgba[idx4] = 0;
        outRgba[idx4 + 1] = 0;
        outRgba[idx4 + 2] = 0;
        outRgba[idx4 + 3] = 0;
        continue;
      }

      // Boundary smoothing / anti-aliasing
      let bgNeighborCount = 0;
      for (let dy = -1; dy <= 1; dy++) {
        for (let dx = -1; dx <= 1; dx++) {
          const ny = y + dy, nx = x + dx;
          if (ny >= 0 && ny < H && nx >= 0 && nx < W) {
            if (visited[ny * W + nx] === 0) {
              bgNeighborCount++;
            }
          }
        }
      }

      let alpha = 255;
      if (bgNeighborCount > 0) {
        const dist = Math.sqrt((r - bgR) ** 2 + (g - bgG) ** 2 + (b - bgB) ** 2);
        if (dist < 35) {
          alpha = Math.round(Math.max(40, Math.min(255, (dist / 35) * 255)));
        } else {
          alpha = Math.round(255 - (bgNeighborCount / 9) * 45);
        }
      }

      outRgba[idx4] = r;
      outRgba[idx4 + 1] = g;
      outRgba[idx4 + 2] = b;
      outRgba[idx4 + 3] = alpha;
    }
  }

  // Save to public destination
  await sharp(outRgba, {
    raw: { width: W, height: H, channels: 4 }
  })
    .png()
    .toFile(destPublic);
  console.log(`Saved flawless transparent avatar to: ${destPublic}`);

  // Also sync to dist if exists
  if (fs.existsSync(path.dirname(destDist))) {
    await sharp(outRgba, {
      raw: { width: W, height: H, channels: 4 }
    })
      .png()
      .toFile(destDist);
    console.log(`Synced to dist: ${destDist}`);
  }
}

generateFlawlessZoya().catch(console.error);
