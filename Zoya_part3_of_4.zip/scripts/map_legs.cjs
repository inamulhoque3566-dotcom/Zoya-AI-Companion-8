const sharp = require('sharp');
const path = require('path');

async function mapLegs() {
  const { data, info } = await sharp(path.join(__dirname, '../src/assets/images/zoya_3d_sweater_glasses_1793764031303.jpg'))
    .raw()
    .toBuffer({ resolveWithObject: true });

  const getPixel = (x, y) => {
    const idx = (y * info.width + x) * info.channels;
    return [data[idx], data[idx + 1], data[idx + 2]];
  };

  // For each y from 1200 to 1370, let's scan across x and find contiguous intervals that belong to character legs
  // The studio floor background has r ~ 200..220, g ~ 200..220, b ~ 200..220, very uniform, grey/desaturated.
  // The socks have r ~ 220..245 or shadow on sock, or shoe is dark black/brown.
  // Let's print out what the background color gradient is on the left (x=100) vs right (x=680)
  for (let y = 1200; y <= 1370; y += 10) {
    const bgL = getPixel(100, y);
    const bgR = getPixel(680, y);
    // Find x ranges where pixel differs from background
    let characterSegments = [];
    let inChar = false;
    let startX = -1;
    for (let x = 200; x <= 560; x++) {
      const p = getPixel(x, y);
      // Background expected: interp between bgL and bgR
      const expectedBg = [
        bgL[0] + (bgR[0] - bgL[0]) * (x / 768),
        bgL[1] + (bgR[1] - bgL[1]) * (x / 768),
        bgL[2] + (bgR[2] - bgL[2]) * (x / 768),
      ];
      const dist = Math.hypot(p[0] - expectedBg[0], p[1] - expectedBg[1], p[2] - expectedBg[2]);
      const isChar = dist > 22; // noticeably different from background
      if (isChar && !inChar) {
        inChar = true;
        startX = x;
      } else if (!isChar && inChar) {
        inChar = false;
        characterSegments.push(`[${startX}..${x-1}]`);
      }
    }
    if (inChar) characterSegments.push(`[${startX}..560]`);
    console.log(`y=${y}: segments: ${characterSegments.join(', ')}`);
  }
}

mapLegs().catch(console.error);
