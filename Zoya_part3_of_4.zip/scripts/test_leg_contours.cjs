const sharp = require('sharp');
const path = require('path');

async function testLegContours() {
  const src = path.join(__dirname, '../src/assets/images/zoya_3d_sweater_glasses_1793764031303.jpg');
  const { data, info } = await sharp(src).removeAlpha().raw().toBuffer({ resolveWithObject: true });
  const W = info.width, H = info.height;

  // Let's print out for every 5 lines from y=1190 to 1365
  for (let y = 1190; y <= 1365; y += 5) {
    let l_in = -1, l_out = -1, r_in = -1, r_out = -1;
    // We know left leg is around x 320..385
    // Let's find where left leg starts and ends
    // Left shoe/leg has edges
    let s = `y=${y}: `;
    // Check points
    for (const x of [310, 320, 325, 330, 350, 370, 375, 385, 395, 400, 410, 430, 445, 455, 465, 475]) {
      const idx = (y * W + x) * 3;
      const r = data[idx];
      s += `${x}:${r} `;
    }
    console.log(s);
  }
}
testLegContours().catch(console.error);
