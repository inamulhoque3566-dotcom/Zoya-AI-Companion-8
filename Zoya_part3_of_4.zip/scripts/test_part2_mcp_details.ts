import path from 'path';
import { mcpClientManager } from '../src/services/agent/mcpClient.ts';
import { agentPermissionGuard } from '../src/services/agent/agentPermissionGuard.ts';

async function runPart2Tests() {
  console.log('========================================================================');
  console.log('🔍 PHASE 5 PART 2: REAL 3P MCP SERVER, CRASH EXIT CODES & APPROVAL UI');
  console.log('========================================================================\n');

  const workspaceRoot = path.join(process.cwd(), 'workspace');
  const serverPath = path.join(process.cwd(), 'node_modules', '@modelcontextprotocol', 'server-filesystem', 'dist', 'index.js');

  // --- ITEM 1: REAL THIRD-PARTY MCP SERVER ---
  console.log('------------------------------------------------------------------------');
  console.log('1. CONNECT REAL 3P MCP SERVER (@modelcontextprotocol/server-filesystem)');
  console.log('------------------------------------------------------------------------');
  const fsServer = mcpClientManager.addServer({
    name: 'mcp-official-filesystem',
    transport: 'stdio',
    command: process.execPath,
    args: [serverPath, workspaceRoot],
    cwd: workspaceRoot,
    allowNetwork: false,
  }, { userApproved: true });

  const fsTools = await mcpClientManager.connectServer(fsServer.id, { userApproved: true });
  console.log(`Connected to official MCP filesystem server (ID: ${fsServer.id})`);
  console.log(`Discovered ${fsTools.length} tools. Tools list:`);
  for (const t of fsTools) {
    console.log(`  - ${t.name}: ${t.description.split('\n')[1]?.slice(0, 80) || t.description}...`);
  }

  // One approved call inside workspace
  console.log('\nExecuting approved tool call: list_directory inside allowed workspace...');
  const approvedCall = await mcpClientManager.callTool(fsServer.id, 'list_directory', { path: workspaceRoot }, { approvalGranted: true });
  console.log('Tool call output:');
  console.log(approvedCall.output);

  // Attempt to read outside workspace
  console.log('\nAttempting to read outside workspace (/etc/passwd):');
  const outsideCall = await mcpClientManager.callTool(fsServer.id, 'read_file', { path: '/etc/passwd' }, { approvalGranted: true });
  console.log('Outside read result:');
  console.log(outsideCall.output);

  await mcpClientManager.removeServer(fsServer.id);
  console.log('Official filesystem server disconnected and removed.\n');

  // --- ITEM 2: CRASH REPORTING "server exited with code N" ---
  console.log('------------------------------------------------------------------------');
  console.log('2. VERIFY CRASHED SERVER REPORTS "server exited with code N" (NOT TIMEOUT)');
  console.log('------------------------------------------------------------------------');
  const stdioScript = path.join(workspaceRoot, 'mcp_test_server.py');
  const crashServer = mcpClientManager.addServer({
    name: 'crash-demo-server',
    transport: 'stdio',
    command: '/usr/bin/python3',
    args: [stdioScript],
    cwd: workspaceRoot,
    allowNetwork: false,
  }, { userApproved: true });

  await mcpClientManager.connectServer(crashServer.id, { userApproved: true });
  console.log('Calling tool crash_or_hang with mode="crash" (subprocess invokes sys.exit(42))...');
  const crashStart = Date.now();
  const crashResult = await mcpClientManager.callTool(crashServer.id, 'crash_or_hang', { mode: 'crash' }, { approvalGranted: true, timeoutMs: 5000 });
  const crashDuration = Date.now() - crashStart;

  console.log(`Returned in: ${crashDuration}ms (Instant, did NOT wait for 5000ms timeout)`);
  console.log(`Success: ${crashResult.success}`);
  console.log(`Reported Output: ${crashResult.output}`);
  await mcpClientManager.removeServer(crashServer.id);

  // --- ITEM 3: APPROVAL REQUEST TEXT SHOWN TO USER ---
  console.log('\n------------------------------------------------------------------------');
  console.log('3. USER APPROVAL REQUEST TEXT FOR call_mcp_tool');
  console.log('------------------------------------------------------------------------');
  const evalResult = agentPermissionGuard.evaluateToolCall('call_mcp_tool', {
    serverId: 'mcp-production-database',
    toolName: 'execute_sql_query',
    arguments: {
      query: 'SELECT user_id, email, role FROM production_users LIMIT 50',
      database: 'customer_db',
      readOnly: true,
    },
  }, workspaceRoot);

  const pending = agentPermissionGuard.requestApproval(
    'task-demo-441',
    'call_mcp_tool',
    {
      serverName: 'mcp-production-database',
      serverId: 'mcp_prod_db_01',
      toolName: 'execute_sql_query',
      arguments: {
        query: 'SELECT user_id, email, role FROM production_users LIMIT 50',
        database: 'customer_db',
        readOnly: true,
      },
    },
    evalResult.level,
    evalResult.reason,
    evalResult.warning
  );

  console.log('=== PENDING APPROVAL REQUEST AS PRESENTED TO USER ===');
  console.log(`Approval ID:    ${pending.pendingId}`);
  console.log(`Action / Tool:  call_mcp_tool`);
  console.log(`Server Name:    ${(agentPermissionGuard.getPendingApprovals().find(p => p.id === pending.pendingId)?.args as any).serverName}`);
  console.log(`MCP Tool Name:  ${(agentPermissionGuard.getPendingApprovals().find(p => p.id === pending.pendingId)?.args as any).toolName}`);
  console.log(`Permission:     ${evalResult.level}`);
  console.log(`Warning Banner: ${evalResult.warning}`);
  console.log(`Full Arguments:`);
  console.log(JSON.stringify((agentPermissionGuard.getPendingApprovals().find(p => p.id === pending.pendingId)?.args as any).arguments, null, 2));
  console.log('=====================================================');

  // Clean up approval
  agentPermissionGuard.resolveApproval(pending.pendingId, false, 'test_cleanup');
}

runPart2Tests().catch((e) => {
  console.error('Part 2 test error:', e);
  process.exit(1);
});
