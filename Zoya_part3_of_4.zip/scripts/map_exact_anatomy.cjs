const sharp = require('sharp');

async function checkBackupPng9() {
  const { data, info } = await sharp('data/avatar_backups_original/transparent/avatar_9_cyber_maid.png').raw().toBuffer({ resolveWithObject: true });
  const W = info.width;
  console.log('=== backup avatar_9_cyber_maid.png y=950..1350 ===');
  for (let y = 950; y <= 1350; y += 12) {
    let line = `${String(y).padStart(4)}: `;
    for (let x = 120; x <= 640; x += 7) {
      const idx = (y * W + x) * 4;
      const r = data[idx], g = data[idx + 1], b = data[idx + 2], a = data[idx + 3];
      if (a === 0) line += '.';
      else if (r > 180 && g > 180 && b > 180) line += 'W';
      else line += '#';
    }
    console.log(line);
  }
}

checkBackupPng9().catch(console.error);
