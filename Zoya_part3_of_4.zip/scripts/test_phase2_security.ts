import path from 'path';
import fs from 'fs';
import { AgentPermissionGuard, maskSecrets, agentPermissionGuard } from '../src/services/agent/agentPermissionGuard.ts';
import { AgentToolExecutor } from '../src/services/agent/agentTools.ts';
import { AgentAuthManager } from '../src/services/agent/agentAuth.ts';

const TEST_WORKSPACE = path.join(process.cwd(), 'workspace', 'security_test_sandbox');
if (!fs.existsSync(TEST_WORKSPACE)) {
  fs.mkdirSync(TEST_WORKSPACE, { recursive: true });
}

const SECURITY_LOG_FILE = path.join(process.cwd(), 'data', 'agent_logs', 'security_audit.log');

async function runPhase2SecurityTests() {
  console.log('====================================================');
  console.log('🛡️  RUNNING PHASE 2: SECURITY & PERMISSIONS VERIFICATION');
  console.log('====================================================\n');

  let passed = 0;
  let failed = 0;

  function assert(condition: boolean, testName: string, detail?: string) {
    if (condition) {
      console.log(`✅ PASS: ${testName}`);
      passed++;
    } else {
      console.error(`❌ FAIL: ${testName} - ${detail || ''}`);
      failed++;
    }
  }

  const guard = AgentPermissionGuard.getInstance();

  // ---------------------------------------------------------------
  // TEST 1: Read file runs without approval (AUTO_ALLOW)
  // ---------------------------------------------------------------
  console.log('--- TEST 1: Read file runs without approval ---');
  fs.writeFileSync(path.join(TEST_WORKSPACE, 'sample.txt'), 'Hello Security Sandbox', 'utf8');

  const evalRead = guard.evaluateToolCall('read_file', { path: 'sample.txt' }, TEST_WORKSPACE);
  console.log(`[EVALUATION] read_file -> level: ${evalRead.level}, needsApproval: ${evalRead.needsApproval}`);
  assert(
    evalRead.level === 'AUTO_ALLOW' && !evalRead.needsApproval,
    'Read file runs without approval (AUTO_ALLOW)'
  );

  // ---------------------------------------------------------------
  // TEST 2: Write file waits for approval (ASK_APPROVAL)
  // ---------------------------------------------------------------
  console.log('\n--- TEST 2: Write file waits for approval ---');
  const evalWrite = guard.evaluateToolCall('write_file', { path: 'new_file.txt', content: 'test' }, TEST_WORKSPACE);
  console.log(`[EVALUATION] write_file -> level: ${evalWrite.level}, needsApproval: ${evalWrite.needsApproval}`);
  assert(
    evalWrite.level === 'ASK_APPROVAL' && evalWrite.needsApproval,
    'Write file requires approval (ASK_APPROVAL)'
  );

  // Test approval workflow: trigger approval, verify pending, resolve approve
  const approvalFlow = guard.requestApproval(
    'test_task_1',
    'write_file',
    { path: 'approved_file.txt', content: 'secure' },
    'ASK_APPROVAL',
    'Writing approved file'
  );

  const pendingList = guard.getPendingApprovals();
  assert(
    pendingList.some((p) => p.id === approvalFlow.pendingId),
    'Approval request registered in pending approvals map'
  );

  // Approve it
  guard.resolveApproval(approvalFlow.pendingId, true, 'security_admin');
  const approvalResult = await approvalFlow.promise;
  assert(approvalResult === true, 'Approved action promise resolves true');

  // ---------------------------------------------------------------
  // TEST 3: "rm -rf /" is blocked or needs strict approval with warning
  // ---------------------------------------------------------------
  console.log('\n--- TEST 3: "rm -rf /" command security inspection ---');
  const inspRmRf = guard.inspectCommand('rm -rf /', TEST_WORKSPACE);
  console.log(`[INSPECTION] "rm -rf /" -> level: ${inspRmRf.level}, reason: ${inspRmRf.reason}, warning: ${inspRmRf.warningDetails}`);
  assert(
    inspRmRf.level === 'STRICT_APPROVAL_WITH_WARNING' || inspRmRf.isBlocked,
    '"rm -rf /" escalates to strict approval with warning or is blocked',
    inspRmRf.reason
  );

  // ---------------------------------------------------------------
  // TEST 4: "cat /etc/passwd" is blocked outright
  // ---------------------------------------------------------------
  console.log('\n--- TEST 4: "cat /etc/passwd" is blocked ---');
  const inspPasswd = guard.inspectCommand('cat /etc/passwd', TEST_WORKSPACE);
  console.log(`[INSPECTION] "cat /etc/passwd" -> level: ${inspPasswd.level}, isBlocked: ${inspPasswd.isBlocked}, reason: ${inspPasswd.reason}`);
  assert(
    inspPasswd.level === 'BLOCKED' && inspPasswd.isBlocked,
    '"cat /etc/passwd" is strictly blocked as critical security violation'
  );

  // ---------------------------------------------------------------
  // TEST 5: npm install needs strict approval
  // ---------------------------------------------------------------
  console.log('\n--- TEST 5: npm install needs strict approval ---');
  const inspNpm = guard.inspectCommand('npm install express', TEST_WORKSPACE);
  console.log(`[INSPECTION] "npm install express" -> level: ${inspNpm.level}, matchedPattern: ${inspNpm.matchedPattern}`);
  assert(
    inspNpm.level === 'STRICT_APPROVAL_WITH_WARNING' && inspNpm.matchedPattern === 'PACKAGE_INSTALL',
    'npm install requires strict approval with warning'
  );

  // ---------------------------------------------------------------
  // TEST 6: Extended secret masking (All secret classes)
  // ---------------------------------------------------------------
  console.log('\n--- TEST 6: Extended Secret Masking ---');
  process.env.CUSTOM_TEST_API_KEY = 'super_secret_custom_env_key_999888';
  process.env.APP_SECRET_TOKEN = 'app_secret_token_abcdef123456';

  const rawTestString = `
1. Gemini: AQ.Ab8RN6JjOTRMYZza3H2Cnt6x7DIvKKF6EUt3xHvloUZvQ0qwxw
2. Google: AIzaSyD4j5k6l7m8n9o0p1q2r3s4t5u6v7w8x9y
3. Claude: sk-ant-api03-abcdefghijklmnopqrstuvwxyz1234567890-test
4. OpenAI: sk-proj-1234567890abcdefghijklmnopqrstuvwxyz1234
5. GitHub GHP: ghp_1234567890abcdefghijklmnopqrstuvwxyz
6. GitHub PAT: github_pat_11ABCDEF0123456789_abcdefghijklmnopqrstuvwxyz0123456789ABCDEF
7. AWS Access Key: AKIAIOSFODNN7EXAMPLE
8. Bearer Token: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.e30.fake
9. Private Key:
-----BEGIN RSA PRIVATE KEY-----
MIIEowIBAAKCAQEA0Yq3fakeKeyDataLine1...
MIIEowIBAAKCAQEA0Yq3fakeKeyDataLine2...
-----END RSA PRIVATE KEY-----
10. Agent Auth: zoya_agent_sec_999988887777666655554444333322221111
11. Env Key: super_secret_custom_env_key_999888
12. Env Token: app_secret_token_abcdef123456
`.trim();

  const masked = maskSecrets(rawTestString);
  console.log('[MASKED OUTPUT SAMPLE]:\n' + masked);

  assert(!masked.includes('AQ.Ab8RN6JjOTRMYZza3H2Cnt6x7DIvKKF6EUt3xHvloUZvQ0qwxw') && masked.includes('[REDACTED_GEMINI_KEY]'), 'Gemini key masked');
  assert(!masked.includes('AIzaSyD4j5k6l7m8n9o0p1q2r3s4t5u6v7w8x9y') && masked.includes('[REDACTED_GOOGLE_API_KEY]'), 'Google API key masked');
  assert(!masked.includes('sk-ant-api03') && masked.includes('[REDACTED_ANTHROPIC_KEY]'), 'Anthropic key masked');
  assert(!masked.includes('sk-proj-1234567890') && masked.includes('[REDACTED_OPENAI_KEY]'), 'OpenAI key masked');
  assert(!masked.includes('ghp_1234567890') && masked.includes('[REDACTED_GITHUB_TOKEN]'), 'GitHub GHP token masked');
  assert(!masked.includes('github_pat_11ABCDEF') && masked.includes('[REDACTED_GITHUB_TOKEN]'), 'GitHub fine-grained PAT masked');
  assert(!masked.includes('AKIAIOSFODNN7EXAMPLE') && masked.includes('[REDACTED_AWS_KEY]'), 'AWS access key masked');
  assert(!masked.includes('eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9') && masked.includes('[REDACTED_BEARER_TOKEN]'), 'Bearer token masked');
  assert(!masked.includes('MIIEowIBAAKCAQEA0Yq3fakeKeyDataLine1') && masked.includes('[REDACTED_PRIVATE_KEY_BLOCK]'), 'Private key block masked');
  assert(!masked.includes('zoya_agent_sec_99998888') && masked.includes('[REDACTED_AGENT_AUTH_TOKEN]'), 'Zoya agent token masked');
  assert(!masked.includes('super_secret_custom_env_key_999888') && masked.includes('REDACTED_ENV_CUSTOM_TEST_API_KEY'), 'Env *KEY masked dynamically');
  assert(!masked.includes('app_secret_token_abcdef123456') && masked.includes('REDACTED_ENV_APP_SECRET_TOKEN'), 'Env *TOKEN masked dynamically');

  // ---------------------------------------------------------------
  // TEST 7: Fake API Key masked in persistent audit log file on disk
  // ---------------------------------------------------------------
  console.log('\n--- TEST 7: Secret masked in saved log file on disk ---');
  const fakeApiKeyToLog = 'AIzaSyDTESTINGFAKEKEY998877665544332211';
  guard.logSecurityEvent({
    action: 'APPROVAL_REQUESTED',
    toolName: 'test_secret_audit',
    details: `Output contained key: ${fakeApiKeyToLog}`,
    level: 'ASK_APPROVAL',
    taskId: 'test_audit_masking',
  });

  const logFileExists = fs.existsSync(SECURITY_LOG_FILE);
  assert(logFileExists, 'Security log file exists on disk');

  const logContent = fs.readFileSync(SECURITY_LOG_FILE, 'utf8');
  const lines = logContent.trim().split('\n');
  const relevantLine = lines.reverse().find((l) => l.includes('test_secret_audit')) || '';
  console.log(`[SAVED LOG LINE]: ${relevantLine}`);

  assert(
    !relevantLine.includes(fakeApiKeyToLog) && relevantLine.includes('[REDACTED_GOOGLE_API_KEY]'),
    'Fake API key is masked as [REDACTED_GOOGLE_API_KEY] in saved security audit log file'
  );

  // ---------------------------------------------------------------
  // TEST 8: Denied action is NOT executed on disk
  // ---------------------------------------------------------------
  console.log('\n--- TEST 8: Denied action is NOT executed ---');
  const deniedFilePath = 'should_never_exist.txt';
  const fullDeniedPath = path.join(TEST_WORKSPACE, deniedFilePath);
  if (fs.existsSync(fullDeniedPath)) fs.unlinkSync(fullDeniedPath);

  const executor = new AgentToolExecutor({
    workspaceRoot: TEST_WORKSPACE,
    commandTimeoutMs: 5000,
    maxOutputChars: 5000,
    autoApprove: false, // Forces approval prompt
  });

  // Start execution asynchronously (it will pause for approval)
  const execPromise = executor.executeTool('write_file', {
    path: deniedFilePath,
    content: 'Malicious or unauthorized payload that must never touch disk',
  });

  // Small delay to allow approval registration
  await new Promise((r) => setTimeout(r, 80));

  const pending = guard.getPendingApprovals();
  const writePending = pending.find((p) => p.args?.path === deniedFilePath);
  assert(Boolean(writePending), 'Write file paused and registered pending approval');

  if (writePending) {
    // Explicitly DENY
    guard.resolveApproval(writePending.id, false, 'security_auditor');
  }

  const execResult = await execPromise;
  console.log(`[DENIED TOOL RESULT] success: ${execResult.success}, output: "${execResult.output}"`);

  assert(
    execResult.success === false && execResult.error === 'ACTION_DENIED',
    'Denied action returned failure with ACTION_DENIED'
  );

  const fileExistsOnDisk = fs.existsSync(fullDeniedPath);
  console.log(`[DISK VERIFICATION] File '${fullDeniedPath}' exists: ${fileExistsOnDisk}`);
  assert(
    !fileExistsOnDisk,
    'Denied file was NOT created on disk (fs.existsSync is false)'
  );

  // ---------------------------------------------------------------
  // TEST 9: Authentication Token Verification & Rotation
  // ---------------------------------------------------------------
  console.log('\n--- TEST 9: Agent Authentication Token Validation & Rotation ---');
  const initialToken = AgentAuthManager.getOrCreateToken();
  assert(Boolean(initialToken && initialToken.length >= 20), 'AgentAuthManager generated valid secure token');

  const validCheck = AgentAuthManager.validateToken(initialToken);
  assert(validCheck === true, 'AgentAuthManager validates correct token');

  const invalidCheck = AgentAuthManager.validateToken('fake_bad_token_123');
  assert(invalidCheck === false, 'AgentAuthManager rejects invalid token');

  const emptyCheck = AgentAuthManager.validateToken(undefined);
  assert(emptyCheck === false, 'AgentAuthManager rejects missing token');

  // Test token rotation
  const rotatedToken = AgentAuthManager.rotateToken();
  assert(
    Boolean(rotatedToken && rotatedToken !== initialToken),
    'AgentAuthManager rotates token to a new distinct cryptographic secret'
  );
  assert(
    AgentAuthManager.validateToken(rotatedToken) === true,
    'New rotated token is valid'
  );
  assert(
    AgentAuthManager.validateToken(initialToken) === false,
    'Old token is invalidated after rotation'
  );

  console.log('\n====================================================');
  console.log(`SECURITY SUITE SUMMARY: ${passed} PASSED, ${failed} FAILED`);
  console.log('====================================================');

  if (failed > 0) {
    process.exit(1);
  }
}

runPhase2SecurityTests().catch((err) => {
  console.error('Security test suite crashed:', err);
  process.exit(1);
});
