const sharp = require('sharp');
const fs = require('fs');

async function makeProofs() {
  console.log('Generating magenta proofs...');
  fs.mkdirSync('proof_artifacts', { recursive: true });

  // 1. Avatar A on bright magenta
  const metaA = await sharp('public/assets/images/avatars_3d/transparent/avatar_pastel_blue_knit_shorts.png').metadata();
  const magentaA = await sharp({
    create: { width: metaA.width, height: metaA.height, channels: 4, background: { r: 255, g: 0, b: 255, alpha: 1 } }
  }).png().toBuffer();

  const fullA = await sharp(magentaA)
    .composite([{ input: 'public/assets/images/avatars_3d/transparent/avatar_pastel_blue_knit_shorts.png' }])
    .png()
    .toBuffer();

  fs.writeFileSync('proof_artifacts/avatar_a_pastel_full_magenta.png', fullA);

  // Zoomed on feet, ankles and sliver area (between legs and around shoes)
  // y: 1300 to 1672, x: 350 to 620
  await sharp(fullA)
    .extract({ left: 350, top: 1300, width: 270, height: 372 })
    .toFile('proof_artifacts/avatar_a_pastel_feet_zoom_magenta.png');

  // Zoomed on entire legs (y: 900 to 1672, x: 300 to 650)
  await sharp(fullA)
    .extract({ left: 300, top: 900, width: 350, height: 772 })
    .toFile('proof_artifacts/avatar_a_pastel_legs_zoom_magenta.png');

  // 2. Avatar B on bright magenta
  const metaB = await sharp('public/assets/images/avatars_3d/transparent/avatar_midnight_gold_zari_saree.png').metadata();
  const magentaB = await sharp({
    create: { width: metaB.width, height: metaB.height, channels: 4, background: { r: 255, g: 0, b: 255, alpha: 1 } }
  }).png().toBuffer();

  const fullB = await sharp(magentaB)
    .composite([{ input: 'public/assets/images/avatars_3d/transparent/avatar_midnight_gold_zari_saree.png' }])
    .png()
    .toBuffer();

  fs.writeFileSync('proof_artifacts/avatar_b_saree_full_magenta.png', fullB);

  // Zoomed on saree hem and bottom (y: 1200 to 1536, x: 200 to 800)
  await sharp(fullB)
    .extract({ left: 200, top: 1200, width: 600, height: 336 })
    .toFile('proof_artifacts/avatar_b_saree_hem_zoom_magenta.png');

  // Zoomed on hands and sides of body (y: 400 to 800, x: 180 to 820)
  await sharp(fullB)
    .extract({ left: 180, top: 400, width: 640, height: 400 })
    .toFile('proof_artifacts/avatar_b_saree_hands_zoom_magenta.png');

  console.log('✓ All magenta proofs generated in proof_artifacts/');
}

makeProofs().catch(console.error);
