export interface Anime3DAvatar {
  id: string;
  name: string;
  japaneseName: string;
  tag: string;
  outfit: string;
  description: string;
  fullImage: string;
  thumbnail: string;
  transparentPng: string;
  styleInspiration: string;
  isCustom?: boolean;
  vrmModelUrl?: string;
  videoUrl?: string;
  modelType?: 'vrm' | 'png' | 'video';
  hasHumanoidRig?: boolean;
}

export const ANIME_3D_AVATARS: Anime3DAvatar[] = [
  {
    id: 'boho_mini_dress',
    name: 'Boho Floral Mini Dress',
    japaneseName: 'ボヘミアン ミニドレス',
    tag: 'Boho Floral',
    outfit: 'Boho Floral Printed Mini Dress & Strappy Heels',
    description: 'फ्लोरल प्रिंटेड बोहो मिनी ड्रेस, वी-नेकलाइन, हाफ स्लीव्स व एलिगेंट स्ट्रैपी ब्लैक हील्स। संपूर्ण ऑउटफिट व पैर स्पष्ट दृश्यमान।',
    fullImage: '/assets/images/avatars_3d/avatar_boho_mini_dress.jpg',
    thumbnail: '/assets/images/avatars_3d/avatar_boho_mini_dress.jpg',
    transparentPng: '/assets/images/avatars_3d/transparent/avatar_boho_mini_dress.png',
    styleInspiration: 'Boho Floral Printed Mini Dress with Strappy Heels',
  },
  {
    id: 'peasant_blouse_skirt',
    name: 'Peasant Blouse & Lavender Skirt',
    japaneseName: 'ラベンダー マキシスカート',
    tag: 'Romantic Pastel',
    outfit: 'Off-Shoulder White Ruffle Blouse & Lavender-Pink Flared Maxi',
    description: 'ऑफ-शोल्डर वाइट रफल ब्लाउज, फ्लोई लैवेंडर-पिंक टायर्ड मैक्सी स्कर्ट, ड्रॉप ईयररिंग्स व न्यूड पम्प्स। नेचुरल ग्राउंड अलाइनमेंट।',
    fullImage: '/assets/images/avatars_3d/avatar_peasant_blouse_skirt.jpg',
    thumbnail: '/assets/images/avatars_3d/avatar_peasant_blouse_skirt.jpg',
    transparentPng: '/assets/images/avatars_3d/transparent/avatar_peasant_blouse_skirt.png',
    styleInspiration: 'Off-Shoulder White Blouse & Lavender Maxi Skirt',
  },
  {
    id: 'pink_knit_maxi',
    name: 'Pink Rib Knit & White Maxi',
    japaneseName: 'ピンク リブニット マキシ',
    tag: 'Cozy Chic',
    outfit: 'Pink Ribbed Knit Sweater & Tiered White Maxi Skirt',
    description: 'पिंक स्क्वेयर-नेक रिब्ड निट स्वेटर, व्हाइट टायर्ड फ्लोई मैक्सी स्कर्ट, शोल्डर चेन बैग व व्हाइट स्नीकर्स।',
    fullImage: '/assets/images/avatars_3d/avatar_pink_knit_maxi.jpg',
    thumbnail: '/assets/images/avatars_3d/avatar_pink_knit_maxi.jpg',
    transparentPng: '/assets/images/avatars_3d/transparent/avatar_pink_knit_maxi.png',
    styleInspiration: 'Pink Knit Crop Sweater & White Tiered Maxi Skirt',
  },
  {
    id: 'floral_palazzo_pants',
    name: 'Floral Palazzo Pants Ensemble',
    japaneseName: 'フローラル パラッツォ',
    tag: 'Graceful Floral',
    outfit: 'White Cami, Sheer Floral Shrug & Wide Palazzo Pants',
    description: 'फ्लोरल शीयर श्रग, आइवरी कैमी व फ्लोरल वाइड-लेग पलाज़ो पैंट्स। पूरे पैर व शूज जमीन पर स्वाभाविक रूप से स्थित।',
    fullImage: '/assets/images/avatars_3d/avatar_floral_palazzo_pants.jpg',
    thumbnail: '/assets/images/avatars_3d/avatar_floral_palazzo_pants.jpg',
    transparentPng: '/assets/images/avatars_3d/transparent/avatar_floral_palazzo_pants.png',
    styleInspiration: 'Floral Wide Palazzo Pants with Sheer Shrug',
  },
  {
    id: 'red_cardigan_floral',
    name: 'Red Cardigan & Floral Skirt',
    japaneseName: 'フレンチ カーディガン',
    tag: 'Chic Parisian',
    outfit: 'Red Knit Cardigan, White Lace Top & Floral Mini Skirt',
    description: 'क्लासिक रेड निट कार्डिगन, वाइट लेस कैमी, फ्लोरल मिनी स्कर्ट, पर्ल नेकलेस, वाइट सॉक्स व रेड मैरी जेन हील्स।',
    fullImage: '/assets/images/avatars_3d/avatar_red_cardigan_floral.jpg',
    thumbnail: '/assets/images/avatars_3d/avatar_red_cardigan_floral.jpg',
    transparentPng: '/assets/images/avatars_3d/transparent/avatar_red_cardigan_floral.png',
    styleInspiration: 'Red Cardigan & Floral Skirt with White Socks & Mary Janes',
  },
  {
    id: 'plum_royal_anarkali',
    name: 'Royal Plum Zari Anarkali',
    japaneseName: 'ロイヤル プラム',
    tag: 'Heritage Royalty',
    outfit: 'Plum Zari Embroidered Anarkali Gown & Dupatta',
    description: 'रॉयल प्लम वेलवेट-सिल्क अनारकली, स्वर्णिम जरी वर्क, मैचिंग फ्लोई दुपट्टा व झुमका ईयररिंग्स।',
    fullImage: '/assets/images/avatars_3d/avatar_plum_royal_anarkali.jpg',
    thumbnail: '/assets/images/avatars_3d/avatar_plum_royal_anarkali.jpg',
    transparentPng: '/assets/images/avatars_3d/transparent/avatar_plum_royal_anarkali.png',
    styleInspiration: 'Royal Plum Zari Embroidered Anarkali',
  },
  {
    id: 'ivory_floral_anarkali',
    name: 'Ivory & Rose Floral Anarkali',
    japaneseName: 'アイボリー フローラル',
    tag: 'Graceful Pastel',
    outfit: 'Ivory Embroidered Anarkali with Rose Floral Dupatta',
    description: 'एलिगेंट आइवरी चिकनकारी अनारकली, रोज़ पिंक फ्लोरल प्रिंटेड दुपट्टा व पर्ल नेकलेस।',
    fullImage: '/assets/images/avatars_3d/avatar_ivory_floral_anarkali.jpg',
    thumbnail: '/assets/images/avatars_3d/avatar_ivory_floral_anarkali.jpg',
    transparentPng: '/assets/images/avatars_3d/transparent/avatar_ivory_floral_anarkali.png',
    styleInspiration: 'Ivory Anarkali with Rose Floral Dupatta',
  },
  {
    id: 'classic',
    name: 'Classic Sweater & Glasses (Zoya)',
    japaneseName: 'ゾーヤ クラシック',
    tag: 'Signature AI',
    outfit: 'Ivory Knit Sweater, Pleated Skirt & Glasses',
    description: 'सिग्नेचर आइवरी निट स्वेटर, प्लीटेड स्कर्ट, वायर-रिम ग्लासेस व नेचुरल 3D प्रेजेंटेशन।',
    fullImage: '/assets/images/zoya_master_render.jpg',
    thumbnail: '/assets/images/zoya_master_render.jpg',
    transparentPng: '/assets/images/zoya_new_avatar_transparent.png',
    styleInspiration: 'Zoya Signature Avatar (Ivory Knit Sweater & Glasses)',
  },

  {
    id: 'avatar_urban_crop_hoodie',
    name: 'Urban Crop Hoodie & Cargo Joggers',
    japaneseName: 'アーバン クロップド フーディー',
    tag: 'Streetwear Chic',
    outfit: 'White Crop Hoodie, Baggy Cargo Joggers & High-Tops',
    description: 'वाइट क्रॉप्ड हुडी (एम्बलम प्रिंट), रेड ब्रेड हेयरस्टाइल, बैगी कार्गो जॉगर्स व ब्लैक स्ट्रैप्स, चंकी स्नीकर्स।',
    fullImage: '/assets/images/avatars_3d/avatar_urban_crop_hoodie.jpg',
    thumbnail: '/assets/images/avatars_3d/avatar_urban_crop_hoodie.jpg',
    transparentPng: '/assets/images/avatars_3d/transparent/avatar_urban_crop_hoodie.png',
    styleInspiration: 'Urban Crop Hoodie & Baggy Cargo Joggers with Red Braid',
  },
  {
    id: 'avatar_white_ruffle_babydoll',
    name: 'White Satin Ruffle Babydoll',
    japaneseName: 'ホワイト サテン ベビードール',
    tag: 'Romantic Doll',
    outfit: 'Pearl White Satin Ruffled Corset Babydoll & Bow Heels',
    description: 'पर्ल-वाइट सैटिन रफल्ड बेबी-डॉल मिनी ड्रेस, कॉर्सेट बॉडिस, वेस्ट बो-टाई, डार्क वेवी हेयर व बो हील्स।',
    fullImage: '/assets/images/avatars_3d/avatar_white_ruffle_babydoll.jpg',
    thumbnail: '/assets/images/avatars_3d/avatar_white_ruffle_babydoll.jpg',
    transparentPng: '/assets/images/avatars_3d/transparent/avatar_white_ruffle_babydoll.png',
    styleInspiration: 'White Satin Ruffle Corset Babydoll Dress with Bow Tie & Heels',
  },
  {
    id: 'avatar_pink_athleisure_track',
    name: 'Pink Athleisure Tracksuit',
    japaneseName: 'ピンク アスレジャー トラック',
    tag: 'Athleisure Chic',
    outfit: 'Glossy Pink Track Jacket, Running Shorts & Oval Glasses',
    description: 'पिंक ग्लॉसी ट्रैक जैकेट, मैचिंग रनिंग शॉर्ट्स, टिंटेड ओवल ग्लासेस, बबलकम पिंक बॉब हेयर व व्हाइट फ्लैट्स।',
    fullImage: '/assets/images/avatars_3d/avatar_pink_athleisure_track.jpg',
    thumbnail: '/assets/images/avatars_3d/avatar_pink_athleisure_track.jpg',
    transparentPng: '/assets/images/avatars_3d/transparent/avatar_pink_athleisure_track.png',
    styleInspiration: 'Pink Nylon Track Jacket & Running Shorts with Tinted Glasses',
  },

  {
    id: 'avatar_pastel_blue_knit_shorts',
    name: 'Pastel Blue Knit & Pink Shorts',
    japaneseName: 'パステルブルー オフショルダー',
    tag: 'Cozy Pastel',
    outfit: 'Striped Off-Shoulder Knit, Dolphin Shorts & Blue Hair',
    description: 'लॉन्ग पेस्टल स्काई-ब्लू हेयर, ऑफ-शोल्डर स्ट्राइप्ड निट स्वेटर, पिंक डॉल्फ़िन शॉर्ट्स व पिंक स्नीकर्स।',
    fullImage: '/assets/images/avatars_3d/avatar_pastel_blue_knit_shorts.jpg',
    thumbnail: '/assets/images/avatars_3d/avatar_pastel_blue_knit_shorts.jpg',
    transparentPng: '/assets/images/avatars_3d/transparent/avatar_pastel_blue_knit_shorts.png',
    styleInspiration: 'Pastel Striped Off-Shoulder Knit & Pink Dolphin Shorts',
  },

  {
    id: 'avatar_slate_blue_regal_kurta',
    name: 'Slate Blue Regal Kurta & Cape',
    japaneseName: 'スレートブルー クルタ',
    tag: 'Ethnic Royalty',
    outfit: 'Slate Blue Embroidered Long Kurta, Cape Dupatta & Palazzo',
    description: 'स्लेट-ब्लू एम्ब्रॉयडर्ड लॉन्ग कुर्ता, शीयर दुपट्टा केप, मैचिंग पलाज़ो पैंट्स व रॉयल झुमका ज्वेलरी।',
    fullImage: '/assets/images/avatars_3d/avatar_slate_blue_regal_kurta.jpg',
    thumbnail: '/assets/images/avatars_3d/avatar_slate_blue_regal_kurta.jpg',
    transparentPng: '/assets/images/avatars_3d/transparent/avatar_slate_blue_regal_kurta.png',
    styleInspiration: 'Slate Blue Embroidered Long Kurta with Sheer Flowing Cape Dupatta',
  },
  {
    id: 'avatar_midnight_gold_zari_saree',
    name: 'Midnight Black & Gold Zari Saree',
    japaneseName: 'ミッドナイト ゴールド サリー',
    tag: 'Midnight Saree',
    outfit: 'Sheer Black Chiffon Saree with Gold Floral Zari Border & Glasses',
    description: 'क्लासिक शीयर ब्लैक शिफॉन साड़ी, स्वर्णिम ज़री फ्लोरल बॉर्डर, वायर-रिम ग्लासेस व एलिगेंट स्लीवलेस ब्लाउज़।',
    fullImage: '/assets/images/avatars_3d/avatar_midnight_gold_zari_saree.jpg',
    thumbnail: '/assets/images/avatars_3d/avatar_midnight_gold_zari_saree.jpg',
    transparentPng: '/assets/images/avatars_3d/transparent/avatar_midnight_gold_zari_saree.png',
    styleInspiration: 'Sheer Black Saree with Gold Floral Zari Border & Wire-Rim Glasses',
  },

  {
    id: 'avatar_nautical_denim_shorts',
    name: 'Silk Blouse & Nautical Denim Shorts',
    japaneseName: 'シルクブラウス デニムショーツ',
    tag: 'Chic Nautical',
    outfit: 'Cream Balloon-Sleeve Blouse, High-Waist Denim Shorts & Glasses',
    description: 'क्रीम बैलून-स्लीव सिल्क ब्लाउज़, हाई-वेस्ट डेनिम शॉर्ट्स (गोल्ड सेलर्स बटन), ग्लासेस व ब्लैक हील्स।',
    fullImage: '/assets/images/avatars_3d/avatar_nautical_denim_shorts.jpg',
    thumbnail: '/assets/images/avatars_3d/avatar_nautical_denim_shorts.jpg',
    transparentPng: '/assets/images/avatars_3d/transparent/avatar_nautical_denim_shorts.png',
    styleInspiration: 'Cream Silk Blouse & High-Waist Sailor Denim Shorts with Glasses',
  },

];

export const STORAGE_KEY_SELECTED_3D_AVATAR = 'zoya_selected_3d_avatar_id_v2';
export const STORAGE_KEY_PERMANENT_AVATAR = 'zoya_permanent_avatar_selection_v3';
export const STORAGE_KEY_3D_AVATAR_ENABLED = 'zoya_3d_avatar_enabled_v1';
export const STORAGE_KEY_3D_AVATAR_SCALE = 'zoya_3d_avatar_scale_v1';
export const STORAGE_KEY_3D_AVATAR_OFFSET_Y = 'zoya_3d_avatar_offset_y_v1';
export const STORAGE_KEY_3D_AVATAR_LIVELINESS = 'zoya_3d_avatar_liveliness_k_v1';
export const STORAGE_KEY_CUSTOM_AVATARS = 'zoya_custom_avatars_v1';

// Custom avatars storage helpers (for uploaded avatars)
export function getCustomAvatars(): Anime3DAvatar[] {
  try {
    if (typeof localStorage !== 'undefined') {
      const data = localStorage.getItem(STORAGE_KEY_CUSTOM_AVATARS);
      if (data) {
        const parsed = JSON.parse(data);
        if (Array.isArray(parsed)) return parsed;
      }
    }
  } catch {}
  return [];
}

export function saveCustomAvatar(avatar: Anime3DAvatar): void {
  try {
    if (typeof localStorage !== 'undefined') {
      const existing = getCustomAvatars().filter((a) => a.id !== avatar.id);
      existing.unshift(avatar);
      localStorage.setItem(STORAGE_KEY_CUSTOM_AVATARS, JSON.stringify(existing));
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('zoya-custom-avatars-updated', { detail: existing }));
      }
    }
  } catch {}
}

export function deleteCustomAvatar(id: string): void {
  try {
    if (typeof localStorage !== 'undefined') {
      const filtered = getCustomAvatars().filter((a) => a.id !== id);
      localStorage.setItem(STORAGE_KEY_CUSTOM_AVATARS, JSON.stringify(filtered));
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('zoya-custom-avatars-updated', { detail: filtered }));
      }
    }
  } catch {}
}

export function getAllAvatars(): Anime3DAvatar[] {
  const custom = getCustomAvatars();
  return [...custom, ...ANIME_3D_AVATARS];
}

// In-memory cache to guarantee persistence even if storage throws in strict privacy mode
let inMemoryActiveAvatarId: string | null = null;

export function getSaved3DAvatarId(): string {
  const all = getAllAvatars();
  if (inMemoryActiveAvatarId && all.some((a) => a.id === inMemoryActiveAvatarId)) {
    return inMemoryActiveAvatarId;
  }
  try {
    if (typeof localStorage !== 'undefined') {
      // 1. Primary permanent key
      const permanent = localStorage.getItem(STORAGE_KEY_PERMANENT_AVATAR);
      if (permanent && all.some((a) => a.id === permanent)) {
        inMemoryActiveAvatarId = permanent;
        return permanent;
      }
      // 2. Legacy key
      const legacy = localStorage.getItem(STORAGE_KEY_SELECTED_3D_AVATAR);
      if (legacy && all.some((a) => a.id === legacy)) {
        inMemoryActiveAvatarId = legacy;
        localStorage.setItem(STORAGE_KEY_PERMANENT_AVATAR, legacy);
        return legacy;
      }
      // 3. Classic style fallback key
      const classic = localStorage.getItem('zoya_saved_avatar_style_v1');
      if (classic && all.some((a) => a.id === classic)) {
        inMemoryActiveAvatarId = classic;
        localStorage.setItem(STORAGE_KEY_PERMANENT_AVATAR, classic);
        return classic;
      }
      // 4. Default avatar
      const defaultId = 'avatar_pastel_blue_knit_shorts';
      inMemoryActiveAvatarId = defaultId;
      localStorage.setItem(STORAGE_KEY_PERMANENT_AVATAR, defaultId);
      localStorage.setItem(STORAGE_KEY_SELECTED_3D_AVATAR, defaultId);
      return defaultId;
    }
  } catch {}
  inMemoryActiveAvatarId = 'avatar_pastel_blue_knit_shorts';
  return 'avatar_pastel_blue_knit_shorts';
}

export function save3DAvatarId(id: string): void {
  if (!id) return;
  const all = getAllAvatars();
  const valid = all.find((a) => a.id === id);
  if (!valid) {
    console.warn(`[Avatar] Attempted to save invalid avatar ID: "${id}". Operation blocked to preserve selection.`);
    return;
  }
  inMemoryActiveAvatarId = id;
  try {
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem(STORAGE_KEY_PERMANENT_AVATAR, id);
      localStorage.setItem(STORAGE_KEY_SELECTED_3D_AVATAR, id);
      if (id === 'classic') {
        localStorage.setItem('zoya_saved_avatar_style_v1', id);
      }
    }
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('zoya-avatar-selected', { detail: { avatarId: id } }));
    }
  } catch {}
}

export function getIs3DAvatarEnabled(): boolean {
  try {
    const saved = localStorage.getItem(STORAGE_KEY_3D_AVATAR_ENABLED);
    return saved !== null ? saved === 'true' : true; // Default ON
  } catch {
    return true;
  }
}

export function saveIs3DAvatarEnabled(enabled: boolean): void {
  try {
    localStorage.setItem(STORAGE_KEY_3D_AVATAR_ENABLED, String(enabled));
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('zoya-avatar-enabled-changed', { detail: { enabled } }));
    }
  } catch {}
}

export function get3DAvatarScale(): number {
  try {
    const saved = localStorage.getItem(STORAGE_KEY_3D_AVATAR_SCALE);
    if (saved) {
      const parsed = parseFloat(saved);
      if (!isNaN(parsed) && parsed >= 0.6 && parsed <= 1.6) return parsed;
    }
  } catch {}
  return 1.0;
}

export function save3DAvatarScale(scale: number): void {
  try {
    localStorage.setItem(STORAGE_KEY_3D_AVATAR_SCALE, String(scale));
  } catch {}
}

export function get3DAvatarOffsetY(): number {
  try {
    const saved = localStorage.getItem(STORAGE_KEY_3D_AVATAR_OFFSET_Y);
    if (saved) {
      const parsed = parseFloat(saved);
      if (!isNaN(parsed) && parsed >= -80 && parsed <= 80) return parsed;
    }
  } catch {}
  return 0;
}

export function save3DAvatarOffsetY(offset: number): void {
  try {
    localStorage.setItem(STORAGE_KEY_3D_AVATAR_OFFSET_Y, String(offset));
  } catch {}
}

export function get3DAvatarLiveliness(): number {
  try {
    const saved = localStorage.getItem(STORAGE_KEY_3D_AVATAR_LIVELINESS);
    if (saved) {
      const parsed = parseFloat(saved);
      if (!isNaN(parsed) && parsed >= 0.2 && parsed <= 1.8) return parsed;
    }
  } catch {}
  return 1.0; // Default liveliness K = 1.0
}

export function save3DAvatarLiveliness(k: number): void {
  try {
    const clamped = Math.max(0.2, Math.min(1.8, k));
    localStorage.setItem(STORAGE_KEY_3D_AVATAR_LIVELINESS, String(clamped));
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('zoya-liveliness-changed', { detail: clamped }));
    }
  } catch {}
}

export function getSelected3DAvatar(id?: string): Anime3DAvatar {
  const all = getAllAvatars();
  const targetId = id || getSaved3DAvatarId();
  return all.find((a) => a.id === targetId) || ANIME_3D_AVATARS[0];
}
