import React from 'react';
import { 
  Youtube, 
  PhoneCall, 
  MessageCircle, 
  Code2, 
  Palette, 
  Mic, 
  MessageSquare 
} from 'lucide-react';

interface ZoyaQuickActionsBarProps {
  onOpenAppLauncher: () => void;
  onOpenPhoneCall: () => void;
  onOpenMessageComposer: () => void;
  onOpenWebsiteBuilder: () => void;
  onOpenSketchCanvas: () => void;
  onOpenVoiceCall: () => void;
  onOpenTextChat: () => void;
  onOpenPythonStudio?: () => void;
  onOpenCodingAgent?: () => void;
}

export const ZoyaQuickActionsBar: React.FC<ZoyaQuickActionsBarProps> = ({
  onOpenAppLauncher,
  onOpenPhoneCall,
  onOpenMessageComposer,
  onOpenWebsiteBuilder,
  onOpenSketchCanvas,
  onOpenVoiceCall,
  onOpenTextChat,
  onOpenPythonStudio,
  onOpenCodingAgent,
}) => {
  const actions = [
    {
      id: 'app',
      label: 'YouTube / Apps',
      icon: Youtube,
      color: 'from-red-500 to-rose-600',
      border: 'border-red-500/30',
      onClick: onOpenAppLauncher,
    },
    {
      id: 'call',
      label: 'Call',
      icon: PhoneCall,
      color: 'from-emerald-400 to-teal-500',
      border: 'border-emerald-500/30',
      onClick: onOpenPhoneCall,
    },
    {
      id: 'message',
      label: 'WhatsApp',
      icon: MessageCircle,
      color: 'from-green-500 to-emerald-600',
      border: 'border-green-500/30',
      onClick: onOpenMessageComposer,
    },
    {
      id: 'website',
      label: 'Website',
      icon: Code2,
      color: 'from-purple-500 to-indigo-600',
      border: 'border-purple-500/30',
      onClick: onOpenWebsiteBuilder,
    },
    {
      id: 'sketch',
      label: 'Sketch',
      icon: Palette,
      color: 'from-amber-400 to-pink-500',
      border: 'border-amber-500/30',
      onClick: onOpenSketchCanvas,
    },
    {
      id: 'voice',
      label: 'Voice Call',
      icon: Mic,
      color: 'from-sky-400 to-blue-600',
      border: 'border-sky-500/30',
      onClick: onOpenVoiceCall,
    },
    {
      id: 'chat',
      label: 'Ask Chat',
      icon: MessageSquare,
      color: 'from-pink-500 to-rose-500',
      border: 'border-pink-500/30',
      onClick: onOpenTextChat,
    },
    {
      id: 'python',
      label: 'Python Studio',
      icon: Code2,
      color: 'from-blue-600 via-cyan-500 to-yellow-500',
      border: 'border-cyan-500/40',
      onClick: onOpenPythonStudio || onOpenWebsiteBuilder,
    },
    {
      id: 'agent',
      label: 'Coding Agent',
      icon: Code2,
      color: 'from-purple-600 via-indigo-600 to-violet-500',
      border: 'border-purple-500/40',
      onClick: onOpenCodingAgent,
    },
  ];

  return (
    <div className="w-full max-w-xl mx-auto px-4 py-1">
      <div className="flex items-center justify-start sm:justify-center gap-2 overflow-x-auto pb-1 no-scrollbar">
        {actions.map((act) => {
          const Icon = act.icon;
          return (
            <button
              key={act.id}
              onClick={act.onClick}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-slate-900/80 hover:bg-slate-850 border ${act.border} hover:scale-105 transition-all text-xs font-semibold text-slate-200 shrink-0 shadow-sm group`}
            >
              <div className={`w-5 h-5 rounded-full bg-gradient-to-tr ${act.color} flex items-center justify-center text-white shadow-xs`}>
                <Icon className="w-2.5 h-2.5" />
              </div>
              <span className="text-[11px] font-sans">{act.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
