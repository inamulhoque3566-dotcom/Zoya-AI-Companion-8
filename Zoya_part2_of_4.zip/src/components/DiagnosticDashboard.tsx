import React, { useState, useEffect, useRef } from 'react';
import type { ExtractedFile } from '../types/zip';
import { 
  runFullSystemDiagnostics, 
  CRITICAL_PROJECT_FILES,
  type SystemHealthReport,
  type ProblemSeverity,
  type DiagnosticProblemItem
} from '../services/systemDiagnosticEngine';
import { micStateMachine, type MicStateSnapshot } from '../services/speech/MicStateMachine';
import { voiceTelemetry, type VoiceTelemetrySnapshot } from '../services/voiceTelemetry';
import { agentClient } from '../services/agent/agentClient';
import { 
  Activity, 
  Mic, 
  MicOff, 
  Volume2, 
  CheckCircle2, 
  AlertTriangle, 
  XCircle, 
  RefreshCw, 
  Terminal, 
  ShieldCheck, 
  Layers, 
  Check, 
  Cpu, 
  Key,
  Lock,
  ShieldAlert,
  FileCode,
  Sliders,
  ChevronDown,
  ChevronUp
} from 'lucide-react';

interface DiagnosticDashboardProps {
  files: ExtractedFile[];
}

export const DiagnosticDashboard: React.FC<DiagnosticDashboardProps> = ({ files }) => {
  const [report, setReport] = useState<SystemHealthReport | null>(null);
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [consoleExported, setConsoleExported] = useState<boolean>(false);

  // Tab navigation
  const [problemFilter, setProblemFilter] = useState<'ALL' | ProblemSeverity>('ALL');
  const [activeSubsystemCategory, setActiveSubsystemCategory] = useState<'all' | 'audio' | 'tts' | 'avatar' | 'gemini' | 'files'>('all');
  const [showInteractiveLabs, setShowInteractiveLabs] = useState<boolean>(true);

  // Live Mic Test State
  const [isMicTesting, setIsMicTesting] = useState<boolean>(false);
  const [micVolume, setMicVolume] = useState<number>(0);
  const [micFrequencyData, setMicFrequencyData] = useState<number[]>(new Array(16).fill(0));
  const [micError, setMicError] = useState<string | null>(null);

  const audioContextRef = useRef<AudioContext | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const animationFrameRef = useRef<number | null>(null);

  // Live 3-Tier Neural TTS Test State
  const [ttsText, setTtsText] = useState<string>(
    'नमस्ते! जोया वॉयस पाइपलाइन, 3-टियर न्यूरल टीटीएस और वेब ऑडियो सब कुछ 100% सही तरीके से काम कर रहा है।'
  );
  const [testingEngine, setTestingEngine] = useState<string | null>(null);
  const [isServerTtsTesting, setIsServerTtsTesting] = useState<boolean>(false);
  const [serverTtsResult, setServerTtsResult] = useState<string | null>(null);
  const activeAudioRef = useRef<HTMLAudioElement | null>(null);

  // Live 9-Stage Voice Pipeline Telemetry + Mic Permission Snapshot
  const [voiceTelemetrySnap, setVoiceTelemetrySnap] = useState<VoiceTelemetrySnapshot>(() =>
    voiceTelemetry.getSnapshot()
  );
  const [micSnapshot, setMicSnapshot] = useState<MicStateSnapshot>(() => micStateMachine.getSnapshot());

  useEffect(() => {
    const unsubTelemetry = voiceTelemetry.subscribe(setVoiceTelemetrySnap);
    const unsubMic = micStateMachine.subscribe(setMicSnapshot);
    void micStateMachine.refreshMicPermission();
    executeDiagnostic();
    return () => {
      unsubTelemetry();
      unsubMic();
      stopMicTest();
      if (activeAudioRef.current) {
        try {
          activeAudioRef.current.pause();
          activeAudioRef.current.src = '';
        } catch {}
        activeAudioRef.current = null;
      }
    };
  }, [files]);

  const executeDiagnostic = async () => {
    setIsRunning(true);
    try {
      const res = await runFullSystemDiagnostics(files);
      setReport(res);
    } catch (err) {
      console.error('Diagnostic error:', err);
    } finally {
      setIsRunning(false);
    }
  };

  // Live Microphone Test Functions
  const startMicTest = async () => {
    setMicError(null);
    try {
      micStateMachine.requestPauseForCall('voice_call');
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true },
      });
      mediaStreamRef.current = stream;

      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      const ctx = new AudioCtx();
      audioContextRef.current = ctx;

      const source = ctx.createMediaStreamSource(stream);
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 64;
      source.connect(analyser);

      const bufferLength = analyser.frequencyBinCount;
      const dataArray = new Uint8Array(bufferLength);

      setIsMicTesting(true);

      const updateMeter = () => {
        analyser.getByteFrequencyData(dataArray);
        let sum = 0;
        const bars: number[] = [];
        const step = Math.floor(bufferLength / 16) || 1;
        for (let i = 0; i < 16; i++) {
          const val = dataArray[i * step] || 0;
          bars.push(val);
          sum += val;
        }
        const avg = Math.round(sum / bufferLength);
        setMicVolume(Math.min(100, Math.round((avg / 128) * 100)));
        setMicFrequencyData(bars);

        animationFrameRef.current = requestAnimationFrame(updateMeter);
      };

      updateMeter();
    } catch (err: unknown) {
      const e = err as { name?: string; message?: string };
      console.warn('[DIAGNOSTICS] getUserMedia failed:', e?.name, e?.message);
      setMicError('माइक की अनुमति नहीं मिली। ब्राउज़र में Allow करो या ऐप को नए टैब में खोलो।');
      stopMicTest();
    }
  };

  const stopMicTest = () => {
    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current);
      animationFrameRef.current = null;
    }
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach((t) => t.stop());
      mediaStreamRef.current = null;
    }
    if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
      audioContextRef.current.close().catch(() => {});
      audioContextRef.current = null;
    }
    setIsMicTesting(false);
    setMicVolume(0);
    setMicFrequencyData(new Array(16).fill(0));
    micStateMachine.requestResumeAfterCall('voice_call');
  };

  const stopActiveAudio = () => {
    if (activeAudioRef.current) {
      try {
        activeAudioRef.current.pause();
        activeAudioRef.current.src = '';
      } catch {}
      activeAudioRef.current = null;
    }
    setIsServerTtsTesting(false);
    setTestingEngine(null);
  };

  const handleTestTtsEngine = async (forceEngine?: 'elevenlabs' | 'elevenlabs-turbo' | 'gemini-flash' | 'gemini-tts' | 'gemini-live') => {
    if (isServerTtsTesting) {
      stopActiveAudio();
      return;
    }

    stopActiveAudio();
    setIsServerTtsTesting(true);
    const engineLabel = forceEngine === 'elevenlabs' || forceEngine === 'elevenlabs-turbo'
      ? 'Primary: ElevenLabs TTS (eleven_turbo_v2_5)'
      : forceEngine === 'gemini-flash' || forceEngine === 'gemini-tts'
      ? 'Backup: Google Gemini Flash TTS (gemini-3.8-flash-lite-tts)'
      : forceEngine === 'gemini-live'
      ? 'Fallback: Google Gemini Live API (gemini-3.8-live)'
      : 'Auto Priority Chain (ElevenLabs Primary → Gemini Flash Backup → Gemini Live Fallback)';

    setTestingEngine(forceEngine || 'auto');
    setServerTtsResult(`${engineLabel} से ऑडियो जनरेट हो रहा है...`);

    try {
      let elevenLabsVoiceId = '';
      try {
        elevenLabsVoiceId = localStorage.getItem('zoya_elevenlabs_voice_id') || '';
      } catch {}

      const res = await fetch('/api/tts', {
        method: 'POST',
        headers: agentClient.getOwnerFetchHeaders({ 'Content-Type': 'application/json' }),
        credentials: 'include',
        body: JSON.stringify({
          text: ttsText,
          language: 'hi-IN',
          forceEngine,
          elevenLabsVoiceId: elevenLabsVoiceId || undefined,
        }),
      });

      const contentType = res.headers.get('content-type') || '';
      let data: any = null;
      if (contentType.includes('application/json')) {
        try {
          data = await res.json();
        } catch {}
      }

      if (data?.audioData) {
        const mime = data.mimeType || 'audio/wav';
        const audio = new Audio(`data:${mime};base64,${data.audioData}`);
        activeAudioRef.current = audio;
        audio.onended = () => {
          activeAudioRef.current = null;
          setIsServerTtsTesting(false);
          setTestingEngine(null);
          setServerTtsResult(`✓ ऑडियो प्लेबैक पूर्ण (${data.engineUsed || 'Neural TTS'} · ${mime})`);
        };
        audio.onerror = () => {
          activeAudioRef.current = null;
          setIsServerTtsTesting(false);
          setTestingEngine(null);
          setServerTtsResult(`⚠ HTML5 ऑडियो प्लेबैक एरर (${data.engineUsed})`);
        };
        await audio.play();
        setServerTtsResult(`▶ ध्वनि बज रही है: ${data.engineUsed} (${mime}, ${Math.round(data.audioData.length * 0.75 / 1024)} KB)`);
        return;
      } else if (data?.quotaExhausted) {
        setServerTtsResult(`⏳ जेमिनी फ्री टियर 3 RPM लिमिट सक्रिय (${data.retryAfter || 45}s शेष) · प्राकृतिक वॉइस सुरक्षित`);
      } else if (data?.error) {
        setServerTtsResult(`⚠ ${data.error}`);
      } else {
        setServerTtsResult('⚠ ऑडियो जनरेशन असफल');
      }
    } catch (err: any) {
      setServerTtsResult(`त्रुटि: ${err?.message || 'कनेक्शन समस्या'}`);
    } finally {
      if (!activeAudioRef.current) {
        setIsServerTtsTesting(false);
        setTestingEngine(null);
      }
    }
  };

  const handleExportConsole = () => {
    if (!report) return;
    console.clear();
    console.log('%c======================================================', 'color: #38bdf8');
    console.log('%c  ZOYA & OMNIZIP SYSTEM HEALTH & DIAGNOSTIC REPORT    ', 'color: #38bdf8; font-weight: bold; font-size: 14px');
    console.log('%c======================================================', 'color: #38bdf8');
    console.log(`Generated At: ${report.timestamp} | Health Score: ${report.score}%`);
    console.log(`Summary: Total Problems: ${report.summary.totalProblems} | Critical: ${report.summary.criticalCount} | High: ${report.summary.highCount} | Medium: ${report.summary.mediumCount} | Low: ${report.summary.lowCount}`);
    console.table(
      report.problems.map((p) => ({
        Severity: p.severity,
        Location: `${p.file}:${p.line}`,
        Title: p.title,
        Status: p.status,
      }))
    );
    console.log('%c======================================================', 'color: #38bdf8');
    setConsoleExported(true);
    setTimeout(() => setConsoleExported(false), 2500);
  };

  const filteredProblems = report?.problems.filter((p) => {
    if (problemFilter === 'ALL') return true;
    return p.severity === problemFilter;
  }) || [];

  const filteredSubsystemChecks = report?.checks.filter((c) => {
    if (activeSubsystemCategory === 'all') return true;
    return c.category === activeSubsystemCategory;
  }) || [];

  const filePathsSet = new Set(files.map((f) => f.path.replace(/^\//, '')));

  return (
    <div className="space-y-6 pb-12 font-sans text-slate-100 max-w-7xl mx-auto">
      {/* =========================================================================
          SECTION 1: MASTER SUMMARY HEADER (Required by Prompt)
          ========================================================================= */}
      <div className="bg-gradient-to-br from-slate-900 via-slate-900 to-slate-950 rounded-2xl border border-slate-800 p-5 sm:p-6 shadow-2xl relative overflow-hidden">
        {/* Top bar with title and action buttons */}
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2.5">
              <div className="p-2.5 bg-sky-500/10 border border-sky-500/20 rounded-xl text-sky-400 shrink-0">
                <Activity className="w-6 h-6" />
              </div>
              <div>
                <h2 className="text-lg sm:text-xl font-bold text-white tracking-tight flex items-center gap-2">
                  <span>पूर्ण सिस्टम डायग्नोस्टिक्स व सुरक्षा ऑडिट</span>
                  <span className="text-xs font-mono font-medium px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                    Live Audit
                  </span>
                </h2>
                <p className="text-xs text-slate-400 font-mono mt-0.5">
                  Syntax, Runtime, Security, API Key Leaks, Voice, and Architecture Diagnostics
                </p>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-2.5 shrink-0 flex-wrap">
            <button
              onClick={executeDiagnostic}
              disabled={isRunning}
              className="flex items-center gap-2 px-4 py-2.5 text-xs font-semibold text-white bg-sky-600 hover:bg-sky-500 disabled:opacity-50 rounded-xl transition-all shadow-md shadow-sky-950/50 cursor-pointer active:scale-95"
            >
              <RefreshCw className={`w-4 h-4 ${isRunning ? 'animate-spin' : ''}`} />
              <span>{isRunning ? 'जाँच जारी है...' : 'Re-run Diagnostics'}</span>
            </button>

            <button
              onClick={handleExportConsole}
              className="flex items-center gap-1.5 px-3.5 py-2.5 text-xs font-medium text-slate-300 bg-slate-800 hover:bg-slate-700 border border-slate-700/80 rounded-xl transition-colors cursor-pointer"
              title="ब्राउज़र कंसोल (F12) में संपूर्ण टेबल निर्यात करें"
            >
              {consoleExported ? <Check className="w-4 h-4 text-emerald-400" /> : <Terminal className="w-4 h-4" />}
              <span>{consoleExported ? 'निर्यातित' : 'Console Report'}</span>
            </button>
          </div>
        </div>

        {/* Diagnostic Problem Counts Summary Cards (Real Runtime Counts — Zero Fake Greens) */}
        {report && (
          <div className="mt-6 pt-5 border-t border-slate-800/80 grid grid-cols-2 sm:grid-cols-5 gap-3">
            {/* Total Problems */}
            <div className="p-3.5 bg-slate-950/90 rounded-xl border border-slate-800 flex flex-col justify-between col-span-2 sm:col-span-1">
              <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider">
                Total Problems
              </span>
              <div className="flex items-baseline justify-between mt-1">
                <span className="text-2xl font-extrabold text-white font-mono tabular-nums">
                  {report.summary.totalProblems}
                </span>
                <span
                  className={`text-[10px] font-mono px-1.5 py-0.5 rounded border ${
                    report.summary.unresolvedCount > 0
                      ? 'text-rose-300 bg-rose-950/60 border-rose-700/50'
                      : 'text-emerald-400 bg-emerald-950/50 border-emerald-800/40'
                  }`}
                >
                  {report.summary.unresolvedCount > 0
                    ? `${report.summary.unresolvedCount} Unresolved`
                    : 'All Resolved'}
                </span>
              </div>
            </div>

            {/* Critical */}
            <div className="p-3.5 bg-rose-950/30 rounded-xl border border-rose-900/50 flex flex-col justify-between">
              <div className="flex items-center gap-1.5 text-rose-400 text-xs font-semibold">
                <div className={`w-2 h-2 rounded-full bg-rose-500 ${report.summary.unresolvedCritical > 0 ? 'animate-pulse' : ''}`} />
                <span>CRITICAL</span>
              </div>
              <div className="flex items-baseline justify-between mt-1">
                <span className="text-2xl font-extrabold text-rose-400 font-mono tabular-nums">
                  {report.summary.criticalCount}
                </span>
                <span className={`text-[10px] font-mono ${report.summary.unresolvedCritical > 0 ? 'text-rose-300 font-bold' : 'text-slate-400'}`}>
                  {report.summary.unresolvedCritical} Unresolved
                </span>
              </div>
            </div>

            {/* High */}
            <div className="p-3.5 bg-amber-950/30 rounded-xl border border-amber-900/50 flex flex-col justify-between">
              <div className="flex items-center gap-1.5 text-amber-400 text-xs font-semibold">
                <div className="w-2 h-2 rounded-full bg-amber-500" />
                <span>HIGH</span>
              </div>
              <div className="flex items-baseline justify-between mt-1">
                <span className="text-2xl font-extrabold text-amber-400 font-mono tabular-nums">
                  {report.summary.highCount}
                </span>
                <span className={`text-[10px] font-mono ${report.summary.unresolvedHigh > 0 ? 'text-amber-300 font-bold' : 'text-slate-400'}`}>
                  {report.summary.unresolvedHigh} Unresolved
                </span>
              </div>
            </div>

            {/* Medium */}
            <div className="p-3.5 bg-yellow-950/30 rounded-xl border border-yellow-900/50 flex flex-col justify-between">
              <div className="flex items-center gap-1.5 text-yellow-400 text-xs font-semibold">
                <div className="w-2 h-2 rounded-full bg-yellow-500" />
                <span>MEDIUM</span>
              </div>
              <div className="flex items-baseline justify-between mt-1">
                <span className="text-2xl font-extrabold text-yellow-300 font-mono tabular-nums">
                  {report.summary.mediumCount}
                </span>
                <span className={`text-[10px] font-mono ${report.summary.unresolvedMedium > 0 ? 'text-yellow-300 font-bold' : 'text-slate-400'}`}>
                  {report.summary.unresolvedMedium} Unresolved
                </span>
              </div>
            </div>

            {/* Low */}
            <div className="p-3.5 bg-emerald-950/30 rounded-xl border border-emerald-900/50 flex flex-col justify-between">
              <div className="flex items-center gap-1.5 text-emerald-400 text-xs font-semibold">
                <div className="w-2 h-2 rounded-full bg-emerald-500" />
                <span>LOW</span>
              </div>
              <div className="flex items-baseline justify-between mt-1">
                <span className="text-2xl font-extrabold text-emerald-400 font-mono tabular-nums">
                  {report.summary.lowCount}
                </span>
                <span className={`text-[10px] font-mono ${report.summary.unresolvedLow > 0 ? 'text-emerald-300 font-bold' : 'text-slate-400'}`}>
                  {report.summary.unresolvedLow} Unresolved
                </span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* =========================================================================
          LIVE 9-STAGE VOICE PIPELINE TELEMETRY MONITOR
          ========================================================================= */}
      <div className="bg-slate-900 rounded-2xl border border-slate-800 p-5 sm:p-6 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-sky-500/10 border border-sky-500/20 rounded-xl text-sky-400">
              <Mic className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <span>Live Voice Pipeline Stages (9-Stage Real Telemetry)</span>
              </h3>
              <p className="text-xs text-slate-400 font-mono mt-0.5">
                Mic State: <strong className="text-slate-200">{micSnapshot.state}</strong> · Permission:{' '}
                <strong className={micSnapshot.hasMicPermission ? 'text-emerald-400' : 'text-amber-300'}>
                  {micSnapshot.permissionState}
                </strong>
              </p>
            </div>
          </div>
          <span className="text-[11px] font-mono px-2.5 py-1 rounded bg-slate-950 text-slate-300 border border-slate-800">
            Engine: <strong className="text-sky-300">{micSnapshot.voiceEngine}</strong>
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {([
            'mic',
            'recording',
            'stt',
            'wakeWord',
            'userMessage',
            'geminiApi',
            'aiResponse',
            'tts',
            'speaker',
          ] as const).map((stageKey) => {
            const st = voiceTelemetrySnap[stageKey];
            const isOk = st.health === 'ok';
            const isFail = st.health === 'fail';
            return (
              <div
                key={st.id}
                data-testid={`voice-stage-${st.id}`}
                className={`p-3.5 rounded-xl border flex flex-col justify-between space-y-1.5 ${
                  isOk
                    ? 'bg-emerald-950/20 border-emerald-800/50'
                    : isFail
                    ? 'bg-rose-950/30 border-rose-800/60'
                    : 'bg-slate-950/80 border-slate-800/90'
                }`}
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs font-semibold text-slate-200">{st.label}</span>
                  <span
                    className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded border ${
                      isOk
                        ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/40'
                        : isFail
                        ? 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                        : 'bg-slate-800/80 text-slate-300 border-slate-700'
                    }`}
                  >
                    {st.stateText}
                  </span>
                </div>
                <p className="text-[11px] font-mono text-slate-400 break-words leading-relaxed">
                  {st.error ? `${st.detail} (${st.error})` : st.detail}
                </p>
              </div>
            );
          })}
        </div>
      </div>

      {/* =========================================================================
          SECTION 2: API KEY / SECRET LEAK CHECK (Required by Prompt)
          ========================================================================= */}
      <div className="bg-slate-900 rounded-2xl border border-slate-800 p-5 sm:p-6 shadow-xl space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-emerald-500/10 border border-emerald-500/20 rounded-xl text-emerald-400">
              <Lock className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <span>API Key Security & Runtime Audit</span>
                {report?.apiKeySecurity && (
                  <span
                    className={`text-[11px] font-mono font-semibold px-2 py-0.5 rounded border ${
                      report.apiKeySecurity.overallStatus === 'PASS'
                        ? 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30'
                        : 'bg-rose-500/10 text-rose-300 border-rose-500/30'
                    }`}
                  >
                    {report.apiKeySecurity.overallStatus === 'PASS' ? 'ALL CHECKS PASS' : 'CHECK FAILURES'}
                  </span>
                )}
              </h3>
              <p className="text-xs text-slate-400 font-mono mt-0.5">
                Live Runtime Verification: Auth Probes (401), Server Proxy Isolation, and Storage Scan
              </p>
            </div>
          </div>
          <div className="text-xs font-mono text-slate-400 bg-slate-950 px-3 py-1.5 rounded-lg border border-slate-800/80">
            Secret Policy: <strong className="text-sky-400">Yes/No Status Only (Zero Key Exposure)</strong>
          </div>
        </div>

        {/* 6 Live Runtime Security Checks (PASS / FAIL) */}
        {report?.apiKeySecurity && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {report.apiKeySecurity.checks.map((check) => {
              const isPass = check.status === 'PASS';
              return (
                <div
                  key={check.id}
                  className="p-3.5 bg-slate-950/80 rounded-xl border border-slate-800/90 flex flex-col justify-between space-y-2 hover:border-slate-700 transition-colors"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-slate-200">
                      {check.name}
                    </span>
                    <span
                      className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded ${
                        isPass
                          ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                          : 'bg-rose-500/10 text-rose-400 border border-rose-500/30'
                      }`}
                    >
                      {check.status}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 font-mono leading-relaxed">
                    {check.details}
                  </p>
                </div>
              );
            })}
          </div>
        )}

        {/* Key Configuration Status Table (Yes / No only; zero key substrings) */}
        <div className="mt-4 pt-4 border-t border-slate-800/80 space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider font-mono flex items-center gap-1.5">
              <Key className="w-3.5 h-3.5 text-sky-400" />
              <span>Key Configuration Status & Storage Audit</span>
            </h4>
            <span className="text-[10px] text-slate-400 font-mono">
              6 Monitored Key Slots
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 text-[11px]">
                  <th className="py-2 px-3">Service / Secret</th>
                  <th className="py-2 px-3">Configured</th>
                  <th className="py-2 px-3">Storage Layer</th>
                  <th className="py-2 px-3">File Reference</th>
                  <th className="py-2 px-3">Security Level</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-slate-300">
                {report?.apiKeySecurity?.detectedKeys.map((key) => (
                  <tr key={key.id} className="hover:bg-slate-800/30 transition-colors">
                    <td className="py-2.5 px-3">
                      <div className="font-semibold text-slate-200">{key.label}</div>
                      <div className="text-[10px] text-slate-400">{key.service}</div>
                    </td>
                    <td className="py-2.5 px-3">
                      <span
                        className={`px-2 py-0.5 rounded border font-bold ${
                          key.configured
                            ? 'bg-emerald-950/70 text-emerald-300 border-emerald-700/60'
                            : 'bg-slate-950 text-slate-400 border-slate-800'
                        }`}
                      >
                        {key.configured ? 'Yes' : 'No'}
                      </span>
                    </td>
                    <td className="py-2.5 px-3">
                      <span className="text-slate-300 text-[11px]">
                        {key.source === 'encrypted_vault'
                          ? 'AES-256 Vault'
                          : key.source === 'server_env'
                          ? 'Server Env'
                          : key.source === 'server_config'
                          ? 'Server Config (0o600)'
                          : 'Not Configured'}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-[11px] text-slate-400">
                      {key.fileRef}
                    </td>
                    <td className="py-2.5 px-3">
                      <span
                        className={`text-[10px] px-2 py-0.5 rounded font-mono font-medium border ${
                          key.configured
                            ? 'bg-emerald-950 text-emerald-300 border-emerald-800/60'
                            : 'bg-slate-950 text-slate-400 border-slate-800'
                        }`}
                      >
                        {key.storageSecurity}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* =========================================================================
          SECTION 3: AUDITED PROBLEMS & EXACT FIXES (Required by Prompt)
          ========================================================================= */}
      <div className="bg-slate-900 rounded-2xl border border-slate-800 p-5 sm:p-6 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <ShieldAlert className="w-5 h-5 text-sky-400" />
              <span>Full Audited Problems & Exact Fixes Catalog</span>
            </h3>
            <p className="text-xs text-slate-400 font-mono mt-0.5">
              Ranked and sorted: Critical → High → Medium → Low ({report ? `${report.summary.unresolvedCount} unresolved, ${report.summary.totalProblems} total` : 'loading...'})
            </p>
          </div>

          {/* Severity Filters */}
          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-1">
            {(['ALL', 'CRITICAL', 'HIGH', 'MEDIUM', 'LOW'] as const).map((sev) => {
              const isSelected = problemFilter === sev;
              return (
                <button
                  key={sev}
                  onClick={() => setProblemFilter(sev)}
                  className={`px-3 py-1 rounded-lg text-xs font-mono font-semibold transition-all cursor-pointer whitespace-nowrap ${
                    isSelected
                      ? sev === 'CRITICAL'
                        ? 'bg-rose-600 text-white shadow-sm'
                        : sev === 'HIGH'
                        ? 'bg-amber-600 text-white shadow-sm'
                        : sev === 'MEDIUM'
                        ? 'bg-yellow-600 text-white shadow-sm'
                        : sev === 'LOW'
                        ? 'bg-emerald-600 text-white shadow-sm'
                        : 'bg-sky-600 text-white shadow-sm'
                      : 'bg-slate-950 text-slate-400 hover:text-slate-200 border border-slate-800'
                  }`}
                >
                  {sev}
                </button>
              );
            })}
          </div>
        </div>

        {/* Problems List */}
        <div className="space-y-3.5">
          {filteredProblems.map((p, idx) => {
            const isCritical = p.severity === 'CRITICAL';
            const isHigh = p.severity === 'HIGH';
            const isMed = p.severity === 'MEDIUM';

            return (
              <div
                key={p.id}
                className={`p-4 sm:p-5 rounded-xl border bg-slate-950/80 transition-all ${
                  isCritical
                    ? 'border-rose-900/60 shadow-[0_0_15px_rgba(244,63,94,0.06)]'
                    : isHigh
                    ? 'border-amber-900/50'
                    : isMed
                    ? 'border-yellow-900/40'
                    : 'border-slate-800'
                }`}
              >
                {/* Header row */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div className="flex items-center gap-2.5 flex-wrap">
                    <span
                      className={`text-[10px] font-mono font-extrabold px-2 py-0.5 rounded tracking-wider ${
                        isCritical
                          ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                          : isHigh
                          ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                          : isMed
                          ? 'bg-yellow-500/20 text-yellow-300 border border-yellow-500/40'
                          : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                      }`}
                    >
                      {p.severity}
                    </span>

                    <span className="text-xs font-mono text-slate-400 bg-slate-900 px-2 py-0.5 rounded border border-slate-800 flex items-center gap-1">
                      <FileCode className="w-3 h-3 text-sky-400" />
                      <span>{p.file}:{p.line}</span>
                    </span>

                    <span className="text-[10px] font-mono text-slate-500">#{p.id}</span>
                  </div>

                  <span
                    className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded border self-start sm:self-auto flex items-center gap-1 ${
                      p.status === 'UNRESOLVED'
                        ? 'bg-rose-950 text-rose-300 border-rose-700/70'
                        : 'bg-emerald-950 text-emerald-300 border-emerald-800/70'
                    }`}
                  >
                    {p.status === 'UNRESOLVED' ? (
                      <XCircle className="w-3 h-3 text-rose-400" />
                    ) : (
                      <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                    )}
                    <span>{p.status}</span>
                  </span>
                </div>

                {/* Title */}
                <h4 className="text-sm font-bold text-slate-100 mt-2.5">
                  {idx + 1}. {p.title}
                </h4>

                {/* What is wrong */}
                <div className="mt-2 text-xs space-y-1">
                  <span className="font-semibold text-rose-300 font-mono text-[11px] block">
                    ⚠ What is wrong:
                  </span>
                  <p className="text-slate-300 text-xs leading-relaxed pl-3 border-l-2 border-rose-500/40">
                    {p.whatIsWrong}
                  </p>
                </div>

                {/* Exact fix */}
                <div className="mt-2.5 text-xs space-y-1">
                  <span className="font-semibold text-emerald-400 font-mono text-[11px] block">
                    ✓ Exact Fix Applied:
                  </span>
                  <p className="text-slate-300 text-xs leading-relaxed pl-3 border-l-2 border-emerald-500/50">
                    {p.exactFix}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* =========================================================================
          SECTION 4: COLLAPSIBLE HARDWARE & SUBSYSTEM TEST STATION
          ========================================================================= */}
      <div className="bg-slate-900 rounded-2xl border border-slate-800 p-5 sm:p-6 shadow-xl space-y-5">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-indigo-500/10 border border-indigo-500/20 rounded-xl text-indigo-400">
              <Sliders className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <span>Interactive Hardware & Subsystem Verification Stations</span>
              </h3>
              <p className="text-xs text-slate-400 font-mono mt-0.5">
                Live Microphone Analyser, 3-Tier Neural TTS Streamer, and Architecture Check
              </p>
            </div>
          </div>

          <button
            onClick={() => setShowInteractiveLabs(!showInteractiveLabs)}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-mono text-slate-300 bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors cursor-pointer"
          >
            <span>{showInteractiveLabs ? 'Hide Labs' : 'Show Labs'}</span>
            {showInteractiveLabs ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          </button>
        </div>

        {showInteractiveLabs && (
          <div className="space-y-6">
            {/* Interactive Testers Grid (Mic & TTS) */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* SUB-TEST 1: LIVE MICROPHONE TEST */}
              <div className="bg-slate-950/80 rounded-xl border border-slate-800 p-5 space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="p-1.5 bg-sky-500/10 rounded-lg text-sky-400">
                      <Mic className="w-4 h-4" />
                    </div>
                    <h4 className="text-sm font-semibold text-slate-100">
                      1. लाइव माइक व ऑडियो इनपुट टेस्ट
                    </h4>
                  </div>
                  <span className="text-[10px] font-mono text-slate-400">
                    Web Audio Analyser
                  </span>
                </div>

                <p className="text-xs text-slate-400">
                  माइक का बटन दबाएं और बोलें। यह ऑडियो स्ट्रीम, डेसीबल स्तर और फ्रीक्वेंसी स्पेक्ट्रम की लाइव जाँच करता है।
                </p>

                {/* Equalizer Visualizer */}
                <div className="h-16 bg-slate-900 rounded-lg p-2.5 border border-slate-800 flex items-end justify-between gap-1">
                  {micFrequencyData.map((val, idx) => {
                    const heightPercent = isMicTesting ? Math.max(8, Math.round((val / 255) * 100)) : 8;
                    return (
                      <div
                        key={idx}
                        className="flex-1 bg-gradient-to-t from-sky-600 to-emerald-400 rounded-t transition-all duration-75"
                        style={{ height: `${heightPercent}%` }}
                      />
                    );
                  })}
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-xs font-mono text-slate-400">
                    <span>माइक स्तर:</span>
                    <span className="text-slate-100 font-bold tabular-nums">{micVolume}%</span>
                    <div className="w-16 h-1.5 bg-slate-800 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-emerald-400 transition-all duration-75"
                        style={{ width: `${micVolume}%` }}
                      />
                    </div>
                  </div>

                  {isMicTesting ? (
                    <button
                      onClick={stopMicTest}
                      className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-rose-200 bg-rose-950/80 border border-rose-800/60 hover:bg-rose-900 rounded-lg transition-colors cursor-pointer"
                    >
                      <MicOff className="w-3.5 h-3.5" />
                      <span>माइक बंद करें</span>
                    </button>
                  ) : (
                    <button
                      onClick={startMicTest}
                      className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-sky-600 hover:bg-sky-500 rounded-lg transition-colors cursor-pointer"
                    >
                      <Mic className="w-3.5 h-3.5" />
                      <span>माइक टेस्ट शुरू करें</span>
                    </button>
                  )}
                </div>

                {micError && (
                  <div className="p-2.5 bg-rose-950/70 border border-rose-800/80 rounded text-rose-300 text-xs font-mono">
                    {micError}
                  </div>
                )}
              </div>

              {/* SUB-TEST 2: LIVE 3-TIER NEURAL TTS TEST */}
              <div className="bg-slate-950/80 rounded-xl border border-slate-800 p-5 space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="p-1.5 bg-emerald-500/10 rounded-lg text-emerald-400">
                      <Volume2 className="w-4 h-4" />
                    </div>
                    <h4 className="text-sm font-semibold text-slate-100">
                      2. 3-टियर न्यूरल टीटीएस (Neural TTS) टेस्ट
                    </h4>
                  </div>
                  <span className="text-[10px] font-mono text-slate-400">
                    {report?.checks.find((c) => c.id === 'tts-robotic-voice-eliminated')?.status === 'pass'
                      ? 'Robotic Block Verified'
                      : 'Neural Priority Chain'}
                  </span>
                </div>

                <p className="text-xs text-slate-400">
                  प्राथमिक क्रम (1. ElevenLabs Turbo → 2. Gemini Flash → 3. Gemini Live) में टेस्ट करें:
                </p>

                <input
                  type="text"
                  value={ttsText}
                  onChange={(e) => setTtsText(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-slate-900 border border-slate-800 rounded-lg text-slate-200 font-mono focus:outline-none focus:border-emerald-500"
                />

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  <button
                    onClick={() => handleTestTtsEngine()}
                    disabled={isServerTtsTesting && testingEngine !== 'auto'}
                    className={`flex items-center justify-center gap-1 px-2.5 py-2 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                      testingEngine === 'auto'
                        ? 'bg-emerald-600 text-white shadow-sm'
                        : 'bg-emerald-950/80 hover:bg-emerald-900 text-emerald-300 border border-emerald-700/60'
                    }`}
                  >
                    <Volume2 className={`w-3.5 h-3.5 ${testingEngine === 'auto' ? 'animate-bounce' : ''}`} />
                    <span>Auto Failover</span>
                  </button>

                  <button
                    onClick={() => handleTestTtsEngine('elevenlabs')}
                    disabled={isServerTtsTesting && testingEngine !== 'elevenlabs'}
                    className={`flex items-center justify-center gap-1 px-2.5 py-2 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                      testingEngine === 'elevenlabs'
                        ? 'bg-purple-600 text-white shadow-sm'
                        : 'bg-purple-950/80 hover:bg-purple-900 text-purple-300 border border-purple-700/60'
                    }`}
                  >
                    <span>1. ElevenLabs</span>
                  </button>

                  <button
                    onClick={() => handleTestTtsEngine('gemini-flash')}
                    disabled={isServerTtsTesting && testingEngine !== 'gemini-flash'}
                    className={`flex items-center justify-center gap-1 px-2.5 py-2 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                      testingEngine === 'gemini-flash'
                        ? 'bg-sky-600 text-white shadow-sm'
                        : 'bg-sky-950/80 hover:bg-sky-900 text-sky-300 border border-sky-700/60'
                    }`}
                  >
                    <span>2. Gemini Flash</span>
                  </button>

                  <button
                    onClick={() => handleTestTtsEngine('gemini-live')}
                    disabled={isServerTtsTesting && testingEngine !== 'gemini-live'}
                    className={`flex items-center justify-center gap-1 px-2.5 py-2 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                      testingEngine === 'gemini-live'
                        ? 'bg-indigo-600 text-white shadow-sm'
                        : 'bg-indigo-950/80 hover:bg-indigo-900 text-indigo-300 border border-indigo-700/60'
                    }`}
                  >
                    <span>3. Gemini Live</span>
                  </button>
                </div>

                {serverTtsResult && (
                  <div className={`p-2 rounded text-xs font-mono ${
                    serverTtsResult.startsWith('✓') 
                      ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-800' 
                      : 'bg-slate-900 text-sky-300 border border-slate-800'
                  }`}>
                    {serverTtsResult}
                  </div>
                )}
              </div>
            </div>

            {/* Architecture Files Audit */}
            <div className="bg-slate-950/80 rounded-xl border border-slate-800 p-5 space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider font-mono flex items-center gap-2">
                  <Layers className="w-4 h-4 text-sky-400" />
                  <span>3. आर्किटेक्चर फाइल्स सत्यापन (Architecture Integrity)</span>
                </h4>
                <div className="text-xs font-mono text-slate-400">
                  स्थिति: <strong className="text-emerald-400">{CRITICAL_PROJECT_FILES.filter((f) => filePathsSet.has(f.path) || files.some((fl) => fl.path.endsWith(f.path))).length} / {CRITICAL_PROJECT_FILES.length} सत्यापित</strong>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
                {CRITICAL_PROJECT_FILES.map((item) => {
                  const isPresent = filePathsSet.has(item.path) || files.some((f) => f.path.endsWith(item.path));
                  return (
                    <div
                      key={item.path}
                      className={`p-2 rounded-lg border font-mono text-xs flex items-center justify-between transition-colors ${
                        isPresent
                          ? 'bg-slate-900/70 border-slate-800 text-slate-200'
                          : 'bg-rose-950/30 border-rose-900/60 text-rose-300'
                      }`}
                    >
                      <div className="min-w-0 pr-2">
                        <div className="font-semibold truncate text-[11px] text-slate-300">{item.label}</div>
                        <div className="text-[10px] text-slate-400 truncate">{item.path}</div>
                      </div>
                      {isPresent ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                      ) : (
                        <XCircle className="w-4 h-4 text-rose-400 shrink-0" />
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Subsystem Health Checks */}
            <div className="bg-slate-950/80 rounded-xl border border-slate-800 p-5 space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider font-mono flex items-center gap-2">
                  <Cpu className="w-4 h-4 text-sky-400" />
                  <span>4. सब-सिस्टम डायग्नोस्टिक परिणाम</span>
                </h4>

                <div className="flex items-center gap-1 text-xs">
                  {(['all', 'audio', 'tts', 'avatar', 'gemini', 'files'] as const).map((cat) => (
                    <button
                      key={cat}
                      onClick={() => setActiveSubsystemCategory(cat)}
                      className={`px-2 py-0.5 rounded text-[10px] font-mono transition-colors ${
                        activeSubsystemCategory === cat
                          ? 'bg-sky-600 text-white font-semibold'
                          : 'text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      {cat.toUpperCase()}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                {filteredSubsystemChecks.map((check) => {
                  const isPass = check.status === 'pass';
                  const isWarn = check.status === 'warn';
                  return (
                    <div
                      key={check.id}
                      className="p-3 bg-slate-900/70 rounded-lg border border-slate-800/80 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs"
                    >
                      <div className="space-y-0.5">
                        <div className="flex items-center gap-2">
                          {isPass ? (
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                          ) : isWarn ? (
                            <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                          ) : (
                            <XCircle className="w-3.5 h-3.5 text-rose-400 shrink-0" />
                          )}
                          <span className="font-semibold text-slate-200">{check.title}</span>
                          <span className="text-[10px] text-slate-400 font-mono">({check.category})</span>
                        </div>
                        <p className="text-slate-300 text-xs font-mono">{check.message}</p>
                      </div>

                      {check.latencyMs !== undefined && (
                        <div className="text-[11px] font-mono text-slate-400 shrink-0">
                          विलंबता: <strong className="text-slate-300 tabular-nums">{check.latencyMs} ms</strong>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
