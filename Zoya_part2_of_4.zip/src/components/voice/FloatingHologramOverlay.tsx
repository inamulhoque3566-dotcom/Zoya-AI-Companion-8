import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Zoya3DHologramView } from './Zoya3DHologramView';
import { hologramManager, ZoyaHologramConfig } from '../../services/zoyaHologramManager';
import { useAudioLevel } from '../../services/speech/audioLevelStore';
import { X, Minimize2, Maximize2, Mic, Settings, Volume2 } from 'lucide-react';

interface FloatingHologramOverlayProps {
  voiceStatus: 'idle' | 'listening' | 'processing' | 'speaking';
  audioLevel?: number;
  onTapToTalk?: () => void;
  onOpenSettings?: () => void;
  className?: string;
}

export const FloatingHologramOverlay: React.FC<FloatingHologramOverlayProps> = ({
  voiceStatus,
  audioLevel = 0,
  onTapToTalk,
  onOpenSettings,
  className = '',
}) => {
  const [config, setConfig] = useState<ZoyaHologramConfig>(() => hologramManager.getConfig());
  const [isMinimized, setIsMinimized] = useState<boolean>(false);
  const [isHovered, setIsHovered] = useState<boolean>(false);
  const [isAppInForeground, setIsAppInForeground] = useState<boolean>(() =>
    hologramManager.isAppForeground()
  );

  // Position state (persisted or clamped within window bounds)
  const [position, setPosition] = useState<{ x: number; y: number }>(() => {
    try {
      const saved = localStorage.getItem('zoya_hologram_overlay_pos');
      if (saved) {
        return JSON.parse(saved);
      }
    } catch {}
    // Default: Top-right corner
    return {
      x: typeof window !== 'undefined' ? Math.max(20, window.innerWidth - 220) : 20,
      y: 90,
    };
  });

  const [isDragging, setIsDragging] = useState<boolean>(false);
  const dragStartRef = useRef<{ startX: number; startY: number; origX: number; origY: number }>({
    startX: 0,
    startY: 0,
    origX: 0,
    origY: 0,
  });

  // Listen to configuration updates and foreground state from hologramManager
  useEffect(() => {
    const unsubscribeConfig = hologramManager.subscribe((newConfig) => {
      setConfig(newConfig);
    });
    const unsubscribeForeground = hologramManager.subscribeForeground((st) => {
      setIsAppInForeground(st.isAppInForeground);
    });
    return () => {
      unsubscribeConfig();
      unsubscribeForeground();
    };
  }, []);

  const storeAudioLevel = useAudioLevel();
  const effectiveAudioLevel = audioLevel > 0 ? audioLevel : storeAudioLevel;

  // Synchronize voice state to hologramManager & Android bridge
  useEffect(() => {
    hologramManager.notifyVoiceState(voiceStatus, effectiveAudioLevel);
  }, [voiceStatus, effectiveAudioLevel]);

  // Window bounds clamping on resize
  useEffect(() => {
    const handleResize = () => {
      setPosition((prev) => {
        const size = isMinimized ? 52 : config.baseSizePx;
        const maxX = Math.max(10, window.innerWidth - size - 16);
        const maxY = Math.max(10, window.innerHeight - size - 16);
        return {
          x: Math.min(Math.max(16, prev.x), maxX),
          y: Math.min(Math.max(16, prev.y), maxY),
        };
      });
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [config.baseSizePx, isMinimized]);

  // Mouse / Touch Dragging Handlers
  const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    // Ignore clicks on control buttons
    if ((e.target as HTMLElement).closest('button')) return;

    setIsDragging(true);
    dragStartRef.current = {
      startX: e.clientX,
      startY: e.clientY,
      origX: position.x,
      origY: position.y,
    };
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!isDragging) return;
    const deltaX = e.clientX - dragStartRef.current.startX;
    const deltaY = e.clientY - dragStartRef.current.startY;

    const currentSize = isMinimized
      ? 52
      : voiceStatus === 'speaking'
      ? config.baseSizePx * config.speakingEnlargeRatio
      : config.baseSizePx;

    const maxX = Math.max(10, window.innerWidth - currentSize - 16);
    const maxY = Math.max(10, window.innerHeight - currentSize - 16);

    const newX = Math.min(Math.max(16, dragStartRef.current.origX + deltaX), maxX);
    const newY = Math.min(Math.max(16, dragStartRef.current.origY + deltaY), maxY);

    setPosition({ x: newX, y: newY });
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!isDragging) return;
    setIsDragging(false);
    try {
      (e.currentTarget as HTMLElement).releasePointerCapture(e.pointerId);
      localStorage.setItem('zoya_hologram_overlay_pos', JSON.stringify(position));
    } catch {}
  };

  const handleToggleMinimize = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsMinimized((prev) => !prev);
  };

  const handleCloseOverlay = (e: React.MouseEvent) => {
    e.stopPropagation();
    hologramManager.setEnabled(false);
  };

  // Requirement 1 & 3: While user is inside Zoya, hide the floating overlay completely.
  // The floating hologram is displayed ONLY outside the app (e.g. over Android Home Screen or external apps).
  if (!config.enabled || isAppInForeground) {
    return null;
  }

  // Calculate dynamic dimensions
  const isSpeaking = voiceStatus === 'speaking';
  const effectiveSize = isMinimized
    ? 56
    : isSpeaking
    ? Math.round(config.baseSizePx * config.speakingEnlargeRatio)
    : config.baseSizePx;

  return (
    <div
      style={{
        transform: `translate3d(${position.x}px, ${position.y}px, 0)`,
        width: `${effectiveSize}px`,
        height: `${effectiveSize}px`,
        transition: isDragging
          ? 'none'
          : 'width 0.4s cubic-bezier(0.16, 1, 0.3, 1), height 0.4s cubic-bezier(0.16, 1, 0.3, 1), transform 0.05s ease-out',
      }}
      className={`fixed top-0 left-0 z-[9990] select-none touch-none cursor-grab active:cursor-grabbing ${className}`}
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      onPointerCancel={handlePointerUp}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      role="region"
      aria-label="Zoya 3D Floating Holographic Companion"
    >
      {isMinimized ? (
        // Minimized Orb State
        <div
          onClick={() => setIsMinimized(false)}
          className="w-14 h-14 rounded-full border-2 border-cyan-400 bg-slate-950/90 shadow-[0_0_20px_rgba(6,182,212,0.6)] flex items-center justify-center cursor-pointer transition-transform hover:scale-110 active:scale-95 group relative"
          title="Restore Zoya 3D Hologram"
        >
          <div className="absolute inset-0 rounded-full border border-purple-500/60 animate-ping opacity-30 pointer-events-none" />
          <span className="text-[11px] font-black tracking-widest text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 via-pink-400 to-amber-300">
            ZOYA
          </span>
          <div className="absolute -top-1 -right-1 w-3.5 h-3.5 rounded-full bg-cyan-400 border border-slate-900 flex items-center justify-center">
            <Maximize2 className="w-2 h-2 text-slate-950" />
          </div>
        </div>
      ) : (
        // Full 3D Hologram Companion
        <div className="relative w-full h-full flex items-center justify-center group">
          {/* Main 3D Holographic Rendering Canvas */}
          <div
            onClick={onTapToTalk}
            className="w-full h-full cursor-pointer relative"
            title="Click or tap to talk with Zoya"
          >
            <Zoya3DHologramView
              sizePx={effectiveSize}
              voiceStatus={voiceStatus}
              audioLevel={effectiveAudioLevel}
              config={config}
              interactive={true}
              onClick={onTapToTalk}
            />
          </div>

          {/* Quick HUD Overlay Controls (Revealed on hover or tap) */}
          <div
            className={`absolute -top-3.5 left-1/2 -translate-x-1/2 flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-slate-950/85 backdrop-blur-md border border-cyan-500/30 shadow-[0_4px_16px_rgba(0,0,0,0.6)] transition-opacity duration-200 z-20 ${
              isHovered || isSpeaking ? 'opacity-100' : 'opacity-0 pointer-events-none'
            }`}
          >
            {/* Status Badge */}
            <span
              className={`text-[9.5px] font-mono font-bold uppercase tracking-wider px-1.5 py-0.2 rounded ${
                isSpeaking
                  ? 'text-pink-300 bg-pink-950/70 border border-pink-500/40 animate-pulse'
                  : voiceStatus === 'listening'
                  ? 'text-emerald-300 bg-emerald-950/70 border border-emerald-500/40'
                  : voiceStatus === 'processing'
                  ? 'text-amber-300 bg-amber-950/70 border border-amber-500/40'
                  : 'text-cyan-300 bg-cyan-950/70'
              }`}
            >
              {isSpeaking ? 'Speaking' : voiceStatus}
            </span>

            {/* Mic / Talk Button */}
            {onTapToTalk && (
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  onTapToTalk();
                }}
                className="p-1 rounded-full text-slate-300 hover:text-white hover:bg-slate-800/80 transition-colors cursor-pointer"
                title="Tap to talk"
              >
                <Mic className="w-3 h-3 text-cyan-400" />
              </button>
            )}

            {/* Settings Quick Link */}
            {onOpenSettings && (
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  onOpenSettings();
                }}
                className="p-1 rounded-full text-slate-300 hover:text-white hover:bg-slate-800/80 transition-colors cursor-pointer"
                title="Hologram Settings"
              >
                <Settings className="w-3 h-3 text-purple-400" />
              </button>
            )}

            {/* Minimize Button */}
            <button
              type="button"
              onClick={handleToggleMinimize}
              className="p-1 rounded-full text-slate-300 hover:text-white hover:bg-slate-800/80 transition-colors cursor-pointer"
              title="Minimize to Orb"
            >
              <Minimize2 className="w-3 h-3 text-slate-300" />
            </button>

            {/* Close Overlay */}
            <button
              type="button"
              onClick={handleCloseOverlay}
              className="p-1 rounded-full text-slate-400 hover:text-rose-300 hover:bg-rose-950/40 transition-colors cursor-pointer"
              title="Hide Floating Hologram"
            >
              <X className="w-3 h-3" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
