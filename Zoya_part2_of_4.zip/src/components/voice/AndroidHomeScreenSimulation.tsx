import React, { useState, useEffect } from 'react';
import {
  hologramManager,
  ZoyaHologramConfig,
  ALL_22_HOLOGRAM_STYLES,
} from '../../services/zoyaHologramManager';
import { Zoya3DHologramView } from './Zoya3DHologramView';
import {
  Smartphone,
  Wifi,
  BatteryCharging,
  Search,
  Camera,
  MessageSquare,
  Phone,
  Compass,
  Settings,
  Folder,
  Youtube,
  Sparkles,
  ArrowLeft,
  Volume2,
  Mic,
  RotateCw,
  AlertCircle,
  ExternalLink,
  Layers,
  Check,
  X,
  Play,
  Pause,
} from 'lucide-react';

interface AndroidHomeScreenSimulationProps {
  isOpen: boolean;
  onClose: () => void;
  voiceStatus?: 'idle' | 'listening' | 'processing' | 'speaking' | 'error';
  audioLevel?: number;
  onTapToTalk?: () => void;
  onOpenSettings?: () => void;
}

export const AndroidHomeScreenSimulation: React.FC<AndroidHomeScreenSimulationProps> = ({
  isOpen,
  onClose,
  voiceStatus: initialVoiceStatus = 'idle',
  audioLevel: initialAudioLevel = 0,
  onTapToTalk,
  onOpenSettings,
}) => {
  const [config, setConfig] = useState<ZoyaHologramConfig>(() => hologramManager.getConfig());
  const [simulatedApp, setSimulatedApp] = useState<'home' | 'chrome' | 'messages' | 'notes'>('home');
  const [simVoiceState, setSimVoiceState] = useState<'idle' | 'listening' | 'processing' | 'speaking' | 'error'>('idle');
  const [simAudioLevel, setSimAudioLevel] = useState<number>(0);
  const [currentTime, setCurrentTime] = useState<string>('');
  const [currentDate, setCurrentDate] = useState<string>('');
  
  // Draggable position within the phone frame
  const [hologramPos, setHologramPos] = useState<{ x: number; y: number }>({ x: 210, y: 140 });
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [dragStart, setDragStart] = useState<{ startX: number; startY: number; origX: number; origY: number }>({
    startX: 0,
    startY: 0,
    origX: 210,
    origY: 140,
  });

  useEffect(() => {
    const unsub = hologramManager.subscribe((newCfg) => setConfig(newCfg));
    return () => unsub();
  }, []);

  // Sync clock
  useEffect(() => {
    const updateClock = () => {
      const now = new Date();
      setCurrentTime(
        now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false })
      );
      setCurrentDate(
        now.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })
      );
    };
    updateClock();
    const interval = setInterval(updateClock, 1000);
    return () => clearInterval(interval);
  }, []);

  // Update sim voice state if initial changes
  useEffect(() => {
    if (initialVoiceStatus) {
      setSimVoiceState(initialVoiceStatus);
    }
  }, [initialVoiceStatus]);

  if (!isOpen) return null;

  const activeStyle =
    ALL_22_HOLOGRAM_STYLES.find((s) => s.id === config.selectedStyleId || s.index === config.selectedStyleIndex) ||
    ALL_22_HOLOGRAM_STYLES[0];

  const isSpeaking = simVoiceState === 'speaking';
  const effectiveSize = isSpeaking
    ? Math.round(config.baseSizePx * config.speakingEnlargeRatio)
    : config.baseSizePx;

  // Drag handlers for overlay inside simulated device
  const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    setIsDragging(true);
    setDragStart({
      startX: e.clientX,
      startY: e.clientY,
      origX: hologramPos.x,
      origY: hologramPos.y,
    });
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!isDragging) return;
    const deltaX = e.clientX - dragStart.startX;
    const deltaY = e.clientY - dragStart.startY;
    
    // Bounds clamping within viewport/phone
    const minX = 10;
    const maxX = Math.max(20, window.innerWidth - effectiveSize - 20);
    const minY = 60;
    const maxY = Math.max(80, window.innerHeight - effectiveSize - 80);

    setHologramPos({
      x: Math.min(Math.max(minX, dragStart.origX + deltaX), maxX),
      y: Math.min(Math.max(minY, dragStart.origY + deltaY), maxY),
    });
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!isDragging) return;
    setIsDragging(false);
    try {
      (e.currentTarget as HTMLElement).releasePointerCapture(e.pointerId);
    } catch {}
  };

  const handleReturnToZoya = () => {
    hologramManager.setAppInForeground(true);
    onClose();
  };

  const triggerVoiceState = (state: 'idle' | 'listening' | 'processing' | 'speaking' | 'error') => {
    setSimVoiceState(state);
    if (state === 'listening') {
      setSimAudioLevel(0.8);
      hologramManager.notifyVoiceState('listening', 0.8);
    } else if (state === 'speaking') {
      setSimAudioLevel(0.65);
      hologramManager.notifyVoiceState('speaking', 0.65);
      // Smoothly return to idle after 4.5 seconds
      setTimeout(() => {
        setSimVoiceState('idle');
        setSimAudioLevel(0);
        hologramManager.notifyVoiceState('idle', 0);
      }, 4500);
    } else if (state === 'processing') {
      setSimAudioLevel(0.2);
      hologramManager.notifyVoiceState('processing', 0.2);
      setTimeout(() => {
        triggerVoiceState('speaking');
      }, 2000);
    } else {
      setSimAudioLevel(0);
      hologramManager.notifyVoiceState(state, 0);
    }
  };

  return (
    <div className="fixed inset-0 z-[99999] bg-slate-950/95 flex flex-col items-center justify-center overflow-hidden animate-fadeIn select-none">
      {/* Top Testing Header Bar */}
      <header className="w-full bg-[#0d0c1d] border-b border-[#30255c] px-4 py-2.5 flex items-center justify-between z-30 shrink-0">
        <div className="flex items-center gap-3">
          <button
            onClick={handleReturnToZoya}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-purple-600/30 hover:bg-purple-600/50 border border-purple-400/50 text-white text-xs font-bold transition-all cursor-pointer shadow-md active:scale-95"
          >
            <ArrowLeft className="w-4 h-4 text-purple-300" />
            <span>Return to Zoya App</span>
          </button>
          <span className="hidden sm:inline text-xs font-semibold text-slate-300">
            Simulating Android System (Outside Zoya)
          </span>
        </div>

        {/* Live Status & Hologram Setting Quick Toggle */}
        <div className="flex items-center gap-2.5">
          <div className="flex items-center gap-2 px-3 py-1 rounded-xl bg-[#1a1738] border border-[#3d2f70] text-xs">
            <span className="text-slate-400">Floating Hologram:</span>
            <button
              onClick={() => {
                const nextVal = !config.enabled;
                hologramManager.setEnabled(nextVal);
              }}
              className={`px-2.5 py-0.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                config.enabled
                  ? 'bg-emerald-500 text-slate-950 shadow-[0_0_10px_rgba(16,185,129,0.5)]'
                  : 'bg-rose-950 text-rose-300 border border-rose-500/40'
              }`}
            >
              {config.enabled ? 'ON (Active Outside)' : 'OFF'}
            </button>
          </div>

          <div className="hidden md:flex items-center gap-1.5 px-3 py-1 rounded-xl bg-[#15142b] border border-[#332b60] text-xs">
            <span className="text-slate-400">Environment:</span>
            <span className="text-cyan-300 font-medium">
              {simulatedApp === 'home'
                ? 'Android Home Screen'
                : simulatedApp === 'chrome'
                ? 'Google Chrome'
                : simulatedApp === 'messages'
                ? 'Messages'
                : 'Notes'}
            </span>
          </div>

          <button
            onClick={handleReturnToZoya}
            className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
            title="Close Simulation"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </header>

      {/* Main Screen: Simulated Android Phone Device */}
      <div className="relative flex-1 w-full flex items-center justify-center p-2 sm:p-4 overflow-hidden">
        <div className="relative w-full max-w-[420px] h-[92vh] max-h-[860px] rounded-[38px] border-[5px] border-slate-700/80 bg-black shadow-[0_25px_70px_rgba(0,0,0,0.95)] flex flex-col overflow-hidden ring-1 ring-white/10">
          
          {/* Android Status Bar */}
          <div className="w-full px-6 pt-2 pb-1 flex items-center justify-between text-white text-xs font-semibold tracking-wider z-20 shrink-0">
            <span>{currentTime || '10:45'}</span>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-bold text-slate-300">5G</span>
              <Wifi className="w-3.5 h-3.5 text-white" />
              <div className="flex items-center gap-0.5 text-emerald-400">
                <BatteryCharging className="w-4 h-4" />
                <span className="text-[11px]">98%</span>
              </div>
            </div>
          </div>

          {/* Device Display Screen Content */}
          <div className="relative flex-1 w-full overflow-hidden flex flex-col justify-between">
            {simulatedApp === 'home' ? (
              // 1. Android Home Screen Wallpaper & Apps
              <div className="absolute inset-0 bg-gradient-to-b from-[#0a0720] via-[#120f38] to-[#040212] flex flex-col justify-between p-5 select-none">
                {/* Subtle Nebula Ambient Glow */}
                <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-72 h-72 rounded-full bg-purple-600/15 blur-[60px] pointer-events-none" />
                <div className="absolute bottom-1/3 right-4 w-48 h-48 rounded-full bg-cyan-600/10 blur-[50px] pointer-events-none" />

                {/* Date & Weather At-A-Glance Widget */}
                <div className="mt-4 px-2 space-y-0.5 z-10">
                  <div className="text-xl font-medium text-white">{currentDate || 'Thu, Oct 31'}</div>
                  <div className="text-xs text-purple-200/70 flex items-center gap-1.5">
                    <span>24°C • Sunny</span>
                    <span>•</span>
                    <span>Bengaluru</span>
                  </div>
                </div>

                {/* Google Search Bar Pill */}
                <div className="mx-auto w-full max-w-[340px] px-4 py-2.5 rounded-full bg-white/10 backdrop-blur-xl border border-white/15 flex items-center justify-between shadow-lg z-10 mt-2">
                  <div className="flex items-center gap-2.5">
                    <span className="text-base font-black text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-rose-400 to-amber-400 font-sans">
                      G
                    </span>
                    <span className="text-xs text-slate-300/80">Search apps & web...</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Mic className="w-4 h-4 text-cyan-400" />
                    <Camera className="w-4 h-4 text-amber-400" />
                  </div>
                </div>

                {/* Home Screen App Grid */}
                <div className="grid grid-cols-4 gap-4 px-2 py-4 z-10">
                  {/* Phone */}
                  <div className="flex flex-col items-center gap-1">
                    <div className="w-13 h-13 rounded-2xl bg-emerald-500 flex items-center justify-center text-white shadow-md active:scale-95 transition-transform">
                      <Phone className="w-6 h-6" />
                    </div>
                    <span className="text-[11px] text-slate-200">Phone</span>
                  </div>

                  {/* Messages */}
                  <div
                    onClick={() => setSimulatedApp('messages')}
                    className="flex flex-col items-center gap-1 cursor-pointer"
                  >
                    <div className="w-13 h-13 rounded-2xl bg-blue-500 flex items-center justify-center text-white shadow-md active:scale-95 transition-transform">
                      <MessageSquare className="w-6 h-6" />
                    </div>
                    <span className="text-[11px] text-slate-200">Messages</span>
                  </div>

                  {/* Chrome */}
                  <div
                    onClick={() => setSimulatedApp('chrome')}
                    className="flex flex-col items-center gap-1 cursor-pointer"
                  >
                    <div className="w-13 h-13 rounded-2xl bg-gradient-to-tr from-rose-500 via-amber-400 to-emerald-500 flex items-center justify-center text-white shadow-md active:scale-95 transition-transform">
                      <Compass className="w-6 h-6 text-white" />
                    </div>
                    <span className="text-[11px] text-slate-200">Chrome</span>
                  </div>

                  {/* Camera */}
                  <div className="flex flex-col items-center gap-1">
                    <div className="w-13 h-13 rounded-2xl bg-slate-800 border border-slate-700 flex items-center justify-center text-white shadow-md active:scale-95 transition-transform">
                      <Camera className="w-6 h-6 text-slate-300" />
                    </div>
                    <span className="text-[11px] text-slate-200">Camera</span>
                  </div>

                  {/* Settings */}
                  <div className="flex flex-col items-center gap-1">
                    <div className="w-13 h-13 rounded-2xl bg-slate-700 flex items-center justify-center text-white shadow-md active:scale-95 transition-transform">
                      <Settings className="w-6 h-6 text-slate-300" />
                    </div>
                    <span className="text-[11px] text-slate-200">Settings</span>
                  </div>

                  {/* Files */}
                  <div className="flex flex-col items-center gap-1">
                    <div className="w-13 h-13 rounded-2xl bg-amber-500 flex items-center justify-center text-white shadow-md active:scale-95 transition-transform">
                      <Folder className="w-6 h-6" />
                    </div>
                    <span className="text-[11px] text-slate-200">Files</span>
                  </div>

                  {/* YouTube */}
                  <div className="flex flex-col items-center gap-1">
                    <div className="w-13 h-13 rounded-2xl bg-red-600 flex items-center justify-center text-white shadow-md active:scale-95 transition-transform">
                      <Youtube className="w-6 h-6" />
                    </div>
                    <span className="text-[11px] text-slate-200">YouTube</span>
                  </div>

                  {/* ZOYA AI APP ICON (Primary Shortcut back to Zoya App) */}
                  <div
                    onClick={handleReturnToZoya}
                    className="flex flex-col items-center gap-1 cursor-pointer group"
                    title="Tap to return inside Zoya App"
                  >
                    <div className="relative w-13 h-13 rounded-2xl bg-gradient-to-tr from-purple-700 via-indigo-600 to-pink-500 flex items-center justify-center text-white shadow-[0_0_18px_rgba(168,85,247,0.7)] group-hover:scale-105 group-active:scale-95 transition-transform border border-pink-300/50">
                      <Sparkles className="w-7 h-7 text-white animate-pulse" />
                      <span className="absolute -top-1 -right-1 w-3 h-3 rounded-full bg-cyan-400 border-2 border-slate-900" />
                    </div>
                    <span className="text-[11px] font-bold text-pink-300 truncate max-w-[64px]">
                      ZOYA AI
                    </span>
                  </div>
                </div>

                {/* Bottom App Dock */}
                <div className="w-full px-4 py-3 rounded-3xl bg-white/10 backdrop-blur-2xl border border-white/15 flex items-center justify-around z-10 mb-2">
                  <div className="w-11 h-11 rounded-2xl bg-emerald-500 flex items-center justify-center text-white shadow-sm">
                    <Phone className="w-5 h-5" />
                  </div>
                  <div
                    onClick={() => setSimulatedApp('messages')}
                    className="w-11 h-11 rounded-2xl bg-blue-500 flex items-center justify-center text-white shadow-sm cursor-pointer"
                  >
                    <MessageSquare className="w-5 h-5" />
                  </div>
                  <div
                    onClick={() => setSimulatedApp('chrome')}
                    className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-rose-500 via-amber-400 to-emerald-500 flex items-center justify-center text-white shadow-sm cursor-pointer"
                  >
                    <Compass className="w-5 h-5 text-white" />
                  </div>
                  <div
                    onClick={handleReturnToZoya}
                    className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-purple-600 to-pink-500 flex items-center justify-center text-white shadow-[0_0_12px_rgba(236,72,153,0.6)] cursor-pointer"
                    title="Open Zoya"
                  >
                    <Sparkles className="w-5 h-5" />
                  </div>
                </div>
              </div>
            ) : simulatedApp === 'chrome' ? (
              // 2. External App: Google Chrome
              <div className="absolute inset-0 bg-[#202124] text-white flex flex-col justify-between select-none">
                {/* Chrome URL bar */}
                <div className="px-4 py-3 bg-[#2b2d30] border-b border-white/10 flex items-center justify-between gap-3">
                  <div className="flex-1 px-3 py-1.5 rounded-full bg-[#18191b] border border-white/10 text-xs text-slate-300 truncate">
                    https://news.google.com
                  </div>
                  <button
                    onClick={() => setSimulatedApp('home')}
                    className="text-xs px-2.5 py-1 rounded-lg bg-white/10 hover:bg-white/20 text-slate-200"
                  >
                    Exit to Home
                  </button>
                </div>
                {/* Simulated Web Page Content */}
                <div className="flex-1 p-5 overflow-y-auto space-y-4">
                  <div className="h-6 w-32 bg-slate-700 rounded" />
                  <div className="h-32 rounded-xl bg-slate-800 border border-slate-700 p-4 space-y-2">
                    <div className="h-4 w-48 bg-slate-600 rounded" />
                    <div className="h-3 w-full bg-slate-700/60 rounded" />
                    <div className="h-3 w-5/6 bg-slate-700/60 rounded" />
                  </div>
                  <div className="p-3 rounded-xl bg-cyan-950/40 border border-cyan-500/30 text-xs text-cyan-200">
                    ℹ️ Hologram overlay remains visible over external apps when Zoya is backgrounded.
                  </div>
                </div>
              </div>
            ) : (
              // 3. External App: Messages
              <div className="absolute inset-0 bg-[#121214] text-white flex flex-col justify-between select-none">
                <div className="px-4 py-3 bg-[#1e1f22] border-b border-white/10 flex items-center justify-between">
                  <div className="text-sm font-bold text-white flex items-center gap-2">
                    <MessageSquare className="w-4 h-4 text-blue-400" />
                    Messages
                  </div>
                  <button
                    onClick={() => setSimulatedApp('home')}
                    className="text-xs px-2.5 py-1 rounded-lg bg-white/10 hover:bg-white/20 text-slate-200"
                  >
                    Exit to Home
                  </button>
                </div>
                <div className="flex-1 p-4 space-y-3">
                  <div className="p-3 rounded-2xl bg-blue-600 text-white text-xs max-w-[75%] ml-auto shadow">
                    Hey! Is Zoya running in background?
                  </div>
                  <div className="p-3 rounded-2xl bg-slate-800 text-slate-200 text-xs max-w-[75%] mr-auto shadow">
                    Yes! The circular ZOYA hologram floats right over the screen.
                  </div>
                </div>
              </div>
            )}

            {/* Android Navigation Gesture Bar at bottom */}
            <div className="w-full h-5 flex items-center justify-center z-20 shrink-0">
              <div
                onClick={() => setSimulatedApp('home')}
                className="w-32 h-1 rounded-full bg-white/50 hover:bg-white/80 cursor-pointer transition-colors"
                title="Tap to go Home"
              />
            </div>

            {/* ======================================================== */}
            {/* FLOATING 3D CIRCULAR ZOYA HOLOGRAM OVERLAY               */}
            {/* Renders ONLY outside Zoya when Floating Hologram is ON   */}
            {/* ======================================================== */}
            {config.enabled && (
              <div
                style={{
                  position: 'absolute',
                  top: `${hologramPos.y}px`,
                  left: `${hologramPos.x}px`,
                  width: `${effectiveSize}px`,
                  height: `${effectiveSize}px`,
                  zIndex: 50,
                  transform: 'translate(-50%, -50%)',
                  cursor: isDragging ? 'grabbing' : 'grab',
                  transition: isDragging
                    ? 'none'
                    : 'width 0.35s cubic-bezier(0.16, 1, 0.3, 1), height 0.35s cubic-bezier(0.16, 1, 0.3, 1)',
                }}
                onPointerDown={handlePointerDown}
                onPointerMove={handlePointerMove}
                onPointerUp={handlePointerUp}
                className="touch-none select-none flex items-center justify-center group"
                title="Draggable Floating ZOYA Hologram (Click to talk or bring Zoya to front)"
              >
                {/* 100% Circular Hologram View with Bold "ZOYA" Center Wordmark */}
                <div
                  onClick={() => {
                    if (simVoiceState === 'idle') {
                      triggerVoiceState('listening');
                    } else if (simVoiceState === 'speaking') {
                      triggerVoiceState('idle');
                    }
                  }}
                  className="w-full h-full relative flex items-center justify-center cursor-pointer"
                >
                  <Zoya3DHologramView
                    style={activeStyle}
                    sizePx={effectiveSize}
                    voiceStatus={simVoiceState}
                    audioLevel={simAudioLevel}
                    config={config}
                    interactive={true}
                  />
                </div>

                {/* State Tag HUD */}
                <div className="absolute -bottom-5 left-1/2 -translate-x-1/2 px-2 py-0.5 rounded-full bg-black/80 border border-white/20 text-[9px] font-mono font-bold tracking-wider uppercase text-cyan-300 pointer-events-none whitespace-nowrap shadow-md">
                  {simVoiceState}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Live Voice Activity Simulator Test Panel (Outside the phone for convenient testing) */}
        <div className="hidden lg:flex flex-col gap-3 w-80 ml-6 p-5 rounded-3xl bg-[#110e28] border border-[#3b2d6a] text-slate-100 shadow-2xl z-20">
          <div className="flex items-center justify-between border-b border-[#2d2154] pb-3">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-cyan-400" />
              Live Hologram Test Lab
            </h3>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-purple-950 text-purple-300 border border-purple-500/30">
              Style #{activeStyle.index}
            </span>
          </div>

          <p className="text-xs text-slate-300 leading-relaxed">
            Test all 10 scenarios outside Zoya: drag & reposition, audio-reactive glow, processing ring spin, and speaking enlargement.
          </p>

          {/* Voice State Trigger Buttons */}
          <div className="space-y-2 pt-1">
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
              Trigger Voice States:
            </span>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => triggerVoiceState('idle')}
                className={`px-3 py-2 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                  simVoiceState === 'idle'
                    ? 'bg-cyan-950 border border-cyan-400 text-cyan-200'
                    : 'bg-[#1a1738] border border-white/10 text-slate-300 hover:text-white'
                }`}
              >
                <div className="w-2 h-2 rounded-full bg-cyan-400" />
                Idle Glow
              </button>

              <button
                onClick={() => triggerVoiceState('listening')}
                className={`px-3 py-2 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                  simVoiceState === 'listening'
                    ? 'bg-emerald-950 border border-emerald-400 text-emerald-200 shadow-[0_0_12px_rgba(16,185,129,0.4)]'
                    : 'bg-[#1a1738] border border-white/10 text-slate-300 hover:text-white'
                }`}
              >
                <Mic className="w-3.5 h-3.5 text-emerald-400" />
                Listening Pulse
              </button>

              <button
                onClick={() => triggerVoiceState('processing')}
                className={`px-3 py-2 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                  simVoiceState === 'processing'
                    ? 'bg-amber-950 border border-amber-400 text-amber-200 shadow-[0_0_12px_rgba(245,158,11,0.4)]'
                    : 'bg-[#1a1738] border border-white/10 text-slate-300 hover:text-white'
                }`}
              >
                <RotateCw className="w-3.5 h-3.5 text-amber-400 animate-spin" />
                Processing Spin
              </button>

              <button
                onClick={() => triggerVoiceState('speaking')}
                className={`px-3 py-2 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                  simVoiceState === 'speaking'
                    ? 'bg-pink-950 border border-pink-400 text-pink-200 shadow-[0_0_16px_rgba(244,114,182,0.5)]'
                    : 'bg-[#1a1738] border border-white/10 text-slate-300 hover:text-white'
                }`}
              >
                <Volume2 className="w-3.5 h-3.5 text-pink-400" />
                Speaking (+35%)
              </button>
            </div>
          </div>

          {/* External App Switching */}
          <div className="space-y-2 pt-2 border-t border-[#2d2154]">
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
              Switch Screen Context:
            </span>
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => setSimulatedApp('home')}
                className={`flex-1 py-1.5 px-2 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                  simulatedApp === 'home'
                    ? 'bg-purple-600 text-white'
                    : 'bg-[#1a1738] text-slate-300 hover:text-white'
                }`}
              >
                Home
              </button>
              <button
                onClick={() => setSimulatedApp('chrome')}
                className={`flex-1 py-1.5 px-2 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                  simulatedApp === 'chrome'
                    ? 'bg-purple-600 text-white'
                    : 'bg-[#1a1738] text-slate-300 hover:text-white'
                }`}
              >
                Chrome
              </button>
              <button
                onClick={() => setSimulatedApp('messages')}
                className={`flex-1 py-1.5 px-2 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                  simulatedApp === 'messages'
                    ? 'bg-purple-600 text-white'
                    : 'bg-[#1a1738] text-slate-300 hover:text-white'
                }`}
              >
                Messages
              </button>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="pt-2 border-t border-[#2d2154] space-y-2">
            <button
              onClick={handleReturnToZoya}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-pink-600 hover:brightness-110 text-white text-xs font-bold transition-all cursor-pointer shadow-lg active:scale-95 flex items-center justify-center gap-2"
            >
              <Sparkles className="w-4 h-4" />
              Return to Zoya App (Hides Overlay)
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
