import React, { useEffect, useRef } from 'react';
import {
  HologramStyle,
  ZoyaHologramConfig,
  hologramManager,
  ALL_23_HOLOGRAM_STYLES,
} from '../../services/zoyaHologramManager';

interface Zoya3DHologramViewProps {
  style?: HologramStyle;
  state?: 'IDLE' | 'LISTENING' | 'PROCESSING' | 'SPEAKING' | 'ERROR' | 'idle' | 'listening' | 'processing' | 'speaking' | 'error';
  voiceStatus?: 'idle' | 'listening' | 'processing' | 'speaking' | 'error';
  audioLevel?: number;        // 0.0 to 1.0 (microphone volume or TTS playback amplitude)
  sizePx?: number;            // base diameter in pixels (default 135)
  speakingEnlargeRatio?: number; // scale factor while speaking (default 1.38)
  glowIntensity?: number;     // 0.5 to 1.5 (default 1.0)
  animationSpeed?: number;    // 0.5 to 2.0 (default 1.0)
  config?: ZoyaHologramConfig;
  interactive?: boolean;
  onClick?: () => void;
  className?: string;
  showPedestal?: boolean;
}

export const Zoya3DHologramView: React.FC<Zoya3DHologramViewProps> = ({
  style: propStyle,
  state: propState,
  voiceStatus,
  audioLevel = 0,
  sizePx,
  speakingEnlargeRatio,
  glowIntensity,
  animationSpeed,
  config,
  interactive: _interactive = false,
  onClick,
  className = '',
  showPedestal = true,
}) => {
  const style =
    propStyle ||
    (config?.selectedStyleId
      ? ALL_23_HOLOGRAM_STYLES.find((s) => s.id === config.selectedStyleId)
      : undefined) ||
    hologramManager.getActiveStyle();

  const rawState = propState || voiceStatus || 'IDLE';
  const state = rawState.toUpperCase() as 'IDLE' | 'LISTENING' | 'PROCESSING' | 'SPEAKING' | 'ERROR';

  const effectiveSize = sizePx || config?.baseSizePx || config?.sizePx || 135;
  const effectiveEnlargeRatio = speakingEnlargeRatio || config?.speakingEnlargeRatio || 1.38;
  const effectiveGlow = glowIntensity ?? config?.glowIntensity ?? 1.0;
  const effectiveSpeed = animationSpeed ?? config?.animationSpeed ?? 1.0;

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const animFrameRef = useRef<number | null>(null);
  const stateRef = useRef({
    state,
    audioLevel,
    sizePx: effectiveSize,
    speakingEnlargeRatio: effectiveEnlargeRatio,
    glowIntensity: effectiveGlow,
    animationSpeed: effectiveSpeed,
  });
  stateRef.current = {
    state,
    audioLevel,
    sizePx: effectiveSize,
    speakingEnlargeRatio: effectiveEnlargeRatio,
    glowIntensity: effectiveGlow,
    animationSpeed: effectiveSpeed,
  };

  // Smooth dynamic scale interpolation
  const currentScaleRef = useRef<number>(1.0);
  const currentGlowRef = useRef<number>(1.0);
  const rotationAngleRef = useRef<number>(0);
  const pulsePhaseRef = useRef<number>(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d', { alpha: true });
    if (!ctx) return;

    let lastTime = performance.now();

    // Particle system state
    const particleCount = style.hasSatellites ? (style.satelliteCount || 3) * 6 : 18;
    const particles = Array.from({ length: particleCount }).map((_, i) => ({
      angle: (i / particleCount) * Math.PI * 2,
      orbitRadius: 0.38 + (i % 3) * 0.08,
      speed: (0.4 + (i % 5) * 0.15) * ((i % 2 === 0) ? 1 : -1),
      size: 1.5 + (i % 3) * 1.5,
      alpha: 0.3 + (i % 4) * 0.18,
      offsetY: ((i % 5) - 2) * 4,
    }));

    const render = (time: number) => {
      const dt = Math.min((time - lastTime) / 1000, 0.1);
      lastTime = time;

      const { state: curState, audioLevel: curAudio, speakingEnlargeRatio: curEnlarge, glowIntensity: curGlowMult, animationSpeed: curSpeed } = stateRef.current;

      // Target scale calculation:
      // When SPEAKING: noticeably larger (1.35x - 1.5x)!
      // When LISTENING: slightly expanded with audio reactivity
      // When IDLE: gentle breathing
      let targetScale = 1.0;
      let targetGlow = 1.0;
      let rotSpeed = 0.6 * curSpeed;

      if (curState === 'SPEAKING') {
        targetScale = curEnlarge;
        targetGlow = 1.45 * curGlowMult;
        rotSpeed = 1.8 * curSpeed;
      } else if (curState === 'LISTENING') {
        targetScale = 1.05 + curAudio * 0.12;
        targetGlow = (1.15 + curAudio * 0.4) * curGlowMult;
        rotSpeed = (0.9 + curAudio * 1.2) * curSpeed;
      } else if (curState === 'PROCESSING') {
        targetScale = 1.08;
        targetGlow = 1.35 * curGlowMult;
        rotSpeed = 3.2 * curSpeed;
      } else if (curState === 'ERROR') {
        targetScale = 0.96;
        targetGlow = 0.8;
        rotSpeed = 0.2;
      } else {
        // IDLE breathing
        pulsePhaseRef.current += dt * 1.5;
        targetScale = 1.0 + Math.sin(pulsePhaseRef.current) * 0.02;
        targetGlow = 1.0 * curGlowMult;
      }

      // Smooth cubic ease toward target scale
      currentScaleRef.current += (targetScale - currentScaleRef.current) * Math.min(dt * 7.5, 1.0);
      currentGlowRef.current += (targetGlow - currentGlowRef.current) * Math.min(dt * 6.0, 1.0);
      rotationAngleRef.current += dt * rotSpeed;

      const dpr = window.devicePixelRatio || 1;
      const width = canvas.width / dpr;
      const height = canvas.height / dpr;
      const centerX = width / 2;
      const centerY = height / 2;
      const baseRadius = (Math.min(width, height) / 2) * 0.62 * currentScaleRef.current;

      ctx.save();
      ctx.clearRect(0, 0, width, height);

      // 1. Draw glowing circular pedestal reflection (matching the reference photos)
      if (showPedestal) {
        ctx.save();
        const pedY = centerY + baseRadius * 1.08;
        const pedRx = baseRadius * 0.95;
        const pedRy = baseRadius * 0.22;

        const pedGrad = ctx.createRadialGradient(centerX, pedY, 0, centerX, pedY, pedRx);
        pedGrad.addColorStop(0, hexToRgba(style.primaryColor, 0.45 * currentGlowRef.current));
        pedGrad.addColorStop(0.5, hexToRgba(style.secondaryColor, 0.2 * currentGlowRef.current));
        pedGrad.addColorStop(1, 'transparent');

        ctx.fillStyle = pedGrad;
        ctx.beginPath();
        ctx.ellipse(centerX, pedY, pedRx, pedRy, 0, 0, Math.PI * 2);
        ctx.fill();

        // Pedestal concentric ring
        ctx.strokeStyle = hexToRgba(style.accentColor, 0.6 * currentGlowRef.current);
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.ellipse(centerX, pedY, pedRx * 0.82, pedRy * 0.82, 0, 0, Math.PI * 2);
        ctx.stroke();
        ctx.restore();
      }

      // 2. Draw Outer Multi-layered 3D Holographic Concentric Rings
      const rot = rotationAngleRef.current;
      const glow = currentGlowRef.current;

      // Outer Bloom Glow Ring
      ctx.save();
      ctx.shadowColor = style.primaryColor;
      ctx.shadowBlur = 18 * glow;
      ctx.strokeStyle = hexToRgba(style.primaryColor, 0.85);
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.arc(centerX, centerY, baseRadius, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();

      // Middle Dynamic Ring (style-specific accent)
      ctx.save();
      ctx.shadowColor = style.secondaryColor;
      ctx.shadowBlur = 12 * glow;
      ctx.strokeStyle = hexToRgba(style.secondaryColor, 0.9);
      ctx.lineWidth = 3.0;

      if (style.ringStyle === 'wavy_lotus') {
        // Scalloped undulating wave
        ctx.beginPath();
        const waves = 8;
        for (let a = 0; a <= Math.PI * 2; a += 0.05) {
          const r = baseRadius + Math.sin(a * waves + rot * 2) * 5.5;
          const x = centerX + Math.cos(a) * r;
          const y = centerY + Math.sin(a) * r;
          if (a === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        }
        ctx.closePath();
        ctx.stroke();
      } else if (style.ringStyle === 'cyber_brackets') {
        // Segmented HUD brackets
        for (let s = 0; s < 4; s++) {
          const start = rot + (s * Math.PI) / 2 + 0.15;
          const end = start + Math.PI / 2 - 0.3;
          ctx.beginPath();
          ctx.arc(centerX, centerY, baseRadius * 1.08, start, end);
          ctx.stroke();
        }
      } else if (style.ringStyle === 'audio_spectrum') {
        // Frequency bars
        const bars = 28;
        for (let i = 0; i < bars; i++) {
          const a = (i / bars) * Math.PI * 2 + rot * 0.5;
          const barH = 4 + Math.sin(i * 1.5 + rot * 4) * 8 * (curState === 'SPEAKING' || curState === 'LISTENING' ? 1.6 : 1.0);
          const x1 = centerX + Math.cos(a) * (baseRadius - barH);
          const y1 = centerY + Math.sin(a) * (baseRadius - barH);
          const x2 = centerX + Math.cos(a) * (baseRadius + barH);
          const y2 = centerY + Math.sin(a) * (baseRadius + barH);
          ctx.beginPath();
          ctx.moveTo(x1, y1);
          ctx.lineTo(x2, y2);
          ctx.stroke();
        }
      } else {
        // Concentric smooth dual rings
        ctx.beginPath();
        ctx.arc(centerX, centerY, baseRadius * 0.92, 0, Math.PI * 2);
        ctx.stroke();

        ctx.strokeStyle = hexToRgba(style.accentColor, 0.7);
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.arc(centerX, centerY, baseRadius * 0.85, 0, Math.PI * 2);
        ctx.stroke();
      }
      ctx.restore();

      // 3. Orbiting 3D Elliptical Rings with Perspective Tilt
      ctx.save();
      ctx.translate(centerX, centerY);
      ctx.rotate(rot * 0.4);
      ctx.beginPath();
      ctx.ellipse(0, 0, baseRadius * 1.22, baseRadius * 0.45, 0.4, 0, Math.PI * 2);
      ctx.strokeStyle = hexToRgba(style.primaryColor, 0.5 * glow);
      ctx.lineWidth = 2.0;
      ctx.shadowColor = style.primaryColor;
      ctx.shadowBlur = 10 * glow;
      ctx.stroke();

      // Counter-rotating tilted ring
      ctx.beginPath();
      ctx.ellipse(0, 0, baseRadius * 1.18, baseRadius * 0.4, -0.45 - rot * 0.6, 0, Math.PI * 2);
      ctx.strokeStyle = hexToRgba(style.secondaryColor, 0.45 * glow);
      ctx.lineWidth = 1.8;
      ctx.stroke();
      ctx.restore();

      // 4. Moving Holographic Particles & Orbiting Satellites
      for (const p of particles) {
        p.angle += dt * p.speed * curSpeed;
        const pDist = baseRadius * p.orbitRadius;
        const px = centerX + Math.cos(p.angle) * pDist;
        const py = centerY + Math.sin(p.angle) * (pDist * 0.75) + p.offsetY;

        ctx.save();
        ctx.beginPath();
        ctx.arc(px, py, p.size * (curState === 'SPEAKING' ? 1.4 : 1.0), 0, Math.PI * 2);
        ctx.fillStyle = hexToRgba(style.accentColor, p.alpha * glow);
        ctx.shadowColor = style.accentColor;
        ctx.shadowBlur = 6 * glow;
        ctx.fill();
        ctx.restore();
      }

      // Large orbiting satellite spheres (if style has them, matching reference images)
      if (style.hasSatellites) {
        const satCount = style.satelliteCount || 3;
        for (let s = 0; s < satCount; s++) {
          const satAngle = rot * 0.8 + (s * Math.PI * 2) / satCount;
          const satDist = baseRadius * 1.12;
          const sx = centerX + Math.cos(satAngle) * satDist;
          const sy = centerY + Math.sin(satAngle) * (satDist * 0.85);
          const sphereR = 6.5 * (curState === 'SPEAKING' ? 1.3 : 1.0);

          ctx.save();
          const sphereGrad = ctx.createRadialGradient(sx - 2, sy - 2, 0, sx, sy, sphereR);
          sphereGrad.addColorStop(0, '#FFFFFF');
          sphereGrad.addColorStop(0.4, style.secondaryColor);
          sphereGrad.addColorStop(1, style.primaryColor);

          ctx.fillStyle = sphereGrad;
          ctx.shadowColor = style.primaryColor;
          ctx.shadowBlur = 12 * glow;
          ctx.beginPath();
          ctx.arc(sx, sy, sphereR, 0, Math.PI * 2);
          ctx.fill();
          ctx.restore();
        }
      }

      // 5. Center Core Transparent Glass Disc
      ctx.save();
      const coreGrad = ctx.createRadialGradient(centerX, centerY, 0, centerX, centerY, baseRadius * 0.8);
      coreGrad.addColorStop(0, hexToRgba(style.secondaryColor, 0.35 * glow));
      coreGrad.addColorStop(0.65, hexToRgba('#050518', 0.82));
      coreGrad.addColorStop(1, hexToRgba('#02020A', 0.92));

      ctx.fillStyle = coreGrad;
      ctx.beginPath();
      ctx.arc(centerX, centerY, baseRadius * 0.82, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();

      // 6. Center Emblem (Golden Crown / Diamond / Star if featured in reference design)
      if (style.centerEmblem === 'crown') {
        ctx.save();
        const crownY = centerY - baseRadius * 0.38;
        const crownSize = baseRadius * 0.28;
        drawCrown(ctx, centerX, crownY, crownSize, style.primaryColor, glow);
        ctx.restore();
      } else if (style.centerEmblem === 'diamond') {
        ctx.save();
        const diaSize = baseRadius * 0.22;
        drawDiamond(ctx, centerX, centerY - baseRadius * 0.42, diaSize, style.accentColor, glow);
        ctx.restore();
      } else if (style.centerEmblem === 'star') {
        ctx.save();
        drawStar(ctx, centerX, centerY - baseRadius * 0.36, baseRadius * 0.15, style.accentColor, glow);
        drawStar(ctx, centerX, centerY + baseRadius * 0.36, baseRadius * 0.15, style.accentColor, glow);
        ctx.restore();
      }

      // 7. Center Large English Word "ZOYA" (HIGHEST PRIORITY - ALWAYS DISPLAYED IN CENTER)
      ctx.save();
      const fontSize = Math.round(baseRadius * 0.42);
      ctx.font = `900 ${fontSize}px "Plus Jakarta Sans", "Inter", -apple-system, sans-serif`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';

      // Text Glow Shadow
      ctx.shadowColor = style.primaryColor;
      ctx.shadowBlur = 20 * glow;

      // Text Gradient
      const textGrad = ctx.createLinearGradient(
        centerX,
        centerY - fontSize / 2,
        centerX,
        centerY + fontSize / 2
      );
      textGrad.addColorStop(0, '#FFFFFF');
      textGrad.addColorStop(0.5, style.textColor);
      textGrad.addColorStop(1, style.primaryColor);

      ctx.fillStyle = textGrad;
      ctx.letterSpacing = '3px';
      ctx.fillText('ZOYA', centerX, centerY);

      // Delicate bright specular highlight on text
      ctx.shadowBlur = 0;
      ctx.lineWidth = 1.0;
      ctx.strokeStyle = '#FFFFFF';
      ctx.strokeText('ZOYA', centerX, centerY);
      ctx.restore();

      // 8. State-Specific Overlays (Error glitch / Processing spinner)
      if (curState === 'ERROR') {
        ctx.save();
        ctx.strokeStyle = '#FF1744';
        ctx.lineWidth = 2.5;
        ctx.shadowColor = '#FF1744';
        ctx.shadowBlur = 15;
        ctx.beginPath();
        ctx.arc(centerX, centerY, baseRadius * 1.02, 0, Math.PI * 2);
        ctx.stroke();
        ctx.restore();
      }

      ctx.restore();
      animFrameRef.current = requestAnimationFrame(render);
    };

    animFrameRef.current = requestAnimationFrame(render);

    return () => {
      if (animFrameRef.current) {
        cancelAnimationFrame(animFrameRef.current);
      }
    };
  }, [style]);

  const canvasDim = Math.round(effectiveSize * 1.65);

  return (
    <div
      onClick={onClick}
      className={`relative inline-flex items-center justify-center select-none cursor-pointer transition-transform ${className}`}
      style={{
        width: `${canvasDim}px`,
        height: `${canvasDim}px`,
      }}
    >
      <canvas
        ref={canvasRef}
        width={canvasDim * (typeof window !== 'undefined' ? (window.devicePixelRatio || 1) : 1)}
        height={canvasDim * (typeof window !== 'undefined' ? (window.devicePixelRatio || 1) : 1)}
        style={{
          width: `${canvasDim}px`,
          height: `${canvasDim}px`,
        }}
        className="block"
      />
    </div>
  );
};

// --- Vector Emblems Helper Functions ---

function hexToRgba(hex: string, alpha: number): string {
  const clean = hex.replace('#', '');
  const num = parseInt(clean, 16);
  if (clean.length === 6) {
    const r = (num >> 16) & 255;
    const g = (num >> 8) & 255;
    const b = num & 255;
    return `rgba(${r}, ${g}, ${b}, ${alpha})`;
  }
  return `rgba(0, 229, 255, ${alpha})`;
}

function drawCrown(ctx: CanvasRenderingContext2D, cx: number, cy: number, size: number, color: string, glow: number) {
  const w = size * 1.1;
  const h = size * 0.7;
  ctx.save();
  ctx.fillStyle = color;
  ctx.shadowColor = color;
  ctx.shadowBlur = 10 * glow;

  ctx.beginPath();
  ctx.moveTo(cx - w / 2, cy + h / 2);
  ctx.lineTo(cx - w / 2, cy - h / 3);
  ctx.lineTo(cx - w / 4, cy + h / 6);
  ctx.lineTo(cx, cy - h / 2);
  ctx.lineTo(cx + w / 4, cy + h / 6);
  ctx.lineTo(cx + w / 2, cy - h / 3);
  ctx.lineTo(cx + w / 2, cy + h / 2);
  ctx.closePath();
  ctx.fill();

  // Crown jewels
  ctx.fillStyle = '#FFFFFF';
  ctx.beginPath();
  ctx.arc(cx, cy - h / 2 - 2, 2.5, 0, Math.PI * 2);
  ctx.arc(cx - w / 2, cy - h / 3 - 2, 2.0, 0, Math.PI * 2);
  ctx.arc(cx + w / 2, cy - h / 3 - 2, 2.0, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

function drawDiamond(ctx: CanvasRenderingContext2D, cx: number, cy: number, size: number, color: string, glow: number) {
  ctx.save();
  ctx.strokeStyle = color;
  ctx.fillStyle = hexToRgba(color, 0.4);
  ctx.shadowColor = color;
  ctx.shadowBlur = 8 * glow;
  ctx.lineWidth = 1.5;

  ctx.beginPath();
  ctx.moveTo(cx, cy - size);
  ctx.lineTo(cx + size * 0.8, cy);
  ctx.lineTo(cx, cy + size);
  ctx.lineTo(cx - size * 0.8, cy);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();
  ctx.restore();
}

function drawStar(ctx: CanvasRenderingContext2D, cx: number, cy: number, size: number, color: string, glow: number) {
  ctx.save();
  ctx.fillStyle = color;
  ctx.shadowColor = color;
  ctx.shadowBlur = 8 * glow;

  ctx.beginPath();
  ctx.moveTo(cx, cy - size);
  ctx.quadraticCurveTo(cx, cy, cx + size, cy);
  ctx.quadraticCurveTo(cx, cy, cx, cy + size);
  ctx.quadraticCurveTo(cx, cy, cx - size, cy);
  ctx.quadraticCurveTo(cx, cy, cx, cy - size);
  ctx.closePath();
  ctx.fill();
  ctx.restore();
}
