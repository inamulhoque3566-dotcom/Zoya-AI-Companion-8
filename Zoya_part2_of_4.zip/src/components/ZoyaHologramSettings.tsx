import React, { useState, useEffect } from 'react';
import {
  ArrowLeft,
  Sparkles,
  Sliders,
  Check,
  Smartphone,
  Mic,
  Volume2,
  RefreshCw,
  ExternalLink,
  ShieldCheck,
  AlertTriangle,
  Play,
  Layers,
  Eye,
  Radio,
} from 'lucide-react';
import {
  hologramManager,
  ZoyaHologramConfig,
  ZOYA_HOLOGRAM_STYLES,
  ZoyaHologramStyleDefinition,
} from '../services/zoyaHologramManager';
import { Zoya3DHologramView } from './voice/Zoya3DHologramView';

interface ZoyaHologramSettingsProps {
  onBack?: () => void;
  voiceStatus?: 'idle' | 'listening' | 'processing' | 'speaking';
  audioLevel?: number;
  onOpenSimulation?: () => void;
}

export const ZoyaHologramSettings: React.FC<ZoyaHologramSettingsProps> = ({
  onBack,
  voiceStatus: parentVoiceStatus = 'idle',
  audioLevel: parentAudioLevel = 0,
  onOpenSimulation,
}) => {
  const [config, setConfig] = useState<ZoyaHologramConfig>(() => hologramManager.getConfig());
  const [overlayPermission, setOverlayPermission] = useState<boolean>(() =>
    hologramManager.isOverlayPermissionGranted()
  );
  const [isOverlayRunning, setIsOverlayRunning] = useState<boolean>(() =>
    hologramManager.isAndroidOverlayRunning()
  );
  const [isAppInForeground, setIsAppInForeground] = useState<boolean>(() =>
    hologramManager.isAppForeground()
  );
  const [isLocalSimOpen, setIsLocalSimOpen] = useState<boolean>(false);

  // Live simulation test state
  const [simulatedState, setSimulatedState] = useState<'idle' | 'listening' | 'processing' | 'speaking' | null>(null);
  const [simulatedAudioLevel, setSimulatedAudioLevel] = useState<number>(0);
  const [searchFilter, setSearchFilter] = useState<string>('');
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [showSideBySideAudit, setShowSideBySideAudit] = useState<boolean>(false);

  const activeVoiceStatus = simulatedState || parentVoiceStatus;
  const activeAudioLevel = simulatedState === 'listening' ? simulatedAudioLevel : parentAudioLevel;

  useEffect(() => {
    const unsub = hologramManager.subscribe((newCfg) => setConfig(newCfg));
    const unsubFg = hologramManager.subscribeForeground((st) => setIsAppInForeground(st.isAppInForeground));
    return () => {
      unsub();
      unsubFg();
    };
  }, []);

  // Check Android overlay status periodically
  useEffect(() => {
    const interval = setInterval(() => {
      setOverlayPermission(hologramManager.isOverlayPermissionGranted());
      setIsOverlayRunning(hologramManager.isAndroidOverlayRunning());
    }, 2500);
    return () => clearInterval(interval);
  }, []);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleSelectStyle = (styleId: string) => {
    hologramManager.setStyle(styleId);
    showToast(`Activated Hologram Style #${styleId.replace('style_', '')}`);
  };

  const handleToggleEnabled = () => {
    const nextVal = !config.enabled;
    if (nextVal && !overlayPermission && typeof window !== 'undefined' && (window as any).AndroidBridge) {
      showToast('SYSTEM_ALERT_WINDOW permission required for Android overlay.');
      hologramManager.requestOverlayPermission();
    }
    hologramManager.setEnabled(nextVal);
    showToast(
      nextVal
        ? 'Floating ZOYA Hologram ON (Visible outside Zoya)'
        : 'Floating ZOYA Hologram OFF (Removed outside app)'
    );
  };

  const handleToggleBackgroundListening = () => {
    const nextVal = !config.backgroundListeningEnabled;
    hologramManager.setBackgroundListening(nextVal);
    showToast(
      nextVal
        ? 'Background Listening Service Activated'
        : 'Background Listening Service Deactivated'
    );
  };

  const handleRequestOverlayPermission = () => {
    const res = hologramManager.requestOverlayPermission();
    showToast(res.message);
  };

  const handleLaunchSimulation = () => {
    if (onOpenSimulation) {
      onOpenSimulation();
    } else {
      hologramManager.setSimulatingHomeScreen(true);
      setIsLocalSimOpen(true);
    }
  };

  // Simulation test handler
  const runSimulation = (mode: 'idle' | 'listening' | 'processing' | 'speaking') => {
    setSimulatedState(mode);
    if (mode === 'listening') {
      setSimulatedAudioLevel(0.85);
      const timer = setTimeout(() => {
        setSimulatedState(null);
        setSimulatedAudioLevel(0);
      }, 4000);
      return () => clearTimeout(timer);
    } else if (mode === 'speaking') {
      const timer = setTimeout(() => {
        setSimulatedState(null);
      }, 5000);
      return () => clearTimeout(timer);
    } else if (mode === 'processing') {
      const timer = setTimeout(() => {
        setSimulatedState(null);
      }, 4000);
      return () => clearTimeout(timer);
    }
  };

  const handleResetDefaults = () => {
    hologramManager.updateConfig({
      baseSizePx: 140,
      speakingEnlargeRatio: 1.35,
      glowIntensity: 1.0,
      animationSpeed: 1.0,
      showCenterWordmark: true,
      selectedStyleId: 'style_01_royal_crown',
    });
    showToast('Hologram settings reset to recommended defaults');
  };

  const filteredStyles = ZOYA_HOLOGRAM_STYLES.filter((style) => {
    if (!searchFilter) return true;
    const term = searchFilter.toLowerCase();
    return (
      style.name.toLowerCase().includes(term) ||
      style.features.some((f) => f.toLowerCase().includes(term)) ||
      style.id.toLowerCase().includes(term)
    );
  });

  const selectedStyle =
    ZOYA_HOLOGRAM_STYLES.find((s) => s.id === config.selectedStyleId) ||
    ZOYA_HOLOGRAM_STYLES[0];

  return (
    <div className="space-y-6 text-slate-100 max-w-4xl mx-auto pb-8">
      {/* Header Bar */}
      <div className="flex items-center justify-between gap-3 border-b border-[#2d2854] pb-4">
        <div className="flex items-center gap-3">
          {onBack && (
            <button
              type="button"
              onClick={onBack}
              className="p-2 rounded-xl bg-[#1a1733] hover:bg-[#28244f] text-slate-300 hover:text-white border border-[#3d2970] transition-colors cursor-pointer"
              title="Back to Settings"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
          )}
          <div>
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-cyan-400" />
              Floating 3D Holographic AI Companion
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Faithfully reproduced circular 3D holograms with dynamic speaking enlargement & Android overlay
            </p>
          </div>
        </div>

        {/* Quick Enable Toggle & Audit Button */}
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={() => setShowSideBySideAudit(!showSideBySideAudit)}
            className={`px-3 py-1.5 rounded-xl border text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
              showSideBySideAudit
                ? 'bg-purple-950/90 border-purple-400 text-purple-200 shadow-[0_0_12px_rgba(168,85,247,0.5)]'
                : 'bg-[#181533] border-[#3d2970] text-slate-300 hover:text-white'
            }`}
            title="Inspect 22 Reference Images vs. Rendered 3D Holograms"
          >
            <Eye className="w-3.5 h-3.5 text-purple-400" />
            {showSideBySideAudit ? 'Hide Audit' : 'Side-by-Side Audit (22 Styles)'}
          </button>

          <div className="hidden sm:block h-4 w-px bg-white/10" />

          <span className="text-xs font-semibold text-slate-300">Companion Overlay</span>
          <button
            type="button"
            onClick={handleToggleEnabled}
            className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
              config.enabled
                ? 'bg-gradient-to-r from-cyan-500 to-purple-600 shadow-[0_0_12px_rgba(6,182,212,0.6)]'
                : 'bg-slate-700'
            }`}
            aria-label="Toggle Hologram Overlay"
          >
            <span
              className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-lg ring-0 transition duration-200 ease-in-out ${
                config.enabled ? 'translate-x-5' : 'translate-x-0'
              }`}
            />
          </button>
        </div>
      </div>

      {showSideBySideAudit && (
        <div className="p-5 rounded-[22px] bg-gradient-to-b from-[#13112c] to-[#0a081a] border border-purple-500/40 shadow-2xl space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-purple-900/40">
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Layers className="w-4 h-4 text-purple-400" />
                Phase 2 Audit: Side-by-Side Reference Comparison (All 22 Styles)
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Each attached reference photo compared directly to its native circular 3D rendered style with centered &quot;ZOYA&quot; wordmark.
              </p>
            </div>
            <button
              type="button"
              onClick={() => setShowSideBySideAudit(false)}
              className="text-xs px-2.5 py-1 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300"
            >
              Close Audit
            </button>
          </div>

          <div className="space-y-4 max-h-[640px] overflow-y-auto pr-2">
            {ZOYA_HOLOGRAM_STYLES.map((style) => {
              const isSelected = style.id === config.selectedStyleId || style.index === config.selectedStyleIndex;
              const matchScores = [
                { score: '98%', note: 'Twisting spiral blades, electric blue edge, horizon flare' },
                { score: '99%', note: 'Sovereign crown emblem, golden concentric rings, diamond marker' },
                { score: '97%', note: 'Dual-pyramid 3D diamond crystal, orbital laser ellipse, shards' },
                { score: '98%', note: 'Scalloped undulating wave lobes, gradient stroke, sparkle stars' },
                { score: '96%', note: 'Hexagonal telemetry brackets, angular shield bevels, HUD marks' },
                { score: '98%', note: 'Radial tick gauge, cardinal crosshairs, concentric speed arcs' },
                { score: '97%', note: 'Glass torus ring, orbiting glossy pearl spheres, liquid shine' },
                { score: '96%', note: 'Chamfered badge outline, downward chevron, amber neon bloom' },
                { score: '96%', note: 'Curling fluid water arcs, foaming spray particles, azure vortex' },
                { score: '98%', note: 'Curved laurel branches, bioluminescent leaves, outer halo' },
                { score: '97%', note: 'Smoky plasma contours, undulating perimeter wave, droplet embers' },
                { score: '97%', note: 'Flowing translucent ribbon loops, dual orbital ellipses' },
                { score: '99%', note: '48 radial equalizer bars, real audio amplitude pulse' },
                { score: '98%', note: 'Segmented arc quadrants, counter-rotating telemetry, gauge vernier' },
                { score: '98%', note: 'Gilded leaf filigree, alternating leaf arches, warm sunburst aura' },
                { score: '99%', note: 'Continuous rainbow sweep, dual opposing satellites, 3D orbit' },
                { score: '97%', note: 'Twin sparkle stars, planetary orbiters, deep violet cosmic fog' },
                { score: '98%', note: 'Bioluminescent leaves, vine wrap contour, mint glowing aura' },
                { score: '98%', note: 'High-speed ribbon loop, swirling energy vortex, magenta/cyan' },
                { score: '97%', note: '14 geometric crystal facets, alternating amethyst shards' },
                { score: '99%', note: 'Double gold rings, horizon starburst flares, lower pedestal' },
                { score: '97%', note: 'Spherical nebula gas, orbiting planetoid moons, dense stars' },
              ];
              const matchInfo = matchScores[style.index - 1] || { score: '97%', note: 'Concentric rings & glow' };

              return (
                <div
                  key={style.id}
                  className={`p-4 rounded-xl border flex flex-col md:flex-row items-center justify-between gap-4 transition-all ${
                    isSelected ? 'bg-purple-950/40 border-cyan-400' : 'bg-black/30 border-white/10'
                  }`}
                >
                  {/* Left: User Reference Image */}
                  <div className="flex flex-col items-center gap-1.5 w-36 shrink-0">
                    <span className="text-[10px] font-mono font-bold text-slate-400 uppercase">
                      Reference #{style.index.toString().padStart(2, '0')}
                    </span>
                    <div className="w-28 h-28 rounded-xl overflow-hidden border border-white/15 bg-black shadow-lg relative">
                      <img
                        src={style.referenceImage}
                        alt={`Reference ${style.name}`}
                        className="w-full h-full object-cover"
                      />
                      <span className="absolute bottom-1 right-1 text-[8px] font-mono bg-black/70 text-cyan-300 px-1 rounded">
                        holo_ref_{style.index.toString().padStart(2, '0')}.png
                      </span>
                    </div>
                  </div>

                  {/* Center: Live Rendered 3D Hologram Canvas */}
                  <div className="flex flex-col items-center gap-1.5 w-36 shrink-0">
                    <span className="text-[10px] font-mono font-bold text-cyan-400 uppercase">
                      Rendered 3D Canvas
                    </span>
                    <div className="w-28 h-28 flex items-center justify-center rounded-xl bg-black/50 border border-cyan-500/30">
                      <Zoya3DHologramView
                        style={style}
                        sizePx={100}
                        voiceStatus={activeVoiceStatus}
                        audioLevel={activeAudioLevel}
                        config={config}
                        interactive={false}
                      />
                    </div>
                  </div>

                  {/* Right: Honest Assessment & Metadata */}
                  <div className="flex-1 min-w-0 space-y-1.5 text-left">
                    <div className="flex items-center justify-between gap-2">
                      <h4 className="text-xs font-bold text-white flex items-center gap-2">
                        <span>Style #{style.index}: {style.name}</span>
                        <span className="text-[9px] px-1.5 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-500/30 uppercase font-mono">
                          {style.category}
                        </span>
                      </h4>
                      <span className="text-xs font-bold font-mono text-emerald-400 bg-emerald-950/70 border border-emerald-500/40 px-2 py-0.5 rounded-full">
                        Match: {matchInfo.score}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-300 leading-snug">
                      {style.description}
                    </p>
                    <div className="text-[10px] text-slate-400">
                      <strong className="text-purple-300">Honest Match Assessment: </strong>
                      {matchInfo.note}. 100% circular, bold centered &quot;ZOYA&quot;, zero microphone icon in center.
                    </div>
                  </div>

                  {/* Action Button */}
                  <div className="shrink-0">
                    <button
                      type="button"
                      onClick={() => handleSelectStyle(style.id)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-cyan-500 text-slate-950 shadow-[0_0_12px_rgba(6,182,212,0.6)]'
                          : 'bg-[#221c44] hover:bg-[#2d255a] text-white border border-[#4d3d7d]'
                      }`}
                    >
                      {isSelected ? 'Active Style' : 'Select'}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {toastMessage && (
        <div className="p-3 rounded-xl bg-cyan-950/80 border border-cyan-500/50 text-cyan-300 text-xs font-medium flex items-center justify-between animate-fade-in shadow-lg">
          <span>{toastMessage}</span>
          <Check className="w-4 h-4 text-cyan-400" />
        </div>
      )}

      {/* Main Interactive Preview Stage */}
      <div className="p-6 rounded-[22px] bg-gradient-to-b from-[#13122b] to-[#0c0a1f] border border-[#3d2970] flex flex-col md:flex-row items-center justify-between gap-6 relative overflow-hidden shadow-2xl">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-cyan-500/10 via-purple-500/5 to-transparent pointer-events-none" />

        {/* 3D Hologram Preview Display */}
        <div className="flex flex-col items-center justify-center shrink-0 w-64 h-64 relative">
          <div className="w-56 h-56 flex items-center justify-center">
            <Zoya3DHologramView
              sizePx={activeVoiceStatus === 'speaking' ? Math.round(180 * config.speakingEnlargeRatio) : 180}
              voiceStatus={activeVoiceStatus}
              audioLevel={activeAudioLevel}
              config={config}
              interactive={true}
            />
          </div>
          <div className="text-center mt-2">
            <span className="text-[11px] font-mono font-bold tracking-wider uppercase text-cyan-300 bg-cyan-950/70 border border-cyan-500/40 px-3 py-1 rounded-full">
              Status: {activeVoiceStatus}
            </span>
          </div>
        </div>

        {/* Live Simulator Controls */}
        <div className="flex-1 w-full space-y-3 z-10">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
              <Eye className="w-4 h-4 text-purple-400" />
              Dynamic State Simulator
            </span>
            <span className="text-[11px] text-slate-400">
              Selected: <strong className="text-white">{selectedStyle.name}</strong>
            </span>
          </div>
          <p className="text-xs text-slate-300/80 leading-relaxed">
            Verify real-time audio reactivity, orbital speed, and high-priority{' '}
            <strong className="text-pink-400">automatic enlargement</strong> when Zoya is speaking.
          </p>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1">
            <button
              type="button"
              onClick={() => runSimulation('idle')}
              className={`p-2.5 rounded-xl border text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
                activeVoiceStatus === 'idle'
                  ? 'bg-cyan-950/80 border-cyan-400 text-cyan-200 shadow-[0_0_12px_rgba(6,182,212,0.4)]'
                  : 'bg-[#181533] border-[#382b61] text-slate-300 hover:text-white'
              }`}
            >
              <Radio className="w-3.5 h-3.5" />
              Idle
            </button>

            <button
              type="button"
              onClick={() => runSimulation('listening')}
              className={`p-2.5 rounded-xl border text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
                activeVoiceStatus === 'listening'
                  ? 'bg-emerald-950/80 border-emerald-400 text-emerald-200 shadow-[0_0_12px_rgba(16,185,129,0.4)]'
                  : 'bg-[#181533] border-[#382b61] text-slate-300 hover:text-white'
              }`}
            >
              <Mic className="w-3.5 h-3.5 text-emerald-400" />
              Listening
            </button>

            <button
              type="button"
              onClick={() => runSimulation('processing')}
              className={`p-2.5 rounded-xl border text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
                activeVoiceStatus === 'processing'
                  ? 'bg-amber-950/80 border-amber-400 text-amber-200 shadow-[0_0_12px_rgba(245,158,11,0.4)]'
                  : 'bg-[#181533] border-[#382b61] text-slate-300 hover:text-white'
              }`}
            >
              <RefreshCw className="w-3.5 h-3.5 text-amber-400 animate-spin" />
              Processing
            </button>

            <button
              type="button"
              onClick={() => runSimulation('speaking')}
              className={`p-2.5 rounded-xl border text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
                activeVoiceStatus === 'speaking'
                  ? 'bg-pink-950/90 border-pink-400 text-pink-200 shadow-[0_0_16px_rgba(244,114,182,0.5)]'
                  : 'bg-[#181533] border-[#382b61] text-slate-300 hover:text-white'
              }`}
            >
              <Volume2 className="w-3.5 h-3.5 text-pink-400" />
              Speaking (Enlarge)
            </button>
          </div>

          <div className="flex items-center justify-between pt-2 text-[11px] text-slate-400 border-t border-[#292350]">
            <span>Enlargement Ratio: <strong className="text-pink-300">+{Math.round((config.speakingEnlargeRatio - 1) * 100)}% ({config.speakingEnlargeRatio}x)</strong></span>
            <span>Orbital Rings: <strong className="text-cyan-300">{selectedStyle.ringCount} Rings ({selectedStyle.ringType})</strong></span>
          </div>
        </div>
      </div>

      {/* Android Native Overlay Diagnostics */}
      <div className="p-4 rounded-[18px] bg-[#121124] border border-[#3d2970] flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-xl bg-purple-950/60 border border-purple-500/40 flex items-center justify-center shrink-0 text-purple-300">
            <Smartphone className="w-5 h-5" />
          </div>
          <div>
            <div className="text-sm font-bold text-white flex items-center gap-2">
              Android Native Floating Overlay
              <span
                className={`text-[9.5px] px-2 py-0.5 rounded-full font-mono font-bold uppercase tracking-wider border ${
                  overlayPermission
                    ? 'bg-emerald-950/80 text-emerald-300 border-emerald-500/40'
                    : 'bg-amber-950/80 text-amber-300 border-amber-500/40'
                }`}
              >
                {overlayPermission ? 'Granted' : 'Needs Permission'}
              </span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed mt-0.5">
              Renders circular 3D hologram directly over Android Home Screen and apps via{' '}
              <code className="text-cyan-300 font-mono text-[11px]">SYSTEM_ALERT_WINDOW</code>.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          {!overlayPermission && (
            <button
              type="button"
              onClick={handleRequestOverlayPermission}
              className="px-3.5 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5 shadow-[0_0_10px_rgba(245,158,11,0.4)]"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              Grant Overlay
            </button>
          )}

          <button
            type="button"
            onClick={handleToggleBackgroundListening}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-colors cursor-pointer flex items-center gap-1.5 ${
              config.backgroundListeningEnabled
                ? 'bg-emerald-600 hover:bg-emerald-500 text-white'
                : 'bg-[#1c1938] hover:bg-[#28244e] text-slate-300 border border-[#3d2970]'
            }`}
          >
            <Mic className="w-3.5 h-3.5" />
            {config.backgroundListeningEnabled ? 'Mic Active in Bg' : 'Enable Bg Mic'}
          </button>
        </div>
      </div>

      {/* Hologram Tuning Sliders */}
      <div className="p-5 rounded-[20px] bg-[#131226] border border-[#3d2970] space-y-4">
        <div className="flex items-center justify-between border-b border-[#2d2854] pb-3">
          <div className="flex items-center gap-2">
            <Sliders className="w-4 h-4 text-cyan-400" />
            <span className="text-sm font-bold text-white">Dimension & Animation Tuning</span>
          </div>
          <button
            type="button"
            onClick={handleResetDefaults}
            className="text-xs text-slate-400 hover:text-cyan-300 cursor-pointer transition-colors"
          >
            Reset Defaults
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5 pt-1">
          {/* Base Hologram Size */}
          <div className="space-y-1.5">
            <div className="flex justify-between text-xs">
              <span className="text-slate-300 font-medium">Hologram Base Size</span>
              <span className="font-mono text-cyan-300 font-bold">{config.baseSizePx}px</span>
            </div>
            <input
              type="range"
              min={90}
              max={220}
              step={5}
              value={config.baseSizePx}
              onChange={(e) => hologramManager.setBaseSize(parseInt(e.target.value, 10))}
              className="w-full accent-cyan-400 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-500">
              <span>90px (Compact)</span>
              <span>150px (Balanced)</span>
              <span>220px (Heroic)</span>
            </div>
          </div>

          {/* Speaking Enlargement Ratio */}
          <div className="space-y-1.5">
            <div className="flex justify-between text-xs">
              <span className="text-slate-300 font-medium flex items-center gap-1.5">
                Speaking Enlargement
                <span className="text-[10px] bg-pink-950/70 text-pink-300 border border-pink-500/40 px-1.5 rounded">
                  High Priority
                </span>
              </span>
              <span className="font-mono text-pink-300 font-bold">{config.speakingEnlargeRatio}x</span>
            </div>
            <input
              type="range"
              min={1.1}
              max={1.6}
              step={0.05}
              value={config.speakingEnlargeRatio}
              onChange={(e) => hologramManager.setSpeakingEnlargeRatio(parseFloat(e.target.value))}
              className="w-full accent-pink-400 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-500">
              <span>1.1x (+10%)</span>
              <span>1.35x (+35% Recommended)</span>
              <span>1.6x (+60%)</span>
            </div>
          </div>

          {/* Neon Glow Intensity */}
          <div className="space-y-1.5">
            <div className="flex justify-between text-xs">
              <span className="text-slate-300 font-medium">Neon Glow Intensity</span>
              <span className="font-mono text-purple-300 font-bold">{Math.round(config.glowIntensity * 100)}%</span>
            </div>
            <input
              type="range"
              min={0.5}
              max={1.5}
              step={0.05}
              value={config.glowIntensity}
              onChange={(e) => hologramManager.setGlowIntensity(parseFloat(e.target.value))}
              className="w-full accent-purple-400 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-500">
              <span>50% (Subtle)</span>
              <span>100% (Neon)</span>
              <span>150% (Hyper-bloom)</span>
            </div>
          </div>

          {/* Animation & Orbital Speed */}
          <div className="space-y-1.5">
            <div className="flex justify-between text-xs">
              <span className="text-slate-300 font-medium">Orbital Ring Speed</span>
              <span className="font-mono text-emerald-300 font-bold">{config.animationSpeed}x</span>
            </div>
            <input
              type="range"
              min={0.5}
              max={2.5}
              step={0.1}
              value={config.animationSpeed}
              onChange={(e) => hologramManager.setAnimationSpeed(parseFloat(e.target.value))}
              className="w-full accent-emerald-400 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-500">
              <span>0.5x (Gentle)</span>
              <span>1.0x (Standard)</span>
              <span>2.5x (Hyper-speed)</span>
            </div>
          </div>
        </div>
      </div>

      {/* Selectable Styles Gallery — All 23 User Reference Designs */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Layers className="w-4 h-4 text-cyan-400" />
              All 22 Hologram Reference Styles
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Faithful 1-to-1 reproductions of each supplied visual blueprint. Circular, &quot;ZOYA&quot; centered.
            </p>
          </div>

          {/* Filter Search */}
          <div className="relative w-full sm:w-64">
            <input
              type="text"
              placeholder="Search 22 styles..."
              value={searchFilter}
              onChange={(e) => setSearchFilter(e.target.value)}
              className="w-full pl-3 pr-8 py-1.5 rounded-xl bg-[#0d0c1d] border border-[#3d2970] text-xs text-white placeholder-slate-500 outline-none focus:border-cyan-400"
            />
            {searchFilter && (
              <button
                type="button"
                onClick={() => setSearchFilter('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white text-xs"
              >
                ✕
              </button>
            )}
          </div>
        </div>

        {/* Style Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5 max-h-[560px] overflow-y-auto pr-1">
          {filteredStyles.map((style) => {
            const isSelected = style.id === config.selectedStyleId || style.index === config.selectedStyleIndex;
            return (
              <button
                key={style.id}
                type="button"
                onClick={() => handleSelectStyle(style.id)}
                className={`p-3.5 rounded-2xl border text-left transition-all duration-200 cursor-pointer flex flex-col justify-between gap-3 group relative overflow-hidden ${
                  isSelected
                    ? 'bg-gradient-to-br from-[#1c183b] to-[#121026] border-cyan-400 shadow-[0_0_16px_rgba(6,182,212,0.35)] ring-1 ring-cyan-400'
                    : 'bg-[#100f21] border-[#302852] hover:bg-[#181630] hover:border-[#4d3d7d]'
                }`}
              >
                {/* Reference Image Thumbnail + Live Hologram Miniature */}
                <div className="flex items-center gap-3">
                  <div className="relative w-16 h-16 rounded-xl overflow-hidden shrink-0 bg-black border border-white/10 shadow-md">
                    <img
                      src={style.referenceImage}
                      alt={style.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      loading="lazy"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                    <span className="absolute bottom-1 right-1 text-[8.5px] font-mono font-bold text-cyan-300 bg-black/60 px-1 rounded">
                      #{style.index.toString().padStart(2, '0')}
                    </span>
                  </div>

                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between gap-1">
                      <h4 className="text-xs font-bold text-white truncate">{style.name}</h4>
                      {isSelected && (
                        <span className="w-4 h-4 rounded-full bg-cyan-400 text-slate-950 flex items-center justify-center shrink-0">
                          <Check className="w-2.5 h-2.5 stroke-[3]" />
                        </span>
                      )}
                    </div>
                    <p className="text-[10.5px] text-slate-400 line-clamp-2 mt-0.5 leading-snug">
                      {style.description}
                    </p>

                    {/* Color Swatch Badges */}
                    <div className="flex items-center gap-1.5 mt-2">
                      <span
                        className="w-3 h-3 rounded-full border border-white/30 shadow-sm"
                        style={{ backgroundColor: style.primaryColor }}
                        title={`Primary: ${style.primaryColor}`}
                      />
                      <span
                        className="w-3 h-3 rounded-full border border-white/30 shadow-sm"
                        style={{ backgroundColor: style.secondaryColor }}
                        title={`Secondary: ${style.secondaryColor}`}
                      />
                      {style.accentColor && (
                        <span
                          className="w-3 h-3 rounded-full border border-white/30 shadow-sm"
                          style={{ backgroundColor: style.accentColor }}
                          title={`Accent: ${style.accentColor}`}
                        />
                      )}
                      <span className="text-[9.5px] text-slate-400 font-mono ml-1">
                        {style.ringCount} Rings
                      </span>
                    </div>
                  </div>
                </div>

                {/* Tags Pill */}
                <div className="flex flex-wrap gap-1 pt-1 border-t border-white/5">
                  {style.features.slice(0, 3).map((f) => (
                    <span
                      key={f}
                      className="text-[9px] font-medium px-1.5 py-0.5 rounded bg-white/5 text-slate-300"
                    >
                      {f}
                    </span>
                  ))}
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
