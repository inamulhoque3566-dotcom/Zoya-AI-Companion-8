import React, { useState, useEffect } from 'react';
import { 
  History, 
  X, 
  Trash2, 
  Phone, 
  MessageSquare, 
  Globe, 
  LayoutGrid, 
  Mic, 
  PenTool, 
  Clock, 
  Calendar,
  RotateCcw
} from 'lucide-react';

export interface HistoryItem {
  id: string;
  type: 'voice' | 'call' | 'message' | 'app' | 'website' | 'sketch' | 'chat';
  title: string;
  detail: string;
  timestamp: string;
}

const DEFAULT_HISTORY: HistoryItem[] = [
  {
    id: 'hist-1',
    type: 'voice',
    title: 'वॉयस टॉक (Tap to Talk)',
    detail: '"नमस्ते जोया, आप कैसी हैं?" -> जोया का उत्तर: "मैं बहुत खुश हूँ!"',
    timestamp: 'आज, 10:20 AM',
  },
  {
    id: 'hist-2',
    type: 'app',
    title: 'ऐप लॉन्च किया',
    detail: '"YouTube kholo" -> YouTube ऐप खोला गया',
    timestamp: 'आज, 09:45 AM',
  },
  {
    id: 'hist-3',
    type: 'call',
    title: 'फ़ोन कॉल',
    detail: '"Mummy ko call karo" -> Mummy (+91 98765 43210) पर कॉल',
    timestamp: 'कल, 08:30 PM',
  },
  {
    id: 'hist-4',
    type: 'message',
    title: 'व्हाट्सएप संदेश',
    detail: '"Papa ko WhatsApp karo" -> पापा को संदेश भेजा',
    timestamp: 'कल, 06:15 PM',
  },
  {
    id: 'hist-5',
    type: 'website',
    title: 'वेबसाइट बनाई',
    detail: '"ek cafe ki website banao" -> कैफ़े लैंडिंग पेज जनरेट किया',
    timestamp: '25 अक्टूबर, 04:10 PM',
  },
  {
    id: 'hist-6',
    type: 'sketch',
    title: 'फोटो स्केच / ड्राइंग',
    detail: '"drawing banao" -> पेंसिल स्केच कैनवास सक्रिय हुआ',
    timestamp: '24 अक्टूबर, 02:20 PM',
  },
];

interface ZoyaHistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onRepeatAction?: (item: HistoryItem) => void;
}

export const ZoyaHistoryModal: React.FC<ZoyaHistoryModalProps> = ({
  isOpen,
  onClose,
  onRepeatAction,
}) => {
  const [historyItems, setHistoryItems] = useState<HistoryItem[]>(() => {
    try {
      const saved = localStorage.getItem('zoya_action_history');
      if (saved) return JSON.parse(saved);
    } catch {
      // fallback
    }
    return DEFAULT_HISTORY;
  });

  const [filter, setFilter] = useState<'all' | 'voice' | 'actions'>('all');

  useEffect(() => {
    try {
      localStorage.setItem('zoya_action_history', JSON.stringify(historyItems));
    } catch {
      // ignore
    }
  }, [historyItems]);

  if (!isOpen) return null;

  const handleClearAll = () => {
    if (window.confirm('क्या आप पूरा इतिहास मिटाना चाहते हैं?')) {
      setHistoryItems([]);
    }
  };

  const filteredItems = historyItems.filter((item) => {
    if (filter === 'voice') return item.type === 'voice' || item.type === 'chat';
    if (filter === 'actions') return item.type !== 'voice' && item.type !== 'chat';
    return true;
  });

  const getIcon = (type: HistoryItem['type']) => {
    switch (type) {
      case 'voice':
        return <Mic className="w-4 h-4 text-pink-400" />;
      case 'call':
        return <Phone className="w-4 h-4 text-emerald-400" />;
      case 'message':
        return <MessageSquare className="w-4 h-4 text-blue-400" />;
      case 'app':
        return <LayoutGrid className="w-4 h-4 text-amber-400" />;
      case 'website':
        return <Globe className="w-4 h-4 text-indigo-400" />;
      case 'sketch':
        return <PenTool className="w-4 h-4 text-purple-400" />;
      default:
        return <Clock className="w-4 h-4 text-slate-400" />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-xl bg-[#0c0a20] border border-purple-500/30 rounded-3xl shadow-[0_10px_50px_rgba(217,70,239,0.2)] flex flex-col max-h-[85vh] overflow-hidden">
        
        {/* Top Header */}
        <div className="p-4 sm:p-5 border-b border-purple-900/40 flex items-center justify-between bg-gradient-to-r from-purple-950/40 to-slate-900/40">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-indigo-600 to-pink-500 flex items-center justify-center shadow-lg shadow-pink-500/20">
              <History className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-bold text-white flex items-center gap-2">
                इतिहास (History)
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/30">
                  {historyItems.length} रिकॉर्ड
                </span>
              </h2>
              <p className="text-xs text-purple-300/70">
                हाल ही की बातचीत, वॉयस कमांड और किए गए कार्य
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {historyItems.length > 0 && (
              <button
                onClick={handleClearAll}
                className="p-2 rounded-xl text-slate-400 hover:text-red-400 hover:bg-red-500/10 transition-colors"
                title="इतिहास साफ़ करें"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            )}
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Filter Tabs */}
        <div className="px-4 py-2.5 bg-purple-950/20 border-b border-purple-900/30 flex items-center gap-2 text-xs">
          <button
            onClick={() => setFilter('all')}
            className={`px-3 py-1 rounded-lg transition-all ${
              filter === 'all'
                ? 'bg-purple-600 text-white font-medium shadow-sm'
                : 'bg-purple-950/40 text-purple-300/60 hover:text-white'
            }`}
          >
            सभी (All)
          </button>
          <button
            onClick={() => setFilter('voice')}
            className={`px-3 py-1 rounded-lg transition-all ${
              filter === 'voice'
                ? 'bg-pink-600 text-white font-medium shadow-sm'
                : 'bg-purple-950/40 text-purple-300/60 hover:text-white'
            }`}
          >
            वॉयस बातचीत (Voice)
          </button>
          <button
            onClick={() => setFilter('actions')}
            className={`px-3 py-1 rounded-lg transition-all ${
              filter === 'actions'
                ? 'bg-indigo-600 text-white font-medium shadow-sm'
                : 'bg-purple-950/40 text-purple-300/60 hover:text-white'
            }`}
          >
            एक्शन व ऐप्स (Actions)
          </button>
        </div>

        {/* History Items List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-2.5 custom-scrollbar">
          {filteredItems.length === 0 ? (
            <div className="text-center py-12 text-purple-300/60">
              <History className="w-10 h-10 mx-auto mb-2 opacity-30 text-purple-400" />
              <p className="text-sm font-medium">कोई इतिहास रिकॉर्ड नहीं है</p>
              <p className="text-xs text-purple-300/40 mt-1">
                माइक से बोलकर या कार्ड्स पर टैप करके कुछ शुरू करें।
              </p>
            </div>
          ) : (
            filteredItems.map((item) => (
              <div
                key={item.id}
                className="p-3.5 rounded-2xl bg-[#13112d]/80 hover:bg-[#18153b] border border-purple-900/40 hover:border-purple-500/40 transition-all flex items-start justify-between gap-3 group"
              >
                <div className="flex items-start gap-3 flex-1 min-w-0">
                  <div className="w-8 h-8 rounded-xl bg-purple-950/60 border border-purple-500/30 flex items-center justify-center shrink-0 mt-0.5">
                    {getIcon(item.type)}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <h4 className="text-xs sm:text-sm font-semibold text-white">
                        {item.title}
                      </h4>
                      <span className="text-[10px] text-purple-400/50 flex items-center gap-1 font-mono">
                        <Calendar className="w-2.5 h-2.5" />
                        {item.timestamp}
                      </span>
                    </div>
                    <p className="text-xs text-purple-200/70 mt-1 line-clamp-2">
                      {item.detail}
                    </p>
                  </div>
                </div>

                {onRepeatAction && (
                  <button
                    onClick={() => onRepeatAction(item)}
                    className="p-1.5 rounded-lg text-purple-400/50 hover:text-pink-300 hover:bg-pink-500/10 transition-colors shrink-0"
                    title="दोबारा करें"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
