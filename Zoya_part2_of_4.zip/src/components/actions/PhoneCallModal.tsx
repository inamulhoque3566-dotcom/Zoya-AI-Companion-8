import React, { useState, useEffect, useRef } from 'react';
import { 
  X, 
  Phone, 
  PhoneOff, 
  User, 
  Mic, 
  MicOff, 
  Volume2, 
  VolumeX, 
  Clock, 
  Heart,
  Sparkles,
  PhoneCall
} from 'lucide-react';
import { micStateMachine } from '../../services/speech/MicStateMachine';
import { agentClient } from '../../services/agent/agentClient';

interface PhoneCallModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultContact?: string;
}

export const PhoneCallModal: React.FC<PhoneCallModalProps> = ({
  isOpen,
  onClose,
  defaultContact = 'Mummy',
}) => {
  const [selectedContact, setSelectedContact] = useState(defaultContact);
  const [callState, setCallState] = useState<'idle' | 'ringing' | 'connected' | 'ended'>('idle');
  const [callDuration, setCallDuration] = useState(0);
  const [isMuted, setIsMuted] = useState(false);
  const [speakerOn, setSpeakerOn] = useState(true);
  const [customNumber, setCustomNumber] = useState('');

  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const audioPlaybackRef = useRef<HTMLAudioElement | null>(null);

  const contacts = [
    { name: 'Mummy', label: 'मम्मी ❤️', number: '+91 98765 43210', voiceText: 'हाँ बेटा, बोलो! सब ठीक है ना? मैं तुम्हारी ही याद कर रही थी।' },
    { name: 'Papa', label: 'पापा 👔', number: '+91 98765 12345', voiceText: 'हाँ बेटा, कहो! क्या हालचाल हैं? कोई काम था?' },
    { name: 'Bhai', label: 'भाई 🎮', number: '+91 98765 67890', voiceText: 'अरे भाई! क्या चल रहा है? कब मिल रहे हैं?' },
    { name: 'Best Friend', label: 'दोस्त 🌟', number: '+91 98765 99999', voiceText: 'हाय! क्या कर रहा है? जल्दी बता कोई नया प्लान है क्या?' },
  ];

  const currentContact = contacts.find((c) => c.name === selectedContact) || {
    name: selectedContact || 'Custom',
    label: selectedContact || 'कॉल',
    number: customNumber || '+91 98765 00000',
    voiceText: 'हेलो! आपकी कॉल कनेक्ट हो गई है।',
  };

  useEffect(() => {
    if (isOpen && callState === 'idle') {
      startCall(defaultContact);
    }
    return () => {
      endCall();
    };
  }, [isOpen]);

  const startCall = (contactName: string) => {
    // Release native wake word and central mic so call audio has full priority
    micStateMachine.requestPauseForCall('phone');
    setSelectedContact(contactName);
    setCallState('ringing');
    setCallDuration(0);

    // Play ring tone beep via Web Audio API
    playRingtone();

    // Auto connect after 2.5 seconds
    setTimeout(async () => {
      setCallState('connected');
      // Speak contact greeting via neural TTS
      const contactObj = contacts.find((c) => c.name === contactName);
      if (contactObj) {
        try {
          let elevenLabsVoiceId = '';
          try {
            elevenLabsVoiceId = localStorage.getItem('zoya_elevenlabs_voice_id') || '';
          } catch {}

          const res = await fetch('/api/tts', {
            method: 'POST',
            headers: agentClient.getOwnerFetchHeaders({ 'Content-Type': 'application/json' }),
            credentials: 'include',
            body: JSON.stringify({
              text: contactObj.voiceText,
              language: 'hi-IN',
              elevenLabsVoiceId: elevenLabsVoiceId || undefined,
            }),
          });
          const contentType = res.headers.get('content-type') || '';
          let data: any = null;
          if (contentType.includes('application/json')) {
            try {
              data = await res.json();
            } catch {}
          }
          if (data?.audioData) {
            const audio = new Audio(`data:${data.mimeType || 'audio/wav'};base64,${data.audioData}`);
            audioPlaybackRef.current = audio;
            audio.play().catch(() => {});
          }
        } catch {}
      }
    }, 2800);
  };

  // Timer for connected call
  useEffect(() => {
    if (callState === 'connected') {
      timerRef.current = setInterval(() => {
        setCallDuration((prev) => prev + 1);
      }, 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [callState]);

  const endCall = () => {
    if (audioPlaybackRef.current) {
      try {
        audioPlaybackRef.current.pause();
        audioPlaybackRef.current.src = '';
      } catch {}
      audioPlaybackRef.current = null;
    }
    setCallState('ended');
    // Resume central mic and wake word via state machine
    micStateMachine.requestResumeAfterCall('phone');
    setTimeout(() => {
      setCallState('idle');
      onClose();
    }, 800);
  };

  // Synthesize soft phone ring sound
  const playRingtone = () => {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(440, ctx.currentTime);
      gain.gain.setValueAtTime(0.08, ctx.currentTime);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 1.2);
    } catch {}
  };

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60).toString().padStart(2, '0');
    const s = (secs % 60).toString().padStart(2, '0');
    return `${m}:${s}`;
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-sm bg-gradient-to-b from-slate-900 to-slate-950 rounded-3xl border border-slate-800 shadow-2xl p-6 flex flex-col items-center justify-between min-h-[520px]">
        {/* Top Dismiss Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Contact Info Header */}
        <div className="flex flex-col items-center text-center mt-4 space-y-2">
          <div className="relative">
            <div className="w-24 h-24 rounded-full bg-gradient-to-tr from-emerald-400 to-teal-600 flex items-center justify-center text-white text-3xl font-bold shadow-[0_0_35px_rgba(16,185,129,0.3)]">
              {currentContact.label.charAt(0)}
            </div>
            {callState === 'ringing' && (
              <div className="absolute inset-0 rounded-full border-2 border-emerald-400/60 animate-ping" />
            )}
          </div>

          <div>
            <h3 className="text-xl font-bold text-slate-100">{currentContact.label}</h3>
            <p className="text-xs text-slate-400 font-mono mt-0.5">{currentContact.number}</p>
          </div>

          <div className="flex items-center gap-1.5 text-xs font-mono font-medium">
            {callState === 'ringing' && (
              <span className="text-amber-400 animate-pulse">कॉलिंग... (Ringing)</span>
            )}
            {callState === 'connected' && (
              <div className="flex items-center gap-1.5 text-emerald-400">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span>कनेक्टेड · {formatTime(callDuration)}</span>
              </div>
            )}
            {callState === 'ended' && <span className="text-rose-400">कॉल समाप्त (Ended)</span>}
          </div>
        </div>

        {/* Live Spoken Greeting Banner when connected */}
        {callState === 'connected' && (
          <div className="w-full p-3 rounded-2xl bg-slate-900/90 border border-slate-800 text-center text-xs text-slate-200 font-sans shadow-lg animate-fade-in">
            &ldquo;{currentContact.voiceText}&rdquo;
          </div>
        )}

        {/* Quick Contact Switcher when idle */}
        {callState === 'idle' && (
          <div className="w-full space-y-2">
            <div className="text-[11px] text-slate-400 text-center font-mono">किसे कॉल करना है चुनें:</div>
            <div className="grid grid-cols-2 gap-2">
              {contacts.map((c) => (
                <button
                  key={c.name}
                  onClick={() => startCall(c.name)}
                  className="p-2.5 bg-slate-950 hover:bg-slate-800 border border-slate-800 rounded-xl text-left transition-colors flex items-center gap-2"
                >
                  <PhoneCall className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span className="text-xs font-medium text-slate-200 truncate">{c.label}</span>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* In-Call Action Buttons */}
        <div className="w-full space-y-4">
          <div className="flex items-center justify-center gap-6">
            <button
              onClick={() => setIsMuted(!isMuted)}
              className={`p-3.5 rounded-full border transition-colors ${
                isMuted
                  ? 'bg-rose-950/80 border-rose-800 text-rose-300'
                  : 'bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-800'
              }`}
              title="माइक म्यूट करें"
            >
              {isMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
            </button>

            <button
              onClick={() => setSpeakerOn(!speakerOn)}
              className={`p-3.5 rounded-full border transition-colors ${
                speakerOn
                  ? 'bg-sky-950/80 border-sky-800 text-sky-300'
                  : 'bg-slate-900 border-slate-800 text-slate-400 hover:bg-slate-800'
              }`}
              title="स्पीकर टॉगल करें"
            >
              {speakerOn ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
            </button>

            {/* Direct Mobile Dialer Link */}
            <a
              href={`tel:${currentContact.number}`}
              className="p-3.5 rounded-full bg-slate-900 border border-slate-800 text-slate-300 hover:bg-slate-800 transition-colors"
              title="असली फोन डायलर पर खोलें"
            >
              <Phone className="w-5 h-5" />
            </a>
          </div>

          {/* End Call / Start Call Button */}
          <div className="flex justify-center">
            {callState !== 'idle' ? (
              <button
                onClick={endCall}
                className="w-16 h-16 rounded-full bg-red-600 hover:bg-red-500 text-white flex items-center justify-center shadow-lg transition-transform hover:scale-105"
                title="कॉल काटें (End Call)"
              >
                <PhoneOff className="w-7 h-7" />
              </button>
            ) : (
              <button
                onClick={() => startCall(selectedContact)}
                className="w-16 h-16 rounded-full bg-emerald-600 hover:bg-emerald-500 text-white flex items-center justify-center shadow-lg transition-transform hover:scale-105"
                title="कॉल शुरू करें"
              >
                <Phone className="w-7 h-7" />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
