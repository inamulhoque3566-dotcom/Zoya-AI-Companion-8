import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { X, Sparkles, Eye, Wind, Camera, CheckCircle2, Sliders, Maximize2 } from 'lucide-react';
import { ALL_AVATARS_ANATOMY, AvatarAnatomyConfig } from '../../data/avatarAnatomy';
import { ANIME_3D_AVATARS, Anime3DAvatar } from '../../data/anime3DAvatars';

export const TARGET_14_AVATARS = [
  'boho_mini_dress',
  'peasant_blouse_skirt',
  'pink_knit_maxi',
  'floral_palazzo_pants',
  'red_cardigan_floral',
  'plum_royal_anarkali',
  'ivory_floral_anarkali',
  'classic',
  'avatar_urban_crop_hoodie',
  'avatar_white_ruffle_babydoll',
  'avatar_pink_athleisure_track',
  'avatar_pastel_blue_knit_shorts',
  'avatar_slate_blue_regal_kurta',
  'avatar_midnight_gold_zari_saree',
];

interface AvatarInstance {
  id: string;
  name: string;
  group: THREE.Group;
  baseMesh: THREE.Mesh;
  eyelidMesh: THREE.Mesh;
  eyelidMat: THREE.MeshBasicMaterial;
  halfTex: THREE.Texture | null;
  closedTex: THREE.Texture | null;
  isBlinking: boolean;
  blinkStartTime: number;
  nextBlinkTime: number;
  isDoubleBlink: boolean;
  timeOffset: number;
  amplitude: number;
}

interface All14LivingAvatarsShowcaseProps {
  isOpen: boolean;
  onClose: () => void;
  initialLayout?: 'grid2x7' | 'lineup' | 'spotlight';
}

export const All14LivingAvatarsShowcase: React.FC<All14LivingAvatarsShowcaseProps> = ({
  isOpen,
  onClose,
  initialLayout = 'grid2x7',
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [layoutMode, setLayoutMode] = useState<'grid2x7' | 'lineup' | 'spotlight'>(initialLayout);
  const [selectedAvatarId, setSelectedAvatarId] = useState<string>(TARGET_14_AVATARS[0]);
  const [breezeScale, setBreezeScale] = useState<number>(1.0);
  const [isBlinkingPaused, setIsBlinkingPaused] = useState<boolean>(false);
  const [activeBlinkingCount, setActiveBlinkingCount] = useState<number>(0);
  const [isLoaded, setIsLoaded] = useState<boolean>(false);

  const instancesRef = useRef<AvatarInstance[]>([]);
  const animFrameRef = useRef<number | null>(null);
  const breezeScaleRef = useRef(breezeScale);
  breezeScaleRef.current = breezeScale;

  useEffect(() => {
    if (!isOpen) return;

    const container = containerRef.current;
    const canvas = canvasRef.current;
    if (!container || !canvas) return;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x060919); // Clean, deep dark studio background without darkening

    // Strictly locked-off perspective camera
    const camera = new THREE.PerspectiveCamera(38, 1, 0.1, 100);
    camera.position.set(0, 0, 7.5);
    camera.lookAt(0, 0, 0);

    const renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: true,
      alpha: false,
      powerPreference: 'high-performance',
      preserveDrawingBuffer: true,
    });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2.0));
    renderer.toneMapping = THREE.NoToneMapping;
    renderer.outputColorSpace = THREE.SRGBColorSpace; // Accurate, bright sRGB colors - zero color shift

    const textureLoader = new THREE.TextureLoader();
    const instances: AvatarInstance[] = [];

    const avatarsRoot = new THREE.Group();
    scene.add(avatarsRoot);

    // Track resources for clean disposal
    const geometriesToDispose: THREE.BufferGeometry[] = [];
    const materialsToDispose: THREE.Material[] = [];
    const texturesToDispose: THREE.Texture[] = [];

    // Load each avatar with its modular textures, hair mask, and eyelid layers
    TARGET_14_AVATARS.forEach((avatarId, idx) => {
      const anatomy: AvatarAnatomyConfig = ALL_AVATARS_ANATOMY[avatarId] || {
        id: avatarId,
        name: avatarId,
        widthPx: 768,
        heightPx: 1200,
        aspectRatio: 768 / 1200,
        bodyWidth3D: 1.0,
        bodyHeight3D: 1.6,
        modularPath: `/assets/images/avatars_modular/${avatarId}`,
        hasGlasses: false,
        hasFaceBlendshapes: true,
        landmarks: {
          shoulderY: 0.8,
          chestY: 0.5,
          waistY: 0.2,
          hipY: -0.1,
          feetY: -1.45,
          shoulderWidth: 0.7,
          waistWidth: 0.5,
        },
      };

      const avData = ANIME_3D_AVATARS.find((a) => a.id === avatarId);
      const name = avData?.name || anatomy.name;

      const avatarGroup = new THREE.Group();
      avatarsRoot.add(avatarGroup);

      const targetHeight = 1.45;
      const targetWidth = targetHeight * (anatomy.widthPx / anatomy.heightPx);

      // Base subdivided geometry for organic hair displacement
      const geo = new THREE.PlaneGeometry(targetWidth, targetHeight, 40, 64);
      geometriesToDispose.push(geo);

      const bodyTexturePath = avData?.transparentPng || `${anatomy.modularPath}/body_skin.png`;
      const baseTex = textureLoader.load(bodyTexturePath);
      baseTex.colorSpace = THREE.SRGBColorSpace;
      baseTex.minFilter = THREE.LinearMipmapLinearFilter;
      baseTex.magFilter = THREE.LinearFilter;
      texturesToDispose.push(baseTex);

      const hairMaskPath = `${anatomy.modularPath}/hair_mask.png`;
      const hairMaskTex = textureLoader.load(hairMaskPath);
      hairMaskTex.colorSpace = THREE.LinearSRGBColorSpace;
      hairMaskTex.minFilter = THREE.LinearFilter;
      hairMaskTex.magFilter = THREE.LinearFilter;
      hairMaskTex.wrapS = THREE.ClampToEdgeWrapping;
      hairMaskTex.wrapT = THREE.ClampToEdgeWrapping;
      texturesToDispose.push(hairMaskTex);

      const amplitude = targetWidth * 0.0085; // Subtle, realistic hair strand sway in soft breeze

      // Custom unlit shader with hair strand vertex displacement
      const mat = new THREE.ShaderMaterial({
        uniforms: {
          uTime: { value: 0 },
          uTexture: { value: baseTex },
          uHairMask: { value: hairMaskTex },
          uAmplitude: { value: amplitude },
          uTimeOffset: { value: idx * 1.47 }, // Individual desynchronized breeze phase per avatar
        },
        vertexShader: `
          uniform float uTime;
          uniform float uTimeOffset;
          uniform sampler2D uHairMask;
          uniform float uAmplitude;
          varying vec2 vUv;

          void main() {
            vUv = uv;
            vec3 pos = position;

            float mask = texture2D(uHairMask, uv).r;
            if (mask > 0.003) {
              float t = uTime + uTimeOffset;
              // Organic breeze harmonic wave: gentle left-to-right swaying
              float wave1 = sin(t * 1.55 + (1.0 - uv.y) * 5.2);
              float wave2 = sin(t * 0.95 + (1.0 - uv.y) * 8.4 + 1.2) * 0.45;
              float microNoise = sin(t * 2.3 + uv.x * 12.0) * 0.12;

              float displacement = (wave1 + wave2 + microNoise) * uAmplitude * mask;
              pos.x += displacement;
              // Subtle 3D depth billow in breeze
              pos.z += sin(t * 1.15 + (1.0 - uv.y) * 5.6) * uAmplitude * 0.35 * mask;
            }

            gl_Position = projectionMatrix * modelViewMatrix * vec4(pos, 1.0);
          }
        `,
        fragmentShader: `
          uniform sampler2D uTexture;
          varying vec2 vUv;

          void main() {
            vec4 color = texture2D(uTexture, vUv);
            if (color.a < 0.01) discard;
            // Pure unlit 1:1 color output with accurate Linear->sRGB encoding
            gl_FragColor = color;
            #include <tonemapping_fragment>
            #include <colorspace_fragment>
          }
        `,
        transparent: true,
        depthWrite: true,
        side: THREE.DoubleSide,
      });
      materialsToDispose.push(mat);

      const baseMesh = new THREE.Mesh(geo, mat);
      baseMesh.position.set(0, 0, 0);
      avatarGroup.add(baseMesh);

      // Eyelid overlay (biological blinking using original eyelids)
      const eyeMarks = anatomy.eyeLandmarks || {
        cropW: 190,
        cropH: 80,
        eyeCenterX: anatomy.widthPx * 0.5,
        eyeCenterY: anatomy.heightPx * 0.15,
      };

      const { cropW, cropH, eyeCenterX, eyeCenterY } = eyeMarks;
      const eyeMeshW = (cropW / anatomy.widthPx) * targetWidth;
      const eyeMeshH = (cropH / anatomy.heightPx) * targetHeight;

      const normX = (eyeCenterX - anatomy.widthPx * 0.5) / anatomy.widthPx;
      const normY = (anatomy.heightPx * 0.5 - eyeCenterY) / anatomy.heightPx;
      const eyeLocalX = normX * targetWidth;
      const eyeLocalY = normY * targetHeight;

      const eyeGeo = new THREE.PlaneGeometry(eyeMeshW, eyeMeshH, 1, 1);
      geometriesToDispose.push(eyeGeo);

      const eyelidMat = new THREE.MeshBasicMaterial({
        map: null,
        transparent: true,
        opacity: 1,
        depthWrite: false,
        depthTest: false,
        side: THREE.DoubleSide,
      });
      materialsToDispose.push(eyelidMat);

      const eyelidMesh = new THREE.Mesh(eyeGeo, eyelidMat);
      eyelidMesh.renderOrder = 10;
      eyelidMesh.position.set(eyeLocalX, eyeLocalY, 0.003);
      eyelidMesh.visible = false;
      avatarGroup.add(eyelidMesh);

      const closedTex = textureLoader.load(`${anatomy.modularPath}/eyes_closed.png`, (tex) => {
        tex.needsUpdate = true;
        if (eyelidMat) {
          if (!eyelidMat.map) eyelidMat.map = tex;
          eyelidMat.needsUpdate = true;
        }
      });
      closedTex.colorSpace = THREE.SRGBColorSpace;
      texturesToDispose.push(closedTex);

      const halfTex = textureLoader.load(`${anatomy.modularPath}/eyes_half.png`, (tex) => {
        tex.needsUpdate = true;
        if (eyelidMat) eyelidMat.needsUpdate = true;
      });
      halfTex.colorSpace = THREE.SRGBColorSpace;
      texturesToDispose.push(halfTex);

      // Independent randomized blink schedule
      const initialDelay = 1.0 + Math.random() * 3.5;

      instances.push({
        id: avatarId,
        name,
        group: avatarGroup,
        baseMesh,
        eyelidMesh,
        eyelidMat,
        halfTex,
        closedTex,
        isBlinking: false,
        blinkStartTime: 0,
        nextBlinkTime: initialDelay,
        isDoubleBlink: false,
        timeOffset: idx * 1.47,
        amplitude,
      });
    });

    instancesRef.current = instances;
    setIsLoaded(true);

    // Apply layout positions (Grid 2x7, Lineup, or Spotlight)
    const updateLayout = () => {
      const mode = layoutMode;
      const total = instances.length;

      if (mode === 'grid2x7') {
        // 2 rows of 7 avatars (or 7 rows of 2 on tall screens)
        const containerW = container.clientWidth || 800;
        const containerH = container.clientHeight || 600;
        const isTall = containerH > containerW;

        if (isTall) {
          // 7 rows x 2 cols
          const cols = 2;
          const rows = 7;
          const spacingX = 1.35;
          const spacingY = 0.95;
          const scale = 0.65;

          instances.forEach((inst, i) => {
            const col = i % cols;
            const row = Math.floor(i / cols);
            const x = (col - (cols - 1) / 2) * spacingX;
            const y = ((rows - 1) / 2 - row) * spacingY;
            inst.group.position.set(x, y, 0);
            inst.group.scale.set(scale, scale, scale);
            inst.group.visible = true;
          });
          camera.position.set(0, 0, 7.8);
        } else {
          // 2 rows x 7 cols
          const cols = 7;
          const rows = 2;
          const spacingX = 1.15;
          const spacingY = 1.65;
          const scale = 0.72;

          instances.forEach((inst, i) => {
            const col = i % cols;
            const row = Math.floor(i / cols);
            const x = (col - (cols - 1) / 2) * spacingX;
            const y = ((rows - 1) / 2 - row) * spacingY;
            inst.group.position.set(x, y, 0);
            inst.group.scale.set(scale, scale, scale);
            inst.group.visible = true;
          });
          camera.position.set(0, 0, 8.2);
        }
      } else if (mode === 'lineup') {
        // Single panoramic row with all 14 side-by-side
        const spacingX = 1.05;
        const scale = 0.58;
        instances.forEach((inst, i) => {
          const x = (i - (total - 1) / 2) * spacingX;
          inst.group.position.set(x, 0, 0);
          inst.group.scale.set(scale, scale, scale);
          inst.group.visible = true;
        });
        camera.position.set(0, 0, 11.5);
      } else if (mode === 'spotlight') {
        // Spotlight selected avatar centered, others hidden
        instances.forEach((inst) => {
          if (inst.id === selectedAvatarId) {
            inst.group.position.set(0, 0, 0);
            inst.group.scale.set(1.4, 1.4, 1.4);
            inst.group.visible = true;
          } else {
            inst.group.visible = false;
          }
        });
        camera.position.set(0, 0, 4.2);
      }

      camera.lookAt(0, 0, 0);
      camera.updateProjectionMatrix();
    };

    updateLayout();

    const handleResize = () => {
      if (!container || !camera || !renderer) return;
      const w = container.clientWidth || 800;
      const h = container.clientHeight || 600;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h, false);
      updateLayout();
    };

    handleResize();
    window.addEventListener('resize', handleResize);

    // Main 60fps render loop: Hair breeze swaying + independent biological eyelid blinking
    let lastTime = performance.now();
    let accumulatedTime = 0;
    let isRunning = true;

    const render = (now: number) => {
      if (!isRunning) return;

      const deltaSec = Math.min((now - lastTime) / 1000, 0.1);
      lastTime = now;
      accumulatedTime += deltaSec;

      let currentBlinking = 0;

      // Update all 14 living avatars
      instances.forEach((inst) => {
        // 1. Update hair breeze displacement shader
        const mat = inst.baseMesh.material as THREE.ShaderMaterial;
        if (mat?.uniforms?.uTime) {
          mat.uniforms.uTime.value = accumulatedTime;
          mat.uniforms.uAmplitude.value = inst.amplitude * breezeScaleRef.current;
        }

        // 2. Independent biological blinking per avatar
        if (!isBlinkingPaused) {
          if (!inst.isBlinking && accumulatedTime >= inst.nextBlinkTime) {
            inst.isBlinking = true;
            inst.blinkStartTime = accumulatedTime;
          }

          if (inst.isBlinking && inst.eyelidMat && inst.eyelidMesh) {
            currentBlinking++;
            const elapsed = accumulatedTime - inst.blinkStartTime;
            const targetHalf = inst.halfTex || inst.closedTex;
            const targetClosed = inst.closedTex || inst.halfTex;

            if (elapsed < 0.055) {
              // Phase 1: closing half
              if (inst.eyelidMat.map !== targetHalf && targetHalf) {
                inst.eyelidMat.map = targetHalf;
                inst.eyelidMat.needsUpdate = true;
              }
              inst.eyelidMesh.visible = Boolean(targetHalf);
            } else if (elapsed < 0.165) {
              // Phase 2: fully closed
              if (inst.eyelidMat.map !== targetClosed && targetClosed) {
                inst.eyelidMat.map = targetClosed;
                inst.eyelidMat.needsUpdate = true;
              }
              inst.eyelidMesh.visible = Boolean(targetClosed);
            } else if (elapsed < 0.22) {
              // Phase 3: opening half
              if (inst.eyelidMat.map !== targetHalf && targetHalf) {
                inst.eyelidMat.map = targetHalf;
                inst.eyelidMat.needsUpdate = true;
              }
              inst.eyelidMesh.visible = Boolean(targetHalf);
            } else {
              // Blink complete
              inst.eyelidMesh.visible = false;
              inst.isBlinking = false;

              if (!inst.isDoubleBlink && Math.random() < 0.16) {
                inst.isDoubleBlink = true;
                inst.nextBlinkTime = accumulatedTime + 0.12; // Rapid double-blink
              } else {
                inst.isDoubleBlink = false;
                inst.nextBlinkTime = accumulatedTime + 2.5 + Math.random() * 3.5; // Next blink in 2.5 - 6.0 seconds
              }
            }
          }
        }
      });

      setActiveBlinkingCount(currentBlinking);
      renderer.render(scene, camera);
      animFrameRef.current = requestAnimationFrame(render);
    };

    animFrameRef.current = requestAnimationFrame(render);

    return () => {
      isRunning = false;
      if (animFrameRef.current !== null) {
        cancelAnimationFrame(animFrameRef.current);
      }
      window.removeEventListener('resize', handleResize);

      // Clean disposal
      geometriesToDispose.forEach((g) => g.dispose());
      materialsToDispose.forEach((m) => m.dispose());
      texturesToDispose.forEach((t) => t.dispose());
      renderer.dispose();
    };
  }, [isOpen, layoutMode, selectedAvatarId, isBlinkingPaused]);

  const [zenMode, setZenMode] = useState<boolean>(false);
  const [backgroundColor, setBackgroundColor] = useState<string>('#060919');

  // Handle keyboard shortcuts (H to toggle Zen mode / hide text, Esc to close)
  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      } else if (e.key === 'h' || e.key === 'H') {
        setZenMode((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleCaptureShot = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    try {
      const dataUrl = canvas.toDataURL('image/png');
      const a = document.createElement('a');
      a.href = dataUrl;
      a.download = `zoya_14_living_avatars_locked_camera_${Date.now()}.png`;
      a.click();
    } catch (e) {
      console.warn('Capture failed:', e);
    }
  };

  const handleTriggerSimultaneousBlink = () => {
    const now = performance.now() / 1000;
    instancesRef.current.forEach((inst, i) => {
      // Stagger slightly so it feels organic
      inst.nextBlinkTime = now + (i * 0.08);
      inst.isBlinking = false;
    });
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="14 Living Avatars Showcase"
      className="fixed inset-0 z-50 flex flex-col bg-[#030614] select-none overflow-hidden"
    >
      {/* Top Header Bar - Hidden in Zen Mode (Zero Text / No Watermark) */}
      {!zenMode && (
        <header className="h-14 sm:h-16 px-4 sm:px-6 bg-[#090E24]/90 border-b border-[#252D5A] flex items-center justify-between shrink-0 z-20">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-indigo-500 to-purple-600 flex items-center justify-center text-white shadow-[0_0_15px_rgba(99,102,241,0.5)]">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-sm sm:text-base font-extrabold text-white tracking-tight">
                  14 Living Avatars • Locked-Off Camera Shot
                </h2>
                <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-400/40 text-emerald-300 text-[10.5px] font-extrabold flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  Live 60 FPS
                </span>
              </div>
              <p className="text-[11px] font-medium text-slate-400 hidden sm:block">
                Identical faces, clothing & brightness • Soft breeze hair sway • Independent biological eyelids
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 sm:gap-3">
            {/* Zen Mode Toggle: Hide all text & overlays for pure locked-off shot */}
            <button
              type="button"
              onClick={() => setZenMode(true)}
              className="px-3 py-1.5 rounded-xl bg-indigo-600/30 hover:bg-indigo-600/50 border border-indigo-400/40 text-indigo-200 text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer shadow-sm active:scale-95"
              title="Zen Mode: Remove all text, buttons & overlays for a pure camera shot (Press H)"
            >
              <Maximize2 className="w-3.5 h-3.5 text-indigo-300" />
              <span>Clean Shot (No Text)</span>
            </button>

            {/* Quick Screenshot Button */}
            <button
              type="button"
              onClick={handleCaptureShot}
              className="px-3 py-1.5 rounded-xl bg-[#172044] hover:bg-[#202c5c] border border-[#374478] text-slate-200 text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer shadow-sm active:scale-95"
              title="Capture high-resolution PNG shot of all 14 living avatars"
            >
              <Camera className="w-3.5 h-3.5 text-cyan-400" />
              <span className="hidden md:inline">Save Frame</span>
            </button>

            {/* Close Button */}
            <button
              type="button"
              onClick={onClose}
              className="w-9 h-9 rounded-xl bg-[#172044] hover:bg-rose-500/20 hover:border-rose-400/50 border border-[#374478] text-slate-300 hover:text-white flex items-center justify-center transition-all cursor-pointer"
              aria-label="Close Showcase"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </header>
      )}

      {/* Main Viewport: Locked-off Three.js WebGL Scene */}
      <div
        ref={containerRef}
        style={{ backgroundColor }}
        className="relative flex-1 w-full h-full min-h-0 overflow-hidden"
      >
        <canvas
          ref={canvasRef}
          data-testid="all-14-avatars-canvas"
          className="w-full h-full block cursor-default"
        />

        {/* In Zen Mode: Floating discreet toggle button at top right to restore UI */}
        {zenMode && (
          <div className="absolute top-4 right-4 z-30 flex items-center gap-2 opacity-35 hover:opacity-100 transition-opacity">
            <button
              type="button"
              onClick={() => setZenMode(false)}
              className="px-3 py-1.5 rounded-xl bg-[#0b1026]/90 border border-slate-700/60 text-slate-300 hover:text-white text-xs font-semibold backdrop-blur-md cursor-pointer shadow-lg"
              title="Show Controls (Press H)"
            >
              Show Controls (H)
            </button>
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-xl bg-[#0b1026]/90 border border-slate-700/60 text-slate-300 hover:text-white backdrop-blur-md cursor-pointer shadow-lg"
              title="Close (Esc)"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Floating Verification HUD Pill: Locked Camera & Active Blinking (Hidden in Zen mode) */}
        {!zenMode && (
          <div className="absolute top-4 left-4 z-10 flex flex-wrap items-center gap-2 pointer-events-none">
            <div className="px-3 py-1.5 rounded-full bg-[#0c1229]/85 backdrop-blur-md border border-[#2b3664] text-slate-200 text-xs font-semibold flex items-center gap-2 shadow-lg">
              <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
              <span>Camera: <strong>Static & Locked-Off</strong></span>
            </div>

            <div className="px-3 py-1.5 rounded-full bg-[#0c1229]/85 backdrop-blur-md border border-[#2b3664] text-slate-200 text-xs font-semibold flex items-center gap-2 shadow-lg">
              <Eye className="w-3.5 h-3.5 text-indigo-400" />
              <span>Active Blinking: <strong>{activeBlinkingCount} / 14</strong></span>
            </div>

            <div className="px-3 py-1.5 rounded-full bg-[#0c1229]/85 backdrop-blur-md border border-[#2b3664] text-slate-200 text-xs font-semibold flex items-center gap-2 shadow-lg">
              <Wind className="w-3.5 h-3.5 text-emerald-400" />
              <span>Hair Breeze: <strong>Soft Left-to-Right ({Math.round(breezeScale * 100)}%)</strong></span>
            </div>
          </div>
        )}

        {/* Floating Controls Bar at Bottom (Hidden in Zen mode) */}
        {!zenMode && (
          <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-10 w-[94%] max-w-2xl bg-[#090F28]/92 backdrop-blur-md border border-[#2B3564] rounded-2xl p-2.5 sm:p-3 flex flex-wrap items-center justify-between gap-2.5 shadow-2xl">
            {/* Layout Mode Switcher */}
            <div className="flex items-center gap-1.5 bg-[#121838] p-1 rounded-xl border border-[#202952]">
              <button
                type="button"
                onClick={() => setLayoutMode('grid2x7')}
                className={`px-3 py-1.5 rounded-lg text-xs font-extrabold transition-all cursor-pointer ${
                  layoutMode === 'grid2x7'
                    ? 'bg-gradient-to-r from-indigo-500 to-purple-600 text-white shadow-md'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                14 Grid View
              </button>
              <button
                type="button"
                onClick={() => setLayoutMode('lineup')}
                className={`px-3 py-1.5 rounded-lg text-xs font-extrabold transition-all cursor-pointer ${
                  layoutMode === 'lineup'
                    ? 'bg-gradient-to-r from-indigo-500 to-purple-600 text-white shadow-md'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Panorama
              </button>
              <button
                type="button"
                onClick={() => setLayoutMode('spotlight')}
                className={`px-3 py-1.5 rounded-lg text-xs font-extrabold transition-all cursor-pointer ${
                  layoutMode === 'spotlight'
                    ? 'bg-gradient-to-r from-indigo-500 to-purple-600 text-white shadow-md'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Solo Spotlight
              </button>
            </div>

            {/* Interactive Actions: Test Staggered Blink & Breeze Slider */}
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={handleTriggerSimultaneousBlink}
                className="px-3 py-1.5 rounded-xl bg-purple-600/30 hover:bg-purple-600/45 border border-purple-400/50 text-purple-200 text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer active:scale-95"
                title="Test biological blinking cycle"
              >
                <Eye className="w-3.5 h-3.5" />
                <span>Test Blink</span>
              </button>

              <div className="flex items-center gap-2 bg-[#121838] px-3 py-1.5 rounded-xl border border-[#202952]">
                <Wind className="w-3.5 h-3.5 text-slate-400" />
                <input
                  type="range"
                  min="0.3"
                  max="2.0"
                  step="0.1"
                  value={breezeScale}
                  onChange={(e) => setBreezeScale(parseFloat(e.target.value))}
                  className="w-16 sm:w-20 accent-indigo-500 cursor-pointer"
                  title="Breeze strength"
                />
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
