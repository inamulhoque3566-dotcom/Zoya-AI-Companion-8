import React, { useState, useRef } from 'react';
import { X, Play, Pause, RotateCcw, Download, Eye, Wind, Sparkles, CheckCircle2, ShieldCheck, Film, Maximize2 } from 'lucide-react';

interface FiveLivingAvatarsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const FiveLivingAvatarsModal: React.FC<FiveLivingAvatarsModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<'video' | 'interactive' | 'audit'>('video');
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [playbackRate, setPlaybackRate] = useState<number>(1.0);
  const videoRef = useRef<HTMLVideoElement | null>(null);

  if (!isOpen) return null;

  const handlePlayPause = () => {
    if (!videoRef.current) return;
    if (videoRef.current.paused) {
      videoRef.current.play();
      setIsPlaying(true);
    } else {
      videoRef.current.pause();
      setIsPlaying(false);
    }
  };

  const handleRestart = () => {
    if (!videoRef.current) return;
    videoRef.current.currentTime = 0;
    videoRef.current.play();
    setIsPlaying(true);
  };

  const handleSpeedChange = (rate: number) => {
    setPlaybackRate(rate);
    if (videoRef.current) {
      videoRef.current.playbackRate = rate;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-5xl max-h-[94vh] flex flex-col bg-[#080d22] border border-[#3d2970] rounded-2xl shadow-2xl overflow-hidden">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#251d4e] bg-[#0c1230]">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-gradient-to-tr from-[#7c4dff] to-[#00e5ff] text-white shadow-lg shadow-[#7c4dff]/30">
              <Film className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-white tracking-wide">
                  5 Living Avatars — Locked Camera Video
                </h2>
                <span className="px-2 py-0.5 text-xs font-semibold rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  Full HD 1080p
                </span>
              </div>
              <p className="text-xs text-slate-400">
                5 Avatars • Natural 2-Blink Biological Timing • Left-to-Right Gentle Hair Breeze • 100% Original Colors & Faces
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <a
              href="/assets/videos/five_avatars_living_video.mp4"
              download="five_avatars_living_video.mp4"
              className="flex items-center gap-1.5 px-3 py-1.5 bg-[#7c4dff] hover:bg-[#6a3de8] text-white text-xs font-medium rounded-lg transition-colors shadow-md"
            >
              <Download className="w-3.5 h-3.5" />
              Download MP4
            </a>
            <button
              onClick={onClose}
              className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
              aria-label="Close modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-2 px-6 pt-3 pb-2 border-b border-[#1b2140] bg-[#090e26]">
          <button
            onClick={() => setActiveTab('video')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              activeTab === 'video'
                ? 'bg-[#7c4dff] text-white shadow-md shadow-[#7c4dff]/25'
                : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <Film className="w-3.5 h-3.5" />
            Rendered MP4 Video
          </button>
          <button
            onClick={() => setActiveTab('interactive')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              activeTab === 'interactive'
                ? 'bg-[#7c4dff] text-white shadow-md shadow-[#7c4dff]/25'
                : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <Wind className="w-3.5 h-3.5" />
            Live WebGL Simulator
          </button>
          <button
            onClick={() => setActiveTab('audit')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              activeTab === 'audit'
                ? 'bg-[#7c4dff] text-white shadow-md shadow-[#7c4dff]/25'
                : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            Eye & Hair Quality Audit
          </button>
        </div>

        {/* Body Content */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 bg-[#060919] flex flex-col items-center justify-center">
          {activeTab === 'video' && (
            <div className="w-full max-w-4xl flex flex-col items-center gap-4">
              <div className="relative w-full aspect-video rounded-xl overflow-hidden bg-black/80 border border-[#2b2756] shadow-2xl flex items-center justify-center group">
                <video
                  ref={videoRef}
                  src="/assets/videos/five_avatars_living_video.mp4"
                  className="w-full h-full object-contain"
                  autoPlay
                  loop
                  muted
                  playsInline
                  onPlay={() => setIsPlaying(true)}
                  onPause={() => setIsPlaying(false)}
                />
                
                {/* Floating quick control overlay */}
                <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between px-4 py-2 rounded-lg bg-black/70 backdrop-blur-md opacity-0 group-hover:opacity-100 transition-opacity">
                  <div className="flex items-center gap-2">
                    <button
                      onClick={handlePlayPause}
                      className="p-1.5 rounded-md bg-white/20 hover:bg-white/30 text-white"
                    >
                      {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                    </button>
                    <button
                      onClick={handleRestart}
                      className="p-1.5 rounded-md bg-white/10 hover:bg-white/20 text-white"
                    >
                      <RotateCcw className="w-4 h-4" />
                    </button>
                    <span className="text-xs text-slate-300 font-mono">1080p • 8.0s Loop</span>
                  </div>

                  <div className="flex items-center gap-1.5">
                    {[0.5, 1.0, 1.5].map((rate) => (
                      <button
                        key={rate}
                        onClick={() => handleSpeedChange(rate)}
                        className={`px-2 py-0.5 rounded text-[11px] font-mono ${
                          playbackRate === rate ? 'bg-[#7c4dff] text-white font-bold' : 'text-slate-400 hover:text-white'
                        }`}
                      >
                        {rate}x
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Verified Checklist Box */}
              <div className="w-full grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
                <div className="p-3 rounded-xl bg-[#0e1430] border border-[#262c50]">
                  <div className="flex items-center gap-2 text-emerald-400 text-xs font-semibold mb-1">
                    <CheckCircle2 className="w-4 h-4 shrink-0" />
                    Natural Biological Blink
                  </div>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    All 5 avatars blink 2 times with original eyelids, skin tone, & lashes. Zero white/blank eyes.
                  </p>
                </div>

                <div className="p-3 rounded-xl bg-[#0e1430] border border-[#262c50]">
                  <div className="flex items-center gap-2 text-sky-400 text-xs font-semibold mb-1">
                    <Wind className="w-4 h-4 shrink-0" />
                    Hair in the Breeze
                  </div>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    Light wind blows from left to right. Strands flow organically and settle back smoothly.
                  </p>
                </div>

                <div className="p-3 rounded-xl bg-[#0e1430] border border-[#262c50]">
                  <div className="flex items-center gap-2 text-purple-400 text-xs font-semibold mb-1">
                    <Sparkles className="w-4 h-4 shrink-0" />
                    1:1 Crystal Quality
                  </div>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    Full crisp resolution, unlit sRGB colors. Zero dimming, softening, grain, or filters.
                  </p>
                </div>

                <div className="p-3 rounded-xl bg-[#0e1430] border border-[#262c50]">
                  <div className="flex items-center gap-2 text-amber-400 text-xs font-semibold mb-1">
                    <ShieldCheck className="w-4 h-4 shrink-0" />
                    Locked Static Camera
                  </div>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    Zero camera movement, zoom, pan, or cut. Clothing and anatomy stay 100% stable.
                  </p>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'interactive' && (
            <div className="w-full h-[600px] rounded-xl overflow-hidden border border-[#2c2758] bg-black shadow-inner">
              <iframe
                src="/five-avatars-video"
                title="5 Living Avatars Interactive Canvas"
                className="w-full h-full border-0"
              />
            </div>
          )}

          {activeTab === 'audit' && (
            <div className="w-full max-w-4xl flex flex-col gap-4 text-xs">
              <div className="p-4 rounded-xl bg-[#0c122c] border border-[#222a52]">
                <h3 className="font-bold text-sm text-white mb-2 flex items-center gap-2">
                  <Eye className="w-4 h-4 text-[#7c4dff]" />
                  Desynchronized 2-Blink Schedule Verification
                </h3>
                <p className="text-slate-400 mb-4">
                  Each avatar blinks exactly 2 times at non-overlapping, natural moments across the 8-second locked camera sequence:
                </p>

                <div className="space-y-2.5">
                  <div className="flex items-center justify-between p-2.5 rounded-lg bg-[#070b1c] border border-white/5">
                    <span className="font-medium text-white">1. Pink Athleisure Tracksuit</span>
                    <span className="font-mono text-purple-300">Blink 1 @ 1.00s • Blink 2 @ 4.80s</span>
                    <span className="px-2 py-0.5 rounded text-[10px] bg-emerald-500/20 text-emerald-400">Verified Original Eyelids</span>
                  </div>

                  <div className="flex items-center justify-between p-2.5 rounded-lg bg-[#070b1c] border border-white/5">
                    <span className="font-medium text-white">2. Pastel Blue Knit & Pink Shorts</span>
                    <span className="font-mono text-purple-300">Blink 1 @ 1.90s • Blink 2 @ 5.60s</span>
                    <span className="px-2 py-0.5 rounded text-[10px] bg-emerald-500/20 text-emerald-400">Verified Original Eyelids</span>
                  </div>

                  <div className="flex items-center justify-between p-2.5 rounded-lg bg-[#070b1c] border border-white/5">
                    <span className="font-medium text-white">3. Midnight Black & Gold Zari Saree</span>
                    <span className="font-mono text-purple-300">Blink 1 @ 2.70s • Blink 2 @ 6.40s</span>
                    <span className="px-2 py-0.5 rounded text-[10px] bg-emerald-500/20 text-emerald-400">Verified Original Eyelids</span>
                  </div>

                  <div className="flex items-center justify-between p-2.5 rounded-lg bg-[#070b1c] border border-white/5">
                    <span className="font-medium text-white">4. Silk Blouse & Nautical Denim Shorts</span>
                    <span className="font-mono text-purple-300">Blink 1 @ 0.60s • Blink 2 @ 3.90s</span>
                    <span className="px-2 py-0.5 rounded text-[10px] bg-emerald-500/20 text-emerald-400">Verified Original Eyelids</span>
                  </div>

                  <div className="flex items-center justify-between p-2.5 rounded-lg bg-[#070b1c] border border-white/5">
                    <span className="font-medium text-white">5. Slate Blue Regal Kurta & Cape</span>
                    <span className="font-mono text-purple-300">Blink 1 @ 3.30s • Blink 2 @ 7.10s</span>
                    <span className="px-2 py-0.5 rounded text-[10px] bg-emerald-500/20 text-emerald-400">Verified Original Eyelids</span>
                  </div>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-[#0c122c] border border-[#222a52]">
                <h3 className="font-bold text-sm text-white mb-2 flex items-center gap-2">
                  <Wind className="w-4 h-4 text-sky-400" />
                  Left-to-Right Breeze Motion Formula
                </h3>
                <p className="text-slate-400 mb-2 leading-relaxed">
                  Hair displacement propagates from left to right along the horizontal X-axis:
                  <code className="block mt-2 p-2 rounded bg-black/50 font-mono text-emerald-400">
                    displacement = (sin(uTime * 1.6 - uv.x * 2.2 + (1.0 - uv.y) * 4.6) + 0.35) * uAmplitude * uHairMask.r;
                  </code>
                </p>
                <p className="text-slate-400 text-[11px]">
                  All hair displacement strictly multiplies by <code className="text-slate-200">uHairMask.r</code>, ensuring clothing, jewelry, skin, background, and faces stay 100% frozen and identical to the source image.
                </p>
              </div>
            </div>
          )}
        </div>

      </div>
    </div>
  );
};
