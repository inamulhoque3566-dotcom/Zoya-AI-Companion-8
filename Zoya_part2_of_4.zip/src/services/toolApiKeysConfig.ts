// Extensible Tool API Keys Registry & Brand Guidelines Configuration
// Designed to support Skills Part 1 of 7 through Part 7 of 7 without UI redesign.

export interface ToolApiKeyDefinition {
  id: string;
  label: string;
  serviceName: string;
  storageKey: string;
  placeholder: string;
  description: string;
  usedBySkills: string[];
  requiredForSkill: boolean;
  partNumber: number;
  docsHint?: string;
}

/**
 * Master extensible list of external Tool API Keys.
 * Future skill batches (Part 2–7) can simply append new entries to this array
 * and the "Tool API Keys" settings screen will automatically render them.
 */
export const TOOL_API_KEYS_REGISTRY: ToolApiKeyDefinition[] = [
  {
    id: 'composio_api_key',
    label: 'Composio API Key',
    serviceName: 'Composio Tool Router (connect-apps / connect)',
    storageKey: 'zoya_tool_key_composio',
    placeholder: 'comp_...',
    description:
      'Enables connecting Zoya to external apps (Gmail, Slack, GitHub, Notion, Linear, Calendar) via Composio.',
    usedBySkills: ['connect-apps', 'connect'],
    requiredForSkill: true,
    partNumber: 1,
    docsHint: 'Get a free key at platform.composio.dev',
  },
  {
    id: 'github_pat_token',
    label: 'GitHub Personal Access Token (Optional)',
    serviceName: 'GitHub API (changelog-generator)',
    storageKey: 'zoya_tool_key_github_pat',
    placeholder: 'ghp_...',
    description:
      'Optional token to fetch commit logs directly from private or rate-limited GitHub repositories when generating changelogs.',
    usedBySkills: ['changelog-generator'],
    requiredForSkill: false,
    partNumber: 1,
    docsHint: 'Optional — pasted commit logs work without a key',
  },
  {
    id: 'ad_library_api_key',
    label: 'Ad Library Scraper API Key (Optional)',
    serviceName: 'Ad Library Data Provider (competitive-ads-extractor)',
    storageKey: 'zoya_tool_key_ad_library',
    placeholder: 'adlib_...',
    description:
      'Optional external ad-intelligence key; analyzing pasted competitor ad copy and messaging works immediately without a key.',
    usedBySkills: ['competitive-ads-extractor'],
    requiredForSkill: false,
    partNumber: 1,
    docsHint: 'Optional — paste ad copy in chat to analyze without a key',
  },
  {
    id: 'langsmith_api_key',
    label: 'LangSmith API Key (Optional)',
    serviceName: 'LangSmith Trace Inspector (langsmith-fetch)',
    storageKey: 'zoya_tool_key_langsmith',
    placeholder: 'lsv2_pt_...',
    description:
      'Optional LangSmith key; in mobile text mode you can paste trace JSON/text directly in chat for error, tool-call, latency, and token analysis.',
    usedBySkills: ['langsmith-fetch'],
    requiredForSkill: false,
    partNumber: 4,
    docsHint: 'Optional — paste LangSmith trace JSON/text directly in chat',
  },
  {
    id: 'slack_webhook_url',
    label: 'Slack Incoming Webhook URL (Free Tier)',
    serviceName: 'Slack Integration (skill-share)',
    storageKey: 'zoya_tool_key_slack_webhook',
    placeholder: 'https://hooks.slack.com/services/T.../B.../...',
    description:
      'Free Slack Incoming Webhook URL to broadcast generated skills, packages, and team updates to your Slack workspace channel.',
    usedBySkills: ['skill-share'],
    requiredForSkill: false,
    partNumber: 6,
    docsHint: 'Get a 100% free webhook from api.slack.com/apps (Skill works in preview mode without a key)',
  },
];

import {
  storeEncryptedSecret,
  getDecryptedSecretSync,
  initializeSecretVault,
} from './secretVault';

// Auto-initialize vault for all registered tool API keys
if (typeof window !== 'undefined') {
  initializeSecretVault(TOOL_API_KEYS_REGISTRY.map((k) => k.storageKey));
}

export function getToolApiKey(id: string): string {
  const def = TOOL_API_KEYS_REGISTRY.find((k) => k.id === id);
  if (!def) return '';
  return getDecryptedSecretSync(def.storageKey);
}

export function setToolApiKey(id: string, value: string): void {
  const def = TOOL_API_KEYS_REGISTRY.find((k) => k.id === id);
  if (!def) return;
  storeEncryptedSecret(def.storageKey, value.trim());
}

export function hasToolApiKey(id: string): boolean {
  return getToolApiKey(id).length > 0;
}

export function getAllToolApiKeys(): Record<string, string> {
  const map: Record<string, string> = {};
  for (const item of TOOL_API_KEYS_REGISTRY) {
    map[item.id] = getToolApiKey(item.id);
  }
  return map;
}

/**
 * Masks sensitive keys, tokens, Slack webhooks, and credentials for safe UI and logging.
 */
export function maskSecret(secret: string): string {
  if (!secret) return '';
  const s = secret.trim();
  if (s.startsWith('https://hooks.slack.com/services/')) {
    const parts = s.split('/');
    if (parts.length >= 7) {
      return `https://hooks.slack.com/services/${parts[4]}/***/${parts[6].slice(0, 3)}***`;
    }
    return 'https://hooks.slack.com/services/***REDACTED***';
  }
  if (s.length <= 8) return '********';
  return `${s.slice(0, 4)}...${s.slice(-4)}`;
}

/**
 * Sanitizes traces, stack traces, and request payloads by scrubbing any bearer tokens,
 * passwords, API keys, or webhooks before display or logging.
 */
export function sanitizeSecretLog(content: string): string {
  if (!content) return '';
  return content
    .replace(/https:\/\/hooks\.slack\.com\/services\/[A-Za-z0-9_/]+/g, 'https://hooks.slack.com/services/***REDACTED***')
    .replace(/(ghp_[A-Za-z0-9]{20,})/g, 'ghp_***REDACTED***')
    .replace(/(comp_[A-Za-z0-9_-]{16,})/g, 'comp_***REDACTED***')
    .replace(/(AIza[0-9A-Za-z-_]{35})/g, 'AIza***REDACTED***')
    .replace(/(bearer\s+[A-Za-z0-9._~+/-]{15,})/gi, 'Bearer ***REDACTED***');
}

// ============================================================================
// BRAND GUIDELINES CONFIGURATION (Skill #2: brand-guidelines)
// ============================================================================

export type BrandPresetId = 'anthropic_warm' | 'swiss_editorial' | 'zoya_royal';

export interface BrandPalettePreset {
  id: BrandPresetId;
  name: string;
  subtitle: string;
  colors: {
    dark: string;
    light: string;
    midGray: string;
    lightGray: string;
    accentPrimary: string;
    accentSecondary: string;
    accentTertiary: string;
  };
  typography: {
    headingFont: string;
    bodyFont: string;
  };
}

export const BRAND_PALETTE_PRESETS: BrandPalettePreset[] = [
  {
    id: 'anthropic_warm',
    name: 'Anthropic Official Warm',
    subtitle: 'Poppins + Lora · #141413 Dark, #FAF9F5 Light, #D97757 Orange Accent',
    colors: {
      dark: '#141413',
      light: '#faf9f5',
      midGray: '#b0aea5',
      lightGray: '#e8e6dc',
      accentPrimary: '#d97757',
      accentSecondary: '#6a9bcc',
      accentTertiary: '#788c5d',
    },
    typography: {
      headingFont: 'Poppins, Arial, sans-serif',
      bodyFont: 'Lora, Georgia, serif',
    },
  },
  {
    id: 'swiss_editorial',
    name: 'Swiss Brutalist Grid',
    subtitle: 'Space Grotesk + IBM Plex · High-Contrast Architectural Editorial',
    colors: {
      dark: '#0f0f10',
      light: '#f4f3ef',
      midGray: '#8c8b85',
      lightGray: '#dedcd4',
      accentPrimary: '#e63946',
      accentSecondary: '#1d3557',
      accentTertiary: '#2a9d8f',
    },
    typography: {
      headingFont: 'Poppins, Helvetica, Arial, sans-serif',
      bodyFont: 'Georgia, serif',
    },
  },
  {
    id: 'zoya_royal',
    name: 'Zoya Obsidian & Gold',
    subtitle: 'Poppins + Lora · Deep Indigo Ink with Warm Terracotta & Sage',
    colors: {
      dark: '#12111a',
      light: '#f8f6f2',
      midGray: '#9e9ab0',
      lightGray: '#e6e3f0',
      accentPrimary: '#d97757',
      accentSecondary: '#5b82b8',
      accentTertiary: '#6c8f5e',
    },
    typography: {
      headingFont: 'Poppins, Arial, sans-serif',
      bodyFont: 'Lora, Georgia, serif',
    },
  },
];

export interface BrandGuidelinesConfig {
  enabled: boolean;
  presetId: BrandPresetId;
}

const BRAND_CONFIG_STORAGE_KEY = 'zoya_brand_guidelines_config';

export function getBrandGuidelinesConfig(): BrandGuidelinesConfig {
  try {
    if (typeof localStorage !== 'undefined') {
      const raw = localStorage.getItem(BRAND_CONFIG_STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        return {
          enabled: typeof parsed.enabled === 'boolean' ? parsed.enabled : true,
          presetId: parsed.presetId || 'anthropic_warm',
        };
      }
    }
  } catch {}
  return {
    enabled: true,
    presetId: 'anthropic_warm',
  };
}

export function saveBrandGuidelinesConfig(config: BrandGuidelinesConfig): void {
  try {
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem(BRAND_CONFIG_STORAGE_KEY, JSON.stringify(config));
    }
  } catch {}
}

export function getActiveBrandPreset(): BrandPalettePreset {
  const cfg = getBrandGuidelinesConfig();
  return (
    BRAND_PALETTE_PRESETS.find((p) => p.id === cfg.presetId) ||
    BRAND_PALETTE_PRESETS[0]
  );
}
