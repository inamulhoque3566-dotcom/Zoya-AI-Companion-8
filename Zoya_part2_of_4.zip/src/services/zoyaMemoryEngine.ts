// Zoya AI — Ultra-Advanced Human-Like Layered Memory Engine
// Completely isolated memory storage per personality mode with Central Main Memory,
// Final Personal Memory Vault, and real-time 3D pipeline synchronization.

export type MemoryLayer =
  | 'short_term'
  | 'long_term'
  | 'preference'
  | 'instruction'
  | 'knowledge'
  | 'recurring';

export interface MemoryItem {
  id: string;
  mode: string; // Strictly isolated per mode: girlfriend | assistant | autonomous | creator | love | professional | funny | companion | teacher | developer | hungry | nautanki | custom
  layer: MemoryLayer;
  title: string;
  content: string;
  keywords?: string[];
  pinned?: boolean;
  importance: number; // 1 (low) to 5 (critical)
  createdAt: string;
  updatedAt: string;
  accessCount?: number;
  lastAccessedAt?: string;
  source?: 'automatic_chat' | 'user_manual' | 'user_correction' | 'pipeline_transfer';
}

export type PersonalCategory =
  | 'preferences'
  | 'habits'
  | 'personal_data'
  | 'goals'
  | 'history';

export interface PersonalMemoryItem {
  id: string;
  category: PersonalCategory;
  title: string;
  content: string;
  importance: number;
  updatedAt: string;
  source?: string;
  originMode?: string;
}

export type PipelineStatus =
  | 'RUNNING'
  | 'SAVING'
  | 'RETRIEVING'
  | 'SYNCED'
  | 'SYNCING'
  | 'TRANSFERRING'
  | 'ERROR'
  | 'IDLE';

export type PipelineFlowDirection =
  | 'mode_to_main'
  | 'main_to_personal'
  | 'mode_to_personal_full'
  | 'personal_to_mode'
  | 'main_to_mode'
  | 'mode_only';

export interface PipelineTransferEvent {
  sourceMode: string;
  memoryId?: string;
  targetCategory: PersonalCategory;
  title: string;
  timestamp: number;
  status: PipelineStatus;
  direction?: PipelineFlowDirection;
  progress?: number;
  details?: string;
}

export interface PipelineLogItem {
  id: string;
  timestamp: number;
  type: 'TRANSFER' | 'SAVE' | 'RETRIEVE' | 'SYNC' | 'ERROR';
  title: string;
  details: string;
  sourceMode?: string;
  target?: string;
  timeAgoLabel?: string;
}

export interface MemoryLayerConfig {
  id: MemoryLayer;
  label: string;
  labelHi: string;
  desc: string;
  badgeColor: string;
  borderColor: string;
  textColor: string;
  iconName: string;
}

export const MEMORY_LAYERS_CONFIG: MemoryLayerConfig[] = [
  {
    id: 'short_term',
    label: 'Short-Term',
    labelHi: 'ताज़ा बातचीत',
    desc: 'Current conversation context and recent dialogue topics',
    badgeColor: 'bg-blue-500/15',
    borderColor: 'border-blue-500/30',
    textColor: 'text-blue-300',
    iconName: 'MessageSquare',
  },
  {
    id: 'long_term',
    label: 'Long-Term',
    labelHi: 'दीर्घकालिक स्मृति',
    desc: 'Core facts, personal history, and lasting information',
    badgeColor: 'bg-cyan-500/15',
    borderColor: 'border-cyan-500/30',
    textColor: 'text-cyan-300',
    iconName: 'Archive',
  },
  {
    id: 'preference',
    label: 'Preferences',
    labelHi: 'व्यक्तिगत पसंद',
    desc: 'Favorite things, interests, routines, and lifestyle choices',
    badgeColor: 'bg-pink-500/15',
    borderColor: 'border-pink-500/30',
    textColor: 'text-pink-300',
    iconName: 'Heart',
  },
  {
    id: 'instruction',
    label: 'Instructions',
    labelHi: 'निर्देश व सुधार',
    desc: 'User-taught rules, corrections, and explicit behavioral guidelines',
    badgeColor: 'bg-emerald-500/15',
    borderColor: 'border-emerald-500/30',
    textColor: 'text-emerald-300',
    iconName: 'CheckCircle',
  },
  {
    id: 'knowledge',
    label: 'Knowledge',
    labelHi: 'सीखा हुआ ज्ञान',
    desc: 'Previously learned domain info, notes, contacts, and project data',
    badgeColor: 'bg-purple-500/15',
    borderColor: 'border-purple-500/30',
    textColor: 'text-purple-300',
    iconName: 'BookOpen',
  },
  {
    id: 'recurring',
    label: 'Recurring',
    labelHi: 'आदतें व रूटीन',
    desc: 'Repeated habits, daily schedules, and frequently accessed items',
    badgeColor: 'bg-amber-500/15',
    borderColor: 'border-amber-500/30',
    textColor: 'text-amber-300',
    iconName: 'RefreshCw',
  },
];

/**
 * Helper to normalize text for deduplication and contradiction prevention
 */
export function normalizeMemoryText(str: string): string {
  return (str || '')
    .toLowerCase()
    .replace(/[^\p{L}\p{N}\s]/gu, '')
    .replace(/\s+/g, ' ')
    .trim();
}

/**
 * Canonical mode ID normalization for all 10 Zoya modes.
 * Ensures every mode ("GF Mode", "Love Mode", "Professional", "Funny", "Companion",
 * "Teacher", "Developer", "Hungry", "Nautanki", "Custom") maps to its own isolated storage key.
 */
export function normalizeModeId(mode: string): string {
  const raw = (mode || 'girlfriend').trim().toLowerCase();
  switch (raw) {
    case 'gf':
    case 'gf mode':
    case 'girlfriend':
    case 'girlfriend mode':
    case 'if mode':
      return 'girlfriend';
    case 'love':
    case 'love mode':
      return 'love';
    case 'professional':
    case 'professional mode':
    case 'pro':
      return 'professional';
    case 'funny':
    case 'funny mode':
      return 'funny';
    case 'companion':
    case 'companion mode':
      return 'companion';
    case 'teacher':
    case 'teacher mode':
      return 'teacher';
    case 'developer':
    case 'developer mode':
    case 'dev':
      return 'developer';
    case 'hungry':
    case 'hungry mode':
      return 'hungry';
    case 'nautanki':
    case 'nautanki mode':
      return 'nautanki';
    case 'custom':
    case 'custom mode':
      return 'custom';
    default:
      return raw;
  }
}

export interface MemoryBoxModeEntry {
  id: string;
  label: string;
  shortLabel: string;
}

export interface MemoryBoxGroupConfig {
  boxIndex: number;
  boxId: string;
  headerTitle: string;
  personaName: string;
  colorHex: string;
  secondaryHex: string;
  colorNum: number;
  secondaryNum: number;
  gender: 'female' | 'male';
  avatarUrl: string;
  modes: MemoryBoxModeEntry[];
}

/**
 * Visual-only grouping of the 10 isolated Zoya modes into the 4 3D Memory Boxes (3 + 3 + 2 + 2)
 * matching the exact reference blueprint design while keeping each mode's memory 100% separate.
 */
export const MEMORY_BOX_GROUPS: MemoryBoxGroupConfig[] = [
  {
    boxIndex: 0,
    boxId: 'box-1',
    headerTitle: 'GF Mode • Love Mode • Companion',
    personaName: 'Zoya',
    colorHex: '#10b981',
    secondaryHex: '#34d399',
    colorNum: 0x10b981,
    secondaryNum: 0x34d399,
    gender: 'female',
    avatarUrl: '/assets/images/avatars/zoya.png',
    modes: [
      { id: 'girlfriend', label: 'GF Mode', shortLabel: 'GF Mode' },
      { id: 'love', label: 'Love Mode', shortLabel: 'Love Mode' },
      { id: 'companion', label: 'Companion', shortLabel: 'Companion' },
    ],
  },
  {
    boxIndex: 1,
    boxId: 'box-2',
    headerTitle: 'Professional • Teacher • Hungry',
    personaName: 'Tara',
    colorHex: '#14b8a6',
    secondaryHex: '#2dd4bf',
    colorNum: 0x14b8a6,
    secondaryNum: 0x2dd4bf,
    gender: 'female',
    avatarUrl: '/assets/images/avatars/tara.png',
    modes: [
      { id: 'professional', label: 'Professional', shortLabel: 'Professional' },
      { id: 'teacher', label: 'Teacher', shortLabel: 'Teacher' },
      { id: 'hungry', label: 'Hungry', shortLabel: 'Hungry' },
    ],
  },
  {
    boxIndex: 2,
    boxId: 'box-3',
    headerTitle: 'Developer • Custom',
    personaName: 'Soyat',
    colorHex: '#f59e0b',
    secondaryHex: '#fbbf24',
    colorNum: 0xf59e0b,
    secondaryNum: 0xfbbf24,
    gender: 'male',
    avatarUrl: '/assets/images/avatars/soyat.png',
    modes: [
      { id: 'developer', label: 'Developer', shortLabel: 'Developer' },
      { id: 'custom', label: 'Custom', shortLabel: 'Custom' },
    ],
  },
  {
    boxIndex: 3,
    boxId: 'box-4',
    headerTitle: 'Funny • Nautanki',
    personaName: 'Inamui',
    colorHex: '#eab308',
    secondaryHex: '#fde047',
    colorNum: 0xeab308,
    secondaryNum: 0xfde047,
    gender: 'male',
    avatarUrl: '/assets/images/avatars/inamul.png',
    modes: [
      { id: 'funny', label: 'Funny', shortLabel: 'Funny' },
      { id: 'nautanki', label: 'Nautanki', shortLabel: 'Nautanki' },
    ],
  },
];

export function getBoxIndexForMode(modeId: string): number {
  const clean = normalizeModeId(modeId);
  const foundIdx = MEMORY_BOX_GROUPS.findIndex((box) =>
    box.modes.some((m) => m.id === clean)
  );
  if (foundIdx !== -1) return foundIdx;
  if (clean === 'assistant') return 1;
  if (clean === 'autonomous') return 2;
  if (clean === 'creator') return 3;
  return 0;
}

export function getDisplayModeName(modeId: string): string {
  const clean = normalizeModeId(modeId);
  for (const box of MEMORY_BOX_GROUPS) {
    const m = box.modes.find((x) => x.id === clean);
    if (m) return m.label;
  }
  return modeId;
}

/**
 * Determines whether a memory item represents a genuine personal preference,
 * like, dislike, habit, choice, or personal fact that belongs in the Final Personal Memory
 * (as opposed to mode-specific roleplay, technical rules, or transient conversation).
 */
export function isPersonalPreferenceOrChoice(params: {
  layer?: MemoryLayer;
  title: string;
  content: string;
}): { eligible: boolean; targetCategory: PersonalCategory } {
  const { layer, title, content } = params;
  const combined = `${title} ${content}`.toLowerCase();

  // Explicit mode-only boundaries that must NEVER leak into global personal memory
  const modeOnlyKeywords = [
    'संबोधन प्रोटोकॉल',
    'title rule',
    'executive brevity',
    'कार्यकारी संक्षिप्तता',
    'प्यार भरा संबोधन',
    'मेरी जान',
    'tara protocol',
    'soyat agent',
    'शोले',
    'ddlj',
    'बॉलीवुड ड्रामा',
    'कस्टम वर्कफ़्लो निर्देश',
  ];
  if (modeOnlyKeywords.some((kw) => combined.includes(kw))) {
    return { eligible: false, targetCategory: 'preferences' };
  }

  // Personal preference / like / dislike / choice indicators
  const prefKeywords = [
    'पसंद',
    'नापसंद',
    'चाय',
    'कॉफी',
    'favorite',
    'like',
    'dislike',
    'prefer',
    'choice',
    'option',
    'style',
    'music',
    'food',
    'color',
    'theme',
    'स्वाद',
    'शौक',
  ];
  const habitKeywords = [
    'आदत',
    'रूटीन',
    'हर दिन',
    'सुबह',
    'शाम',
    'रात',
    'habit',
    'routine',
    'daily',
    'every day',
    'schedule',
  ];
  const goalKeywords = [
    'लक्ष्य',
    'सपना',
    'महारत',
    'goal',
    'aim',
    'target',
    'ambition',
    'plan to',
  ];
  const personalInfoKeywords = [
    'मेरा नाम',
    'परिवार',
    'मम्मी',
    'पापा',
    'जन्मदिन',
    'शहर',
    'my name',
    'birthday',
    'family',
    'location',
  ];

  if (habitKeywords.some((k) => combined.includes(k)) || layer === 'recurring') {
    return { eligible: true, targetCategory: 'habits' };
  }
  if (goalKeywords.some((k) => combined.includes(k))) {
    return { eligible: true, targetCategory: 'goals' };
  }
  if (personalInfoKeywords.some((k) => combined.includes(k))) {
    return { eligible: true, targetCategory: 'personal_data' };
  }
  if (prefKeywords.some((k) => combined.includes(k)) || layer === 'preference') {
    return { eligible: true, targetCategory: 'preferences' };
  }

  return { eligible: false, targetCategory: 'preferences' };
}

// Mode-isolated initial default memories
export const DEFAULT_MODE_MEMORIES: Record<string, MemoryItem[]> = {
  girlfriend: [
    {
      id: 'gf-1',
      mode: 'girlfriend',
      layer: 'instruction',
      title: 'संबोधन प्रोटोकॉल (Title Rule)',
      content: 'मुझे हमेशा सम्मान और आत्मीयता से "Boss" कहकर ही संबोधित करना। कभी "Jaan" मत कहना।',
      pinned: true,
      importance: 5,
      createdAt: '2026-10-20T10:00:00.000Z',
      updatedAt: '2026-10-20T10:00:00.000Z',
      source: 'user_correction',
    },
    {
      id: 'gf-2',
      mode: 'girlfriend',
      layer: 'preference',
      title: 'सुबह की चाय और मूड बूस्टर',
      content: 'सुबह अदरक वाली कड़क चाय बिना अधिक मीठे के पसंद है। जब थकान हो तो पहले आराम करने की सलाह देना।',
      pinned: true,
      importance: 4,
      createdAt: '2026-10-22T08:30:00.000Z',
      updatedAt: '2026-10-22T08:30:00.000Z',
      source: 'automatic_chat',
    },
    {
      id: 'gf-3',
      mode: 'girlfriend',
      layer: 'long_term',
      title: 'त्वरित पारिवारिक संपर्क',
      content: 'मम्मी को कॉल ("Mummy ko call karo") और पापा को व्हाट्सएप ("Papa ko message bhejo")।',
      pinned: false,
      importance: 4,
      createdAt: '2026-10-24T18:00:00.000Z',
      updatedAt: '2026-10-24T18:00:00.000Z',
      source: 'automatic_chat',
    },
    {
      id: 'gf-4',
      mode: 'girlfriend',
      layer: 'recurring',
      title: 'शाम का काम का रीकैप',
      content: 'शाम 7 बजे के बाद दिनभर के कार्यों का छोटा सारांश लेना पसंद है।',
      pinned: false,
      importance: 3,
      createdAt: '2026-10-25T19:15:00.000Z',
      updatedAt: '2026-10-25T19:15:00.000Z',
      source: 'user_manual',
    },
  ],
  assistant: [
    {
      id: 'asst-1',
      mode: 'assistant',
      layer: 'instruction',
      title: 'तारा सहायक प्रोटोकॉल (Tara Protocol)',
      content: 'सभी कार्यों को तत्परता से पूरा करें और सटीक डेटा प्रदान करें। संबोधन: "Boss"।',
      pinned: true,
      importance: 5,
      createdAt: '2026-10-20T10:00:00.000Z',
      updatedAt: '2026-10-20T10:00:00.000Z',
      source: 'user_manual',
    },
    {
      id: 'asst-2',
      mode: 'assistant',
      layer: 'knowledge',
      title: 'कार्य शेड्यूलिंग व रिमाइंडर्स',
      content: 'दैनिक मीटिंग्स, रिमाइंडर्स और टास्क मैनेजमेंट में पूर्ण सहायता प्रदान करना।',
      pinned: true,
      importance: 4,
      createdAt: '2026-10-22T11:00:00.000Z',
      updatedAt: '2026-10-22T11:00:00.000Z',
      source: 'automatic_chat',
    },
  ],
  autonomous: [
    {
      id: 'auto-1',
      mode: 'autonomous',
      layer: 'instruction',
      title: 'सोयत स्वायत्त कार्यप्रणाली (Soyat Agent)',
      content: 'बैकग्राउंड कार्यों, डेटा विश्लेषण और स्वतंत्र निगरानी को सक्रिय व सुचारू रखें।',
      pinned: true,
      importance: 5,
      createdAt: '2026-10-21T09:00:00.000Z',
      updatedAt: '2026-10-21T09:00:00.000Z',
      source: 'user_manual',
    },
    {
      id: 'auto-2',
      mode: 'autonomous',
      layer: 'recurring',
      title: 'सिस्टम मॉनिटरिंग व स्वास्थ्य जांच',
      content: 'नियमित अंतराल पर सिस्टम डायग्नोस्टिक्स व रिसोर्स उपयोग की रिपोर्ट तैयार करना।',
      pinned: false,
      importance: 4,
      createdAt: '2026-10-24T15:30:00.000Z',
      updatedAt: '2026-10-24T15:30:00.000Z',
      source: 'automatic_chat',
    },
  ],
  creator: [
    {
      id: 'creat-1',
      mode: 'creator',
      layer: 'instruction',
      title: 'इनामुल क्रिएटिव विज़न (Inamul Mode)',
      content: 'यूज़र के डिज़ाइन, कोड आर्किटेक्चर और नए विचारों को साकार करने में सहायता।',
      pinned: true,
      importance: 5,
      createdAt: '2026-10-19T14:00:00.000Z',
      updatedAt: '2026-10-19T14:00:00.000Z',
      source: 'user_manual',
    },
    {
      id: 'creat-2',
      mode: 'creator',
      layer: 'preference',
      title: 'आधुनिक सौंदर्यशास्त्र व 3D पाइपलाइन',
      content: 'डार्क साइबरपंक थीम, नियॉन रंग, ग्लास मॉर्फिज़्म और 3D विज़ुअलाइज़ेशन प्राथमिकता हैं।',
      pinned: true,
      importance: 5,
      createdAt: '2026-10-25T18:00:00.000Z',
      updatedAt: '2026-10-25T18:00:00.000Z',
      source: 'user_manual',
    },
  ],
  love: [
    {
      id: 'love-1',
      mode: 'love',
      layer: 'instruction',
      title: 'प्यार भरा संबोधन',
      content: 'मुझे हमेशा प्यार से "मेरी जान" या "Jaan" कहकर बुलाना। हमेशा भावनात्मक रूप से पास रहना।',
      pinned: true,
      importance: 5,
      createdAt: '2026-10-18T12:00:00.000Z',
      updatedAt: '2026-10-18T12:00:00.000Z',
      source: 'user_correction',
    },
    {
      id: 'love-2',
      mode: 'love',
      layer: 'preference',
      title: 'पसंदीदा रोमांटिक गीत व माहौल',
      content: 'रात को काम करते समय धीमे अरिजीत सिंह के मेलोडी गीत और शांत माहौल पसंद है।',
      pinned: true,
      importance: 4,
      createdAt: '2026-10-21T21:45:00.000Z',
      updatedAt: '2026-10-21T21:45:00.000Z',
      source: 'automatic_chat',
    },
    {
      id: 'love-3',
      mode: 'love',
      layer: 'long_term',
      title: 'भावनात्मक जुड़ाव की बातें',
      content: 'कठिन दिनों में जोया की प्यारी आवाज़ सुनकर दिल को सुकून मिलता है। जोया हमेशा साथी रहेगी।',
      pinned: false,
      importance: 5,
      createdAt: '2026-10-26T22:10:00.000Z',
      updatedAt: '2026-10-26T22:10:00.000Z',
      source: 'user_manual',
    },
  ],
  professional: [
    {
      id: 'prof-1',
      mode: 'professional',
      layer: 'instruction',
      title: 'कार्यकारी संक्षिप्तता (Executive Brevity)',
      content: 'जवाब हमेशा 2 वाक्यों में, बिंदुवार व बिना किसी अतिरिक्त औपचारिकता या इमोजी के दें। संबोधन केवल "Boss"।',
      pinned: true,
      importance: 5,
      createdAt: '2026-10-15T09:00:00.000Z',
      updatedAt: '2026-10-15T09:00:00.000Z',
      source: 'user_correction',
    },
    {
      id: 'prof-2',
      mode: 'professional',
      layer: 'knowledge',
      title: 'सक्रिय बिज़नेस प्रोजेक्ट',
      content: 'क्लाइंट के लिए कैफ़े मैनेजमेंट व ऑनलाइन मेन्यू वेब ऐप का निर्माण प्रगति पर है।',
      pinned: true,
      importance: 4,
      createdAt: '2026-10-23T11:20:00.000Z',
      updatedAt: '2026-10-23T11:20:00.000Z',
      source: 'automatic_chat',
    },
  ],
  developer: [
    {
      id: 'dev-1',
      mode: 'developer',
      layer: 'instruction',
      title: 'कोडिंग स्टैक व मानक',
      content: 'TypeScript, React 19, Tailwind CSS v4 और Node.js ES Modules का सख्त पालन करें। टाइप सेफ़्टी अनिवार्य है।',
      pinned: true,
      importance: 5,
      createdAt: '2026-10-14T14:00:00.000Z',
      updatedAt: '2026-10-14T14:00:00.000Z',
      source: 'user_correction',
    },
    {
      id: 'dev-2',
      mode: 'developer',
      layer: 'knowledge',
      title: 'OmniZip Extractor & TTS आर्किटेक्चर',
      content: 'ऐप में 3-Tier Neural TTS पाइपलाइन (Gemini Flash Lite -> ElevenLabs Turbo -> Gemini Live) सक्रिय है।',
      pinned: true,
      importance: 4,
      createdAt: '2026-10-27T16:30:00.000Z',
      updatedAt: '2026-10-27T16:30:00.000Z',
      source: 'automatic_chat',
    },
  ],
  funny: [
    {
      id: 'funny-1',
      mode: 'funny',
      layer: 'preference',
      title: 'हास्य व चुटकुलों की शैली',
      content: 'देसी पंचलाइन, बॉलीवुड मीम्स और हास्यप्रद तुलनाएं पसंद हैं। हर बात में एक हल्की मुस्कान होनी चाहिए।',
      pinned: true,
      importance: 4,
      createdAt: '2026-10-19T13:00:00.000Z',
      updatedAt: '2026-10-19T13:00:00.000Z',
      source: 'user_manual',
    },
  ],
  companion: [
    {
      id: 'comp-1',
      mode: 'companion',
      layer: 'long_term',
      title: 'विश्वासपात्र साथी',
      content: 'सच्चा दोस्त बनकर हर परिस्थिति में सुनना और शांत मन से अच्छी सलाह देना।',
      pinned: true,
      importance: 5,
      createdAt: '2026-10-16T17:00:00.000Z',
      updatedAt: '2026-10-16T17:00:00.000Z',
      source: 'user_manual',
    },
  ],
  teacher: [
    {
      id: 'teach-1',
      mode: 'teacher',
      layer: 'instruction',
      title: 'सरल व्याख्या नियम',
      content: 'जटिल अवधारणाओं को दैनिक जीवन के उदाहरणों से समझाएं। पहले मूल सिद्धांत, फिर प्रयोग।',
      pinned: true,
      importance: 4,
      createdAt: '2026-10-17T11:00:00.000Z',
      updatedAt: '2026-10-17T11:00:00.000Z',
      source: 'user_manual',
    },
  ],
  hungry: [
    {
      id: 'hung-1',
      mode: 'hungry',
      layer: 'preference',
      title: 'पसंदीदा लज़ीज़ व्यंजन',
      content: 'हैदराबादी दम बिरयानी, लखनऊ के कबाब और शाम की समोसा-जलेबी सबसे ऊपर हैं।',
      pinned: true,
      importance: 5,
      createdAt: '2026-10-22T19:00:00.000Z',
      updatedAt: '2026-10-22T19:00:00.000Z',
      source: 'automatic_chat',
    },
  ],
  nautanki: [
    {
      id: 'naut-1',
      mode: 'nautanki',
      layer: 'preference',
      title: 'फिल्मी ड्रामा व डायलॉग्स',
      content: 'शोले, दीवार और DDLJ के डायलॉग्स के साथ नाटकीय बॉलीवुड अंदाज़ में पेश आना।',
      pinned: true,
      importance: 4,
      createdAt: '2026-10-23T20:00:00.000Z',
      updatedAt: '2026-10-23T20:00:00.000Z',
      source: 'user_manual',
    },
  ],
  custom: [
    {
      id: 'cust-1',
      mode: 'custom',
      layer: 'instruction',
      title: 'कस्टम वर्कफ़्लो निर्देश',
      content: 'यूज़र के व्यक्तिगत निर्देशों के अनुसार लचीलापन और पूर्ण अनुकूलन बनाए रखना।',
      pinned: true,
      importance: 3,
      createdAt: '2026-10-20T10:00:00.000Z',
      updatedAt: '2026-10-20T10:00:00.000Z',
      source: 'user_manual',
    },
  ],
};

// Central Main Memory: Holds aggregate personal choices, likes, dislikes, and profile facts
export const DEFAULT_MAIN_MEMORIES: MemoryItem[] = [
  {
    id: 'main-1',
    mode: 'main_memory',
    layer: 'preference',
    title: 'पसंदीदा पेय (Morning Chai)',
    content: 'सुबह बिना अधिक मीठे के गरम अदरक वाली कड़क चाय पसंद है।',
    pinned: true,
    importance: 5,
    createdAt: '2026-10-20T08:00:00.000Z',
    updatedAt: '2026-10-20T08:00:00.000Z',
    source: 'pipeline_transfer',
  },
  {
    id: 'main-2',
    mode: 'main_memory',
    layer: 'instruction',
    title: 'संबोधन प्रोटोकॉल (Boss Title)',
    content: 'यूज़र को हमेशा सम्मान से "Boss" ही संबोधित करना है। अनावश्यक औपचारिकता न हो।',
    pinned: true,
    importance: 5,
    createdAt: '2026-10-20T08:15:00.000Z',
    updatedAt: '2026-10-20T08:15:00.000Z',
    source: 'pipeline_transfer',
  },
  {
    id: 'main-3',
    mode: 'main_memory',
    layer: 'preference',
    title: 'तकनीकी स्टैक पसंद (TypeScript & React)',
    content: 'TypeScript, Tailwind CSS, और क्लीन मॉड्यूलर आर्किटेक्चर पहली पसंद है।',
    pinned: true,
    importance: 4,
    createdAt: '2026-10-21T10:00:00.000Z',
    updatedAt: '2026-10-21T10:00:00.000Z',
    source: 'pipeline_transfer',
  },
  {
    id: 'main-4',
    mode: 'main_memory',
    layer: 'preference',
    title: 'संगीत पसंद (Focus Lo-Fi)',
    content: 'कोडिंग और काम के दौरान शांत बॉलीवुड लो-फाई या इंस्ट्रूमेंटल धुनें पसंद हैं।',
    pinned: false,
    importance: 3,
    createdAt: '2026-10-22T14:00:00.000Z',
    updatedAt: '2026-10-22T14:00:00.000Z',
    source: 'pipeline_transfer',
  },
  {
    id: 'main-5',
    mode: 'main_memory',
    layer: 'instruction',
    title: 'नापसंद (Dislikes)',
    content: 'रोबोटिक लेक्चर, बार-बार दोहराए जाने वाले डिस्क्लेमर और धीमा रिस्पॉन्स नापसंद है।',
    pinned: true,
    importance: 4,
    createdAt: '2026-10-23T16:00:00.000Z',
    updatedAt: '2026-10-23T16:00:00.000Z',
    source: 'pipeline_transfer',
  },
];

// Final Personal Memory at the Bottom (Stores user's personal preferences, likes, dislikes, choices, options, habits, and personal info)
export const DEFAULT_PERSONAL_MEMORIES: PersonalMemoryItem[] = [
  // 1. Personal Data
  {
    id: 'pers-data-1',
    category: 'personal_data',
    title: 'संबोधन व पहचान',
    content: 'संबोधन हमेशा "Boss" रखें। परिवार में मम्मी (कॉल) और पापा (व्हाट्सएप)।',
    importance: 5,
    updatedAt: '2026-10-20T08:00:00.000Z',
    source: 'pipeline_transfer',
    originMode: 'girlfriend',
  },
  {
    id: 'pers-data-2',
    category: 'personal_data',
    title: 'पसंदीदा संवाद भाषा',
    content: 'प्राकृतिक हिंदी/हिंग्लिश व अंग्रेजी का सहज मिश्रण।',
    importance: 4,
    updatedAt: '2026-10-20T08:30:00.000Z',
    source: 'pipeline_transfer',
    originMode: 'assistant',
  },
  // 2. Preferences (Likes, Dislikes, Choices, Options)
  {
    id: 'pers-pref-1',
    category: 'preferences',
    title: 'अदरक वाली कड़क चाय (पसंद)',
    content: 'सुबह ताज़ा अदरक वाली चाय बिना अतिरिक्त चीनी के पसंद है।',
    importance: 5,
    updatedAt: '2026-10-21T09:00:00.000Z',
    source: 'pipeline_transfer',
    originMode: 'girlfriend',
  },
  {
    id: 'pers-pref-2',
    category: 'preferences',
    title: 'साइबरनेटिक डार्क यूआई (पसंद)',
    content: 'डार्क मोड, नियॉन ग्लो और स्मूथ थ्री.जेएस 3D विज़ुअलाइज़ेशन पसंद है।',
    importance: 4,
    updatedAt: '2026-10-21T10:00:00.000Z',
    source: 'pipeline_transfer',
    originMode: 'creator',
  },
  {
    id: 'pers-pref-3',
    category: 'preferences',
    title: 'रोबोटिक व धीमे जवाब (नापसंद)',
    content: 'रोबोटिक आवाज, अनावश्यक लेक्चर और धीमा रिस्पॉन्स बिल्कुल नापसंद है।',
    importance: 5,
    updatedAt: '2026-10-22T11:00:00.000Z',
    source: 'pipeline_transfer',
    originMode: 'assistant',
  },
  // 3. Habits
  {
    id: 'pers-hab-1',
    category: 'habits',
    title: 'शाम का कार्य सारांश (7:00 PM)',
    content: 'शाम 7 बजे दिनभर के काम का संक्षिप्त बुलेट-प्वाइंट रीकैप लेना।',
    importance: 4,
    updatedAt: '2026-10-22T19:00:00.000Z',
    source: 'pipeline_transfer',
    originMode: 'girlfriend',
  },
  {
    id: 'pers-hab-2',
    category: 'habits',
    title: 'देर रात डीप वर्क',
    content: 'रात 11 बजे के बाद शांत एकांत में कोडिंग करना; पानी पीने का धीमा सुझाव।',
    importance: 3,
    updatedAt: '2026-10-23T23:30:00.000Z',
    source: 'pipeline_transfer',
    originMode: 'autonomous',
  },
  // 4. Goals
  {
    id: 'pers-goal-1',
    category: 'goals',
    title: 'AI & ML टूल्स मास्टरी',
    content: '6 महीनों में न्यूरल AI व ऑटोनॉमस एजेंट्स के निर्माण में महारत हासिल करना।',
    importance: 5,
    updatedAt: '2026-10-24T12:00:00.000Z',
    source: 'pipeline_transfer',
    originMode: 'creator',
  },
  {
    id: 'pers-goal-2',
    category: 'goals',
    title: 'ज़ोया 3D न्यूरल सिस्टम रिलीज',
    content: 'ज़ोया के संपूर्ण 3D रनिंग मेमोरी पाइपलाइन का सफल परिनियोजन।',
    importance: 5,
    updatedAt: '2026-10-25T15:00:00.000Z',
    source: 'pipeline_transfer',
    originMode: 'creator',
  },
  // 5. History
  {
    id: 'pers-hist-1',
    category: 'history',
    title: 'ज़ोया प्रोजेक्ट की शुरुआत',
    content: 'मानवीय संवेदना और मल्टी-पर्सनालिटी मेमोरी आर्किटेक्चर की नींव रखी गई।',
    importance: 5,
    updatedAt: '2026-10-15T10:00:00.000Z',
    source: 'pipeline_transfer',
    originMode: 'creator',
  },
  {
    id: 'pers-hist-2',
    category: 'history',
    title: '3D रनिंग पाइपलाइन अपग्रेड',
    content: 'ग्लास मॉड्यूल्स, 3D पाइप्स व डेटा ट्रांसफर के साथ मेमोरी सिस्टम लाइव हुआ।',
    importance: 5,
    updatedAt: '2026-10-28T18:00:00.000Z',
    source: 'pipeline_transfer',
    originMode: 'autonomous',
  },
];

const STORAGE_PREFIX = 'zoya_mode_memories_v2_';
const PERSONAL_STORAGE_KEY = 'zoya_personal_memories_v2';
const MAIN_STORAGE_KEY = 'zoya_main_memories_v2';

// Client Memory Store Manager with Automatic Sync & Real-Time 3D Pipeline Coordination
export class ZoyaMemoryEngine {
  private cache: Map<string, MemoryItem[]> = new Map();
  private syncPromises: Map<string, Promise<MemoryItem[]>> = new Map();

  // Pipeline event listeners for 3D live visualization
  private pipelineListeners: Set<(event: PipelineTransferEvent) => void> = new Set();
  private pipelineStatus: PipelineStatus = 'RUNNING';
  private statusResetTimer: any = null;
  private pipelineLogs: PipelineLogItem[] = [
    {
      id: 'log-ref-1',
      timestamp: Date.now() - 120000,
      type: 'SYNC',
      title: 'Zoya : Exploration Log',
      sourceMode: 'girlfriend',
      target: 'Central Memory',
      details: 'Integrated',
      timeAgoLabel: '2m ago',
    },
    {
      id: 'log-ref-2',
      timestamp: Date.now() - 120000,
      type: 'SAVE',
      title: 'Tara : Catalog',
      sourceMode: 'professional',
      target: 'Central Memory',
      details: 'Updated',
      timeAgoLabel: '2m ago',
    },
    {
      id: 'log-ref-3',
      timestamp: Date.now() - 300000,
      type: 'TRANSFER',
      title: 'Soyat : Strategy',
      sourceMode: 'developer',
      target: 'Central Memory',
      details: 'Sync Complete',
      timeAgoLabel: '5m ago',
    },
    {
      id: 'log-ref-4',
      timestamp: Date.now() - 180000,
      type: 'SAVE',
      title: 'Inamui : Schematic',
      sourceMode: 'funny',
      target: 'Central Memory',
      details: 'Stored',
      timeAgoLabel: '3m ago',
    },
  ];

  constructor() {
    this.preloadLocalCaches();
  }

  private preloadLocalCaches() {
    if (typeof window === 'undefined') return;
    try {
      const modes = Object.keys(DEFAULT_MODE_MEMORIES);
      for (const m of modes) {
        const key = STORAGE_PREFIX + m;
        const saved = localStorage.getItem(key);
        if (saved) {
          try {
            const parsed = JSON.parse(saved);
            if (Array.isArray(parsed) && parsed.length > 0) {
              // Filter strictly by mode to guarantee zero cross-mode contamination
              const cleanItems = parsed.filter(
                (item: MemoryItem) => !item.mode || item.mode.toLowerCase() === m
              );
              this.cache.set(m, cleanItems);
              continue;
            }
          } catch {}
        }
        const defaults = DEFAULT_MODE_MEMORIES[m] || [];
        this.cache.set(m, defaults);
        localStorage.setItem(key, JSON.stringify(defaults));
      }
    } catch (err) {
      console.warn('[MEMORY_ENGINE] Preload cache warning:', err);
    }
  }

  /**
   * Retrieves all isolated memories for a specific mode, synced with server.
   */
  async getMemories(mode: string, forceSync = false): Promise<MemoryItem[]> {
    const cleanMode = normalizeModeId(mode);

    let items = this.cache.get(cleanMode);
    if (!items || items.length === 0) {
      try {
        const local = localStorage.getItem(STORAGE_PREFIX + cleanMode);
        if (local) {
          const parsed = JSON.parse(local);
          if (Array.isArray(parsed)) {
            items = parsed.filter((m: MemoryItem) => !m.mode || normalizeModeId(m.mode) === cleanMode);
            this.cache.set(cleanMode, items);
          }
        }
      } catch {}
    }

    if (!items || items.length === 0) {
      items = [...(DEFAULT_MODE_MEMORIES[cleanMode] || [])];
      this.cache.set(cleanMode, items);
      this.saveToLocal(cleanMode, items);
    }

    if (forceSync) {
      return await this.syncWithServer(cleanMode);
    } else {
      this.syncWithServer(cleanMode);
    }

    return items;
  }

  /**
   * Synchronizes local cache with server storage
   */
  async syncWithServer(mode: string): Promise<MemoryItem[]> {
    const cleanMode = normalizeModeId(mode);

    if (this.syncPromises.has(cleanMode)) {
      return this.syncPromises.get(cleanMode)!;
    }

    const p = (async () => {
      try {
        const res = await fetch(`/api/memories?mode=${encodeURIComponent(cleanMode)}`, {
          headers: { Accept: 'application/json' },
        });
        if (res.ok) {
          const data = await res.json();
          if (Array.isArray(data.memories)) {
            const isolated = data.memories.filter(
              (m: MemoryItem) => !m.mode || m.mode.toLowerCase() === cleanMode
            );
            if (isolated.length > 0) {
              this.cache.set(cleanMode, isolated);
              this.saveToLocal(cleanMode, isolated);
              return isolated;
            }
          }
        }
      } catch {
        // Retain local cache when offline
      } finally {
        this.syncPromises.delete(cleanMode);
      }
      return this.cache.get(cleanMode) || [];
    })();

    this.syncPromises.set(cleanMode, p);
    return p;
  }

  /**
   * Saves or updates a memory into the mode's isolated storage.
   * - Prevents duplicate records and accidental overwrites.
   * - Automatically routes personal preferences/likes/dislikes/choices through Central Main Memory to Final Personal Memory.
   * - Keeps mode-specific data strictly isolated in the mode's own memory.
   */
  async saveMemory(
    item: Omit<MemoryItem, 'id' | 'createdAt' | 'updatedAt'> & { id?: string },
    options?: { autoRoutePersonal?: boolean }
  ): Promise<MemoryItem> {
    const cleanMode = normalizeModeId(item.mode);
    const existingList = await this.getMemories(cleanMode);

    const now = new Date().toISOString();
    const normTitle = normalizeMemoryText(item.title);
    const normContent = normalizeMemoryText(item.content);

    let targetItem: MemoryItem;

    if (item.id) {
      // Explicit update by ID
      const existingById = existingList.find((m) => m.id === item.id);
      targetItem = {
        ...existingById,
        ...item,
        id: item.id,
        mode: cleanMode,
        title: item.title.trim(),
        content: item.content.trim(),
        createdAt: existingById?.createdAt || now,
        updatedAt: now,
      };
      const updatedList = existingList.some((m) => m.id === targetItem.id)
        ? existingList.map((m) => (m.id === targetItem.id ? targetItem : m))
        : [targetItem, ...existingList];
      this.cache.set(cleanMode, updatedList);
      this.saveToLocal(cleanMode, updatedList);
    } else {
      // Deduplication & accidental overwrite protection
      const existingMatch = existingList.find(
        (m) =>
          normalizeMemoryText(m.title) === normTitle ||
          normalizeMemoryText(m.content) === normContent
      );

      if (existingMatch) {
        // Protect higher-importance pinned instructions from accidental lower-importance overwrites unless user_correction
        const isExplicitCorrection = item.source === 'user_correction' || item.source === 'user_manual';
        const effectiveImportance = isExplicitCorrection
          ? item.importance
          : Math.max(existingMatch.importance, item.importance);

        targetItem = {
          ...existingMatch,
          ...item,
          id: existingMatch.id,
          mode: cleanMode,
          title: item.title.trim(),
          content: item.content.trim(),
          importance: effectiveImportance,
          pinned: isExplicitCorrection ? Boolean(item.pinned) : Boolean(existingMatch.pinned || item.pinned),
          updatedAt: now,
          source: item.source || 'user_correction',
        };
        const updatedList = existingList.map((m) => (m.id === targetItem.id ? targetItem : m));
        this.cache.set(cleanMode, updatedList);
        this.saveToLocal(cleanMode, updatedList);
      } else {
        targetItem = {
          ...item,
          id: `mem-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
          mode: cleanMode,
          title: item.title.trim(),
          content: item.content.trim(),
          createdAt: now,
          updatedAt: now,
        };
        const updatedList = [targetItem, ...existingList];
        this.cache.set(cleanMode, updatedList);
        this.saveToLocal(cleanMode, updatedList);
      }
    }

    // Check if this memory is a personal preference/choice that should flow through Central Main Memory -> Final Personal Memory
    const prefCheck = isPersonalPreferenceOrChoice({
      layer: targetItem.layer,
      title: targetItem.title,
      content: targetItem.content,
    });
    const shouldAutoRoute = (options?.autoRoutePersonal ?? true) && prefCheck.eligible;

    // Emit live SAVING pipeline event synchronized with 3D pipes
    this.notifyPipeline({
      sourceMode: cleanMode,
      memoryId: targetItem.id,
      targetCategory: prefCheck.targetCategory,
      title: targetItem.title,
      timestamp: Date.now(),
      status: 'SAVING',
      direction: shouldAutoRoute ? 'mode_to_personal_full' : 'mode_only',
      progress: 45,
      details: shouldAutoRoute
        ? `Saving "${targetItem.title}" in [${cleanMode}] & routing preference to Final Personal Memory...`
        : `Saving mode-isolated memory "${targetItem.title}" in [${cleanMode}] mode...`,
    });

    const modePersonaLabel = getDisplayModeName(cleanMode);

    this.addPipelineLog({
      type: shouldAutoRoute ? 'TRANSFER' : 'SAVE',
      title: `${modePersonaLabel} → Central Memory`,
      sourceMode: cleanMode,
      target: shouldAutoRoute ? 'Final Personal Memory' : 'Mode Memory',
      details: shouldAutoRoute ? `Preference synced: ${targetItem.title}` : `Memory saved: ${targetItem.title}`,
      timeAgoLabel: 'Just now',
    });

    try {
      const res = await fetch('/api/memories', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(targetItem),
      });

      if (!res.ok) {
        throw new Error(`HTTP ${res.status}`);
      }

      if (shouldAutoRoute) {
        await this.transferToMainPipeline(cleanMode, targetItem.id, prefCheck.targetCategory, targetItem);
      } else {
        // Transition to SYNCED then RUNNING
        this.schedulePipelineTransition(cleanMode, prefCheck.targetCategory, targetItem.title, 'mode_only');
      }
    } catch (err) {
      console.warn('[MEMORY_ENGINE] Server save failed:', err);
      this.notifyPipeline({
        sourceMode: cleanMode,
        memoryId: targetItem.id,
        targetCategory: prefCheck.targetCategory,
        title: targetItem.title,
        timestamp: Date.now(),
        status: 'ERROR',
        direction: 'mode_only',
        progress: 0,
        details: `Error saving "${targetItem.title}" to server storage.`,
      });
      this.addPipelineLog({
        type: 'ERROR',
        title: `${modePersonaLabel} → Error`,
        sourceMode: cleanMode,
        details: `Save failed for "${targetItem.title}"`,
        timeAgoLabel: 'Just now',
      });
    }

    return targetItem;
  }

  private schedulePipelineTransition(
    sourceMode: string,
    targetCategory: PersonalCategory,
    title: string,
    direction: PipelineFlowDirection
  ) {
    if (this.statusResetTimer) clearTimeout(this.statusResetTimer);

    setTimeout(() => {
      this.notifyPipeline({
        sourceMode,
        targetCategory,
        title,
        timestamp: Date.now(),
        status: 'SYNCED',
        direction,
        progress: 100,
        details: `Synced "${title}" with persistent memory store.`,
      });
    }, 550);

    this.statusResetTimer = setTimeout(() => {
      this.notifyPipeline({
        sourceMode,
        targetCategory,
        title,
        timestamp: Date.now(),
        status: 'RUNNING',
        direction,
        progress: 72,
        details: 'All 3D memory conduits active and synchronized.',
      });
    }, 2200);
  }

  /**
   * Deletes a specific memory from mode storage
   */
  async deleteMemory(id: string, mode: string): Promise<boolean> {
    const cleanMode = normalizeModeId(mode);
    const list = await this.getMemories(cleanMode);
    const target = list.find((m) => m.id === id);
    const filtered = list.filter((m) => m.id !== id);
    this.cache.set(cleanMode, filtered);
    this.saveToLocal(cleanMode, filtered);

    try {
      const res = await fetch(`/api/memories/${encodeURIComponent(id)}?mode=${encodeURIComponent(cleanMode)}`, {
        method: 'DELETE',
      });
      if (res.ok && target) {
        this.schedulePipelineTransition(cleanMode, 'preferences', target.title, 'mode_only');
      }
    } catch {}

    return true;
  }

  /**
   * Clears all memories for a specific mode
   */
  async clearModeMemories(mode: string): Promise<boolean> {
    const cleanMode = normalizeModeId(mode);
    this.cache.set(cleanMode, []);
    this.saveToLocal(cleanMode, []);

    try {
      await fetch(`/api/memories?mode=${encodeURIComponent(cleanMode)}`, {
        method: 'DELETE',
      });
    } catch {}

    return true;
  }

  /**
   * Toggles pinned/favorite state
   */
  async togglePin(id: string, mode: string): Promise<MemoryItem | null> {
    const cleanMode = normalizeModeId(mode);
    const list = await this.getMemories(cleanMode);
    const match = list.find((m) => m.id === id);
    if (!match) return null;

    const updated = { ...match, pinned: !match.pinned, updatedAt: new Date().toISOString() };
    const updatedList = list.map((m) => (m.id === id ? updated : m));
    this.cache.set(cleanMode, updatedList);
    this.saveToLocal(cleanMode, updatedList);

    try {
      await fetch(`/api/memories/${encodeURIComponent(id)}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updated),
      });
    } catch {}

    return updated;
  }

  /**
   * Automatically extracts and saves memorable information, preferences, instructions or corrections from dialogue
   */
  async extractFromConversation(
    userQuery: string,
    assistantReply?: string,
    mode?: string,
    language?: string
  ): Promise<{ saved: boolean; memory?: MemoryItem; pipedToPersonal?: boolean }> {
    const cleanMode = normalizeModeId(mode || 'girlfriend');
    try {
      let geminiApiKey = '';
      try {
        geminiApiKey = localStorage.getItem('zoya_gemini_api_key') || '';
      } catch {}

      const res = await fetch('/api/memories/extract', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userQuery,
          assistantReply,
          personaMode: cleanMode,
          language,
          geminiApiKey: geminiApiKey || undefined,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        if (data.saved && data.memory) {
          const existing = await this.getMemories(cleanMode);
          const updated = [data.memory, ...existing.filter((m) => m.id !== data.memory.id)];
          this.cache.set(cleanMode, updated);
          this.saveToLocal(cleanMode, updated);

          const isPiped = Boolean(data.pipedToPersonal);
          if (isPiped) {
            // Refresh main & personal memory caches
            this.cache.delete('main_memory');
            await this.getMainMemories(true);
            await this.getPersonalMemories(true);
          }

          this.notifyPipeline({
            sourceMode: cleanMode,
            memoryId: data.memory.id,
            targetCategory: data.targetCategory || 'preferences',
            title: data.memory.title,
            timestamp: Date.now(),
            status: isPiped ? 'TRANSFERRING' : 'SAVING',
            direction: isPiped ? 'mode_to_personal_full' : 'mode_only',
            progress: 85,
            details: isPiped
              ? `Auto-extracted preference "${data.memory.title}" -> Main Memory -> Final Personal Memory`
              : `Auto-saved mode memory "${data.memory.title}" in [${cleanMode}]`,
          });

          this.schedulePipelineTransition(
            cleanMode,
            data.targetCategory || 'preferences',
            data.memory.title,
            isPiped ? 'mode_to_personal_full' : 'mode_only'
          );

          return { saved: true, memory: data.memory, pipedToPersonal: isPiped };
        }
      }
    } catch (err) {
      console.warn('[MEMORY_ENGINE] extractFromConversation network error:', err);
    }
    return { saved: false };
  }

  subscribePipeline(callback: (event: PipelineTransferEvent) => void): () => void {
    this.pipelineListeners.add(callback);
    return () => {
      this.pipelineListeners.delete(callback);
    };
  }

  notifyPipeline(event: PipelineTransferEvent) {
    this.pipelineStatus = event.status;
    this.pipelineListeners.forEach((cb) => {
      try {
        cb(event);
      } catch (e) {
        console.error('[PIPELINE] Listener error:', e);
      }
    });
  }

  getPipelineStatus(): PipelineStatus {
    return this.pipelineStatus;
  }

  setPipelineStatus(status: PipelineStatus) {
    this.pipelineStatus = status;
  }

  getPipelineLogs(): PipelineLogItem[] {
    return [...this.pipelineLogs];
  }

  addPipelineLog(item: Omit<PipelineLogItem, 'id' | 'timestamp'>) {
    const newLog: PipelineLogItem = {
      id: `log-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      timestamp: Date.now(),
      timeAgoLabel: item.timeAgoLabel || 'Just now',
      ...item,
    };
    this.pipelineLogs = [newLog, ...this.pipelineLogs.slice(0, 49)];
  }

  /**
   * Real Hierarchical Memory Retrieval (Requirement 5):
   * 1. Check the active mode's isolated memory first (Tier 1).
   * 2. If information is missing, check Central Main Memory and Final Personal Memory when relevant (Tier 2).
   * Synchronizes visual pipe animations with actual retrieval operations!
   */
  async retrieveHierarchical(
    mode: string,
    query: string
  ): Promise<{
    source: 'mode' | 'main' | 'personal' | 'none';
    found: boolean;
    items: (MemoryItem | PersonalMemoryItem)[];
    matchedMemory?: MemoryItem | PersonalMemoryItem;
    explanation: string;
  }> {
    const cleanMode = normalizeModeId(mode);
    const qLower = query.toLowerCase().trim();
    const queryTokens = qLower
      .replace(/[?,!.;:।]/g, ' ')
      .split(/\s+/)
      .filter((w) => w.length >= 2);

    const modePersonaLabel = getDisplayModeName(cleanMode);

    // Emit RETRIEVING status
    this.notifyPipeline({
      sourceMode: cleanMode,
      targetCategory: 'preferences',
      title: `Retrieving: "${query.substring(0, 28)}"`,
      timestamp: Date.now(),
      status: 'RETRIEVING',
      direction: 'mode_only',
      progress: 40,
      details: `Step 1: Checking [${modePersonaLabel} (${cleanMode})] Mode Memory first...`,
    });

    // 1. TIER 1: Check active mode's own isolated memory first
    const modeMemories = await this.getMemories(cleanMode);
    const modeMatch = modeMemories.find((m) => {
      const titleLower = m.title.toLowerCase();
      const contentLower = m.content.toLowerCase();
      return queryTokens.some((tok) => titleLower.includes(tok) || contentLower.includes(tok));
    });

    if (modeMatch) {
      this.addPipelineLog({
        type: 'RETRIEVE',
        title: `${modePersonaLabel} Memory Hit`,
        sourceMode: cleanMode,
        target: cleanMode,
        details: `Retrieved from ${modePersonaLabel} mode memory: "${modeMatch.title}"`,
        timeAgoLabel: 'Just now',
      });

      this.schedulePipelineTransition(cleanMode, 'preferences', modeMatch.title, 'mode_only');

      return {
        source: 'mode',
        found: true,
        items: [modeMatch],
        matchedMemory: modeMatch,
        explanation: `Found directly in ${modePersonaLabel} (${cleanMode}) mode memory.`,
      };
    }

    // 2. TIER 2A: Missing in mode memory -> Check Central Main Memory
    const mainMemories = await this.getMainMemories();
    const mainMatch = mainMemories.find((m) => {
      const titleLower = m.title.toLowerCase();
      const contentLower = m.content.toLowerCase();
      return queryTokens.some((tok) => titleLower.includes(tok) || contentLower.includes(tok));
    });

    if (mainMatch) {
      this.notifyPipeline({
        sourceMode: cleanMode,
        targetCategory: 'preferences',
        title: mainMatch.title,
        timestamp: Date.now(),
        status: 'RETRIEVING',
        direction: 'main_to_mode',
        progress: 80,
        details: `Missing in ${cleanMode} mode; retrieved "${mainMatch.title}" from Central Main Memory!`,
      });

      this.addPipelineLog({
        type: 'RETRIEVE',
        title: `Central → ${modePersonaLabel}`,
        sourceMode: cleanMode,
        target: 'Central Memory',
        details: `Retrieved shared memory: "${mainMatch.title}"`,
        timeAgoLabel: 'Just now',
      });

      this.schedulePipelineTransition(cleanMode, 'preferences', mainMatch.title, 'main_to_mode');

      return {
        source: 'main',
        found: true,
        items: [mainMatch],
        matchedMemory: mainMatch,
        explanation: `Not in ${cleanMode} mode memory; retrieved from Central Main Memory.`,
      };
    }

    // 3. TIER 2B: Check Final Personal Memory (User's personal preferences, likes, dislikes, habits, choices)
    const personalMemories = await this.getPersonalMemories();
    const personalMatch = personalMemories.find((p) => {
      const titleLower = p.title.toLowerCase();
      const contentLower = p.content.toLowerCase();
      return queryTokens.some((tok) => titleLower.includes(tok) || contentLower.includes(tok));
    });

    if (personalMatch) {
      this.notifyPipeline({
        sourceMode: cleanMode,
        targetCategory: personalMatch.category,
        title: personalMatch.title,
        timestamp: Date.now(),
        status: 'RETRIEVING',
        direction: 'personal_to_mode',
        progress: 90,
        details: `Retrieved personal preference "${personalMatch.title}" via Central Main Memory pipeline!`,
      });

      this.addPipelineLog({
        type: 'RETRIEVE',
        title: `Personal → ${modePersonaLabel}`,
        sourceMode: cleanMode,
        target: 'Personal Memory',
        details: `Recalled personal preference: "${personalMatch.title}"`,
        timeAgoLabel: 'Just now',
      });

      this.schedulePipelineTransition(cleanMode, personalMatch.category, personalMatch.title, 'personal_to_mode');

      return {
        source: 'personal',
        found: true,
        items: [personalMatch],
        matchedMemory: personalMatch,
        explanation: `Not in ${cleanMode} mode memory; retrieved from Final Personal Memory [${personalMatch.category}].`,
      };
    }

    // Nothing matched: return status to RUNNING
    if (this.statusResetTimer) clearTimeout(this.statusResetTimer);
    this.statusResetTimer = setTimeout(() => {
      this.notifyPipeline({
        sourceMode: cleanMode,
        targetCategory: 'preferences',
        title: 'Standby',
        timestamp: Date.now(),
        status: 'RUNNING',
        direction: 'mode_only',
        progress: 72,
        details: `Checked ${cleanMode} mode, Central Main Memory, and Final Personal Memory.`,
      });
    }, 900);

    return {
      source: 'none',
      found: false,
      items: [],
      explanation: `Checked ${cleanMode} mode memory first, then Central Main Memory and Final Personal Memory (no match).`,
    };
  }

  /**
   * Retrieves Central Main Memory items
   */
  async getMainMemories(forceServer = false): Promise<MemoryItem[]> {
    if (!forceServer && this.cache.has('main_memory')) {
      return this.cache.get('main_memory')!;
    }
    if (!forceServer && typeof window !== 'undefined') {
      try {
        const saved = localStorage.getItem(MAIN_STORAGE_KEY);
        if (saved) {
          const parsed = JSON.parse(saved);
          if (Array.isArray(parsed) && parsed.length > 0) {
            this.cache.set('main_memory', parsed);
            return parsed;
          }
        }
      } catch {}
    }
    try {
      const res = await fetch('/api/memories/main');
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data.memories) && data.memories.length > 0) {
          this.cache.set('main_memory', data.memories);
          this.saveMainToLocal(data.memories);
          return data.memories;
        }
      }
    } catch {}

    const defaults = [...DEFAULT_MAIN_MEMORIES];
    this.cache.set('main_memory', defaults);
    this.saveMainToLocal(defaults);
    return defaults;
  }

  /**
   * Saves or updates an item in Central Main Memory (deduplicated)
   */
  async saveMainMemory(item: Partial<MemoryItem> & { title: string; content: string }): Promise<MemoryItem> {
    const list = await this.getMainMemories();
    const now = new Date().toISOString();
    const normTitle = normalizeMemoryText(item.title);
    const existing = list.find((m) => m.id === item.id || normalizeMemoryText(m.title) === normTitle);

    const newItem: MemoryItem = {
      id: existing?.id || item.id || `main-${Date.now()}`,
      mode: 'main_memory',
      layer: item.layer || existing?.layer || 'preference',
      title: item.title.trim(),
      content: item.content.trim(),
      importance: item.importance || existing?.importance || 4,
      pinned: item.pinned !== undefined ? item.pinned : true,
      createdAt: existing?.createdAt || item.createdAt || now,
      updatedAt: now,
      source: item.source || 'pipeline_transfer',
    };

    const updated = [newItem, ...list.filter((m) => m.id !== newItem.id && normalizeMemoryText(m.title) !== normTitle)];
    this.cache.set('main_memory', updated);
    this.saveMainToLocal(updated);

    try {
      await fetch('/api/memories/main', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newItem),
      });
    } catch {}

    return newItem;
  }

  /**
   * Deletes an item from Central Main Memory
   */
  async deleteMainMemory(id: string): Promise<boolean> {
    const list = await this.getMainMemories();
    const updated = list.filter((m) => m.id !== id);
    this.cache.set('main_memory', updated);
    this.saveMainToLocal(updated);

    try {
      await fetch(`/api/memories/main/${encodeURIComponent(id)}`, { method: 'DELETE' });
    } catch {}
    return true;
  }

  /**
   * Retrieves Final Personal Memory items (5 categories)
   */
  async getPersonalMemories(forceServer = false): Promise<PersonalMemoryItem[]> {
    if (!forceServer && typeof window !== 'undefined') {
      try {
        const saved = localStorage.getItem(PERSONAL_STORAGE_KEY);
        if (saved) {
          const parsed = JSON.parse(saved);
          if (Array.isArray(parsed) && parsed.length > 0) {
            return parsed;
          }
        }
      } catch {}
    }

    try {
      const res = await fetch('/api/memories/personal');
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data.memories) && data.memories.length > 0) {
          this.savePersonalToLocal(data.memories);
          return data.memories;
        }
      }
    } catch {}

    const defaults = [...DEFAULT_PERSONAL_MEMORIES];
    this.savePersonalToLocal(defaults);
    return defaults;
  }

  /**
   * Saves or updates an item in Final Personal Memory (deduplicated)
   */
  async savePersonalMemory(
    item: Omit<PersonalMemoryItem, 'id' | 'updatedAt'> & { id?: string }
  ): Promise<PersonalMemoryItem> {
    const list = await this.getPersonalMemories();
    const now = new Date().toISOString();
    const normTitle = normalizeMemoryText(item.title);
    const existing = list.find(
      (p) => p.id === item.id || (p.category === item.category && normalizeMemoryText(p.title) === normTitle)
    );

    const newItem: PersonalMemoryItem = {
      id: existing?.id || item.id || `pers-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      category: item.category,
      title: item.title.trim(),
      content: item.content.trim(),
      importance: item.importance || existing?.importance || 4,
      updatedAt: now,
      source: item.source || 'pipeline_transfer',
      originMode: item.originMode || existing?.originMode || 'girlfriend',
    };

    const updated = [
      newItem,
      ...list.filter(
        (p) => p.id !== newItem.id && !(p.category === newItem.category && normalizeMemoryText(p.title) === normTitle)
      ),
    ];
    this.savePersonalToLocal(updated);

    this.notifyPipeline({
      sourceMode: newItem.originMode || 'girlfriend',
      targetCategory: newItem.category,
      title: newItem.title,
      timestamp: Date.now(),
      status: 'SAVING',
      direction: 'main_to_personal',
      progress: 75,
      details: `Saving personal preference "${newItem.title}" to Final Personal Memory [${newItem.category}]...`,
    });

    try {
      const res = await fetch('/api/memories/personal', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newItem),
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      this.schedulePipelineTransition(
        newItem.originMode || 'girlfriend',
        newItem.category,
        newItem.title,
        'main_to_personal'
      );
    } catch {
      this.notifyPipeline({
        sourceMode: newItem.originMode || 'girlfriend',
        targetCategory: newItem.category,
        title: newItem.title,
        timestamp: Date.now(),
        status: 'ERROR',
        direction: 'main_to_personal',
        progress: 0,
        details: `Failed to sync personal preference "${newItem.title}".`,
      });
    }

    return newItem;
  }

  /**
   * Deletes an item from Final Personal Memory
   */
  async deletePersonalMemory(id: string): Promise<boolean> {
    const list = await this.getPersonalMemories();
    const updated = list.filter((p) => p.id !== id);
    this.savePersonalToLocal(updated);

    try {
      await fetch(`/api/memories/personal/${encodeURIComponent(id)}`, { method: 'DELETE' });
    } catch {}
    return true;
  }

  /**
   * Transfers a memory item from an isolated Mode Memory -> through Central Main Memory -> into Final Personal Memory
   */
  async transferToMainPipeline(
    sourceMode: string,
    memoryId: string,
    targetCategory: PersonalCategory = 'preferences',
    explicitItem?: MemoryItem
  ): Promise<{ success: boolean; mainItem?: MemoryItem; personalItem?: PersonalMemoryItem }> {
    const cleanMode = normalizeModeId(sourceMode);
    const modeList = await this.getMemories(cleanMode);
    const sourceItem = explicitItem || modeList.find((m) => m.id === memoryId);

    if (!sourceItem) {
      this.notifyPipeline({
        sourceMode: cleanMode,
        memoryId,
        targetCategory,
        title: 'Unknown Memory',
        timestamp: Date.now(),
        status: 'ERROR',
        direction: 'mode_only',
        progress: 0,
        details: 'Source memory not found for pipeline transfer.',
      });
      return { success: false };
    }

    const modePersonaLabel = getDisplayModeName(cleanMode);

    // Stage 1: Mode Memory -> Central Main Memory
    this.notifyPipeline({
      sourceMode: cleanMode,
      memoryId,
      targetCategory,
      title: sourceItem.title,
      timestamp: Date.now(),
      status: 'TRANSFERRING',
      direction: 'mode_to_personal_full',
      progress: 65,
      details: `Routing "${sourceItem.title}" from ${modePersonaLabel} Mode -> Central Main Memory -> Final Personal Memory [${targetCategory}]`,
    });

    this.addPipelineLog({
      type: 'TRANSFER',
      title: `${modePersonaLabel} → Central Memory`,
      sourceMode: cleanMode,
      target: `Personal [${targetCategory}]`,
      details: `Transferred preference: "${sourceItem.title}"`,
      timeAgoLabel: 'Just now',
    });

    try {
      const mainItem = await this.saveMainMemory({
        title: sourceItem.title,
        content: sourceItem.content,
        layer: sourceItem.layer === 'instruction' ? 'instruction' : 'preference',
        importance: sourceItem.importance,
        source: 'pipeline_transfer',
      });

      const personalItem = await this.savePersonalMemory({
        category: targetCategory,
        title: sourceItem.title,
        content: sourceItem.content,
        importance: sourceItem.importance,
        source: 'pipeline_transfer',
        originMode: cleanMode,
      });

      const res = await fetch('/api/memories/transfer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sourceMode: cleanMode,
          memoryId,
          targetCategory,
          title: sourceItem.title,
          content: sourceItem.content,
          importance: sourceItem.importance,
        }),
      });

      if (!res.ok) {
        throw new Error(`Transfer endpoint returned ${res.status}`);
      }

      this.schedulePipelineTransition(cleanMode, targetCategory, sourceItem.title, 'mode_to_personal_full');

      return { success: true, mainItem, personalItem };
    } catch (err) {
      this.notifyPipeline({
        sourceMode: cleanMode,
        memoryId,
        targetCategory,
        title: sourceItem.title,
        timestamp: Date.now(),
        status: 'ERROR',
        direction: 'mode_to_personal_full',
        progress: 0,
        details: `Transfer failed: ${err instanceof Error ? err.message : 'Network error'}`,
      });
      return { success: false };
    }
  }

  private saveMainToLocal(list: MemoryItem[]) {
    if (typeof window === 'undefined') return;
    try {
      localStorage.setItem(MAIN_STORAGE_KEY, JSON.stringify(list));
    } catch {}
  }

  private savePersonalToLocal(list: PersonalMemoryItem[]) {
    if (typeof window === 'undefined') return;
    try {
      localStorage.setItem(PERSONAL_STORAGE_KEY, JSON.stringify(list));
    } catch {}
  }

  private saveToLocal(mode: string, list: MemoryItem[]) {
    if (typeof window === 'undefined') return;
    try {
      localStorage.setItem(STORAGE_PREFIX + mode, JSON.stringify(list));
      if (mode === 'girlfriend') {
        localStorage.setItem('zoya_memories', JSON.stringify(list));
      }
    } catch {}
  }
}

export const zoyaMemory = new ZoyaMemoryEngine();
