/**
 * Zoya Neural Voice Registry & Settings Manager
 * Supports:
 * - Google Gemini Prebuilt Neural Voices (Kore, Aoede, Puck, Charon, Fenrir) via gemini-3.8-flash-lite-tts / gemini-3.8-live
 * - ElevenLabs v4 Turbo Voices (Rachel, Domi, Bella, Antoni) via eleven_turbo_v2_5
 * - ElevenLabs v4 Multilingual Voices (Elli, Josh) via eleven_multilingual_v2
 * - Custom ElevenLabs Voice ID configured in API Settings
 *
 * Enforces Zero-Robotic-Voice: Never falls back to browser SpeechSynthesis or Android default TTS.
 */

export interface ZoyaVoiceItem {
  id: string;
  name: string;
  displayName: string;
  provider: 'gemini' | 'elevenlabs';
  providerLabel: string;
  model: string;
  voiceParam: string;
  gender: 'Female' | 'Male';
  badge?: string;
  description: string;
  sampleText: string;
  isDefault?: boolean;
}

export const ZOYA_AVAILABLE_VOICES: ZoyaVoiceItem[] = [
  // -------------------------------------------------------------
  // Google Gemini Prebuilt Neural Voices (24kHz HD Audio)
  // -------------------------------------------------------------
  {
    id: 'gemini-kore',
    name: 'Kore',
    displayName: 'Kore',
    provider: 'gemini',
    providerLabel: 'Google Gemini Neural',
    model: 'gemini-3.8-flash-lite-tts',
    voiceParam: 'Kore',
    gender: 'Female',
    badge: 'Zoya Default',
    description: 'Warm, natural, clear, and balanced feminine tone with exceptional articulation.',
    sampleText: 'Hello! I am Zoya, your intelligent AI companion. How can I help you today?',
    isDefault: true,
  },
  {
    id: 'gemini-aoede',
    name: 'Aoede',
    displayName: 'Aoede',
    provider: 'gemini',
    providerLabel: 'Google Gemini Neural',
    model: 'gemini-3.8-flash-lite-tts',
    voiceParam: 'Aoede',
    gender: 'Female',
    badge: 'Melodious',
    description: 'Expressive, melodious, and sophisticated tone with gentle emotional warmth.',
    sampleText: 'Hello! I am Zoya, your intelligent AI companion. How can I help you today?',
  },
  {
    id: 'gemini-puck',
    name: 'Puck',
    displayName: 'Puck',
    provider: 'gemini',
    providerLabel: 'Google Gemini Neural',
    model: 'gemini-3.8-flash-lite-tts',
    voiceParam: 'Puck',
    gender: 'Male',
    badge: 'Energetic',
    description: 'Youthful, vibrant, and enthusiastic tone for upbeat conversation.',
    sampleText: 'Hello! I am Zoya, your intelligent AI companion. How can I help you today?',
  },
  {
    id: 'gemini-charon',
    name: 'Charon',
    displayName: 'Charon',
    provider: 'gemini',
    providerLabel: 'Google Gemini Neural',
    model: 'gemini-3.8-flash-lite-tts',
    voiceParam: 'Charon',
    gender: 'Male',
    badge: 'Calm & Deep',
    description: 'Deep, calm, and authoritative voice suitable for executive professional tasks.',
    sampleText: 'Hello! I am Zoya, your intelligent AI companion. How can I help you today?',
  },
  {
    id: 'gemini-fenrir',
    name: 'Fenrir',
    displayName: 'Fenrir',
    provider: 'gemini',
    providerLabel: 'Google Gemini Neural',
    model: 'gemini-3.8-flash-lite-tts',
    voiceParam: 'Fenrir',
    gender: 'Male',
    badge: 'Strong',
    description: 'Strong, resonant, confident, and direct speaking delivery.',
    sampleText: 'Hello! I am Zoya, your intelligent AI companion. How can I help you today?',
  },

  // -------------------------------------------------------------
  // ElevenLabs Neural Voices (Tier 1: Turbo v2.5 & Tier 2: Multilingual v2)
  // -------------------------------------------------------------
  {
    id: 'eleven-rachel',
    name: 'Rachel',
    displayName: 'Rachel',
    provider: 'elevenlabs',
    providerLabel: 'ElevenLabs Turbo',
    model: 'eleven_turbo_v2_5',
    voiceParam: '21m00Tcm4TlvDq8ikWAM',
    gender: 'Female',
    badge: 'Calm & Polish',
    description: 'Calm, articulate, professional, and natural conversational cadence.',
    sampleText: 'Hello! I am Zoya, your intelligent AI companion. How can I help you today?',
  },
  {
    id: 'eleven-domi',
    name: 'Domi',
    displayName: 'Domi',
    provider: 'elevenlabs',
    providerLabel: 'ElevenLabs Turbo',
    model: 'eleven_turbo_v2_5',
    voiceParam: 'AZnzlk1XvdvUeBnXmlld',
    gender: 'Female',
    badge: 'Expressive',
    description: 'Strong, emotive, and engaging feminine voice with clear inflection.',
    sampleText: 'Hello! I am Zoya, your intelligent AI companion. How can I help you today?',
  },
  {
    id: 'eleven-bella',
    name: 'Bella',
    displayName: 'Bella',
    provider: 'elevenlabs',
    providerLabel: 'ElevenLabs Turbo',
    model: 'eleven_turbo_v2_5',
    voiceParam: 'EXAVITQu4vr4xnSDxMaL',
    gender: 'Female',
    badge: 'Sweet & Young',
    description: 'Bright, sweet, friendly, and cheerful feminine voice.',
    sampleText: 'Hello! I am Zoya, your intelligent AI companion. How can I help you today?',
  },
  {
    id: 'eleven-antoni',
    name: 'Antoni',
    displayName: 'Antoni',
    provider: 'elevenlabs',
    providerLabel: 'ElevenLabs Turbo',
    model: 'eleven_turbo_v2_5',
    voiceParam: 'ErXwobaYiN019PkySvjV',
    gender: 'Male',
    badge: 'Smooth',
    description: 'Smooth, pleasant, articulate, and well-rounded masculine voice.',
    sampleText: 'Hello! I am Zoya, your intelligent AI companion. How can I help you today?',
  },
  {
    id: 'eleven-elli',
    name: 'Elli',
    displayName: 'Elli',
    provider: 'elevenlabs',
    providerLabel: 'ElevenLabs Multilingual',
    model: 'eleven_multilingual_v2',
    voiceParam: 'MF3mGyEYCl7XYWbV9V6O',
    gender: 'Female',
    badge: 'Conversational',
    description: 'Warm, youthful, cheerful, and optimized for multilingual conversations.',
    sampleText: 'Hello! I am Zoya, your intelligent AI companion. How can I help you today?',
  },
  {
    id: 'eleven-josh',
    name: 'Josh',
    displayName: 'Josh',
    provider: 'elevenlabs',
    providerLabel: 'ElevenLabs Multilingual',
    model: 'eleven_multilingual_v2',
    voiceParam: 'TxGEqnHWrfWFTfGW9XjX',
    gender: 'Male',
    badge: 'Deep & Warm',
    description: 'Deep, relaxed, resonant, and natural masculine delivery.',
    sampleText: 'Hello! I am Zoya, your intelligent AI companion. How can I help you today?',
  },
];

const STORAGE_KEY = 'zoya_selected_voice_id';

export const zoyaVoiceManager = {
  getVoices(): ZoyaVoiceItem[] {
    return ZOYA_AVAILABLE_VOICES;
  },

  getSelectedVoiceId(): string {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved && ZOYA_AVAILABLE_VOICES.some((v) => v.id === saved)) {
        return saved;
      }
    } catch {}
    return 'gemini-kore'; // Default Zoya signature voice
  },

  getSelectedVoice(): ZoyaVoiceItem {
    const id = this.getSelectedVoiceId();
    return ZOYA_AVAILABLE_VOICES.find((v) => v.id === id) || ZOYA_AVAILABLE_VOICES[0];
  },

  setSelectedVoiceId(id: string): void {
    const found = ZOYA_AVAILABLE_VOICES.find((v) => v.id === id);
    if (!found) return;
    try {
      localStorage.setItem(STORAGE_KEY, id);
      window.dispatchEvent(new CustomEvent('zoya-voice-changed', { detail: { voice: found } }));
    } catch {}
  },

  getVoiceById(id: string): ZoyaVoiceItem | undefined {
    return ZOYA_AVAILABLE_VOICES.find((v) => v.id === id);
  },
};
