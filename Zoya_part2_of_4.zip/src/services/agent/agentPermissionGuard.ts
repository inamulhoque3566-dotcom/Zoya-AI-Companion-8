import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { maskSecrets } from './secretMasker.ts';

export type PermissionLevel = 'AUTO_ALLOW' | 'ASK_APPROVAL' | 'STRICT_APPROVAL_WITH_WARNING' | 'BLOCKED';

export interface CommandSecurityInspection {
  level: PermissionLevel;
  isBlocked: boolean;
  reason: string;
  warningDetails?: string;
  matchedPattern?: string;
}

export interface PendingApprovalRequest {
  id: string;
  taskId: string;
  toolName: string;
  args: Record<string, any>;
  bindingHash: string;
  level: 'ASK_APPROVAL' | 'STRICT_APPROVAL_WITH_WARNING';
  reason: string;
  warning?: string;
  createdAt: string;
  expiresAt: number; // 5-minute TTL
  status: 'pending' | 'approved' | 'denied';
  resolvedAt?: string;
  resolvedBy?: string;
  consumed: boolean; // Single-use enforcement
  consumedAt?: string;
}

export interface SecurityAuditLogItem {
  id: string;
  timestamp: string;
  taskId?: string;
  action: 'AUTO_ALLOWED' | 'APPROVAL_REQUESTED' | 'APPROVED' | 'DENIED' | 'BLOCKED_VIOLATION';
  toolName: string;
  details: string;
  level: PermissionLevel;
  userOverride?: boolean;
}

const SECURITY_LOG_FILE = path.join(process.cwd(), 'data', 'agent_logs', 'security_audit.log');

export { maskSecrets };


export class AgentPermissionGuard {
  private static instance: AgentPermissionGuard;
  private pendingApprovals = new Map<string, PendingApprovalRequest>();
  private approvalResolvers = new Map<string, (approved: boolean) => void>();
  private securityAuditLogs: SecurityAuditLogItem[] = [];

  constructor() {
    this.ensureLogDir();
  }

  public static getInstance(): AgentPermissionGuard {
    if (!AgentPermissionGuard.instance) {
      AgentPermissionGuard.instance = new AgentPermissionGuard();
    }
    return AgentPermissionGuard.instance;
  }

  private ensureLogDir() {
    try {
      const dir = path.dirname(SECURITY_LOG_FILE);
      if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    } catch {}
  }

  /**
   * Inspects a command and checks for dangerous patterns or prohibited operations
   */
  public inspectCommand(command: string, workspaceRoot: string): CommandSecurityInspection {
    const raw = (command || '').trim();
    const lower = raw.toLowerCase();

    // 1. Strictly BLOCKED: Sensitive system file exfiltration across cat, head, tail, python, node, bash, or relative paths
    // Obfuscation patterns: string concatenation '/e'+'tc', base64 piping, command substitution $(...), symlinks
    const sensitiveSysFiles = /(?:(?:\/|\.\.\/)+etc\/(?:passwd|shadow|hosts|sudoers|group)|(?:open|readFile|readFileSync|cat|tail|head|less|more|grep|strings)[\s("']+[^"']*(?:passwd|shadow|hosts|sudoers|group)|\/etc\/(?:passwd|shadow|hosts|sudoers|group))/i;
    const stringConcatObfuscation = /['"][^'"]*\/e['"]\s*\+\s*['"]tc/i;
    const stringConcatAnyPasswd = /['"][^'"]*\+[^'"]*(?:passwd|shadow|etc)/i;
    const base64DecodePipe = /base64\s+(-d|--decode)\s*\|\s*(sh|bash|zsh)/i;
    const commandSubstitutionEtc = /(\$\([^)]*etc[^)]*\)|`[^`]*etc[^`]*`)/i;
    const cdRootAccess = /(?:^|[;&|]\s*)cd\s+\/\s*(?:&&|[;&|]|$)/i;
    const symlinkOutsideWorkspace = /\bln\s+-[a-z]*s\b[^\n]+(?:\/etc|\/root|\/var|\/usr|\/bin|\/home)/i;
    const etcPasswdDirect = /\betc\/passwd\b/i;

    if (
      sensitiveSysFiles.test(raw) ||
      stringConcatObfuscation.test(raw) ||
      stringConcatAnyPasswd.test(raw) ||
      base64DecodePipe.test(raw) ||
      commandSubstitutionEtc.test(raw) ||
      cdRootAccess.test(raw) ||
      symlinkOutsideWorkspace.test(raw) ||
      etcPasswdDirect.test(raw) ||
      /\bcat\s+.*\/etc\/(passwd|shadow|hosts|sudoers)\b/i.test(raw) ||
      /\b(\/etc\/passwd|\/etc\/shadow|\/etc\/hosts|\/etc\/sudoers)\b/i.test(raw) ||
      /\.\.\/.*etc\/(passwd|shadow|hosts|sudoers)/i.test(raw)
    ) {
      return {
        level: 'BLOCKED',
        isBlocked: true,
        reason: 'CRITICAL SECURITY VIOLATION: Access to sensitive system files (/etc/passwd, /etc/hosts, /etc/shadow) or obfuscated evasion is prohibited.',
        matchedPattern: 'SENSITIVE_SYSTEM_FILE_ACCESS',
      };
    }

    // Agent self-approval / privilege token exfiltration / credential file access blocked
    if (
      /\b\.env\b/i.test(raw) ||
      /\bagent_auth_token\b/i.test(raw) ||
      /\bagent_user_secret\b/i.test(raw) ||
      /\/api\/agent\/(?:auth\/token|auth\/pairing-code|approvals)|\bapprovals\/[^\s\/]+\/respond\b/i.test(raw) ||
      /\bx-user-approval-token\b/i.test(raw) ||
      /\bx-agent-pairing-code\b/i.test(raw) ||
      /\bZOYA_USER_APPROVAL_SECRET\b/i.test(raw)
    ) {
      return {
        level: 'BLOCKED',
        isBlocked: true,
        reason: 'SECURITY VIOLATION: Agent subprocess cannot invoke approval endpoints or access user approval secrets and credential files (.env, tokens).',
        matchedPattern: 'SECRET_CREDENTIAL_ACCESS',
      };
    }

    if (/\b(sudo|su\s|chmod\s+\+x|chmod\s+777|chown)\b/i.test(raw)) {
      return {
        level: 'BLOCKED',
        isBlocked: true,
        reason: 'PRIVILEGE ESCALATION VIOLATION: Execution of sudo, su, or root permission changes is prohibited.',
        matchedPattern: 'PRIVILEGE_ESCALATION',
      };
    }

    if (/\|\s*(sh|bash|zsh)\b/i.test(raw)) {
      return {
        level: 'BLOCKED',
        isBlocked: true,
        reason: 'DANGEROUS SHELL PIPING: Piping arbitrary output directly to sh/bash is prohibited.',
        matchedPattern: 'SHELL_INJECTION_PIPE',
      };
    }

    // Reject any command referencing absolute paths outside the workspace
    // (Allowed system binary paths like /bin/bash, /usr/bin/python3, /usr/bin/node are permitted as the executable)
    const normalizedWorkspace = path.resolve(workspaceRoot);
    const strippedUrls = raw.replace(/https?:\/\/[^\s'"]+/g, '');
    const absolutePathRegex = /(?:^|[\s'"(=:,])(\/(?:[a-zA-Z0-9_\-\.]+\/?)*)/g;
    let pathMatch: RegExpExecArray | null;
    while ((pathMatch = absolutePathRegex.exec(strippedUrls)) !== null) {
      const cleanPath = pathMatch[1].trim();
      if (!cleanPath) continue;
      if (cleanPath === '/') {
        return {
          level: 'BLOCKED',
          isBlocked: true,
          reason: `SECURITY VIOLATION: Command references root filesystem path '/' outside workspace.`,
          matchedPattern: 'ABSOLUTE_PATH_OUTSIDE_WORKSPACE',
        };
      }
      const allowedBinaryPrefixes = ['/bin/', '/usr/bin/', '/usr/local/bin/', '/sbin/', '/usr/sbin/'];
      const isAllowedBinary = allowedBinaryPrefixes.some((p) => cleanPath === p.slice(0, -1) || cleanPath.startsWith(p));
      const isInsideWorkspace = cleanPath === normalizedWorkspace || cleanPath.startsWith(normalizedWorkspace + '/');
      const isInsideSkills = cleanPath.startsWith(path.resolve(process.cwd(), 'data', 'agent_skills', 'installed'));
      if (!isInsideWorkspace && !isAllowedBinary && !isInsideSkills) {
        return {
          level: 'BLOCKED',
          isBlocked: true,
          reason: `SECURITY VIOLATION: Command references absolute path outside workspace: '${cleanPath}'`,
          matchedPattern: 'ABSOLUTE_PATH_OUTSIDE_WORKSPACE',
        };
      }
    }

    // 2. STRICT APPROVAL WITH WARNING: Destructive commands, package installs, external network
    if (
      /\brm\s+(-[a-z]*r[a-z]*f|-[a-z]*f[a-z]*r|--recursive)\b/i.test(raw) ||
      /\brm\s+-rf\b/i.test(raw) ||
      /\b(shutil\.rmtree|os\.remove|os\.unlink|fs\.rmSync|fs\.rmdirSync|rimraf)\b/i.test(raw)
    ) {
      return {
        level: 'STRICT_APPROVAL_WITH_WARNING',
        isBlocked: false,
        reason: 'DANGEROUS DELETION: Recursive forced file deletion or destructive script call detected.',
        warningDetails: 'WARNING: This will permanently delete files and directories. Requires explicit user approval.',
        matchedPattern: 'RM_RF',
      };
    }

    if (/\b(npm\s+(i|install|add)|pip\s+install|pip3\s+install|apt|apk|yum)\b/i.test(raw)) {
      return {
        level: 'STRICT_APPROVAL_WITH_WARNING',
        isBlocked: false,
        reason: 'PACKAGE INSTALLATION: Command attempts to install or modify packages.',
        warningDetails: 'WARNING: Package installation modifies environment dependencies. Requires explicit user approval.',
        matchedPattern: 'PACKAGE_INSTALL',
      };
    }

    if (/\b(curl|wget|git\s+push|nc|ncat|ssh|scp|sftp)\b/i.test(raw)) {
      return {
        level: 'STRICT_APPROVAL_WITH_WARNING',
        isBlocked: false,
        reason: 'NETWORK ACCESS / EGRESS: Command initiates external network connections.',
        warningDetails: 'WARNING: External network transfer detected. Verify target URL before approving.',
        matchedPattern: 'NETWORK_EGRESS',
      };
    }

    // Check if command references paths outside workspace (e.g. /var, /root, /etc, /tmp)
    if (
      /(?:^|\s|['"(])(?:\/root|\/etc|\/var|\/usr|\/bin|\/sbin|\/dev|\/tmp|\.\.\/\.\.)/i.test(raw) &&
      !raw.includes(workspaceRoot)
    ) {
      return {
        level: 'STRICT_APPROVAL_WITH_WARNING',
        isBlocked: false,
        reason: 'OUTSIDE PATH REFERENCE: Command references paths outside the confined workspace.',
        warningDetails: 'WARNING: Attempting to interact with files outside the designated workspace.',
        matchedPattern: 'PATH_OUTSIDE_WORKSPACE',
      };
    }

    // 3. SCRIPT FILE INSPECTION: Inspect referenced script files inside the workspace
    // Matches commands like: python3 script.py, node run.js, bash test.sh, ./run.sh
    const scriptRefMatch =
      raw.match(/(?:python[0-9.]*|node|bash|sh|ts-node|tsx)\s+([a-zA-Z0-9_\-\.\/]+\.(?:py|js|ts|sh|bash|rb|pl))/i) ||
      raw.match(/(?:^|[;&|]\s*)\.\/([a-zA-Z0-9_\-\.]+\.(?:py|js|ts|sh|bash))/i);

    if (scriptRefMatch) {
      const scriptRelPath = scriptRefMatch[1];
      const scriptFullPath = path.isAbsolute(scriptRelPath)
        ? scriptRelPath
        : path.resolve(workspaceRoot, scriptRelPath);

      if (fs.existsSync(scriptFullPath) && fs.statSync(scriptFullPath).isFile()) {
        try {
          const scriptContent = fs.readFileSync(scriptFullPath, 'utf8');
          const scriptHash = crypto.createHash('sha256').update(scriptContent).digest('hex');
          const preview = scriptContent.slice(0, 300);

          // Scan script content for sensitive evasion or system file access
          const hasChrPasswd =
            /chr\s*\(\s*47\s*\)\s*\+\s*['"]etc['"]/i.test(scriptContent) ||
            /chr\s*\(\s*47\s*\)[\s\S]*?(?:passwd|shadow)/i.test(scriptContent) ||
            /chr\s*\(\s*101\s*\)\s*\+\s*chr\s*\(\s*116\s*\)/i.test(scriptContent);
          const hasEtcPasswdInScript = /(?:\/etc\/(?:passwd|shadow|hosts|sudoers)|\/root\/\.zoya)/i.test(scriptContent);
          const hasBase64PipeInScript = /base64\s+(-d|--decode)\s*\|\s*(sh|bash)/i.test(scriptContent);

          if (hasChrPasswd || hasEtcPasswdInScript || hasBase64PipeInScript) {
            return {
              level: 'BLOCKED',
              isBlocked: true,
              reason: `SECURITY VIOLATION: Script file '${path.basename(scriptFullPath)}' (SHA-256: ${scriptHash.slice(0, 16)}...) contains malicious evasion or unauthorized access to system files (/etc/passwd, /root/.zoya).`,
              matchedPattern: 'SCRIPT_FILE_EVASION',
              warningDetails: `[SCRIPT INSPECTION] Hash: ${scriptHash}\nPreview:\n${preview}`,
            };
          }

          // Script is clean: provide script content preview and hash in approval details
          return {
            level: 'ASK_APPROVAL',
            isBlocked: false,
            reason: `STANDARD_EXECUTION: User approval required for script execution.`,
            warningDetails: `[SCRIPT INSPECTION] Target: ${path.basename(scriptFullPath)} | SHA-256: ${scriptHash.slice(0, 16)}...\n--- SCRIPT PREVIEW ---\n${preview}${scriptContent.length > 300 ? '\n... (truncated)' : ''}\n----------------------`,
          };
        } catch {}
      }
    }

    // Default for standard commands (e.g. ls, pytest)
    return {
      level: 'ASK_APPROVAL',
      isBlocked: false,
      reason: 'STANDARD_EXECUTION: User approval required for shell execution.',
    };
  }

  public checkToolCall(
    toolName: string,
    args: Record<string, any>,
    workspaceRoot: string
  ) {
    return this.evaluateToolCall(toolName, args, workspaceRoot);
  }

  /**
   * Evaluates any tool call before execution
   */
  public evaluateToolCall(
    toolName: string,
    args: Record<string, any>,
    workspaceRoot: string
  ): {
    level: PermissionLevel;
    needsApproval: boolean;
    isBlocked: boolean;
    reason: string;
    warning?: string;
  } {
    // 1. AUTO-ALLOW READ-ONLY TOOLS
    if (['read_file', 'list_dir', 'search_code'].includes(toolName)) {
      const targetPath = args.path || args.dirPath || '';
      // Verify path doesn't attempt illegal traversal or secret file access
      if (
        typeof targetPath === 'string' &&
        (targetPath.includes('/etc/') ||
          targetPath.startsWith('/') ||
          targetPath.includes('..') ||
          targetPath.includes('agent_user_secret'))
      ) {
        return {
          level: 'BLOCKED',
          needsApproval: false,
          isBlocked: true,
          reason: 'Access to system root, parent path traversal, or user approval secret is prohibited.',
        };
      }
      return {
        level: 'AUTO_ALLOW',
        needsApproval: false,
        isBlocked: false,
        reason: 'Read-only operation allowed automatically.',
      };
    }

    // 2. SHELL COMMANDS: Run through deep inspection
    if (toolName === 'run_command') {
      const inspection = this.inspectCommand(args.command || '', workspaceRoot);
      if (inspection.isBlocked) {
        return {
          level: 'BLOCKED',
          needsApproval: false,
          isBlocked: true,
          reason: inspection.reason,
        };
      }
      if (inspection.level === 'STRICT_APPROVAL_WITH_WARNING') {
        return {
          level: 'STRICT_APPROVAL_WITH_WARNING',
          needsApproval: true,
          isBlocked: false,
          reason: inspection.reason,
          warning: inspection.warningDetails,
        };
      }
      return {
        level: 'ASK_APPROVAL',
        needsApproval: true,
        isBlocked: false,
        reason: inspection.reason || 'Standard shell command execution requires approval.',
        warning: inspection.warningDetails,
      };
    }

    // 3. FILE MUTATIONS & WRITES: Ask approval
    if (['write_file', 'replace_file_content', 'multi_file_edit'].includes(toolName)) {
      return {
        level: 'ASK_APPROVAL',
        needsApproval: true,
        isBlocked: false,
        reason: `File modification tool '${toolName}' requires user approval.`,
      };
    }

    // 4. TEST, BUILD, & SKILL SCRIPT RUNNERS
    if (['run_tests', 'run_build'].includes(toolName)) {
      return {
        level: 'ASK_APPROVAL',
        needsApproval: true,
        isBlocked: false,
        reason: `Build / Test execution tool '${toolName}' requires user approval.`,
      };
    }

    if (toolName === 'run_skill_script') {
      return {
        level: 'ASK_APPROVAL',
        needsApproval: true,
        isBlocked: false,
        reason: `Executing skill script '${args.script}' from skill '${args.skillId}' requires approval.`,
      };
    }

    // 5. MCP (Model Context Protocol) TOOL CALLS: Require explicit approval per call unless marked auto-allow by user
    if (toolName === 'call_mcp_tool' || toolName.startsWith('mcp_')) {
      const isAutoAllowed = Boolean(args?._autoAllow);
      if (isAutoAllowed) {
        return {
          level: 'AUTO_ALLOW',
          needsApproval: false,
          isBlocked: false,
          reason: `MCP tool '${args?.toolName || toolName}' is explicitly marked auto-allow by user policy.`,
        };
      }
      return {
        level: 'ASK_APPROVAL',
        needsApproval: true,
        isBlocked: false,
        reason: `Executing MCP tool '${args?.toolName || toolName}' on server '${args?.serverId || 'unknown'}' requires user approval.`,
        warning: 'WARNING: MCP servers and tool descriptions are untrusted data. Verify arguments before approving.',
      };
    }

    // 6. DELETIONS OR UNRECOGNIZED ACTIONS
    if (toolName.includes('delete') || toolName.includes('remove')) {
      return {
        level: 'STRICT_APPROVAL_WITH_WARNING',
        needsApproval: true,
        isBlocked: false,
        reason: `Destructive tool '${toolName}' requires strict confirmation.`,
        warning: 'WARNING: File deletion is irreversible.',
      };
    }

    return {
      level: 'ASK_APPROVAL',
      needsApproval: true,
      isBlocked: false,
      reason: `Tool '${toolName}' requires approval.`,
    };
  }

  /**
   * Generates a tamper-proof cryptographic binding hash for the exact request action and payload
   */
  public static generateBindingHash(toolName: string, args: Record<string, any>): string {
    let raw = '';
    if (toolName === 'write_file') {
      const p = path.normalize(args.path || '');
      const c = typeof args.content === 'string' ? args.content : '';
      const cHash = crypto.createHash('sha256').update(c).digest('hex');
      raw = `write_file:${p}:${cHash}`;
    } else if (toolName === 'delete_file') {
      const p = path.normalize(args.path || '');
      raw = `delete_file:${p}:${Boolean(args.recursive)}`;
    } else if (toolName === 'run_command') {
      raw = `run_command:${(args.command || '').trim()}`;
    } else if (toolName === 'replace_file_content') {
      const p = path.normalize(args.path || '');
      const t = typeof args.targetContent === 'string' ? args.targetContent : '';
      const r = typeof args.replacementContent === 'string' ? args.replacementContent : '';
      const tHash = crypto.createHash('sha256').update(t).digest('hex');
      const rHash = crypto.createHash('sha256').update(r).digest('hex');
      raw = `replace_file_content:${p}:${tHash}:${rHash}`;
    } else if (toolName === 'run_skill_script') {
      raw = `run_skill_script:${args.skillId || ''}:${args.script || ''}:${JSON.stringify(args.args || [])}`;
    } else if (toolName === 'call_mcp_tool') {
      const sId = args?.serverId || '';
      const tName = args?.toolName || '';
      const aHash = crypto.createHash('sha256').update(JSON.stringify(args?.arguments || args?.args || {})).digest('hex');
      raw = `call_mcp_tool:${sId}:${tName}:${aHash}`;
    } else {
      raw = `${toolName}:${crypto.createHash('sha256').update(JSON.stringify(args || {})).digest('hex')}`;
    }
    return crypto.createHash('sha256').update(raw).digest('hex');
  }

  /**
   * Registers a pending approval and waits for user decision
   */
  public requestApproval(
    taskId: string,
    toolName: string,
    args: Record<string, any>,
    level: 'ASK_APPROVAL' | 'STRICT_APPROVAL_WITH_WARNING',
    reason: string,
    warning?: string
  ): {
    pendingId: string;
    promise: Promise<boolean>;
  } {
    const pendingId = `appr_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const bindingHash = AgentPermissionGuard.generateBindingHash(toolName, args);
    const now = Date.now();
    const pendingRequest: PendingApprovalRequest = {
      id: pendingId,
      taskId,
      toolName,
      args,
      bindingHash,
      level,
      reason,
      warning,
      createdAt: new Date(now).toISOString(),
      expiresAt: now + 5 * 60 * 1000, // 5 minutes TTL
      status: 'pending',
      consumed: false,
    };

    this.pendingApprovals.set(pendingId, pendingRequest);

    this.logSecurityEvent({
      action: 'APPROVAL_REQUESTED',
      toolName,
      details: `${level}: ${reason} (Binding: ${bindingHash.slice(0, 12)}..., Args: ${maskSecrets(JSON.stringify(args))})`,
      level,
      taskId,
    });

    const promise = new Promise<boolean>((resolve) => {
      this.approvalResolvers.set(pendingId, (approved: boolean) => {
        pendingRequest.status = approved ? 'approved' : 'denied';
        pendingRequest.resolvedAt = new Date().toISOString();
        this.logSecurityEvent({
          action: approved ? 'APPROVED' : 'DENIED',
          toolName,
          details: `User ${approved ? 'approved' : 'denied'} request ${pendingId}`,
          level,
          taskId,
          userOverride: true,
        });
        resolve(approved);
      });
    });

    return { pendingId, promise };
  }

  /**
   * Responds to a pending approval request
   */
  public resolveApproval(pendingId: string, approve: boolean, actor: string = 'user'): boolean {
    const req = this.pendingApprovals.get(pendingId);
    if (!req) return false;

    req.status = approve ? 'approved' : 'denied';
    req.resolvedAt = new Date().toISOString();
    req.resolvedBy = actor;

    this.logSecurityEvent({
      action: approve ? 'APPROVED' : 'DENIED',
      toolName: req.toolName,
      details: `User ${approve ? 'approved' : 'denied'} request ${pendingId} (Actor: ${actor})`,
      level: req.level,
      taskId: req.taskId,
      userOverride: true,
    });

    const resolver = this.approvalResolvers.get(pendingId);
    if (resolver) {
      this.approvalResolvers.delete(pendingId);
      resolver(approve);
    }

    return true;
  }

  public getPendingApprovals(): PendingApprovalRequest[] {
    const now = Date.now();
    return Array.from(this.pendingApprovals.values()).filter(
      (r) => r.status === 'pending' && now <= r.expiresAt
    );
  }

  public getApproval(id: string): PendingApprovalRequest | undefined {
    return this.pendingApprovals.get(id);
  }

  public setApprovalExpiryForTesting(id: string, expiresAt: number): boolean {
    const req = this.pendingApprovals.get(id);
    if (!req) return false;
    req.expiresAt = expiresAt;
    return true;
  }

  public isApproved(id: string): boolean {
    const req = this.pendingApprovals.get(id);
    if (!req) return false;
    if (req.status !== 'approved') return false;
    if (req.consumed) return false;
    if (Date.now() > req.expiresAt) return false;
    return true;
  }

  /**
   * Validates single-use, 5-minute TTL, and exact cryptographic request binding before consuming
   */
  public validateAndConsumeApproval(
    approvalId: string,
    toolName: string,
    args: Record<string, any>
  ): { valid: boolean; error?: string } {
    const req = this.pendingApprovals.get(approvalId);
    if (!req) {
      return { valid: false, error: `Approval request '${approvalId}' not found.` };
    }

    if (req.status === 'denied') {
      return { valid: false, error: `Approval request '${approvalId}' was denied.` };
    }

    if (req.status === 'pending') {
      return { valid: false, error: `Approval request '${approvalId}' is still pending approval.` };
    }

    if (req.consumed) {
      return {
        valid: false,
        error: `Approval request '${approvalId}' has already been consumed (single-use only).`,
      };
    }

    if (Date.now() > req.expiresAt) {
      return {
        valid: false,
        error: `Approval request '${approvalId}' has expired (5-minute TTL exceeded).`,
      };
    }

    // Verify cryptographic request binding
    const expectedBinding = AgentPermissionGuard.generateBindingHash(toolName, args);
    if (req.bindingHash !== expectedBinding) {
      return {
        valid: false,
        error: `Approval binding mismatch: Approval '${approvalId}' was granted for a different action or payload.`,
      };
    }

    // Mark as consumed (single-use)
    req.consumed = true;
    req.consumedAt = new Date().toISOString();

    this.logSecurityEvent({
      action: 'APPROVED',
      toolName,
      details: `Approval ${approvalId} consumed for tool=${toolName}`,
      level: req.level,
      taskId: req.taskId,
    });

    return { valid: true };
  }

  public createPendingApproval(
    taskId: string,
    toolName: string,
    args: Record<string, any>,
    level: 'ASK_APPROVAL' | 'STRICT_APPROVAL_WITH_WARNING',
    reason: string,
    warning?: string
  ): PendingApprovalRequest {
    const pendingId = `appr_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const bindingHash = AgentPermissionGuard.generateBindingHash(toolName, args);
    const now = Date.now();
    const pendingRequest: PendingApprovalRequest = {
      id: pendingId,
      taskId,
      toolName,
      args,
      bindingHash,
      level,
      reason,
      warning,
      createdAt: new Date(now).toISOString(),
      expiresAt: now + 5 * 60 * 1000, // 5 minutes TTL
      status: 'pending',
      consumed: false,
    };
    this.pendingApprovals.set(pendingId, pendingRequest);
    this.logSecurityEvent({
      action: 'APPROVAL_REQUESTED',
      toolName,
      details: `${level}: ${reason} (Binding: ${bindingHash.slice(0, 12)}..., Args: ${maskSecrets(JSON.stringify(args))})`,
      level,
      taskId,
    });
    return pendingRequest;
  }

  public logSecurityEvent(entry: Omit<SecurityAuditLogItem, 'id' | 'timestamp'>): void {
    const item: SecurityAuditLogItem = {
      id: `sec_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      timestamp: new Date().toISOString(),
      ...entry,
      details: maskSecrets(entry.details),
    };

    this.securityAuditLogs.push(item);
    if (this.securityAuditLogs.length > 500) {
      this.securityAuditLogs.shift();
    }

    // Append to file
    try {
      const line = `${item.timestamp} [${item.action}] [${item.level}] tool=${item.toolName} - ${item.details}\n`;
      fs.appendFileSync(SECURITY_LOG_FILE, line, 'utf8');
    } catch {}
  }

  public getSecurityLogs(): SecurityAuditLogItem[] {
    return [...this.securityAuditLogs];
  }
}

export const agentPermissionGuard = AgentPermissionGuard.getInstance();
