import { GoogleGenAI } from '@google/genai';
import fs from 'fs';
import path from 'path';

export interface AgentToolParamProperty {
  type: 'string' | 'number' | 'boolean' | 'array' | 'object';
  description: string;
  items?: { type: string };
  enum?: string[];
}

export interface AgentToolDeclaration {
  name: string;
  description: string;
  parameters: {
    type: 'object';
    properties: Record<string, AgentToolParamProperty>;
    required?: string[];
  };
}

export interface AgentToolCall {
  id: string;
  name: string;
  args: Record<string, any>;
}

export interface AgentMessage {
  role: 'system' | 'user' | 'assistant' | 'tool';
  content: string;
  toolCalls?: AgentToolCall[];
  toolCallId?: string;
  name?: string;
}

export interface ModelResponse {
  content: string;
  toolCalls?: AgentToolCall[];
  modelUsed: string;
  provider: string;
  usage?: {
    promptTokens?: number;
    completionTokens?: number;
  };
}

export interface ModelProviderConfig {
  provider: 'gemini' | 'anthropic' | 'openai' | 'mock';
  model?: string;
  apiKey?: string;
  temperature?: number;
  maxTokens?: number;
  customEndpoint?: string;
  mockResponses?: ModelResponse[];
}

export interface IModelProvider {
  readonly providerName: string;
  generate(
    messages: AgentMessage[],
    tools?: AgentToolDeclaration[]
  ): Promise<ModelResponse>;
}

/**
 * Resolves Gemini API Key from explicit config, process.env, or container process
 */
export function resolveGeminiApiKey(explicitKey?: string): string {
  if (explicitKey && explicitKey !== 'NO_API_KEY_CONFIGURED') return explicitKey;
  if (process.env.GEMINI_API_KEY) return process.env.GEMINI_API_KEY;

  // 1. Check /proc/self/environ
  try {
    const selfEnv = fs.readFileSync('/proc/self/environ', 'utf8');
    const m = selfEnv.match(/(?:^|\0)GEMINI_API_KEY=([^\0]+)/);
    if (m && m[1]) return m[1];
  } catch {}

  // 2. Scan /proc for running server process environment
  try {
    const entries = fs.readdirSync('/proc');
    for (const entry of entries) {
      if (/^\d+$/.test(entry)) {
        try {
          const envPath = path.join('/proc', entry, 'environ');
          const content = fs.readFileSync(envPath, 'utf8');
          const m = content.match(/(?:^|\0)GEMINI_API_KEY=([^\0]+)/);
          if (m && m[1]) {
            process.env.GEMINI_API_KEY = m[1];
            return m[1];
          }
        } catch {}
      }
    }
  } catch {}

  return 'NO_API_KEY_CONFIGURED';
}

/**
 * Gemini Provider: Integrates with @google/genai
 * Includes automatic model fallback chain for high-resilience execution
 */
export class GeminiAgentProvider implements IModelProvider {
  public readonly providerName = 'gemini';
  private client: GoogleGenAI;
  private primaryModel: string;
  private fallbackModels: string[];

  constructor(config?: { apiKey?: string; model?: string }) {
    const key = resolveGeminiApiKey(config?.apiKey);

    this.client = new GoogleGenAI({
      apiKey: key,
      httpOptions: {
        headers: { 'User-Agent': 'aistudio-build' },
      },
    });

    this.primaryModel = config?.model || 'gemini-3.5-flash-lite';
    // Fallback order based on verified availability tests
    this.fallbackModels = [
      'gemini-3.5-flash-lite',
      'gemini-3.1-flash-lite-preview',
      'gemini-3.8-flash',
    ].filter((m) => m !== this.primaryModel);
  }

  async generate(
    messages: AgentMessage[],
    tools?: AgentToolDeclaration[]
  ): Promise<ModelResponse> {
    const candidateModels = [this.primaryModel, ...this.fallbackModels];
    let lastError: any = null;

    // Format system instructions vs conversation contents
    const systemInstruction = messages
      .filter((m) => m.role === 'system')
      .map((m) => m.content)
      .join('\n\n');

    const conversationMessages = messages.filter((m) => m.role !== 'system');

    // Build tool definitions for Gemini function declarations
    const functionDeclarations = tools?.map((t) => ({
      name: t.name,
      description: t.description,
      parameters: t.parameters,
    }));

    // Build prompt text / parts
    const promptParts: string[] = [];
    for (const msg of conversationMessages) {
      if (msg.role === 'tool') {
        promptParts.push(`[TOOL RESULT for ${msg.name || 'tool'}]:\n${msg.content}`);
      } else if (msg.role === 'assistant') {
        promptParts.push(`Assistant:\n${msg.content}`);
      } else {
        promptParts.push(`User:\n${msg.content}`);
      }
    }

    const contents = promptParts.join('\n\n');

    for (const model of candidateModels) {
      try {
        const callConfig: any = {
          systemInstruction: systemInstruction || undefined,
        };

        if (functionDeclarations && functionDeclarations.length > 0) {
          callConfig.tools = [{ functionDeclarations }];
        }

        const response: any = await this.client.models.generateContent({
          model,
          contents,
          config: callConfig,
        });

        const textOutput = response.text || '';
        const toolCalls: AgentToolCall[] = [];

        // Check for function calls in response candidates or top-level SDK helper
        if (response.functionCalls && Array.isArray(response.functionCalls)) {
          for (const fc of response.functionCalls) {
            toolCalls.push({
              id: `call_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
              name: fc.name,
              args: fc.args || {},
            });
          }
        }

        const candidate = response.candidates?.[0];
        const parts = candidate?.content?.parts || [];
        for (const p of parts) {
          if (p.functionCall && !toolCalls.some((t) => t.name === p.functionCall.name)) {
            toolCalls.push({
              id: `call_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
              name: p.functionCall.name,
              args: p.functionCall.args || {},
            });
          }
        }

        // Also parse structured XML/JSON tool calls if model emitted them in text
        if (toolCalls.length === 0 && textOutput) {
          const parsedCalls = this.parseTextToolCalls(textOutput);
          if (parsedCalls.length > 0) {
            toolCalls.push(...parsedCalls);
          }
        }

        return {
          content: textOutput,
          toolCalls: toolCalls.length > 0 ? toolCalls : undefined,
          modelUsed: model,
          provider: 'gemini',
        };
      } catch (err: any) {
        lastError = err;
        console.warn(`[GEMINI_PROVIDER] Model ${model} failed: ${err?.message}. Trying fallback...`);
      }
    }

    throw new Error(
      `All Gemini model candidates failed. Last error: ${lastError?.message || 'Unknown error'}`
    );
  }

  private parseTextToolCalls(text: string): AgentToolCall[] {
    const calls: AgentToolCall[] = [];
    // Match <tool_call>{"name":"...","args":{...}}</tool_call>
    const toolCallRegex = /<tool_call>([\s\S]*?)<\/tool_call>/g;
    let match: RegExpExecArray | null;
    while ((match = toolCallRegex.exec(text)) !== null) {
      try {
        const parsed = JSON.parse(match[1].trim());
        if (parsed.name && typeof parsed.name === 'string') {
          calls.push({
            id: `call_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
            name: parsed.name,
            args: parsed.args || {},
          });
        }
      } catch {
        // invalid json inside tool call
      }
    }

    // Also match ```json\n{"action": "...", "tool": "..."}\n```
    if (calls.length === 0) {
      const jsonBlockRegex = /```json\s*(\{[\s\S]*?\})\s*```/g;
      let jsonMatch: RegExpExecArray | null;
      while ((jsonMatch = jsonBlockRegex.exec(text)) !== null) {
        try {
          const obj = JSON.parse(jsonMatch[1].trim());
          const name = obj.tool || obj.action || obj.tool_name || obj.name;
          if (name && typeof name === 'string' && (obj.parameters || obj.args || obj.arguments)) {
            calls.push({
              id: `call_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
              name,
              args: obj.parameters || obj.args || obj.arguments || {},
            });
          }
        } catch {
          // ignore
        }
      }
    }

    return calls;
  }
}

/**
 * Anthropic Claude Provider
 */
export class AnthropicAgentProvider implements IModelProvider {
  public readonly providerName = 'anthropic';
  private apiKey: string;
  private model: string;

  constructor(config?: { apiKey?: string; model?: string }) {
    this.apiKey = config?.apiKey || process.env.ANTHROPIC_API_KEY || '';
    this.model = config?.model || 'claude-3-5-sonnet-20241022';
  }

  async generate(
    messages: AgentMessage[],
    tools?: AgentToolDeclaration[]
  ): Promise<ModelResponse> {
    if (!this.apiKey) {
      throw new Error('Anthropic API key is missing. Configure it in Agent Settings.');
    }

    const systemMsg = messages.find((m) => m.role === 'system')?.content || '';
    const conversation = messages
      .filter((m) => m.role !== 'system')
      .map((m) => ({
        role: m.role === 'assistant' ? 'assistant' : 'user',
        content: m.role === 'tool' ? `[Tool result for ${m.name}]: ${m.content}` : m.content,
      }));

    const formattedTools = tools?.map((t) => ({
      name: t.name,
      description: t.description,
      input_schema: t.parameters,
    }));

    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'x-api-key': this.apiKey,
        'anthropic-version': '2023-06-01',
        'content-type': 'application/json',
      },
      body: JSON.stringify({
        model: this.model,
        max_tokens: 4096,
        system: systemMsg,
        messages: conversation,
        tools: formattedTools && formattedTools.length > 0 ? formattedTools : undefined,
      }),
    });

    if (!response.ok) {
      const errText = await response.text();
      throw new Error(`Anthropic API error (${response.status}): ${errText}`);
    }

    const data: any = await response.json();
    let textOutput = '';
    const toolCalls: AgentToolCall[] = [];

    for (const item of data.content || []) {
      if (item.type === 'text') {
        textOutput += item.text;
      } else if (item.type === 'tool_use') {
        toolCalls.push({
          id: item.id,
          name: item.name,
          args: item.input,
        });
      }
    }

    return {
      content: textOutput,
      toolCalls: toolCalls.length > 0 ? toolCalls : undefined,
      modelUsed: this.model,
      provider: 'anthropic',
    };
  }
}

/**
 * OpenAI / Custom Compatible Provider
 */
export class OpenAIAgentProvider implements IModelProvider {
  public readonly providerName = 'openai';
  private apiKey: string;
  private model: string;
  private endpoint: string;

  constructor(config?: { apiKey?: string; model?: string; customEndpoint?: string }) {
    this.apiKey = config?.apiKey || process.env.OPENAI_API_KEY || '';
    this.model = config?.model || 'gpt-4o';
    this.endpoint = config?.customEndpoint || 'https://api.openai.com/v1/chat/completions';
  }

  async generate(
    messages: AgentMessage[],
    tools?: AgentToolDeclaration[]
  ): Promise<ModelResponse> {
    if (!this.apiKey) {
      throw new Error('OpenAI API key is missing. Configure it in Agent Settings.');
    }

    const formattedMessages = messages.map((m) => ({
      role: m.role === 'tool' ? 'tool' : m.role,
      content: m.content,
      tool_call_id: m.toolCallId,
      name: m.name,
    }));

    const formattedTools = tools?.map((t) => ({
      type: 'function',
      function: {
        name: t.name,
        description: t.description,
        parameters: t.parameters,
      },
    }));

    const response = await fetch(this.endpoint, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${this.apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: this.model,
        messages: formattedMessages,
        tools: formattedTools && formattedTools.length > 0 ? formattedTools : undefined,
      }),
    });

    if (!response.ok) {
      const errText = await response.text();
      throw new Error(`OpenAI API error (${response.status}): ${errText}`);
    }

    const data: any = await response.json();
    const choice = data.choices?.[0];
    const message = choice?.message;

    const toolCalls: AgentToolCall[] = [];
    if (message?.tool_calls) {
      for (const tc of message.tool_calls) {
        let args = {};
        try {
          args = JSON.parse(tc.function.arguments);
        } catch {
          // parse error
        }
        toolCalls.push({
          id: tc.id,
          name: tc.function.name,
          args,
        });
      }
    }

    return {
      content: message?.content || '',
      toolCalls: toolCalls.length > 0 ? toolCalls : undefined,
      modelUsed: this.model,
      provider: 'openai',
    };
  }
}

/**
 * Mock Provider for deterministic agent loop testing
 */
export class MockAgentProvider implements IModelProvider {
  public readonly providerName = 'mock';
  private responses: ModelResponse[];
  private index = 0;

  constructor(responses: ModelResponse[] = []) {
    this.responses = responses;
  }

  async generate(messages: AgentMessage[], tools?: AgentToolDeclaration[]): Promise<ModelResponse> {
    if (this.index < this.responses.length) {
      return this.responses[this.index++];
    }
    return {
      content: 'Task completed successfully.',
      toolCalls: [],
      modelUsed: 'mock-model',
      provider: 'mock',
    };
  }
}

/**
 * Provider Factory
 */
export function createModelProvider(config?: ModelProviderConfig): IModelProvider {
  const provider = config?.provider || 'gemini';
  switch (provider) {
    case 'mock':
      return new MockAgentProvider(config?.mockResponses || []);
    case 'anthropic':
      return new AnthropicAgentProvider({ apiKey: config?.apiKey, model: config?.model });
    case 'openai':
      return new OpenAIAgentProvider({
        apiKey: config?.apiKey,
        model: config?.model,
        customEndpoint: config?.customEndpoint,
      });
    case 'gemini':
    default:
      return new GeminiAgentProvider({ apiKey: config?.apiKey, model: config?.model });
  }
}
