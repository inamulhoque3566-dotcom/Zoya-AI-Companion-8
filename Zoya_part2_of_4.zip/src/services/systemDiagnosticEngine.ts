import type { ExtractedFile } from '../types/zip';
import { getDecryptedSecretSync, PROTECTED_SECRET_KEYS, DEPRECATED_PURGED_SECRET_KEYS } from './secretVault';
import { agentClient } from './agent/agentClient';
import { voiceTelemetry } from './voiceTelemetry';
import { micStateMachine } from './speech/MicStateMachine';

export type DiagnosticStatus = 'pass' | 'warn' | 'fail' | 'testing';

export interface DiagnosticCheckItem {
  id: string;
  category: 'audio' | 'tts' | 'avatar' | 'gemini' | 'files';
  title: string;
  titleHi: string;
  status: DiagnosticStatus;
  message: string;
  details?: string;
  latencyMs?: number;
  remediation?: string;
}

export type ProblemSeverity = 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';

export interface DiagnosticProblemItem {
  id: string;
  severity: ProblemSeverity;
  category: 'security' | 'api_key' | 'runtime' | 'audio' | 'build' | 'network' | 'ui';
  file: string;
  line: string | number;
  title: string;
  whatIsWrong: string;
  exactFix: string;
  status: 'UNRESOLVED' | 'FIXED' | 'RESOLVED' | 'VERIFIED_SAFE' | 'PROTECTED';
}

export interface ApiKeySecurityCheck {
  id: string;
  name: string;
  status: 'PASS' | 'FAIL';
  details: string;
  remediation?: string;
}

export interface KeyConfigRecord {
  id: string;
  label: string;
  service: string;
  configured: boolean;
  source: 'server_env' | 'server_config' | 'encrypted_vault' | 'not_set';
  fileRef: string;
  storageSecurity: 'SERVER_PROXY' | 'ENCRYPTED_VAULT' | 'SERVER_ENV' | 'NOT_CONFIGURED';
}

export interface ApiKeySecurityReport {
  overallStatus: 'PASS' | 'FAIL';
  checks: ApiKeySecurityCheck[];
  detectedKeys: KeyConfigRecord[];
}

export interface DiagnosticSummary {
  totalProblems: number;
  unresolvedCount: number;
  criticalCount: number;
  highCount: number;
  mediumCount: number;
  lowCount: number;
  unresolvedCritical: number;
  unresolvedHigh: number;
  unresolvedMedium: number;
  unresolvedLow: number;
}

export interface SystemHealthReport {
  overallStatus: 'healthy' | 'warning' | 'degraded';
  score: number; // 0 to 100
  timestamp: string;
  totalChecks: number;
  passedChecks: number;
  warningChecks: number;
  failedChecks: number;
  checks: DiagnosticCheckItem[];
  micAudioLevel?: number;
  availableVoicesCount: number;
  geminiConfigured: boolean;
  missingFilesList: string[];
  summary: DiagnosticSummary;
  problems: DiagnosticProblemItem[];
  apiKeySecurity: ApiKeySecurityReport;
}

// Critical project architecture files to audit
export const CRITICAL_PROJECT_FILES = [
  // Types
  { path: 'src/types/zip.ts', label: 'OmniZip Extractor Engine Types' },
  { path: 'src/services/speech/SpeechTypes.ts', label: 'Speech Engine State & Hardware Types' },
  // Services
  { path: 'src/services/languageConfig.ts', label: '23 Indian Languages & Persona Config' },
  { path: 'src/services/speech/AudioTonePlayer.ts', label: 'Audio Tone & Cue Generator' },
  { path: 'src/services/toolApiKeysConfig.ts', label: 'Tool API Keys & Integrations Config' },
  { path: 'src/services/zoyaSkillsPart1.ts', label: 'Zoya Part 1 Skills Engine' },
  { path: 'src/services/zoyaSkillsPart2And4.ts', label: 'Zoya Part 2 & 4 Skills Engine' },
  { path: 'src/services/zoyaSkillsPart5And6.ts', label: 'Zoya Part 5 & 6 Skills Engine' },
  { path: 'src/services/zoyaSkillsPart7.ts', label: 'Zoya Part 7 Skills Engine' },
  // Components
  { path: 'src/components/ZoyaAvatarDisplay.tsx', label: 'Zoya Live Avatar Display Component' },
  { path: 'src/components/ZoyaSettingsModal.tsx', label: 'Zoya Mode & Voice Settings Modal' },
  { path: 'src/components/ZoyaMemoryModal.tsx', label: 'Zoya Persona Memory Modal' },
  { path: 'src/components/ZoyaHistoryModal.tsx', label: 'Zoya Action History Modal' },
  { path: 'src/components/DiagnosticDashboard.tsx', label: 'System Diagnostic Dashboard' },
  { path: 'src/components/actions/TextChatModal.tsx', label: 'Zoya Text & Skills Chat Modal' },
  // Assets
  { path: 'public/assets/images/zoya_new_avatar_transparent.png', label: 'Zoya 3D Living Avatar Model Sprite' },
];

/**
 * 1. Test Web Audio API & AudioContext capability
 */
export async function testWebAudioAPI(): Promise<DiagnosticCheckItem> {
  const t0 = performance.now();
  const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;

  if (!AudioCtx) {
    return {
      id: 'audio-context',
      category: 'audio',
      title: 'Web Audio API Support',
      titleHi: 'वेब ऑडियो एपीआई सपोर्ट',
      status: 'fail',
      message: 'Browser does not support Web Audio API.',
      remediation: 'Please use a modern browser (Chrome, Edge, Firefox, or Safari).',
    };
  }

  try {
    const ctx = new AudioCtx();
    if (ctx.state === 'suspended') {
      try {
        await ctx.resume();
      } catch {
        // Browsers without a user gesture keep AudioContext suspended until interaction
      }
    }
    const state = ctx.state;
    const latency = Math.round(performance.now() - t0);
    const sampleRate = ctx.sampleRate;
    const baseLatency = ctx.baseLatency;
    try {
      if (ctx.state !== 'closed') {
        await ctx.close();
      }
    } catch {
      // Ignore close errors on restricted autoplay contexts
    }

    return {
      id: 'audio-context',
      category: 'audio',
      title: 'Web Audio API Support',
      titleHi: 'वेब ऑडियो एपीआई सपोर्ट',
      status: 'pass',
      message: `AudioContext operational at ${sampleRate}Hz (State: ${state})`,
      details: `Sample Rate: ${sampleRate}Hz · Channels: 2 · Base Latency: ${baseLatency || 'N/A'}s`,
      latencyMs: latency,
    };
  } catch (err) {
    return {
      id: 'audio-context',
      category: 'audio',
      title: 'Web Audio API Support',
      titleHi: 'वेब ऑडियो एपीआई सपोर्ट',
      status: 'warn',
      message: `AudioContext initialized with restriction: ${(err as Error).message}`,
      remediation: 'Click anywhere on the screen to permit browser audio.',
    };
  }
}

/**
 * 2. Check Microphone permission & Audio Input devices
 */
export async function testMicrophoneDevices(): Promise<{ check: DiagnosticCheckItem; devices: MediaDeviceInfo[] }> {
  const t0 = performance.now();

  if (!navigator.mediaDevices || !navigator.mediaDevices.enumerateDevices) {
    return {
      check: {
        id: 'mic-device-support',
        category: 'audio',
        title: 'Microphone Hardware Support',
        titleHi: 'माइक हार्डवेयर व परमिशन',
        status: 'fail',
        message: 'MediaDevices API not supported in this browser environment.',
        remediation: 'Ensure you are browsing over HTTPS or localhost.',
      },
      devices: [],
    };
  }

  try {
    const allDevices = await navigator.mediaDevices.enumerateDevices();
    const audioInputs = allDevices.filter((d) => d.kind === 'audioinput');
    const latency = Math.round(performance.now() - t0);

    if (audioInputs.length === 0) {
      return {
        check: {
          id: 'mic-device-support',
          category: 'audio',
          title: 'Microphone Device Detection',
          titleHi: 'माइक डिवाइस खोज',
          status: 'warn',
          message: 'No physical microphone hardware detected or permission pending.',
          details: 'Zero audio input devices reported by browser.',
          remediation: 'Plug in a microphone or grant microphone permission in browser address bar.',
          latencyMs: latency,
        },
        devices: [],
      };
    }

    const hasLabel = audioInputs.some((d) => d.label.length > 0);

    return {
      check: {
        id: 'mic-device-support',
        category: 'audio',
        title: 'Microphone Device Detection',
        titleHi: 'माइक डिवाइस खोज',
        status: hasLabel ? 'pass' : 'warn',
        message: `${audioInputs.length} audio input device(s) detected.`,
        details: hasLabel
          ? `Primary: ${audioInputs[0].label || 'Default Microphone'}`
          : 'Permission not yet granted; device names masked until requested.',
        latencyMs: latency,
      },
      devices: audioInputs,
    };
  } catch (err) {
    return {
      check: {
        id: 'mic-device-support',
        category: 'audio',
        title: 'Microphone Device Detection',
        titleHi: 'माइक डिवाइस खोज',
        status: 'fail',
        message: `Failed to enumerate audio devices: ${(err as Error).message}`,
      },
      devices: [],
    };
  }
}

/**
 * 3. Test 3-Engine Neural TTS Architecture (Zero Robotic Browser Voice)
 * Engine 1 (Primary): ElevenLabs TTS (eleven_turbo_v2_5)
 * Engine 2 (Backup): Google Gemini Flash TTS (gemini-3.8-flash-lite-tts)
 * Engine 3 (Fallback): Google Gemini Live API (gemini-3.8-live, Voice: Kore)
 * Strict Directive: Zero Robotic Voice, Zero Browser SpeechSynthesis
 */
export async function testTTSPipeline(): Promise<{
  elevenLabsCheck: DiagnosticCheckItem;
  geminiFlashCheck: DiagnosticCheckItem;
  geminiLiveCheck: DiagnosticCheckItem;
  roboticPurgeCheck: DiagnosticCheckItem;
}> {
  const t0 = performance.now();

  let elevenConfigured = false;
  let elevenVoice = '';
  try {
    elevenVoice = (localStorage.getItem('zoya_elevenlabs_voice_id') || '').trim();
    const statusRes = await fetch('/api/elevenlabs/status', {
      method: 'GET',
      signal: AbortSignal.timeout(2500),
    });
    if (statusRes.ok) {
      const statusData = await statusRes.json().catch(() => ({}));
      elevenConfigured = Boolean(statusData?.configured);
      if (!elevenVoice && typeof statusData?.voiceId === 'string') {
        elevenVoice = statusData.voiceId;
      }
    }
  } catch {}

  let serverConfirmedRoboticBlock = false;

  // 1. PRIMARY: ElevenLabs TTS (exclusively via server proxy; never handles API key in browser)
  let elevenAvailable = false;
  let elevenQuotaExhausted = false;
  let elevenErrorMsg = '';
  let elevenLatency = 0;
  if (elevenConfigured) {
    try {
      const startT = performance.now();
      const res = await fetch('/api/tts', {
        method: 'POST',
        headers: agentClient.getOwnerFetchHeaders({ 'Content-Type': 'application/json' }),
        credentials: 'include',
        body: JSON.stringify({
          text: 'नमस्ते',
          forceEngine: 'elevenlabs',
          elevenLabsVoiceId: elevenVoice || undefined,
        }),
      });
      elevenLatency = Math.round(performance.now() - startT);
      const contentType = res.headers.get('content-type') || '';
      if (contentType.includes('application/json')) {
        const data = await res.json().catch(() => ({}));
        if (data?.roboticFallbackBlocked === true) serverConfirmedRoboticBlock = true;
        if (data?.audioData) {
          elevenAvailable = true;
        } else {
          elevenQuotaExhausted = Boolean(data?.quotaExhausted);
          elevenErrorMsg = data?.error || `HTTP ${res.status} without audio payload`;
        }
      } else {
        elevenErrorMsg = `HTTP ${res.status} non-JSON response`;
      }
    } catch (err: any) {
      elevenLatency = Math.round(performance.now() - t0);
      elevenErrorMsg = err?.message || 'Network error';
    }
  }

  const elevenLabsCheck: DiagnosticCheckItem = {
    id: 'tts-elevenlabs-primary',
    category: 'tts',
    title: 'Primary TTS: ElevenLabs TTS',
    titleHi: 'प्राथमिक टीटीएस: एलेवेनलैब्स (eleven_turbo_v2_5)',
    status: elevenAvailable
      ? 'pass'
      : elevenQuotaExhausted || elevenConfigured
      ? 'fail'
      : 'warn',
    message: elevenAvailable
      ? `ElevenLabs TTS is active via server proxy and generating natural speech (${elevenLatency}ms).`
      : elevenQuotaExhausted
      ? `ElevenLabs quota exhausted or rate-limited (${elevenLatency}ms): ${elevenErrorMsg}`
      : elevenConfigured
      ? `ElevenLabs API key is configured on server, but synthesis failed (${elevenLatency}ms): ${elevenErrorMsg}`
      : 'ElevenLabs API Key not configured on server. Zoya will automatically use Gemini Flash TTS backup.',
    details: `Model: eleven_turbo_v2_5 · Voice: ${elevenVoice || 'Rachel (Natural Female)'} · MP3 44.1kHz (Server Proxy)`,
    latencyMs: elevenLatency,
    remediation: elevenConfigured
      ? elevenAvailable
        ? undefined
        : 'Check ElevenLabs API quota, voice ID validity, or server connectivity.'
      : 'Enter ElevenLabs API Key in Settings > Voice Settings to store it on the server proxy.',
  };

  // 2. BACKUP: Google Gemini Flash TTS
  let geminiFlashAvailable = false;
  let geminiFlashQuotaExhausted = false;
  let geminiFlashError = '';
  let geminiFlashLatency = 0;
  try {
    const startT = performance.now();
    const res = await fetch('/api/tts', {
      method: 'POST',
      headers: agentClient.getOwnerFetchHeaders({ 'Content-Type': 'application/json' }),
      credentials: 'include',
      body: JSON.stringify({
        text: 'नमस्ते',
        forceEngine: 'gemini-flash',
      }),
    });
    geminiFlashLatency = Math.round(performance.now() - startT);
    const contentType = res.headers.get('content-type') || '';
    if (contentType.includes('application/json')) {
      const data = await res.json().catch(() => ({}));
      if (data?.roboticFallbackBlocked === true) serverConfirmedRoboticBlock = true;
      if (data?.audioData) {
        geminiFlashAvailable = true;
      } else if (data?.quotaExhausted) {
        geminiFlashQuotaExhausted = true;
        geminiFlashError = `Quota exhausted (${data.retryAfter || 45}s cooldown)`;
      } else {
        geminiFlashError = data?.error || `HTTP ${res.status} without audio payload`;
      }
    } else {
      geminiFlashError = `HTTP ${res.status} non-JSON response`;
    }
  } catch (err: any) {
    geminiFlashLatency = Math.round(performance.now() - t0);
    geminiFlashError = err?.message || 'Network error';
  }

  const geminiFlashCheck: DiagnosticCheckItem = {
    id: 'tts-gemini-flash-backup',
    category: 'tts',
    title: 'Backup TTS: Google Gemini Flash TTS',
    titleHi: 'बैकअप टीटीएस: गूगल जेमिनी फ्लैश (gemini-3.8-flash-lite-tts)',
    status: geminiFlashAvailable ? 'pass' : 'fail',
    message: geminiFlashAvailable
      ? `Google Gemini Flash TTS generated real 24kHz HD WAV audio (${geminiFlashLatency}ms).`
      : geminiFlashQuotaExhausted
      ? `Google Gemini Flash TTS FAILED: ${geminiFlashError}.`
      : `Google Gemini Flash TTS FAILED: ${geminiFlashError || 'No audio returned'}.`,
    details: 'Model: gemini-3.8-flash-lite-tts · Prebuilt Voice: Kore · Format: audio/wav (24kHz HD)',
    latencyMs: geminiFlashLatency,
    remediation: geminiFlashAvailable ? undefined : 'Verify GEMINI_API_KEY and Gemini TTS quota/rate limits.',
  };

  // 3. Final Fallback: Google Gemini Live API
  let geminiLiveAvailable = false;
  let geminiLiveQuotaExhausted = false;
  let geminiLiveError = '';
  let geminiLiveLatency = 0;
  try {
    const startT = performance.now();
    const res = await fetch('/api/tts', {
      method: 'POST',
      headers: agentClient.getOwnerFetchHeaders({ 'Content-Type': 'application/json' }),
      credentials: 'include',
      body: JSON.stringify({
        text: 'नमस्ते',
        forceEngine: 'gemini-live',
      }),
    });
    geminiLiveLatency = Math.round(performance.now() - startT);
    const contentType = res.headers.get('content-type') || '';
    if (contentType.includes('application/json')) {
      const data = await res.json().catch(() => ({}));
      if (data?.roboticFallbackBlocked === true) serverConfirmedRoboticBlock = true;
      if (data?.audioData) {
        geminiLiveAvailable = true;
      } else if (data?.quotaExhausted) {
        geminiLiveQuotaExhausted = true;
        geminiLiveError = `Quota exhausted (${data.retryAfter || 45}s cooldown)`;
      } else {
        geminiLiveError = data?.error || `HTTP ${res.status} without audio payload`;
      }
    } else {
      geminiLiveError = `HTTP ${res.status} non-JSON response`;
    }
  } catch (err: any) {
    geminiLiveLatency = Math.round(performance.now() - t0);
    geminiLiveError = err?.message || 'Network error';
  }

  const geminiLiveCheck: DiagnosticCheckItem = {
    id: 'tts-gemini-live-backup',
    category: 'tts',
    title: 'Final Fallback: Google Gemini Live API',
    titleHi: 'अंतिम बैकअप: गूगल जेमिनी लाइव एपीआई (gemini-3.8-live / flash-lite-tts)',
    status: geminiLiveAvailable ? 'pass' : 'fail',
    message: geminiLiveAvailable
      ? `Google Gemini Live / Neural TTS generated real 24kHz HD audio (${geminiLiveLatency}ms).`
      : geminiLiveQuotaExhausted
      ? `Google Gemini Live API FAILED: ${geminiLiveError}.`
      : `Google Gemini Live API FAILED: ${geminiLiveError || 'No audio returned'}.`,
    details: 'Model: gemini-3.8-live / gemini-3.8-flash-lite-tts · Prebuilt Voice: Kore · Format: audio/wav',
    latencyMs: geminiLiveLatency,
    remediation: geminiLiveAvailable ? undefined : 'Verify GEMINI_API_KEY and Live WebSocket reachability.',
  };

  // 4. Strict Zero Robotic Voice Policy Verification (verified from live server telemetry)
  const roboticPurgeCheck: DiagnosticCheckItem = {
    id: 'tts-robotic-voice-eliminated',
    category: 'tts',
    title: 'Zero Robotic Voice Policy Enforcement',
    titleHi: 'रोबोटिक व सिस्टम वॉइस पूर्ण निष्कासन व ब्लॉकिंग',
    status: serverConfirmedRoboticBlock ? 'pass' : 'warn',
    message: serverConfirmedRoboticBlock
      ? 'Verified from live /api/tts telemetry: roboticFallbackBlocked === true and browser speechSynthesis is not used.'
      : 'Could not verify roboticFallbackBlocked flag from /api/tts response.',
    details: 'Policy: Strict Natural Neural Voices Only · Retry backup Gemini engines instead of browser speechSynthesis',
  };

  return { elevenLabsCheck, geminiFlashCheck, geminiLiveCheck, roboticPurgeCheck };
}

/**
 * 4. Test Avatar Graphics & Rendering (WebGL / Canvas)
 */
export async function testAvatarSubsystem(files: ExtractedFile[]): Promise<{
  webglCheck: DiagnosticCheckItem;
  assetsCheck: DiagnosticCheckItem;
}> {
  const t0 = performance.now();

  // Test WebGL
  let webglSupported = false;
  let rendererInfo = 'Standard Canvas 2D';
  try {
    const canvas = document.createElement('canvas');
    const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
    if (gl) {
      webglSupported = true;
      const debugInfo = (gl as WebGLRenderingContext).getExtension('WEBGL_debug_renderer_info');
      if (debugInfo) {
        rendererInfo = (gl as WebGLRenderingContext).getParameter(debugInfo.UNMASKED_RENDERER_WEBGL) || 'Hardware Accelerated';
      }
    }
  } catch {
    webglSupported = false;
  }

  const webglCheck: DiagnosticCheckItem = {
    id: 'avatar-webgl',
    category: 'avatar',
    title: 'Avatar 3D & WebGL Graphics Acceleration',
    titleHi: 'अवतार 3D व वेब-जीएल एक्सेलेरेशन',
    status: webglSupported ? 'pass' : 'warn',
    message: webglSupported ? 'Hardware WebGL 3D acceleration verified.' : 'Fallback 2D canvas rendering enabled.',
    details: `Renderer: ${rendererInfo}`,
    latencyMs: Math.round(performance.now() - t0),
  };

  // Check avatar sprite/image assets in loaded files or public folder
  const avatarImages = files.filter(
    (f) => f.path.includes('zoya_new_avatar') || f.isImage
  );

  const assetsCheck: DiagnosticCheckItem = {
    id: 'avatar-assets',
    category: 'avatar',
    title: 'Avatar Visual Sprites & 3D Assets',
    titleHi: 'अवतार विजुअल स्प्राइट्स व एसेट्स',
    status: avatarImages.length > 0 ? 'pass' : 'warn',
    message: avatarImages.length > 0
      ? `${avatarImages.length} avatar graphic asset(s) loaded and verified in memory.`
      : 'Default SVG / CSS procedural avatar renderer active.',
    details: avatarImages.map((a) => a.name).join(', ') || 'No avatar images found in archive.',
  };

  return { webglCheck, assetsCheck };
}

/**
 * 5. Test Gemini API Environment & Readiness
 */
export async function testGeminiAPIIntegration(): Promise<DiagnosticCheckItem> {
  const t0 = performance.now();
  const hasClientKey = Boolean(import.meta.env.VITE_GEMINI_API_KEY);

  let serverProxyOk = false;
  let healthStatusCode = 0;
  let healthError = '';
  try {
    const res = await fetch('/api/health', { method: 'GET', signal: AbortSignal.timeout(2500) });
    healthStatusCode = res.status;
    if (res.ok) {
      const payload = await res.json().catch(() => null);
      serverProxyOk = Boolean(payload && payload.status === 'ok');
      if (!serverProxyOk) {
        healthError = 'GET /api/health returned unexpected payload';
      }
    } else {
      healthError = `GET /api/health returned HTTP ${res.status}`;
    }
  } catch (err: any) {
    serverProxyOk = false;
    healthError = err?.message || 'GET /api/health request failed';
  }

  const latency = Math.round(performance.now() - t0);

  if (!serverProxyOk) {
    return {
      id: 'gemini-api',
      category: 'gemini',
      title: 'Gemini AI API Engine',
      titleHi: 'जेमिनी एआई एपीआई इंजन',
      status: 'fail',
      message: `Backend /api/health probe FAILED (${healthError || `HTTP ${healthStatusCode || 'NETWORK_ERROR'}`}).`,
      details: hasClientKey ? 'Client env key set, but backend API proxy is unreachable.' : 'Backend API proxy unreachable.',
      latencyMs: latency,
      remediation: 'Verify server.ts is running and /api/health responds with HTTP 200.',
    };
  }

  return {
    id: 'gemini-api',
    category: 'gemini',
    title: 'Gemini AI API Engine',
    titleHi: 'जेमिनी एआई एपीआई इंजन',
    status: 'pass',
    message: 'Backend /api/health responded OK and Gemini server proxy is reachable.',
    details: hasClientKey ? 'Server proxy + client env active' : 'Server proxy active (/api/chat, /api/chat-stream)',
    latencyMs: latency,
  };
}

/**
 * 6. Audit Critical Project Files (0 Missing Files Guarantee)
 */
export function auditCriticalFiles(files: ExtractedFile[]): {
  check: DiagnosticCheckItem;
  missingFiles: string[];
  foundFilesCount: number;
} {
  if (files.length === 0) {
    return {
      check: {
        id: 'files-audit',
        category: 'files',
        title: 'Project Files & Architecture Audit',
        titleHi: 'प्रोजेक्ट फाइल्स व आर्किटेक्चर ऑडिट',
        status: 'warn',
        message: 'No ZIP archive loaded yet. Please upload a ZIP to verify file presence.',
      },
      missingFiles: [],
      foundFilesCount: 0,
    };
  }

  const filePathsSet = new Set(files.map((f) => f.path.replace(/^\//, '')));
  const missingFiles: string[] = [];
  let foundCount = 0;

  for (const item of CRITICAL_PROJECT_FILES) {
    const cleanPath = item.path.replace(/^\//, '');
    const found = filePathsSet.has(cleanPath) || files.some((f) => f.path.endsWith(cleanPath));
    if (found) {
      foundCount++;
    } else {
      missingFiles.push(`${item.path} (${item.label})`);
    }
  }

  const total = CRITICAL_PROJECT_FILES.length;
  const isAllPresent = missingFiles.length === 0;

  return {
    check: {
      id: 'files-audit',
      category: 'files',
      title: 'Project Modules & File Integrity',
      titleHi: 'प्रोजेक्ट मॉड्यूल व फाइल्स सत्यता',
      status: isAllPresent ? 'pass' : missingFiles.length <= 2 ? 'warn' : 'fail',
      message: isAllPresent
        ? `All ${foundCount}/${total} critical files and modules verified in archive.`
        : `${foundCount}/${total} critical files found. ${missingFiles.length} file(s) missing.`,
      details: isAllPresent ? 'Zero missing files' : `Missing: ${missingFiles.slice(0, 3).join(', ')}`,
      remediation: isAllPresent ? undefined : 'Check if all folders were included in the ZIP archive.',
    },
    missingFiles,
    foundFilesCount: foundCount,
  };
}

export const MASTER_AUDIT_PROBLEMS: DiagnosticProblemItem[] = [
  {
    id: 'SEC-01',
    severity: 'CRITICAL',
    category: 'security',
    file: 'src/services/agent/agentAuth.ts & server.ts',
    line: 'agentAuth.ts:707 & server.ts:4014,4152',
    title: 'Unified Agent Auth, Proxy-Aware Loopback Guard & Single-Use Pairing',
    whatIsWrong: 'Duplicate auth middleware, X-Forwarded-For loopback spoofing behind reverse proxies, static pairing code fallback, and unauthenticated/passphrase-based rate-limit reset could expose /api/agent/* RPC endpoints.',
    exactFix: 'Unified into single agentAuth middleware; disabled loopback trust when X-Forwarded-For is present; enforced 128-bit single-use 5-minute pairing codes deleted on consumption; added 5/15min per-IP backoff + setup-code-only reset on reset-limit; enforced 0o700/0o600 permissions.',
    status: 'FIXED',
  },
  {
    id: 'SEC-02',
    severity: 'CRITICAL',
    category: 'security',
    file: 'android/app/src/main/java/.../BankingSafetyConfig.kt',
    line: '15-160',
    title: 'Fail-Closed Accessibility Allowlist Policy',
    whatIsWrong: 'Regex blocklist with broad patterns (.*cred.*, .*upi.*) risked both false-positive blocks and fail-open gaps on unlisted financial apps.',
    exactFix: 'Switched to fail-closed allowlist (ALLOWED_AUTOMATION_PACKAGES) blocking all non-allowlisted packages while maintaining exact known banking/UPI package names.',
    status: 'FIXED',
  },
  {
    id: 'SEC-03',
    severity: 'HIGH',
    category: 'api_key',
    file: 'src/services/serverYouTubeService.ts',
    line: '91-620',
    title: 'YouTube Data API Key Header Isolation & Clean HTTP Error Handling',
    whatIsWrong: 'API key in URL parameters or missing finally clearTimeout / response.ok / 403 / 429 checks could leak or hang requests.',
    exactFix: 'Enforced X-Goog-Api-Key header, finally { clearTimeout(timer) } cleanup, response.ok checks before JSON parsing, and explicit 403/429 error reporting.',
    status: 'FIXED',
  },
  {
    id: 'SEC-04',
    severity: 'HIGH',
    category: 'api_key',
    file: 'server.ts & src/components/ZoyaSettingsModal.tsx',
    line: 'server.ts:1702,2278 & ZoyaSettingsModal.tsx:716',
    title: 'Server-Side ElevenLabs Proxy (Zero Browser Key Storage)',
    whatIsWrong: 'ElevenLabs API keys were previously handled or stored in the browser client and sent in TTS payloads.',
    exactFix: 'Moved ElevenLabs config and API calls behind server proxy routes (/api/elevenlabs/status, /api/elevenlabs/config, /api/elevenlabs/test-connection, /api/tts) with 0o600 server storage.',
    status: 'FIXED',
  },
  {
    id: 'SEC-05',
    severity: 'HIGH',
    category: 'api_key',
    file: '.gitignore & src/services/serverYouTubeService.ts',
    line: '.gitignore:7-9, serverYouTubeService.ts:75',
    title: 'Plaintext API Key Saved to Un-gitignored File (data/youtube_config.json)',
    whatIsWrong: 'When a user entered a YouTube Data API key in Settings, the server wrote it to data/youtube_config.json. The .gitignore file omitted data/*_config.json.',
    exactFix: 'Added data/*_config.json, data/youtube_config.json, data/auth_token.json, and data/user_secret.json to .gitignore. Restricted file creation permission to mode: 0o600.',
    status: 'FIXED',
  },
  {
    id: 'SEC-06',
    severity: 'HIGH',
    category: 'security',
    file: 'src/services/agent/secretMasker.ts',
    line: '20-48',
    title: 'Context-Based ElevenLabs Redaction (No Broad 32-Hex False Positives)',
    whatIsWrong: 'Generic /\\b[0-9a-f]{32}\\b/ regex redacted every UUID and MD5 hash in logs alongside ElevenLabs keys.',
    exactFix: 'Replaced generic 32-hex regex with context-based sk_[0-9a-f]{32,} and (xi-api-key["\\s:=]+)[0-9a-f]{32,} patterns while keeping OpenAI, Anthropic, and GitHub patterns.',
    status: 'FIXED',
  },
  {
    id: 'BUG-07',
    severity: 'MEDIUM',
    category: 'network',
    file: 'server.ts',
    line: '2310-2375',
    title: 'ElevenLabs Connection Test Error Reporting & Timeout Cleanup',
    whatIsWrong: '/api/elevenlabs/test-connection risked leaking timeout timers or missing voice lookup warnings.',
    exactFix: 'Wrapped fetch timeout cleanup in finally blocks and added explicit voice ID verification warnings.',
    status: 'FIXED',
  },
  {
    id: 'BUG-08',
    severity: 'MEDIUM',
    category: 'network',
    file: 'src/services/serverYouTubeService.ts',
    line: '98, 407, 523, 602',
    title: 'YouTube API Requests Timeout & Clean Abort Cleanup',
    whatIsWrong: 'Direct fetch() calls to external Google APIs needed deterministic timeout and abort timer cleanup.',
    exactFix: 'Attached AbortController with 7000ms timeout and finally { clearTimeout(timer) } on all YouTube Data API calls.',
    status: 'FIXED',
  },
  {
    id: 'PERF-09',
    severity: 'MEDIUM',
    category: 'audio',
    file: 'src/services/systemDiagnosticEngine.ts & src/main.tsx',
    line: '109-155',
    title: 'Scoped Web Audio Context Resume & Cleanup Without Global Prototype Override',
    whatIsWrong: 'Global AudioContext.prototype.close override masked real errors across the app; mobile WebKit/Safari suspended contexts need scoped handling.',
    exactFix: 'Removed global AudioContext.close() override from main.tsx and handled resume()/close() cleanly inside try/catch in testWebAudioAPI.',
    status: 'FIXED',
  },
  {
    id: 'UI-10',
    severity: 'LOW',
    category: 'ui',
    file: 'src/components/DiagnosticDashboard.tsx',
    line: '555',
    title: 'Diagnostic Dashboard Filter Tabs Responsive Scrolling',
    whatIsWrong: 'Filter category buttons wrapped awkwardly across multiple lines on narrow mobile screens (<360px).',
    exactFix: 'Wrapped the category selector in a smooth horizontal scroll container (flex overflow-x-auto no-scrollbar gap-1.5 py-1).',
    status: 'FIXED',
  },
];

export async function auditApiKeySecurity(): Promise<ApiKeySecurityReport> {
  const checks: ApiKeySecurityCheck[] = [];

  // 1. Live probe: /api/agent/status without token MUST return 401
  let agentNoTokenStatus = 0;
  try {
    const res = await fetch('/api/agent/status', {
      method: 'GET',
      signal: AbortSignal.timeout(3000),
    });
    agentNoTokenStatus = res.status;
  } catch {
    agentNoTokenStatus = 0;
  }
  checks.push({
    id: 'check-agent-no-token-401',
    name: '1. Agent Endpoint Rejects Missing Token (401)',
    status: agentNoTokenStatus === 401 ? 'PASS' : 'FAIL',
    details:
      agentNoTokenStatus === 401
        ? 'Live probe GET /api/agent/status without token returned HTTP 401.'
        : `Live probe GET /api/agent/status returned HTTP ${agentNoTokenStatus || 'NETWORK_ERROR'} (expected 401).`,
    remediation: agentNoTokenStatus === 401 ? undefined : 'Ensure agentAuth middleware is active on /api/agent/*.',
  });

  // 2. Live probe: /api/agent/status with empty Bearer MUST return 401
  let agentEmptyBearerStatus = 0;
  try {
    const res = await fetch('/api/agent/status', {
      method: 'GET',
      headers: { Authorization: 'Bearer ' },
      signal: AbortSignal.timeout(3000),
    });
    agentEmptyBearerStatus = res.status;
  } catch {
    agentEmptyBearerStatus = 0;
  }
  checks.push({
    id: 'check-agent-empty-bearer-401',
    name: '2. Agent Endpoint Rejects Empty Bearer (401)',
    status: agentEmptyBearerStatus === 401 ? 'PASS' : 'FAIL',
    details:
      agentEmptyBearerStatus === 401
        ? 'Live probe GET /api/agent/status with "Bearer " returned HTTP 401.'
        : `Live probe returned HTTP ${agentEmptyBearerStatus || 'NETWORK_ERROR'} (expected 401).`,
  });

  // 3. Live probe: /api/agent/auth/owner/reset-limit without auth MUST return 401
  let resetLimitNoAuthStatus = 0;
  try {
    const res = await fetch('/api/agent/auth/owner/reset-limit', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: '{}',
      signal: AbortSignal.timeout(3000),
    });
    resetLimitNoAuthStatus = res.status;
  } catch {
    resetLimitNoAuthStatus = 0;
  }
  checks.push({
    id: 'check-reset-limit-401',
    name: '3. Rate-Limit Reset Endpoint Protected (401)',
    status: resetLimitNoAuthStatus === 401 ? 'PASS' : 'FAIL',
    details:
      resetLimitNoAuthStatus === 401
        ? 'Live probe POST /api/agent/auth/owner/reset-limit without auth returned HTTP 401.'
        : `Live probe returned HTTP ${resetLimitNoAuthStatus || 'NETWORK_ERROR'} (expected 401).`,
  });

  // 4. Live browser check: zero plaintext/deprecated secrets in localStorage
  const leakedKeys: string[] = [];
  const rawSecretValuePattern = /(AIza[0-9A-Za-z-_]{20,}|sk-[A-Za-z0-9_-]{20,}|sk_[0-9a-fA-F]{24,}|ghp_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}|zoya_agent_sec_[A-Za-z0-9_]{12,})/;
  try {
    if (typeof localStorage !== 'undefined') {
      for (const k of [...PROTECTED_SECRET_KEYS, ...DEPRECATED_PURGED_SECRET_KEYS]) {
        if (localStorage.getItem(k) !== null) {
          leakedKeys.push(k);
        }
      }
      for (let i = 0; i < localStorage.length; i++) {
        const storageKey = localStorage.key(i);
        if (!storageKey) continue;
        const val = localStorage.getItem(storageKey) || '';
        if (rawSecretValuePattern.test(val) && !leakedKeys.includes(storageKey)) {
          leakedKeys.push(storageKey);
        }
      }
    }
  } catch {
    // ignore
  }
  checks.push({
    id: 'check-frontend-storage',
    name: '4. Zero Plaintext/Deprecated Secrets in Browser localStorage',
    status: leakedKeys.length === 0 ? 'PASS' : 'FAIL',
    details:
      leakedKeys.length === 0
        ? `Live scan checked ${PROTECTED_SECRET_KEYS.length + DEPRECATED_PURGED_SECRET_KEYS.length} secret slots and all localStorage entries: 0 secrets exposed.`
        : `Detected unpurged secret key(s) in localStorage: ${leakedKeys.join(', ')}`,
  });

  // 5. Live probe: ElevenLabs proxy status endpoint never echoes API key
  let elevenConfigured = false;
  let elevenSource: 'server_env' | 'server_config' | 'not_set' = 'not_set';
  let elevenProxySafe = false;
  try {
    const res = await fetch('/api/elevenlabs/status', {
      method: 'GET',
      signal: AbortSignal.timeout(3000),
    });
    if (res.ok) {
      const data = await res.json().catch(() => null);
      if (data && typeof data.configured === 'boolean' && !('apiKey' in data) && !('key' in data)) {
        elevenProxySafe = true;
        elevenConfigured = data.configured;
        elevenSource = data.source === 'env' ? 'server_env' : data.source === 'server_config' ? 'server_config' : 'not_set';
      }
    }
  } catch {
    elevenProxySafe = false;
  }
  checks.push({
    id: 'check-elevenlabs-server-proxy',
    name: '5. ElevenLabs Server Proxy Isolation',
    status: elevenProxySafe ? 'PASS' : 'FAIL',
    details: elevenProxySafe
      ? `GET /api/elevenlabs/status verified: key isolated server-side (Configured: ${elevenConfigured ? 'Yes' : 'No'}).`
      : 'Live probe GET /api/elevenlabs/status failed or returned unexpected payload.',
  });

  // 6. Live probe: TTS & ElevenLabs mutation/synthesis endpoints require auth (401 without token/session)
  let ttsDiagNoAuthStatus = 0;
  let elevenCfgNoAuthStatus = 0;
  try {
    const [diagNoAuthRes, cfgNoAuthRes] = await Promise.all([
      fetch('/api/tts/diagnostics', { method: 'GET', signal: AbortSignal.timeout(3000) }),
      fetch('/api/elevenlabs/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: '{}',
        signal: AbortSignal.timeout(3000),
      }),
    ]);
    ttsDiagNoAuthStatus = diagNoAuthRes.status;
    elevenCfgNoAuthStatus = cfgNoAuthRes.status;
  } catch {}

  let geminiConfigured = false;
  let ttsPolicyVerified = false;
  if (agentClient.hasOwnerOrAgentAuth()) {
    try {
      const res = await fetch('/api/tts/diagnostics', {
        method: 'GET',
        headers: agentClient.getOwnerFetchHeaders(),
        credentials: 'include',
        signal: AbortSignal.timeout(3000),
      });
      if (res.ok) {
        const data = await res.json().catch(() => null);
        geminiConfigured = Boolean(data?.env?.hasGeminiKey);
        ttsPolicyVerified = Boolean(data?.policy?.roboticSpeechSynthesisBlocked);
      }
    } catch {}
  }

  let youtubeConfigured = false;
  let youtubeSource: 'server_env' | 'server_config' | 'not_set' = 'not_set';
  try {
    const res = await fetch('/api/youtube/status', {
      method: 'GET',
      signal: AbortSignal.timeout(3000),
    });
    if (res.ok) {
      const data = await res.json().catch(() => null);
      youtubeConfigured = Boolean(data?.configured);
      youtubeSource = data?.keySource === 'environment' ? 'server_env' : data?.keySource === 'stored_config' ? 'server_config' : 'not_set';
    }
  } catch {}

  const ttsRoutesLockedDown = ttsDiagNoAuthStatus === 401 && elevenCfgNoAuthStatus === 401;
  checks.push({
    id: 'check-tts-routes-auth',
    name: '6. TTS & ElevenLabs Proxy Routes Require Auth (401)',
    status: ttsRoutesLockedDown ? 'PASS' : 'FAIL',
    details: ttsRoutesLockedDown
      ? ttsPolicyVerified
        ? 'Unauthenticated GET /api/tts/diagnostics & POST /api/elevenlabs/config returned HTTP 401; authenticated telemetry confirmed roboticSpeechSynthesisBlocked === true.'
        : 'Unauthenticated GET /api/tts/diagnostics & POST /api/elevenlabs/config returned HTTP 401.'
      : `Expected HTTP 401 without auth (got diagnostics=${ttsDiagNoAuthStatus || 'ERR'}, config=${elevenCfgNoAuthStatus || 'ERR'}).`,
  });

  const hasComposio = Boolean(getDecryptedSecretSync('zoya_tool_key_composio'));
  const hasGitHubPat = Boolean(getDecryptedSecretSync('zoya_tool_key_github_pat'));

  const detectedKeys: KeyConfigRecord[] = [
    {
      id: 'gemini-server-key',
      label: 'Google Gemini API Key',
      service: 'Google AI Studio / GenAI SDK',
      configured: geminiConfigured,
      source: geminiConfigured ? 'server_env' : 'not_set',
      fileRef: 'server.ts & .env.example',
      storageSecurity: geminiConfigured ? 'SERVER_ENV' : 'NOT_CONFIGURED',
    },
    {
      id: 'elevenlabs-voice-key',
      label: 'ElevenLabs Neural TTS Key',
      service: 'ElevenLabs Speech API (Server Proxy)',
      configured: elevenConfigured,
      source: elevenConfigured ? elevenSource : 'not_set',
      fileRef: 'server.ts (/api/elevenlabs/*)',
      storageSecurity: elevenConfigured ? 'SERVER_PROXY' : 'NOT_CONFIGURED',
    },
    {
      id: 'youtube-data-key',
      label: 'YouTube Data API v3 Key',
      service: 'Google Cloud Platform (YouTube API)',
      configured: youtubeConfigured,
      source: youtubeConfigured ? youtubeSource : 'not_set',
      fileRef: 'src/services/serverYouTubeService.ts',
      storageSecurity: youtubeConfigured ? 'SERVER_PROXY' : 'NOT_CONFIGURED',
    },
    {
      id: 'agent-auth-token',
      label: 'Zoya Agent Auth Bearer Token',
      service: 'Zoya Coding Agent Subsystem',
      configured: agentNoTokenStatus === 401,
      source: agentNoTokenStatus === 401 ? 'server_config' : 'not_set',
      fileRef: 'src/services/agent/agentAuth.ts',
      storageSecurity: agentNoTokenStatus === 401 ? 'SERVER_ENV' : 'NOT_CONFIGURED',
    },
    {
      id: 'composio-tool-key',
      label: 'Composio Tool Router Key',
      service: 'Composio Workspace Integration',
      configured: hasComposio,
      source: hasComposio ? 'encrypted_vault' : 'not_set',
      fileRef: 'src/services/toolApiKeysConfig.ts',
      storageSecurity: hasComposio ? 'ENCRYPTED_VAULT' : 'NOT_CONFIGURED',
    },
    {
      id: 'github-pat-key',
      label: 'GitHub Personal Access Token',
      service: 'GitHub Changelog & Commit Sync',
      configured: hasGitHubPat,
      source: hasGitHubPat ? 'encrypted_vault' : 'not_set',
      fileRef: 'src/services/toolApiKeysConfig.ts',
      storageSecurity: hasGitHubPat ? 'ENCRYPTED_VAULT' : 'NOT_CONFIGURED',
    },
  ];

  return {
    overallStatus: checks.every((c) => c.status === 'PASS') ? 'PASS' : 'FAIL',
    checks,
    detectedKeys,
  };
}

/**
 * Master Diagnostic Runner
 * Runs all diagnostics sequentially, compiles health score, and prints structured report to console.
 */
export async function runFullSystemDiagnostics(files: ExtractedFile[]): Promise<SystemHealthReport> {
  const checks: DiagnosticCheckItem[] = [];

  // 1. Audio
  const audioCheck = await testWebAudioAPI();
  checks.push(audioCheck);

  const { check: micCheck, devices } = await testMicrophoneDevices();
  checks.push(micCheck);

  // 2. 3-Engine Neural TTS Architecture (ElevenLabs Primary, Gemini Flash Backup, Gemini Live Fallback)
  const { elevenLabsCheck, geminiFlashCheck, geminiLiveCheck, roboticPurgeCheck } = await testTTSPipeline();
  checks.push(elevenLabsCheck);
  checks.push(geminiFlashCheck);
  checks.push(geminiLiveCheck);
  checks.push(roboticPurgeCheck);

  // 3. Avatar
  const { webglCheck, assetsCheck } = await testAvatarSubsystem(files);
  checks.push(webglCheck);
  checks.push(assetsCheck);

  // 4. Gemini
  const geminiCheck = await testGeminiAPIIntegration();
  checks.push(geminiCheck);

  // 5. Files Audit
  const { check: filesCheck, missingFiles } = auditCriticalFiles(files);
  checks.push(filesCheck);

  // API Key Security & Problems Summary (real runtime checks — zero fake greens)
  const apiKeySecurity = await auditApiKeySecurity();
  const liveProblems: DiagnosticProblemItem[] = [];

  for (const chk of checks) {
    if (chk.status === 'fail' || chk.status === 'warn') {
      const severity: ProblemSeverity =
        chk.status === 'fail'
          ? chk.category === 'gemini' || chk.category === 'audio'
            ? 'CRITICAL'
            : 'HIGH'
          : 'MEDIUM';
      liveProblems.push({
        id: `LIVE-${chk.id.toUpperCase()}`,
        severity,
        category: chk.category === 'audio' || chk.category === 'tts' ? 'audio' : chk.category === 'gemini' ? 'network' : 'runtime',
        file: chk.category === 'gemini' ? 'server.ts (/api/health, /api/chat-stream)' : 'src/services/systemDiagnosticEngine.ts',
        line: 'live-check',
        title: `${chk.title} (${chk.status.toUpperCase()})`,
        whatIsWrong: chk.message,
        exactFix: chk.remediation || chk.details || 'Inspect live endpoint and browser permissions.',
        status: 'UNRESOLVED',
      });
    }
  }

  for (const sec of apiKeySecurity.checks) {
    if (sec.status === 'FAIL') {
      liveProblems.push({
        id: `SEC-LIVE-${sec.id.toUpperCase()}`,
        severity: 'CRITICAL',
        category: 'security',
        file: 'server.ts & src/services/agent/agentAuth.ts',
        line: 'runtime-probe',
        title: `${sec.name} FAILED`,
        whatIsWrong: sec.details,
        exactFix: sec.remediation || 'Verify auth middleware on /api/agent/* and /api/elevenlabs/* routes.',
        status: 'UNRESOLVED',
      });
    }
  }

  const telemetrySnap = voiceTelemetry.getSnapshot();
  for (const stage of Object.values(telemetrySnap)) {
    if (stage.health === 'fail') {
      liveProblems.push({
        id: `VOICE-${stage.id.toUpperCase()}`,
        severity: stage.id === 'mic' || stage.id === 'recording' ? 'CRITICAL' : 'HIGH',
        category: 'audio',
        file: 'src/services/voiceTelemetry.ts',
        line: stage.id,
        title: `Voice Pipeline Stage Failed: ${stage.label} (${stage.stateText})`,
        whatIsWrong: stage.error || stage.detail,
        exactFix: 'Verify microphone permissions, live STT recognition, and Gemini/TTS network connectivity.',
        status: 'UNRESOLVED',
      });
    }
  }

  const micSnap = micStateMachine.getSnapshot();
  if (micSnap.permissionState === 'denied') {
    liveProblems.push({
      id: 'MIC-PERMISSION-DENIED',
      severity: 'CRITICAL',
      category: 'audio',
      file: 'src/services/speech/MicStateMachine.ts',
      line: 'permissions',
      title: 'Microphone Permission Denied',
      whatIsWrong: 'navigator.permissions reports microphone permission is denied.',
      exactFix: 'Allow microphone access in browser site settings or Android app permissions.',
      status: 'UNRESOLVED',
    });
  }

  const problems: DiagnosticProblemItem[] = [...liveProblems, ...MASTER_AUDIT_PROBLEMS];

  const isUnresolved = (p: DiagnosticProblemItem) => p.status === 'UNRESOLVED';
  const criticalCount = problems.filter((p) => p.severity === 'CRITICAL').length;
  const highCount = problems.filter((p) => p.severity === 'HIGH').length;
  const mediumCount = problems.filter((p) => p.severity === 'MEDIUM').length;
  const lowCount = problems.filter((p) => p.severity === 'LOW').length;

  const unresolvedCritical = problems.filter((p) => isUnresolved(p) && p.severity === 'CRITICAL').length;
  const unresolvedHigh = problems.filter((p) => isUnresolved(p) && p.severity === 'HIGH').length;
  const unresolvedMedium = problems.filter((p) => isUnresolved(p) && p.severity === 'MEDIUM').length;
  const unresolvedLow = problems.filter((p) => isUnresolved(p) && p.severity === 'LOW').length;
  const unresolvedCount = unresolvedCritical + unresolvedHigh + unresolvedMedium + unresolvedLow;

  const summary: DiagnosticSummary = {
    totalProblems: problems.length,
    unresolvedCount,
    criticalCount,
    highCount,
    mediumCount,
    lowCount,
    unresolvedCritical,
    unresolvedHigh,
    unresolvedMedium,
    unresolvedLow,
  };

  // Compute Overall Score honestly from real check outcomes
  const total = checks.length;
  const passed = checks.filter((c) => c.status === 'pass').length;
  const warnings = checks.filter((c) => c.status === 'warn').length;
  const failed = checks.filter((c) => c.status === 'fail').length;

  const score = total > 0 ? Math.round(((passed * 1 + warnings * 0.5) / total) * 100) : 0;
  const overallStatus: 'healthy' | 'warning' | 'degraded' =
    failed > 0 || unresolvedCritical > 0 ? 'degraded' : warnings > 0 || unresolvedCount > 0 ? 'warning' : 'healthy';

  const report: SystemHealthReport = {
    overallStatus,
    score,
    timestamp: new Date().toLocaleTimeString('hi-IN', { hour12: true }),
    totalChecks: total,
    passedChecks: passed,
    warningChecks: warnings,
    failedChecks: failed,
    checks,
    availableVoicesCount: 3, // 3-Tier Neural TTS (ElevenLabs, Gemini Flash, Gemini Live)
    geminiConfigured: geminiCheck.status === 'pass',
    missingFilesList: missingFiles,
    summary,
    problems,
    apiKeySecurity,
  };

  // Log clean, scannable report to browser DevTools Console
  console.group('%c[OmniZip & Zoya System Diagnostic Report]', 'color: #38bdf8; font-weight: bold; font-size: 13px;');
  console.log(`Overall Health Score: ${score}% (${overallStatus.toUpperCase()}) | Unresolved: ${unresolvedCount}`);
  console.log(`Summary: Total: ${summary.totalProblems} | Unresolved: ${summary.unresolvedCount} (C:${unresolvedCritical} H:${unresolvedHigh} M:${unresolvedMedium} L:${unresolvedLow})`);
  console.log(`Timestamp: ${report.timestamp} · Total Checks: ${total} | Passed: ${passed} | Warnings: ${warnings} | Failed: ${failed}`);
  console.table(
    problems.map((p) => ({
      Severity: p.severity,
      File: `${p.file}:${p.line}`,
      Title: p.title,
      Status: p.status,
    }))
  );
  console.groupEnd();

  return report;
}
