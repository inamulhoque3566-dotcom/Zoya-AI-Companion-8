import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import * as SkeletonUtils from 'three/examples/jsm/utils/SkeletonUtils.js';

export interface ModelBoneMap {
  root?: THREE.Bone;
  hips?: THREE.Bone;
  leftShoulder?: THREE.Bone;
  leftArm?: THREE.Bone;
  leftForeArm?: THREE.Bone;
  leftHand?: THREE.Bone;
  rightShoulder?: THREE.Bone;
  rightArm?: THREE.Bone;
  rightForeArm?: THREE.Bone;
  rightHand?: THREE.Bone;
}

export interface MorphTargetBinding {
  mesh: THREE.Mesh;
  index: number;
  name: string;
}

export interface AvatarDiagnosticInfo {
  avatarName: string;
  isCustomLoaded: boolean;
  totalBonesFound: number;
  mappedBones: string[];
  missingBones: string[];
  totalMorphTargetsFound: number;
  mappedMorphTargets: string[];
  warnings: string[];
  isProceduralFallback: boolean;
}

export type CameraFramingMode = 'full' | 'upper' | 'face';

/**
 * Robust regex patterns to match standard Mixamo, Ready Player Me, VRM,
 * Blender Rigify, and custom humanoid bone naming conventions.
 */
const BONE_PATTERNS = {
  hips: /^(hips|pelvis|root|mixamorig[:_]?hips|bip01[:_]?pelvis|cc_base_hip)$/i,
  leftShoulder: /(left.*(shoulder|clavicle)|mixamorig[:_]?leftshoulder|clavicle_l|shoulder\.l)/i,
  leftArm: /(left.*(upperarm|arm)|mixamorig[:_]?leftarm|upperarm_l|arm\.l)/i,
  leftForeArm: /(left.*(forearm|lowerarm)|mixamorig[:_]?leftforearm|lowerarm_l|forearm\.l)/i,
  leftHand: /(left.*hand|mixamorig[:_]?lefthand|hand_l|hand\.l)/i,
  rightShoulder: /(right.*(shoulder|clavicle)|mixamorig[:_]?rightshoulder|clavicle_r|shoulder\.r)/i,
  rightArm: /(right.*(upperarm|arm)|mixamorig[:_]?rightarm|upperarm_r|arm\.r)/i,
  rightForeArm: /(right.*(forearm|lowerarm)|mixamorig[:_]?rightforearm|lowerarm_r|forearm\.r)/i,
  rightHand: /(right.*hand|mixamorig[:_]?righthand|hand_r|hand\.r)/i,
};

const BLINK_PATTERNS = /(eyeblinkleft|eyeblinkright|blink|eyesclosed|blink_l|blink_r|fcl_eyeblink_l|fcl_eyeblink_r|eye_closed)/i;
const MOUTH_PATTERNS = /(mouthopen|jawopen|viseme_aa|v_aa|mouth_open|jaw_open|moutha|fcl_mth_a|vrc\.v_aa)/i;

/**
 * Disposes a Three.js material cleanly, freeing texture GPU memory
 */
function disposeMaterial(mat: THREE.Material) {
  const m = mat as any;
  for (const key of Object.keys(m)) {
    const val = m[key];
    if (val && typeof val === 'object' && val.isTexture) {
      val.dispose();
    }
  }
  mat.dispose();
}

/**
 * Creates a beautiful, fully-rigged 3D humanoid skinned mesh
 * used as a reliable fallback when a GLB file path is not yet present on disk.
 */
export function createProceduralHumanoidAvatar(avatarName: string, colorHex: string): THREE.Group {
  const rootGroup = new THREE.Group();
  rootGroup.name = `ProceduralRigged_${avatarName.replace(/\s+/g, '_')}`;

  const bodyHeight = 1.72;
  const hipY = 0.92;
  const waistY = 1.08;
  const chestY = 1.28;
  const neckY = 1.44;
  const headY = 1.58;
  const shoulderY = 1.38;
  const shoulderW = 0.36;

  // 1. Build standard humanoid bone hierarchy
  const hips = new THREE.Bone();
  hips.name = 'mixamorigHips';
  hips.position.set(0, hipY, 0);
  rootGroup.add(hips);

  const spine = new THREE.Bone();
  spine.name = 'mixamorigSpine';
  spine.position.set(0, waistY - hipY, 0);
  hips.add(spine);

  const chest = new THREE.Bone();
  chest.name = 'mixamorigChest';
  chest.position.set(0, chestY - waistY, 0);
  spine.add(chest);

  const neck = new THREE.Bone();
  neck.name = 'mixamorigNeck';
  neck.position.set(0, neckY - chestY, 0);
  chest.add(neck);

  const head = new THREE.Bone();
  head.name = 'mixamorigHead';
  head.position.set(0, headY - neckY, 0);
  neck.add(head);

  // Left Arm Chain
  const leftShoulder = new THREE.Bone();
  leftShoulder.name = 'mixamorigLeftShoulder';
  leftShoulder.position.set(-shoulderW * 0.45, shoulderY - chestY, 0);
  chest.add(leftShoulder);

  const leftArm = new THREE.Bone();
  leftArm.name = 'mixamorigLeftArm';
  leftArm.position.set(-shoulderW * 0.55, -0.04, 0);
  leftShoulder.add(leftArm);

  const leftForeArm = new THREE.Bone();
  leftForeArm.name = 'mixamorigLeftForeArm';
  leftForeArm.position.set(0, -0.28, 0);
  leftArm.add(leftForeArm);

  const leftHand = new THREE.Bone();
  leftHand.name = 'mixamorigLeftHand';
  leftHand.position.set(0, -0.24, 0);
  leftForeArm.add(leftHand);

  // Right Arm Chain
  const rightShoulder = new THREE.Bone();
  rightShoulder.name = 'mixamorigRightShoulder';
  rightShoulder.position.set(shoulderW * 0.45, shoulderY - chestY, 0);
  chest.add(rightShoulder);

  const rightArm = new THREE.Bone();
  rightArm.name = 'mixamorigRightArm';
  rightArm.position.set(shoulderW * 0.55, -0.04, 0);
  rightShoulder.add(rightArm);

  const rightForeArm = new THREE.Bone();
  rightForeArm.name = 'mixamorigRightForeArm';
  rightForeArm.position.set(0, -0.28, 0);
  rightArm.add(rightForeArm);

  const rightHand = new THREE.Bone();
  rightHand.name = 'mixamorigRightHand';
  rightHand.position.set(0, -0.24, 0);
  rightForeArm.add(rightHand);

  // Legs Chain
  const leftThigh = new THREE.Bone();
  leftThigh.name = 'mixamorigLeftUpLeg';
  leftThigh.position.set(-0.11, 0, 0);
  hips.add(leftThigh);

  const leftLeg = new THREE.Bone();
  leftLeg.name = 'mixamorigLeftLeg';
  leftLeg.position.set(0, -0.46, 0);
  leftThigh.add(leftLeg);

  const leftFoot = new THREE.Bone();
  leftFoot.name = 'mixamorigLeftFoot';
  leftFoot.position.set(0, -0.44, 0.04);
  leftLeg.add(leftFoot);

  const rightThigh = new THREE.Bone();
  rightThigh.name = 'mixamorigRightUpLeg';
  rightThigh.position.set(0.11, 0, 0);
  hips.add(rightThigh);

  const rightLeg = new THREE.Bone();
  rightLeg.name = 'mixamorigRightLeg';
  rightLeg.position.set(0, -0.46, 0);
  rightThigh.add(rightLeg);

  const rightFoot = new THREE.Bone();
  rightFoot.name = 'mixamorigRightFoot';
  rightFoot.position.set(0, -0.44, 0.04);
  rightLeg.add(rightFoot);

  // Pre-position arms naturally beside the torso (not stuck in strict 90deg T-pose)
  leftArm.rotation.z = THREE.MathUtils.degToRad(-68);
  leftArm.rotation.x = THREE.MathUtils.degToRad(8);
  leftForeArm.rotation.x = THREE.MathUtils.degToRad(-18);

  rightArm.rotation.z = THREE.MathUtils.degToRad(68);
  rightArm.rotation.x = THREE.MathUtils.degToRad(8);
  rightForeArm.rotation.x = THREE.MathUtils.degToRad(-18);

  // 2. High-grade materials with color accents
  const primaryColor = new THREE.Color(colorHex);
  const skinMaterial = new THREE.MeshStandardMaterial({
    color: 0xffdfd0,
    roughness: 0.55,
    metalness: 0.05,
  });

  const outfitMaterial = new THREE.MeshStandardMaterial({
    color: primaryColor,
    roughness: 0.42,
    metalness: 0.12,
  });

  const darkMaterial = new THREE.MeshStandardMaterial({
    color: 0x1e2029,
    roughness: 0.65,
    metalness: 0.08,
  });

  const hairMaterial = new THREE.MeshStandardMaterial({
    color: 0x241d1a,
    roughness: 0.48,
    metalness: 0.05,
  });

  // Torso Mesh attached to spine
  const torsoGeo = new THREE.CylinderGeometry(0.16, 0.13, 0.38, 20);
  const torsoMesh = new THREE.Mesh(torsoGeo, outfitMaterial);
  torsoMesh.position.set(0, 0.12, 0);
  torsoMesh.castShadow = true;
  spine.add(torsoMesh);

  // Pelvis / Hips Mesh attached to hips
  const hipsGeo = new THREE.CylinderGeometry(0.13, 0.15, 0.18, 18);
  const hipsMesh = new THREE.Mesh(hipsGeo, darkMaterial);
  hipsMesh.position.set(0, 0, 0);
  hipsMesh.castShadow = true;
  hips.add(hipsMesh);

  // Head Mesh attached to head bone
  const headGeo = new THREE.SphereGeometry(0.11, 24, 24);
  headGeo.scale(1.0, 1.18, 1.05);

  // Add Eyelid and Mouth Morph Targets to Head
  const morphPositionClosed = headGeo.attributes.position.clone();
  for (let i = 0; i < morphPositionClosed.count; i++) {
    const y = morphPositionClosed.getY(i);
    const z = morphPositionClosed.getZ(i);
    // Displace vertices near eyes downward to simulate blink closure
    if (y > 0.01 && y < 0.06 && z > 0.07) {
      morphPositionClosed.setY(i, y - 0.038);
    }
  }

  const morphPositionMouth = headGeo.attributes.position.clone();
  for (let i = 0; i < morphPositionMouth.count; i++) {
    const y = morphPositionMouth.getY(i);
    const z = morphPositionMouth.getZ(i);
    // Displace vertices near jaw/mouth downward to simulate open mouth
    if (y < -0.01 && y > -0.07 && z > 0.05) {
      morphPositionMouth.setY(i, y - 0.035);
    }
  }

  headGeo.morphAttributes.position = [morphPositionClosed, morphPositionMouth];
  const headMesh = new THREE.Mesh(headGeo, skinMaterial);
  headMesh.name = 'AvatarHeadMesh';
  headMesh.morphTargetDictionary = {
    eyeBlinkLeft: 0,
    eyeBlinkRight: 0,
    blink: 0,
    eyesClosed: 0,
    mouthOpen: 1,
    jawOpen: 1,
    mouth_open: 1,
  };
  headMesh.morphTargetInfluences = [0, 0];
  headMesh.position.set(0, 0.04, 0);
  headMesh.castShadow = true;
  head.add(headMesh);

  // Stylized Hair
  const hairGeo = new THREE.SphereGeometry(0.12, 20, 20);
  hairGeo.scale(1.06, 1.12, 1.14);
  const hairMesh = new THREE.Mesh(hairGeo, hairMaterial);
  hairMesh.position.set(0, 0.06, -0.01);
  head.add(hairMesh);

  // Cute eye badges on face
  const eyeMat = new THREE.MeshBasicMaterial({ color: 0x111827 });
  const eyeL = new THREE.Mesh(new THREE.CircleGeometry(0.018, 16), eyeMat);
  eyeL.position.set(-0.045, 0.032, 0.112);
  head.add(eyeL);

  const eyeR = new THREE.Mesh(new THREE.CircleGeometry(0.018, 16), eyeMat);
  eyeR.position.set(0.045, 0.032, 0.112);
  head.add(eyeR);

  // Arm Segments
  const upperArmGeo = new THREE.CylinderGeometry(0.042, 0.038, 0.26, 14);
  upperArmGeo.translate(0, -0.13, 0);

  const leftUpperArmMesh = new THREE.Mesh(upperArmGeo, outfitMaterial);
  leftArm.add(leftUpperArmMesh);

  const rightUpperArmMesh = new THREE.Mesh(upperArmGeo, outfitMaterial);
  rightArm.add(rightUpperArmMesh);

  const foreArmGeo = new THREE.CylinderGeometry(0.036, 0.030, 0.23, 14);
  foreArmGeo.translate(0, -0.115, 0);

  const leftForeArmMesh = new THREE.Mesh(foreArmGeo, skinMaterial);
  leftForeArm.add(leftForeArmMesh);

  const rightForeArmMesh = new THREE.Mesh(foreArmGeo, skinMaterial);
  rightForeArm.add(rightForeArmMesh);

  const handGeo = new THREE.BoxGeometry(0.045, 0.075, 0.024);
  handGeo.translate(0, -0.04, 0);

  const leftHandMesh = new THREE.Mesh(handGeo, skinMaterial);
  leftHand.add(leftHandMesh);

  const rightHandMesh = new THREE.Mesh(handGeo, skinMaterial);
  rightHand.add(rightHandMesh);

  // Legs Segments
  const thighGeo = new THREE.CylinderGeometry(0.058, 0.048, 0.44, 16);
  thighGeo.translate(0, -0.22, 0);

  const leftThighMesh = new THREE.Mesh(thighGeo, darkMaterial);
  leftThigh.add(leftThighMesh);

  const rightThighMesh = new THREE.Mesh(thighGeo, darkMaterial);
  rightThigh.add(rightThighMesh);

  const shinGeo = new THREE.CylinderGeometry(0.046, 0.038, 0.42, 16);
  shinGeo.translate(0, -0.21, 0);

  const leftShinMesh = new THREE.Mesh(shinGeo, skinMaterial);
  leftLeg.add(leftShinMesh);

  const rightShinMesh = new THREE.Mesh(shinGeo, skinMaterial);
  rightLeg.add(rightShinMesh);

  const footGeo = new THREE.BoxGeometry(0.08, 0.045, 0.16);
  footGeo.translate(0, -0.02, 0.04);

  const leftFootMesh = new THREE.Mesh(footGeo, darkMaterial);
  leftFoot.add(leftFootMesh);

  const rightFootMesh = new THREE.Mesh(footGeo, darkMaterial);
  rightFoot.add(rightFootMesh);

  return rootGroup;
}

/**
 * Main WebGL Avatar Engine
 */
export class RiggedAvatarEngine {
  container: HTMLElement;
  canvas: HTMLCanvasElement;
  scene: THREE.Scene;
  camera: THREE.PerspectiveCamera;
  renderer: THREE.WebGLRenderer;

  // Scene lighting
  ambientLight: THREE.AmbientLight;
  keyLight: THREE.DirectionalLight;
  fillLight: THREE.DirectionalLight;
  rimLight: THREE.DirectionalLight;
  groundShadow: THREE.Mesh;

  // Current active avatar
  currentAvatarGroup: THREE.Group | null = null;
  gltfLoader: GLTFLoader;

  // Bone mapping
  bones: ModelBoneMap = {};
  initialRestQuaternions: Map<THREE.Bone, THREE.Quaternion> = new Map();
  initialHipsPosition = new THREE.Vector3();
  initialHipsQuaternion = new THREE.Quaternion();

  // Morph targets for blinking and audio-synchronized lip-sync
  morphBindings: MorphTargetBinding[] = [];
  mouthBindings: MorphTargetBinding[] = [];
  isSpeaking: boolean = false;
  audioLevel: number = 0;
  mouthValue: number = 0;

  // Animation clock and timer
  clock = new THREE.Clock();
  animId: number = 0;
  isPaused: boolean = false;
  framingMode: CameraFramingMode = 'upper';

  // Blinking State (fast close ~45ms, brief hold, slower open ~80ms, random interval 2-5s)
  blinkState = {
    isBlinking: false,
    blinkStartTime: 0,
    blinkDuration: 0.15, // 120ms - 180ms
    nextBlinkTime: 2.5,
    isDoubleBlink: false,
    value: 0,
  };

  // Diagnostic Log Callback
  onDiagnosticsUpdate?: (info: AvatarDiagnosticInfo) => void;
  onLoadingStateChange?: (loading: boolean, text: string) => void;

  constructor(container: HTMLElement, canvas: HTMLCanvasElement) {
    this.container = container;
    this.canvas = canvas;

    // 1. Scene
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x131620); // Neutral dark studio vignette

    // 2. Camera: Framed upright, facing avatar directly
    this.camera = new THREE.PerspectiveCamera(36, 1, 0.1, 50);
    this.camera.position.set(0, 1.30, 2.35); // Upper body framing default
    this.camera.lookAt(0, 1.25, 0);

    // 3. Renderer with Strict autoClear = true (eliminates ghosting/trails)
    this.renderer = new THREE.WebGLRenderer({
      canvas: this.canvas,
      antialias: true,
      alpha: false,
      powerPreference: 'high-performance',
      preserveDrawingBuffer: false,
    });
    this.renderer.autoClear = true; // STRICT RULE: Clear every frame, no ghosting
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    // 4. Soft 3-Point Studio Lighting
    this.ambientLight = new THREE.AmbientLight(0xffffff, 1.25);
    this.scene.add(this.ambientLight);

    // Key Light (warm high-contrast key)
    this.keyLight = new THREE.DirectionalLight(0xfff6ea, 1.75);
    this.keyLight.position.set(1.8, 2.6, 2.8);
    this.keyLight.castShadow = true;
    this.scene.add(this.keyLight);

    // Fill Light (cool soft fill from opposite side)
    this.fillLight = new THREE.DirectionalLight(0xa5c4ff, 0.85);
    this.fillLight.position.set(-2.0, 1.6, 2.2);
    this.scene.add(this.fillLight);

    // Rim Light (backlight for contour separation against neutral background)
    this.rimLight = new THREE.DirectionalLight(0xffffff, 1.1);
    this.rimLight.position.set(0, 2.8, -2.5);
    this.scene.add(this.rimLight);

    // Subtle Ground Shadow (clean studio contact shadow, no overlapping meshes)
    const shadowGeo = new THREE.PlaneGeometry(1.6, 1.2);
    const canvasTex = document.createElement('canvas');
    canvasTex.width = 256;
    canvasTex.height = 256;
    const ctx = canvasTex.getContext('2d')!;
    const grad = ctx.createRadialGradient(128, 128, 0, 128, 128, 120);
    grad.addColorStop(0, 'rgba(0,0,0,0.48)');
    grad.addColorStop(0.6, 'rgba(0,0,0,0.18)');
    grad.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 256, 256);
    const shadowMap = new THREE.CanvasTexture(canvasTex);

    const shadowMat = new THREE.MeshBasicMaterial({
      map: shadowMap,
      transparent: true,
      depthWrite: false,
    });
    this.groundShadow = new THREE.Mesh(shadowGeo, shadowMat);
    this.groundShadow.rotation.x = -Math.PI / 2;
    this.groundShadow.position.set(0, 0.002, 0);
    this.scene.add(this.groundShadow);

    this.gltfLoader = new GLTFLoader();

    this.updateSize();
    this.startAnimationLoop();
  }

  updateSize() {
    const w = this.container.clientWidth || 400;
    const h = this.container.clientHeight || 600;
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h, false);
  }

  setFramingMode(mode: CameraFramingMode) {
    this.framingMode = mode;
    if (mode === 'face') {
      this.camera.position.set(0, 1.54, 0.85);
      this.camera.lookAt(0, 1.52, 0);
    } else if (mode === 'upper') {
      this.camera.position.set(0, 1.30, 2.20);
      this.camera.lookAt(0, 1.22, 0);
    } else {
      // Full Body
      this.camera.position.set(0, 0.95, 3.40);
      this.camera.lookAt(0, 0.88, 0);
    }
  }

  /**
   * STRICT DISPOSAL:
   * Completely disposes previous avatar geometries, materials, textures,
   * bone controllers, and removes it from the scene so no duplicates or ghosts ever exist.
   */
  disposeCurrentAvatar() {
    if (!this.currentAvatarGroup) return;

    this.currentAvatarGroup.traverse((node) => {
      if ((node as THREE.Mesh).isMesh) {
        const mesh = node as THREE.Mesh;
        if (mesh.geometry) {
          mesh.geometry.dispose();
        }
        if (Array.isArray(mesh.material)) {
          mesh.material.forEach((m) => disposeMaterial(m));
        } else if (mesh.material) {
          disposeMaterial(mesh.material);
        }
      }
    });

    this.scene.remove(this.currentAvatarGroup);
    this.currentAvatarGroup = null;
    this.bones = {};
    this.initialRestQuaternions.clear();
    this.morphBindings = [];
  }

  /**
   * Searches and discovers bones matching standard patterns
   */
  private discoverBones(root: THREE.Object3D): { bones: ModelBoneMap; allFound: string[]; missing: string[] } {
    const bones: ModelBoneMap = {};
    const allBonesInModel: THREE.Bone[] = [];

    root.traverse((child) => {
      if ((child as THREE.Bone).isBone) {
        allBonesInModel.push(child as THREE.Bone);
      }
    });

    const mappedNames: string[] = [];
    const missingNames: string[] = [];

    // Search for each required pattern
    for (const [key, pattern] of Object.entries(BONE_PATTERNS) as [keyof ModelBoneMap, RegExp][]) {
      const match = allBonesInModel.find((b) => pattern.test(b.name));
      if (match) {
        bones[key] = match;
        mappedNames.push(`${key} -> "${match.name}"`);
      } else {
        missingNames.push(key);
        console.warn(`[AvatarEngine] Warning: Bone "${key}" not found in model using pattern ${pattern}`);
      }
    }

    return { bones, allFound: mappedNames, missing: missingNames };
  }

  /**
   * Discovers eyelid blink and audio lip-sync morph targets across all meshes
   */
  private discoverMorphTargets(root: THREE.Object3D): {
    bindings: MorphTargetBinding[];
    mouthBindings: MorphTargetBinding[];
    names: string[];
  } {
    const bindings: MorphTargetBinding[] = [];
    const mouthBindings: MorphTargetBinding[] = [];
    const names: string[] = [];

    root.traverse((child) => {
      if ((child as THREE.Mesh).isMesh) {
        const mesh = child as THREE.Mesh;
        if (mesh.morphTargetDictionary && mesh.morphTargetInfluences) {
          for (const [name, index] of Object.entries(mesh.morphTargetDictionary)) {
            if (BLINK_PATTERNS.test(name)) {
              bindings.push({ mesh, index, name });
              names.push(`${mesh.name || 'Mesh'}.${name} (Blink)`);
            }
            if (MOUTH_PATTERNS.test(name)) {
              mouthBindings.push({ mesh, index, name });
              names.push(`${mesh.name || 'Mesh'}.${name} (LipSync)`);
            }
          }
        }
      }
    });

    if (bindings.length === 0) {
      console.warn('[AvatarEngine] Warning: No eyelid blink morph targets found in model matching pattern');
    }

    return { bindings, mouthBindings, names };
  }

  /**
   * Loads a GLB/GLTF model, or smoothly falls back to procedural rigged humanoid
   * if the file isn't found at the specified path.
   */
  async loadAvatar(avatarName: string, path: string, colorAccent: string = '#8C9BFF'): Promise<void> {
    if (this.onLoadingStateChange) {
      this.onLoadingStateChange(true, `Loading ${avatarName}...`);
    }

    // 1. Strictly dispose old avatar first to prevent any duplicate/ghost meshes
    this.disposeCurrentAvatar();

    let newAvatar: THREE.Group;
    let isProcedural = false;

    try {
      // Attempt loading real GLB
      const gltf = await new Promise<any>((resolve, reject) => {
        this.gltfLoader.load(
          path,
          (g) => resolve(g),
          undefined,
          (err) => reject(err)
        );
      });

      // Use the root scene
      newAvatar = gltf.scene || gltf.scenes[0];
      newAvatar.name = `GLTF_${avatarName}`;

      // Adjust scale and ensure upright grounding
      const box = new THREE.Box3().setFromObject(newAvatar);
      const size = box.getSize(new THREE.Vector3());
      if (size.y > 0) {
        // Target standard humanoid height of 1.70m
        const targetHeight = 1.70;
        const scale = targetHeight / size.y;
        newAvatar.scale.set(scale, scale, scale);

        // Center on floor
        box.setFromObject(newAvatar);
        newAvatar.position.y = -box.min.y;
        newAvatar.position.x = -(box.min.x + box.max.x) / 2;
        newAvatar.position.z = -(box.min.z + box.max.z) / 2;
      }
    } catch (err) {
      // Graceful fallback to procedural rigged model
      console.info(`[AvatarEngine] GLB not found at "${path}". Instantiating procedural rigged avatar: ${avatarName}`);
      newAvatar = createProceduralHumanoidAvatar(avatarName, colorAccent);
      isProcedural = true;
    }

    // Ensure shadows and no double-render materials
    newAvatar.traverse((o) => {
      if ((o as THREE.Mesh).isMesh) {
        o.castShadow = true;
        o.receiveShadow = false;
      }
    });

    // 2. Add to scene (only ONE avatar in the scene at any time)
    this.scene.add(newAvatar);
    this.currentAvatarGroup = newAvatar;

    // 3. Discover bones and morph targets
    const boneResults = this.discoverBones(newAvatar);
    this.bones = boneResults.bones;

    const morphResults = this.discoverMorphTargets(newAvatar);
    this.morphBindings = morphResults.bindings;
    this.mouthBindings = morphResults.mouthBindings;

    // 4. Cache initial rest quaternions of arms and shoulders for additive/relative rotation
    this.initialRestQuaternions.clear();
    const bonesToCache: (THREE.Bone | undefined)[] = [
      this.bones.leftShoulder,
      this.bones.leftArm,
      this.bones.leftForeArm,
      this.bones.leftHand,
      this.bones.rightShoulder,
      this.bones.rightArm,
      this.bones.rightForeArm,
      this.bones.rightHand,
    ];

    bonesToCache.forEach((b) => {
      if (b) {
        this.initialRestQuaternions.set(b, b.quaternion.clone());
      }
    });

    // 5. POSE LOCK: Cache hips/root rest pose to lock it strictly every frame
    const hipsBone = this.bones.hips || this.bones.root;
    if (hipsBone) {
      this.initialHipsPosition.copy(hipsBone.position);
      this.initialHipsQuaternion.copy(hipsBone.quaternion);
    }

    // Trigger diagnostics callback
    if (this.onDiagnosticsUpdate) {
      const warnings: string[] = [];
      if (boneResults.missing.length > 0) {
        warnings.push(`Missing bones: ${boneResults.missing.join(', ')}`);
      }
      if (morphResults.bindings.length === 0) {
        warnings.push('No eyelid blink morph targets found on this model');
      }

      this.onDiagnosticsUpdate({
        avatarName,
        isCustomLoaded: !isProcedural,
        totalBonesFound: boneResults.allFound.length,
        mappedBones: boneResults.allFound,
        missingBones: boneResults.missing,
        totalMorphTargetsFound: morphResults.bindings.length,
        mappedMorphTargets: morphResults.names,
        warnings,
        isProceduralFallback: isProcedural,
      });
    }

    if (this.onLoadingStateChange) {
      this.onLoadingStateChange(false, '');
    }
  }

  /**
   * Loads a custom GLB/GLTF file directly from an ArrayBuffer / File object
   * (Allows users to drop their real GLBs directly into the viewer)
   */
  async loadCustomFile(file: File): Promise<void> {
    if (this.onLoadingStateChange) {
      this.onLoadingStateChange(true, `Reading ${file.name}...`);
    }

    const buffer = await file.arrayBuffer();
    this.disposeCurrentAvatar();

    try {
      const gltf = await new Promise<any>((resolve, reject) => {
        this.gltfLoader.parse(
          buffer,
          '',
          (g) => resolve(g),
          (err) => reject(err)
        );
      });

      const newAvatar: THREE.Group = gltf.scene || gltf.scenes[0];
      newAvatar.name = `CustomGLB_${file.name}`;

      // Normalize size
      const box = new THREE.Box3().setFromObject(newAvatar);
      const size = box.getSize(new THREE.Vector3());
      if (size.y > 0) {
        const targetHeight = 1.70;
        const scale = targetHeight / size.y;
        newAvatar.scale.set(scale, scale, scale);

        box.setFromObject(newAvatar);
        newAvatar.position.y = -box.min.y;
        newAvatar.position.x = -(box.min.x + box.max.x) / 2;
        newAvatar.position.z = -(box.min.z + box.max.z) / 2;
      }

      this.scene.add(newAvatar);
      this.currentAvatarGroup = newAvatar;

      const boneResults = this.discoverBones(newAvatar);
      this.bones = boneResults.bones;

      const morphResults = this.discoverMorphTargets(newAvatar);
      this.morphBindings = morphResults.bindings;
      this.mouthBindings = morphResults.mouthBindings;

      this.initialRestQuaternions.clear();
      const bonesToCache = [
        this.bones.leftShoulder,
        this.bones.leftArm,
        this.bones.leftForeArm,
        this.bones.leftHand,
        this.bones.rightShoulder,
        this.bones.rightArm,
        this.bones.rightForeArm,
        this.bones.rightHand,
      ];

      bonesToCache.forEach((b) => {
        if (b) this.initialRestQuaternions.set(b, b.quaternion.clone());
      });

      const hipsBone = this.bones.hips || this.bones.root;
      if (hipsBone) {
        this.initialHipsPosition.copy(hipsBone.position);
        this.initialHipsQuaternion.copy(hipsBone.quaternion);
      }

      if (this.onDiagnosticsUpdate) {
        const warnings: string[] = [];
        if (boneResults.missing.length > 0) {
          warnings.push(`Missing bones: ${boneResults.missing.join(', ')}`);
        }
        if (morphResults.bindings.length === 0) {
          warnings.push('No eyelid blink morph targets found on this model');
        }

        this.onDiagnosticsUpdate({
          avatarName: file.name,
          isCustomLoaded: true,
          totalBonesFound: boneResults.allFound.length,
          mappedBones: boneResults.allFound,
          missingBones: boneResults.missing,
          totalMorphTargetsFound: morphResults.bindings.length,
          mappedMorphTargets: morphResults.names,
          warnings,
          isProceduralFallback: false,
        });
      }
    } catch (err) {
      console.error('[AvatarEngine] Failed to parse custom GLB file:', err);
    } finally {
      if (this.onLoadingStateChange) {
        this.onLoadingStateChange(false, '');
      }
    }
  }

  /**
   * Main 60FPS animation loop
   */
  startAnimationLoop() {
    const tempEuler = new THREE.Euler();
    const deltaQ = new THREE.Quaternion();

    const animate = () => {
      this.animId = requestAnimationFrame(animate);

      if (this.isPaused) return;

      const dt = Math.min(this.clock.getDelta(), 0.05);
      const time = this.clock.getElapsedTime();

      // =========================================================================
      // 1. STRAIGHT STANDING POSITION:
      // Lock root/hips position and orientation EVERY frame.
      // All bones (shoulders, arms, forearms, hands, spine, head, legs) stay
      // perfectly aligned in straight natural upright standing position.
      // Zero tilted bodies, leaning, bending, twisting, or distorted posture.
      // Avatars remain completely still while speaking.
      // =========================================================================
      const hipsBone = this.bones.hips || this.bones.root;
      if (hipsBone) {
        hipsBone.position.copy(this.initialHipsPosition);
        hipsBone.quaternion.copy(this.initialHipsQuaternion);
      }

      for (const [bone, restQ] of this.initialRestQuaternions.entries()) {
        bone.quaternion.copy(restQ);
      }

      // =========================================================================
      // 2. ORIGINAL AUDIO-SYNCHRONIZED LIP-SYNC ONLY:
      // Single active lip-sync controller accurately driving mouth morph targets.
      // Accurately synchronized with spoken audio level without duplicate layers.
      // =========================================================================
      let targetMouth = 0.0;
      if (this.isSpeaking) {
        const audioAmp = Math.max(0, Math.min(1, this.audioLevel));
        const speechCadence = Math.sin(time * 20) * 0.28 + Math.sin(time * 32) * 0.18 + 0.54;
        targetMouth = audioAmp > 0.04
          ? Math.max(0.18, Math.min(0.95, audioAmp * 1.3))
          : Math.max(0.16, Math.min(0.85, speechCadence));
      } else {
        targetMouth = 0.0;
      }
      this.mouthValue += (targetMouth - this.mouthValue) * 0.38;
      if (!this.isSpeaking && this.mouthValue < 0.01) {
        this.mouthValue = 0.0;
      }

      for (const binding of this.mouthBindings) {
        if (binding.mesh.morphTargetInfluences) {
          binding.mesh.morphTargetInfluences[binding.index] = this.mouthValue;
        }
      }

      // =========================================================================
      // ANIMATION 2: NATURAL BIOLOGICAL EYE BLINKING
      // Blinks every 2 to 5 seconds at random intervals.
      // Fast close (45ms), brief hold, slower open (75-90ms), total 120-180ms.
      // Occasionally does a double blink (~15%). Never keeps eyes closed.
      // =========================================================================
      const bs = this.blinkState;

      if (!bs.isBlinking && time >= bs.nextBlinkTime) {
        bs.isBlinking = true;
        bs.blinkStartTime = time;
        bs.isDoubleBlink = Math.random() < 0.15; // 15% double blink chance
        // Total duration calibrated between 120ms and 180ms
        bs.blinkDuration = 0.12 + Math.random() * 0.06;
      }

      let blinkWeight = 0;

      if (bs.isBlinking) {
        const elapsed = time - bs.blinkStartTime;
        const closeDuration = 0.045; // Rapid 45ms downward descent
        const holdDuration = 0.020; // 20ms full closure
        const openDuration = bs.blinkDuration - closeDuration - holdDuration;

        if (elapsed < closeDuration) {
          // Fast close
          const progress = elapsed / closeDuration;
          blinkWeight = Math.sin((progress * Math.PI) / 2);
        } else if (elapsed < closeDuration + holdDuration) {
          // Closed
          blinkWeight = 1.0;
        } else if (elapsed < bs.blinkDuration) {
          // Slower open
          const progress = (elapsed - closeDuration - holdDuration) / Math.max(0.01, openDuration);
          blinkWeight = 1.0 - Math.sin((progress * Math.PI) / 2);
        } else {
          // Completed
          blinkWeight = 0;
          bs.isBlinking = false;

          if (bs.isDoubleBlink) {
            // Rapid secondary blink within 110-160ms
            bs.nextBlinkTime = time + 0.11 + Math.random() * 0.05;
            bs.isDoubleBlink = false;
          } else {
            // Next random blink in 2 to 5 seconds
            bs.nextBlinkTime = time + 2.0 + Math.random() * 3.0;
          }
        }
      }

      bs.value = blinkWeight;

      // Apply to all discovered morph target bindings
      for (const binding of this.morphBindings) {
        if (binding.mesh.morphTargetInfluences) {
          binding.mesh.morphTargetInfluences[binding.index] = blinkWeight;
        }
      }

      // Render the frame with autoClear = true (strictly no ghosting)
      this.renderer.render(this.scene, this.camera);
    };

    animate();
  }

  triggerTestBlink() {
    this.blinkState.nextBlinkTime = this.clock.getElapsedTime();
    this.blinkState.isBlinking = false;
  }

  setSpeech(isSpeaking: boolean, audioLevel: number = 0) {
    this.isSpeaking = isSpeaking;
    this.audioLevel = audioLevel;
  }

  destroy() {
    cancelAnimationFrame(this.animId);
    this.disposeCurrentAvatar();
    this.groundShadow.geometry.dispose();
    (this.groundShadow.material as THREE.Material).dispose();
    this.renderer.dispose();
  }
}
