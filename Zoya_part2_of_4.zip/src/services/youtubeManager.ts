/**
 * Zoya YouTube Integration Manager
 * Manages:
 * 1. Preferred YouTube playback app selection ('youtube_app' | 'browser' | 'auto')
 * 2. Official YouTube app detection & deep linking with browser fallback
 * 3. Permanent favorite singers management (add, remove, persist)
 * 4. YouTube Data API v3 proxy communication
 */

export type PreferredYouTubeApp = 'youtube_app' | 'browser' | 'auto';

export interface FavoriteSinger {
  id: string;
  name: string;
  channelId?: string;
  channelTitle?: string;
  customUrl?: string;
  thumbnail?: string;
  isPrimary?: boolean;
  addedAt: number;
}

export interface AppDetectionDetails {
  detected: boolean;
  platform: 'android_bridge' | 'android_web' | 'ios' | 'browser';
  reason: string;
  supportsNativeApp: boolean;
  supportsBrowserFallback: boolean;
}

export interface YouTubeApiStatus {
  configured: boolean;
  connected: boolean;
  maskedKey: string;
  keySource: string;
  message: string;
  error?: string | null;
}

export interface YouTubeVideo {
  videoId: string;
  title: string;
  description: string;
  thumbnail: string;
  channelTitle: string;
  channelId: string;
  publishedAt: string;
  videoUrl: string;
}

export interface YouTubeChannel {
  channelId: string;
  title: string;
  description: string;
  customUrl?: string;
  thumbnail: string;
  subscriberCount?: string;
  videoCount?: string;
  isOfficialArtist?: boolean;
}

// Initial default popular singers to suggest if the user's list is initially empty
export const SUGGESTED_SINGERS: Array<Omit<FavoriteSinger, 'id' | 'addedAt'>> = [
  {
    name: 'Arijit Singh',
    channelTitle: 'Arijit Singh Official',
    thumbnail: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=120&q=80',
  },
  {
    name: 'Shreya Ghoshal',
    channelTitle: 'Shreya Ghoshal Official',
    thumbnail: 'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?auto=format&fit=crop&w=120&q=80',
  },
  {
    name: 'Diljit Dosanjh',
    channelTitle: 'Diljit Dosanjh',
    thumbnail: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?auto=format&fit=crop&w=120&q=80',
  },
  {
    name: 'Kishore Kumar',
    channelTitle: 'Kishore Kumar Classics',
    thumbnail: 'https://images.unsplash.com/photo-1465847899084-d164df4dedc6?auto=format&fit=crop&w=120&q=80',
  },
  {
    name: 'Lata Mangeshkar',
    channelTitle: 'Lata Mangeshkar Music',
    thumbnail: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&w=120&q=80',
  },
];

class YouTubeManager {
  private preferredApp: PreferredYouTubeApp = 'auto';
  private favoriteSingers: FavoriteSinger[] = [];

  constructor() {
    this.init();
  }

  private init() {
    if (typeof window === 'undefined') return;

    // Load preferred app
    try {
      const savedApp = localStorage.getItem('zoya_youtube_preferred_app') as PreferredYouTubeApp | null;
      if (savedApp && ['youtube_app', 'browser', 'auto'].includes(savedApp)) {
        this.preferredApp = savedApp;
      }
    } catch {}

    // Load favorite singers
    try {
      const savedSingers = localStorage.getItem('zoya_favorite_singers');
      if (savedSingers) {
        const parsed = JSON.parse(savedSingers);
        if (Array.isArray(parsed)) {
          this.favoriteSingers = parsed;
        }
      }
    } catch {}
  }

  // --- Preferred App Selection & Detection ---

  public getPreferredApp(): PreferredYouTubeApp {
    return this.preferredApp;
  }

  public setPreferredApp(app: PreferredYouTubeApp): void {
    this.preferredApp = app;
    try {
      localStorage.setItem('zoya_youtube_preferred_app', app);
      window.dispatchEvent(new CustomEvent('zoya_youtube_preferred_app_changed', { detail: { app } }));
    } catch {}
  }

  /**
   * Detect whether official YouTube app is supported or installed on device
   */
  public isYouTubeAppDetected(): boolean {
    return this.getAppDetectionDetails().detected;
  }

  /**
   * Detailed detection information for device & playback apps
   */
  public getAppDetectionDetails(): AppDetectionDetails {
    if (typeof window === 'undefined') {
      return {
        detected: false,
        platform: 'browser',
        reason: 'Server environment detected.',
        supportsNativeApp: false,
        supportsBrowserFallback: true,
      };
    }

    // 1. Native AndroidBridge injected into WebView
    const hasAndroidBridge = typeof (window as any).AndroidBridge !== 'undefined';
    if (hasAndroidBridge) {
      return {
        detected: true,
        platform: 'android_bridge',
        reason: 'Native Android bridge active (Direct YouTube app package invocation available).',
        supportsNativeApp: true,
        supportsBrowserFallback: true,
      };
    }

    const ua = navigator.userAgent.toLowerCase();

    // 2. Android mobile OS
    if (ua.includes('android')) {
      return {
        detected: true,
        platform: 'android_web',
        reason: 'Android OS detected (Supports official YouTube package intent with auto browser fallback).',
        supportsNativeApp: true,
        supportsBrowserFallback: true,
      };
    }

    // 3. iOS mobile device
    if (ua.includes('iphone') || ua.includes('ipad') || ua.includes('ipod')) {
      return {
        detected: true,
        platform: 'ios',
        reason: 'Apple iOS device detected (Supports vnd.youtube:// app protocol with browser fallback).',
        supportsNativeApp: true,
        supportsBrowserFallback: true,
      };
    }

    // 4. Desktop / Web browser
    return {
      detected: false,
      platform: 'browser',
      reason: 'Standard web browser environment (Browser tab playback fallback available).',
      supportsNativeApp: false,
      supportsBrowserFallback: true,
    };
  }

  /**
   * Open a YouTube video in the selected preferred app with browser fallback
   */
  public openVideo(videoId: string, fallbackUrl?: string): { success: boolean; method: string; target: string } {
    const webUrl = fallbackUrl || (videoId ? `https://www.youtube.com/watch?v=${videoId}` : 'https://www.youtube.com');
    const targetApp = this.preferredApp;

    if (typeof window === 'undefined') {
      return { success: false, method: 'server_env', target: webUrl };
    }

    const detection = this.getAppDetectionDetails();

    // Case 1: Browser preference selected explicitly
    if (targetApp === 'browser' || (!detection.supportsNativeApp && targetApp === 'auto')) {
      try {
        const opened = window.open(webUrl, '_blank', 'noopener,noreferrer');
        if (!opened) {
          window.location.href = webUrl;
        }
        return { success: true, method: 'browser', target: webUrl };
      } catch {
        window.location.href = webUrl;
        return { success: true, method: 'browser_location', target: webUrl };
      }
    }

    // Case 2: Native AndroidBridge available
    if (detection.platform === 'android_bridge') {
      try {
        (window as any).AndroidBridge.executeAccessibilityAction?.(
          JSON.stringify({
            action: 'open_app',
            app: 'com.google.android.youtube',
            url: webUrl,
            videoId,
          })
        );
        return { success: true, method: 'native_bridge', target: 'com.google.android.youtube' };
      } catch (bridgeErr) {
        console.warn('[YOUTUBE] Bridge launch failed, using fallback:', bridgeErr);
      }
    }

    // Case 3: Android deep link intent with built-in browser fallback
    if (detection.platform === 'android_web') {
      try {
        const intentUrl = videoId
          ? `intent://www.youtube.com/watch?v=${videoId}#Intent;package=com.google.android.youtube;scheme=https;S.browser_fallback_url=${encodeURIComponent(webUrl)};end`
          : `intent://www.youtube.com#Intent;package=com.google.android.youtube;scheme=https;S.browser_fallback_url=${encodeURIComponent(webUrl)};end`;
        
        window.location.href = intentUrl;
        return { success: true, method: 'android_intent', target: intentUrl };
      } catch {
        window.open(webUrl, '_blank');
        return { success: true, method: 'browser_fallback', target: webUrl };
      }
    }

    // Case 4: iOS protocol with fallback
    if (detection.platform === 'ios') {
      try {
        const appProtocol = videoId ? `vnd.youtube://${videoId}` : 'youtube://';
        const timeout = setTimeout(() => {
          window.open(webUrl, '_blank');
        }, 1200);
        window.location.href = appProtocol;
        window.addEventListener('blur', () => clearTimeout(timeout), { once: true });
        return { success: true, method: 'app_protocol', target: appProtocol };
      } catch {
        window.open(webUrl, '_blank');
        return { success: true, method: 'browser_fallback', target: webUrl };
      }
    }

    // Case 5: Default browser tab fallback
    try {
      window.open(webUrl, '_blank', 'noopener,noreferrer');
      return { success: true, method: 'browser_fallback', target: webUrl };
    } catch {
      window.location.href = webUrl;
      return { success: true, method: 'fallback_href', target: webUrl };
    }
  }

  // --- Favorite Singers Management ---

  public getFavoriteSingers(): FavoriteSinger[] {
    return [...this.favoriteSingers];
  }

  public getPrimaryFavoriteSinger(): FavoriteSinger | null {
    if (this.favoriteSingers.length === 0) return null;
    return this.favoriteSingers.find((s) => s.isPrimary) || this.favoriteSingers[0];
  }

  public setPrimaryFavoriteSinger(singerId: string): void {
    this.favoriteSingers = this.favoriteSingers.map((s) => ({
      ...s,
      isPrimary: s.id === singerId,
    }));
    this.persistSingers();
  }

  public addFavoriteSinger(singer: Omit<FavoriteSinger, 'id' | 'addedAt'>): FavoriteSinger {
    // Check if already exists by name or channelId
    const existing = this.favoriteSingers.find(
      (s) =>
        s.name.toLowerCase() === singer.name.toLowerCase() ||
        (singer.channelId && s.channelId === singer.channelId)
    );

    if (existing) {
      return existing;
    }

    const newSinger: FavoriteSinger = {
      ...singer,
      id: `singer_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
      addedAt: Date.now(),
    };

    this.favoriteSingers = [newSinger, ...this.favoriteSingers];
    this.persistSingers();
    return newSinger;
  }

  public removeFavoriteSinger(idOrName: string): boolean {
    const beforeCount = this.favoriteSingers.length;
    this.favoriteSingers = this.favoriteSingers.filter(
      (s) => s.id !== idOrName && s.name.toLowerCase() !== idOrName.toLowerCase()
    );
    const changed = this.favoriteSingers.length !== beforeCount;
    if (changed) {
      this.persistSingers();
    }
    return changed;
  }

  public isFavorite(nameOrChannelId: string): boolean {
    const norm = nameOrChannelId.toLowerCase().trim();
    return this.favoriteSingers.some(
      (s) => s.name.toLowerCase() === norm || s.id === norm || (s.channelId && s.channelId.toLowerCase() === norm)
    );
  }

  private persistSingers(): void {
    try {
      localStorage.setItem('zoya_favorite_singers', JSON.stringify(this.favoriteSingers));
      window.dispatchEvent(new CustomEvent('zoya_singers_updated', { detail: { singers: this.favoriteSingers } }));
    } catch {}
  }

  // --- YouTube Data API Proxy Calls ---

  public async getStatus(): Promise<YouTubeApiStatus> {
    try {
      const res = await fetch('/api/youtube/status');
      if (!res.ok) {
        return {
          configured: false,
          connected: false,
          maskedKey: '',
          keySource: 'none',
          message: `HTTP error ${res.status}`,
        };
      }
      return await res.json();
    } catch (e: any) {
      return {
        configured: false,
        connected: false,
        maskedKey: '',
        keySource: 'none',
        message: e?.message || 'Network error checking status',
      };
    }
  }

  public async configureKey(apiKey: string): Promise<{ success: boolean; valid?: boolean; message: string; maskedKey?: string }> {
    try {
      const res = await fetch('/api/youtube/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ apiKey }),
      });
      return await res.json();
    } catch (e: any) {
      return {
        success: false,
        message: e?.message || 'Failed to submit YouTube API key.',
      };
    }
  }

  public async searchSingers(query: string): Promise<{ success: boolean; channels: YouTubeChannel[]; error?: string; noKey?: boolean }> {
    try {
      const res = await fetch(`/api/youtube/search-singers?q=${encodeURIComponent(query)}`);
      return await res.json();
    } catch (e: any) {
      return {
        success: false,
        channels: [],
        error: e?.message || 'Network error searching singers.',
      };
    }
  }

  public async searchVideos(query: string, singerName?: string, maxResults = 10): Promise<{ success: boolean; videos: YouTubeVideo[]; error?: string; noKey?: boolean }> {
    try {
      let url = `/api/youtube/search-videos?q=${encodeURIComponent(query)}&maxResults=${maxResults}`;
      if (singerName) {
        url += `&singer=${encodeURIComponent(singerName)}`;
      }
      const res = await fetch(url);
      return await res.json();
    } catch (e: any) {
      return {
        success: false,
        videos: [],
        error: e?.message || 'Network error searching videos.',
      };
    }
  }

  public async getSingerTopTracks(singerName: string, channelId?: string): Promise<{ success: boolean; videos: YouTubeVideo[]; error?: string; noKey?: boolean }> {
    try {
      let url = `/api/youtube/singer-top-tracks?singer=${encodeURIComponent(singerName)}`;
      if (channelId) {
        url += `&channelId=${encodeURIComponent(channelId)}`;
      }
      const res = await fetch(url);
      return await res.json();
    } catch (e: any) {
      return {
        success: false,
        videos: [],
        error: e?.message || 'Network error fetching top tracks.',
      };
    }
  }

  /**
   * Parse voice query to detect YouTube favorite singer commands or specific singer song searches.
   * Handles English, Hindi, and Hinglish (e.g. "Diljit Dosanjh ke gaane chalao").
   */
  public parseVoiceCommand(query: string): { isFavoriteSinger: boolean; singerName: string | null; songName: string | null } {
    const q = query.trim();
    const lowerQ = q.toLowerCase();

    // Check favorite singer intent
    const isFavoriteSinger =
      lowerQ.includes('favorite singer') ||
      lowerQ.includes('favourite singer') ||
      lowerQ.includes('fav singer') ||
      lowerQ.includes('पसंदीदा सिंगर') ||
      lowerQ.includes('फेवरेट सिंगर') ||
      lowerQ.includes('पसंदीदा गायक') ||
      (lowerQ.includes('favorite') && (lowerQ.includes('song') || lowerQ.includes('music') || lowerQ.includes('गाना')));

    // Check specific singer search intent
    let singerName: string | null = null;

    // Pattern 1: "find songs by Arijit Singh", "play songs by ...", "songs by ...", "music by ..."
    const englishMatch = q.match(/(?:find songs by|play songs by|search songs by|songs by|music by|play songs of)\s+([a-zA-Z0-9\u0900-\u097F\s]+)/i);
    if (englishMatch) {
      singerName = englishMatch[1].trim();
    }

    // Pattern 2: Hinglish/Hindi suffix: "[Singer Name] ke gaane [chalao]", "[Singer] ke songs", "[Singer] के गाने"
    if (!singerName) {
      const suffixMatch = q.match(/([a-zA-Z0-9\u0900-\u097F\s]+?)\s+(?:ke\s+gaane|ke\s+gane|ke\s+songs|ke\s+geet|ka\s+gana|के\s+गाने|के\s+सोंग्स|के\s+गीत|का\s+गाना)(?:\s+(?:chalao|sunao|play|bajao|खोलें|चलाओ|सुनाओ|लगाओ|बजाओ))?/i);
      if (suffixMatch) {
        singerName = suffixMatch[1].trim();
      }
    }

    // Pattern 3: Hindi/Hinglish prefix: "गाने सुनाओ [Singer]", "गाना सुनाओ [Singer]"
    if (!singerName) {
      const prefixMatch = q.match(/(?:गाने सुनाओ|गाना सुनाओ|गाना चलाओ|गीत सुनाओ|songs of|play track of)\s+([a-zA-Z0-9\u0900-\u097F\s]+)/i);
      if (prefixMatch) {
        singerName = prefixMatch[1].trim();
      }
    }

    // Pattern 4: Check if any saved favorite singer's name is mentioned in the query
    if (!singerName) {
      for (const fav of this.favoriteSingers) {
        const favName = fav.name.toLowerCase();
        const firstName = favName.split(' ')[0] || favName;
        if (
          lowerQ.includes(favName) ||
          (firstName.length > 3 && lowerQ.includes(firstName))
        ) {
          singerName = fav.name;
          break;
        }
      }
    }

    // Pattern 5: Song name extraction, e.g. "play song Kesariya", "find song Chaleya", "play Kesariya"
    let songName: string | null = null;
    const songMatch = q.match(/(?:play song|find song|search song|song|गाना चलाओ|गीत बजाओ|play)\s+([a-zA-Z0-9\u0900-\u097F\s]+?)(?:\s+(?:by|from|singer|sung by)\s+([a-zA-Z0-9\u0900-\u097F\s]+))?$/i);
    if (songMatch && !isFavoriteSinger) {
      const candidateSong = songMatch[1].trim();
      const candidateSinger = songMatch[2]?.trim();
      if (candidateSong && !candidateSong.toLowerCase().includes('favorite') && candidateSong.length > 2) {
        songName = candidateSong
          .replace(/^(?:zoya|joya|hey zoya|hello zoya|ok zoya)[,\s]+/i, '')
          .trim();
        if (candidateSinger) {
          singerName = candidateSinger;
        }
      }
    }

    // Cleanup any lingering trailing keywords on singerName
    if (singerName) {
      singerName = singerName
        .replace(/^(?:zoya|joya|hey zoya|hello zoya|ok zoya|जोया|ज़ोया)[,\s]+/i, '')
        .replace(/(?:ke\s+gaane|ke\s+gane|ke\s+songs|के\s+गाने|के\s+सोंग्स|chalao|sunao|play|songs|song|music|चलाओ|सुनाओ|बजाओ|लगाओ)/gi, '')
        .trim();
      if (singerName.length < 2) {
        singerName = null;
      }
    }

    return { isFavoriteSinger, singerName, songName };
  }
}

export const youtubeManager = new YouTubeManager();
