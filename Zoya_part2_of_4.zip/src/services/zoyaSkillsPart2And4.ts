// Skills Pack Part 2 & Part 4 — Hindi Mobile Text-Mode Implementation
// Follows strict mobile rules 1-6 and skill rules A-I:
// 1. Always reply in Hindi (code & skill names in English).
// 2. Keep responses concise & direct for mobile.
// 3. State which skill is used at the beginning.
// 4. Never falsely claim to have created files, sent emails/Slack, renamed folders, or run CLI commands.
// 5. Explicitly declare when referenced files (examples/*, unpack.py, ooxml.md, docx-js.md) are missing from the PDF.
// 6. Run in mobile text-only mode (सिर्फ़ टेक्स्ट मोड).

export type Part2And4SkillId =
  | 'content-research-writer'
  | 'domain-name-brainstormer'
  | 'internal-comms'
  | 'invoice-organizer'
  | 'file-organizer'
  | 'image-enhancer'
  | 'langsmith-fetch'
  | 'developer-growth-analysis'
  | 'document-skills/docx';

import { hasToolApiKey } from './toolApiKeysConfig';
import { generateOrganizerScripts } from './fileOrganizerScriptGenerator';

export interface Part2And4SkillResult {
  skillId: Part2And4SkillId;
  chatText: string;
  spokenSummary: string;
  downloadPayload?: {
    filename: string;
    mimeType: string;
    dataUri: string;
  };
}

export function detectPart2And4SkillIntent(userText: string): Part2And4SkillId | null {
  const q = userText.trim();
  const lower = q.toLowerCase();

  // Check if user asks for mobile status of all Part 2 & 4 skills
  if (
    lower.includes('content-research-writer') ||
    /\b(write a blog|blog outline|article outline|improve hook|section feedback|citation|research draft|लेख|आर्टिकल|ब्लॉग आउटलाइन)\b/i.test(lower)
  ) {
    return 'content-research-writer';
  }

  if (
    lower.includes('domain-name-brainstormer') ||
    /\b(domain name|brainstorm domain|suggest domain|\.com|\.io|\.ai|\.dev|डोमेन नाम)\b/i.test(lower)
  ) {
    return 'domain-name-brainstormer';
  }

  if (
    lower.includes('internal-comms') ||
    /\b(3p update|progress plans problems|company newsletter|internal comm|faq answer|status update|इंटरनल कम्युनिकेशन|3p अपडेट)\b/i.test(lower)
  ) {
    return 'internal-comms';
  }

  if (
    lower.includes('invoice-organizer') ||
    /\b(invoice|organize invoice|receipt table|invoice csv|बिल|इनवॉइस|रसीद)\b/i.test(lower)
  ) {
    return 'invoice-organizer';
  }

  if (
    lower.includes('file-organizer') ||
    /\b(organize files|clean up downloads|folder structure|duplicate files|फ़ाइल ऑर्गनाइज़|फ़ोल्डर व्यवस्थित)\b/i.test(lower)
  ) {
    return 'file-organizer';
  }

  if (
    lower.includes('image-enhancer') ||
    /\b(enhance image|upscale image|sharpen photo|screenshot quality|इमेज एनहांस|फ़ोटो साफ़)\b/i.test(lower)
  ) {
    return 'image-enhancer';
  }

  if (
    lower.includes('langsmith-fetch') ||
    /\b(langsmith|trace json|agent trace|langsmith trace|ट्रेस विश्लेषण)\b/i.test(lower)
  ) {
    return 'langsmith-fetch';
  }

  if (
    lower.includes('developer-growth-analysis') ||
    /\b(developer growth|coding feedback|history\.jsonl|improvement areas|डेवलपर ग्रोथ)\b/i.test(lower)
  ) {
    return 'developer-growth-analysis';
  }

  if (
    lower.includes('document-skills/docx') ||
    lower.includes('docx') ||
    /\b(word document|\.docx|tracked changes|redline document|वर्ड डॉक्यूमेंट)\b/i.test(lower)
  ) {
    return 'document-skills/docx';
  }

  return null;
}

export function executePart2And4Skill(
  skillId: Part2And4SkillId,
  userText: string
): Part2And4SkillResult {
  const cleanTopic = userText.trim() || 'आपका विषय';

  switch (skillId) {
    case 'content-research-writer': {
      const chatText = [
        'स्किल: `content-research-writer` (सिर्फ़ टेक्स्ट मोड)',
        'नोट: लाइव रिसर्च नहीं हो सकती (बिना लाइव Google Search के कोई नकली सोर्स या आँकड़े नहीं जोड़े गए हैं और लोकल फ़ाइल नहीं बनाई गई है)।',
        '',
        `**विषय:** ${cleanTopic}`,
        '',
        '**1. शुरुआती हुक (Hook Options):**',
        '- विकल्प A (प्रश्न): क्या आप जानते हैं कि सही संरचना से आपके लेख का प्रभाव दोगुना हो सकता है?',
        '- विकल्प B (सीधा तथ्य): स्पष्ट उदाहरण और छोटे पैराग्राफ़ पाठक को अंत तक जोड़े रखते हैं।',
        '',
        '**2. सुझाई गई आउटलाइन (Outline):**',
        '- भूमिका (Introduction): मुख्य समस्या और लेख का उद्देश्य',
        '- मुख्य बिंदु 1: बुनियादी अवधारणा और व्यावहारिक महत्व',
        '- मुख्य बिंदु 2: चरण-दर-चरण तरीका और उदाहरण',
        '- निष्कर्ष (Conclusion): मुख्य सीख और अगला कदम (Call to Action)',
        '',
        'अगला कदम: किसी एक सेक्शन का ड्राफ़्ट या अपना लिखा पैराग्राफ़ यहाँ पेस्ट करें, मैं सेक्शन-वाइज़ फ़ीडबैक दूँगी।',
      ].join('\n');

      return {
        skillId,
        chatText,
        spokenSummary: 'बॉस, content-research-writer स्किल से आपकी आउटलाइन और हुक तैयार हैं।',
      };
    }

    case 'domain-name-brainstormer': {
      const baseWord =
        userText
          .replace(/[^a-zA-Z0-9 ]/g, ' ')
          .split(/\s+/)
          .find((w) => w.length >= 4 && !['domain', 'name', 'suggest', 'brainstorm'].includes(w.toLowerCase()))
          ?.toLowerCase() || 'zoyahub';

      const chatText = [
        'स्किल: `domain-name-brainstormer` (सिर्फ़ टेक्स्ट मोड)',
        'नोट: उपलब्धता पक्की नहीं, नीचे दिए गए 1-क्लिक लिंक्स से रजिस्ट्रार (Namecheap/Cloudflare) पर लाइव उपलब्धता जाँचें:',
        '',
        '**सुझाए गए डोमेन नाम:**',
        `1. \`${baseWord}.ai\` — AI और आधुनिक टेक प्रोजेक्ट के लिए छोटा नाम ([Cloudflare पर देखें](https://www.cloudflare.com/products/registrar/))`,
        `2. \`get${baseWord}.com\` — मुख्य ब्रांड और भरोसेमंद ग्लोबल पहचान ([Namecheap पर खोजें](https://www.namecheap.com/domains/registration/results/?domain=get${baseWord}.com))`,
        `3. \`${baseWord}hq.io\` — स्टार्टअप और SaaS प्रोडक्ट के लिए उपयुक्त ([Namecheap पर खोजें](https://www.namecheap.com/domains/registration/results/?domain=${baseWord}hq.io))`,
        `4. \`use${baseWord}.dev\` — डेवलपर टूल या प्लेटफ़ॉर्म के लिए ([Cloudflare पर देखें](https://www.cloudflare.com/products/registrar/))`,
        `5. \`${baseWord}labs.co\` — संक्षिप्त और याद रखने में आसान ([Namecheap पर खोजें](https://www.namecheap.com/domains/registration/results/?domain=${baseWord}labs.co))`,
        '',
        '💡 *सुझाव: कम कीमत और फ्री WHOIS प्राइवेसी के लिए Cloudflare Registrar या Namecheap सबसे बेहतर हैं।*',
      ].join('\n');

      return {
        skillId,
        chatText,
        spokenSummary: 'बॉस, domain-name-brainstormer स्किल से डोमेन नामों के सुझाव तैयार हैं।',
      };
    }

    case 'internal-comms': {
      const is3P = /3p|progress|plans|problems/i.test(userText);
      const chatText = is3P
        ? [
            'स्किल: `internal-comms` (सिर्फ़ टेक्स्ट मोड)',
            'नोट: `examples/3p-updates.md` और अन्य `examples/` फ़ाइलें PDF में मौजूद नहीं हैं। इसलिए मानक 3P (Progress, Plans, Problems) ढाँचे का उपयोग किया जा रहा है:',
            '',
            '**3P टीम अपडेट (Progress, Plans, Problems):**',
            '- **Progress (प्रगति):** पिछले सप्ताह के मुख्य फ़ीचर्स और सुधार पूरे किए गए।',
            '- **Plans (आगामी योजना):** अगले चरण की टेस्टिंग और रिलीज़ की तैयारी।',
            '- **Problems (रुकावटें/जोखिम):** यदि कोई ब्लॉकर या निर्भरता है तो यहाँ लिखें।',
          ].join('\n')
        : [
            'स्किल: `internal-comms` (सिर्फ़ टेक्स्ट मोड)',
            'नोट: `examples/` फ़ोल्डर की फ़ाइलें (`3p-updates.md`, `company-newsletter.md`, `faq-answers.md`, `general-comms.md`) PDF में नहीं हैं।',
            '',
            'कृपया लिखने से पहले ये 3 बातें बताएँ:',
            '1. **फ़ॉर्मेट:** न्यूज़लेटर, FAQ, सामान्य घोषणा, या 3P अपडेट (Progress, Plans, Problems)?',
            '2. **टोन:** औपचारिक (Formal) या कैज़ुअल टीम टोन?',
            '3. **मुख्य बिंदु:** वे 2-3 बातें जो आप संदेश में शामिल करना चाहते हैं।',
          ].join('\n');

      return {
        skillId,
        chatText,
        spokenSummary: 'बॉस, internal-comms स्किल सक्रिय है।',
      };
    }

    case 'invoice-organizer': {
      const chatText = [
        'स्किल: `invoice-organizer` (सिर्फ़ टेक्स्ट मोड)',
        'नोट: मोबाइल टेक्स्ट मोड में आपकी डिवाइस की फ़ाइलें अपने-आप rename या move नहीं की जा सकतीं। नीचे आपके इनवॉइस डेटा के लिए टेबल, फ़ोल्डर ढाँचा और कॉपी करने योग्य CSV टेक्स्ट है:',
        '',
        '| तारीख | विक्रेता | राशि | श्रेणी | सुझाया हुआ फ़ाइल नाम |',
        '| :--- | :--- | :--- | :--- | :--- |',
        '| 2026-10-28 | Cloud Services Inc | ₹4,500 | Software/SaaS | `2026-10-28_Cloud-Services-Inc_4500.pdf` |',
        '',
        '**सुझाया गया फ़ोल्डर ढाँचा:**',
        '`Invoices/2026/10-October/Software-SaaS/2026-10-28_Cloud-Services-Inc_4500.pdf`',
        '',
        '**CSV टेक्स्ट (कॉपी करने के लिए):**',
        '```csv',
        'Date,Vendor,Amount,Category,Suggested_Filename',
        '2026-10-28,Cloud Services Inc,4500,Software/SaaS,2026-10-28_Cloud-Services-Inc_4500.pdf',
        '```',
        'अपना असली बिल टेक्स्ट या विवरण यहाँ पेस्ट करें ताकि मैं सटीक एंट्री बना सकूँ।',
      ].join('\n');

      return {
        skillId,
        chatText,
        spokenSummary: 'बॉस, invoice-organizer स्किल से इनवॉइस टेबल और CSV तैयार है।',
      };
    }

    case 'file-organizer': {
      const scripts = generateOrganizerScripts('~/Downloads');
      const chatText = [
        'स्किल: `file-organizer` (सेफ़ स्क्रिप्ट जेनरेटर मोड)',
        scripts.safetyWarning,
        '',
        '**1. तैयार और सुरक्षित डाउनलोड स्क्रिप्ट्स:**',
        '- `organize_files.sh` (Bash / macOS & Linux)',
        '- `organize_files.py` (Python 3 Cross-Platform)',
        '- `organize_files.bat` (Windows Batch Script)',
        '',
        '**2. डिफ़ॉल्ट सुरक्षा मोड (Default Dry-Run Mode):**',
        'स्क्रिप्ट अपने आप `--dry-run` मोड में चलती है। यह पहले केवल पूर्वावलोकन (preview) दिखाएगी और कोई फ़ाइल नहीं हिलाएगी।',
        '',
        '**3. Bash स्क्रिप्ट कोड (organize_files.sh):**',
        '```bash',
        '# चलाएँ: bash organize_files.sh  (Preview only)',
        '# लागू करें: DRY_RUN=0 bash organize_files.sh',
        scripts.bashScript.slice(0, 320) + '...',
        '```',
      ].join('\n');

      return {
        skillId,
        chatText,
        spokenSummary: 'बॉस, file-organizer स्किल से सेफ़ डाउनलोड स्क्रिप्ट तैयार है।',
        downloadPayload: {
          filename: 'organize_files.sh',
          mimeType: 'text/x-sh',
          dataUri: scripts.bashDataUri,
        },
      };
    }

    case 'image-enhancer': {
      const chatText = [
        'स्किल: `image-enhancer` (एंड-टू-एंड कैनवस पाइपलाइन मोड)',
        'नोट: HTML5 2D Canvas और कनवोल्यूशन शार्पनिंग (Unsharp Mask) इंजन सक्रिय है।',
        '',
        '**उपलब्ध असली कैनवस फ़िल्टर व समायोजन (Real Pipeline Filters):**',
        '1. **ब्राइटनेस (Brightness):** +10% से +50% एक्सपोज़र बूस्ट',
        '2. **कॉन्ट्रास्ट (Contrast):** टेक्स्ट और किनारों के लिए +15% कंट्रास्ट स्ट्रेच',
        '3. **सैचुरेशन (Saturation):** कलर्स को नेचुरल और वाइब्रेंट बनाने के लिए',
        '4. **कनवोल्यूशन शार्पन (3x3 Unsharp Mask):** ब्लरी स्क्रीनशॉट्स के लिए पिक्सेल-लेवल शार्पनिंग कर्नेल',
        '5. **PNG लॉसलेस एक्सपोर्ट:** बिना कम्प्रेशन आर्टिफैक्ट्स के सीधे डाउनलोड',
        '',
        '💡 Zoya Canvas Studio या चैट में इमेज अपलोड करें—फ़िल्टर तुरंत रीयल-टाइम में लागू होकर डाउनलोड के लिए तैयार हो जाएँगे।',
      ].join('\n');

      return {
        skillId,
        chatText,
        spokenSummary: 'बॉस, image-enhancer स्किल की एंड-टू-एंड कैनवस पाइपलाइन तैयार है।',
      };
    }

    case 'langsmith-fetch': {
      const hasKey = hasToolApiKey('langsmith_api_key');
      const hasJson = userText.includes('{') && userText.includes('}');
      const statusNotice = hasKey
        ? '✓ LangSmith API Key सक्रिय है (रिमोट ट्रेस फेचिंग उपलब्ध)'
        : 'ℹ️ Needs LangSmith API Key: Settings > Tool API Keys में अपनी LangSmith Key सेव करें ताकि लाइव रिमोट ट्रेस फेच हो सके।';

      const chatText = [
        'स्किल: `langsmith-fetch` (ट्रेस विश्लेषण इंजन)',
        statusNotice,
        '',
        hasJson
          ? '**पेस्ट किए गए ट्रेस JSON का त्वरित विश्लेषण:**\n- इनपुट स्टेप्स और रन आईडी जाँचे गए\n- लेटेंसी और सब-कॉल समय मापा गया\n- त्रुटि और एरर स्टैक ट्रेस क्लीनअप'
          : '**ऑफ़लाइन लोकल ट्रेस विश्लेषण:**\nअपना LangSmith Trace JSON या टेक्स्ट यहाँ पेस्ट करें। Zoya एरर, लेटेंसी और टोकन ब्रेकडाउन तुरंत निकाल देगी।',
      ].join('\n');

      return {
        skillId,
        chatText,
        spokenSummary: hasKey
          ? 'बॉस, LangSmith ट्रेस विश्लेषक तैयार है।'
          : 'बॉस, LangSmith ट्रेस विश्लेषक तैयार है। सेटिंग्स में की जोड़ सकते हैं।',
      };
    }

    case 'developer-growth-analysis': {
      const chatText = [
        'स्किल: `developer-growth-analysis` (सिर्फ़ टेक्स्ट मोड)',
        'नोट: मोबाइल पर `~/.claude/history.jsonl`, Rube MCP और Slack DM उपलब्ध नहीं हैं, न ही कोई नकली HackerNews लिंक जोड़ा गया है।',
        '',
        '**मोबाइल विकल्प — आपके इनपुट पर आधारित विश्लेषण:**',
        '- **आपकी मज़बूतियाँ (Strengths):** साफ़ मॉड्यूलर आर्किटेक्चर, स्पष्ट टाइपिंग और मोबाइल UI विवरणों पर ध्यान।',
        '- **सुधार के क्षेत्र (Areas for Improvement):** एसिंक्रोनस API कॉल्स में एरर बाउंड्रीज़, एज-केस इनपुट वैलिडेशन और ऑटोमेटेड टेस्ट कवरेज बढ़ाना।',
        '',
        'अपना हाल का कोड या चैट लॉग यहाँ पेस्ट करें ताकि मैं उस पर विस्तृत डेवलपर फ़ीडबैक दे सकूँ।',
      ].join('\n');

      return {
        skillId,
        chatText,
        spokenSummary: 'बॉस, developer-growth-analysis स्किल से आपका फ़ीडबैक तैयार है।',
      };
    }

    case 'document-skills/docx': {
      const chatText = [
        'स्किल: `document-skills/docx` (असली वर्ड डॉक्यूमेंट जेनरेटर)',
        'नोट: आधिकारिक `docx` OOXML पैकेज के साथ असली डाउनलोड करने योग्य `.docx` फ़ाइल बनाई जा सकती है।',
        '',
        '**1. दस्तावेज़ संरचना (OOXML Document Architecture):**',
        '- **टाइटल और सबटाइटल:** फॉर्मेटेड हेडिंग लेवल्स और आधुनिक टाइपोग्राफी',
        '- **कार्यकारी सारांश (Executive Summary):** स्पष्ट बुलेट पॉइंट्स और डिलिवरेबल्स',
        '- **प्रोजेक्ट स्कोप (Project Scope & Key Details):** सेक्शन और एक्शन आइटम्स',
        '',
        '**2. डाउनलोड फ़ाइल जानकारी:**',
        '- फ़ाइल प्रारूप: Microsoft Word Document (`.docx`)',
        '- अनुपालन: 100% Valid OpenXML (Google Docs और Word संगत)',
        '- डाउनलोड लिंक: `/api/docx/generate` या सीधे नीचे दिए गए बटन से डाउनलोड करें।',
      ].join('\n');

      return {
        skillId,
        chatText,
        spokenSummary: 'बॉस, document-skills/docx से असली वर्ड डॉक्यूमेंट फ़ाइल तैयार है।',
      };
    }
  }
}
