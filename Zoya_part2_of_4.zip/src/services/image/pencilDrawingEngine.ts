/**
 * Real-Time 3D Pencil Photo Sketch Engine
 * Analyzes any uploaded photograph (portraits, objects, scenery), extracts ordered
 * structural contours, fine details, tonal cross-hatching, and deep graphite shadows,
 * and renders progressive artist-grade graphite strokes synchronized with a live 3D pencil.
 */

export type PencilStyleId =
  | 'realistic-graphite'
  | 'detailed-3d'
  | 'fine-line'
  | 'shaded-portrait';

export type DrawingStage =
  | 'outlines'
  | 'details'
  | 'shading'
  | 'shadows';

export interface PencilStrokePoint {
  x: number; // Normalized [0..1]
  y: number; // Normalized [0..1]
  pressure: number; // [0.2..1.0]
}

export interface PencilStroke {
  id: number;
  stage: DrawingStage;
  points: PencilStrokePoint[];
  widthNorm: number; // Relative to canvas longest side
  opacity: number; // [0.05..0.95]
  graphiteShade: number; // 0 (deep 8B black) .. 110 (light 2H gray)
  smudgeAlpha: number; // Soft tortillon tonal deposit along stroke
  smudgeRadiusNorm: number;
  bristles: number; // 1..3 parallel graphite grain micro-fibers
  lengthNorm: number; // Total normalized arc length
}

export interface StyleProfile {
  id: PencilStyleId;
  label: string;
  shortLabel: string;
  description: string;
  paperBg: string;
  paperWarmth: [number, number, number];
  outlineThreshold: number;
  detailThreshold: number;
  outlineWidthScale: number;
  hatchStepPx: number;
  hatchMaxDarkness: number;
  smudgeStrength: number;
  contrastGamma: number;
  crossHatchLevels: number;
}

export const PENCIL_STYLE_PROFILES: Record<PencilStyleId, StyleProfile> = {
  'realistic-graphite': {
    id: 'realistic-graphite',
    label: 'Realistic Graphite Pencil',
    shortLabel: 'Realistic Graphite',
    description: 'Balanced HB/2B/4B outlines, natural grain & layered cross-hatching',
    paperBg: '#f7f3e9',
    paperWarmth: [247, 243, 233],
    outlineThreshold: 34,
    detailThreshold: 17,
    outlineWidthScale: 1.0,
    hatchStepPx: 8,
    hatchMaxDarkness: 0.92,
    smudgeStrength: 0.65,
    contrastGamma: 1.15,
    crossHatchLevels: 3,
  },
  'detailed-3d': {
    id: 'detailed-3d',
    label: 'Detailed 3D Pencil Sketch',
    shortLabel: 'Detailed 3D',
    description: 'High-relief 3D depth shading, crisp edges & sculptural hatching',
    paperBg: '#f5f2eb',
    paperWarmth: [245, 242, 235],
    outlineThreshold: 29,
    detailThreshold: 14,
    outlineWidthScale: 1.18,
    hatchStepPx: 7,
    hatchMaxDarkness: 0.98,
    smudgeStrength: 0.82,
    contrastGamma: 1.32,
    crossHatchLevels: 4,
  },
  'fine-line': {
    id: 'fine-line',
    label: 'Fine-Line Pencil Drawing',
    shortLabel: 'Fine-Line',
    description: 'Precision 2H/HB architectural & portrait contours with airy shading',
    paperBg: '#fbfaf6',
    paperWarmth: [251, 250, 246],
    outlineThreshold: 26,
    detailThreshold: 13,
    outlineWidthScale: 0.78,
    hatchStepPx: 10,
    hatchMaxDarkness: 0.56,
    smudgeStrength: 0.28,
    contrastGamma: 1.05,
    crossHatchLevels: 2,
  },
  'shaded-portrait': {
    id: 'shaded-portrait',
    label: 'Shaded Graphite Portrait',
    shortLabel: 'Shaded Portrait',
    description: 'Silky 2B/6B tortillon tonal blending & velvety core shadows',
    paperBg: '#f6f0e4',
    paperWarmth: [246, 240, 228],
    outlineThreshold: 38,
    detailThreshold: 19,
    outlineWidthScale: 0.95,
    hatchStepPx: 7,
    hatchMaxDarkness: 0.96,
    smudgeStrength: 1.0,
    contrastGamma: 1.24,
    crossHatchLevels: 3,
  },
};

export interface AnalyzedPencilPlan {
  width: number;
  height: number;
  style: PencilStyleId;
  strokes: PencilStroke[];
  stageCounts: Record<DrawingStage, number>;
  stageBoundaries: {
    outlinesEnd: number;
    detailsEnd: number;
    shadingEnd: number;
    shadowsEnd: number;
  };
  totalArcLength: number;
  paperPatternCanvas: HTMLCanvasElement;
}

/**
 * Loads an HTMLImageElement from File or Blob cleanly.
 */
export function loadSketchImageFromFile(file: File | Blob): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => resolve(img);
      img.onerror = () => reject(new Error('Could not decode uploaded image'));
      img.src = String(e.target?.result || '');
    };
    reader.onerror = () => reject(new Error('Failed to read image file'));
    reader.readAsDataURL(file);
  });
}

/**
 * Generates an HTMLImageElement from a data URL.
 */
export function loadSketchImageFromDataUrl(dataUrl: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error('Failed to load sample image'));
    img.src = dataUrl;
  });
}

/**
 * Deterministic fast hash noise for paper tooth & organic graphite micro-jitter.
 */
function hashNoise(x: number, y: number): number {
  const n = Math.sin(x * 127.1 + y * 311.7) * 43758.5453123;
  return n - Math.floor(n);
}

/**
 * Builds cold-press cotton drawing paper canvas at target dimensions.
 */
export function createCottonPaperCanvas(
  width: number,
  height: number,
  style: PencilStyleId
): HTMLCanvasElement {
  const profile = PENCIL_STYLE_PROFILES[style];
  const [baseR, baseG, baseB] = profile.paperWarmth;

  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');
  if (!ctx) return canvas;

  const imgData = ctx.createImageData(width, height);
  const data = imgData.data;

  // Fine cold-press cotton paper grain + subtle directional fiber tooth
  for (let y = 0; y < height; y++) {
    const rowOff = y * width;
    const vNorm = y / Math.max(1, height - 1) - 0.5;
    for (let x = 0; x < width; x++) {
      const uNorm = x / Math.max(1, width - 1) - 0.5;
      const idx = (rowOff + x) * 4;

      const fine = (hashNoise(x * 0.85, y * 0.85) - 0.5) * 9.5;
      const tooth =
        (Math.sin(x * 0.42 + y * 0.17) * Math.cos(x * 0.19 - y * 0.39)) * 3.2;
      const radialEdge = (uNorm * uNorm + vNorm * vNorm) * 14.0;

      const delta = fine + tooth - radialEdge;
      data[idx] = Math.max(0, Math.min(255, baseR + delta));
      data[idx + 1] = Math.max(0, Math.min(255, baseG + delta));
      data[idx + 2] = Math.max(0, Math.min(255, baseB + delta - 1));
      data[idx + 3] = 255;
    }
  }

  ctx.putImageData(imgData, 0, 0);
  return canvas;
}

/**
 * Spatial nearest-neighbor stroke ordering inside a stage so the 3D pencil glides
 * cleanly from region to region without jarring jumps across the sheet.
 */
function sortStrokesSpatially(strokes: PencilStroke[]): PencilStroke[] {
  if (strokes.length <= 2) return strokes;
  const remaining = strokes.slice();
  // Start near upper-left corner (where artists typically anchor composition)
  remaining.sort((a, b) => {
    const da = a.points[0].x * 0.7 + a.points[0].y;
    const db = b.points[0].x * 0.7 + b.points[0].y;
    return da - db;
  });

  const ordered: PencilStroke[] = [];
  const used = new Uint8Array(remaining.length);

  let currentIdx = 0;
  used[0] = 1;
  ordered.push(remaining[0]);
  let curEnd = remaining[0].points[remaining[0].points.length - 1];

  // Bucket grid for O(1) amortized neighbor lookup even with 6,000+ strokes
  const gridCols = 16;
  const gridRows = 16;
  const buckets: number[][] = Array.from({ length: gridCols * gridRows }, () => []);
  for (let i = 1; i < remaining.length; i++) {
    const p = remaining[i].points[0];
    const gx = Math.min(gridCols - 1, Math.max(0, Math.floor(p.x * gridCols)));
    const gy = Math.min(gridRows - 1, Math.max(0, Math.floor(p.y * gridRows)));
    buckets[gy * gridCols + gx].push(i);
  }

  for (let step = 1; step < remaining.length; step++) {
    const cx = Math.min(gridCols - 1, Math.max(0, Math.floor(curEnd.x * gridCols)));
    const cy = Math.min(gridRows - 1, Math.max(0, Math.floor(curEnd.y * gridRows)));

    let bestIdx = -1;
    let bestDistSq = Infinity;
    let shouldReverse = false;

    // Search expanding rings around current cell
    for (let radius = 0; radius <= gridCols; radius++) {
      const minX = Math.max(0, cx - radius);
      const maxX = Math.min(gridCols - 1, cx + radius);
      const minY = Math.max(0, cy - radius);
      const maxY = Math.min(gridRows - 1, cy + radius);

      for (let gy = minY; gy <= maxY; gy++) {
        for (let gx = minX; gx <= maxX; gx++) {
          if (
            radius > 0 &&
            gx > minX &&
            gx < maxX &&
            gy > minY &&
            gy < maxY
          ) {
            continue;
          }
          const cell = buckets[gy * gridCols + gx];
          for (let k = 0; k < cell.length; k++) {
            const idx = cell[k];
            if (used[idx]) continue;
            const st = remaining[idx];
            const pStart = st.points[0];
            const pEnd = st.points[st.points.length - 1];
            const dStart =
              (pStart.x - curEnd.x) * (pStart.x - curEnd.x) +
              (pStart.y - curEnd.y) * (pStart.y - curEnd.y);
            const dEnd =
              (pEnd.x - curEnd.x) * (pEnd.x - curEnd.x) +
              (pEnd.y - curEnd.y) * (pEnd.y - curEnd.y);
            if (dStart < bestDistSq) {
              bestDistSq = dStart;
              bestIdx = idx;
              shouldReverse = false;
            }
            if (dEnd < bestDistSq) {
              bestDistSq = dEnd;
              bestIdx = idx;
              shouldReverse = true;
            }
          }
        }
      }
      if (bestIdx !== -1 && radius >= 1) break;
      if (bestIdx !== -1 && bestDistSq < 0.008) break;
    }

    if (bestIdx === -1) {
      for (let i = 0; i < remaining.length; i++) {
        if (!used[i]) {
          bestIdx = i;
          shouldReverse = false;
          break;
        }
      }
    }

    if (bestIdx === -1) break;
    used[bestIdx] = 1;
    const chosen = remaining[bestIdx];
    if (shouldReverse && chosen.points.length > 1) {
      chosen.points.reverse();
    }
    ordered.push(chosen);
    curEnd = chosen.points[chosen.points.length - 1];
    currentIdx = bestIdx;
  }

  void currentIdx;
  return ordered;
}

function computeArcLength(pts: PencilStrokePoint[]): number {
  let len = 0;
  for (let i = 1; i < pts.length; i++) {
    const dx = pts[i].x - pts[i - 1].x;
    const dy = pts[i].y - pts[i - 1].y;
    len += Math.sqrt(dx * dx + dy * dy);
  }
  return len;
}

/**
 * Smooths traced polyline points gently to eliminate jagged pixel staircase steps.
 */
function smoothPolyline(pts: PencilStrokePoint[]): PencilStrokePoint[] {
  if (pts.length < 3) return pts;
  const out: PencilStrokePoint[] = [pts[0]];
  for (let i = 1; i < pts.length - 1; i++) {
    out.push({
      x: 0.25 * pts[i - 1].x + 0.5 * pts[i].x + 0.25 * pts[i + 1].x,
      y: 0.25 * pts[i - 1].y + 0.5 * pts[i].y + 0.25 * pts[i + 1].y,
      pressure: pts[i].pressure,
    });
  }
  out.push(pts[pts.length - 1]);
  return out;
}

/**
 * Analyzes an uploaded image and builds an ordered multi-stage pencil drawing plan:
 *   1. Structural Outlines
 *   2. Facial / Inner Details & Textures
 *   3. Tonal Midtone Shading & Cross-Hatching
 *   4. Deep Graphite Shadows & Core Contrast
 */
export async function analyzePhotoForPencilDrawing(
  img: HTMLImageElement,
  style: PencilStyleId = 'realistic-graphite',
  onProgress?: (pct: number, label: string) => void
): Promise<AnalyzedPencilPlan> {
  const profile = PENCIL_STYLE_PROFILES[style];
  const origW = img.naturalWidth || img.width || 800;
  const origH = img.naturalHeight || img.height || 800;

  // Render output target resolution (crisp high-res canvas up to 1440px longest side)
  const targetMaxDim = 1440;
  let outW = origW;
  let outH = origH;
  if (outW > targetMaxDim || outH > targetMaxDim) {
    if (outW >= outH) {
      outH = Math.max(320, Math.round((outH * targetMaxDim) / outW));
      outW = targetMaxDim;
    } else {
      outW = Math.max(320, Math.round((outW * targetMaxDim) / outH));
      outH = targetMaxDim;
    }
  }

  // Analysis grid (up to 560px longest side for accurate ridge detection + fast mobile speed)
  const analysisMaxDim = 560;
  let w = outW;
  let h = outH;
  if (w > analysisMaxDim || h > analysisMaxDim) {
    if (w >= h) {
      h = Math.max(180, Math.round((h * analysisMaxDim) / w));
      w = analysisMaxDim;
    } else {
      w = Math.max(180, Math.round((w * analysisMaxDim) / h));
      h = analysisMaxDim;
    }
  }

  onProgress?.(12, 'Sampling photo luminance & subject proportions...');
  await new Promise((r) => setTimeout(r, 10));

  const workCanvas = document.createElement('canvas');
  workCanvas.width = w;
  workCanvas.height = h;
  const wCtx = workCanvas.getContext('2d', { willReadFrequently: true });
  if (!wCtx) throw new Error('Unable to initialize canvas image analyzer');
  wCtx.drawImage(img, 0, 0, w, h);

  const src = wCtx.getImageData(0, 0, w, h).data;
  const total = w * h;

  // 1. Perceptual luminance + gentle tonal normalization
  const rawLum = new Float32Array(total);
  let minL = 255;
  let maxL = 0;
  for (let i = 0; i < total; i++) {
    const p = i * 4;
    const l = 0.299 * src[p] + 0.587 * src[p + 1] + 0.114 * src[p + 2];
    rawLum[i] = l;
    if (l < minL) minL = l;
    if (l > maxL) maxL = l;
  }

  // Gentle auto-levels (only stretches 70% toward full range so shadows/highlights keep true mood)
  const range = Math.max(25, maxL - minL);
  const lum = new Float32Array(total);
  for (let i = 0; i < total; i++) {
    const stretched = ((rawLum[i] - minL) / range) * 255;
    const blended = rawLum[i] * 0.35 + stretched * 0.65;
    const n = Math.max(0, Math.min(1, blended / 255));
    lum[i] = Math.pow(n, profile.contrastGamma) * 255;
  }

  // 2. Separable Gaussian-like 3x3 smoothing for clean noise-free edge gradients
  const smoothLum = new Float32Array(total);
  for (let y = 0; y < h; y++) {
    const y0 = Math.max(0, y - 1) * w;
    const y1 = y * w;
    const y2 = Math.min(h - 1, y + 1) * w;
    for (let x = 0; x < w; x++) {
      const xm = Math.max(0, x - 1);
      const xp = Math.min(w - 1, x + 1);
      smoothLum[y1 + x] =
        (lum[y0 + xm] + 2 * lum[y0 + x] + lum[y0 + xp] +
          2 * lum[y1 + xm] + 4 * lum[y1 + x] + 2 * lum[y1 + xp] +
          lum[y2 + xm] + 2 * lum[y2 + x] + lum[y2 + xp]) /
        16;
    }
  }

  onProgress?.(32, 'Extracting primary outlines & facial contour ridges...');
  await new Promise((r) => setTimeout(r, 10));

  // 3. Sobel edge magnitude + angle + 1px Non-Maximum Suppression (NMS)
  const gradMag = new Float32Array(total);
  const gradAngle = new Float32Array(total);
  const gxArr = new Float32Array(total);
  const gyArr = new Float32Array(total);

  for (let y = 1; y < h - 1; y++) {
    const yPrev = (y - 1) * w;
    const yCurr = y * w;
    const yNext = (y + 1) * w;
    for (let x = 1; x < w - 1; x++) {
      const idx = yCurr + x;
      const gx =
        -smoothLum[yPrev + x - 1] +
        smoothLum[yPrev + x + 1] -
        2 * smoothLum[idx - 1] +
        2 * smoothLum[idx + 1] -
        smoothLum[yNext + x - 1] +
        smoothLum[yNext + x + 1];
      const gy =
        -smoothLum[yPrev + x - 1] -
        2 * smoothLum[yPrev + x] -
        smoothLum[yPrev + x + 1] +
        smoothLum[yNext + x - 1] +
        2 * smoothLum[yNext + x] +
        smoothLum[yNext + x + 1];
      const m = Math.sqrt(gx * gx + gy * gy) * 0.25; // normalized ~0..255
      gradMag[idx] = m;
      gradAngle[idx] = Math.atan2(gy, gx);
      gxArr[idx] = gx;
      gyArr[idx] = gy;
    }
  }

  const nmsMag = new Float32Array(total);
  for (let y = 1; y < h - 1; y++) {
    const yCurr = y * w;
    for (let x = 1; x < w - 1; x++) {
      const idx = yCurr + x;
      const m = gradMag[idx];
      if (m < 4) continue;
      let deg = (gradAngle[idx] * 180) / Math.PI;
      if (deg < 0) deg += 180;

      let m1 = 0;
      let m2 = 0;
      if ((deg >= 0 && deg < 22.5) || (deg >= 157.5 && deg <= 180)) {
        m1 = gradMag[idx - 1];
        m2 = gradMag[idx + 1];
      } else if (deg >= 22.5 && deg < 67.5) {
        m1 = gradMag[(y - 1) * w + x + 1];
        m2 = gradMag[(y + 1) * w + x - 1];
      } else if (deg >= 67.5 && deg < 112.5) {
        m1 = gradMag[(y - 1) * w + x];
        m2 = gradMag[(y + 1) * w + x];
      } else {
        m1 = gradMag[(y - 1) * w + x - 1];
        m2 = gradMag[(y + 1) * w + x + 1];
      }

      if (m >= m1 && m >= m2) {
        nmsMag[idx] = m;
      }
    }
  }

  // Also add fine high-pass Difference signal for delicate eyelashes/lips/hair strands
  const detailBoost = new Float32Array(total);
  for (let y = 1; y < h - 1; y++) {
    const yCurr = y * w;
    for (let x = 1; x < w - 1; x++) {
      const idx = yCurr + x;
      // Local dark ridge (e.g. eye crease, strand of hair, nostril)
      const diff = smoothLum[idx] - lum[idx];
      const combined = Math.max(nmsMag[idx], diff > 3 ? diff * 2.1 : 0);
      detailBoost[idx] = combined;
    }
  }

  // 4. Trace continuous contour polylines for Stage 1 (Outlines) & Stage 2 (Details)
  const visited = new Uint8Array(total);
  const dirs = [
    [1, 0],
    [1, 1],
    [0, 1],
    [-1, 1],
    [-1, 0],
    [-1, -1],
    [0, -1],
    [1, -1],
  ];

  const traceContours = (
    field: Float32Array,
    seedThresh: number,
    followThresh: number,
    minLen: number,
    maxLen: number,
    stage: DrawingStage,
    widthNorm: number,
    baseOpacity: number,
    shadeVal: number
  ): PencilStroke[] => {
    const result: PencilStroke[] = [];

    // Sort seed candidates strongest-first by buckets for clean structural ordering
    const seeds: number[] = [];
    for (let y = 2; y < h - 2; y++) {
      const row = y * w;
      for (let x = 2; x < w - 2; x++) {
        const idx = row + x;
        if (!visited[idx] && field[idx] >= seedThresh) {
          seeds.push(idx);
        }
      }
    }
    seeds.sort((a, b) => field[b] - field[a]);

    for (let s = 0; s < seeds.length; s++) {
      const seedIdx = seeds[s];
      if (visited[seedIdx]) continue;

      const walkDirection = (
        startX: number,
        startY: number,
        initDx: number,
        initDy: number
      ) => {
        const pts: { x: number; y: number; mag: number }[] = [];
        let cx = startX;
        let cy = startY;
        let prevDx = initDx;
        let prevDy = initDy;

        for (let step = 0; step < maxLen; step++) {
          let bestNx = -1;
          let bestNy = -1;
          let bestScore = -1;

          for (let d = 0; d < 8; d++) {
            const nx = cx + dirs[d][0];
            const ny = cy + dirs[d][1];
            if (nx < 1 || nx >= w - 1 || ny < 1 || ny >= h - 1) continue;
            const nIdx = ny * w + nx;
            if (visited[nIdx]) continue;
            const mag = field[nIdx];
            if (mag < followThresh) continue;

            // Momentum dot product prefers smooth continuation
            const dot = dirs[d][0] * prevDx + dirs[d][1] * prevDy;
            if (step > 0 && dot < -0.2) continue;
            const score = mag * (1.0 + Math.max(0, dot) * 0.65);
            if (score > bestScore) {
              bestScore = score;
              bestNx = nx;
              bestNy = ny;
            }
          }

          if (bestNx === -1) break;
          const nIdx = bestNy * w + bestNx;
          visited[nIdx] = 1;
          prevDx = bestNx - cx;
          prevDy = bestNy - cy;
          const pLen = Math.hypot(prevDx, prevDy) || 1;
          prevDx /= pLen;
          prevDy /= pLen;
          cx = bestNx;
          cy = bestNy;
          pts.push({ x: cx, y: cy, mag: field[nIdx] });
        }
        return pts;
      };

      const sx = seedIdx % w;
      const sy = Math.floor(seedIdx / w);
      visited[seedIdx] = 1;

      const tangX = -gyArr[seedIdx];
      const tangY = gxArr[seedIdx];
      const tLen = Math.hypot(tangX, tangY) || 1;
      const dirX = tangX / tLen;
      const dirY = tangY / tLen;

      const forward = walkDirection(sx, sy, dirX, dirY);
      const backward = walkDirection(sx, sy, -dirX, -dirY);

      const fullRaw = [
        ...backward.reverse(),
        { x: sx, y: sy, mag: field[seedIdx] },
        ...forward,
      ];

      if (fullRaw.length < minLen) continue;

      // Subsample & convert to normalized points
      const sampled: PencilStrokePoint[] = [];
      const stride = fullRaw.length > 14 ? 2 : 1;
      for (let i = 0; i < fullRaw.length; i += stride) {
        const pt = fullRaw[i];
        const localDark = 1 - lum[pt.y * w + pt.x] / 255;
        const pressure = Math.min(
          1,
          Math.max(0.32, 0.42 + (pt.mag / 110) * 0.35 + localDark * 0.25)
        );
        sampled.push({
          x: pt.x / (w - 1),
          y: pt.y / (h - 1),
          pressure,
        });
      }
      const last = fullRaw[fullRaw.length - 1];
      if (sampled[sampled.length - 1]?.x !== last.x / (w - 1)) {
        sampled.push({
          x: last.x / (w - 1),
          y: last.y / (h - 1),
          pressure: 0.45,
        });
      }

      if (sampled.length < 2) continue;
      const smoothed = smoothPolyline(sampled);
      const arcLen = computeArcLength(smoothed);
      if (arcLen < 0.004) continue;

      result.push({
        id: 0,
        stage,
        points: smoothed,
        widthNorm: widthNorm * profile.outlineWidthScale,
        opacity: baseOpacity,
        graphiteShade: shadeVal,
        smudgeAlpha: 0,
        smudgeRadiusNorm: 0,
        bristles: stage === 'outlines' ? 2 : 1,
        lengthNorm: arcLen,
      });
    }
    return result;
  };

  const rawOutlines = traceContours(
    nmsMag,
    profile.outlineThreshold,
    profile.outlineThreshold * 0.48,
    5,
    85,
    'outlines',
    0.00145,
    0.84,
    24
  );

  onProgress?.(54, 'Mapping facial details, hair strands & inner textures...');
  await new Promise((r) => setTimeout(r, 10));

  const rawDetails = traceContours(
    detailBoost,
    profile.detailThreshold,
    profile.detailThreshold * 0.55,
    3,
    46,
    'details',
    0.00105,
    0.66,
    46
  );

  onProgress?.(76, 'Building cross-hatching & 3D graphite shading layers...');
  await new Promise((r) => setTimeout(r, 10));

  // 5. Generate Stage 3 (Midtone Shading & Cross-Hatching) + Stage 4 (Deep Shadows)
  const rawShading: PencilStroke[] = [];
  const rawShadows: PencilStroke[] = [];

  const hatchStep = profile.hatchStepPx;
  const normW = w - 1;
  const normH = h - 1;

  // Deterministic angle helper for form-following + classic artist hatch angles
  const addHatchPass = (
    targetList: PencilStroke[],
    stage: DrawingStage,
    stepPx: number,
    minDarkness: number,
    maxDarkness: number,
    baseAngleRad: number,
    followContour: boolean,
    strokePxLen: number,
    widthNorm: number,
    opacityScale: number,
    shadeVal: number,
    smudgeFactor: number,
    jitterOffset: number
  ) => {
    for (let y = Math.floor(stepPx * 0.5) + jitterOffset; y < h - 2; y += stepPx) {
      for (let x = Math.floor(stepPx * 0.5) + jitterOffset; x < w - 2; x += stepPx) {
        const rnd = hashNoise(x + jitterOffset * 3.1, y - jitterOffset * 1.7);
        const rnd2 = hashNoise(y * 1.7 + jitterOffset, x * 2.3 - jitterOffset);
        const jx = Math.min(w - 2, Math.max(1, Math.round(x + (rnd - 0.5) * stepPx * 0.76)));
        const jy = Math.min(h - 2, Math.max(1, Math.round(y + (rnd2 - 0.5) * stepPx * 0.76)));

        const idx = jy * w + jx;
        const lVal = lum[idx] / 255;
        const darkness = Math.max(0, 1 - lVal);
        if (darkness < minDarkness) continue;

        const normDark = Math.min(
          1,
          (darkness - minDarkness) / Math.max(0.1, maxDarkness - minDarkness)
        );

        let angle = baseAngleRad + (rnd - 0.5) * 0.22;
        if (followContour && gradMag[idx] > 8) {
          // Stroke gently follows local surface tangent
          angle = gradAngle[idx] + Math.PI * 0.5 + (rnd2 - 0.5) * 0.24;
        }

        const halfLen = (strokePxLen * (0.68 + 0.56 * normDark)) / 2;
        const dx = Math.cos(angle) * halfLen;
        const dy = Math.sin(angle) * halfLen;

        // Slight organic hand curve bow perpendicular to stroke
        const bow = (rnd - 0.5) * halfLen * 0.26;
        const nx = -Math.sin(angle) * bow;
        const ny = Math.cos(angle) * bow;

        const clampX = (px: number) => Math.max(0, Math.min(1, px / normW));
        const clampY = (py: number) => Math.max(0, Math.min(1, py / normH));

        const pts: PencilStrokePoint[] = [
          { x: clampX(jx - dx), y: clampY(jy - dy), pressure: 0.35 + normDark * 0.3 },
          { x: clampX(jx + nx), y: clampY(jy + ny), pressure: 0.55 + normDark * 0.45 },
          { x: clampX(jx + dx), y: clampY(jy + dy), pressure: 0.35 + normDark * 0.3 },
        ];

        const arcLen = computeArcLength(pts);
        if (arcLen < 0.002) continue;

        targetList.push({
          id: 0,
          stage,
          points: pts,
          widthNorm,
          opacity: Math.min(
            0.85,
            (0.11 + normDark * 0.38) * opacityScale * profile.hatchMaxDarkness
          ),
          graphiteShade: Math.max(8, Math.round(shadeVal - normDark * 26)),
          smudgeAlpha:
            smudgeFactor * profile.smudgeStrength * (0.03 + normDark * 0.11),
          smudgeRadiusNorm: (stepPx * 1.3) / Math.max(w, h),
          bristles: stage === 'shadows' ? 3 : 2,
          lengthNorm: arcLen,
        });
      }
    }
  };

  // Pass 3A: Primary 45° form-blended midtone shading across face, clothes & scenery
  addHatchPass(
    rawShading,
    'shading',
    hatchStep,
    0.15,
    0.9,
    Math.PI * 0.24,
    true,
    hatchStep * 2.9,
    0.00115,
    0.82,
    60,
    0.95,
    0
  );

  // Pass 3B: Cross-hatch -42° in deeper midtones
  if (profile.crossHatchLevels >= 2) {
    addHatchPass(
      rawShading,
      'shading',
      Math.max(6, hatchStep + 1),
      0.38,
      0.94,
      -Math.PI * 0.24,
      false,
      hatchStep * 2.7,
      0.00108,
      0.76,
      46,
      0.7,
      2
    );
  }

  // Pass 3C: Fine 15° directional accent hatch for 3D sculptural roundness
  if (profile.crossHatchLevels >= 3) {
    addHatchPass(
      rawShading,
      'shading',
      Math.max(7, hatchStep + 2),
      0.56,
      0.96,
      Math.PI * 0.09,
      false,
      hatchStep * 2.5,
      0.00102,
      0.7,
      36,
      0.45,
      3
    );
  }

  // Pass 4: Deep 4B/6B core shadows (pupils, hair shadows, deep folds, silhouettes)
  addHatchPass(
    rawShadows,
    'shadows',
    Math.max(5, hatchStep - 1),
    0.66,
    1.0,
    Math.PI * 0.39,
    true,
    hatchStep * 2.4,
    0.0015,
    0.95,
    14,
    1.15,
    1
  );

  // Extra cross pass in deepest blacks (lum < 45) so dark hair & pupils are velvety rich
  addHatchPass(
    rawShadows,
    'shadows',
    Math.max(5, hatchStep),
    0.8,
    1.0,
    -Math.PI * 0.36,
    false,
    hatchStep * 2.2,
    0.00145,
    0.92,
    8,
    0.95,
    2
  );

  onProgress?.(92, 'Sequencing natural artist stroke trajectory...');
  await new Promise((r) => setTimeout(r, 10));

  const sortedOutlines = sortStrokesSpatially(rawOutlines);
  const sortedDetails = sortStrokesSpatially(rawDetails);
  const sortedShading = sortStrokesSpatially(rawShading);
  const sortedShadows = sortStrokesSpatially(rawShadows);

  const strokes: PencilStroke[] = [
    ...sortedOutlines,
    ...sortedDetails,
    ...sortedShading,
    ...sortedShadows,
  ];

  let totalArcLength = 0;
  for (let i = 0; i < strokes.length; i++) {
    strokes[i].id = i;
    totalArcLength += strokes[i].lengthNorm;
  }

  const outlinesEnd = sortedOutlines.length;
  const detailsEnd = outlinesEnd + sortedDetails.length;
  const shadingEnd = detailsEnd + sortedShading.length;
  const shadowsEnd = shadingEnd + sortedShadows.length;

  const paperPatternCanvas = createCottonPaperCanvas(outW, outH, style);

  onProgress?.(100, 'Ready to sketch live');

  return {
    width: outW,
    height: outH,
    style,
    strokes,
    stageCounts: {
      outlines: sortedOutlines.length,
      details: sortedDetails.length,
      shading: sortedShading.length,
      shadows: sortedShadows.length,
    },
    stageBoundaries: {
      outlinesEnd,
      detailsEnd,
      shadingEnd,
      shadowsEnd,
    },
    totalArcLength,
    paperPatternCanvas,
  };
}

/**
 * Renders a partial or complete segment of a PencilStroke directly onto the 2D drawing paper canvas,
 * depositing authentic tapered graphite fibers and optional soft tortillon tonal smudge.
 */
export function renderStrokeSegment(
  ctx: CanvasRenderingContext2D,
  stroke: PencilStroke,
  fromT: number,
  toT: number,
  canvasWidth: number,
  canvasHeight: number
): PencilStrokePoint {
  const pts = stroke.points;
  const segCount = Math.max(1, pts.length - 1);
  const maxDim = Math.max(canvasWidth, canvasHeight);
  const baseWidth = Math.max(0.7, stroke.widthNorm * maxDim);

  const startFloat = Math.max(0, Math.min(segCount, fromT * segCount));
  const endFloat = Math.max(startFloat, Math.min(segCount, toT * segCount));

  const sampleAt = (fIdx: number): PencilStrokePoint => {
    const i0 = Math.min(segCount - 1, Math.floor(fIdx));
    const i1 = Math.min(pts.length - 1, i0 + 1);
    const frac = fIdx - i0;
    return {
      x: pts[i0].x + (pts[i1].x - pts[i0].x) * frac,
      y: pts[i0].y + (pts[i1].y - pts[i0].y) * frac,
      pressure: pts[i0].pressure + (pts[i1].pressure - pts[i0].pressure) * frac,
    };
  };

  const pStart = sampleAt(startFloat);
  const pEnd = sampleAt(endFloat);

  // Build sub-polyline vertices from startFloat to endFloat
  const subPts: PencilStrokePoint[] = [pStart];
  const firstInt = Math.floor(startFloat) + 1;
  const lastInt = Math.floor(endFloat);
  for (let idx = firstInt; idx <= lastInt; idx++) {
    if (idx < pts.length) {
      subPts.push(pts[idx]);
    }
  }
  if (endFloat > lastInt || subPts.length < 2) {
    subPts.push(pEnd);
  }

  if (subPts.length >= 2) {
    ctx.save();
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    const g = stroke.graphiteShade;

    // Fast soft tortillon graphite shading pass strictly along swept segment
    if (stroke.smudgeAlpha > 0.004 && endFloat > startFloat) {
      const smudgeWidth = Math.max(3.2, stroke.smudgeRadiusNorm * maxDim * 1.35);
      const smudgeAlpha = Math.min(0.22, stroke.smudgeAlpha * 0.85);
      ctx.strokeStyle = `rgba(${g + 6}, ${g + 6}, ${g + 8}, ${smudgeAlpha})`;
      ctx.lineWidth = smudgeWidth;
      ctx.beginPath();
      ctx.moveTo(subPts[0].x * canvasWidth, subPts[0].y * canvasHeight);
      for (let k = 1; k < subPts.length; k++) {
        ctx.lineTo(subPts[k].x * canvasWidth, subPts[k].y * canvasHeight);
      }
      ctx.stroke();
    }

    for (let b = 0; b < stroke.bristles; b++) {
      const bristleOffset = b === 0 ? 0 : (b === 1 ? 0.55 : -0.55) * baseWidth * 0.6;
      const avgPressure = (pStart.pressure + pEnd.pressure) * 0.5;
      const bAlpha = Math.min(
        0.95,
        stroke.opacity * (b === 0 ? 1.0 : 0.48) * (0.65 + avgPressure * 0.45)
      );
      ctx.strokeStyle = `rgba(${g}, ${g}, ${g + 2}, ${bAlpha})`;
      ctx.lineWidth = Math.max(
        0.55,
        baseWidth * (0.65 + avgPressure * 0.55) * (b === 0 ? 1.0 : 0.62)
      );

      ctx.beginPath();
      ctx.moveTo(
        subPts[0].x * canvasWidth + bristleOffset,
        subPts[0].y * canvasHeight + bristleOffset * 0.6
      );
      for (let k = 1; k < subPts.length; k++) {
        ctx.lineTo(
          subPts[k].x * canvasWidth + bristleOffset,
          subPts[k].y * canvasHeight + bristleOffset * 0.6
        );
      }
      ctx.stroke();
    }
    ctx.restore();
  }

  return pEnd;
}

/**
 * Generates clean procedural sample test photos (Portrait, Object, Scenery) via HTML5 Canvas
 * with zero external file/network dependencies so users can test all categories immediately.
 */
export function createSampleTestPhotoDataUrl(
  preset: 'portrait' | 'object' | 'scenery'
): string {
  const canvas = document.createElement('canvas');
  canvas.width = 720;
  canvas.height = 720;
  const ctx = canvas.getContext('2d');
  if (!ctx) return '';

  if (preset === 'portrait') {
    // Warm studio backdrop
    const bg = ctx.createRadialGradient(360, 290, 40, 360, 360, 480);
    bg.addColorStop(0, '#ded6cc');
    bg.addColorStop(0.65, '#9d8f82');
    bg.addColorStop(1, '#4c423b');
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, 720, 720);

    // Shoulders & blazer collar
    ctx.fillStyle = '#252936';
    ctx.beginPath();
    ctx.moveTo(115, 720);
    ctx.quadraticCurveTo(165, 530, 360, 520);
    ctx.quadraticCurveTo(555, 530, 605, 720);
    ctx.closePath();
    ctx.fill();

    // Inner white shirt V
    ctx.fillStyle = '#f2efe9';
    ctx.beginPath();
    ctx.moveTo(295, 525);
    ctx.lineTo(360, 650);
    ctx.lineTo(425, 525);
    ctx.closePath();
    ctx.fill();

    // Neck & cast shadow
    const neckGrad = ctx.createLinearGradient(310, 430, 410, 540);
    neckGrad.addColorStop(0, '#c88d71');
    neckGrad.addColorStop(1, '#e8b699');
    ctx.fillStyle = neckGrad;
    ctx.fillRect(312, 425, 96, 120);

    ctx.fillStyle = 'rgba(72, 34, 22, 0.35)';
    ctx.beginPath();
    ctx.ellipse(360, 445, 54, 26, 0, 0, Math.PI * 2);
    ctx.fill();

    // Hair back volume
    ctx.fillStyle = '#1f1614';
    ctx.beginPath();
    ctx.ellipse(360, 275, 165, 195, 0, 0, Math.PI * 2);
    ctx.fill();

    // Ears
    ctx.fillStyle = '#dea589';
    ctx.beginPath();
    ctx.ellipse(238, 305, 18, 34, -0.1, 0, Math.PI * 2);
    ctx.ellipse(482, 305, 18, 34, 0.1, 0, Math.PI * 2);
    ctx.fill();

    // Face contour with 3D directional lighting
    const faceGrad = ctx.createRadialGradient(330, 265, 25, 360, 300, 155);
    faceGrad.addColorStop(0, '#f8cfb7');
    faceGrad.addColorStop(0.55, '#e2a98d');
    faceGrad.addColorStop(1, '#b5785d');
    ctx.fillStyle = faceGrad;
    ctx.beginPath();
    ctx.moveTo(245, 255);
    ctx.quadraticCurveTo(245, 165, 360, 165);
    ctx.quadraticCurveTo(475, 165, 475, 255);
    ctx.quadraticCurveTo(472, 375, 420, 422);
    ctx.quadraticCurveTo(360, 462, 300, 422);
    ctx.quadraticCurveTo(248, 375, 245, 255);
    ctx.closePath();
    ctx.fill();

    // Cheek blush & cheekbone contour
    ctx.fillStyle = 'rgba(185, 90, 75, 0.18)';
    ctx.beginPath();
    ctx.ellipse(290, 340, 28, 18, 0, 0, Math.PI * 2);
    ctx.ellipse(430, 340, 28, 18, 0, 0, Math.PI * 2);
    ctx.fill();

    // Eyebrows
    ctx.strokeStyle = '#241815';
    ctx.lineWidth = 9;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(274, 258);
    ctx.quadraticCurveTo(306, 242, 336, 255);
    ctx.moveTo(446, 258);
    ctx.quadraticCurveTo(414, 242, 384, 255);
    ctx.stroke();

    // Eyes (sclera, iris, pupil, specular catchlight, upper lash)
    const drawEye = (cx: number, cy: number) => {
      ctx.fillStyle = '#f8f6f2';
      ctx.beginPath();
      ctx.ellipse(cx, cy, 24, 13, 0, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = '#4e3528';
      ctx.beginPath();
      ctx.arc(cx, cy, 11.5, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = '#0e0b0a';
      ctx.beginPath();
      ctx.arc(cx, cy, 6, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(cx - 4, cy - 4, 3, 0, Math.PI * 2);
      ctx.fill();

      ctx.strokeStyle = '#1b1210';
      ctx.lineWidth = 4.5;
      ctx.beginPath();
      ctx.moveTo(cx - 25, cy + 1);
      ctx.quadraticCurveTo(cx, cy - 16, cx + 25, cy + 1);
      ctx.stroke();
    };
    drawEye(306, 286);
    drawEye(414, 286);

    // Nose bridge & tip shadow
    ctx.strokeStyle = 'rgba(135, 82, 62, 0.72)';
    ctx.lineWidth = 3.5;
    ctx.beginPath();
    ctx.moveTo(356, 284);
    ctx.quadraticCurveTo(352, 330, 344, 344);
    ctx.quadraticCurveTo(360, 355, 376, 344);
    ctx.stroke();

    // Lips
    ctx.fillStyle = '#b45c58';
    ctx.beginPath();
    ctx.moveTo(322, 386);
    ctx.quadraticCurveTo(344, 373, 360, 378);
    ctx.quadraticCurveTo(376, 373, 398, 386);
    ctx.quadraticCurveTo(360, 412, 322, 386);
    ctx.fill();
    ctx.strokeStyle = '#753331';
    ctx.lineWidth = 2.4;
    ctx.beginPath();
    ctx.moveTo(324, 386);
    ctx.quadraticCurveTo(360, 391, 396, 386);
    ctx.stroke();

    // Front hair strands
    ctx.fillStyle = '#1a1210';
    ctx.beginPath();
    ctx.moveTo(220, 260);
    ctx.quadraticCurveTo(235, 130, 370, 125);
    ctx.quadraticCurveTo(495, 128, 502, 265);
    ctx.quadraticCurveTo(455, 195, 392, 188);
    ctx.quadraticCurveTo(325, 185, 220, 260);
    ctx.fill();

    // Hair highlight arcs
    ctx.strokeStyle = 'rgba(210, 190, 175, 0.25)';
    ctx.lineWidth = 3;
    for (let i = 0; i < 6; i++) {
      ctx.beginPath();
      ctx.moveTo(255 + i * 32, 165);
      ctx.quadraticCurveTo(310 + i * 25, 145, 360 + i * 20, 165);
      ctx.stroke();
    }
  } else if (preset === 'object') {
    // Still life: Classic Ceramic Pitcher, Sphere & Book on Studio Table
    const wall = ctx.createLinearGradient(0, 0, 720, 500);
    wall.addColorStop(0, '#ebe5db');
    wall.addColorStop(1, '#9f968a');
    ctx.fillStyle = wall;
    ctx.fillRect(0, 0, 720, 480);

    const table = ctx.createLinearGradient(0, 480, 0, 720);
    table.addColorStop(0, '#c6b59f');
    table.addColorStop(1, '#6f5f4d');
    ctx.fillStyle = table;
    ctx.fillRect(0, 480, 720, 240);

    // Table edge line
    ctx.strokeStyle = '#4f4234';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(0, 480);
    ctx.lineTo(720, 480);
    ctx.stroke();

    // Cast shadows
    ctx.fillStyle = 'rgba(40, 32, 24, 0.35)';
    ctx.beginPath();
    ctx.ellipse(395, 560, 165, 32, 0.05, 0, Math.PI * 2);
    ctx.fill();

    // Ceramic Vase / Pitcher
    const vaseGrad = ctx.createLinearGradient(230, 170, 410, 550);
    vaseGrad.addColorStop(0, '#f5f2ec');
    vaseGrad.addColorStop(0.5, '#b8ada0');
    vaseGrad.addColorStop(1, '#554d45');
    ctx.fillStyle = vaseGrad;
    ctx.beginPath();
    ctx.moveTo(285, 175);
    ctx.lineTo(365, 175);
    ctx.quadraticCurveTo(352, 235, 365, 275);
    ctx.quadraticCurveTo(435, 355, 405, 470);
    ctx.quadraticCurveTo(385, 548, 325, 552);
    ctx.quadraticCurveTo(265, 548, 245, 470);
    ctx.quadraticCurveTo(215, 355, 285, 275);
    ctx.quadraticCurveTo(298, 235, 285, 175);
    ctx.closePath();
    ctx.fill();

    // Rim ellipse
    ctx.fillStyle = '#3d3630';
    ctx.beginPath();
    ctx.ellipse(325, 175, 40, 12, 0, 0, Math.PI * 2);
    ctx.fill();

    // Handle
    ctx.strokeStyle = '#8b7f73';
    ctx.lineWidth = 18;
    ctx.beginPath();
    ctx.moveTo(356, 210);
    ctx.bezierCurveTo(455, 210, 460, 355, 392, 375);
    ctx.stroke();

    // Decorative bands on vase
    ctx.strokeStyle = '#474039';
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.ellipse(325, 360, 86, 16, 0, 0, Math.PI);
    ctx.stroke();

    // Studio Sphere beside vase
    const sphereGrad = ctx.createRadialGradient(485, 465, 12, 515, 495, 76);
    sphereGrad.addColorStop(0, '#ffffff');
    sphereGrad.addColorStop(0.45, '#b7bcc2');
    sphereGrad.addColorStop(1, '#2b3036');
    ctx.fillStyle = sphereGrad;
    ctx.beginPath();
    ctx.arc(510, 495, 74, 0, Math.PI * 2);
    ctx.fill();

    // Framed sketch card leaning behind
    ctx.strokeStyle = '#4b433b';
    ctx.lineWidth = 12;
    ctx.strokeRect(110, 260, 130, 230);
    ctx.fillStyle = '#e8dfd1';
    ctx.fillRect(116, 266, 118, 218);
  } else {
    // Scenery: Alpine Mountains, Sun, Pine Trees, Stone Bridge & River Reflection
    const sky = ctx.createLinearGradient(0, 0, 0, 440);
    sky.addColorStop(0, '#6a89a8');
    sky.addColorStop(0.55, '#bdd0e0');
    sky.addColorStop(1, '#f3dfc4');
    ctx.fillStyle = sky;
    ctx.fillRect(0, 0, 720, 440);

    // Sun glow
    ctx.fillStyle = '#fff5dc';
    ctx.beginPath();
    ctx.arc(535, 135, 44, 0, Math.PI * 2);
    ctx.fill();

    // Far mountains
    ctx.fillStyle = '#738294';
    ctx.beginPath();
    ctx.moveTo(0, 370);
    ctx.lineTo(130, 210);
    ctx.lineTo(255, 310);
    ctx.lineTo(395, 165);
    ctx.lineTo(540, 295);
    ctx.lineTo(665, 190);
    ctx.lineTo(720, 245);
    ctx.lineTo(720, 440);
    ctx.lineTo(0, 440);
    ctx.closePath();
    ctx.fill();

    // Sunlit mountain ridge faces
    ctx.fillStyle = '#aeb9c4';
    ctx.beginPath();
    ctx.moveTo(395, 165);
    ctx.lineTo(445, 315);
    ctx.lineTo(540, 295);
    ctx.closePath();
    ctx.fill();

    // Midground dark pine hills
    ctx.fillStyle = '#2d4137';
    ctx.beginPath();
    ctx.moveTo(0, 390);
    ctx.quadraticCurveTo(180, 340, 360, 385);
    ctx.quadraticCurveTo(540, 420, 720, 365);
    ctx.lineTo(720, 455);
    ctx.lineTo(0, 455);
    ctx.closePath();
    ctx.fill();

    // Pine tree silhouettes
    const drawPine = (px: number, py: number, s: number) => {
      ctx.fillStyle = '#192922';
      for (let t = 0; t < 3; t++) {
        ctx.beginPath();
        ctx.moveTo(px, py - s * (1.2 - t * 0.25));
        ctx.lineTo(px - s * (0.45 + t * 0.12), py - s * (0.45 - t * 0.22));
        ctx.lineTo(px + s * (0.45 + t * 0.12), py - s * (0.45 - t * 0.22));
        ctx.closePath();
        ctx.fill();
      }
    };
    [70, 115, 160, 580, 625, 675].forEach((x, i) =>
      drawPine(x, 425, 58 + (i % 2) * 18)
    );

    // Lake / River surface
    const water = ctx.createLinearGradient(0, 450, 0, 720);
    water.addColorStop(0, '#8ca0b0');
    water.addColorStop(0.5, '#597082');
    water.addColorStop(1, '#2c3d4a');
    ctx.fillStyle = water;
    ctx.fillRect(0, 450, 720, 270);

    // Classic Stone Arch Bridge
    ctx.fillStyle = '#47433e';
    ctx.beginPath();
    ctx.moveTo(190, 470);
    ctx.quadraticCurveTo(360, 425, 530, 470);
    ctx.lineTo(530, 520);
    ctx.lineTo(445, 520);
    ctx.arc(360, 520, 85, 0, Math.PI, true);
    ctx.lineTo(190, 520);
    ctx.closePath();
    ctx.fill();

    // Water ripples & bridge reflection
    ctx.strokeStyle = 'rgba(245, 240, 225, 0.45)';
    ctx.lineWidth = 2.5;
    for (let r = 0; r < 14; r++) {
      const ry = 535 + r * 12;
      const rw = 65 + Math.sin(r * 1.4) * 35;
      ctx.beginPath();
      ctx.moveTo(535 - rw * 0.6, ry);
      ctx.lineTo(535 + rw * 0.6, ry);
      ctx.stroke();
    }
  }

  return canvas.toDataURL('image/png');
}
