import { useSyncExternalStore } from 'react';

type AudioLevelListener = (level: number) => void;

class AudioLevelStore {
  private level = 0;
  private listeners = new Set<AudioLevelListener>();

  get(): number {
    return this.level;
  }

  set(nextLevel: number): void {
    const clamped = Number.isFinite(nextLevel) ? Math.max(0, Math.min(1, nextLevel)) : 0;
    // Skip redundant notifications for tiny jitter unless transitioning to/from zero
    if (
      Math.abs(clamped - this.level) < 0.008 &&
      !((clamped === 0 && this.level !== 0) || (clamped !== 0 && this.level === 0))
    ) {
      return;
    }
    this.level = clamped;
    this.listeners.forEach((listener) => {
      try {
        listener(clamped);
      } catch {
        // Ignore subscriber errors
      }
    });
  }

  subscribe(listener: AudioLevelListener): () => void {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }
}

export const audioLevelStore = new AudioLevelStore();

const subscribeStore = (onStoreChange: () => void) => audioLevelStore.subscribe(onStoreChange);
const getSnapshot = () => audioLevelStore.get();

export function useAudioLevel(): number {
  return useSyncExternalStore(subscribeStore, getSnapshot, () => 0);
}
