/**
 * Smart Battery, Flight Mode & System Voice Alert System for Zoya AI Companion
 * 
 * Strict Features:
 * 1. Charger Connected:
 *    - "Charging shuru ho gayi, power aa gaya. Abhi battery {PERCENT} percent hai."
 *    - If {PERCENT} >= 95: "Charging shuru ho gayi, power aa gaya. Battery already {PERCENT} percent hai, lagbhag full."
 * 2. Charger Disconnected:
 *    - "Power off ho gaya, charger nikal diya gaya. Abhi battery {PERCENT} percent hai."
 * 3. Low Battery Warnings (Only while NOT charging):
 *    - 20%: "Boss, battery sirf {PERCENT} percent bachi hai. Kripya charger laga dijiye, warna jaldi band ho sakta hai."
 *    - 10%: "Boss, battery bahut kam hai, sirf {PERCENT} percent! Abhi charger lagaiye, warna phone band ho jayega."
 *    - 3%:  "Boss, emergency! Battery sirf {PERCENT} percent hai, phone kabhi bhi band ho sakta hai. Turant charger lagaiye!"
 *    - Plays ONCE per discharge cycle per threshold.
 *    - Reset on charger connected or when level rises above threshold + 3%.
 *    - On jumps (e.g. 21% to 9%), speaks ONLY the most severe threshold crossed.
 *    - 3% warning is highest priority (interrupts lower priority announcement).
 * 4. Flight Mode Announcements:
 *    - ON: "Flight mode on ho gaya. Network aur internet band ho gaye hain."
 *    - OFF: "Flight mode off ho gaya. Network wapas aa raha hai."
 *    - Both use phone's built-in offline TTS (Android TextToSpeech / browser speechSynthesis).
 *    - Shows on-screen toast if TTS fails.
 * 5. App Install / Uninstall Announcements:
 *    - Install: "{APP_NAME} install ho gaya."
 *    - Uninstall: "{APP_NAME} uninstall ho gaya."
 * 6. Speaking + Microphone Coordination:
 *    - Integrates with central micStateMachine. Pauses wake-word & speech recognition during speech.
 *    - Queue drops items older than 15 seconds.
 *    - Never leaves mic stuck paused if TTS fails.
 */

import { BATTERY_ALERT_CONFIG, SystemAnnouncementsConfig } from './batteryAlertConfig';
import { micStateMachine } from '../speech/MicStateMachine';
import { agentClient } from '../agent/agentClient';

export interface BatteryAlertStatus {
  levelPercent: number; // 0 - 100
  isCharging: boolean;
  supported: boolean;
  source: 'Android BatteryManager' | 'Web Battery API' | 'Simulated Engine';
  enabled: boolean;
  chargingAnnouncementsEnabled: boolean;
  lowBatteryWarningsEnabled: boolean;
  flightModeAnnouncementsEnabled: boolean;
  appInstallAnnouncementsEnabled: boolean;
  isAirplaneMode: boolean;
  lastEvent: string;
  lastAnnouncement: string;
  lastAnnouncementTimestamp: number;
  announcedThresholds: {
    twenty: boolean;
    ten: boolean;
    three: boolean;
  };
}

export type BatteryStatusListener = (status: BatteryAlertStatus) => void;
export type BatterySpeaker = (text: string, onDone?: () => void) => void;

interface QueuedAnnouncement {
  id: string;
  text: string;
  priority: 'critical' | 'normal';
  isOfflineTts: boolean;
  createdAt: number;
  onDone?: () => void;
}

const STORAGE_KEY_MASTER_ENABLED = 'zoya_battery_voice_alerts_enabled';
const STORAGE_KEY_CHARGING_ENABLED = 'zoya_battery_charging_announcements_enabled';
const STORAGE_KEY_LOW_WARNINGS_ENABLED = 'zoya_battery_low_warnings_enabled';
const STORAGE_KEY_FLIGHT_MODE_ENABLED = 'zoya_flight_mode_announcements_enabled';
const STORAGE_KEY_APP_INSTALL_ENABLED = 'zoya_app_install_announcements_enabled';

const STORAGE_KEY_CYCLE_20 = 'zoya_battery_cycle_announced_20';
const STORAGE_KEY_CYCLE_10 = 'zoya_battery_cycle_announced_10';
const STORAGE_KEY_CYCLE_3 = 'zoya_battery_cycle_announced_3';
const STORAGE_KEY_LAST_CHARGING = 'zoya_battery_last_known_charging';
const STORAGE_KEY_LAST_LEVEL = 'zoya_battery_last_known_level';

export class BatteryAlertSystem {
  public config: SystemAnnouncementsConfig = BATTERY_ALERT_CONFIG;
  private isInitialized: boolean = false;
  private batteryManager: any = null;
  private primarySpeaker: BatterySpeaker | null = null;
  private listeners: Set<BatteryStatusListener> = new Set();

  // Internal State
  private levelPercent: number = 85;
  private isCharging: boolean = false;
  private supported: boolean = false;
  private source: 'Android BatteryManager' | 'Web Battery API' | 'Simulated Engine' = 'Simulated Engine';
  private isAirplaneMode: boolean = false;

  // Discharge Cycle Tracking
  private announced20: boolean = false;
  private announced10: boolean = false;
  private announced3: boolean = false;

  // Event Debouncing Timestamps
  private initialCheckDone: boolean = false;
  private lastChargingState: boolean | null = null;
  private lastLevelPercent: number = 85;
  private lastChargingToggleTime: number = 0;
  private lastFlightModeState: boolean | null = null;
  private lastFlightModeToggleTime: number = 0;
  private lastAppEventTime: number = 0;
  private lastAppEventKey: string = '';

  // UI status tracking
  private lastEventDescription: string = 'सिस्टम तैयार है';
  private lastAnnouncementText: string = '';
  private lastAnnouncementTime: number = 0;

  // Audio queue & concurrency management
  private announcementQueue: QueuedAnnouncement[] = [];
  private isCurrentlySpeaking: boolean = false;
  private currentSpeakingPriority: 'critical' | 'normal' | null = null;
  private ttsSafetyWatchdog: any = null;

  // In-memory fallback cache for toggles (supports SSR, testing, or restricted storage)
  private cachedMasterEnabled: boolean = true;
  private cachedChargingEnabled: boolean = true;
  private cachedLowWarningsEnabled: boolean = true;
  private cachedFlightModeEnabled: boolean = true;
  private cachedAppInstallEnabled: boolean = true;

  constructor() {
    this.loadPersistedState();
  }

  private loadPersistedState(): void {
    try {
      if (typeof localStorage !== 'undefined') {
        this.announced20 = localStorage.getItem(STORAGE_KEY_CYCLE_20) === 'true';
        this.announced10 = localStorage.getItem(STORAGE_KEY_CYCLE_10) === 'true';
        this.announced3 = localStorage.getItem(STORAGE_KEY_CYCLE_3) === 'true';

        const savedCharging = localStorage.getItem(STORAGE_KEY_LAST_CHARGING);
        if (savedCharging !== null) {
          this.lastChargingState = savedCharging === 'true';
          this.isCharging = this.lastChargingState;
        }

        const savedLevel = localStorage.getItem(STORAGE_KEY_LAST_LEVEL);
        if (savedLevel !== null) {
          const parsed = parseInt(savedLevel, 10);
          if (!isNaN(parsed) && parsed >= 0 && parsed <= 100) {
            this.lastLevelPercent = parsed;
            this.levelPercent = parsed;
          }
        }

        const m = localStorage.getItem(STORAGE_KEY_MASTER_ENABLED);
        if (m !== null) this.cachedMasterEnabled = m === 'true';
        const c = localStorage.getItem(STORAGE_KEY_CHARGING_ENABLED);
        if (c !== null) this.cachedChargingEnabled = c === 'true';
        const l = localStorage.getItem(STORAGE_KEY_LOW_WARNINGS_ENABLED);
        if (l !== null) this.cachedLowWarningsEnabled = l === 'true';
        const f = localStorage.getItem(STORAGE_KEY_FLIGHT_MODE_ENABLED);
        if (f !== null) this.cachedFlightModeEnabled = f === 'true';
        const a = localStorage.getItem(STORAGE_KEY_APP_INSTALL_ENABLED);
        if (a !== null) this.cachedAppInstallEnabled = a === 'true';
      }
    } catch {}
  }

  private savePersistedCycle(): void {
    try {
      if (typeof localStorage !== 'undefined') {
        localStorage.setItem(STORAGE_KEY_CYCLE_20, String(this.announced20));
        localStorage.setItem(STORAGE_KEY_CYCLE_10, String(this.announced10));
        localStorage.setItem(STORAGE_KEY_CYCLE_3, String(this.announced3));
        if (this.lastChargingState !== null) {
          localStorage.setItem(STORAGE_KEY_LAST_CHARGING, String(this.lastChargingState));
        }
        localStorage.setItem(STORAGE_KEY_LAST_LEVEL, String(this.levelPercent));
      }
    } catch {}
  }

  // =========================================================================
  // SETTINGS & PERSISTENCE
  // =========================================================================

  public isEnabled(): boolean {
    try {
      if (typeof window !== 'undefined' && (window as any).AndroidBridge?.isBatteryVoiceAlertsEnabled) {
        return Boolean((window as any).AndroidBridge.isBatteryVoiceAlertsEnabled());
      }
      if (typeof localStorage !== 'undefined') {
        const val = localStorage.getItem(STORAGE_KEY_MASTER_ENABLED);
        return val === null ? this.cachedMasterEnabled : val === 'true';
      }
    } catch {}
    return this.cachedMasterEnabled;
  }

  public setEnabled(enabled: boolean): void {
    this.cachedMasterEnabled = enabled;
    try {
      if (typeof localStorage !== 'undefined') {
        localStorage.setItem(STORAGE_KEY_MASTER_ENABLED, String(enabled));
      }
      if (typeof window !== 'undefined' && (window as any).AndroidBridge?.setBatteryVoiceAlertsEnabled) {
        (window as any).AndroidBridge.setBatteryVoiceAlertsEnabled(enabled);
      }
    } catch {}
    this.notifyListeners();
  }

  public isChargingAnnouncementsEnabled(): boolean {
    try {
      if (typeof window !== 'undefined' && (window as any).AndroidBridge?.isChargingAnnouncementsEnabled) {
        return Boolean((window as any).AndroidBridge.isChargingAnnouncementsEnabled());
      }
      if (typeof localStorage !== 'undefined') {
        const val = localStorage.getItem(STORAGE_KEY_CHARGING_ENABLED);
        return val === null ? this.cachedChargingEnabled : val === 'true';
      }
    } catch {}
    return this.cachedChargingEnabled;
  }

  public setChargingAnnouncementsEnabled(enabled: boolean): void {
    this.cachedChargingEnabled = enabled;
    try {
      if (typeof localStorage !== 'undefined') {
        localStorage.setItem(STORAGE_KEY_CHARGING_ENABLED, String(enabled));
      }
      if (typeof window !== 'undefined' && (window as any).AndroidBridge?.setChargingAnnouncementsEnabled) {
        (window as any).AndroidBridge.setChargingAnnouncementsEnabled(enabled);
      }
    } catch {}
    this.notifyListeners();
  }

  public isLowBatteryWarningsEnabled(): boolean {
    try {
      if (typeof window !== 'undefined' && (window as any).AndroidBridge?.isLowBatteryWarningsEnabled) {
        return Boolean((window as any).AndroidBridge.isLowBatteryWarningsEnabled());
      }
      if (typeof localStorage !== 'undefined') {
        const val = localStorage.getItem(STORAGE_KEY_LOW_WARNINGS_ENABLED);
        return val === null ? this.cachedLowWarningsEnabled : val === 'true';
      }
    } catch {}
    return this.cachedLowWarningsEnabled;
  }

  public setLowBatteryWarningsEnabled(enabled: boolean): void {
    this.cachedLowWarningsEnabled = enabled;
    try {
      if (typeof localStorage !== 'undefined') {
        localStorage.setItem(STORAGE_KEY_LOW_WARNINGS_ENABLED, String(enabled));
      }
      if (typeof window !== 'undefined' && (window as any).AndroidBridge?.setLowBatteryWarningsEnabled) {
        (window as any).AndroidBridge.setLowBatteryWarningsEnabled(enabled);
      }
    } catch {}
    this.notifyListeners();
  }

  public isFlightModeAnnouncementsEnabled(): boolean {
    try {
      if (typeof window !== 'undefined' && (window as any).AndroidBridge?.isFlightModeAnnouncementsEnabled) {
        return Boolean((window as any).AndroidBridge.isFlightModeAnnouncementsEnabled());
      }
      if (typeof localStorage !== 'undefined') {
        const val = localStorage.getItem(STORAGE_KEY_FLIGHT_MODE_ENABLED);
        return val === null ? this.cachedFlightModeEnabled : val === 'true';
      }
    } catch {}
    return this.cachedFlightModeEnabled;
  }

  public setFlightModeAnnouncementsEnabled(enabled: boolean): void {
    this.cachedFlightModeEnabled = enabled;
    try {
      if (typeof localStorage !== 'undefined') {
        localStorage.setItem(STORAGE_KEY_FLIGHT_MODE_ENABLED, String(enabled));
      }
      if (typeof window !== 'undefined' && (window as any).AndroidBridge?.setFlightModeAnnouncementsEnabled) {
        (window as any).AndroidBridge.setFlightModeAnnouncementsEnabled(enabled);
      }
    } catch {}
    this.notifyListeners();
  }

  public isAppInstallAnnouncementsEnabled(): boolean {
    try {
      if (typeof window !== 'undefined' && (window as any).AndroidBridge?.isAppInstallAnnouncementsEnabled) {
        return Boolean((window as any).AndroidBridge.isAppInstallAnnouncementsEnabled());
      }
      if (typeof localStorage !== 'undefined') {
        const val = localStorage.getItem(STORAGE_KEY_APP_INSTALL_ENABLED);
        return val === null ? this.cachedAppInstallEnabled : val === 'true';
      }
    } catch {}
    return this.cachedAppInstallEnabled;
  }

  public setAppInstallAnnouncementsEnabled(enabled: boolean): void {
    this.cachedAppInstallEnabled = enabled;
    try {
      if (typeof localStorage !== 'undefined') {
        localStorage.setItem(STORAGE_KEY_APP_INSTALL_ENABLED, String(enabled));
      }
      if (typeof window !== 'undefined' && (window as any).AndroidBridge?.setAppInstallAnnouncementsEnabled) {
        (window as any).AndroidBridge.setAppInstallAnnouncementsEnabled(enabled);
      }
    } catch {}
    this.notifyListeners();
  }

  // =========================================================================
  // INITIALIZATION & EVENT LISTENERS
  // =========================================================================

  public registerSpeaker(speaker: BatterySpeaker): void {
    this.primarySpeaker = speaker;
  }

  public async init(speaker?: BatterySpeaker): Promise<void> {
    if (speaker) {
      this.primarySpeaker = speaker;
    }

    if (this.isInitialized) return;
    this.isInitialized = true;

    // 1. Check Native Android Bridge
    const nativeHandled = this.checkNativeAndroidBridge();

    // 2. Web Battery Status API (if native not present)
    if (!nativeHandled && typeof navigator !== 'undefined' && 'getBattery' in navigator) {
      try {
        const battery = await (navigator as any).getBattery();
        this.batteryManager = battery;
        this.supported = true;
        this.source = 'Web Battery API';

        const updateFromWeb = (isInitial: boolean = false) => {
          const rawLevel = typeof battery.level === 'number' ? battery.level : 1.0;
          const pct = Math.max(0, Math.min(100, Math.round(rawLevel * 100)));
          const charging = Boolean(battery.charging);
          this.handleBatteryUpdate(pct, charging, isInitial);
        };

        battery.addEventListener('chargingchange', () => updateFromWeb(false));
        battery.addEventListener('levelchange', () => updateFromWeb(false));
        updateFromWeb(true);
      } catch (err) {
        console.warn('[BATTERY_SYSTEM] Web Battery API unavailable:', err);
      }
    }

    // 3. Android Bridge Events via Window CustomEvent
    if (typeof window !== 'undefined') {
      window.addEventListener('battery-status-changed', (e: any) => {
        const detail = e.detail || {};
        const pct = typeof detail.level === 'number' ? detail.level : this.levelPercent;
        const charging = typeof detail.isCharging === 'boolean' ? detail.isCharging : this.isCharging;
        this.source = 'Android BatteryManager';
        this.supported = true;
        this.handleBatteryUpdate(pct, charging, false);
      });

      // Airplane Mode Changed (Native Android)
      window.addEventListener('airplane-mode-changed', (e: any) => {
        const isAirplane = Boolean(e?.detail?.isAirplaneMode);
        this.handleFlightModeUpdate(isAirplane, false);
      });

      // Browser Fallback for Airplane Mode (online/offline events)
      window.addEventListener('offline', () => {
        // Only treat as flight mode hint if native Android bridge is not active
        if (!(window as any).AndroidBridge?.isAirplaneMode) {
          this.handleFlightModeUpdate(true, true);
        }
      });
      window.addEventListener('online', () => {
        if (!(window as any).AndroidBridge?.isAirplaneMode) {
          this.handleFlightModeUpdate(false, true);
        }
      });

      // App Installed (Native Android)
      window.addEventListener('app-installed', (e: any) => {
        const appName = e?.detail?.appName || 'App';
        this.handleAppInstalled(appName);
      });

      // App Uninstalled (Native Android)
      window.addEventListener('app-uninstalled', (e: any) => {
        const appName = e?.detail?.appName || 'App';
        this.handleAppUninstalled(appName);
      });

      // Visibility change to check missed thresholds on screen unlock
      document.addEventListener('visibilitychange', () => {
        if (document.visibilityState === 'visible') {
          this.pollCurrentState();
        }
      });
    }

    if (!this.supported) {
      this.supported = true;
      this.source = 'Simulated Engine';
      this.handleBatteryUpdate(this.levelPercent, this.isCharging, true);
    }
  }

  private checkNativeAndroidBridge(): boolean {
    if (typeof window === 'undefined') return false;
    const androidBridge = (window as any).AndroidBridge;

    if (androidBridge) {
      try {
        if (typeof androidBridge.isAirplaneMode === 'function') {
          this.isAirplaneMode = Boolean(androidBridge.isAirplaneMode());
        }
        if (typeof androidBridge.getBatteryLevel === 'function') {
          const lvl = androidBridge.getBatteryLevel();
          const charging = typeof androidBridge.isCharging === 'function' ? androidBridge.isCharging() : false;
          if (typeof lvl === 'number' && lvl >= 0) {
            this.supported = true;
            this.source = 'Android BatteryManager';
            this.handleBatteryUpdate(lvl, Boolean(charging), true);
            return true;
          }
        }
      } catch {}
    }
    return false;
  }

  private pollCurrentState(): void {
    if (this.batteryManager) {
      const rawLevel = typeof this.batteryManager.level === 'number' ? this.batteryManager.level : 1.0;
      const pct = Math.max(0, Math.min(100, Math.round(rawLevel * 100)));
      const charging = Boolean(this.batteryManager.charging);
      this.handleBatteryUpdate(pct, charging, false);
    } else {
      this.checkNativeAndroidBridge();
    }
  }

  // =========================================================================
  // CORE BATTERY EVENT LOGIC
  // =========================================================================

  public handleBatteryUpdate(levelPercent: number, isCharging: boolean, isInitialCheck: boolean = false): void {
    const clampedLevel = Math.max(0, Math.min(100, Math.round(levelPercent)));
    const now = Date.now();
    const previousCharging = this.lastChargingState;

    this.levelPercent = clampedLevel;
    this.isCharging = isCharging;

    // Contact bounce debounce: ignore repeats within debounceMs (2000ms)
    const isChargingToggled = previousCharging !== null && previousCharging !== isCharging;
    const isRapidFlicker = isChargingToggled && (now - this.lastChargingToggleTime < this.config.debounceMs);
    if (isChargingToggled) {
      this.lastChargingToggleTime = now;
    }

    // -------------------------------------------------------------------------
    // CASE A: INITIAL STARTUP / APP OPEN / UNLOCK
    // Opening or unlocking the phone must NOT trigger any charging/level speech.
    // However, if already below a threshold while closed, trigger the missed warning once.
    // -------------------------------------------------------------------------
    if (!this.initialCheckDone || isInitialCheck) {
      this.initialCheckDone = true;
      this.lastChargingState = isCharging;
      this.lastLevelPercent = clampedLevel;
      this.savePersistedCycle();

      if (isCharging) {
        this.resetDischargeCycle();
        this.notifyListeners();
        return;
      }

      // If discharging on startup, check if a low-battery threshold was ALREADY missed
      if (!isCharging && this.isLowBatteryWarningsEnabled() && this.isEnabled()) {
        if (clampedLevel <= this.config.thresholds.three) {
          if (!this.announced3) {
            this.announced3 = true;
            this.announced10 = true;
            this.announced20 = true;
            this.savePersistedCycle();
            const text = this.config.dialogues.lowBattery3.replace('{PERCENT}', String(clampedLevel));
            this.queueAnnouncement(text, 'critical', false, `मिस हुआ 3% अलर्ट (${clampedLevel}%)`);
          }
        } else if (clampedLevel <= this.config.thresholds.ten) {
          if (!this.announced10) {
            this.announced10 = true;
            this.announced20 = true;
            this.savePersistedCycle();
            const text = this.config.dialogues.lowBattery10.replace('{PERCENT}', String(clampedLevel));
            this.queueAnnouncement(text, 'normal', false, `मिस हुआ 10% अलर्ट (${clampedLevel}%)`);
          }
        } else if (clampedLevel <= this.config.thresholds.twenty) {
          if (!this.announced20) {
            this.announced20 = true;
            this.savePersistedCycle();
            const text = this.config.dialogues.lowBattery20.replace('{PERCENT}', String(clampedLevel));
            this.queueAnnouncement(text, 'normal', false, `मिस हुआ 20% अलर्ट (${clampedLevel}%)`);
          }
        }
      }

      this.notifyListeners();
      return;
    }

    // -------------------------------------------------------------------------
    // CASE B: CHARGER PLUGGED IN / UNPLUGGED TRANSITIONS
    // -------------------------------------------------------------------------
    if (previousCharging !== null && previousCharging !== isCharging && !isRapidFlicker) {
      this.lastChargingState = isCharging;
      this.savePersistedCycle();

      if (isCharging) {
        // PLUGGED IN: Reset low battery warning flags for next discharge cycle
        this.resetDischargeCycle();

        if (this.isChargingAnnouncementsEnabled() && this.isEnabled()) {
          const text = clampedLevel >= 95
            ? this.config.dialogues.chargerConnectedFull.replace('{PERCENT}', String(clampedLevel))
            : this.config.dialogues.chargerConnectedNormal.replace('{PERCENT}', String(clampedLevel));

          this.queueAnnouncement(text, 'normal', false, `चार्जर कनेक्टेड (${clampedLevel}%)`);
        }
        this.notifyListeners();
        return;
      } else {
        // UNPLUGGED:
        if (this.isChargingAnnouncementsEnabled() && this.isEnabled()) {
          const text = this.config.dialogues.chargerDisconnected.replace('{PERCENT}', String(clampedLevel));
          this.queueAnnouncement(text, 'normal', false, `चार्जर डिस्कनेक्टेड (${clampedLevel}%)`);
        }
        this.notifyListeners();
        return;
      }
    }

    // -------------------------------------------------------------------------
    // CASE C: LOW-BATTERY WARNINGS (Discharging Only)
    // While charging, NEVER speak low-battery warnings!
    // -------------------------------------------------------------------------
    if (!isCharging && this.isLowBatteryWarningsEnabled() && this.isEnabled()) {
      // Recovery hysteresis: reset threshold if battery rises above threshold + offset (3%)
      const { twenty, ten, three } = this.config.thresholds;
      const offset = this.config.hysteresisOffset;

      if (clampedLevel > twenty + offset) this.announced20 = false;
      if (clampedLevel > ten + offset) this.announced10 = false;
      if (clampedLevel > three + offset) this.announced3 = false;

      // Check thresholds: On jumps (e.g. 21% -> 9%), speak only the most severe threshold crossed
      if (clampedLevel <= three && !this.announced3) {
        // Crosses 3% (and possibly 10% and 20%)
        this.announced3 = true;
        this.announced10 = true;
        this.announced20 = true;
        this.savePersistedCycle();

        const text = this.config.dialogues.lowBattery3.replace('{PERCENT}', String(clampedLevel));
        this.queueAnnouncement(text, 'critical', false, `क्रिटिकल अलर्ट (3% सीमा: ${clampedLevel}%)`);
      } else if (clampedLevel <= ten && !this.announced10) {
        // Crosses 10% (and possibly 20%)
        this.announced10 = true;
        this.announced20 = true;
        this.savePersistedCycle();

        const text = this.config.dialogues.lowBattery10.replace('{PERCENT}', String(clampedLevel));
        this.queueAnnouncement(text, 'normal', false, `लो-बैटरी अलर्ट (10% सीमा: ${clampedLevel}%)`);
      } else if (clampedLevel <= twenty && !this.announced20) {
        // Crosses 20%
        this.announced20 = true;
        this.savePersistedCycle();

        const text = this.config.dialogues.lowBattery20.replace('{PERCENT}', String(clampedLevel));
        this.queueAnnouncement(text, 'normal', false, `लो-बैटरी चेतावनी (20% सीमा: ${clampedLevel}%)`);
      }
    }

    this.lastLevelPercent = clampedLevel;
    this.savePersistedCycle();
    this.notifyListeners();
  }

  public resetDischargeCycle(): void {
    this.announced20 = false;
    this.announced10 = false;
    this.announced3 = false;
    this.savePersistedCycle();
  }

  // =========================================================================
  // FLIGHT MODE (AIRPLANE MODE) ANNOUNCEMENTS (Offline TTS Required)
  // =========================================================================

  public handleFlightModeUpdate(isAirplaneMode: boolean, isBrowserApproximate: boolean = false): void {
    const now = Date.now();

    // Debounce repeats within 2000ms or if state is unchanged
    if (this.lastFlightModeState !== null && this.lastFlightModeState === isAirplaneMode) {
      return;
    }
    if (now - this.lastFlightModeToggleTime < this.config.debounceMs) {
      return;
    }

    this.lastFlightModeState = isAirplaneMode;
    this.lastFlightModeToggleTime = now;
    this.isAirplaneMode = isAirplaneMode;

    if (!this.isFlightModeAnnouncementsEnabled() || !this.isEnabled()) {
      this.notifyListeners();
      return;
    }

    const text = isAirplaneMode ? this.config.dialogues.flightModeOn : this.config.dialogues.flightModeOff;
    const desc = isAirplaneMode ? 'Flight Mode चालू (ON)' : 'Flight Mode बंद (OFF)';

    // Section 4: Flight mode announcements MUST use offline TTS (isOfflineTts = true)
    this.queueAnnouncement(text, 'normal', true, `${desc}${isBrowserApproximate ? ' (Browser)' : ''}`);
    this.notifyListeners();
  }

  // =========================================================================
  // APP INSTALL / UNINSTALL ANNOUNCEMENTS
  // =========================================================================

  public handleAppInstalled(appName: string): void {
    const now = Date.now();
    const key = `install_${appName}`;
    if (this.lastAppEventKey === key && now - this.lastAppEventTime < this.config.debounceMs) {
      return;
    }
    this.lastAppEventKey = key;
    this.lastAppEventTime = now;

    if (!this.isAppInstallAnnouncementsEnabled() || !this.isEnabled()) {
      return;
    }

    const text = this.config.dialogues.appInstalled.replace('{APP_NAME}', appName);
    this.queueAnnouncement(text, 'normal', false, `ऐप इंस्टॉल: ${appName}`);
  }

  public handleAppUninstalled(appName: string): void {
    const now = Date.now();
    const key = `uninstall_${appName}`;
    if (this.lastAppEventKey === key && now - this.lastAppEventTime < this.config.debounceMs) {
      return;
    }
    this.lastAppEventKey = key;
    this.lastAppEventTime = now;

    if (!this.isAppInstallAnnouncementsEnabled() || !this.isEnabled()) {
      return;
    }

    const text = this.config.dialogues.appUninstalled.replace('{APP_NAME}', appName);
    this.queueAnnouncement(text, 'normal', false, `ऐप अनइन्स्टॉल: ${appName}`);
  }

  // =========================================================================
  // QUEUE & MICROPHONE COORDINATION (Rule 8)
  // =========================================================================

  private queueAnnouncement(
    text: string,
    priority: 'critical' | 'normal',
    isOfflineTts: boolean,
    eventDesc: string,
    onDone?: () => void
  ): void {
    this.lastEventDescription = eventDesc;
    this.lastAnnouncementText = text;
    this.lastAnnouncementTime = Date.now();

    const item: QueuedAnnouncement = {
      id: `announcement_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      text,
      priority,
      isOfflineTts,
      createdAt: Date.now(),
      onDone,
    };

    const micSnap = micStateMachine.getSnapshot();
    const isCallActive = micSnap.activeCallType !== null && micSnap.activeCallType !== undefined;
    const isTtsActive = micStateMachine.isSpeaking() || this.isCurrentlySpeaking;

    // Critical 3% warning: If lower-priority speech is active and NO phone call is active, interrupt!
    if (priority === 'critical' && !isCallActive && isTtsActive && this.currentSpeakingPriority !== 'critical') {
      console.log('[BATTERY_SYSTEM] 🚨 Interrupting lower priority speech for 3% critical battery warning!');
      this.cancelCurrentSpeech();
      this.playAnnouncement(item);
      return;
    }

    // If currently busy speaking or during active call, push to queue
    if (isTtsActive || isCallActive) {
      console.log(`[BATTERY_SYSTEM] Assistant busy (speaking: ${isTtsActive}, call: ${isCallActive}). Queuing: "${text}"`);
      this.announcementQueue.push(item);
      return;
    }

    this.playAnnouncement(item);
  }

  private playAnnouncement(item: QueuedAnnouncement): void {
    // Check age before speaking: drop if older than queueMaxAgeMs (15 seconds)
    if (Date.now() - item.createdAt > this.config.queueMaxAgeMs) {
      console.warn(`[BATTERY_SYSTEM] Dropped stale announcement (>15s): "${item.text}"`);
      item.onDone?.();
      this.processNextInQueue();
      return;
    }

    this.isCurrentlySpeaking = true;
    this.currentSpeakingPriority = item.priority;

    // Coordinate with micStateMachine: pause wake-word and speech recognition
    micStateMachine.reportSpeakStart('battery_announcement');

    // 12-second safety watchdog: never leave mic stuck in speaking
    if (this.ttsSafetyWatchdog) {
      clearTimeout(this.ttsSafetyWatchdog);
    }
    this.ttsSafetyWatchdog = setTimeout(() => {
      console.warn('[BATTERY_SYSTEM] TTS playback watchdog fired (12s). Safely unlocking mic.');
      this.finishCurrentSpeaking(item);
    }, 12000);

    const onComplete = () => {
      this.finishCurrentSpeaking(item);
    };

    if (item.isOfflineTts) {
      // Must use offline TTS
      this.speakOffline(item.text, onComplete);
    } else if (this.primarySpeaker) {
      // Use primary natural TTS pipeline
      try {
        this.primarySpeaker(item.text, onComplete);
      } catch (err) {
        console.warn('[BATTERY_SYSTEM] Primary speaker failed, falling back to offline:', err);
        this.speakOffline(item.text, onComplete);
      }
    } else {
      // Standalone server TTS or offline fallback
      this.playNaturalServerAudio(item.text, onComplete);
    }
  }

  private finishCurrentSpeaking(item: QueuedAnnouncement): void {
    if (this.ttsSafetyWatchdog) {
      clearTimeout(this.ttsSafetyWatchdog);
      this.ttsSafetyWatchdog = null;
    }

    this.isCurrentlySpeaking = false;
    this.currentSpeakingPriority = null;

    // Report clean completion to micStateMachine to resume STANDBY
    micStateMachine.reportSpeakEnd('battery_announcement');

    try {
      item.onDone?.();
    } catch {}

    // Process next item in queue after short 250ms gap
    setTimeout(() => {
      this.processNextInQueue();
    }, 250);
  }

  private cancelCurrentSpeech(): void {
    if (this.ttsSafetyWatchdog) {
      clearTimeout(this.ttsSafetyWatchdog);
      this.ttsSafetyWatchdog = null;
    }
    this.isCurrentlySpeaking = false;
    this.currentSpeakingPriority = null;

    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      try {
        window.speechSynthesis.cancel();
      } catch {}
    }
    micStateMachine.reportSpeakInterrupted('battery_announcement');
  }

  private processNextInQueue(): void {
    if (this.isCurrentlySpeaking || this.announcementQueue.length === 0) {
      return;
    }

    const micSnap = micStateMachine.getSnapshot();
    if (micSnap.activeCallType) {
      // Call still active, keep in queue
      return;
    }

    while (this.announcementQueue.length > 0) {
      const nextItem = this.announcementQueue.shift()!;
      // Rule 8: Drop an announcement older than 15 seconds when its turn arrives
      if (Date.now() - nextItem.createdAt > this.config.queueMaxAgeMs) {
        console.warn(`[BATTERY_SYSTEM] Dropping queued announcement older than 15s: "${nextItem.text}"`);
        nextItem.onDone?.();
        continue;
      }

      this.playAnnouncement(nextItem);
      return;
    }
  }

  // =========================================================================
  // OFFLINE TTS & TOAST FALLBACK
  // =========================================================================

  public speakOffline(text: string, onDone?: () => void): void {
    let handled = false;

    // 1. Android Bridge Native Offline TextToSpeech
    if (typeof window !== 'undefined' && (window as any).AndroidBridge?.speakOffline) {
      try {
        const ok = (window as any).AndroidBridge.speakOffline(text);
        if (ok) {
          handled = true;
          // Approximate speech duration based on text length (min 1.8s)
          const duration = Math.max(1800, text.length * 80);
          setTimeout(() => onDone?.(), duration);
          return;
        }
      } catch (err) {
        console.warn('[BATTERY_SYSTEM] AndroidBridge.speakOffline failed:', err);
      }
    }

    // 2. Browser SpeechSynthesis (Built-in Offline Voice)
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      try {
        window.speechSynthesis.cancel();
        const utter = new SpeechSynthesisUtterance(text);
        utter.lang = 'hi-IN';
        utter.rate = 1.0;
        utter.pitch = 1.05;

        utter.onend = () => {
          onDone?.();
        };
        utter.onerror = (e) => {
          console.warn('[BATTERY_SYSTEM] SpeechSynthesis error:', e);
          this.showOnScreenToast(text);
          onDone?.();
        };

        window.speechSynthesis.speak(utter);
        handled = true;
        return;
      } catch (err) {
        console.warn('[BATTERY_SYSTEM] SpeechSynthesis throw:', err);
      }
    }

    // 3. Fallback: On-screen toast if TTS fails completely
    if (!handled) {
      this.showOnScreenToast(text);
      onDone?.();
    }
  }

  public showOnScreenToast(text: string): void {
    if (typeof window !== 'undefined') {
      console.log(`[BATTERY_SYSTEM] Toast notification: "${text}"`);
      window.dispatchEvent(
        new CustomEvent('zoya-system-toast', {
          detail: {
            message: text,
            type: 'info',
            timestamp: Date.now(),
          },
        })
      );
    }
  }

  private async playNaturalServerAudio(text: string, onDone?: () => void): Promise<void> {
    try {
      const res = await fetch('/api/tts', {
        method: 'POST',
        headers: agentClient.getOwnerFetchHeaders({ 'Content-Type': 'application/json' }),
        credentials: 'include',
        body: JSON.stringify({
          text,
          language: 'hi-IN',
        }),
      });

      const contentType = res.headers.get('content-type') || '';
      if (!contentType.includes('application/json')) {
        this.speakOffline(text, onDone);
        return;
      }

      const data = await res.json();
      if (data && data.audioData) {
        const raw = atob(data.audioData);
        const bytes = new Uint8Array(raw.length);
        for (let i = 0; i < raw.length; i++) {
          bytes[i] = raw.charCodeAt(i);
        }
        const blob = new Blob([bytes], { type: data.mimeType || 'audio/wav' });
        const blobUrl = URL.createObjectURL(blob);
        const audio = new Audio(blobUrl);

        audio.onended = () => {
          URL.revokeObjectURL(blobUrl);
          onDone?.();
        };
        audio.onerror = () => {
          URL.revokeObjectURL(blobUrl);
          this.speakOffline(text, onDone);
        };

        await audio.play();
        return;
      }
      this.speakOffline(text, onDone);
    } catch {
      this.speakOffline(text, onDone);
    }
  }

  // =========================================================================
  // SIMULATION & TEST BUTTON METHODS (For Settings UI)
  // =========================================================================

  public simulateEvent(
    type:
      | 'connected'
      | 'connected_full'
      | 'disconnected'
      | '20'
      | '10'
      | '3'
      | 'flight_on'
      | 'flight_off'
      | 'app_install'
      | 'app_uninstall'
      | 'custom',
    customLevel?: number
  ): void {
    // Reset debounce timers for explicit user manual test buttons
    this.lastChargingToggleTime = 0;
    this.lastFlightModeToggleTime = 0;
    this.lastAppEventTime = 0;
    this.lastFlightModeState = null;

    switch (type) {
      case 'connected':
        this.lastChargingState = false;
        this.handleBatteryUpdate(customLevel ?? 65, true, false);
        break;
      case 'connected_full':
        this.lastChargingState = false;
        this.handleBatteryUpdate(customLevel ?? 96, true, false);
        break;
      case 'disconnected':
        this.lastChargingState = true;
        this.handleBatteryUpdate(customLevel ?? 60, false, false);
        break;
      case '20':
        this.announced20 = false;
        this.lastChargingState = false;
        this.handleBatteryUpdate(20, false, false);
        break;
      case '10':
        this.announced10 = false;
        this.lastChargingState = false;
        this.handleBatteryUpdate(10, false, false);
        break;
      case '3':
        this.announced3 = false;
        this.lastChargingState = false;
        this.handleBatteryUpdate(3, false, false);
        break;
      case 'flight_on':
        this.handleFlightModeUpdate(true, false);
        break;
      case 'flight_off':
        this.handleFlightModeUpdate(false, false);
        break;
      case 'app_install':
        this.handleAppInstalled('WhatsApp');
        break;
      case 'app_uninstall':
        this.handleAppUninstalled('WhatsApp');
        break;
      case 'custom':
        if (typeof customLevel === 'number') {
          this.handleBatteryUpdate(customLevel, this.isCharging, false);
        }
        break;
    }
  }

  // =========================================================================
  // STATUS & LISTENERS
  // =========================================================================

  public getStatus(): BatteryAlertStatus {
    return {
      levelPercent: this.levelPercent,
      isCharging: this.isCharging,
      supported: this.supported,
      source: this.source,
      enabled: this.isEnabled(),
      chargingAnnouncementsEnabled: this.isChargingAnnouncementsEnabled(),
      lowBatteryWarningsEnabled: this.isLowBatteryWarningsEnabled(),
      flightModeAnnouncementsEnabled: this.isFlightModeAnnouncementsEnabled(),
      appInstallAnnouncementsEnabled: this.isAppInstallAnnouncementsEnabled(),
      isAirplaneMode: this.isAirplaneMode,
      lastEvent: this.lastEventDescription,
      lastAnnouncement: this.lastAnnouncementText,
      lastAnnouncementTimestamp: this.lastAnnouncementTime,
      announcedThresholds: {
        twenty: this.announced20,
        ten: this.announced10,
        three: this.announced3,
      },
    };
  }

  public addListener(listener: BatteryStatusListener): void {
    this.listeners.add(listener);
    listener(this.getStatus());
  }

  public removeListener(listener: BatteryStatusListener): void {
    this.listeners.delete(listener);
  }

  private notifyListeners(): void {
    const status = this.getStatus();
    this.listeners.forEach((l) => {
      try {
        l(status);
      } catch {}
    });
  }
}

export const batteryAlertSystem = new BatteryAlertSystem();
