import sys
# Fixed bug
def calc(a, b):
    return a + b

assert calc(2, 3) == 5, "calc(2, 3) != 5"
print("ALL_TESTS_PASSED")
