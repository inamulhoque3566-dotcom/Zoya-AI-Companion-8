export const formatNumber = (n: number) => `Val: ${n}`;
