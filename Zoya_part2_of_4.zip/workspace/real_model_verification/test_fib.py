import unittest
from fibonacci import fib

class TestFibonacci(unittest.TestCase):
    def test_base_cases(self):
        self.assertEqual(fib(0), 0)
        self.assertEqual(fib(1), 1)

    def test_positive_integers(self):
        self.assertEqual(fib(2), 1)
        self.assertEqual(fib(3), 2)
        self.assertEqual(fib(4), 3)
        self.assertEqual(fib(5), 5)
        self.assertEqual(fib(10), 55)
        self.assertEqual(fib(20), 6765)

    def test_invalid_input_negative(self):
        with self.assertRaises(ValueError):
            fib(-1)
        with self.assertRaises(ValueError):
            fib(-10)

    def test_invalid_input_type(self):
        with self.assertRaises(TypeError):
            fib("5")
        with self.assertRaises(TypeError):
            fib(3.5)

if __name__ == "__main__":
    unittest.main()
