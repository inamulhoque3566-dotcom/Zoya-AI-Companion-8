import { chromium } from 'playwright';
import fs from 'fs';
import path from 'path';

async function verify14LivingAvatars() {
  console.log('🚀 Starting 14 Living Avatars Verification with Playwright...');
  const browser = await chromium.launch({
    headless: true,
    args: ['--no-sandbox', '--disable-setuid-sandbox', '--use-gl=angle', '--use-angle=swiftshader'],
  });

  const page = await browser.newPage({
    viewport: { width: 1440, height: 900 },
  });

  const proofDir = path.resolve('public/assets/proof');
  if (!fs.existsSync(proofDir)) {
    fs.mkdirSync(proofDir, { recursive: true });
  }

  try {
    await page.goto('http://localhost:3000', { waitUntil: 'networkidle', timeout: 30000 });
    console.log('✓ Home page loaded');

    // Click 14 avatars button in header
    const showcaseBtn = page.locator('[data-testid="header-14-avatars-btn"]');
    await showcaseBtn.waitFor({ state: 'visible', timeout: 10000 });
    await showcaseBtn.click();
    console.log('✓ Clicked 14 Living Avatars Showcase button');

    // Wait for the WebGL canvas
    const canvas = page.locator('[data-testid="all-14-avatars-canvas"]');
    await canvas.waitFor({ state: 'visible', timeout: 10000 });
    console.log('✓ All 14 Avatars WebGL Canvas mounted and visible');

    // Allow 1.5 seconds for textures to load and hair breeze motion to initialize
    await page.waitForTimeout(1500);

    // Save Frame 1: Standard Showcase view
    const frame1Path = path.join(proofDir, 'living_14_avatars_frame_1.png');
    await page.screenshot({ path: frame1Path, fullPage: true });
    console.log(`✓ Frame 1 captured: ${frame1Path}`);

    // Trigger test blink button
    const testBlinkBtn = page.getByRole('button', { name: /Test Blink/i });
    if (await testBlinkBtn.isVisible()) {
      await testBlinkBtn.click();
      console.log('✓ Triggered Test Blink across avatars');
      await page.waitForTimeout(120); // Mid-blink capture
      const frame2Path = path.join(proofDir, 'living_14_avatars_frame_2_blink.png');
      await page.screenshot({ path: frame2Path, fullPage: true });
      console.log(`✓ Frame 2 (Blink Cycle) captured: ${frame2Path}`);
    }

    // Toggle Clean Shot (No Text) Mode
    const cleanShotBtn = page.getByRole('button', { name: /Clean Shot/i });
    if (await cleanShotBtn.isVisible()) {
      await cleanShotBtn.click();
      console.log('✓ Switched to Clean Shot (No Text / Pure Locked-off Camera)');
      await page.waitForTimeout(500);
      const frame3Path = path.join(proofDir, 'living_14_avatars_frame_3_clean_shot.png');
      await page.screenshot({ path: frame3Path, fullPage: true });
      console.log(`✓ Frame 3 (Pure Clean Shot, Zero Text) captured: ${frame3Path}`);
    }

    console.log('🎉 14 Living Avatars verification completed successfully!');
  } catch (err) {
    console.error('❌ Verification failed:', err);
    process.exitCode = 1;
  } finally {
    await browser.close();
  }
}

verify14LivingAvatars();
