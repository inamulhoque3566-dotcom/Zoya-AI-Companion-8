const sharp = require('sharp');

async function inspectJpgBottomRight() {
  const jpg = await sharp('pristine_sources/avatar_midnight_gold_zari_saree.jpg')
    .raw()
    .toBuffer({ resolveWithObject: true });

  const w = jpg.info.width;
  const h = jpg.info.height;

  // Let's check what is at (950, 1400): [254, 221, 204] - that's peach/pink! That is the saree pallu or border trail!
  // In the PNG, is it included?
  const png = await sharp('public/assets/aistudio/file_00000000c0d4821189e14bf178224f8d_f1687d5b.png')
    .raw()
    .toBuffer({ resolveWithObject: true });

  const cur = await sharp('public/assets/images/avatars_3d/transparent/avatar_midnight_gold_zari_saree.png')
    .raw()
    .toBuffer({ resolveWithObject: true });

  console.log('At (950, 1400):');
  const idx = (1400 * w + 950) * 4;
  console.log('PNG:', png.data[idx], png.data[idx+1], png.data[idx+2], png.data[idx+3]);
  console.log('CUR:', cur.data[idx], cur.data[idx+1], cur.data[idx+2], cur.data[idx+3]);

  // Now let's inspect the feet in the JPG!
  // Where would feet be? Between x=350 and 650, around y=1450..1536.
  // In the JPG, is there floor shadow under the hem?
  // Let's print out what colors are in the JPG around center bottom:
  console.log('\nJPG center bottom rows (y=1490..1535):');
  for (let y = 1490; y < 1536; y += 10) {
    let rowDesc = [];
    for (let x = 380; x <= 620; x += 30) {
      const p = (y * w + x) * 3;
      rowDesc.push(`x${x}:[${jpg.data[p]},${jpg.data[p+1]},${jpg.data[p+2]}]`);
    }
    console.log(`y=${y}:`, rowDesc.join(' '));
  }
}

inspectJpgBottomRight().catch(console.error);
