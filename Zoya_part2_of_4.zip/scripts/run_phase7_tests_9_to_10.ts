import path from 'path';
import { AgentAuthManager } from '../src/services/agent/agentAuth.js';
import { execSync } from 'child_process';

const BASE_URL = 'http://localhost:3000';
const BROWSER_UA = 'Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36';
const OWNER_PASSPHRASE = 'OwnerSecurePassphrase2026!';

let sessionCookie: string | null = null;

async function req(endpoint: string, options: any = {}) {
  const url = `${BASE_URL}${endpoint}`;
  const headers: Record<string, string> = {
    'User-Agent': BROWSER_UA,
    'Content-Type': 'application/json',
    ...(options.headers || {}),
  };
  if (sessionCookie && !headers['Cookie'] && !headers['cookie']) {
    headers['Cookie'] = sessionCookie;
  }
  const res = await fetch(url, {
    ...options,
    headers,
    body: options.body ? (typeof options.body === 'string' ? options.body : JSON.stringify(options.body)) : undefined,
  });
  const text = await res.text();
  let json: any = null;
  try {
    json = JSON.parse(text);
  } catch {}

  const setCookie = res.headers.get('set-cookie');
  if (setCookie) {
    const match = setCookie.match(/zoya_approval_session=([^;]+)/);
    if (match) {
      sessionCookie = `zoya_approval_session=${match[1]}`;
    }
  }

  return { status: res.status, headers: res.headers, raw: text, data: json };
}

async function runTests9And10() {
  console.log('--- AUTH BOOTSTRAP ---');
  const setupCode = AgentAuthManager.getOrCreateSetupCode();
  try {
    AgentAuthManager.setOwnerPassphraseWithSetupCode(OWNER_PASSPHRASE, setupCode);
  } catch {}

  await req('/api/agent/auth/owner/login', {
    method: 'POST',
    body: { passphrase: OWNER_PASSPHRASE },
  });

  const pairRes = await req('/api/agent/auth/pairing-code', {
    method: 'POST',
    body: { passphrase: OWNER_PASSPHRASE },
  });
  const pairingCode = pairRes.data?.pairingCode;

  const tokenRes = await req('/api/agent/auth/token', {
    headers: { 'x-agent-pairing-code': pairingCode },
  });
  const token = tokenRes.data?.token;

  const authHeaders = {
    Authorization: `Bearer ${token}`,
  };

  // ========================================================================
  // TEST 9: Run a successful project build (npm run build)
  // ========================================================================
  console.log('\n=== TEST 9: Project Build (npm run build) ===');
  let buildOutput = '';
  let buildExitCode = 0;
  try {
    buildOutput = execSync('npm run build', { encoding: 'utf8', stdio: ['pipe', 'pipe', 'pipe'] });
  } catch (err: any) {
    buildExitCode = err.status || 1;
    buildOutput = (err.stdout || '') + '\n' + (err.stderr || '');
  }

  console.log(`[TEST 9 BUILD EXIT]: ${buildExitCode}`);
  console.log(`[TEST 9 BUILD SNIPPET]:\n${buildOutput.split('\n').filter(l => l.includes('dist') || l.includes('built in') || l.includes('vite') || l.includes('esbuild') || l.includes('server')).join('\n')}`);
  const pass9 = buildExitCode === 0;
  console.log(`[TEST 9 RESULT]: ${pass9 ? 'PASS' : 'FAIL'}`);

  // ========================================================================
  // TEST 10: Disable and remove the imported skill safely (ls before and after)
  // ========================================================================
  console.log('\n=== TEST 10: Disable and Remove Skill Safely ===');
  const installedDir = path.join(process.cwd(), 'data', 'agent_skills', 'installed');

  const lsBefore = execSync(`ls -1 "${installedDir}"`, { encoding: 'utf8' }).trim().split('\n');
  console.log(`[TEST 10 LS BEFORE]: [${lsBefore.join(', ')}]`);

  const disableRes = await req('/api/agent/skills/algorithmic-art/disable', {
    method: 'POST',
    headers: authHeaders,
  });
  console.log(`[TEST 10 DISABLE STATUS]: ${disableRes.status}`);

  const deleteRes = await req('/api/agent/skills/algorithmic-art', {
    method: 'DELETE',
    headers: authHeaders,
  });
  console.log(`[TEST 10 DELETE STATUS]: ${deleteRes.status}`);
  console.log(`[TEST 10 DELETE RAW]: ${deleteRes.raw}`);

  const lsAfter = execSync(`ls -1 "${installedDir}"`, { encoding: 'utf8' }).trim().split('\n');
  console.log(`[TEST 10 LS AFTER]: [${lsAfter.join(', ')}]`);

  const pass10 = disableRes.status === 200 && deleteRes.status === 200 && !lsAfter.includes('algorithmic-art');
  console.log(`[TEST 10 RESULT]: ${pass10 ? 'PASS' : 'FAIL'}`);

  if (!pass9 || !pass10) {
    process.exit(1);
  }
}

runTests9And10().catch((err) => {
  console.error('Tests 9-10 Failed:', err);
  process.exit(1);
});
