const sharp = require('sharp');

async function inspectAvatarBCarefully() {
  const src = await sharp('public/assets/aistudio/file_00000000c0d4821189e14bf178224f8d_f1687d5b.png')
    .raw()
    .toBuffer({ resolveWithObject: true });

  const w = src.info.width;
  const h = src.info.height;

  // Let's inspect:
  // 1. Hands: left hand ~ (x: 200..320, y: 480..680), right hand ~ (x: 700..850, y: 550..800)
  // 2. Saree hem: y: 1350..1536
  // 3. Sides of body: waist/hips/pallu
  // 4. Hair halos
  console.log('Inspecting Avatar B source alpha distribution...');
  let semiTransCount = 0;
  for (let i = 0; i < src.data.length; i += 4) {
    const a = src.data[i + 3];
    if (a > 10 && a < 235) semiTransCount++;
  }
  console.log(`Semi-transparent pixels (sheer saree fabric & anti-aliased edges): ${semiTransCount}`);

  // Check bottom hem: y > 1520
  // Are there feet? In pristine_sources/avatar_midnight_gold_zari_saree.jpg, the saree is a floor-length royal saree extending all the way to the floor with an ornate gold zari border!
  console.log('\n--- Bottom hem analysis (y=1500..1536) ---');
  for (let y = 1500; y < h; y += 5) {
    let rowAlphas = 0, rowDark = 0, rowGold = 0, rowSkin = 0;
    for (let x = 0; x < w; x++) {
      const idx = (y * w + x) * 4;
      const a = src.data[idx + 3];
      if (a > 20) {
        rowAlphas++;
        const r = src.data[idx], g = src.data[idx+1], b = src.data[idx+2];
        if (r > 150 && g > 110 && b < 100) rowGold++;
        else if (r > 180 && g > 140 && b > 130) rowSkin++;
        else if (r < 40 && g < 40 && b < 40) rowDark++;
      }
    }
    console.log(`y=${y}: active=${rowAlphas}, goldZari=${rowGold}, skin=${rowSkin}, darkFabric=${rowDark}`);
  }
}

inspectAvatarBCarefully().catch(console.error);
