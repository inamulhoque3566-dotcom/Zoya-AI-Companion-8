import path from 'path';
import { AgentAuthManager } from '../src/services/agent/agentAuth.js';
import fs from 'fs';

const BASE_URL = 'http://localhost:3000';
const BROWSER_UA = 'Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36';
const OWNER_PASSPHRASE = 'OwnerSecurePassphrase2026!';

let sessionCookie: string | null = null;

async function req(endpoint: string, options: any = {}) {
  const url = `${BASE_URL}${endpoint}`;
  const headers: Record<string, string> = {
    'User-Agent': BROWSER_UA,
    'Content-Type': 'application/json',
    ...(options.headers || {}),
  };
  if (sessionCookie && !headers['Cookie'] && !headers['cookie']) {
    headers['Cookie'] = sessionCookie;
  }
  const res = await fetch(url, {
    ...options,
    headers,
    body: options.body ? (typeof options.body === 'string' ? options.body : JSON.stringify(options.body)) : undefined,
  });
  const text = await res.text();
  let json: any = null;
  try {
    json = JSON.parse(text);
  } catch {}

  const setCookie = res.headers.get('set-cookie');
  if (setCookie) {
    const match = setCookie.match(/zoya_approval_session=([^;]+)/);
    if (match) {
      sessionCookie = `zoya_approval_session=${match[1]}`;
    }
  }

  return { status: res.status, headers: res.headers, raw: text, data: json };
}

async function runRedoneTest3And4() {
  console.log('--- AUTH BOOTSTRAP ---');
  const setupCode = AgentAuthManager.getOrCreateSetupCode();
  try {
    AgentAuthManager.setOwnerPassphraseWithSetupCode(OWNER_PASSPHRASE, setupCode);
  } catch {}

  await req('/api/agent/auth/owner/login', {
    method: 'POST',
    body: { passphrase: OWNER_PASSPHRASE },
  });

  const pairRes = await req('/api/agent/auth/pairing-code', {
    method: 'POST',
    body: { passphrase: OWNER_PASSPHRASE },
  });
  const pairingCode = pairRes.data?.pairingCode;

  const tokenRes = await req('/api/agent/auth/token', {
    headers: { 'x-agent-pairing-code': pairingCode },
  });
  const token = tokenRes.data?.token;

  const authHeaders = {
    Authorization: `Bearer ${token}`,
  };

  console.log(`[AUTH] Session Cookie: ${sessionCookie}`);

  // Create test skill script in installed skill that prints id
  const skillDir = path.join(process.cwd(), 'data', 'agent_skills', 'installed', 'algorithmic-art');
  const scriptPath = path.join(skillDir, 'print_identity.py');
  fs.writeFileSync(scriptPath, 'import os, subprocess\nprint("MARKER: ZOYA_PHASE7_SCRIPT_EXEC")\nsubprocess.run(["id"])\n', 'utf8');

  // ========================================================================
  // TEST 3: Skill script execution approval lifecycle
  // ========================================================================
  console.log('\n=== TEST 3a: Run skill script WITHOUT approval -> Must be refused ===');
  const unapprovedRun = await req('/api/agent/skills/algorithmic-art/run', {
    method: 'POST',
    headers: authHeaders,
    body: {
      scriptPath: 'print_identity.py',
      args: [],
    },
  });
  console.log(`[TEST 3a STATUS]: ${unapprovedRun.status}`);
  console.log(`[TEST 3a RAW]: ${unapprovedRun.raw}`);
  const pending3 = unapprovedRun.data?.pendingApproval;
  const pass3a = unapprovedRun.status === 202 && Boolean(pending3?.id);

  console.log('\n=== TEST 3b: Approve via real user cookie flow ===');
  const approveRes3 = await req(`/api/agent/approvals/${pending3.id}/respond`, {
    method: 'POST',
    body: { approve: true },
  });
  console.log(`[TEST 3b STATUS]: ${approveRes3.status}`);
  console.log(`[TEST 3b RAW]: ${approveRes3.raw}`);
  const pass3b = approveRes3.status === 200 && approveRes3.data?.success === true;

  console.log('\n=== TEST 3c: Run script with consumed approval -> uid=1000(appuser) in stdout ===');
  const approvedRun = await req('/api/agent/skills/algorithmic-art/run', {
    method: 'POST',
    headers: authHeaders,
    body: {
      scriptPath: 'print_identity.py',
      args: [],
      approvalId: pending3.id,
    },
  });
  console.log(`[TEST 3c STATUS]: ${approvedRun.status}`);
  console.log(`[TEST 3c RAW]: ${approvedRun.raw}`);
  const stdout3 = approvedRun.data?.result?.stdout || '';
  const pass3c = approvedRun.status === 200 && stdout3.includes('uid=1000(appuser)') && stdout3.includes('MARKER: ZOYA_PHASE7_SCRIPT_EXEC');
  console.log(`[TEST 3 RESULT]: ${pass3a && pass3b && pass3c ? 'PASS' : 'FAIL'}`);

  // ========================================================================
  // TEST 4: MCP Tool call approval lifecycle (verifying approved: true bypass is blocked)
  // ========================================================================
  console.log('\n=== TEST 4a: Call MCP tool without user cookie approval (testing approved: true body) ===');
  const workspaceRoot = path.join(process.cwd(), 'workspace');
  const serverPath = path.join(process.cwd(), 'node_modules', '@modelcontextprotocol', 'server-filesystem', 'dist', 'index.js');

  const mcpReg = await req('/api/agent/mcp/servers', {
    method: 'POST',
    headers: authHeaders,
    body: {
      name: 'phase7-fs-mcp2',
      transport: 'stdio',
      command: process.execPath,
      args: [serverPath, workspaceRoot],
      cwd: workspaceRoot,
      allowNetwork: false,
      approved: true,
    },
  });
  const serverId = mcpReg.data?.server?.id;

  await req(`/api/agent/mcp/servers/${serverId}/connect`, {
    method: 'POST',
    headers: authHeaders,
    body: { approved: true },
  });

  // Client attempts to pass "approved: true" without real approvalId
  const unapprovedMcpCall = await req('/api/agent/mcp/tools/call', {
    method: 'POST',
    headers: authHeaders,
    body: {
      serverId,
      toolName: 'list_directory',
      arguments: { path: workspaceRoot },
      approved: true, // Should NOT bypass approval
    },
  });
  console.log(`[TEST 4a STATUS]: ${unapprovedMcpCall.status}`);
  console.log(`[TEST 4a RAW]: ${unapprovedMcpCall.raw}`);
  const pending4 = unapprovedMcpCall.data?.pendingApproval;
  const pass4a = unapprovedMcpCall.status === 202 && Boolean(pending4?.id);

  console.log('\n=== TEST 4b: Approve MCP tool via real user cookie flow ===');
  const approveRes4 = await req(`/api/agent/approvals/${pending4.id}/respond`, {
    method: 'POST',
    body: { approve: true },
  });
  console.log(`[TEST 4b STATUS]: ${approveRes4.status}`);
  console.log(`[TEST 4b RAW]: ${approveRes4.raw}`);
  const pass4b = approveRes4.status === 200 && approveRes4.data?.success === true;

  console.log('\n=== TEST 4c: Call MCP tool with consumed approvalId ===');
  const approvedMcpCall = await req('/api/agent/mcp/tools/call', {
    method: 'POST',
    headers: authHeaders,
    body: {
      serverId,
      toolName: 'list_directory',
      arguments: { path: workspaceRoot },
      approvalId: pending4.id,
    },
  });
  console.log(`[TEST 4c STATUS]: ${approvedMcpCall.status}`);
  console.log(`[TEST 4c RAW]: ${approvedMcpCall.raw}`);
  const pass4c = approvedMcpCall.status === 200 && approvedMcpCall.data?.success === true;

  // Cleanup
  await req(`/api/agent/mcp/servers/${serverId}`, {
    method: 'DELETE',
    headers: authHeaders,
  });

  console.log(`[TEST 4 RESULT]: ${pass4a && pass4b && pass4c ? 'PASS' : 'FAIL'}`);

  if (!pass3a || !pass3b || !pass3c || !pass4a || !pass4b || !pass4c) {
    process.exit(1);
  }
}

runRedoneTest3And4().catch((e) => {
  console.error('Test 3 & 4 Redo Failed:', e);
  process.exit(1);
});
