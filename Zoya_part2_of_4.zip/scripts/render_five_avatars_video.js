import { chromium } from 'playwright';
import { spawn } from 'child_process';
import path from 'path';
import fs from 'fs';

async function main() {
  console.log('=== STARTING 5 LIVING AVATARS MP4 VIDEO GENERATION ===');
  const outputDir = path.join(process.cwd(), 'public', 'assets', 'videos');
  if (!fs.existsSync(outputDir)) {
    fs.mkdirSync(outputDir, { recursive: true });
  }

  const outputPath = path.join(outputDir, 'five_avatars_living_video.mp4');
  console.log('Target output video:', outputPath);

  const browser = await chromium.launch({
    executablePath: '/ms-playwright/chromium_headless_shell-1247/chrome-headless-shell-linux64/chrome-headless-shell',
    args: ['--no-sandbox', '--disable-setuid-sandbox']
  });

  const page = await browser.newPage({
    viewport: { width: 1920, height: 1080 },
    deviceScaleFactor: 1
  });

  console.log('Navigating to http://localhost:3000/five_avatars_video.html ...');
  await page.goto('http://localhost:3000/five_avatars_video.html', { waitUntil: 'networkidle' });

  // Wait for textures and shaders to be ready
  await page.waitForFunction(() => window.__isReady === true, { timeout: 30000 });
  console.log('WebGL 5 Living Avatars scene is ready!');

  const fps = 30;
  const duration = 8.0;
  const totalFrames = Math.round(duration * fps); // 240 frames

  console.log(`Rendering ${totalFrames} frames at ${fps} fps (Duration: ${duration}s)...`);

  const ffmpeg = spawn('ffmpeg', [
    '-y',
    '-f', 'image2pipe',
    '-vcodec', 'png',
    '-r', String(fps),
    '-i', '-',
    '-c:v', 'libx264',
    '-pix_fmt', 'yuv420p',
    '-preset', 'medium',
    '-crf', '18',
    outputPath
  ]);

  ffmpeg.stderr.on('data', (d) => {
    const msg = d.toString();
    if (msg.includes('error') || msg.includes('Error')) {
      console.error('[FFMPEG]', msg);
    }
  });

  for (let frame = 0; frame < totalFrames; frame++) {
    const t = frame / fps;
    await page.evaluate((time) => {
      window.renderAtTime(time);
    }, t);

    // Capture screenshot buffer directly from the webgl canvas or page
    const buffer = await page.locator('#webgl-canvas').screenshot({ type: 'png' });
    ffmpeg.stdin.write(buffer);

    if (frame % 30 === 0 || frame === totalFrames - 1) {
      console.log(`Rendered frame ${frame + 1}/${totalFrames} (t=${t.toFixed(2)}s)`);
    }
  }

  ffmpeg.stdin.end();

  await new Promise((resolve, reject) => {
    ffmpeg.on('close', (code) => {
      if (code === 0) {
        console.log('FFmpeg finished successfully! Video saved to:', outputPath);
        resolve(code);
      } else {
        reject(new Error(`FFmpeg exited with code ${code}`));
      }
    });
  });

  const stats = fs.statSync(outputPath);
  console.log(`Video file size: ${(stats.size / (1024 * 1024)).toFixed(2)} MB`);

  await browser.close();
}

main().catch((err) => {
  console.error('Video generation failed:', err);
  process.exit(1);
});
