const sharp = require('sharp');
const fs = require('fs');

async function reprocessAvatarPastelClean() {
  console.log('=== FLAWLESS REPROCESSING OF AVATAR: PASTEL BLUE KNIT & PINK SHORTS ===');

  const pristineFile = 'public/assets/aistudio/file_00000000eb7881fa8a888c25bfc4c0f7_32dd4f88.png';
  const { data, info } = await sharp(pristineFile)
    .raw()
    .toBuffer({ resolveWithObject: true });

  const w = info.width;
  const h = info.height;
  console.log(`Pristine source dimensions: ${w} x ${h}`);

  // 1. Identify main connected body component starting from center (x=470, y=500)
  const visited = new Uint8Array(w * h);
  const queue = [470, 500];
  visited[500 * w + 470] = 1;

  // We connect all pixels with alpha > 15
  let bodyPixels = 0;
  while (queue.length > 0) {
    const cy = queue.pop();
    const cx = queue.pop();
    bodyPixels++;

    // 8-way connectivity to ensure smooth anti-aliased edges and thin hair wisps are connected
    const neighbors = [
      [cx - 1, cy], [cx + 1, cy], [cx, cy - 1], [cx, cy + 1],
      [cx - 1, cy - 1], [cx + 1, cy - 1], [cx - 1, cy + 1], [cx + 1, cy + 1]
    ];
    for (const [nx, ny] of neighbors) {
      if (nx >= 0 && nx < w && ny >= 0 && ny < h) {
        const nidx = ny * w + nx;
        if (!visited[nidx] && data[nidx * 4 + 3] > 15) {
          visited[nidx] = 1;
          queue.push(nx, ny);
        }
      }
    }
  }

  console.log(`Connected main body component: ${bodyPixels} pixels`);

  // Create clean buffer
  const out = Buffer.alloc(w * h * 4);

  let keptCount = 0;
  let discardedIsolated = 0;

  for (let i = 0; i < w * h; i++) {
    const p = i * 4;
    if (visited[i]) {
      out[p] = data[p];
      out[p + 1] = data[p + 1];
      out[p + 2] = data[p + 2];
      out[p + 3] = data[p + 3];
      keptCount++;
    } else {
      // Discard isolated pixels / noise
      if (data[p + 3] > 0) {
        discardedIsolated++;
      }
      out[p] = 0;
      out[p + 1] = 0;
      out[p + 2] = 0;
      out[p + 3] = 0;
    }
  }

  console.log(`Kept ${keptCount} pixels, discarded ${discardedIsolated} isolated pixels`);

  // Check the hip/thigh area (y=920..1020, x=340..385)
  let hipPixelCount = 0;
  for (let y = 920; y <= 1020; y++) {
    for (let x = 340; x <= 385; x++) {
      if (out[(y * w + x) * 4 + 3] > 20) {
        hipPixelCount++;
      }
    }
  }
  console.log(`Hip/thigh pixels preserved (y=920..1020, x=340..385): ${hipPixelCount}`);

  // Check between legs gap (y=1380..1520, x=465..500)
  let legGapPixels = 0;
  for (let y = 1380; y <= 1520; y++) {
    for (let x = 465; x <= 500; x++) {
      if (out[(y * w + x) * 4 + 3] > 20) {
        legGapPixels++;
      }
    }
  }
  console.log(`Pixels in gap between lower calves/ankles: ${legGapPixels} (should be 0)`);

  // 2. Export the pristine transparent PNG
  const transPath = 'public/assets/images/avatars_3d/transparent/avatar_pastel_blue_knit_shorts.png';
  const pngBuffer = await sharp(out, { raw: { width: w, height: h, channels: 4 } })
    .png({ compressionLevel: 8 })
    .toBuffer();

  fs.writeFileSync(transPath, pngBuffer);
  console.log(`✓ Saved transparent PNG: ${transPath}`);

  // Update modular layer body_skin.png
  const modularPath = 'public/assets/images/avatars_modular/avatar_pastel_blue_knit_shorts/body_skin.png';
  if (fs.existsSync('public/assets/images/avatars_modular/avatar_pastel_blue_knit_shorts')) {
    fs.writeFileSync(modularPath, pngBuffer);
    console.log(`✓ Saved modular fallback: ${modularPath}`);
  }

  // Generate card preview JPG on subtle dark gradient background
  const cardBgSvg = `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}">
    <defs>
      <radialGradient id="cardBg" cx="50%" cy="40%" r="65%">
        <stop offset="0%" stop-color="#1e1b4b"/>
        <stop offset="60%" stop-color="#0f172a"/>
        <stop offset="100%" stop-color="#020617"/>
      </radialGradient>
    </defs>
    <rect width="${w}" height="${h}" fill="url(#cardBg)"/>
  </svg>`;
  const cardBgBuf = Buffer.from(cardBgSvg);
  const cardJpgPath = 'public/assets/images/avatars_3d/avatar_pastel_blue_knit_shorts.jpg';
  await sharp(cardBgBuf)
    .resize(w, h)
    .composite([{ input: pngBuffer, top: 0, left: 0 }])
    .jpeg({ quality: 92 })
    .toFile(cardJpgPath);
  console.log(`✓ Saved card JPG preview: ${cardJpgPath}`);

  // 3. Generate Mandatory Proof Images
  fs.mkdirSync('proof_artifacts', { recursive: true });

  const magentaBg = await sharp({
    create: { width: w, height: h, channels: 4, background: { r: 255, g: 0, b: 255, alpha: 1 } }
  }).png().toBuffer();

  const fullMagenta = await sharp(magentaBg)
    .composite([{ input: pngBuffer }])
    .png()
    .toBuffer();

  fs.writeFileSync('proof_artifacts/avatar_a_pastel_full_magenta.png', fullMagenta);

  // Zoomed on hip / upper thigh (y: 860 to 1080, x: 300 to 460) -> NO NOTCH, smooth natural curvature
  await sharp(fullMagenta)
    .extract({ left: 310, top: 880, width: 160, height: 200 })
    .toFile('proof_artifacts/avatar_a_hip_thigh_zoom_magenta.png');

  // Zoomed on both hips, shorts and upper thighs (y: 800 to 1150, x: 260 to 680)
  await sharp(fullMagenta)
    .extract({ left: 280, top: 800, width: 380, height: 350 })
    .toFile('proof_artifacts/avatar_a_hips_shorts_zoom_magenta.png');

  // Zoomed on ankles and sneakers (y: 1350 to 1672, x: 350 to 620)
  await sharp(fullMagenta)
    .extract({ left: 350, top: 1350, width: 270, height: 322 })
    .toFile('proof_artifacts/avatar_a_pastel_feet_zoom_magenta.png');

  console.log('✓ Created zoomed magenta proofs in proof_artifacts/');
}

reprocessAvatarPastelClean().catch(console.error);
