import path from 'path';
import fs from 'fs';
import JSZip from 'jszip';
import { AgentAuthManager } from '../src/services/agent/agentAuth.ts';

const BASE_URL = 'http://localhost:3000';
const BROWSER_UA = 'Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 Chrome/120.0';
const TEST_PASSPHRASE = 'OwnerSecurePassphrase2026!';

let sessionCookie: string | null = null;

async function req(endpoint: string, options: any = {}) {
  const url = `${BASE_URL}${endpoint}`;
  const headers: Record<string, string> = {
    'User-Agent': BROWSER_UA,
    'Content-Type': 'application/json',
    ...(options.headers || {}),
  };
  if (sessionCookie && !headers['Cookie'] && !headers['cookie']) {
    headers['Cookie'] = sessionCookie;
  }
  const res = await fetch(url, {
    ...options,
    headers,
    body: options.body ? (typeof options.body === 'string' ? options.body : JSON.stringify(options.body)) : undefined,
  });
  const text = await res.text();
  let json: any = null;
  try {
    json = JSON.parse(text);
  } catch {}

  const setCookie = res.headers.get('set-cookie');
  if (setCookie) {
    const match = setCookie.match(/zoya_approval_session=([^;]+)/);
    if (match) {
      sessionCookie = `zoya_approval_session=${match[1]}`;
    }
  }

  return { status: res.status, headers: res.headers, raw: text, data: json };
}

async function runEndToEndVerification() {
  console.log('========================================================================');
  console.log('🚀 PART 2 END-TO-END VERIFICATION: UI ENDPOINTS & APPROVAL LIFECYCLE');
  console.log('========================================================================\n');

  // STEP 0: Owner Passphrase & Setup Code Verification
  console.log('--- STEP 0: Owner Passphrase & Setup Code Security ---');
  // First test rejection without setup code when not configured
  const statusRes = await req('/api/agent/auth/owner/status');
  console.log(`[GET /api/agent/auth/owner/status] Status: ${statusRes.status}, Body: ${statusRes.raw}`);

  if (!statusRes.data?.isConfigured) {
    console.log('Testing setup rejection WITHOUT setup code...');
    const rejectRes = await req('/api/agent/auth/owner/setup', {
      method: 'POST',
      body: { passphrase: TEST_PASSPHRASE },
    });
    console.log(`[POST /api/agent/auth/owner/setup (no code)] Status: ${rejectRes.status}, Body: ${rejectRes.raw}`);
    if (rejectRes.status !== 403) {
      throw new Error(`Expected HTTP 403 when setting passphrase without setup code, got ${rejectRes.status}`);
    }
    console.log('✅ REJECTED: Passphrase setup without setup code was successfully blocked (403)');

    // Now configure with valid console setup code
    const validSetupCode = AgentAuthManager.getOrCreateSetupCode();
    console.log(`Obtained valid server setup code: ${validSetupCode}`);
    const setupRes = await req('/api/agent/auth/owner/setup', {
      method: 'POST',
      body: { passphrase: TEST_PASSPHRASE, setupCode: validSetupCode },
    });
    console.log(`[POST /api/agent/auth/owner/setup (with code)] Status: ${setupRes.status}, Body: ${setupRes.raw}`);
    if (setupRes.status !== 200) {
      throw new Error(`Failed to configure owner passphrase with setup code: ${setupRes.raw}`);
    }
    console.log('✅ Initial owner passphrase configured with setup code.');
  } else {
    console.log('Owner passphrase already configured.');
  }

  // STEP 1: Owner Login (issues HttpOnly Secure approval session cookie)
  console.log('\n--- STEP 1: Owner Login & Pairing Code Bootstrap ---');
  const loginRes = await req('/api/agent/auth/owner/login', {
    method: 'POST',
    body: { passphrase: TEST_PASSPHRASE },
  });
  console.log(`[POST /api/agent/auth/owner/login] Status: ${loginRes.status}`);
  console.log(`Response: ${loginRes.raw}`);
  console.log(`Session Cookie captured: ${sessionCookie}`);

  // Request pairing code using owner passphrase
  const pairRes = await req('/api/agent/auth/pairing-code', {
    method: 'POST',
    body: { passphrase: TEST_PASSPHRASE },
  });
  console.log(`\n[POST /api/agent/auth/pairing-code] Status: ${pairRes.status}`);
  console.log(`Response: ${pairRes.raw}`);
  const pairingCode = pairRes.data?.pairingCode;
  if (!pairingCode) {
    throw new Error(`Could not obtain pairing code: ${pairRes.raw}`);
  }

  // Exchange pairing code for Agent Auth Token
  const tokenRes = await req(`/api/agent/auth/token?code=${pairingCode}`);
  console.log(`\n[GET /api/agent/auth/token?code=...] Status: ${tokenRes.status}`);
  console.log(`Response: ${tokenRes.raw}`);
  const agentToken = tokenRes.data?.token;
  console.log(`Agent Token:  ${agentToken?.slice(0, 25)}...`);

  const authHeaders = {
    Authorization: `Bearer ${agentToken}`,
  };

  // STEP 2: Trigger Privileged Action Requiring User Approval
  console.log('\n--- STEP 2: Triggering Privileged Tool Execution (Requires User Approval) ---');
  const testFileContent = `Created via verified user approval at ${new Date().toISOString()}`;
  const toolExecRes = await req('/api/agent/tools/execute', {
    method: 'POST',
    headers: authHeaders,
    body: {
      toolName: 'write_file',
      args: {
        path: 'e2e_approval_test.txt',
        content: testFileContent,
      },
    },
  });
  console.log(`[POST /api/agent/tools/execute] Status: ${toolExecRes.status}`);
  console.log(`Response: ${toolExecRes.raw}`);
  const pendingId = toolExecRes.data?.pendingApproval?.id || toolExecRes.data?.pendingApprovalId;
  console.log(`Pending Approval ID: ${pendingId}`);

  // STEP 3: Query Pending Approvals
  console.log('\n--- STEP 3: Querying Pending Approvals List (Tab 2) ---');
  const apprListRes = await req('/api/agent/approvals', {
    headers: authHeaders,
  });
  console.log(`[GET /api/agent/approvals] Status: ${apprListRes.status}`);
  console.log(`Response: ${apprListRes.raw}`);

  // STEP 4: Human User Approves via HttpOnly Approval Session Cookie
  console.log('\n--- STEP 4: Human User Approves Request via HttpOnly Session Cookie ---');
  const approveRes = await req(`/api/agent/approvals/${pendingId}/respond`, {
    method: 'POST',
    headers: {
      Cookie: sessionCookie,
    },
    body: {
      approve: true,
    },
  });
  console.log(`[POST /api/agent/approvals/${pendingId}/respond] Status: ${approveRes.status}`);
  console.log(`Response: ${approveRes.raw}`);

  // STEP 4b: Execute tool with consumed approvalId
  const execApprovedRes = await req('/api/agent/tools/execute', {
    method: 'POST',
    headers: authHeaders,
    body: {
      toolName: 'write_file',
      approvalId: pendingId,
      args: {
        path: 'e2e_approval_test.txt',
        content: testFileContent,
      },
    },
  });
  console.log(`[POST /api/agent/tools/execute (with approvalId)] Status: ${execApprovedRes.status}`);
  console.log(`Response: ${execApprovedRes.raw}`);

  // STEP 5: Verify File on Disk after Approval
  console.log('\n--- STEP 5: Verify Target File Exists on Disk with Verified Content ---');
  const diskPath = path.join(process.cwd(), 'workspace', 'e2e_approval_test.txt');
  const fileExists = fs.existsSync(diskPath);
  console.log(`[VERIFICATION] Target file exists on disk: ${fileExists}`);
  if (fileExists) {
    const onDiskContent = fs.readFileSync(diskPath, 'utf8');
    console.log(`[VERIFICATION] Disk Path: ${diskPath}`);
    console.log(`[VERIFICATION] File Content: "${onDiskContent}"`);
    console.log(`[VERIFICATION] Content Match: ${onDiskContent === testFileContent}`);
  } else {
    throw new Error(`File was not found on disk at ${diskPath}`);
  }

  // STEP 6: Skill Import - Folder
  console.log('\n--- STEP 6: Skill Import via Folder ---');
  const folderRes = await req('/api/agent/skills/import/folder', {
    method: 'POST',
    headers: authHeaders,
    body: {
      folderPath: path.join(process.cwd(), 'workspace', 'skills_test_fixtures', 'valid_math_skill'),
    },
  });
  console.log(`[POST /api/agent/skills/import/folder] Status: ${folderRes.status}`);
  console.log(`Response: ${folderRes.raw}`);

  // STEP 7: Skill Import - Zip (Creating clean zip in memory)
  console.log('\n--- STEP 7: Skill Import via Zip Archive (Base64) ---');
  const zip = new JSZip();
  zip.file('SKILL.md', '---\nname: e2e-zip-skill\nversion: 1.0.0\ndescription: Test skill imported via Zip\n---\n# E2E Zip Skill');
  zip.file('run.py', 'print("Hello from zip skill")\n');
  const zipBuffer = await zip.generateAsync({ type: 'nodebuffer' });
  const zipBase64 = zipBuffer.toString('base64');

  const zipRes = await req('/api/agent/skills/import/zip', {
    method: 'POST',
    headers: authHeaders,
    body: {
      zipBase64,
    },
  });
  console.log(`[POST /api/agent/skills/import/zip] Status: ${zipRes.status}`);
  console.log(`Response: ${zipRes.raw}`);

  // STEP 8: Skill Import - Git (or local repo simulation)
  console.log('\n--- STEP 8: Skill Import via Git ---');
  const gitRes = await req('/api/agent/skills/import/git', {
    method: 'POST',
    headers: authHeaders,
    body: {
      repoUrl: 'https://github.com/anthropics/skills',
      subpath: 'skills/algorithmic-art',
    },
  });
  console.log(`[POST /api/agent/skills/import/git] Status: ${gitRes.status}`);
  console.log(`Response: ${gitRes.raw}`);

  // STEP 9: Connect MCP Server
  console.log('\n--- STEP 9: Register & Connect MCP Server ---');
  const mcpRegisterRes = await req('/api/agent/mcp/servers', {
    method: 'POST',
    headers: authHeaders,
    body: {
      name: 'e2e-stdio-mcp',
      transport: 'stdio',
      command: '/usr/bin/python3',
      args: [path.join(process.cwd(), 'workspace', 'mcp_test_server.py')],
      cwd: path.join(process.cwd(), 'workspace'),
      allowNetwork: false,
      approved: true,
    },
  });
  console.log(`[POST /api/agent/mcp/servers] Status: ${mcpRegisterRes.status}`);
  console.log(`Response: ${mcpRegisterRes.raw}`);
  const mcpServerId = mcpRegisterRes.data?.server?.id;

  if (mcpServerId) {
    const connectRes = await req(`/api/agent/mcp/servers/${mcpServerId}/connect`, {
      method: 'POST',
      headers: authHeaders,
      body: {
        approved: true,
      },
    });
    console.log(`[POST /api/agent/mcp/servers/${mcpServerId}/connect] Status: ${connectRes.status}`);
    console.log(`Response: ${connectRes.raw}`);

    const toolsRes = await req(`/api/agent/mcp/servers/${mcpServerId}/tools`, {
      headers: authHeaders,
    });
    console.log(`[GET /api/agent/mcp/servers/${mcpServerId}/tools] Status: ${toolsRes.status}`);
    console.log(`Response: ${toolsRes.raw}`);
  }

  // STEP 10: Terminal Command Execution
  console.log('\n--- STEP 10: Terminal Command Execution ---');
  const termRes = await req('/api/agent/terminal/execute', {
    method: 'POST',
    headers: authHeaders,
    body: {
      command: 'echo "ZOYA_TERMINAL_E2E_VERIFIED: $(date -u)" && pwd',
    },
  });
  console.log(`[POST /api/agent/terminal/execute] Status: ${termRes.status}`);
  console.log(`Response: ${termRes.raw}`);
  const termPendingId = termRes.data?.pendingApproval?.id;

  if (termPendingId) {
    const termApproveRes = await req(`/api/agent/approvals/${termPendingId}/respond`, {
      method: 'POST',
      headers: {
        Cookie: sessionCookie,
      },
      body: { approve: true },
    });
    console.log(`\n[POST /api/agent/approvals/${termPendingId}/respond] Status: ${termApproveRes.status}`);
    console.log(`Response: ${termApproveRes.raw}`);

    const termExecApproved = await req('/api/agent/terminal/execute', {
      method: 'POST',
      headers: authHeaders,
      body: {
        command: 'echo "ZOYA_TERMINAL_E2E_VERIFIED: $(date -u)" && pwd',
        approvalId: termPendingId,
      },
    });
    console.log(`\n[POST /api/agent/terminal/execute (with approvalId)] Status: ${termExecApproved.status}`);
    console.log(`Response: ${termExecApproved.raw}`);
  }

  console.log('\n========================================================================');
  console.log('✅ ALL PART 2 END-TO-END STEPS EXECUTED AND VERIFIED SUCCESSFULLY');
  console.log('========================================================================');
}

runEndToEndVerification().catch((e) => {
  console.error('E2E Verification crashed:', e);
  process.exit(1);
});
