const sharp = require('sharp');
const path = require('path');

async function testBgChroma() {
  const src = path.join(__dirname, '../src/assets/images/zoya_3d_sweater_glasses_1793764031303.jpg');
  const { data, info } = await sharp(src).removeAlpha().raw().toBuffer({ resolveWithObject: true });
  const W = info.width, H = info.height;

  // Let's sample the background at x in [0..150] and [W-150..W-1] for all y
  let maxChromaLeft = 0;
  let maxChromaRight = 0;
  let maxChromaTop = 0;
  let maxChromaBottom = 0;

  for (let y = 0; y < H; y++) {
    for (let x = 0; x < 100; x++) {
      const idx = (y * W + x) * 3;
      const r = data[idx], g = data[idx+1], b = data[idx+2];
      const ch = Math.max(Math.abs(r-g), Math.abs(r-b), Math.abs(g-b));
      if (ch > maxChromaLeft) maxChromaLeft = ch;
    }
    for (let x = W - 100; x < W; x++) {
      const idx = (y * W + x) * 3;
      const r = data[idx], g = data[idx+1], b = data[idx+2];
      const ch = Math.max(Math.abs(r-g), Math.abs(r-b), Math.abs(g-b));
      if (ch > maxChromaRight) maxChromaRight = ch;
    }
  }

  for (let y = 0; y < 20; y++) {
    for (let x = 0; x < W; x++) {
      const idx = (y * W + x) * 3;
      const r = data[idx], g = data[idx+1], b = data[idx+2];
      const ch = Math.max(Math.abs(r-g), Math.abs(r-b), Math.abs(g-b));
      if (ch > maxChromaTop) maxChromaTop = ch;
    }
  }

  for (let y = 1365; y < H; y++) {
    for (let x = 0; x < W; x++) {
      const idx = (y * W + x) * 3;
      const r = data[idx], g = data[idx+1], b = data[idx+2];
      const ch = Math.max(Math.abs(r-g), Math.abs(r-b), Math.abs(g-b));
      if (ch > maxChromaBottom) maxChromaBottom = ch;
    }
  }

  console.log({ maxChromaLeft, maxChromaRight, maxChromaTop, maxChromaBottom });
}
testBgChroma().catch(console.error);
