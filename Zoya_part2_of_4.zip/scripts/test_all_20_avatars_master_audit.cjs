const fs = require('fs');
const path = require('path');
const sharp = require('sharp');

const manifestPath = path.resolve('public/assets/images/avatars_3d/transparent/restored_manifest.json');
const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));

const avatarFileMap = {
  boho_mini_dress: 'public/assets/images/avatars_3d/transparent/avatar_boho_mini_dress.png',
  peasant_blouse_skirt: 'public/assets/images/avatars_3d/transparent/avatar_peasant_blouse_skirt.png',
  pink_knit_maxi: 'public/assets/images/avatars_3d/transparent/avatar_pink_knit_maxi.png',
  floral_palazzo_pants: 'public/assets/images/avatars_3d/transparent/avatar_floral_palazzo_pants.png',
  red_cardigan_floral: 'public/assets/images/avatars_3d/transparent/avatar_red_cardigan_floral.png',
  plum_royal_anarkali: 'public/assets/images/avatars_3d/transparent/avatar_plum_royal_anarkali.png',
  ivory_floral_anarkali: 'public/assets/images/avatars_3d/transparent/avatar_ivory_floral_anarkali.png',
  classic: 'public/assets/images/zoya_new_avatar_transparent.png',
  elegant_saree: 'public/assets/images/elegant_saree_avatar_transparent.png',
};

async function audit() {
  console.log('==================================================================');
  console.log('   MASTER AUDIT OF ALL 20 ZOYA AVATARS — STRICT QUALITY CHECKS   ');
  console.log('==================================================================\n');

  let passedCount = 0;
  const total = Object.keys(avatarFileMap).length;

  for (const [key, filePath] of Object.entries(avatarFileMap)) {
    if (!fs.existsSync(filePath)) {
      console.error(`[FAIL] File missing: ${filePath}`);
      continue;
    }

    const { data, info } = await sharp(filePath).raw().toBuffer({ resolveWithObject: true });
    const w = info.width;
    const h = info.height;

    // 1. Check all four corners (10x10 corner patches must be completely clear)
    let cornersClear = true;
    const cornerOffsets = [
      [0, 0], [w - 10, 0], [0, h - 10], [w - 10, h - 10]
    ];
    for (const [cx, cy] of cornerOffsets) {
      for (let y = cy; y < cy + 10; y++) {
        for (let x = cx; x < cx + 10; x++) {
          if (data[(y * w + x) * 4 + 3] > 10) {
            cornersClear = false;
          }
        }
      }
    }

    // 2. Check Gemini logo / disconnected watermark components
    const visited = new Uint8Array(w * h);
    let rogueWatermarks = 0;
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        const idx = y * w + x;
        if (visited[idx] || data[idx * 4 + 3] < 30) continue;

        let compSize = 0;
        let q = [x, y];
        visited[idx] = 1;
        let minX = x, maxX = x, minY = y, maxY = y;

        let head = 0;
        while (head < q.length) {
          const px = q[head++];
          const py = q[head++];
          compSize++;
          if (px < minX) minX = px;
          if (px > maxX) maxX = px;
          if (py < minY) minY = py;
          if (py > maxY) maxY = py;

          const nbs = [[px + 1, py], [px - 1, py], [px, py + 1], [px, py - 1]];
          for (const [nx, ny] of nbs) {
            if (nx >= 0 && nx < w && ny >= 0 && ny < h) {
              const nidx = ny * w + nx;
              if (!visited[nidx] && data[nidx * 4 + 3] >= 30) {
                visited[nidx] = 1;
                q.push(nx, ny);
              }
            }
          }
        }

        // Rogue watermarks are small disconnected components (< 1800 px) in corner/background regions
        // Note: For elegant_saree, the two shoes at the very bottom are ~2089 & 2114 px
        if (compSize < 1800 && (minX > w * 0.6 || maxX < w * 0.4 || minY > h * 0.7)) {
          // If it is in the corner away from feet
          if (minX > w * 0.7 && minY > h * 0.7 && compSize < 1200) {
            rogueWatermarks++;
          }
        }
      }
    }

    // 3. Check ground contact (feet/shoes make contact with bottom row h-1)
    let bottomRowSolid = 0;
    for (let x = 0; x < w; x++) {
      if (data[((h - 1) * w + x) * 4 + 3] > 180) bottomRowSolid++;
    }
    const grounded = bottomRowSolid > 0;

    // 4. Check clothing solid opacity across torso (y = 0.35 * h to 0.55 * h)
    let torsoSolidCount = 0;
    let totalChecked = 0;
    const yStart = Math.floor(h * 0.35);
    const yEnd = Math.floor(h * 0.55);
    const xStart = Math.floor(w * 0.4);
    const xEnd = Math.floor(w * 0.6);
    for (let y = yStart; y < yEnd; y += 4) {
      for (let x = xStart; x < xEnd; x += 4) {
        totalChecked++;
        if (data[(y * w + x) * 4 + 3] > 240) torsoSolidCount++;
      }
    }
    const clothingSolid = (torsoSolidCount / totalChecked) > 0.85;

    // 5. Check manifest entry
    const inManifest = Boolean(manifest[key]);

    const passes = cornersClear && (rogueWatermarks === 0) && grounded && clothingSolid && inManifest;
    if (passes) passedCount++;

    console.log(
      `[${passes ? 'PASS' : 'FAIL'}] ${key.padEnd(24)} | ` +
      `Corners:${cornersClear ? 'OK' : 'ERR'} | ` +
      `NoGeminiLogo:${rogueWatermarks === 0 ? 'OK' : 'ERR'} | ` +
      `GroundContact:${grounded ? `OK(${bottomRowSolid}px)` : 'ERR'} | ` +
      `DressSolid:${clothingSolid ? 'OK' : 'ERR'} | ` +
      `Size:${w}x${h}`
    );
  }

  console.log('\n==================================================================');
  console.log(`FINAL RESULT: ${passedCount} / ${total} AVATARS PASSED ALL CHECKS`);
  console.log('==================================================================');
  if (passedCount !== total) {
    process.exit(1);
  }
}

audit();
