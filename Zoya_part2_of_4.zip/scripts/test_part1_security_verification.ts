import fetch from 'node-fetch';
import { AgentAuthManager } from '../src/services/agent/agentAuth.ts';
import { AgentToolExecutor } from '../src/services/agent/agentTools.ts';
import path from 'path';
import fs from 'fs';

const BASE_URL = 'http://127.0.0.1:3000';
const TEST_PASSPHRASE = 'OwnerSecurePassphrase2026!';

async function runPart1SecurityTests() {
  console.log('====================================================');
  console.log('🔒 PART 1: SECURITY VERIFICATION SUITE');
  console.log('====================================================\n');

  let passed = 0;
  let failed = 0;

  function assert(condition: boolean, testName: string, detail?: string) {
    if (condition) {
      console.log(`✅ PASS: ${testName}`);
      passed++;
    } else {
      console.error(`❌ FAIL: ${testName} - ${detail || ''}`);
      failed++;
    }
  }

  // Setup owner passphrase if not already configured
  console.log('--- Step 0: Initializing Owner Passphrase ---');
  AgentAuthManager.setOwnerPassphrase(TEST_PASSPHRASE);
  console.log('Owner passphrase configured with salted scrypt hash.\n');

  // --------------------------------------------------------------------------
  // (a) Pairing without passphrase -> 401/403, even with a browser User-Agent
  // --------------------------------------------------------------------------
  console.log('--- Test (a): Pairing without passphrase rejected (even with browser User-Agent) ---');
  const spoofedUA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';

  // Attempt 1: GET without passphrase
  const resGet = await fetch(`${BASE_URL}/api/agent/auth/pairing-code`, {
    headers: { 'User-Agent': spoofedUA },
  });
  console.log(`GET /api/agent/auth/pairing-code with spoofed UA -> Status: ${resGet.status}`);
  const getBody = await resGet.json();
  console.log(`Response body: ${JSON.stringify(getBody)}`);
  assert(resGet.status === 401 || resGet.status === 405, 'GET pairing-code rejected without passphrase (status 401/405)');

  // Attempt 2: POST without passphrase
  const resPostNoPass = await fetch(`${BASE_URL}/api/agent/auth/pairing-code`, {
    method: 'POST',
    headers: {
      'User-Agent': spoofedUA,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({}),
  });
  console.log(`POST /api/agent/auth/pairing-code without passphrase -> Status: ${resPostNoPass.status}`);
  const postNoPassBody = await resPostNoPass.json();
  console.log(`Response body: ${JSON.stringify(postNoPassBody)}`);
  assert(resPostNoPass.status === 401, 'POST pairing-code without passphrase rejected with 401 Unauthorized');

  // Attempt 3: POST with wrong passphrase
  const resPostWrongPass = await fetch(`${BASE_URL}/api/agent/auth/pairing-code`, {
    method: 'POST',
    headers: {
      'User-Agent': spoofedUA,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ passphrase: 'WrongPassphrase123!' }),
  });
  console.log(`POST /api/agent/auth/pairing-code with wrong passphrase -> Status: ${resPostWrongPass.status}`);
  const postWrongBody = await resPostWrongPass.json();
  console.log(`Response body: ${JSON.stringify(postWrongBody)}\n`);
  assert(resPostWrongPass.status === 401, 'POST pairing-code with wrong passphrase rejected with 401 Unauthorized');

  // --------------------------------------------------------------------------
  // (b) No response body anywhere contains "userSecret" or approval secret
  // --------------------------------------------------------------------------
  console.log('--- Test (b): No response body anywhere contains "userSecret" ---');
  // First obtain valid pairing code with owner passphrase
  const resPairValid = await fetch(`${BASE_URL}/api/agent/auth/pairing-code`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ passphrase: TEST_PASSPHRASE }),
  });
  const pairValidBody = await resPairValid.json() as any;
  console.log(`Pairing code response: ${JSON.stringify(pairValidBody)}`);
  const pairingCode = pairValidBody.pairingCode;
  assert(Boolean(pairingCode), 'Valid pairing code generated with owner passphrase');

  // Now call /api/agent/auth/token?code=...
  const resToken = await fetch(`${BASE_URL}/api/agent/auth/token?code=${pairingCode}`);
  const tokenBodyRaw = await resToken.text();
  console.log(`Token bootstrap response: ${tokenBodyRaw}`);
  const tokenBody = JSON.parse(tokenBodyRaw);
  const agentToken = tokenBody.token;

  assert(!tokenBodyRaw.includes('userSecret'), 'Response body does NOT contain "userSecret"');
  assert(!tokenBodyRaw.includes('zoya_user_approver_sec_'), 'Response body does NOT contain approval secret value');
  assert(tokenBody.userSecret === undefined, 'tokenBody.userSecret is undefined');
  assert(Boolean(agentToken), 'Agent auth token received successfully\n');

  // --------------------------------------------------------------------------
  // Trigger a real pending approval on the server to test authorization
  // --------------------------------------------------------------------------
  console.log('--- Triggering server-side pending approval request ---');
  // Initiate file write in background (this pauses for approval on server)
  const writeTriggerPromise = fetch(`${BASE_URL}/api/agent/files/write`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${agentToken}`,
    },
    body: JSON.stringify({
      path: 'auth_security_test_file.txt',
      content: 'testing approval flows',
    }),
  });

  // Short wait for approval to register
  await new Promise((r) => setTimeout(r, 400));

  const resApprovals = await fetch(`${BASE_URL}/api/agent/approvals`, {
    headers: { Authorization: `Bearer ${agentToken}` },
  });
  const approvalsList = await resApprovals.json() as any;
  const targetApproval = approvalsList.pending?.[0];
  console.log(`Registered pending approval ID: ${targetApproval?.id} (tool: ${targetApproval?.tool})`);
  assert(Boolean(targetApproval?.id), 'Pending approval request successfully registered on server\n');

  // --------------------------------------------------------------------------
  // (c) The agent token alone cannot approve actions
  // --------------------------------------------------------------------------
  console.log('--- Test (c): The agent token alone CANNOT approve actions ---');
  const resAgentSelfApprove = await fetch(`${BASE_URL}/api/agent/approvals/${targetApproval?.id}/respond`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${agentToken}`,
      'x-agent-auth-token': agentToken,
    },
    body: JSON.stringify({ approve: true }),
  });
  console.log(`Agent token self-approval attempt -> Status: ${resAgentSelfApprove.status}`);
  const selfApproveBody = await resAgentSelfApprove.json();
  console.log(`Response body: ${JSON.stringify(selfApproveBody)}`);
  assert(resAgentSelfApprove.status === 403, 'Agent token self-approval rejected with 403 Forbidden');
  assert(
    selfApproveBody.code === 'AGENT_SELF_APPROVAL_FORBIDDEN',
    'Agent self-approval error code is AGENT_SELF_APPROVAL_FORBIDDEN\n'
  );

  // --------------------------------------------------------------------------
  // (e) & (f): Correct passphrase issues HttpOnly SameSite=Strict Secure cookie
  // and approve/deny works with cookie only
  // --------------------------------------------------------------------------
  console.log('--- Test (e) & (f): Correct passphrase issues HttpOnly SameSite=Strict Secure cookie ---');
  const resLogin = await fetch(`${BASE_URL}/api/agent/auth/owner/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ passphrase: TEST_PASSPHRASE }),
  });
  console.log(`POST /api/agent/auth/owner/login -> Status: ${resLogin.status}`);
  const loginBody = await resLogin.json();
  console.log(`Response body: ${JSON.stringify(loginBody)}`);

  const setCookieHeader = resLogin.headers.get('set-cookie') || '';
  console.log(`Set-Cookie header received: ${setCookieHeader}`);

  // (f) Test HttpOnly, SameSite=Strict, Secure flags
  assert(setCookieHeader.includes('HttpOnly'), 'Set-Cookie contains HttpOnly flag (not accessible to JS document.cookie)');
  assert(setCookieHeader.includes('SameSite=Strict'), 'Set-Cookie contains SameSite=Strict');
  assert(setCookieHeader.includes('Secure'), 'Set-Cookie contains Secure flag');
  assert(setCookieHeader.includes('zoya_approval_session='), 'Set-Cookie defines zoya_approval_session');

  // Extract cookie value
  const cookieMatch = setCookieHeader.match(/zoya_approval_session=([^;]+)/);
  const sessionCookieVal = cookieMatch ? cookieMatch[1] : '';

  // Approve using the session cookie ONLY (no token or secret in headers or body)
  console.log('\nApproving action using session cookie only (no secret in JS memory)...');
  const resCookieApprove = await fetch(`${BASE_URL}/api/agent/approvals/${targetApproval?.id}/respond`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Cookie: `zoya_approval_session=${sessionCookieVal}`,
    },
    body: JSON.stringify({ approve: true }),
  });
  console.log(`Approval response with cookie -> Status: ${resCookieApprove.status}`);
  const approveResult = await resCookieApprove.json();
  console.log(`Response body: ${JSON.stringify(approveResult)}`);
  assert(resCookieApprove.status === 200, 'Approval succeeds with 200 OK when authenticating via session cookie');
  assert(approveResult.success === true, 'Approval response returned success: true\n');

  // --------------------------------------------------------------------------
  // (d) A wrong passphrase is rate-limited and locked out
  // --------------------------------------------------------------------------
  console.log('--- Test (d): Wrong passphrase rate-limiting and lockout ---');
  for (let i = 1; i <= 5; i++) {
    const resFail = await fetch(`${BASE_URL}/api/agent/auth/owner/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ passphrase: `BadPass-${i}` }),
    });
    const failJson = await resFail.json() as any;
    console.log(`Attempt ${i} -> Status: ${resFail.status}, error: ${failJson.error}`);
    if (i < 5) {
      assert(resFail.status === 401, `Failed attempt ${i} returns 401 Unauthorized`);
    } else {
      assert(resFail.status === 429, `5th consecutive failed attempt returns 429 Too Many Requests (Lockout)`);
      assert(failJson.rateLimited === true, 'Response payload specifies rateLimited: true');
    }
  }

  // 6th attempt while locked out: immediately rejected with 429
  const resLockedOut = await fetch(`${BASE_URL}/api/agent/auth/owner/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ passphrase: TEST_PASSPHRASE }), // even with correct passphrase!
  });
  const lockedJson = await resLockedOut.json() as any;
  console.log(`6th attempt while locked -> Status: ${resLockedOut.status}, error: ${lockedJson.error}`);
  assert(resLockedOut.status === 429, 'Locked out system rejects subsequent attempts with 429\n');

  // Reset rate limiter on server for system readiness
  await fetch(`${BASE_URL}/api/agent/auth/owner/reset-limit`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ passphrase: TEST_PASSPHRASE }),
  });

  // --------------------------------------------------------------------------
  // (2) Network Isolation MUST Fail Closed
  // --------------------------------------------------------------------------
  console.log('--- Test (2): Network isolation MUST fail closed when unshare is unavailable or fails ---');
  process.env.FORCE_SIMULATE_UNSHARE_FAIL = 'true';

  const testWorkspace = path.join(process.cwd(), 'workspace', 'security_test_sandbox');
  const toolExecutor = new AgentToolExecutor({
    workspaceRoot: testWorkspace,
    autoApprove: true,
  });

  const simulatedFailResult = await toolExecutor.executeTool('run_command', {
    command: 'python3 -c "print(\'this should never execute without isolation\')"',
  });

  delete process.env.FORCE_SIMULATE_UNSHARE_FAIL;

  console.log(`Simulated unshare failure output: ${JSON.stringify(simulatedFailResult, null, 2)}`);
  assert(simulatedFailResult.success === false, 'Command execution was refused when unshare failed');
  assert(
    simulatedFailResult.error === 'NETWORK_ISOLATION_FAILURE',
    'Error code is NETWORK_ISOLATION_FAILURE'
  );
  assert(
    simulatedFailResult.output.includes('REFUSED') && simulatedFailResult.output.includes('unshare -n'),
    'Output explicitly states REFUSED: Network isolation via unshare -n is unavailable or failed'
  );

  console.log('\n====================================================');
  console.log(`PART 1 VERIFICATION SUMMARY: ${passed} PASSED, ${failed} FAILED`);
  console.log('====================================================');

  if (failed > 0) process.exit(1);
}

runPart1SecurityTests().catch((err) => {
  console.error('Part 1 security test suite crashed:', err);
  process.exit(1);
});
