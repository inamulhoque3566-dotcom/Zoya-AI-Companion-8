const sharp = require('sharp');

async function inspectUpper() {
  // 1. Avatar 3 (harajuku_street): white stripe on left & right jacket sleeves (y=340..540)
  {
    const { data, info } = await sharp('src/assets/images/zoya_3d_harajuku_street_1793631433771.jpg').raw().toBuffer({ resolveWithObject: true });
    const W = info.width;
    console.log('=== Avatar 3 (harajuku_street) Jacket Sleeve Edges y=340..540 ===');
    for (let y = 340; y <= 540; y += 12) {
      let line = `${String(y).padStart(4)}: `;
      for (let x = 175; x <= 610; x += 6) {
        const idx = (y * W + x) * 3;
        const r = data[idx], g = data[idx + 1], b = data[idx + 2];
        const chroma = Math.max(Math.abs(r - g), Math.abs(r - b), Math.abs(g - b));
        const minC = Math.min(r, g, b);
        if (g - r > 10) line += 'M'; // mint jacket
        else if (minC < 120) line += '#'; // black stripe / cami
        else if (r - b > 14) line += 'S'; // skin
        else if (minC >= 233 && chroma <= 4) line += '.'; // studio bg (~235,235,235)
        else line += 'W'; // white sleeve panel or shaded white
      }
      console.log(line);
    }
  }

  // 2. Avatar 9 (cyber_maid): wrist cuffs (y=190..330) and white skirt ruffle (y=510..620)
  {
    const { data, info } = await sharp('src/assets/images/zoya_3d_cyber_maid_1793631534918.jpg').raw().toBuffer({ resolveWithObject: true });
    const W = info.width;
    console.log('\n=== Avatar 9 (cyber_maid) Skirt Ruffle & Apron y=420..620 ===');
    for (let y = 420; y <= 620; y += 12) {
      let line = `${String(y).padStart(4)}: `;
      for (let x = 165; x <= 655; x += 7) {
        const idx = (y * W + x) * 3;
        const r = data[idx], g = data[idx + 1], b = data[idx + 2];
        const chroma = Math.max(Math.abs(r - g), Math.abs(r - b), Math.abs(g - b));
        const minC = Math.min(r, g, b);
        if (minC < 120) line += '#'; // black skirt / lace
        else if (b - r > 6 || g - r > 6) line += 'c'; // cyan trim
        else if (minC >= 239 && chroma <= 4) line += '.'; // studio bg (~242,242,244)
        else line += 'W'; // white apron / white ruffle
      }
      console.log(line);
    }
  }
}

inspectUpper().catch(console.error);
