import { chromium } from 'playwright';

async function runDump() {
  const browser = await chromium.launch({
    headless: true,
    executablePath: '/ms-playwright/chromium_headless_shell-1247/chrome-headless-shell-linux64/chrome-headless-shell',
    args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage'],
  });

  const context = await browser.newContext();
  const page = await context.newPage();

  console.log('Navigating to http://localhost:3000/ ...');
  await page.goto('http://localhost:3000/', { waitUntil: 'networkidle', timeout: 30000 });
  await page.waitForTimeout(1500);

  const storageData = await page.evaluate(() => {
    const ls: Record<string, string | null> = {};
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k) ls[k] = localStorage.getItem(k);
    }
    const ss: Record<string, string | null> = {};
    for (let i = 0; i < sessionStorage.length; i++) {
      const k = sessionStorage.key(i);
      if (k) ss[k] = sessionStorage.getItem(k);
    }
    return {
      localStorageLength: localStorage.length,
      sessionStorageLength: sessionStorage.length,
      localStorage: ls,
      sessionStorage: ss,
    };
  });

  console.log('REAL_PLAYWRIGHT_STORAGE_RESULT_START');
  console.log(JSON.stringify(storageData, null, 2));
  console.log('REAL_PLAYWRIGHT_STORAGE_RESULT_END');

  await browser.close();
}

runDump().catch((err) => {
  console.error('Playwright dump failed:', err);
  process.exit(1);
});
