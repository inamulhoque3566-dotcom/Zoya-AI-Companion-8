import fs from 'fs';
import path from 'path';
import sharp from 'sharp';

interface AvatarSpec {
  id: string;
  sourceFile: string;
  bgType: 'transparent' | 'neutral_light' | 'dark_blue' | 'pure_white';
  isGlasses?: boolean;
}

const AVATAR_SPECS: AvatarSpec[] = [
  {
    id: 'avatar_urban_crop_hoodie',
    sourceFile: 'public/assets/aistudio/file_00000000d12881f68a210961f707e2f7_2252122d.png',
    bgType: 'transparent',
    isGlasses: false,
  },
  {
    id: 'avatar_white_ruffle_babydoll',
    sourceFile: 'public/assets/aistudio/file_00000000714082118158b0be2e90f7cf_7fe119d0.png',
    bgType: 'transparent',
    isGlasses: false,
  },
  {
    id: 'avatar_pink_athleisure_track',
    sourceFile: 'public/assets/aistudio/1794316198287_50e22112.png',
    bgType: 'neutral_light',
    isGlasses: true,
  },
  {
    id: 'avatar_scarlet_peasant_cargo',
    sourceFile: 'public/assets/aistudio/file_0000000091d48207b6f9f29a32014cf0_bd82fc9f.png',
    bgType: 'transparent',
    isGlasses: false,
  },
  {
    id: 'avatar_pastel_blue_knit_shorts',
    sourceFile: 'public/assets/aistudio/file_00000000eb7881fa8a888c25bfc4c0f7_32dd4f88.png',
    bgType: 'transparent',
    isGlasses: false,
  },
  {
    id: 'avatar_violet_ruffle_cocktail',
    sourceFile: 'public/assets/aistudio/file_00000000156481faa774d203567b03c2_733a5cf3.png',
    bgType: 'neutral_light',
    isGlasses: false,
  },
  {
    id: 'avatar_slate_blue_regal_kurta',
    sourceFile: 'public/assets/aistudio/file_000000009b6081f589589ca050473a44_1a702475.png',
    bgType: 'transparent',
    isGlasses: false,
  },
  {
    id: 'avatar_midnight_gold_zari_saree',
    sourceFile: 'public/assets/aistudio/file_00000000c0d4821189e14bf178224f8d_f1687d5b.png',
    bgType: 'transparent',
    isGlasses: true,
  },
  {
    id: 'avatar_black_lace_mermaid_saree',
    sourceFile: 'public/assets/aistudio/file_0000000049f48211942df25c415acd25_3bf70b59.png',
    bgType: 'neutral_light',
    isGlasses: false,
  },
  {
    id: 'avatar_nautical_denim_shorts',
    sourceFile: 'public/assets/aistudio/file_000000009d4482078f1192d031bddc07_a2c80c89.png',
    bgType: 'dark_blue',
    isGlasses: true,
  },
  {
    id: 'avatar_parisian_beret_skater',
    sourceFile: 'public/assets/aistudio/27d4c655521f0e120597d929710fca20_88a75c28.jpg',
    bgType: 'pure_white',
    isGlasses: false,
  },
];

async function removeBackgroundFloodFill(
  rawBuffer: Buffer,
  w: number,
  h: number,
  bgType: 'neutral_light' | 'dark_blue' | 'pure_white'
): Promise<Buffer> {
  const out = Buffer.from(rawBuffer);
  const visited = new Uint8Array(w * h);
  const queue: number[] = [];

  // Seed borders
  for (let x = 0; x < w; x++) {
    queue.push(x, 0);
    queue.push(x, h - 1);
  }
  for (let y = 0; y < h; y++) {
    queue.push(0, y);
    queue.push(w - 1, y);
  }

  const isBgPixel = (r: number, g: number, b: number, y: number, x: number): boolean => {
    if (bgType === 'pure_white') {
      // Pure white or near white background
      return (r > 240 && g > 240 && b > 240) || (r > 230 && g > 230 && b > 230 && Math.abs(r - g) < 8 && Math.abs(g - b) < 8);
    }
    if (bgType === 'neutral_light') {
      // Studio off-white / light grey background
      const isNeutral = Math.abs(r - g) < 18 && Math.abs(g - b) < 18 && Math.abs(r - b) < 18;
      // High lightness
      if (isNeutral && r > 195 && g > 195 && b > 195) return true;
      // Floor shadow near bottom
      if (y > h * 0.88 && isNeutral && r > 150) return true;
      return false;
    }
    if (bgType === 'dark_blue') {
      // Blue/purple background [8..45, 2..20, 48..150]
      // Blue channel dominant, red and green low
      const isDarkBluePurple = b > 35 && b > r + 15 && b > g + 15 && r < 75 && g < 75;
      const isVeryDarkEdge = r < 25 && g < 25 && b < 70;
      return isDarkBluePurple || isVeryDarkEdge;
    }
    return false;
  };

  let head = 0;
  while (head < queue.length) {
    const x = queue[head++];
    const y = queue[head++];
    const idx = y * w + x;
    if (visited[idx]) continue;
    visited[idx] = 1;

    const p = idx * 4;
    const r = out[p], g = out[p + 1], b = out[p + 2];

    if (isBgPixel(r, g, b, y, x)) {
      out[p + 3] = 0; // Transparent
      if (x > 0 && !visited[idx - 1]) queue.push(x - 1, y);
      if (x < w - 1 && !visited[idx + 1]) queue.push(x + 1, y);
      if (y > 0 && !visited[idx - w]) queue.push(x, y - 1);
      if (y < h - 1 && !visited[idx + w]) queue.push(x, y + 1);
    }
  }

  // Second pass: also check between-leg gaps connected to floor
  // Find bottom floor middle
  for (let y = Math.floor(h * 0.65); y < Math.floor(h * 0.95); y++) {
    for (let x = Math.floor(w * 0.35); x < Math.floor(w * 0.65); x++) {
      const idx = y * w + x;
      if (visited[idx]) continue;
      const p = idx * 4;
      const r = out[p], g = out[p + 1], b = out[p + 2];
      if (isBgPixel(r, g, b, y, x)) {
        // Run flood fill for this enclosed island
        const islandQueue = [x, y];
        while (islandQueue.length > 0) {
          const iy = islandQueue.pop()!;
          const ix = islandQueue.pop()!;
          const iidx = iy * w + ix;
          if (visited[iidx]) continue;
          visited[iidx] = 1;
          const ip = iidx * 4;
          const ir = out[ip], ig = out[ip + 1], ib = out[ip + 2];
          if (isBgPixel(ir, ig, ib, iy, ix)) {
            out[ip + 3] = 0;
            if (ix > 0 && !visited[iidx - 1]) islandQueue.push(ix - 1, iy);
            if (ix < w - 1 && !visited[iidx + 1]) islandQueue.push(ix + 1, iy);
            if (iy > 0 && !visited[iidx - w]) islandQueue.push(ix, iy - 1);
            if (iy < h - 1 && !visited[iidx + w]) islandQueue.push(ix, iy + 1);
          }
        }
      }
    }
  }

  return out;
}

async function run() {
  console.log('Starting avatar processing for all 11 avatars...');

  const transDir = path.resolve('public/assets/images/avatars_3d/transparent');
  const mainDir = path.resolve('public/assets/images/avatars_3d');
  const modularBaseDir = path.resolve('public/assets/images/avatars_modular');

  if (!fs.existsSync(transDir)) fs.mkdirSync(transDir, { recursive: true });
  if (!fs.existsSync(mainDir)) fs.mkdirSync(mainDir, { recursive: true });
  if (!fs.existsSync(modularBaseDir)) fs.mkdirSync(modularBaseDir, { recursive: true });

  const summaryResults: any[] = [];

  for (const spec of AVATAR_SPECS) {
    console.log(`Processing ${spec.id} from ${spec.sourceFile}...`);
    const img = sharp(spec.sourceFile);
    const meta = await img.metadata();
    const w = meta.width!;
    const h = meta.height!;

    let finalRawBuffer: Buffer;

    if (spec.bgType === 'transparent') {
      // Image already has alpha channel. Clean edge halos by zeroing out very faint border alpha
      const { data, info } = await sharp(spec.sourceFile).ensureAlpha().raw().toBuffer({ resolveWithObject: true });
      for (let i = 0; i < data.length; i += 4) {
        if (data[i + 3] < 15) {
          data[i + 3] = 0;
        }
      }
      finalRawBuffer = data;
    } else {
      // Solid background -> flood-fill remove background
      const { data } = await sharp(spec.sourceFile).ensureAlpha().raw().toBuffer({ resolveWithObject: true });
      finalRawBuffer = await removeBackgroundFloodFill(data, w, h, spec.bgType);
    }

    // Save transparent PNG
    const transPath = path.join(transDir, `${spec.id}.png`);
    await sharp(finalRawBuffer, { raw: { width: w, height: h, channels: 4 } })
      .png({ compressionLevel: 8 })
      .toFile(transPath);

    // Save JPG thumbnail / card preview on subtle gradient background for gallery card
    const cardBgSvg = `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}">
      <defs>
        <radialGradient id="cardBg" cx="50%" cy="40%" r="65%">
          <stop offset="0%" stop-color="#1e1b4b"/>
          <stop offset="60%" stop-color="#0f172a"/>
          <stop offset="100%" stop-color="#020617"/>
        </radialGradient>
      </defs>
      <rect width="${w}" height="${h}" fill="url(#cardBg)"/>
    </svg>`;
    const cardBgBuf = Buffer.from(cardBgSvg);

    const jpgPath = path.join(mainDir, `${spec.id}.jpg`);
    await sharp(cardBgBuf)
      .resize(w, h)
      .composite([{ input: transPath, top: 0, left: 0 }])
      .jpeg({ quality: 90 })
      .toFile(jpgPath);

    // Create modular directory
    const modDir = path.join(modularBaseDir, spec.id);
    if (!fs.existsSync(modDir)) fs.mkdirSync(modDir, { recursive: true });
    fs.copyFileSync(transPath, path.join(modDir, 'body_skin.png'));

    // Create eyes_closed.png placeholder for blinking engine
    const blinkSvg = `<svg xmlns="http://www.w3.org/2000/svg" width="200" height="80">
      <path d="M 30,40 Q 60,60 90,40" stroke="#22181c" stroke-width="6" fill="none" stroke-linecap="round"/>
      <path d="M 110,40 Q 140,60 170,40" stroke="#22181c" stroke-width="6" fill="none" stroke-linecap="round"/>
    </svg>`;
    await sharp(Buffer.from(blinkSvg)).png().toFile(path.join(modDir, 'eyes_closed.png'));

    summaryResults.push({
      id: spec.id,
      dimensions: `${w}x${h}`,
      aspectRatio: Number((w / h).toFixed(4)),
      transPng: `/assets/images/avatars_3d/transparent/${spec.id}.png`,
      thumbnail: `/assets/images/avatars_3d/${spec.id}.jpg`,
    });
  }

  console.log('All 11 avatars processed successfully:');
  console.table(summaryResults);
}

run().catch((err) => {
  console.error(err);
  process.exit(1);
});
