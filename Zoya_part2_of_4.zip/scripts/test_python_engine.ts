// Test script to verify the Zoya Python Engine and all subsystems
import { serverPythonEngine } from '../src/services/serverPythonEngine.ts';

async function runTests() {
  console.log('==================================================');
  console.log('🧪 TESTING ZOYA PYTHON ENGINE & DEVELOPMENT STUDIO');
  console.log('==================================================\n');

  let passed = 0;
  let failed = 0;

  function assert(condition: boolean, desc: string) {
    if (condition) {
      console.log(`✓ [PASS] ${desc}`);
      passed++;
    } else {
      console.error(`✗ [FAIL] ${desc}`);
      failed++;
    }
  }

  // 1. Environment Info Test
  console.log('--- Test 1: Python Environment Audit ---');
  const envInfo = await serverPythonEngine.getEnvironmentInfo();
  assert(envInfo.pythonVersion.startsWith('3.10'), `Python version is 3.10.x (found: ${envInfo.pythonVersion})`);
  assert(envInfo.installedPackages.length > 5, `Installed packages found: ${envInfo.installedPackages.length}`);
  const pkgNames = envInfo.installedPackages.map((p) => p.name.toLowerCase());
  assert(pkgNames.includes('numpy'), 'NumPy is installed');
  assert(pkgNames.includes('pandas'), 'Pandas is installed');
  assert(pkgNames.includes('matplotlib'), 'Matplotlib is installed');
  assert(pkgNames.includes('reportlab'), 'ReportLab is installed');
  assert(pkgNames.includes('openpyxl'), 'OpenPyXL is installed');
  assert(pkgNames.includes('flask'), 'Flask is installed');
  assert(pkgNames.includes('requests'), 'Requests is installed');

  // 2. Project Listing & Default Seed Projects
  console.log('\n--- Test 2: Seeded Production Projects ---');
  const projects = serverPythonEngine.listProjects();
  assert(projects.length >= 7, `Seeded projects count >= 7 (found: ${projects.length})`);
  const projectIds = projects.map((p) => p.id);
  assert(projectIds.includes('data_science_charts'), 'Project data_science_charts exists');
  assert(projectIds.includes('pdf_invoice_reportlab'), 'Project pdf_invoice_reportlab exists');
  assert(projectIds.includes('excel_spreadsheet_openpyxl'), 'Project excel_spreadsheet_openpyxl exists');
  assert(projectIds.includes('web_scraper_requests'), 'Project web_scraper_requests exists');
  assert(projectIds.includes('flask_micro_service'), 'Project flask_micro_service exists');
  assert(projectIds.includes('pytest_unit_tests'), 'Project pytest_unit_tests exists');
  assert(projectIds.includes('android_apk_build_tools'), 'Project android_apk_build_tools exists');

  // 3. Script Execution: Data Science & Matplotlib Chart Generation
  console.log('\n--- Test 3: Script Execution & Matplotlib Chart Generation ---');
  const dsResult = await serverPythonEngine.executeScript('data_science_charts', 'main.py');
  assert(dsResult.exitCode === 0, `Data science execution exitCode is 0 (got: ${dsResult.exitCode})`);
  assert(dsResult.stdout.includes('Zoya Data Analysis Engine'), 'Stdout contains Zoya Data Analysis Engine header');
  assert(dsResult.stdout.includes('Total Revenue:'), 'Stdout contains financial summary metrics');
  const chartArtifact = dsResult.generatedFiles.find((f) => f.name.endsWith('.png'));
  assert(!!chartArtifact, 'Matplotlib PNG chart artifact generated successfully');
  if (chartArtifact) {
    assert(chartArtifact.size > 1000, `Chart size is valid (${chartArtifact.size} bytes)`);
    assert(!!chartArtifact.base64Data, 'Inline base64 image data populated for preview');
  }

  // 4. Script Execution: ReportLab PDF Generation
  console.log('\n--- Test 4: ReportLab PDF Generation ---');
  const pdfResult = await serverPythonEngine.executeScript('pdf_invoice_reportlab', 'generate_invoice.py');
  assert(pdfResult.exitCode === 0, `PDF generation exitCode is 0 (got: ${pdfResult.exitCode})`);
  assert(pdfResult.stdout.includes('PDF report successfully generated'), 'PDF built confirmation in stdout');
  const pdfArtifact = pdfResult.generatedFiles.find((f) => f.name.endsWith('.pdf'));
  assert(!!pdfArtifact, 'ReportLab PDF artifact generated');
  if (pdfArtifact) {
    assert(pdfArtifact.size > 500, `PDF size is valid (${pdfArtifact.size} bytes)`);
  }

  // 5. Script Execution: OpenPyXL Excel Spreadsheet
  console.log('\n--- Test 5: OpenPyXL Excel Spreadsheet Generation ---');
  const excelResult = await serverPythonEngine.executeScript('excel_spreadsheet_openpyxl', 'create_excel.py');
  assert(excelResult.exitCode === 0, `Excel generation exitCode is 0 (got: ${excelResult.exitCode})`);
  assert(excelResult.stdout.includes('OpenPyXL Spreadsheet Generator'), 'Excel workbook generator in stdout');
  const xlsxArtifact = excelResult.generatedFiles.find((f) => f.name.endsWith('.xlsx'));
  assert(!!xlsxArtifact, 'OpenPyXL XLSX artifact generated');

  // 6. Script Execution: Flask Microservice Test Client
  console.log('\n--- Test 6: Flask REST API Execution ---');
  const flaskResult = await serverPythonEngine.executeScript('flask_micro_service', 'api.py');
  assert(flaskResult.exitCode === 0, `Flask execution exitCode is 0 (got: ${flaskResult.exitCode})`);
  assert(flaskResult.stdout.includes('GET /api/health -> Status: 200'), 'Flask /api/health route returned 200');
  assert(flaskResult.stdout.includes('GET /api/products -> Status: 200'), 'Flask /api/products route returned 200');

  // 7. Script Execution: Android Build Structure Inspector
  console.log('\n--- Test 7: Android Build Structure Inspector ---');
  const androidResult = await serverPythonEngine.executeScript('android_apk_build_tools', 'inspect_android_build.py');
  assert(androidResult.exitCode === 0, `Android audit exitCode is 0 (got: ${androidResult.exitCode})`);
  assert(androidResult.stdout.includes('Android build structure audit completed successfully'), 'Android audit completed successfully');

  // 8. Script Execution: Pytest Test Suite
  console.log('\n--- Test 8: Pytest Test Suite Execution ---');
  const pytestResult = await serverPythonEngine.executeScript('pytest_unit_tests', 'test_suite.py');
  assert(pytestResult.exitCode === 0, `Pytest execution exitCode is 0 (got: ${pytestResult.exitCode})`);
  assert(pytestResult.stdout.includes('PASSED'), 'Pytest reported passing tests');

  // 9. Custom Script Execution & Error Diagnostics
  console.log('\n--- Test 9: Custom Script Execution & Error Diagnostics ---');
  const customCode = `
import math
print("Computed square root of 256:", math.isqrt(256))
print("Computed factorial of 6:", math.factorial(6))
`;
  const customResult = await serverPythonEngine.executeScript('data_science_charts', 'temp_math.py', customCode);
  assert(customResult.exitCode === 0, 'Custom math script executed with exitCode 0');
  assert(customResult.stdout.includes('Computed square root of 256: 16'), 'Computed square root correct (16)');
  assert(customResult.stdout.includes('Computed factorial of 6: 720'), 'Computed factorial correct (720)');

  // 10. Error capturing test
  const errorScript = `
print("Step 1 ok")
raise ValueError("Intentional test exception for error pipeline audit")
`;
  const errorResult = await serverPythonEngine.executeScript('data_science_charts', 'error_test.py', errorScript);
  assert(errorResult.exitCode !== 0, 'Error script returned non-zero exit code');
  assert(errorResult.stderr.includes('ValueError: Intentional test exception'), 'Stderr captured traceback and error details');

  console.log('\n==================================================');
  console.log(`📊 FINAL TEST RESULTS: ${passed} PASSED, ${failed} FAILED`);
  console.log('==================================================\n');

  if (failed > 0) {
    process.exit(1);
  }
}

runTests().catch((err) => {
  console.error('Fatal test error:', err);
  process.exit(1);
});
