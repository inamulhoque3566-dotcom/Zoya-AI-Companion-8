const sharp = require('sharp');
const path = require('path');

async function inspectShoesExact() {
  const src = path.join(__dirname, '../src/assets/images/zoya_3d_sweater_glasses_1793764031303.jpg');
  const { data, info } = await sharp(src).removeAlpha().raw().toBuffer({ resolveWithObject: true });
  const W = info.width, H = info.height;

  for (let y = 1345; y <= 1361; y += 3) {
    console.log(`--- y=${y} ---`);
    for (let x = 320; x <= 465; x += 5) {
      const idx = (y * W + x) * 3;
      const r = data[idx], g = data[idx+1], b = data[idx+2];
      const chroma = Math.max(Math.abs(r-g), Math.abs(r-b), Math.abs(g-b));
      if (r < 80) {
        process.stdout.write(`[${x}:SHOE] `);
      } else if (chroma <= 4 && r > 180) {
        process.stdout.write(`[${x}:BG] `);
      } else {
        process.stdout.write(`[${x}:${r},${g},${b}] `);
      }
    }
    console.log();
  }
}
inspectShoesExact().catch(console.error);
