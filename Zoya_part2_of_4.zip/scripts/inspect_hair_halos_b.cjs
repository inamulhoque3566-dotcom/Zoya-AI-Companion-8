const sharp = require('sharp');

async function inspectHairHalosAndHands() {
  const { data, info } = await sharp('public/assets/images/avatars_3d/transparent/avatar_midnight_gold_zari_saree.png')
    .raw()
    .toBuffer({ resolveWithObject: true });

  const src = await sharp('public/assets/aistudio/file_00000000c0d4821189e14bf178224f8d_f1687d5b.png')
    .raw()
    .toBuffer({ resolveWithObject: true });

  const w = info.width;
  const h = info.height;

  // Let's check hair perimeter (y: 100..450, x: 250..750)
  // Check for any leftover pixels or halos where alpha > 0
  let hairHalos = 0;
  for (let y = 100; y < 450; y++) {
    for (let x = 200; x < 800; x++) {
      const idx = (y * w + x) * 4;
      const a = data[idx + 3];
      if (a > 0 && a < 255) {
        // Semi-transparent pixel around hair
        const r = data[idx], g = data[idx+1], b = data[idx+2];
        // If it was navy background bleed (b > r + 15)
        if (b > r + 15 && b > 25) {
          hairHalos++;
        }
      }
    }
  }
  console.log('Navy background bleed pixels around hair:', hairHalos);

  // Check hands and sides of body (y: 450..900)
  // Left side: x ~ 250..400
  // Right side: x ~ 650..850
  let sideHalos = 0;
  for (let y = 450; y < 900; y++) {
    for (let x = 200; x < 900; x++) {
      const idx = (y * w + x) * 4;
      const a = data[idx + 3];
      if (a > 0 && a < 255) {
        const r = data[idx], g = data[idx+1], b = data[idx+2];
        if (b > r + 20 && b > 35) {
          sideHalos++;
        }
      }
    }
  }
  console.log('Navy background bleed pixels around body sides and hands:', sideHalos);
}

inspectHairHalosAndHands().catch(console.error);
