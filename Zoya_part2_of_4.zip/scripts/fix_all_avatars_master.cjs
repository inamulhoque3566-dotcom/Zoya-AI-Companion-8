const fs = require('fs');
const path = require('path');
const sharp = require('sharp');

// 20 Registered Avatars with their uncorrupted source files, destinations, and custom parameters
const AVATARS = [
  {
    id: 'boho_mini_dress',
    name: 'Boho Floral Mini Dress',
    src: 'public/assets/aistudio/1794057080707_73517bc8.png',
    dest: 'public/assets/images/avatars_3d/transparent/avatar_boho_mini_dress.png',
    preview: 'public/assets/images/avatars_3d/avatar_boho_mini_dress.jpg',
    modular: 'public/assets/images/avatars_modular/boho_mini_dress/body_skin.png',
    bgType: 'dark_navy',
    removeFloorShadow: false,
    expectedFeetY: 1230
  },
  {
    id: 'peasant_blouse_skirt',
    name: 'Peasant Blouse & Lavender Skirt',
    src: 'public/assets/aistudio/1794056986583_b7a662a3.png',
    dest: 'public/assets/images/avatars_3d/transparent/avatar_peasant_blouse_skirt.png',
    preview: 'public/assets/images/avatars_3d/avatar_peasant_blouse_skirt.jpg',
    modular: 'public/assets/images/avatars_modular/peasant_blouse_skirt/body_skin.png',
    bgType: 'dark_navy',
    removeFloorShadow: false,
    expectedFeetY: 1360
  },
  {
    id: 'pink_knit_maxi',
    name: 'Pink Rib Knit & White Maxi',
    src: 'public/assets/images/avatars_3d/avatar_pink_knit_maxi.jpg',
    dest: 'public/assets/images/avatars_3d/transparent/avatar_pink_knit_maxi.png',
    preview: 'public/assets/images/avatars_3d/avatar_pink_knit_maxi.jpg',
    modular: 'public/assets/images/avatars_modular/pink_knit_maxi/body_skin.png',
    bgType: 'dark_navy',
    removeFloorShadow: false,
    expectedFeetY: 1345
  },
  {
    id: 'floral_palazzo_pants',
    name: 'Floral Palazzo Pants Ensemble',
    src: 'public/assets/aistudio/1794056834343_4889389a.png',
    dest: 'public/assets/images/avatars_3d/transparent/avatar_floral_palazzo_pants.png',
    preview: 'public/assets/images/avatars_3d/avatar_floral_palazzo_pants.jpg',
    modular: 'public/assets/images/avatars_modular/floral_palazzo_pants/body_skin.png',
    bgType: 'dark_navy',
    removeFloorShadow: true,
    shadowCutoffY: 1335,
    feetMaxY: 1360,
    shadowKeepXMin: 260,
    shadowKeepXMax: 500,
    expectedFeetY: 1355
  },
  {
    id: 'red_cardigan_floral',
    name: 'Red Cardigan & Floral Skirt',
    src: 'public/assets/images/avatars_3d/avatar_red_cardigan_floral.jpg',
    dest: 'public/assets/images/avatars_3d/transparent/avatar_red_cardigan_floral.png',
    preview: 'public/assets/images/avatars_3d/avatar_red_cardigan_floral.jpg',
    modular: 'public/assets/images/avatars_modular/red_cardigan_floral/body_skin.png',
    bgType: 'dark_navy',
    removeFloorShadow: false,
    expectedFeetY: 1165
  },
  {
    id: 'plum_royal_anarkali',
    name: 'Royal Plum Zari Anarkali',
    src: 'pristine_sources/avatar_plum_royal_anarkali.jpg',
    dest: 'public/assets/images/avatars_3d/transparent/avatar_plum_royal_anarkali.png',
    preview: 'public/assets/images/avatars_3d/avatar_plum_royal_anarkali.jpg',
    modular: 'public/assets/images/avatars_modular/plum_royal_anarkali/body_skin.png',
    bgType: 'dark_navy',
    removeFloorShadow: true,
    shadowCutoffY: 1318,
    feetMaxY: 1334,
    shadowKeepXMin: 300,
    shadowKeepXMax: 460,
    expectedFeetY: 1334
  },
  {
    id: 'ivory_floral_anarkali',
    name: 'Ivory & Rose Floral Anarkali',
    src: 'pristine_sources/avatar_ivory_floral_anarkali.jpg',
    dest: 'public/assets/images/avatars_3d/transparent/avatar_ivory_floral_anarkali.png',
    preview: 'public/assets/images/avatars_3d/avatar_ivory_floral_anarkali.jpg',
    modular: 'public/assets/images/avatars_modular/ivory_floral_anarkali/body_skin.png',
    bgType: 'dark_navy',
    removeFloorShadow: true,
    shadowCutoffY: 1340,
    expectedFeetY: 1338
  },
  {
    id: 'classic',
    name: 'Classic Sweater & Glasses (Zoya)',
    src: 'public/assets/images/anime_princess_3d_transparent.png',
    dest: 'public/assets/images/zoya_new_avatar_transparent.png',
    altDest: 'public/assets/images/avatars_3d/transparent/anime_princess_3d.png',
    preview: 'public/assets/images/zoya_master_render.jpg',
    modular: 'public/assets/images/avatars_modular/classic/body_skin.png',
    bgType: 'already_transparent',
    expectedFeetY: 1358
  },
  {
    id: 'elegant_saree',
    name: 'Traditional Elegant Saree',
    src: 'pristine_sources/elegant_saree_avatar.jpg',
    dest: 'public/assets/images/elegant_saree_avatar_transparent.png',
    altDest: 'public/assets/images/avatars_3d/transparent/elegant_saree.png',
    preview: 'public/assets/images/elegant_saree_avatar.jpg',
    modular: 'public/assets/images/avatars_modular/elegant_saree/body_skin.png',
    bgType: 'white_studio',
    removeFloorShadow: true,
    shadowCutoffY: 1335,
    feetMaxY: 1356,
    shadowKeepXMin: 280,
    shadowKeepXMax: 660,
    expectedFeetY: 1356
  },
  {
    id: 'avatar_urban_crop_hoodie',
    name: 'Urban Crop Hoodie & Cargo Joggers',
    src: 'public/assets/aistudio/file_00000000d12881f68a210961f707e2f7_2252122d.png',
    dest: 'public/assets/images/avatars_3d/transparent/avatar_urban_crop_hoodie.png',
    preview: 'public/assets/images/avatars_3d/avatar_urban_crop_hoodie.jpg',
    modular: 'public/assets/images/avatars_modular/avatar_urban_crop_hoodie/body_skin.png',
    bgType: 'dark_navy_alpha',
    expectedFeetY: 1671
  },
  {
    id: 'avatar_white_ruffle_babydoll',
    name: 'White Satin Ruffle Babydoll',
    src: 'public/assets/aistudio/file_00000000714082118158b0be2e90f7cf_7fe119d0.png',
    dest: 'public/assets/images/avatars_3d/transparent/avatar_white_ruffle_babydoll.png',
    preview: 'public/assets/images/avatars_3d/avatar_white_ruffle_babydoll.jpg',
    modular: 'public/assets/images/avatars_modular/avatar_white_ruffle_babydoll/body_skin.png',
    bgType: 'dark_navy_alpha',
    expectedFeetY: 1535
  },
  {
    id: 'avatar_pink_athleisure_track',
    name: 'Pink Athleisure Tracksuit',
    src: 'public/assets/aistudio/1794316198287_50e22112.png',
    dest: 'public/assets/images/avatars_3d/transparent/avatar_pink_athleisure_track.png',
    preview: 'public/assets/images/avatars_3d/avatar_pink_athleisure_track.jpg',
    modular: 'public/assets/images/avatars_modular/avatar_pink_athleisure_track/body_skin.png',
    bgType: 'white_studio',
    removeFloorShadow: true,
    shadowCutoffY: 1346,
    expectedFeetY: 1345
  },
  {
    id: 'avatar_scarlet_peasant_cargo',
    name: 'Scarlet Peasant Blouse & Olive Skirt',
    src: 'public/assets/aistudio/file_0000000091d48207b6f9f29a32014cf0_bd82fc9f.png',
    dest: 'public/assets/images/avatars_3d/transparent/avatar_scarlet_peasant_cargo.png',
    preview: 'public/assets/images/avatars_3d/avatar_scarlet_peasant_cargo.jpg',
    modular: 'public/assets/images/avatars_modular/avatar_scarlet_peasant_cargo/body_skin.png',
    bgType: 'dark_navy_alpha',
    expectedFeetY: 1534
  },
  {
    id: 'avatar_pastel_blue_knit_shorts',
    name: 'Pastel Blue Knit & Pink Shorts',
    src: 'public/assets/aistudio/file_00000000eb7881fa8a888c25bfc4c0f7_32dd4f88.png',
    dest: 'public/assets/images/avatars_3d/transparent/avatar_pastel_blue_knit_shorts.png',
    preview: 'public/assets/images/avatars_3d/avatar_pastel_blue_knit_shorts.jpg',
    modular: 'public/assets/images/avatars_modular/avatar_pastel_blue_knit_shorts/body_skin.png',
    bgType: 'dark_navy_alpha',
    expectedFeetY: 1671
  },
  {
    id: 'avatar_violet_ruffle_cocktail',
    name: 'Violet Off-Shoulder Frill Dress',
    src: 'public/assets/aistudio/file_00000000156481faa774d203567b03c2_733a5cf3.png',
    dest: 'public/assets/images/avatars_3d/transparent/avatar_violet_ruffle_cocktail.png',
    preview: 'public/assets/images/avatars_3d/avatar_violet_ruffle_cocktail.jpg',
    modular: 'public/assets/images/avatars_modular/avatar_violet_ruffle_cocktail/body_skin.png',
    bgType: 'white_studio',
    removeFloorShadow: true,
    shadowCutoffY: 1470,
    feetMaxY: 1530,
    shadowKeepXMin: 450,
    shadowKeepXMax: 610,
    expectedFeetY: 1528
  },
  {
    id: 'avatar_slate_blue_regal_kurta',
    name: 'Slate Blue Regal Kurta & Cape',
    src: 'public/assets/aistudio/file_000000009b6081f589589ca050473a44_1a702475.png',
    dest: 'public/assets/images/avatars_3d/transparent/avatar_slate_blue_regal_kurta.png',
    preview: 'public/assets/images/avatars_3d/avatar_slate_blue_regal_kurta.jpg',
    modular: 'public/assets/images/avatars_modular/avatar_slate_blue_regal_kurta/body_skin.png',
    bgType: 'dark_navy_alpha',
    expectedFeetY: 1671
  },
  {
    id: 'avatar_midnight_gold_zari_saree',
    name: 'Midnight Black & Gold Zari Saree',
    src: 'public/assets/aistudio/file_00000000c0d4821189e14bf178224f8d_f1687d5b.png',
    dest: 'public/assets/images/avatars_3d/transparent/avatar_midnight_gold_zari_saree.png',
    preview: 'public/assets/images/avatars_3d/avatar_midnight_gold_zari_saree.jpg',
    modular: 'public/assets/images/avatars_modular/avatar_midnight_gold_zari_saree/body_skin.png',
    bgType: 'dark_navy_alpha',
    removeFloorShadow: true,
    shadowCutoffY: 1510,
    feetMaxY: 1530,
    shadowKeepXMin: 360,
    shadowKeepXMax: 620,
    expectedFeetY: 1530
  },
  {
    id: 'avatar_black_lace_mermaid_saree',
    name: 'Black Embroidered Mermaid Saree',
    src: 'public/assets/aistudio/file_0000000049f48211942df25c415acd25_3bf70b59.png',
    dest: 'public/assets/images/avatars_3d/transparent/avatar_black_lace_mermaid_saree.png',
    preview: 'public/assets/images/avatars_3d/avatar_black_lace_mermaid_saree.jpg',
    modular: 'public/assets/images/avatars_modular/avatar_black_lace_mermaid_saree/body_skin.png',
    bgType: 'white_studio',
    removeFloorShadow: true,
    shadowCutoffY: 1490,
    feetMaxY: 1530,
    shadowKeepXMin: 350,
    shadowKeepXMax: 750,
    expectedFeetY: 1530
  },
  {
    id: 'avatar_nautical_denim_shorts',
    name: 'Silk Blouse & Nautical Denim Shorts',
    src: 'public/assets/aistudio/file_000000009d4482078f1192d031bddc07_a2c80c89.png',
    dest: 'public/assets/images/avatars_3d/transparent/avatar_nautical_denim_shorts.png',
    preview: 'public/assets/images/avatars_3d/avatar_nautical_denim_shorts.jpg',
    modular: 'public/assets/images/avatars_modular/avatar_nautical_denim_shorts/body_skin.png',
    bgType: 'dark_navy_nautical',
    expectedFeetY: 1485
  },
  {
    id: 'avatar_parisian_beret_skater',
    name: 'Parisian Beret & Pleated Skirt',
    src: 'public/assets/aistudio/27d4c655521f0e120597d929710fca20_88a75c28.jpg',
    dest: 'public/assets/images/avatars_3d/transparent/avatar_parisian_beret_skater.png',
    preview: 'public/assets/images/avatars_3d/avatar_parisian_beret_skater.jpg',
    modular: 'public/assets/images/avatars_modular/avatar_parisian_beret_skater/body_skin.png',
    bgType: 'white_studio',
    removeFloorShadow: true,
    shadowCutoffY: 1296,
    expectedFeetY: 1295
  }
];

// Helper: Flood fill for background separation
function segmentAvatar(imgData, width, height, bgType, options = {}) {
  const ch = imgData.length / (width * height);
  const isBg = new Uint8Array(width * height);
  const visited = new Uint8Array(width * height);
  const queue = [];

  // Define background condition based on type
  function checkPixelIsBg(idx, x, y) {
    const r = imgData[idx];
    const g = imgData[idx + 1];
    const b = imgData[idx + 2];
    const a = ch === 4 ? imgData[idx + 3] : 255;

    if (bgType === 'already_transparent') {
      return a < 30;
    }

    if (bgType === 'dark_navy_alpha') {
      // In original alpha PNG, if a is already 0, it is bg
      if (ch === 4 && a < 20) return true;
      // Or dark blue/black background border
      return (r < 25 && g < 15 && b < 45);
    }

    if (bgType === 'dark_navy_nautical') {
      // Specifically preserve the black high heels!
      // Nautical denim background is deep indigo/navy blue: b >= 30, and b > r + 10, b > g + 10
      // Shoes are neutral black/grey: r ~ 15-80, g ~ 15-70, b ~ 20-75, with b - r < 10
      if (b > r + 12 && b > g + 12 && r < 50 && g < 35) return true;
      if (r < 28 && g < 15 && b > 25) return true;
      return false;
    }

    if (bgType === 'dark_navy') {
      // General dark navy studio backdrop: R < 35, G < 25, B < 65, or strong blue tint
      if (r < 32 && g < 22 && b < 60) return true;
      if (b > r + 15 && b > g + 15 && r < 50 && g < 40) return true;
      return false;
    }

    if (bgType === 'white_studio') {
      // White studio backdrop: r > 240, g > 240, b > 240
      // Floor area near bottom may have faint shadow (r > 200, g > 200, b > 200)
      if (r > 238 && g > 238 && b > 238) return true;
      if (y > height * 0.85 && r > 215 && g > 215 && b > 215 && Math.abs(r - g) < 12 && Math.abs(g - b) < 12) {
        return true;
      }
      return false;
    }

    return false;
  }

  // Seed flood fill from image perimeter
  for (let x = 0; x < width; x++) {
    const topIdx = x * ch;
    if (checkPixelIsBg(topIdx, x, 0)) {
      visited[x] = 1;
      isBg[x] = 1;
      queue.push(x, 0);
    }
    const btmPos = (height - 1) * width + x;
    const btmIdx = btmPos * ch;
    if (checkPixelIsBg(btmIdx, x, height - 1)) {
      visited[btmPos] = 1;
      isBg[btmPos] = 1;
      queue.push(x, height - 1);
    }
  }

  for (let y = 1; y < height - 1; y++) {
    const leftPos = y * width;
    const leftIdx = leftPos * ch;
    if (checkPixelIsBg(leftIdx, 0, y)) {
      visited[leftPos] = 1;
      isBg[leftPos] = 1;
      queue.push(0, y);
    }
    const rightPos = y * width + (width - 1);
    const rightIdx = rightPos * ch;
    if (checkPixelIsBg(rightIdx, width - 1, y)) {
      visited[rightPos] = 1;
      isBg[rightPos] = 1;
      queue.push(width - 1, y);
    }
  }

  let head = 0;
  while (head < queue.length) {
    const cx = queue[head++];
    const cy = queue[head++];

    const neighbors = [
      [cx + 1, cy], [cx - 1, cy], [cx, cy + 1], [cx, cy - 1]
    ];

    for (const [nx, ny] of neighbors) {
      if (nx >= 0 && nx < width && ny >= 0 && ny < height) {
        const npos = ny * width + nx;
        if (!visited[npos]) {
          const nidx = npos * ch;
          if (checkPixelIsBg(nidx, nx, ny)) {
            visited[npos] = 1;
            isBg[npos] = 1;
            queue.push(nx, ny);
          }
        }
      }
    }
  }

  // Handle floor shadows specifically if requested
  if (options.removeFloorShadow && options.shadowCutoffY) {
    for (let y = options.shadowCutoffY; y < height; y++) {
      for (let x = 0; x < width; x++) {
        const pos = y * width + x;
        const idx = pos * ch;
        const r = imgData[idx], g = imgData[idx + 1], b = imgData[idx + 2];
        
        // If outside protected feet horizontal bounding box, it is definitely floor shadow
        if (options.shadowKeepXMin !== undefined && options.shadowKeepXMax !== undefined) {
          if (x < options.shadowKeepXMin || x > options.shadowKeepXMax) {
            isBg[pos] = 1;
            continue;
          }
        }

        // If below the actual feet max Y (below shoe soles), everything is ground
        if (options.feetMaxY && y > options.feetMaxY) {
          isBg[pos] = 1;
          continue;
        }
        
        // Inside the protected horizontal zone above feetMaxY:
        // Only mark as background if it actually matches floor/shadow color, NOT foreground shoe/dress colors!
        if (bgType === 'white_studio') {
          // Grey shadow or floor gradient (neutral high values)
          if (r > 190 && g > 190 && b > 190 && Math.abs(r - g) < 12 && Math.abs(g - b) < 12) {
            isBg[pos] = 1;
          }
        } else {
          // dark navy floor shadow
          if ((r < 32 && g < 22 && b < 65) || (r < 40 && g < 30 && b > r + 15)) {
            isBg[pos] = 1;
          }
        }
      }
    }
  }

  // Create clean alpha channel with anti-aliasing
  const outData = Buffer.alloc(width * height * 4);
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const pos = y * width + x;
      const srcIdx = pos * ch;
      const outIdx = pos * 4;

      outData[outIdx] = imgData[srcIdx];
      outData[outIdx + 1] = imgData[srcIdx + 1];
      outData[outIdx + 2] = imgData[srcIdx + 2];

      if (isBg[pos]) {
        outData[outIdx + 3] = 0;
      } else {
        // Check distance to nearest bg pixel for smooth 1.5px feathering
        let bgNeighbors = 0;
        for (let dy = -1; dy <= 1; dy++) {
          for (let dx = -1; dx <= 1; dx++) {
            if (dx === 0 && dy === 0) continue;
            const qx = x + dx, qy = y + dy;
            if (qx < 0 || qx >= width || qy < 0 || qy >= height || isBg[qy * width + qx]) {
              bgNeighbors++;
            }
          }
        }
        if (bgNeighbors > 0) {
          outData[outIdx + 3] = Math.max(80, Math.floor(255 * (1 - (bgNeighbors / 12))));
        } else {
          outData[outIdx + 3] = 255;
        }
      }
    }
  }

  return outData;
}

async function run() {
  console.log('=== FIXING ALL 20 AVATARS ===');
  const results = [];

  for (const av of AVATARS) {
    console.log(`\nProcessing: ${av.id} (${av.name}) from ${av.src}...`);
    if (!fs.existsSync(av.src)) {
      console.error(`  ERROR: Source not found: ${av.src}`);
      continue;
    }

    const img = sharp(av.src);
    const meta = await img.metadata();
    const { data: rawSrc, info } = await img.raw().toBuffer({ resolveWithObject: true });

    // Segment foreground from background
    const rgba = segmentAvatar(rawSrc, info.width, info.height, av.bgType, {
      removeFloorShadow: av.removeFloorShadow,
      shadowCutoffY: av.shadowCutoffY,
      feetMaxY: av.feetMaxY,
      shadowKeepXMin: av.shadowKeepXMin,
      shadowKeepXMax: av.shadowKeepXMax
    });

    // Make sure parent dirs exist
    fs.mkdirSync(path.dirname(av.dest), { recursive: true });
    if (av.altDest) fs.mkdirSync(path.dirname(av.altDest), { recursive: true });
    if (av.modular) fs.mkdirSync(path.dirname(av.modular), { recursive: true });

    // Save transparent PNG
    await sharp(rgba, { raw: { width: info.width, height: info.height, channels: 4 } })
      .png({ compressionLevel: 9 })
      .toFile(av.dest);
    console.log(`  Saved transparent PNG: ${av.dest}`);

    if (av.altDest) {
      await sharp(rgba, { raw: { width: info.width, height: info.height, channels: 4 } })
        .png({ compressionLevel: 9 })
        .toFile(av.altDest);
      console.log(`  Saved alt transparent PNG: ${av.altDest}`);
    }

    // Save modular layer
    if (av.modular) {
      await sharp(rgba, { raw: { width: info.width, height: info.height, channels: 4 } })
        .png({ compressionLevel: 9 })
        .toFile(av.modular);
      console.log(`  Saved modular body layer: ${av.modular}`);
    }

    // Save clean preview asset (PNG or high quality JPG with clean aesthetic)
    // To ensure Settings -> Avatar displays transparent preview without black/white box,
    // we also update the preview JPG to render on a stylish transparent/subtle neutral background or provide clean preview
    if (av.preview) {
      // Composite over subtle soft transparent or neutral gradient
      await sharp(rgba, { raw: { width: info.width, height: info.height, channels: 4 } })
        .flatten({ background: { r: 12, g: 14, b: 30 } }) // App dark luxury theme background
        .jpeg({ quality: 92 })
        .toFile(av.preview);
      console.log(`  Updated preview thumbnail: ${av.preview}`);
    }

    // Verification check
    const checkImg = sharp(av.dest);
    const checkRaw = await checkImg.raw().toBuffer({ resolveWithObject: true });
    const cTL = checkRaw.data[3];
    const cTR = checkRaw.data[(info.width - 1) * 4 + 3];
    const cBL = checkRaw.data[((info.height - 1) * info.width) * 4 + 3];
    const cBR = checkRaw.data[((info.height - 1) * info.width + (info.width - 1)) * 4 + 3];

    let minX = info.width, maxX = 0, minY = info.height, maxY = 0;
    for (let y = 0; y < info.height; y++) {
      for (let x = 0; x < info.width; x++) {
        const a = checkRaw.data[(y * info.width + x) * 4 + 3];
        if (a > 20) {
          if (x < minX) minX = x;
          if (x > maxX) maxX = x;
          if (y < minY) minY = y;
          if (y > maxY) maxY = y;
        }
      }
    }

    // Measure spread at bottom 30 rows
    let bottomSpread = 0;
    for (let y = Math.max(0, maxY - 20); y <= maxY; y++) {
      let rMin = info.width, rMax = 0;
      for (let x = 0; x < info.width; x++) {
        if (checkRaw.data[(y * info.width + x) * 4 + 3] > 25) {
          if (x < rMin) rMin = x;
          if (x > rMax) rMax = x;
        }
      }
      if (rMax >= rMin && (rMax - rMin) > bottomSpread) bottomSpread = rMax - rMin;
    }
    const spreadPct = (bottomSpread / info.width * 100).toFixed(1);

    results.push({
      id: av.id,
      name: av.name,
      dimensions: `${info.width}x${info.height}`,
      cornersAlpha: [cTL, cTR, cBL, cBR],
      feetY: maxY,
      feetSpreadPct: spreadPct + '%',
      intact: maxY >= (av.expectedFeetY - 15)
    });
  }

  console.log('\n=== FINAL VERIFICATION SUMMARY ===');
  console.table(results);
}

run().catch(console.error);
