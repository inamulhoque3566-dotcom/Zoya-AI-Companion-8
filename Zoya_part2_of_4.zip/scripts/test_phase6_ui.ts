const BASE_URL = 'http://localhost:3000';

async function jsonReq(url: string, options: any = {}) {
  const res = await fetch(url, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(options.headers || {}),
    },
    body: options.body ? (typeof options.body === 'string' ? options.body : JSON.stringify(options.body)) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  return { status: res.status, data };
}

async function runPhase6Tests() {
  console.log('========================================================================');
  console.log('🔍 PHASE 6: UI ENDPOINTS & WORKSPACE INTEGRATION VERIFICATION');
  console.log('========================================================================');

  let passed = 0;
  let failed = 0;

  function assert(desc: string, condition: boolean, detail?: any) {
    if (condition) {
      console.log(`  ✅ [PASS] ${desc}`);
      passed++;
    } else {
      console.error(`  ❌ [FAIL] ${desc}`, detail || '');
      failed++;
    }
  }

  // 1. One-time pairing code flow bootstrap
  console.log('\n--- 1. Testing Pairing Code Bootstrap & Token Issuance ---');
  let pairingCode = '';
  let token = '';
  try {
    const pRes = await jsonReq(`${BASE_URL}/api/agent/auth/pairing-code`, {
      method: 'POST',
      body: { passphrase: 'OwnerSecurePassphrase2026!' },
      headers: {
        'User-Agent': 'Mozilla/5.0 (Linux; Android 14; Mobile; rv:128.0) Gecko/128.0 Firefox/128.0',
      },
    });
    pairingCode = pRes.data.pairingCode || pRes.data.code;
    assert('Generated one-time pairing code with owner passphrase', !!pairingCode && pairingCode.length >= 6);

    const tRes = await jsonReq(`${BASE_URL}/api/agent/auth/token?code=${pairingCode}`, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Linux; Android 14; Mobile; rv:128.0) Gecko/128.0 Firefox/128.0',
      },
    });
    token = tRes.data.token;
    assert('Exchanged pairing code for agent token', !!token && tRes.data.success === true);
  } catch (e: any) {
    assert('Pairing flow succeeded', false, e.message);
  }

  const authHeaders = {
    Authorization: `Bearer ${token}`,
    'x-agent-auth-token': token,
  };

  // 2. Status & Limits
  console.log('\n--- 2. Agent Status & Security Limits UI Endpoint ---');
  try {
    const sRes = await jsonReq(`${BASE_URL}/api/agent/status`, { headers: authHeaders });
    assert('Agent status returned', sRes.data.success === true);
  } catch (e: any) {
    assert('Status returned successfully', false, e.message);
  }

  // 3. Tab 3: Real Terminal Execution Endpoint
  console.log('\n--- 3. Tab 3: Real Terminal Execution Endpoint ---');
  try {
    const cmdRes = await jsonReq(`${BASE_URL}/api/agent/terminal/execute`, {
      method: 'POST',
      headers: authHeaders,
      body: { command: 'pwd' },
    });
    assert('Terminal command executed or queued for approval', cmdRes.data.success === true || cmdRes.status === 202);
  } catch (e: any) {
    assert('Terminal command succeeded', false, e.message);
  }

  // 4. Tab 4: Project Files Tree & Read
  console.log('\n--- 4. Tab 4: Project Files Tree & Read ---');
  try {
    const treeRes = await jsonReq(`${BASE_URL}/api/agent/files/tree`, { headers: authHeaders });
    assert('Fetched files tree', treeRes.data.success === true && !!treeRes.data.tree);

    const readRes = await jsonReq(`${BASE_URL}/api/agent/files/read?path=live_api_test.txt`, { headers: authHeaders });
    assert('Read file contents (live_api_test.txt)', readRes.data.success === true && !!readRes.data.file?.content);
  } catch (e: any) {
    assert('File operations succeeded', false, e.message);
  }

  // 5. Tab 5: Skills Library (Installed)
  console.log('\n--- 5. Tab 5: Skills Library Listing ---');
  try {
    const skillsRes = await jsonReq(`${BASE_URL}/api/agent/skills`, { headers: authHeaders });
    assert('Fetched installed skills', skillsRes.data.success === true && Array.isArray(skillsRes.data.skills));
  } catch (e: any) {
    assert('Skills library endpoints succeeded', false, e.message);
  }

  // 6. Tab 6: MCP Servers (Listing)
  console.log('\n--- 6. Tab 6: MCP Servers Listing ---');
  try {
    const mcpRes = await jsonReq(`${BASE_URL}/api/agent/mcp/servers`, { headers: authHeaders });
    assert('Fetched MCP servers list', mcpRes.data.success === true && Array.isArray(mcpRes.data.servers));
  } catch (e: any) {
    assert('MCP endpoints succeeded', false, e.message);
  }

  // 7. Tab 8: Security Audit Logs
  console.log('\n--- 7. Tab 8: Security Audit Logs Endpoint ---');
  try {
    const logsRes = await jsonReq(`${BASE_URL}/api/agent/security/logs`, { headers: authHeaders });
    assert('Fetched audit logs', logsRes.data.success === true && Array.isArray(logsRes.data.logs));
    const raw = JSON.stringify(logsRes.data.logs);
    assert('Audit logs mask secrets', !raw.includes('AIzaSy') && !raw.includes('secret-12345'));
  } catch (e: any) {
    assert('Audit logs succeeded', false, e.message);
  }

  // 8. Tab 2: Approvals Listing
  console.log('\n--- 8. Tab 2: Approvals Listing Endpoint ---');
  try {
    const apprRes = await jsonReq(`${BASE_URL}/api/agent/approvals`, { headers: authHeaders });
    assert('Fetched pending approvals', apprRes.data.success === true && Array.isArray(apprRes.data.pending));
  } catch (e: any) {
    assert('Approvals endpoint succeeded', false, e.message);
  }

  console.log('\n========================================================================');
  console.log(`PHASE 6 VERIFICATION COMPLETE: ${passed} PASSED, ${failed} FAILED`);
  console.log('========================================================================');

  if (failed > 0) {
    process.exit(1);
  }
}

runPhase6Tests().catch((e) => {
  console.error('Fatal error in Phase 6 verification:', e);
  process.exit(1);
});
