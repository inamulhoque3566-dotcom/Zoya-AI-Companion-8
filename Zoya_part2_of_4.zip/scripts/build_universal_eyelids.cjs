const sharp = require('sharp');
const fs = require('fs');
const path = require('path');

const AVATAR_SPECS = [
          {
    id: 'casual_anime',
    file: 'public/assets/images/casual_anime_avatar_transparent.png',
    outDir: 'public/assets/images/avatars_modular/casual_anime',
    eyeCenterX: 387,
    eyeCenterY: 220,
    cropW: 190,
    cropH: 80,
    width: 768,
    height: 1376,
  },
  {
    id: 'elegant_anime',
    file: 'public/assets/images/elegant_anime_avatar_transparent.png',
    outDir: 'public/assets/images/avatars_modular/elegant_anime',
    eyeCenterX: 383,
    eyeCenterY: 233,
    cropW: 200,
    cropH: 85,
    width: 768,
    height: 1376,
  },
  {
    id: 'elegant_saree',
    file: 'public/assets/images/elegant_saree_avatar_transparent.png',
    outDir: 'public/assets/images/avatars_modular/elegant_saree',
    eyeCenterX: 383,
    eyeCenterY: 227,
    cropW: 210,
    cropH: 85,
    width: 768,
    height: 1376,
  },
];

async function generateEyelidBlendshape(spec) {
  const { id, file, outDir, eyeCenterX, eyeCenterY, cropW, cropH, width, height } = spec;
  fs.mkdirSync(outDir, { recursive: true });

  const img = sharp(file);
  const { data, info } = await img.raw().toBuffer({ resolveWithObject: true });
  const W = info.width, H = info.height;

  const startX = Math.max(0, eyeCenterX - Math.floor(cropW / 2));
  const startY = Math.max(0, eyeCenterY - Math.floor(cropH / 2));
  const actualW = Math.min(W - startX, cropW);
  const actualH = Math.min(H - startY, cropH);

  // Sample skin tone from just above the upper eyelid fold
  let skinR = 245, skinG = 210, skinB = 200;
  let count = 0;
  for (let y = Math.max(0, startY - 12); y < startY; y++) {
    for (let x = startX + 15; x < startX + actualW - 15; x++) {
      const idx = (y * W + x) * info.channels;
      const a = info.channels === 4 ? data[idx + 3] : 255;
      if (a > 200) {
        skinR += data[idx];
        skinG += data[idx + 1];
        skinB += data[idx + 2];
        count++;
      }
    }
  }
  if (count > 0) {
    skinR = Math.round(skinR / count);
    skinG = Math.round(skinG / count);
    skinB = Math.round(skinB / count);
  }

  const outRgba = new Uint8Array(actualW * actualH * 4);

  for (let cy = 0; cy < actualH; cy++) {
    const y = startY + cy;
    const relY = cy / actualH; // 0..1

    for (let cx = 0; cx < actualW; cx++) {
      const x = startX + cx;
      const srcIdx = (y * W + x) * info.channels;
      const dstIdx = (cy * actualW + cx) * 4;

      const r = data[srcIdx];
      const g = data[srcIdx + 1];
      const b = data[srcIdx + 2];
      const a = info.channels === 4 ? data[srcIdx + 3] : 255;

      // Elliptical distance from center for smooth feathering
      const nx = (cx - actualW / 2) / (actualW / 2);
      const ny = (cy - actualH / 2) / (actualH / 2);
      const dist = Math.hypot(nx, ny);
      const featherAlpha = Math.max(0, Math.min(1, 1 - (dist - 0.45) / 0.55));

      // Is dark eyelash or eyeliner contour
      const isEyelashLine = (relY >= 0.42 && relY <= 0.65) && (r < 80 && g < 60 && b < 60);

      if (a > 20 && featherAlpha > 0) {
        if (isEyelashLine) {
          // Dark delicate resting lash line
          outRgba[dstIdx] = Math.round(r * 0.75);
          outRgba[dstIdx + 1] = Math.round(g * 0.75);
          outRgba[dstIdx + 2] = Math.round(b * 0.75);
          outRgba[dstIdx + 3] = Math.round(255 * featherAlpha);
        } else if (relY >= 0.15 && relY <= 0.85) {
          // Natural closed eyelid skin with subtle shading
          const shade = 1.0 - Math.abs(relY - 0.5) * 0.12;
          outRgba[dstIdx] = Math.round(skinR * shade);
          outRgba[dstIdx + 1] = Math.round(skinG * shade);
          outRgba[dstIdx + 2] = Math.round(skinB * shade);
          outRgba[dstIdx + 3] = Math.round(248 * featherAlpha);
        } else {
          outRgba[dstIdx + 3] = 0;
        }
      } else {
        outRgba[dstIdx + 3] = 0;
      }
    }
  }

  const outPath = path.join(outDir, 'eyes_closed.png');
  await sharp(outRgba, { raw: { width: actualW, height: actualH, channels: 4 } })
    .png()
    .toFile(outPath);

  console.log(`Generated eyelid blendshape for ${id}: ${outPath} (${actualW}x${actualH})`);
  return {
    id,
    cropW: actualW,
    cropH: actualH,
    eyeCenterX,
    eyeCenterY,
  };
}

async function run() {
  console.log('=== GENERATING UNIVERSAL EYELIDS FOR ALL AVATARS ===');
  const results = [];
  for (const spec of AVATAR_SPECS) {
    const res = await generateEyelidBlendshape(spec);
    results.push(res);
  }

  // Also copy classic feathered eyelid if needed
  if (fs.existsSync('public/assets/images/avatar3d/eyes_closed_feathered.png')) {
    fs.mkdirSync('public/assets/images/avatars_modular/classic', { recursive: true });
    fs.copyFileSync(
      'public/assets/images/avatar3d/eyes_closed_feathered.png',
      'public/assets/images/avatars_modular/classic/eyes_closed.png'
    );
    console.log('Linked classic eyes_closed.png to modular directory');
  }

  console.log('RESULTS:', JSON.stringify(results, null, 2));
}

run();
