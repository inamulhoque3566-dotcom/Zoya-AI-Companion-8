const ort = require('onnxruntime-node');
const sharp = require('sharp');

async function testRmbgAv8() {
  const session = await ort.InferenceSession.create('./node_modules/@xenova/transformers/.cache/briaai/RMBG-1.4/onnx/model_quantized.onnx');
  const inputJpg = 'src/assets/images/avatar_8_cute_3d_1793676594165.jpg';
  const meta = await sharp(inputJpg).metadata();

  const resized = await sharp(inputJpg)
    .resize(1024, 1024, { fit: 'fill' })
    .removeAlpha()
    .raw()
    .toBuffer();

  const floatData = new Float32Array(3 * 1024 * 1024);
  const channelSize = 1024 * 1024;
  for (let i = 0; i < channelSize; i++) {
    floatData[i] = (resized[i * 3] / 255.0 - 0.5) / 0.5;
    floatData[channelSize + i] = (resized[i * 3 + 1] / 255.0 - 0.5) / 0.5;
    floatData[2 * channelSize + i] = (resized[i * 3 + 2] / 255.0 - 0.5) / 0.5;
  }

  const results = await session.run({ input: new ort.Tensor('float32', floatData, [1, 3, 1024, 1024]) });
  const maskData = results.output.data;

  const mask8 = new Uint8Array(1024 * 1024);
  for (let i = 0; i < 1024 * 1024; i++) {
    let val = maskData[i];
    if (val <= 0.4) mask8[i] = 0;
    else if (val >= 0.7) mask8[i] = 255;
    else mask8[i] = Math.round(((val - 0.4) / 0.3) * 255);
  }

  const { data: resizedMask, info: maskInfo } = await sharp(mask8, {
    raw: { width: 1024, height: 1024, channels: 1 }
  })
    .resize(meta.width, meta.height)
    .raw()
    .toBuffer({ resolveWithObject: true });

  const originalRgb = await sharp(inputJpg).removeAlpha().raw().toBuffer();
  const outRgba = new Uint8Array(meta.width * meta.height * 4);
  const totalPixels = meta.width * meta.height;
  for (let i = 0; i < totalPixels; i++) {
    outRgba[i * 4] = originalRgb[i * 3];
    outRgba[i * 4 + 1] = originalRgb[i * 3 + 1];
    outRgba[i * 4 + 2] = originalRgb[i * 3 + 2];
    outRgba[i * 4 + 3] = resizedMask[i * maskInfo.channels];
  }

  // Sole cutoff at y=1330
  for (let y = 1330; y < meta.height; y++) {
    for (let x = 0; x < meta.width; x++) {
      outRgba[(y * meta.width + x) * 4 + 3] = 0;
    }
  }

  await sharp(outRgba, {
    raw: { width: meta.width, height: meta.height, channels: 4 }
  })
    .png()
    .toFile('/app/applet/public/assets/images/test_rmbg_avatar8.png');

  console.log('Saved Avatar 8 to public/assets/images/test_rmbg_avatar8.png');
}

testRmbgAv8().catch(console.error);
