const fs = require('fs');
const path = require('path');
const sharp = require('sharp');

const AVATARS_CONFIG = [
  {
    id: 'casual_anime',
    src: 'public/assets/images/casual_anime_avatar_transparent.png',
    outDir: 'public/assets/images/avatars_modular/casual_anime',
    // 768x1376
    neckY: 340,
    waistY: 620,
    hipY: 750,
    kneeY: 1000,
    shoesY: 1200,
  },
  {
    id: 'elegant_anime',
    src: 'public/assets/images/elegant_anime_avatar_transparent.png',
    outDir: 'public/assets/images/avatars_modular/elegant_anime',
    neckY: 345,
    waistY: 630,
    hipY: 760,
    kneeY: 1020,
    shoesY: 1210,
  },
  {
    id: 'elegant_saree',
    src: 'public/assets/images/elegant_saree_avatar_transparent.png',
    outDir: 'public/assets/images/avatars_modular/elegant_saree',
    neckY: 330,
    waistY: 620,
    hipY: 750,
    kneeY: 1000,
    shoesY: 1210,
  },
        ];

async function generateLayers() {
  console.log('Generating modular avatar layers for all 7 alternate avatars...');

  for (const config of AVATARS_CONFIG) {
    if (!fs.existsSync(config.src)) {
      console.warn(`Source not found: ${config.src}`);
      continue;
    }

    fs.mkdirSync(config.outDir, { recursive: true });

    const img = sharp(config.src);
    const meta = await img.metadata();
    const W = meta.width;
    const H = meta.height;
    const { data } = await img.raw().toBuffer({ resolveWithObject: true });

    // Buffers for 4 layers:
    // 1. base_body (Skin, head, hair, arms, hands, legs, feet)
    // 2. outfit_top (Shirt / blouse / cami / jacket)
    // 3. outfit_bottom (Skirt / shorts / jeans / dress lower)
    // 4. outfit_shoes (Heels / sneakers / boots)
    const baseBodyBuf = Buffer.alloc(W * H * 4);
    const outfitTopBuf = Buffer.alloc(W * H * 4);
    const outfitBottomBuf = Buffer.alloc(W * H * 4);
    const outfitShoesBuf = Buffer.alloc(W * H * 4);

    // Copy raw data into baseBody first
    data.copy(baseBodyBuf);

    for (let y = 0; y < H; y++) {
      for (let x = 0; x < W; x++) {
        const idx = (y * W + x) * 4;
        const a = data[idx + 3];
        if (a === 0) continue;

        const r = data[idx];
        const g = data[idx + 1];
        const b = data[idx + 2];

        // Head, hair, face, neck: y < neckY
        // Keep 100% in base body. Do not touch.
        if (y < config.neckY) {
          continue;
        }

        // Shoes region: y >= shoesY
        if (y >= config.shoesY) {
          outfitShoesBuf[idx] = r;
          outfitShoesBuf[idx + 1] = g;
          outfitShoesBuf[idx + 2] = b;
          outfitShoesBuf[idx + 3] = a;
          continue;
        }

        // Top region: neckY <= y < waistY
        if (y >= config.neckY && y < config.waistY) {
          // Check if this is arms / hands on the outer flanks
          // Arms are typically at the far left or far right of the torso
          // Torso center is around W/2 = 384
          const distFromCenter = Math.abs(x - W / 2);
          const isOuterArm = distFromCenter > 170;

          if (isOuterArm) {
            // Keep arm in base body
            continue;
          }

          // Outfit top
          outfitTopBuf[idx] = r;
          outfitTopBuf[idx + 1] = g;
          outfitTopBuf[idx + 2] = b;
          outfitTopBuf[idx + 3] = a;
          continue;
        }

        // Bottom region: waistY <= y < shoesY
        if (y >= config.waistY && y < config.shoesY) {
          // Check if hands at sides: waist level to hip level, distFromCenter > 150
          if (y <= config.hipY + 50 && Math.abs(x - W / 2) > 155) {
            // Hands at hips/sides, keep in base body
            continue;
          }

          outfitBottomBuf[idx] = r;
          outfitBottomBuf[idx + 1] = g;
          outfitBottomBuf[idx + 2] = b;
          outfitBottomBuf[idx + 3] = a;
          continue;
        }
      }
    }

    // Save modular layers
    await sharp(baseBodyBuf, { raw: { width: W, height: H, channels: 4 } })
      .png({ compressionLevel: 9 })
      .toFile(path.join(config.outDir, 'body_skin.png'));

    await sharp(outfitTopBuf, { raw: { width: W, height: H, channels: 4 } })
      .png({ compressionLevel: 9 })
      .toFile(path.join(config.outDir, 'outfit_top.png'));

    await sharp(outfitBottomBuf, { raw: { width: W, height: H, channels: 4 } })
      .png({ compressionLevel: 9 })
      .toFile(path.join(config.outDir, 'outfit_bottom.png'));

    await sharp(outfitShoesBuf, { raw: { width: W, height: H, channels: 4 } })
      .png({ compressionLevel: 9 })
      .toFile(path.join(config.outDir, 'outfit_shoes.png'));

    console.log(`✓ Generated layers for ${config.id}`);
  }

  console.log('All modular avatar layers created successfully!');
}

generateLayers().catch(console.error);
