const sharp = require('sharp');

async function inspectMaidSkirt() {
  const { data, info } = await sharp('src/assets/images/zoya_3d_cyber_maid_1793631534918.jpg').raw().toBuffer({ resolveWithObject: true });
  const W = info.width;
  console.log('=== cyber_maid y=660..875, x=165..655 ===');
  for (let y = 660; y <= 875; y += 8) {
    let line = `${String(y).padStart(3)}: `;
    for (let x = 165; x <= 655; x += 7) {
      const idx = (y * W + x) * 3;
      const r = data[idx], g = data[idx + 1], b = data[idx + 2];
      // row bg from left margin
      const bgR = data[(y * W + 10) * 3];
      const bgG = data[(y * W + 10) * 3 + 1];
      const bgB = data[(y * W + 10) * 3 + 2];
      const dist = Math.sqrt((r - bgR)**2 + (g - bgG)**2 + (b - bgB)**2);
      const chroma = Math.max(Math.abs(r - g), Math.abs(r - b), Math.abs(g - b));
      if (Math.min(r, g, b) < 120) line += '#'; // black skirt / lace
      else if (b - r >= 6 || g - r >= 6) line += 'c'; // cyan trim
      else if (r - b >= 14) line += 'T'; // thigh skin
      else if (dist < 8 && chroma <= 3) line += '.'; // pure studio bg
      else if (dist < 18) line += ':'; // faint shadow / anti-alias
      else line += 'W'; // shaded white ruffle / ribbon
    }
    console.log(line);
  }
}

inspectMaidSkirt().catch(console.error);
