const sharp = require('sharp');
const fs = require('fs');

async function inspectEdgesB() {
  const src = await sharp('public/assets/aistudio/file_00000000c0d4821189e14bf178224f8d_f1687d5b.png')
    .raw()
    .toBuffer({ resolveWithObject: true });

  const w = src.info.width;
  const h = src.info.height;

  // Let's inspect borders of the saree and hair to see if any background remains
  // Check outer bounding box of visible avatar
  let minX = w, maxX = 0, minY = h, maxY = 0;
  let isolatedPixels = 0;

  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const a = src.data[(y * w + x) * 4 + 3];
      if (a > 10) {
        if (x < minX) minX = x;
        if (x > maxX) maxX = x;
        if (y < minY) minY = y;
        if (y > maxY) maxY = y;
      }
    }
  }
  console.log(`Avatar B bounding box: X=[${minX}..${maxX}], Y=[${minY}..${maxY}] in (${w}x${h})`);

  // Check very bottom rows (y > 1525)
  console.log('\nChecking bottom rows y=1526..1535:');
  for (let y = 1526; y < h; y++) {
    let rowCount = 0;
    let minRowX = w, maxRowX = 0;
    for (let x = 0; x < w; x++) {
      const idx = (y * w + x) * 4;
      const a = src.data[idx + 3];
      if (a > 10) {
        rowCount++;
        if (x < minRowX) minRowX = x;
        if (x > maxRowX) maxRowX = x;
      }
    }
    console.log(`y=${y}: count=${rowCount}, span=[${minRowX}..${maxRowX}]`);
  }
}

inspectEdgesB().catch(console.error);
