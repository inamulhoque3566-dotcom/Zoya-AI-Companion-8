import path from 'path';
import { mcpClientManager } from '../src/services/agent/mcpClient.ts';

async function main() {
  console.log('========================================================================');
  console.log('🌐 CONNECTING REAL THIRD-PARTY MCP SERVER: @modelcontextprotocol/server-filesystem');
  console.log('========================================================================\n');

  const workspaceRoot = path.join(process.cwd(), 'workspace');
  const serverPath = path.join(process.cwd(), 'node_modules', '@modelcontextprotocol', 'server-filesystem', 'dist', 'index.js');

  // 1. Add server configuration limited to /app/applet/workspace
  console.log('1. Registering server config (stdio: node server-filesystem)...');
  const server = mcpClientManager.addServer({
    name: 'mcp-official-filesystem',
    transport: 'stdio',
    command: process.execPath, // /usr/local/bin/node
    args: [serverPath, workspaceRoot],
    cwd: workspaceRoot,
    allowNetwork: false, // Network isolation active via unshare -n
  }, { userApproved: true });

  console.log(`Registered server ID: ${server.id}`);

  // 2. Connect & Handshake
  console.log('\n2. Connecting and performing initialize handshake...');
  const tools = await mcpClientManager.connectServer(server.id, { userApproved: true });
  console.log(`Handshake completed! Server status: ${mcpClientManager.getServer(server.id)?.status}`);

  // 3. Show tools/list
  console.log('\n3. Real tools/list result from @modelcontextprotocol/server-filesystem:');
  console.log(JSON.stringify(tools, null, 2));

  // 4. One approved call: list_directory inside workspace
  console.log('\n4. Executing approved tool call: list_directory on workspace directory...');
  const approvedCall = await mcpClientManager.callTool(server.id, 'list_directory', {
    path: workspaceRoot,
  }, { approvalGranted: true });
  console.log('Approved Call Result:');
  console.log(approvedCall.output);

  // 5. Attempt to read outside workspace (/etc/passwd)
  console.log('\n5. Testing path boundary: attempting to read /etc/passwd outside allowed directory...');
  const outsideCall = await mcpClientManager.callTool(server.id, 'read_file', {
    path: '/etc/passwd',
  }, { approvalGranted: true });
  console.log('Outside Workspace Read Result:');
  console.log(outsideCall.output);

  // 6. Cleanup
  console.log('\n6. Disconnecting and removing third-party server...');
  await mcpClientManager.removeServer(server.id);
  console.log('Server removed successfully.\n');
}

main().catch((err) => {
  console.error('Real MCP server test failed:', err);
  process.exit(1);
});
