import { chromium } from 'playwright';
import fs from 'fs';
import path from 'path';

async function captureScreenshots() {
  console.log('Launching headless browser to capture real app screenshots...');
  const browser = await chromium.launch({ headless: true });
  const context = await browser.newContext({
    viewport: { width: 412, height: 915 }, // standard mobile viewport
    deviceScaleFactor: 2,
  });

  const page = await context.newPage();

  // 1. Capture Avatar A on Home Screen
  console.log('Navigating to app with Avatar A active...');
  await page.addInitScript(() => {
    localStorage.setItem('zoya_avatar_selected_3d_id', 'avatar_pastel_blue_knit_shorts');
    localStorage.setItem('zoya_use_3d_avatar', 'true');
  });

  await page.goto('http://localhost:3000', { waitUntil: 'networkidle' });
  await page.waitForTimeout(2500);

  fs.mkdirSync('proof_artifacts', { recursive: true });
  await page.screenshot({ path: 'proof_artifacts/real_homescreen_avatar_a_cozy_pastel.png' });
  console.log('✓ Captured proof_artifacts/real_homescreen_avatar_a_cozy_pastel.png');

  // 2. Open Settings -> Avatar tab to capture Avatar A Card
  console.log('Opening Avatar Settings to capture Settings card for Avatar A...');
  const settingsBtn = page.locator('button:has(svg.lucide-settings), button[aria-label*="settings" i], button[title*="settings" i]').first();
  if (await settingsBtn.isVisible()) {
    await settingsBtn.click();
  } else {
    // Click through evaluate
    await page.evaluate(() => {
      const btns = Array.from(document.querySelectorAll('button'));
      const s = btns.find(b => b.innerHTML.includes('lucide-settings') || b.textContent?.includes('Settings'));
      s?.click();
    });
  }
  await page.waitForTimeout(1000);

  // Click Avatar section tab
  await page.evaluate(() => {
    const tabs = Array.from(document.querySelectorAll('button, div'));
    const avTab = tabs.find(t => t.textContent?.trim() === '3D Avatars' || t.textContent?.trim() === 'Avatars' || t.textContent?.includes('अवतार'));
    (avTab as HTMLElement)?.click();
  });
  await page.waitForTimeout(1200);

  await page.screenshot({ path: 'proof_artifacts/real_settings_card_avatar_a_cozy_pastel.png' });
  console.log('✓ Captured proof_artifacts/real_settings_card_avatar_a_cozy_pastel.png');

  // 3. Switch to Avatar B: Midnight Gold Zari Saree
  console.log('Switching to Avatar B (Midnight Saree)...');
  await page.evaluate(() => {
    localStorage.setItem('zoya_avatar_selected_3d_id', 'avatar_midnight_gold_zari_saree');
    localStorage.setItem('zoya_use_3d_avatar', 'true');
  });

  await page.goto('http://localhost:3000', { waitUntil: 'networkidle' });
  await page.waitForTimeout(2500);

  await page.screenshot({ path: 'proof_artifacts/real_homescreen_avatar_b_midnight_saree.png' });
  console.log('✓ Captured proof_artifacts/real_homescreen_avatar_b_midnight_saree.png');

  // 4. Open Settings to capture Settings card for Avatar B
  const settingsBtnB = page.locator('button:has(svg.lucide-settings), button[aria-label*="settings" i], button[title*="settings" i]').first();
  if (await settingsBtnB.isVisible()) {
    await settingsBtnB.click();
  } else {
    await page.evaluate(() => {
      const btns = Array.from(document.querySelectorAll('button'));
      const s = btns.find(b => b.innerHTML.includes('lucide-settings') || b.textContent?.includes('Settings'));
      s?.click();
    });
  }
  await page.waitForTimeout(1000);

  await page.evaluate(() => {
    const tabs = Array.from(document.querySelectorAll('button, div'));
    const avTab = tabs.find(t => t.textContent?.trim() === '3D Avatars' || t.textContent?.trim() === 'Avatars' || t.textContent?.includes('अवतार'));
    (avTab as HTMLElement)?.click();
  });
  await page.waitForTimeout(1200);

  await page.screenshot({ path: 'proof_artifacts/real_settings_card_avatar_b_midnight_saree.png' });
  console.log('✓ Captured proof_artifacts/real_settings_card_avatar_b_midnight_saree.png');

  await browser.close();
  console.log('=== REAL SCREENSHOT VERIFICATION COMPLETE ===');
}

captureScreenshots().catch(console.error);
