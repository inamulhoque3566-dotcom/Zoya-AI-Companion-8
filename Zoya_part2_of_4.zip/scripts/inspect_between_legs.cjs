const sharp = require('sharp');
const path = require('path');

async function inspectBetweenLegs() {
  const src = path.join(__dirname, '../src/assets/images/zoya_3d_sweater_glasses_1793764031303.jpg');
  const { data, info } = await sharp(src).removeAlpha().raw().toBuffer({ resolveWithObject: true });
  const W = info.width, H = info.height;

  for (let y = 1180; y <= 1340; y += 20) {
    let lShoeEnd = 0, rShoeStart = 0;
    // scan row
    console.log(`y=${y}:`);
    for (let x = 320; x <= 460; x += 10) {
      const idx = (y * W + x) * 3;
      const r = data[idx], g = data[idx+1], b = data[idx+2];
      const chroma = Math.max(Math.abs(r-g), Math.abs(r-b), Math.abs(g-b));
      const dist = Math.sqrt((r-210)**2 + (g-210)**2 + (b-212)**2);
      process.stdout.write(` [x=${x}: ${r},${g},${b} ch=${chroma}]`);
    }
    console.log();
  }
}
inspectBetweenLegs().catch(console.error);
