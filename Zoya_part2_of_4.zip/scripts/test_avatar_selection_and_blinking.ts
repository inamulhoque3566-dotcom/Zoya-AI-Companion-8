/**
 * test_avatar_selection_and_blinking.ts
 * Rigorous test suite for Permanent Avatar Selection and Natural Eye Blinking for All Avatars
 */
import fs from 'fs';
import path from 'path';
import {
  ANIME_3D_AVATARS,
  getSaved3DAvatarId,
  save3DAvatarId,
  getIs3DAvatarEnabled,
  saveIs3DAvatarEnabled,
  STORAGE_KEY_SELECTED_3D_AVATAR,
  STORAGE_KEY_PERMANENT_AVATAR,
} from '../src/data/anime3DAvatars';
import { ALL_AVATARS_ANATOMY, getAvatarAnatomy } from '../src/data/avatarAnatomy';

console.log('================================================================');
console.log('🧪 AVATAR SELECTION PERSISTENCE & NATURAL BLINKING TEST SUITE');
console.log('================================================================');

// -----------------------------------------------------------------------------
// Mock browser localStorage for Node test runner
// -----------------------------------------------------------------------------
const mockStore: Record<string, string> = {};
(global as any).localStorage = {
  getItem: (key: string) => mockStore[key] ?? null,
  setItem: (key: string, val: string) => { mockStore[key] = String(val); },
  removeItem: (key: string) => { delete mockStore[key]; },
  clear: () => {
    for (const k of Object.keys(mockStore)) delete mockStore[k];
  },
};
(global as any).window = {
  localStorage: (global as any).localStorage,
  dispatchEvent: (e: any) => {},
};

// -----------------------------------------------------------------------------
// TEST 1: Permanent Avatar Selection
// -----------------------------------------------------------------------------
console.log('\n--- TEST GROUP 1: Permanent Avatar Selection & Resilience ---');

// 1.1 Fresh launch defaults to first avatar
(global as any).localStorage.clear();
const defaultAvatar = getSaved3DAvatarId();
if (defaultAvatar !== ANIME_3D_AVATARS[0].id) {
  console.error(`❌ Expected default avatar "${ANIME_3D_AVATARS[0].id}", got "${defaultAvatar}"`);
  process.exit(1);
}
console.log(`✅ First launch default avatar correctly initialized to "${defaultAvatar}".`);

// 1.2 User selects a specific avatar (e.g. pink_knit_maxi)
const chosenAvatarId = 'pink_knit_maxi';
save3DAvatarId(chosenAvatarId);
if (mockStore[STORAGE_KEY_PERMANENT_AVATAR] !== chosenAvatarId) {
  console.error(`❌ Primary storage key not updated. Expected "${chosenAvatarId}", got "${mockStore[STORAGE_KEY_PERMANENT_AVATAR]}"`);
  process.exit(1);
}
if (mockStore[STORAGE_KEY_SELECTED_3D_AVATAR] !== chosenAvatarId) {
  console.error(`❌ Legacy storage key not synced. Expected "${chosenAvatarId}", got "${mockStore[STORAGE_KEY_SELECTED_3D_AVATAR]}"`);
  process.exit(1);
}
console.log(`✅ Selected avatar "${chosenAvatarId}" persisted to both permanent and legacy storage.`);

// 1.3 Reopen app / simulate 1-2 hours pass (new session, memory wiped, read from storage)
const restoredAvatar = getSaved3DAvatarId();
if (restoredAvatar !== chosenAvatarId) {
  console.error(`❌ Reopened app expected "${chosenAvatarId}", got "${restoredAvatar}"`);
  process.exit(1);
}
console.log(`✅ Reopened app restores exact previously selected avatar "${restoredAvatar}".`);

// 1.4 Switch to another avatar (e.g. peasant_blouse_skirt)
const secondChoice = 'peasant_blouse_skirt';
save3DAvatarId(secondChoice);
if (getSaved3DAvatarId() !== secondChoice) {
  console.error(`❌ Failed to switch to "${secondChoice}"`);
  process.exit(1);
}
console.log(`✅ User manually switched avatar to "${secondChoice}". Active avatar is now "${secondChoice}".`);

// 1.5 Switch to a Classic avatar style (e.g. classic)
const classicChoice = 'classic';
save3DAvatarId(classicChoice);
if (getSaved3DAvatarId() !== classicChoice) {
  console.error(`❌ Failed to switch to classic avatar "${classicChoice}"`);
  process.exit(1);
}
if (mockStore['zoya_saved_avatar_style_v1'] !== classicChoice) {
  console.error(`❌ Legacy classic style key not updated for "${classicChoice}"`);
  process.exit(1);
}
console.log(`✅ Classic avatar "${classicChoice}" correctly selected and synced with avatarStyle.`);

// 1.6 Guard against invalid/corrupted avatar IDs
save3DAvatarId('non_existent_random_alien_avatar');
if (getSaved3DAvatarId() !== classicChoice) {
  console.error(`❌ Invalid avatar ID overwrote the user selection!`);
  process.exit(1);
}
console.log(`✅ Invalid/malformed avatar ID was safely rejected; user selection "${classicChoice}" remains active.`);

// 1.7 Memory background snapshot must NEVER overwrite active avatar selection
mockStore['zoya_use_3d_memory_bg_v3'] = 'true';
// Simulate user changing avatar while memory was toggled
save3DAvatarId('pink_knit_maxi');
// Simulate memory background toggled OFF
mockStore['zoya_use_3d_memory_bg_v3'] = 'false';
if (getSaved3DAvatarId() !== 'pink_knit_maxi') {
  console.error(`❌ Avatar was incorrectly reverted after memory background toggle! Expected "pink_knit_maxi", got "${getSaved3DAvatarId()}"`);
  process.exit(1);
}
console.log(`✅ 3D Memory background toggle does not alter or reset selected avatar ("${getSaved3DAvatarId()}").`);

// -----------------------------------------------------------------------------
// TEST 2: Natural Eye Blinking For ALL Avatars
// -----------------------------------------------------------------------------
console.log('\n--- TEST GROUP 2: Natural Eye Blinking For ALL Avatars ---');

let verifiedAvatarsCount = 0;

for (const avatar of ANIME_3D_AVATARS) {
  const anatomy = getAvatarAnatomy(avatar.id);
  if (!anatomy) {
    console.error(`❌ Missing anatomy configuration for avatar: ${avatar.id}`);
    process.exit(1);
  }

  // 2.1 Verify eye landmarks exist
  if (!anatomy.eyeLandmarks) {
    console.error(`❌ Missing eyeLandmarks for avatar: ${avatar.id}`);
    process.exit(1);
  }

  const { cropW, cropH, eyeCenterX, eyeCenterY } = anatomy.eyeLandmarks;
  const { widthPx, heightPx } = anatomy;

  if (cropW <= 0 || cropH <= 0 || eyeCenterX <= 0 || eyeCenterY <= 0) {
    console.error(`❌ Invalid eyeLandmarks values for avatar: ${avatar.id}`, anatomy.eyeLandmarks);
    process.exit(1);
  }

  // 2.2 Verify mathematical coordinates are within natural facial boundary
  const leftPct = ((eyeCenterX - cropW / 2) / widthPx) * 100;
  const topPct = ((eyeCenterY - cropH / 2) / heightPx) * 100;
  const widthPct = (cropW / widthPx) * 100;
  const heightPct = (cropH / heightPx) * 100;

  // Eyes must be in upper half of face and horizontally centered
  if (leftPct < 20 || leftPct > 55 || topPct < 5 || topPct > 30) {
    console.error(`❌ Eyelid coordinates out of expected facial bounds for ${avatar.id}: left=${leftPct}%, top=${topPct}%`);
    process.exit(1);
  }

  // 2.3 Verify eyes_closed.png asset exists on disk in public folder
  const eyelidAssetPath = path.join(process.cwd(), 'public', anatomy.modularPath.replace(/^\//, ''), 'eyes_closed.png');
  if (!fs.existsSync(eyelidAssetPath)) {
    console.error(`❌ Missing eyelid asset on disk: ${eyelidAssetPath}`);
    process.exit(1);
  }

  const stat = fs.statSync(eyelidAssetPath);
  if (stat.size < 500) {
    console.error(`❌ Eyelid asset seems corrupted or too small (${stat.size} bytes): ${eyelidAssetPath}`);
    process.exit(1);
  }

  verifiedAvatarsCount++;
  console.log(`✅ [${avatar.id}] Verified eyelid crop (${cropW}x${cropH} at (${eyeCenterX},${eyeCenterY})) -> Asset: ${anatomy.modularPath}/eyes_closed.png (${stat.size} bytes)`);
}

console.log(`\n✅ All ${verifiedAvatarsCount} avatars have verified biological eye landmarks and verified eyelid textures.`);

// -----------------------------------------------------------------------------
// TEST 3: Biological Blink Timing & Motion Simulation
// -----------------------------------------------------------------------------
console.log('\n--- TEST GROUP 3: Biological Timing & Motion Simulation ---');

function simulateBlinkCycle(totalSeconds: number) {
  let isClosing = false;
  let isApex = false;
  let isOpening = false;
  let maxOpacitySeen = 0;
  let minOpacitySeen = 1;
  let blinkCount = 0;

  let state: 'open' | 'closing' | 'closed' | 'opening' = 'open';
  let timer = 0;
  let nextInterval = 2.5;

  const dt = 0.016; // ~60fps
  for (let t = 0; t < totalSeconds; t += dt) {
    let opacity = 0;
    if (state === 'open') {
      opacity = 0;
      timer += dt;
      if (timer >= nextInterval) {
        state = 'closing';
        timer = 0;
        blinkCount++;
      }
    } else {
      timer += dt;
      if (state === 'closing') {
        isClosing = true;
        const p = Math.min(1.0, timer / 0.065);
        opacity = Math.sin((p * Math.PI) / 2);
        if (timer >= 0.065) {
          state = 'closed';
          timer = 0;
          opacity = 1.0;
        }
      } else if (state === 'closed') {
        isApex = true;
        opacity = 1.0;
        if (timer >= 0.025) {
          state = 'opening';
          timer = 0;
        }
      } else if (state === 'opening') {
        isOpening = true;
        const p = Math.min(1.0, timer / 0.115);
        opacity = Math.max(0.0, 1.0 - Math.sin((p * Math.PI) / 2));
        if (timer >= 0.115) {
          state = 'open';
          timer = 0;
          opacity = 0;
          nextInterval = 2.5;
        }
      }
    }
    maxOpacitySeen = Math.max(maxOpacitySeen, opacity);
    minOpacitySeen = Math.min(minOpacitySeen, opacity);
  }

  return { isClosing, isApex, isOpening, maxOpacitySeen, minOpacitySeen, blinkCount };
}

const sim = simulateBlinkCycle(10);
if (!sim.isClosing || !sim.isApex || !sim.isOpening) {
  console.error('❌ Blink state machine failed to transition through natural close -> apex -> open phases!');
  process.exit(1);
}
if (sim.maxOpacitySeen < 0.99) {
  console.error(`❌ Blink failed to reach full apex opacity (max: ${sim.maxOpacitySeen})`);
  process.exit(1);
}
if (sim.minOpacitySeen > 0.01) {
  console.error(`❌ Eyes did not reopen fully to 0 opacity (min: ${sim.minOpacitySeen})`);
  process.exit(1);
}
if (sim.blinkCount < 2 || sim.blinkCount > 5) {
  console.error(`❌ Unnatural blink frequency in 10s window: ${sim.blinkCount} blinks`);
  process.exit(1);
}
console.log(`✅ Simulated 10s biological blink loop: ${sim.blinkCount} natural blinks, full apex closure (1.0), and 100% clean reopening (0.0).`);

console.log('\n================================================================');
console.log('🎉 ALL PERMANENT AVATAR SELECTION & NATURAL BLINKING TESTS PASSED!');
console.log('================================================================');
