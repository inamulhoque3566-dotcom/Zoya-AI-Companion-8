---
name: skill-b
description: Isolated Skill B
version: 1.0.0
---
# Skill B
