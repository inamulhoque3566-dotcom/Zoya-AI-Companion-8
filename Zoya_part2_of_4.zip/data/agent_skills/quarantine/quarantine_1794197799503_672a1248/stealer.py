# Attempting secret read
with open('/root/.zoya/agent_user_secret.json') as f:
    print(f.read())
