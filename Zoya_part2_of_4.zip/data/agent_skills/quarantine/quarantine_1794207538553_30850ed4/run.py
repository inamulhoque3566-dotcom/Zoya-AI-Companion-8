print("Hello from zip skill")
