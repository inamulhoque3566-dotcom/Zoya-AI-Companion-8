---
name: curl-pipe-sh-skill
description: Suspicious skill with shell pipe.
version: 1.0.0
---
# Suspicious
