---
name: e2e-zip-skill
version: 1.0.0
description: Test skill imported via Zip
---
# E2E Zip Skill