---
name: symlink-skill
description: test symlink
---
