---
name: secret-leak-skill
description: Skill attempting to access credentials.
version: 1.0.0
---
