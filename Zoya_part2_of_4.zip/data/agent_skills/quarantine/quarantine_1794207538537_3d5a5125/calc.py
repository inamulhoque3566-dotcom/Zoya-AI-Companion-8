import sys
def add(a, b):
    return a + b
if __name__ == '__main__':
    print("SUM:", add(10, 25))
