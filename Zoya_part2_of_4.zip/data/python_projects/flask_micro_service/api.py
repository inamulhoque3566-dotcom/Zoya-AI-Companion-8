# Micro REST API Backend in Zoya Python Studio
from flask import Flask, jsonify, request
import json
import sqlite3

app = Flask(__name__)

# Initialize in-memory SQLite database
def get_db():
    conn = sqlite3.connect(":memory:")
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE products (
            id INTEGER PRIMARY KEY,
            name TEXT NOT NULL,
            category TEXT NOT NULL,
            price REAL NOT NULL
        )
    """)
    sample_data = [
        (1, "Zoya Hologram Ring v2", "Hardware", 49.99),
        (2, "Neural Speech Synthesizer", "AI Software", 129.00),
        (3, "Android Accessibility Kit", "Tooling", 79.50),
        (4, "Python Execution Engine Pro", "Developer Tools", 199.00)
    ]
    cursor.executemany("INSERT INTO products VALUES (?,?,?,?)", sample_data)
    conn.commit()
    return conn

@app.route("/api/health", methods=["GET"])
def health():
    return jsonify({
        "status": "healthy",
        "service": "Zoya Python API Engine",
        "version": "1.0.0",
        "engine": "Python 3.10 Flask"
    })

@app.route("/api/products", methods=["GET"])
def list_products():
    conn = get_db()
    rows = conn.cursor().execute("SELECT * FROM products").fetchall()
    return jsonify([dict(r) for r in rows])

print("== Testing Flask API Endpoint Execution ==")
# Test routing internally
with app.test_client() as client:
    health_res = client.get("/api/health")
    print(f"GET /api/health -> Status: {health_res.status_code}")
    print(f"Response: {health_res.get_json()}\n")

    products_res = client.get("/api/products")
    print(f"GET /api/products -> Status: {products_res.status_code}")
    print(f"Items: {len(products_res.get_json())} records returned:")
    for p in products_res.get_json():
        print(f"  • #{p['id']} {p['name']} (${p['price']:.2f}) [{p['category']}]")

print("\n✓ Flask API tested successfully.")
