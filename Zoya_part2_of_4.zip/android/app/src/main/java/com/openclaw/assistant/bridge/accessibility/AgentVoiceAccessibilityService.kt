package com.openclaw.assistant.bridge.accessibility

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.openclaw.assistant.bridge.WakeLockManager
import java.security.MessageDigest

/**
 * ============================================================================
 * ZOYA AI ACCESSIBILITY & DEVICE CONTROL SERVICE
 * ============================================================================
 *
 * Provides full, reliable device control for Zoya AI Assistant:
 * - Read visible screen nodes and text hierarchies
 * - Tap, double tap, long press coordinates
 * - Swipe and smooth multi-directional scrolling (up, down, left, right)
 * - Click buttons, links, and text elements with parent resolution
 * - Type text into input fields using ACTION_SET_TEXT
 * - Global system navigation (Back, Home, Recents, Notifications, Quick Settings, Lock)
 * - Launch applications by package or natural query (English & Hindi)
 *
 * STRICT BANKING & PRIVACY RESTRICTION:
 * - Blocked packages (UPI, Google Pay, PhonePe, Paytm, Banks) are strictly protected.
 * - When in foreground, no events are processed, no nodes are read, no gestures are dispatched.
 * - Shows "Blocked for your safety" message.
 * - Passwords, PINs, OTPs, and CVVs are never read, typed into, or logged.
 * - Safe node recycling in try...finally prevents memory leaks and crashes.
 */
class AgentVoiceAccessibilityService : AccessibilityService() {

    private var currentForegroundPackage: String? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Log.i(TAG, "Zoya Accessibility Service Connected & Bound successfully")

        // Ensure all required flags and capabilities are active dynamically
        try {
            val info = serviceInfo ?: AccessibilityServiceInfo()
            info.eventTypes = AccessibilityEvent.TYPES_ALL_MASK
            info.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            info.flags = AccessibilityServiceInfo.FLAG_DEFAULT or
                    AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS or
                    AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS or
                    AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS
            info.notificationTimeout = 100
            serviceInfo = info
            Log.i(TAG, "Zoya Accessibility ServiceInfo flags configured: flagRetrieveInteractiveWindows, flagReportViewIds")
        } catch (e: Exception) {
            Log.w(TAG, "Failed to apply dynamic AccessibilityServiceInfo: ${e.message}")
        }
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        Log.i(TAG, "Zoya Accessibility Service Unbound")
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        Log.i(TAG, "Zoya Accessibility Service Destroyed")
        super.onDestroy()
    }

    override fun onInterrupt() {
        Log.w(TAG, "Zoya Accessibility Service Interrupted by system")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return

        try {
            val pkg = event.packageName?.toString() ?: return

            // 1. Update active foreground package
            if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
                currentForegroundPackage = pkg
            }

            // 2. BANKING SAFETY GUARD: Immediately drop events from protected apps
            if (BankingSafetyConfig.isPackageBlocked(pkg)) {
                // Drop silently to protect user privacy
                return
            }

            // 3. Drop bank OTP / SMS notification events
            if (event.eventType == AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED) {
                val text = event.text.joinToString(" ")
                if (BankingSafetyConfig.isOtpOrSmsContent(text)) {
                    // Drop banking OTP / transaction notifications
                    return
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error in onAccessibilityEvent: ${e.message}")
        }
    }

    /**
     * Helper to verify if the currently active window belongs to a blocked banking/UPI app.
     */
    private fun isCurrentAppBlocked(): Boolean {
        val root = runCatching { rootInActiveWindow }.getOrNull()
        val activePkg = try {
            root?.packageName?.toString() ?: currentForegroundPackage
        } finally {
            runCatching { root?.recycle() }
        }

        if (BankingSafetyConfig.isPackageBlocked(activePkg)) {
            BankingSafetyConfig.notifySafetyBlocked(this)
            return true
        }
        return false
    }

    // =========================================================================
    // SYSTEM NAVIGATION & GLOBAL ACTIONS
    // =========================================================================
    fun performGlobalActionNamed(action: String): Boolean {
        return when (action.trim().lowercase()) {
            "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
            "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
            "recents", "recent_apps", "overview" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
            "notifications", "notification_shade" -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
            "quick_settings" -> performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
            "power_dialog" -> performGlobalAction(GLOBAL_ACTION_POWER_DIALOG)
            "lock", "lock_screen", "lock_device" -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
                } else false
            }
            "screenshot", "take_screenshot" -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
                } else false
            }
            "dismiss_notification_shade" -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    performGlobalAction(GLOBAL_ACTION_DISMISS_NOTIFICATION_SHADE)
                } else performGlobalAction(GLOBAL_ACTION_BACK)
            }
            else -> false
        }
    }

    // =========================================================================
    // TAP, SWIPE, LONG PRESS & GESTURES (WITH BANKING SAFETY CHECK)
    // =========================================================================
    fun performTap(x: Float, y: Float): Boolean {
        if (isCurrentAppBlocked()) {
            Log.w(TAG, "performTap blocked: active app is protected banking/UPI")
            return false
        }
        return WakeLockManager.withWakeLock {
            val path = Path().apply {
                moveTo(x, y)
                lineTo(x + 1f, y + 1f)
            }
            val stroke = GestureDescription.StrokeDescription(path, 0L, 50L)
            val gesture = GestureDescription.Builder().addStroke(stroke).build()
            dispatchGestureWithCallback(gesture)
        }
    }

    fun performLongPress(x: Float, y: Float, durationMs: Long = 500L): Boolean {
        if (isCurrentAppBlocked()) {
            Log.w(TAG, "performLongPress blocked: active app is protected banking/UPI")
            return false
        }
        return WakeLockManager.withWakeLock {
            val path = Path().apply {
                moveTo(x, y)
                lineTo(x + 1f, y + 1f)
            }
            val stroke = GestureDescription.StrokeDescription(path, 0L, durationMs.coerceAtLeast(400L))
            val gesture = GestureDescription.Builder().addStroke(stroke).build()
            dispatchGestureWithCallback(gesture)
        }
    }

    fun performSwipe(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long = 300L): Boolean {
        if (isCurrentAppBlocked()) {
            Log.w(TAG, "performSwipe blocked: active app is protected banking/UPI")
            return false
        }
        return WakeLockManager.withWakeLock {
            val path = Path().apply {
                moveTo(x1, y1)
                lineTo(x2, y2)
            }
            val stroke = GestureDescription.StrokeDescription(path, 0L, durationMs.coerceAtLeast(50L))
            val gesture = GestureDescription.Builder().addStroke(stroke).build()
            dispatchGestureWithCallback(gesture)
        }
    }

    private fun dispatchGestureWithCallback(gesture: GestureDescription): Boolean {
        val dispatched = dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                Log.d(TAG, "Gesture completed")
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                Log.w(TAG, "Gesture cancelled")
            }
        }, null)
        return dispatched
    }

    // =========================================================================
    // SCROLLING (UP, DOWN, LEFT, RIGHT, FORWARD, BACKWARD)
    // =========================================================================
    fun performScroll(direction: String): Boolean {
        if (isCurrentAppBlocked()) {
            Log.w(TAG, "performScroll blocked: active app is protected banking/UPI")
            return false
        }

        val displayMetrics = resources.displayMetrics
        val centerX = displayMetrics.widthPixels / 2f
        val centerY = displayMetrics.heightPixels / 2f
        val width = displayMetrics.widthPixels.toFloat()
        val height = displayMetrics.heightPixels.toFloat()

        return when (direction.trim().lowercase()) {
            "down", "forward" -> {
                // Swipe from 75% down to 25% up
                performSwipe(centerX, height * 0.75f, centerX, height * 0.25f, 350L)
            }
            "up", "backward" -> {
                // Swipe from 25% up down to 75% down
                performSwipe(centerX, height * 0.25f, centerX, height * 0.75f, 350L)
            }
            "left" -> {
                // Swipe from right to left
                performSwipe(width * 0.85f, centerY, width * 0.15f, centerY, 350L)
            }
            "right" -> {
                // Swipe from left to right
                performSwipe(width * 0.15f, centerY, width * 0.85f, centerY, 350L)
            }
            else -> false
        }
    }

    // =========================================================================
    // CLICK BY TEXT OR ELEMENT (WITH SAFE NODE RECYCLING)
    // =========================================================================
    fun clickText(targetText: String, exact: Boolean = false): Boolean {
        if (isCurrentAppBlocked()) {
            Log.w(TAG, "clickText blocked: active app is protected banking/UPI")
            return false
        }

        val root = rootInActiveWindow ?: return false
        val needle = targetText.trim().lowercase()
        var result = false
        val found = root.findAccessibilityNodeInfosByText(needle)

        try {
            for (node in found) {
                if (node == null) continue
                val txt = (node.text ?: node.contentDescription ?: "").toString().trim().lowercase()
                val match = if (exact) txt == needle else txt.contains(needle)
                if (match) {
                    var target: AccessibilityNodeInfo? = node
                    val ancestors = mutableListOf<AccessibilityNodeInfo>()
                    while (target != null && !target.isClickable) {
                        val parent = target.parent
                        if (parent != null) ancestors.add(parent)
                        target = parent
                    }

                    if (target != null && target.isClickable) {
                        val clicked = target.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                        ancestors.forEach { runCatching { it.recycle() } }
                        if (clicked) {
                            result = true
                            return true
                        }
                    }
                    ancestors.forEach { runCatching { it.recycle() } }

                    // Fallback to tap at coordinates of node
                    val rect = Rect()
                    node.getBoundsInScreen(rect)
                    if (rect.width() > 0 && rect.height() > 0) {
                        result = performTap(rect.centerX().toFloat(), rect.centerY().toFloat())
                        if (result) return true
                    }
                }
            }
        } finally {
            found.forEach { runCatching { it?.recycle() } }
            runCatching { root.recycle() }
        }
        return result
    }

    // =========================================================================
    // TYPE TEXT INTO EDITABLE FIELD (STRICT PASSWORD/PIN PROTECTION & NODE RECYCLING)
    // =========================================================================
    fun typeText(textToType: String): Boolean {
        if (isCurrentAppBlocked()) {
            Log.w(TAG, "typeText blocked: active app is protected banking/UPI")
            return false
        }

        val root = rootInActiveWindow ?: return false
        try {
            val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
                ?: findFirstEditable(root)
                ?: return false

            try {
                // STRICT SECURITY: Never type into password, PIN, CVV, or OTP fields
                if (BankingSafetyConfig.isSensitiveField(focused)) {
                    Log.w(TAG, "Security Guard: Blocked typing into sensitive password/PIN/OTP field")
                    return false
                }

                val arguments = Bundle().apply {
                    putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, textToType)
                }
                return focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments)
            } finally {
                runCatching { focused.recycle() }
            }
        } finally {
            runCatching { root.recycle() }
        }
    }

    private fun findFirstEditable(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (node == null) return null
        if (node.isEditable && !BankingSafetyConfig.isSensitiveField(node)) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = findFirstEditable(child)
            if (found != null) return found
            runCatching { child.recycle() }
        }
        return null
    }

    // =========================================================================
    // OPEN & LAUNCH INSTALLED APPLICATIONS (COMPREHENSIVE INTENT MATCH & HINDI ALIASES)
    // =========================================================================
    fun launchApplication(targetNameOrPkg: String): Boolean {
        val pm = packageManager
        val query = targetNameOrPkg.trim().lowercase()

        // 1. Direct package match
        try {
            val intent = pm.getLaunchIntentForPackage(query)
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(intent)
                return true
            }
        } catch (_: Exception) {}

        // 2. Query Launcher Activities (Android 11+ compatible)
        try {
            val launcherIntent = Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_LAUNCHER)
            }
            val resolveInfos = pm.queryIntentActivities(launcherIntent, 0)
            for (ri in resolveInfos) {
                val label = ri.loadLabel(pm).toString().lowercase()
                if (label == query || label.contains(query)) {
                    val intent = pm.getLaunchIntentForPackage(ri.activityInfo.packageName)
                    if (intent != null) {
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        startActivity(intent)
                        return true
                    }
                }
            }
        } catch (_: Exception) {}

        // 3. Search installed applications by display label fallback
        try {
            val apps = pm.getInstalledApplications(android.content.pm.PackageManager.GET_META_DATA)
            for (app in apps) {
                val label = pm.getApplicationLabel(app).toString().lowercase()
                if (label == query || label.contains(query)) {
                    val intent = pm.getLaunchIntentForPackage(app.packageName)
                    if (intent != null) {
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        startActivity(intent)
                        return true
                    }
                }
            }
        } catch (_: Exception) {}

        // 4. Common English and Hindi application aliases
        val commonPackage = when (query) {
            "settings", "setting", "सेटिंग्स", "सेटिंग" -> "com.android.settings"
            "camera", "कैमरा", "कैमरा चालू करो" -> "com.android.camera"
            "calculator", "कैलकुलेटर" -> "com.android.calculator2"
            "chrome", "browser", "क्रोम", "ब्राउज़र" -> "com.android.chrome"
            "youtube", "यूट्यूब" -> "com.google.android.youtube"
            "maps", "मैप्स", "नक्शा" -> "com.google.android.apps.maps"
            "whatsapp", "व्हाट्सएप", "वॉट्सएप" -> "com.whatsapp"
            "gmail", "email", "जीमेल", "ईमेल" -> "com.google.android.gm"
            "play store", "playstore", "प्ले स्टोर" -> "com.android.vending"
            "messages", "sms", "संदेश", "मैसेज" -> "com.google.android.apps.messaging"
            "contacts", "कॉन्टैक्ट्स", "संपर्क" -> "com.android.contacts"
            "clock", "alarm", "घड़ी", "अलार्म" -> "com.google.android.deskclock"
            "calendar", "कैलेंडर" -> "com.google.android.calendar"
            "gallery", "photos", "गैलरी", "फ़ोटो" -> "com.google.android.apps.photos"
            "files", "file manager", "फ़ाइलें" -> "com.google.android.documentsui"
            else -> null
        }

        if (commonPackage != null) {
            val intent = pm.getLaunchIntentForPackage(commonPackage)
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(intent)
                return true
            }
        }

        return false
    }

    // =========================================================================
    // SCREEN READING & NODE EXTRACTION (WITH BANKING SAFETY & NODE RECYCLING)
    // =========================================================================
    fun readScreenSnapshot(): ScreenSnapshot {
        val roots = snapshotRoots()
        return try {
            ScreenSnapshot.fromRoots(roots, this)
        } finally {
            roots.forEach { runCatching { it.recycle() } }
        }
    }

    fun findNodes(text: String?, className: String?, clickable: Boolean?, limit: Int): List<ScreenNodeSnapshot> {
        val needle = text?.trim()?.lowercase()?.takeIf { it.isNotEmpty() }
        val klass = className?.trim()?.takeIf { it.isNotEmpty() }
        val snapshot = readScreenSnapshot()
        if (snapshot.isSafetyBlocked) {
            return emptyList()
        }
        return snapshot.nodes.filter { node ->
            val hay = listOfNotNull(node.text, node.contentDescription).joinToString(" ").lowercase()
            (needle == null || needle in hay) &&
                    (klass == null || node.className == klass) &&
                    (clickable == null || node.clickable == clickable)
        }.take(limit.coerceIn(1, 50))
    }

    fun describeNode(nodeId: String): ScreenNodeSnapshot? =
        readScreenSnapshot().nodes.firstOrNull { it.nodeId == nodeId }

    fun screenHash(): ScreenHash {
        val snapshot = readScreenSnapshot()
        return ScreenHash(
            hash = snapshot.computeHash(),
            nodeCount = snapshot.nodes.size,
            truncated = snapshot.truncated,
            isSafetyBlocked = snapshot.isSafetyBlocked
        )
    }

    private fun snapshotRoots(): List<AccessibilityNodeInfo> {
        val multi = runCatching { windows.mapNotNull { it.root } }.getOrDefault(emptyList())
        return if (multi.isNotEmpty()) multi else listOfNotNull(rootInActiveWindow)
    }

    companion object {
        private const val TAG = "ZoyaAccessibility"
        @Volatile private var instance: AgentVoiceAccessibilityService? = null

        fun get(): AgentVoiceAccessibilityService? = instance
        fun isRunning(): Boolean = instance != null
    }
}

// =============================================================================
// SCREEN DATA MODELS & SAFE NODE PARSER
// =============================================================================

data class ScreenSnapshot(
    val packageName: String?,
    val rootBounds: BoundsSnapshot,
    val nodes: List<ScreenNodeSnapshot>,
    val truncated: Boolean = false,
    val isSafetyBlocked: Boolean = false,
    val safetyMessage: String? = null,
) {
    fun computeHash(): String {
        if (isSafetyBlocked) return "BLOCKED_FOR_SAFETY"
        val joined = nodes.joinToString("\u001e") { node ->
            listOf(
                node.className.orEmpty(),
                node.text.orEmpty(),
                node.contentDescription.orEmpty(),
                node.viewId.orEmpty(),
                "${node.bounds.left},${node.bounds.top},${node.bounds.right},${node.bounds.bottom}",
            ).joinToString("|")
        }
        return MessageDigest.getInstance("SHA-256")
            .digest(joined.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
    }

    companion object {
        private const val MAX_NODES = 512

        fun fromRoots(roots: List<AccessibilityNodeInfo>, service: AgentVoiceAccessibilityService): ScreenSnapshot {
            if (roots.isEmpty()) {
                return ScreenSnapshot(
                    packageName = null,
                    rootBounds = BoundsSnapshot(0, 0, 0, 0),
                    nodes = emptyList(),
                    truncated = false
                )
            }

            // Check if any root belongs to a blocked banking / payment package
            for (root in roots) {
                val pkg = root.packageName?.toString()
                if (BankingSafetyConfig.isPackageBlocked(pkg)) {
                    BankingSafetyConfig.notifySafetyBlocked(service)
                    return ScreenSnapshot(
                        packageName = pkg,
                        rootBounds = BoundsSnapshot(0, 0, 0, 0),
                        nodes = emptyList(),
                        truncated = false,
                        isSafetyBlocked = true,
                        safetyMessage = BankingSafetyConfig.SAFETY_BLOCKED_MESSAGE
                    )
                }
            }

            val nodes = mutableListOf<ScreenNodeSnapshot>()
            var truncated = false
            var packageName: String? = null
            val union = Rect()
            var unionSet = false

            roots.forEachIndexed { windowIndex, root ->
                if (nodes.size >= MAX_NODES) {
                    truncated = true
                    return@forEachIndexed
                }
                if (packageName == null) packageName = root.packageName?.toString()
                val rect = Rect()
                root.getBoundsInScreen(rect)
                if (!unionSet) {
                    union.set(rect)
                    unionSet = true
                } else {
                    union.union(rect)
                }
                walk(root, windowIndex, nodes)
                if (nodes.size >= MAX_NODES) truncated = true
            }

            return ScreenSnapshot(
                packageName = packageName,
                rootBounds = union.toBoundsSnapshot(),
                nodes = nodes.take(MAX_NODES),
                truncated = truncated,
                isSafetyBlocked = false
            )
        }

        private fun walk(node: AccessibilityNodeInfo?, windowIndex: Int, out: MutableList<ScreenNodeSnapshot>) {
            if (node == null || out.size >= MAX_NODES) return

            // STRICT SECURITY: Never extract nodes that represent password/PIN inputs
            if (BankingSafetyConfig.isSensitiveField(node)) {
                return
            }

            val rect = Rect()
            node.getBoundsInScreen(rect)

            // Extract & redact any potential OTP / bank text
            val rawText = node.text?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.take(500)
            val rawDesc = node.contentDescription?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.take(500)

            val text = BankingSafetyConfig.redactSensitiveContent(rawText)
            val desc = BankingSafetyConfig.redactSensitiveContent(rawDesc)

            val interesting = (text.isNotEmpty() || desc.isNotEmpty() || node.isClickable || node.isLongClickable || node.isScrollable || node.isEditable) &&
                    rect.width() > 0 && rect.height() > 0

            if (interesting) {
                out += ScreenNodeSnapshot(
                    nodeId = "w$windowIndex:${out.size}",
                    text = text.ifEmpty { null },
                    contentDescription = desc.ifEmpty { null },
                    className = node.className?.toString(),
                    viewId = node.viewIdResourceName,
                    bounds = rect.toBoundsSnapshot(),
                    clickable = node.isClickable,
                    longClickable = node.isLongClickable,
                    scrollable = node.isScrollable,
                    editable = node.isEditable,
                    enabled = node.isEnabled,
                )
            }

            for (i in 0 until node.childCount) {
                if (out.size >= MAX_NODES) return
                val child = node.getChild(i) ?: continue
                try {
                    walk(child, windowIndex, out)
                } finally {
                    runCatching { child.recycle() }
                }
            }
        }
    }
}

data class ScreenNodeSnapshot(
    val nodeId: String,
    val text: String?,
    val contentDescription: String?,
    val className: String?,
    val viewId: String?,
    val bounds: BoundsSnapshot,
    val clickable: Boolean,
    val longClickable: Boolean,
    val scrollable: Boolean,
    val editable: Boolean,
    val enabled: Boolean,
)

data class BoundsSnapshot(val left: Int, val top: Int, val right: Int, val bottom: Int) {
    val centerX: Int get() = (left + right) / 2
    val centerY: Int get() = (top + bottom) / 2
}

data class ScreenHash(
    val hash: String,
    val nodeCount: Int,
    val truncated: Boolean,
    val isSafetyBlocked: Boolean
)

private fun Rect.toBoundsSnapshot(): BoundsSnapshot = BoundsSnapshot(left, top, right, bottom)
