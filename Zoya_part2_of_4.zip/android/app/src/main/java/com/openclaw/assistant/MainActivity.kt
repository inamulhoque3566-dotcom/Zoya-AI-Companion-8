package com.openclaw.assistant

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.openclaw.assistant.bridge.AndroidBridge
import com.openclaw.assistant.service.ZoyaService
import org.json.JSONObject

/**
 * Zoya AI Main Android Activity
 *
 * Hosts the bundled Zoya Web App (`file:///android_asset/www/index.html`),
 * injects the native `AndroidBridge` JavaScript interface (connecting
 * AgentVoiceAccessibilityService, Android Keystore EncryptedSharedPreferences,
 * Native Release APK Downloader/Installer, ZoyaService (OpenWakeWord), and 3D Hologram Service),
 * and provides official Android KeyguardManager unlock challenges.
 */
class MainActivity : Activity() {

    private var webView: WebView? = null
    private var batteryReceiver: BroadcastReceiver? = null
    private var wakeWordReceiver: BroadcastReceiver? = null
    private var airplaneModeReceiver: BroadcastReceiver? = null
    private var packageReceiver: BroadcastReceiver? = null

    private var isWebViewLoaded = false
    private var pendingWakeDispatch = false
    private var pendingVoiceCommand: String? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        requestRuntimeAudioPermissionIfNeeded()

        val wv = WebView(this)
        webView = wv
        setContentView(wv)

        wv.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = true
            allowContentAccess = true
            @Suppress("DEPRECATION")
            allowFileAccessFromFileURLs = true
            @Suppress("DEPRECATION")
            allowUniversalAccessFromFileURLs = true
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        }

        // Register native AndroidBridge for JS <-> Kotlin calls
        wv.addJavascriptInterface(AndroidBridge(this), "AndroidBridge")

        wv.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                isWebViewLoaded = true
                flushPendingWakeEvents()
            }
        }
        wv.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest?) {
                runOnUiThread {
                    if (request == null) return@runOnUiThread
                    val requested = request.resources ?: emptyArray()
                    val wantsAudio = requested.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)
                    if (wantsAudio) {
                        val hasMic = ContextCompat.checkSelfPermission(
                            this@MainActivity,
                            Manifest.permission.RECORD_AUDIO
                        ) == PackageManager.PERMISSION_GRANTED
                        if (!hasMic) {
                            requestRuntimeAudioPermissionIfNeeded()
                        }
                        if (ZoyaService.isServiceRunning) {
                            try {
                                val pauseIntent = Intent(this@MainActivity, ZoyaService::class.java).apply {
                                    action = ZoyaService.ACTION_PAUSE_TTS
                                }
                                startService(pauseIntent)
                            } catch (e: Exception) {
                                android.util.Log.w("MainActivity", "Failed to pause ZoyaService for WebView audio: ${e.message}")
                            }
                        }
                    }
                    if (requested.isNotEmpty()) {
                        request.grant(requested)
                    } else {
                        request.deny()
                    }
                }
            }
        }

        wv.loadUrl("file:///android_asset/www/index.html")
        registerBatteryMonitor()
        registerAirplaneModeReceiver()
        registerPackageReceiver()
        registerWakeWordReceiver()

        handleWakeIntent(intent)
    }

    private var requestedOverlayOnce = false
    private var requestedBatteryOnce = false

    override fun onResume() {
        super.onResume()
        val hasMic = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (!hasMic) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 1001)
            return
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val hasNotif = ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
            if (!hasNotif) {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1002)
                return
            }
        }
        if (!android.provider.Settings.canDrawOverlays(this) && !requestedOverlayOnce) {
            requestedOverlayOnce = true
            try {
                startActivity(Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION, android.net.Uri.parse("package:$packageName")))
                return
            } catch (_: Exception) {}
        }
        val pm = getSystemService(Context.POWER_SERVICE) as? android.os.PowerManager
        if (pm != null && !pm.isIgnoringBatteryOptimizations(packageName) && !requestedBatteryOnce) {
            requestedBatteryOnce = true
            try {
                startActivity(Intent(android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, android.net.Uri.parse("package:$packageName")))
                return
            } catch (_: Exception) {}
        }

        if (!ZoyaService.isServiceRunning) {
            val intent = Intent(this, ZoyaService::class.java).apply {
                action = ZoyaService.ACTION_START
            }
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    startForegroundService(intent)
                } else {
                    startService(intent)
                }
            } catch (e: Exception) {
                android.util.Log.w("MainActivity", "Could not start ZoyaService: ${e.message}")
            }
        }
    }

    override fun onPause() {
        super.onPause()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleWakeIntent(intent)
    }

    private fun handleWakeIntent(intent: Intent?) {
        if (intent == null) return
        val action = intent.action
        val wakeExtra = intent.getBooleanExtra("wake_detected", false)
        val voiceCmd = intent.getStringExtra("command")?.trim()

        if (wakeExtra || action == ZoyaService.BROADCAST_WAKE_DETECTED) {
            pendingWakeDispatch = true
        }
        if (!voiceCmd.isNullOrEmpty()) {
            pendingVoiceCommand = voiceCmd
        }
        if (isWebViewLoaded) {
            flushPendingWakeEvents()
        }
    }

    private fun flushPendingWakeEvents() {
        val wv = webView ?: return
        if (pendingWakeDispatch) {
            pendingWakeDispatch = false
            val js = "window.dispatchEvent(new CustomEvent('wake-word-detected', { detail: { keyword: 'Hello Zoya', source: 'zoya_intent' } }));"
            runOnUiThread { wv.evaluateJavascript(js, null) }
        }
        val cmd = pendingVoiceCommand
        if (!cmd.isNullOrEmpty()) {
            pendingVoiceCommand = null
            val escaped = JSONObject.quote(cmd)
            val js = "window.dispatchEvent(new CustomEvent('zoya-voice-command', { detail: { command: $escaped } }));"
            runOnUiThread { wv.evaluateJavascript(js, null) }
        }
    }

    private fun registerWakeWordReceiver() {
        if (wakeWordReceiver != null) return
        wakeWordReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                val action = intent?.action ?: return
                when (action) {
                    ZoyaService.BROADCAST_WAKE_DETECTED -> {
                        val js = "window.dispatchEvent(new CustomEvent('wake-word-detected', { detail: { keyword: 'Hey Zoya', source: 'zoya_service' } }));"
                        runOnUiThread {
                            webView?.evaluateJavascript(js, null)
                        }
                    }
                    ZoyaService.BROADCAST_VOICE_COMMAND -> {
                        val command = intent.getStringExtra("command") ?: return
                        val escaped = JSONObject.quote(command)
                        val js = "window.dispatchEvent(new CustomEvent('zoya-voice-command', { detail: { command: $escaped } }));"
                        runOnUiThread {
                            webView?.evaluateJavascript(js, null)
                        }
                    }
                }
            }
        }
        val filter = IntentFilter().apply {
            addAction(ZoyaService.BROADCAST_WAKE_DETECTED)
            addAction(ZoyaService.BROADCAST_VOICE_COMMAND)
        }
        ContextCompat.registerReceiver(
            this,
            wakeWordReceiver,
            filter,
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
    }

    private fun unregisterWakeWordReceiver() {
        try {
            wakeWordReceiver?.let {
                unregisterReceiver(it)
                wakeWordReceiver = null
            }
        } catch (_: Exception) {}
    }

    /**
     * Native Android Battery Monitoring using BatteryManager & Intent broadcast actions.
     */
    private fun registerBatteryMonitor() {
        if (batteryReceiver != null) return
        batteryReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                if (intent == null) return
                val action = intent.action ?: return
                if (action == Intent.ACTION_POWER_CONNECTED ||
                    action == Intent.ACTION_POWER_DISCONNECTED ||
                    action == Intent.ACTION_BATTERY_CHANGED
                ) {
                    val rawLevel = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                    val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
                    val pct = if (rawLevel != -1 && scale > 0) (rawLevel * 100 / scale.toFloat()).toInt() else -1
                    val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                    val isCharging = action == Intent.ACTION_POWER_CONNECTED ||
                            (status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL)

                    val js = "window.dispatchEvent(new CustomEvent('battery-status-changed', { detail: { level: $pct, isCharging: $isCharging, action: '$action' } }));"
                    runOnUiThread {
                        webView?.evaluateJavascript(js, null)
                    }
                }
            }
        }
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_POWER_CONNECTED)
            addAction(Intent.ACTION_POWER_DISCONNECTED)
            addAction(Intent.ACTION_BATTERY_CHANGED)
        }
        registerReceiver(batteryReceiver, filter)
    }

    private fun unregisterBatteryMonitor() {
        try {
            batteryReceiver?.let {
                unregisterReceiver(it)
                batteryReceiver = null
            }
        } catch (_: Exception) {}
    }

    private fun registerAirplaneModeReceiver() {
        if (airplaneModeReceiver != null) return
        airplaneModeReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                if (intent == null) return
                if (intent.action == Intent.ACTION_AIRPLANE_MODE_CHANGED) {
                    val isAirplane = intent.getBooleanExtra("state", false)
                    val js = "window.dispatchEvent(new CustomEvent('airplane-mode-changed', { detail: { isAirplaneMode: $isAirplane } }));"
                    runOnUiThread {
                        webView?.evaluateJavascript(js, null)
                    }
                }
            }
        }
        val filter = IntentFilter(Intent.ACTION_AIRPLANE_MODE_CHANGED)
        registerReceiver(airplaneModeReceiver, filter)
    }

    private fun unregisterAirplaneModeReceiver() {
        try {
            airplaneModeReceiver?.let {
                unregisterReceiver(it)
                airplaneModeReceiver = null
            }
        } catch (_: Exception) {}
    }

    private fun registerPackageReceiver() {
        if (packageReceiver != null) return
        packageReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                if (intent == null || context == null) return
                val action = intent.action ?: return
                val uri = intent.data ?: return
                val packageName = uri.schemeSpecificPart ?: return
                val isReplacing = intent.getBooleanExtra(Intent.EXTRA_REPLACING, false)
                if (isReplacing) return

                val pm = context.packageManager
                val appName = try {
                    val appInfo = pm.getApplicationInfo(packageName, 0)
                    pm.getApplicationLabel(appInfo).toString()
                } catch (e: Exception) {
                    packageName
                }

                val safeAppName = JSONObject.quote(appName)
                if (action == Intent.ACTION_PACKAGE_ADDED) {
                    val js = "window.dispatchEvent(new CustomEvent('app-installed', { detail: { appName: $safeAppName, packageName: '$packageName' } }));"
                    runOnUiThread { webView?.evaluateJavascript(js, null) }
                } else if (action == Intent.ACTION_PACKAGE_REMOVED || action == Intent.ACTION_PACKAGE_FULLY_REMOVED) {
                    val js = "window.dispatchEvent(new CustomEvent('app-uninstalled', { detail: { appName: $safeAppName, packageName: '$packageName' } }));"
                    runOnUiThread { webView?.evaluateJavascript(js, null) }
                }
            }
        }
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_FULLY_REMOVED)
            addDataScheme("package")
        }
        registerReceiver(packageReceiver, filter)
    }

    private fun unregisterPackageReceiver() {
        try {
            packageReceiver?.let {
                unregisterReceiver(it)
                packageReceiver = null
            }
        } catch (_: Exception) {}
    }

    override fun onDestroy() {
        unregisterBatteryMonitor()
        unregisterAirplaneModeReceiver()
        unregisterPackageReceiver()
        unregisterWakeWordReceiver()
        super.onDestroy()
    }

    private fun requestRuntimeAudioPermissionIfNeeded() {
        val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            perms.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        val missing = perms.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), 1001)
        }
    }

    /**
     * Triggers the official Android Keyguard credential/biometric unlock prompt.
     */
    fun requestSystemKeyguardDismiss(): String {
        val km = getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
            ?: return JSONObject()
                .put("success", false)
                .put("error", "KeyguardManager unavailable")
                .toString()

        if (!km.isKeyguardLocked) {
            return JSONObject()
                .put("success", true)
                .put("alreadyUnlocked", true)
                .put("message", "Device is already unlocked.")
                .toString()
        }

        val isSecure = km.isDeviceSecure
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            runOnUiThread {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
                    setShowWhenLocked(true)
                    setTurnScreenOn(true)
                }
                km.requestDismissKeyguard(
                    this,
                    object : KeyguardManager.KeyguardDismissCallback() {
                        private fun clearLockFlags() {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
                                setShowWhenLocked(false)
                                setTurnScreenOn(false)
                            }
                        }

                        override fun onDismissSucceeded() {
                            super.onDismissSucceeded()
                            clearLockFlags()
                            val js = "window.dispatchEvent(new CustomEvent('zoya-keyguard-result', { detail: { success: true, message: 'Phone unlock ho gaya' } }));"
                            webView?.evaluateJavascript(js, null)
                        }

                        override fun onDismissCancelled() {
                            super.onDismissCancelled()
                            clearLockFlags()
                            val js = "window.dispatchEvent(new CustomEvent('zoya-keyguard-result', { detail: { success: false, cancelled: true, message: 'Unlock cancel ho gaya' } }));"
                            webView?.evaluateJavascript(js, null)
                        }

                        override fun onDismissError() {
                            super.onDismissError()
                            clearLockFlags()
                            val js = "window.dispatchEvent(new CustomEvent('zoya-keyguard-result', { detail: { success: false, message: 'Aapko khud PIN/biometric dalna hoga' } }));"
                            webView?.evaluateJavascript(js, null)
                        }
                    }
                )
            }
            val msg = if (isSecure) {
                "Phone secure hai — aapko khud PIN, pattern ya biometric dalna hoga."
            } else {
                "Unlock ho raha hai."
            }
            return JSONObject()
                .put("success", true)
                .put("action", "unlock_device")
                .put("isDeviceSecure", isSecure)
                .put("message", msg)
                .toString()
        }

        return JSONObject()
            .put("success", false)
            .put("error", "Keyguard dismiss requires Android 8.0 (API 26)+")
            .toString()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        val wv = webView
        if (wv != null && wv.canGoBack()) {
            wv.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
